; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.31177 = type { %struct.X86State.31176 }
%struct.X86State.31176 = type { %struct.ArchState.31145, [32 x %union.VectorReg.31148], %struct.ArithFlags.31149, %union.anon.31144, %struct.Segments.31151, %struct.AddressSpace.31153, %struct.GPR.31154, %struct.X87Stack.31157, %struct.MMX.31161, %struct.FPUStatusFlags.31162, %union.anon.31144, %union.FPU.31171, %struct.SegmentCaches.31173, %struct.K_REG.31175 }
%struct.ArchState.31145 = type { i32, i32, %union.anon.31144 }
%union.VectorReg.31148 = type { %union.vec512_t.31147 }
%union.vec512_t.31147 = type { %struct.uint64v8_t.31146 }
%struct.uint64v8_t.31146 = type { [8 x i64] }
%struct.ArithFlags.31149 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.31151 = type { i16, %union.SegmentSelector.31150, i16, %union.SegmentSelector.31150, i16, %union.SegmentSelector.31150, i16, %union.SegmentSelector.31150, i16, %union.SegmentSelector.31150, i16, %union.SegmentSelector.31150 }
%union.SegmentSelector.31150 = type { i16 }
%struct.AddressSpace.31153 = type { i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152 }
%struct.Reg.31152 = type { %union.anon.31144 }
%struct.GPR.31154 = type { i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152, i64, %struct.Reg.31152 }
%struct.X87Stack.31157 = type { [8 x %struct.anon.3.31156] }
%struct.anon.3.31156 = type { [6 x i8], %struct.float80_t.31155 }
%struct.float80_t.31155 = type { [10 x i8] }
%struct.MMX.31161 = type { [8 x %struct.anon.4.31160] }
%struct.anon.4.31160 = type { i64, %union.vec64_t.31159 }
%union.vec64_t.31159 = type { %struct.uint64v1_t.31158 }
%struct.uint64v1_t.31158 = type { [1 x i64] }
%struct.FPUStatusFlags.31162 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.31144 = type { i64 }
%union.FPU.31171 = type { %struct.anon.13.31170 }
%struct.anon.13.31170 = type { %struct.FpuFXSAVE.31169, [96 x i8] }
%struct.FpuFXSAVE.31169 = type { %union.SegmentSelector.31150, %union.SegmentSelector.31150, %union.FPUAbridgedTagWord.31163, i8, i16, i32, %union.SegmentSelector.31150, i16, i32, %union.SegmentSelector.31150, i16, %union.FPUControlStatus.31164, %union.FPUControlStatus.31164, [8 x %struct.FPUStackElem.31166], [16 x %union.vec128_t.31168] }
%union.FPUAbridgedTagWord.31163 = type { i8 }
%union.FPUControlStatus.31164 = type { i32 }
%struct.FPUStackElem.31166 = type { %union.anon.11.31165, [6 x i8] }
%union.anon.11.31165 = type { %struct.float80_t.31155 }
%union.vec128_t.31168 = type { %struct.uint128v1_t.31167 }
%struct.uint128v1_t.31167 = type { [1 x i128] }
%struct.SegmentCaches.31173 = type { %struct.SegmentShadow.31172, %struct.SegmentShadow.31172, %struct.SegmentShadow.31172, %struct.SegmentShadow.31172, %struct.SegmentShadow.31172, %struct.SegmentShadow.31172 }
%struct.SegmentShadow.31172 = type { %union.anon.31144, i32, i32 }
%struct.K_REG.31175 = type { [8 x %struct.anon.18.31174] }
%struct.anon.18.31174 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1139(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i30 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #16
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i30, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 32
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 32
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 32, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 32
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 20
  %34 = load i32, ptr %EDI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #16
  store ptr %call.i.i28, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 32
  %42 = load i64, ptr %RSI, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #16
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 20
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %49, i64 noundef %48) #16
  %sub.i.i1 = sub i32 %call.i.i, 1
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, 1
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #16
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %51 = and i8 %50, 1
  %conv.i.i.i6 = xor i8 %51, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, 1
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %52 = trunc i32 %xor1.i.i.i.i9 to i8
  %53 = lshr i8 %52, 4
  %conv2.i.i.i10 = and i8 %53, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, 1
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #16
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %44
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  %58 = add i64 %57, 7
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 7
  %61 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %61, 0
  %sf.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool10.i = icmp eq i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool12.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool10.i, %tobool12.i
  %64 = and i1 %tobool.not.i, %cmp.i.i
  %call15.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %64) #17
  %frombool.i = zext i1 %call15.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call15.i, i64 %58, i64 %59
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %60, ptr %MEMORY, align 8
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  ret ptr %66
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1159(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 8, %10
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %10
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 8
  %12 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %14 = and i8 %13, 1
  %conv.i.i.i = xor i8 %14, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 8
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %10
  %15 = trunc i64 %xor1.i.i.i.i to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i = and i8 %16, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %10
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 3
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i64, ptr %RAX, align 8
  %21 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %21, i64 noundef %20) #16
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %21, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %17
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 3
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call zeroext i8 @__remill_read_memory_8(ptr noundef %26, i64 noundef %25) #16
  %conv.i.i7 = zext i8 %call.i.i6 to i64
  store i64 %conv.i.i7, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %22
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i8, ptr %AL, align 1
  %31 = zext i8 %30 to i64
  %32 = load ptr, ptr %MEMORY, align 8
  %conv.i.i8 = trunc i64 %31 to i32
  %sext.i = shl i32 %conv.i.i8, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RBP, align 8
  %37 = sub i64 %36, 4
  %38 = load i32, ptr %EAX, align 4
  %39 = zext i32 %38 to i64
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %40, i64 noundef %37, i32 noundef %38) #16
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %33
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RBP, align 8
  %45 = sub i64 %44, 4
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #16
  %conv.i.i3 = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i3, ptr %RAX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i32, ptr %EAX, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %51, 4294967295
  store i64 %conv.i11.i, ptr %RDI, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 5
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %53
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 5
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %NEXT_PC, align 8
  %61 = sub i64 %60, 284
  %62 = load i64, ptr %NEXT_PC, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %64 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %64, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %63, i64 noundef %sub.i.i, i64 noundef %62) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %61, ptr %rip.i, align 8
  store i64 %61, ptr %NEXT_PC, align 8
  store i64 %62, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  ret ptr %65
}

define ptr @BB_1152(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 2
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 71
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_findsum(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_findsum(ptr, i64, ptr) #2

define ptr @BB_11a0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #16
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #16
  %rip.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_117c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load i32, ptr %EAX, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %8, i64 noundef %5, i32 noundef %6) #16
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 3
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 8
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #16
  %conv.i.i4 = zext i32 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RDX, align 8
  store ptr %14, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RBP, align 8
  %19 = sub i64 %18, 4
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %20, i64 noundef %19) #16
  %conv.i.i = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %20, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %15
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i32, ptr %EAX, align 4
  %25 = zext i32 %24 to i64
  %26 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %25, 4294967295
  store i64 %conv.i11.i, ptr %RSI, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 7
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %NEXT_PC, align 8
  %31 = add i64 %30, 3698
  %32 = load ptr, ptr %MEMORY, align 8
  store i64 %31, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RAX, align 8
  %37 = load ptr, ptr %MEMORY, align 8
  store i64 %36, ptr %RDI, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %33
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 5
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %38
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 5
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %NEXT_PC, align 8
  %46 = sub i64 %45, 299
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %49 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %49, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %sub.i.i, i64 noundef %47) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %46, ptr %rip.i, align 8
  store i64 %46, ptr %NEXT_PC, align 8
  store i64 %47, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  ret ptr %50
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #4

define ptr @BB_119b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31177, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #5 {
entry:
  %agg.tmp = alloca %struct.State.31177, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.31177) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #18
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.31177) align 16, i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rax = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #10 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4409, label %bb_1139
    i64 4434, label %bb_1152
    i64 4441, label %bb_1159
    i64 4476, label %bb_117C
    i64 4507, label %bb_119B
    i64 4512, label %bb_11A0
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
  ]

dead_end:                                         ; preds = %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_119B, %bb_117C, %bb_1159, %bb_1152, %bb_1139, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1139:                                          ; preds = %entry
  %block_pc = add i64 4409, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4409, ptr %1)
  %4 = call ptr @BB_1139(ptr %state, i64 %2, ptr %1) #19
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4434, label %bb_1152
    i64 4441, label %bb_1159
  ]

bb_1152:                                          ; preds = %bb_1139, %entry
  %block_pc1 = add i64 4434, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4434, ptr %6)
  %9 = call ptr @BB_1152(ptr %state, i64 %7, ptr %6) #19
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4512, label %bb_11A0
  ]

bb_1159:                                          ; preds = %bb_1139, %entry
  %block_pc3 = add i64 4441, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4441, ptr %11)
  %14 = call ptr @BB_1159(ptr %state, i64 %12, ptr %11) #19
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4192, label %bb_FFFF000000000000
  ]

bb_117C:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc5 = add i64 4476, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4476, ptr %16)
  %19 = call ptr @BB_117c(ptr %state, i64 %17, ptr %16) #19
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4208, label %bb_FFFF000000000001
  ]

bb_119B:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc7 = add i64 4507, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4507, ptr %21)
  %24 = call ptr @BB_119b(ptr %state, i64 %22, ptr %21) #19
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4512, label %bb_11A0
  ]

bb_11A0:                                          ; preds = %bb_119B, %bb_1152, %entry
  %block_pc9 = add i64 4512, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4512, ptr %26)
  %29 = call ptr @BB_11a0(ptr %state, i64 %27, ptr %26) #19
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  %31 = load ptr, ptr %mem_var, align 8
  ret ptr %31

bb_FFFF000000000000:                              ; preds = %bb_1159, %entry
  %32 = load ptr, ptr %mem_var, align 8
  %33 = load i64, ptr %pc_var, align 4
  %34 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %33, ptr %32) #19
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva11 = sub i64 %35, %base
  switch i64 %next_rva11, label %dead_end [
    i64 4476, label %bb_117C
  ]

bb_FFFF000000000001:                              ; preds = %bb_117C, %entry
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %37, ptr %36) #19
  store ptr %38, ptr %mem_var, align 8
  %39 = call i64 @__extract_rip(ptr %state)
  store i64 %39, ptr %pc_var, align 4
  %next_rva12 = sub i64 %39, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4507, label %bb_119B
  ]

return_bb:                                        ; No predecessors!
  %40 = load ptr, ptr %mem_var, align 8
  ret ptr %40
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #11 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4409, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #12 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() local_unnamed_addr #12 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #12 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #12 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #12 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #13 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.31176, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !23
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #18 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #19 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24, !24, i64 0}
!24 = !{!"omnipotent char", !25, i64 0}
!25 = !{!"Simple C++ TBAA"}
