; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.951 = type { %struct.X86State.950 }
%struct.X86State.950 = type { %struct.ArchState.919, [32 x %union.VectorReg.922], %struct.ArithFlags.923, %union.anon.918, %struct.Segments.925, %struct.AddressSpace.927, %struct.GPR.928, %struct.X87Stack.931, %struct.MMX.935, %struct.FPUStatusFlags.936, %union.anon.918, %union.FPU.945, %struct.SegmentCaches.947, %struct.K_REG.949 }
%struct.ArchState.919 = type { i32, i32, %union.anon.918 }
%union.VectorReg.922 = type { %union.vec512_t.921 }
%union.vec512_t.921 = type { %struct.uint64v8_t.920 }
%struct.uint64v8_t.920 = type { [8 x i64] }
%struct.ArithFlags.923 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.925 = type { i16, %union.SegmentSelector.924, i16, %union.SegmentSelector.924, i16, %union.SegmentSelector.924, i16, %union.SegmentSelector.924, i16, %union.SegmentSelector.924, i16, %union.SegmentSelector.924 }
%union.SegmentSelector.924 = type { i16 }
%struct.AddressSpace.927 = type { i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926 }
%struct.Reg.926 = type { %union.anon.918 }
%struct.GPR.928 = type { i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926, i64, %struct.Reg.926 }
%struct.X87Stack.931 = type { [8 x %struct.anon.3.930] }
%struct.anon.3.930 = type { [6 x i8], %struct.float80_t.929 }
%struct.float80_t.929 = type { [10 x i8] }
%struct.MMX.935 = type { [8 x %struct.anon.4.934] }
%struct.anon.4.934 = type { i64, %union.vec64_t.933 }
%union.vec64_t.933 = type { %struct.uint64v1_t.932 }
%struct.uint64v1_t.932 = type { [1 x i64] }
%struct.FPUStatusFlags.936 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.918 = type { i64 }
%union.FPU.945 = type { %struct.anon.13.944 }
%struct.anon.13.944 = type { %struct.FpuFXSAVE.943, [96 x i8] }
%struct.FpuFXSAVE.943 = type { %union.SegmentSelector.924, %union.SegmentSelector.924, %union.FPUAbridgedTagWord.937, i8, i16, i32, %union.SegmentSelector.924, i16, i32, %union.SegmentSelector.924, i16, %union.FPUControlStatus.938, %union.FPUControlStatus.938, [8 x %struct.FPUStackElem.940], [16 x %union.vec128_t.942] }
%union.FPUAbridgedTagWord.937 = type { i8 }
%union.FPUControlStatus.938 = type { i32 }
%struct.FPUStackElem.940 = type { %union.anon.11.939, [6 x i8] }
%union.anon.11.939 = type { %struct.float80_t.929 }
%union.vec128_t.942 = type { %struct.uint128v1_t.941 }
%struct.uint128v1_t.941 = type { [1 x i128] }
%struct.SegmentCaches.947 = type { %struct.SegmentShadow.946, %struct.SegmentShadow.946, %struct.SegmentShadow.946, %struct.SegmentShadow.946, %struct.SegmentShadow.946, %struct.SegmentShadow.946 }
%struct.SegmentShadow.946 = type { %union.anon.918, i32, i32 }
%struct.K_REG.949 = type { [8 x %struct.anon.18.948] }
%struct.anon.18.948 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_10f9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.951, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i418 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i418, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 52
  %25 = load i32, ptr %EDI, align 4
  %26 = zext i32 %25 to i64
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i332 = call ptr @__remill_write_memory_32(ptr noundef %27, i64 noundef %24, i32 noundef %25) #13
  store ptr %call.i.i332, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 56
  %33 = load i32, ptr %ESI, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i331 = call ptr @__remill_write_memory_32(ptr noundef %35, i64 noundef %32, i32 noundef %33) #13
  store ptr %call.i.i331, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %28
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 60
  %41 = load i32, ptr %EDX, align 4
  %42 = zext i32 %41 to i64
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i330 = call ptr @__remill_write_memory_32(ptr noundef %43, i64 noundef %40, i32 noundef %41) #13
  store ptr %call.i.i330, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %36
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 72
  %49 = load i64, ptr %RCX, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i333 = call ptr @__remill_write_memory_64(ptr noundef %50, i64 noundef %48, i64 noundef %49) #13
  store ptr %call.i.i333, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %44
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 3
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RBP, align 8
  %55 = sub i64 %54, 52
  %56 = load ptr, ptr %MEMORY, align 8
  %call.i.i369 = call i32 @__remill_read_memory_32(ptr noundef %56, i64 noundef %55) #13
  %conv.i.i370 = zext i32 %call.i.i369 to i64
  store i64 %conv.i.i370, ptr %RAX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %51
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 2
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %rax.i315 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %61 = load i32, ptr %rax.i315, align 8
  %conv.i.i316 = sext i32 %61 to i64
  store i64 %conv.i.i316, ptr %rax.i315, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %57
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 8
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RAX, align 8
  %66 = mul i64 %65, 4
  %67 = add i64 0, %66
  %68 = load ptr, ptr %MEMORY, align 8
  store i64 %67, ptr %RDX, align 8
  store ptr %68, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %62
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 4
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RBP, align 8
  %73 = sub i64 %72, 72
  %74 = load ptr, ptr %MEMORY, align 8
  %call.i.i373 = call i64 @__remill_read_memory_64(ptr noundef %74, i64 noundef %73) #13
  store i64 %call.i.i373, ptr %RAX, align 8
  store ptr %74, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %69
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RAX, align 8
  %79 = load i64, ptr %RDX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %add.i.i276 = add i64 %79, %78
  store i64 %add.i.i276, ptr %RAX, align 8
  %cmp.i.i.i277 = icmp ult i64 %add.i.i276, %78
  %cmp1.i.i.i278 = icmp ult i64 %add.i.i276, %79
  %81 = or i1 %cmp.i.i.i277, %cmp1.i.i.i278
  %call.i.i.i279 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %81, i64 noundef %78, i64 noundef %79, i64 noundef %add.i.i276) #13
  %conv.i.i280 = zext i1 %call.i.i.i279 to i8
  %cf.i.i281 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i280, ptr %cf.i.i281, align 1
  %conv.i.i.i.i282 = trunc i64 %add.i.i276 to i8
  %82 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i282)
  %83 = and i8 %82, 1
  %conv.i.i.i283 = xor i8 %83, 1
  %pf.i.i.i284 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i283, ptr %pf.i.i.i284, align 1
  %xor.i.i.i.i285 = xor i64 %add.i.i276, %79
  %xor1.i.i.i.i286 = xor i64 %xor.i.i.i.i285, %78
  %84 = trunc i64 %xor1.i.i.i.i286 to i8
  %85 = lshr i8 %84, 4
  %conv2.i.i.i287 = and i8 %85, 1
  %af.i.i.i288 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i287, ptr %af.i.i.i288, align 1
  %cmp.i.i.i.i289 = icmp eq i64 %add.i.i276, 0
  %call.i.i.i.i290 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i289, i64 noundef %78, i64 noundef %79, i64 noundef %add.i.i276) #13
  %conv5.i.i.i291 = zext i1 %call.i.i.i.i290 to i8
  %zf.i.i.i292 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i291, ptr %zf.i.i.i292, align 1
  %cmp.i27.i.i.i293 = icmp slt i64 %add.i.i276, 0
  %call1.i.i.i.i294 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i293, i64 noundef %78, i64 noundef %79, i64 noundef %add.i.i276) #13
  %conv8.i.i.i295 = zext i1 %call1.i.i.i.i294 to i8
  %sf.i.i.i296 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i295, ptr %sf.i.i.i296, align 1
  %shr8.i.i.i.i297 = xor i64 %add.i.i276, %78
  %xor.i28.i.i.i298 = lshr i64 %shr8.i.i.i.i297, 63
  %xor3.i.i.i.i299 = lshr i64 %xor.i.i.i.i285, 63
  %add.i.i.i.i300 = add nuw nsw i64 %xor.i28.i.i.i298, %xor3.i.i.i.i299
  %cmp.i29.i.i.i301 = icmp eq i64 %add.i.i.i.i300, 2
  %call.i30.i.i.i302 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i301, i64 noundef %78, i64 noundef %79, i64 noundef %add.i.i276) #13
  %conv11.i.i.i303 = zext i1 %call.i30.i.i.i302 to i8
  %of.i.i.i304 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i303, ptr %of.i.i.i304, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %86

86:                                               ; preds = %75
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = add i64 %87, 2
  store i64 %88, ptr %NEXT_PC, align 8
  %89 = load i64, ptr %RAX, align 8
  %90 = load ptr, ptr %MEMORY, align 8
  %call.i.i367 = call i32 @__remill_read_memory_32(ptr noundef %90, i64 noundef %89) #13
  %conv.i.i368 = zext i32 %call.i.i367 to i64
  store i64 %conv.i.i368, ptr %RAX, align 8
  store ptr %90, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %86
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i64, ptr %RBP, align 8
  %95 = sub i64 %94, 5
  %96 = load i8, ptr %AL, align 1
  %97 = zext i8 %96 to i64
  %98 = load ptr, ptr %MEMORY, align 8
  %call.i.i321 = call ptr @__remill_write_memory_8(ptr noundef %98, i64 noundef %95, i8 noundef zeroext %96) #13
  store ptr %call.i.i321, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %91
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RBP, align 8
  %103 = sub i64 %102, 56
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i365 = call i32 @__remill_read_memory_32(ptr noundef %104, i64 noundef %103) #13
  %conv.i.i366 = zext i32 %call.i.i365 to i64
  store i64 %conv.i.i366, ptr %RAX, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %99
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 2
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %rax.i313 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %109 = load i32, ptr %rax.i313, align 8
  %conv.i.i314 = sext i32 %109 to i64
  store i64 %conv.i.i314, ptr %rax.i313, align 8
  store ptr %108, ptr %MEMORY, align 8
  br label %110

110:                                              ; preds = %105
  %111 = load i64, ptr %NEXT_PC, align 8
  store i64 %111, ptr %PC, align 8
  %112 = add i64 %111, 8
  store i64 %112, ptr %NEXT_PC, align 8
  %113 = load i64, ptr %RAX, align 8
  %114 = mul i64 %113, 4
  %115 = add i64 0, %114
  %116 = load ptr, ptr %MEMORY, align 8
  store i64 %115, ptr %RDX, align 8
  store ptr %116, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %110
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 4
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %RBP, align 8
  %121 = sub i64 %120, 72
  %122 = load ptr, ptr %MEMORY, align 8
  %call.i.i372 = call i64 @__remill_read_memory_64(ptr noundef %122, i64 noundef %121) #13
  store i64 %call.i.i372, ptr %RAX, align 8
  store ptr %122, ptr %MEMORY, align 8
  br label %123

123:                                              ; preds = %117
  %124 = load i64, ptr %NEXT_PC, align 8
  store i64 %124, ptr %PC, align 8
  %125 = add i64 %124, 3
  store i64 %125, ptr %NEXT_PC, align 8
  %126 = load i64, ptr %RAX, align 8
  %127 = load i64, ptr %RDX, align 8
  %128 = load ptr, ptr %MEMORY, align 8
  %add.i.i247 = add i64 %127, %126
  store i64 %add.i.i247, ptr %RAX, align 8
  %cmp.i.i.i248 = icmp ult i64 %add.i.i247, %126
  %cmp1.i.i.i249 = icmp ult i64 %add.i.i247, %127
  %129 = or i1 %cmp.i.i.i248, %cmp1.i.i.i249
  %call.i.i.i250 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %129, i64 noundef %126, i64 noundef %127, i64 noundef %add.i.i247) #13
  %conv.i.i251 = zext i1 %call.i.i.i250 to i8
  %cf.i.i252 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i251, ptr %cf.i.i252, align 1
  %conv.i.i.i.i253 = trunc i64 %add.i.i247 to i8
  %130 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i253)
  %131 = and i8 %130, 1
  %conv.i.i.i254 = xor i8 %131, 1
  %pf.i.i.i255 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i254, ptr %pf.i.i.i255, align 1
  %xor.i.i.i.i256 = xor i64 %add.i.i247, %127
  %xor1.i.i.i.i257 = xor i64 %xor.i.i.i.i256, %126
  %132 = trunc i64 %xor1.i.i.i.i257 to i8
  %133 = lshr i8 %132, 4
  %conv2.i.i.i258 = and i8 %133, 1
  %af.i.i.i259 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i258, ptr %af.i.i.i259, align 1
  %cmp.i.i.i.i260 = icmp eq i64 %add.i.i247, 0
  %call.i.i.i.i261 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i260, i64 noundef %126, i64 noundef %127, i64 noundef %add.i.i247) #13
  %conv5.i.i.i262 = zext i1 %call.i.i.i.i261 to i8
  %zf.i.i.i263 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i262, ptr %zf.i.i.i263, align 1
  %cmp.i27.i.i.i264 = icmp slt i64 %add.i.i247, 0
  %call1.i.i.i.i265 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i264, i64 noundef %126, i64 noundef %127, i64 noundef %add.i.i247) #13
  %conv8.i.i.i266 = zext i1 %call1.i.i.i.i265 to i8
  %sf.i.i.i267 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i266, ptr %sf.i.i.i267, align 1
  %shr8.i.i.i.i268 = xor i64 %add.i.i247, %126
  %xor.i28.i.i.i269 = lshr i64 %shr8.i.i.i.i268, 63
  %xor3.i.i.i.i270 = lshr i64 %xor.i.i.i.i256, 63
  %add.i.i.i.i271 = add nuw nsw i64 %xor.i28.i.i.i269, %xor3.i.i.i.i270
  %cmp.i29.i.i.i272 = icmp eq i64 %add.i.i.i.i271, 2
  %call.i30.i.i.i273 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i272, i64 noundef %126, i64 noundef %127, i64 noundef %add.i.i247) #13
  %conv11.i.i.i274 = zext i1 %call.i30.i.i.i273 to i8
  %of.i.i.i275 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i274, ptr %of.i.i.i275, align 1
  store ptr %128, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %123
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 2
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RAX, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  %call.i.i363 = call i32 @__remill_read_memory_32(ptr noundef %138, i64 noundef %137) #13
  %conv.i.i364 = zext i32 %call.i.i363 to i64
  store i64 %conv.i.i364, ptr %RAX, align 8
  store ptr %138, ptr %MEMORY, align 8
  br label %139

139:                                              ; preds = %134
  %140 = load i64, ptr %NEXT_PC, align 8
  store i64 %140, ptr %PC, align 8
  %141 = add i64 %140, 3
  store i64 %141, ptr %NEXT_PC, align 8
  %142 = load i64, ptr %RBP, align 8
  %143 = sub i64 %142, 4
  %144 = load i8, ptr %AL, align 1
  %145 = zext i8 %144 to i64
  %146 = load ptr, ptr %MEMORY, align 8
  %call.i.i320 = call ptr @__remill_write_memory_8(ptr noundef %146, i64 noundef %143, i8 noundef zeroext %144) #13
  store ptr %call.i.i320, ptr %MEMORY, align 8
  br label %147

147:                                              ; preds = %139
  %148 = load i64, ptr %NEXT_PC, align 8
  store i64 %148, ptr %PC, align 8
  %149 = add i64 %148, 3
  store i64 %149, ptr %NEXT_PC, align 8
  %150 = load i64, ptr %RBP, align 8
  %151 = sub i64 %150, 60
  %152 = load ptr, ptr %MEMORY, align 8
  %call.i.i361 = call i32 @__remill_read_memory_32(ptr noundef %152, i64 noundef %151) #13
  %conv.i.i362 = zext i32 %call.i.i361 to i64
  store i64 %conv.i.i362, ptr %RAX, align 8
  store ptr %152, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %147
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 2
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load ptr, ptr %MEMORY, align 8
  %rax.i311 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %157 = load i32, ptr %rax.i311, align 8
  %conv.i.i312 = sext i32 %157 to i64
  store i64 %conv.i.i312, ptr %rax.i311, align 8
  store ptr %156, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %153
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 8
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RAX, align 8
  %162 = mul i64 %161, 4
  %163 = add i64 0, %162
  %164 = load ptr, ptr %MEMORY, align 8
  store i64 %163, ptr %RDX, align 8
  store ptr %164, ptr %MEMORY, align 8
  br label %165

165:                                              ; preds = %158
  %166 = load i64, ptr %NEXT_PC, align 8
  store i64 %166, ptr %PC, align 8
  %167 = add i64 %166, 4
  store i64 %167, ptr %NEXT_PC, align 8
  %168 = load i64, ptr %RBP, align 8
  %169 = sub i64 %168, 72
  %170 = load ptr, ptr %MEMORY, align 8
  %call.i.i371 = call i64 @__remill_read_memory_64(ptr noundef %170, i64 noundef %169) #13
  store i64 %call.i.i371, ptr %RAX, align 8
  store ptr %170, ptr %MEMORY, align 8
  br label %171

171:                                              ; preds = %165
  %172 = load i64, ptr %NEXT_PC, align 8
  store i64 %172, ptr %PC, align 8
  %173 = add i64 %172, 3
  store i64 %173, ptr %NEXT_PC, align 8
  %174 = load i64, ptr %RAX, align 8
  %175 = load i64, ptr %RDX, align 8
  %176 = load ptr, ptr %MEMORY, align 8
  %add.i.i218 = add i64 %175, %174
  store i64 %add.i.i218, ptr %RAX, align 8
  %cmp.i.i.i219 = icmp ult i64 %add.i.i218, %174
  %cmp1.i.i.i220 = icmp ult i64 %add.i.i218, %175
  %177 = or i1 %cmp.i.i.i219, %cmp1.i.i.i220
  %call.i.i.i221 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %177, i64 noundef %174, i64 noundef %175, i64 noundef %add.i.i218) #13
  %conv.i.i222 = zext i1 %call.i.i.i221 to i8
  %cf.i.i223 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i222, ptr %cf.i.i223, align 1
  %conv.i.i.i.i224 = trunc i64 %add.i.i218 to i8
  %178 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i224)
  %179 = and i8 %178, 1
  %conv.i.i.i225 = xor i8 %179, 1
  %pf.i.i.i226 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i225, ptr %pf.i.i.i226, align 1
  %xor.i.i.i.i227 = xor i64 %add.i.i218, %175
  %xor1.i.i.i.i228 = xor i64 %xor.i.i.i.i227, %174
  %180 = trunc i64 %xor1.i.i.i.i228 to i8
  %181 = lshr i8 %180, 4
  %conv2.i.i.i229 = and i8 %181, 1
  %af.i.i.i230 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i229, ptr %af.i.i.i230, align 1
  %cmp.i.i.i.i231 = icmp eq i64 %add.i.i218, 0
  %call.i.i.i.i232 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i231, i64 noundef %174, i64 noundef %175, i64 noundef %add.i.i218) #13
  %conv5.i.i.i233 = zext i1 %call.i.i.i.i232 to i8
  %zf.i.i.i234 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i233, ptr %zf.i.i.i234, align 1
  %cmp.i27.i.i.i235 = icmp slt i64 %add.i.i218, 0
  %call1.i.i.i.i236 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i235, i64 noundef %174, i64 noundef %175, i64 noundef %add.i.i218) #13
  %conv8.i.i.i237 = zext i1 %call1.i.i.i.i236 to i8
  %sf.i.i.i238 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i237, ptr %sf.i.i.i238, align 1
  %shr8.i.i.i.i239 = xor i64 %add.i.i218, %174
  %xor.i28.i.i.i240 = lshr i64 %shr8.i.i.i.i239, 63
  %xor3.i.i.i.i241 = lshr i64 %xor.i.i.i.i227, 63
  %add.i.i.i.i242 = add nuw nsw i64 %xor.i28.i.i.i240, %xor3.i.i.i.i241
  %cmp.i29.i.i.i243 = icmp eq i64 %add.i.i.i.i242, 2
  %call.i30.i.i.i244 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i243, i64 noundef %174, i64 noundef %175, i64 noundef %add.i.i218) #13
  %conv11.i.i.i245 = zext i1 %call.i30.i.i.i244 to i8
  %of.i.i.i246 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i245, ptr %of.i.i.i246, align 1
  store ptr %176, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %171
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 2
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load i64, ptr %RAX, align 8
  %186 = load ptr, ptr %MEMORY, align 8
  %call.i.i359 = call i32 @__remill_read_memory_32(ptr noundef %186, i64 noundef %185) #13
  %conv.i.i360 = zext i32 %call.i.i359 to i64
  store i64 %conv.i.i360, ptr %RAX, align 8
  store ptr %186, ptr %MEMORY, align 8
  br label %187

187:                                              ; preds = %182
  %188 = load i64, ptr %NEXT_PC, align 8
  store i64 %188, ptr %PC, align 8
  %189 = add i64 %188, 3
  store i64 %189, ptr %NEXT_PC, align 8
  %190 = load i64, ptr %RBP, align 8
  %191 = sub i64 %190, 3
  %192 = load i8, ptr %AL, align 1
  %193 = zext i8 %192 to i64
  %194 = load ptr, ptr %MEMORY, align 8
  %call.i.i319 = call ptr @__remill_write_memory_8(ptr noundef %194, i64 noundef %191, i8 noundef zeroext %192) #13
  store ptr %call.i.i319, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %187
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 4
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i64, ptr %RBP, align 8
  %199 = sub i64 %198, 5
  %200 = load ptr, ptr %MEMORY, align 8
  %call.i.i392 = call zeroext i8 @__remill_read_memory_8(ptr noundef %200, i64 noundef %199) #13
  %conv.i.i393 = zext i8 %call.i.i392 to i64
  store i64 %conv.i.i393, ptr %RAX, align 8
  store ptr %200, ptr %MEMORY, align 8
  br label %201

201:                                              ; preds = %195
  %202 = load i64, ptr %NEXT_PC, align 8
  store i64 %202, ptr %PC, align 8
  %203 = add i64 %202, 2
  store i64 %203, ptr %NEXT_PC, align 8
  %204 = load i32, ptr %EAX, align 4
  %205 = zext i32 %204 to i64
  %206 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i334 = and i64 %205, 4294967295
  store i64 %conv.i11.i334, ptr %RDX, align 8
  store ptr %206, ptr %MEMORY, align 8
  br label %207

207:                                              ; preds = %201
  %208 = load i64, ptr %NEXT_PC, align 8
  store i64 %208, ptr %PC, align 8
  %209 = add i64 %208, 4
  store i64 %209, ptr %NEXT_PC, align 8
  %210 = load i64, ptr %RBP, align 8
  %211 = sub i64 %210, 4
  %212 = load ptr, ptr %MEMORY, align 8
  %call.i.i390 = call zeroext i8 @__remill_read_memory_8(ptr noundef %212, i64 noundef %211) #13
  %conv.i.i391 = zext i8 %call.i.i390 to i64
  store i64 %conv.i.i391, ptr %RAX, align 8
  store ptr %212, ptr %MEMORY, align 8
  br label %213

213:                                              ; preds = %207
  %214 = load i64, ptr %NEXT_PC, align 8
  store i64 %214, ptr %PC, align 8
  %215 = add i64 %214, 2
  store i64 %215, ptr %NEXT_PC, align 8
  %216 = load i64, ptr %RAX, align 8
  %217 = load i32, ptr %EDX, align 4
  %218 = zext i32 %217 to i64
  %219 = load ptr, ptr %MEMORY, align 8
  %conv.i.i187 = trunc i64 %216 to i32
  %add.i.i188 = add i32 %217, %conv.i.i187
  %conv.i22.i189 = zext i32 %add.i.i188 to i64
  store i64 %conv.i22.i189, ptr %RAX, align 8
  %cmp.i.i.i190 = icmp ult i32 %add.i.i188, %conv.i.i187
  %cmp1.i.i.i191 = icmp ult i32 %add.i.i188, %217
  %220 = or i1 %cmp.i.i.i190, %cmp1.i.i.i191
  %call.i.i.i192 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %220, i32 noundef %conv.i.i187, i32 noundef %217, i32 noundef %add.i.i188) #13
  %conv.i23.i193 = zext i1 %call.i.i.i192 to i8
  %cf.i.i194 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i193, ptr %cf.i.i194, align 1
  %conv.i.i.i.i195 = trunc i32 %add.i.i188 to i8
  %221 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i195)
  %222 = and i8 %221, 1
  %conv.i.i.i196 = xor i8 %222, 1
  %pf.i.i.i197 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i196, ptr %pf.i.i.i197, align 1
  %xor.i.i.i.i198 = xor i32 %add.i.i188, %217
  %xor1.i.i.i.i199 = xor i32 %xor.i.i.i.i198, %conv.i.i187
  %223 = trunc i32 %xor1.i.i.i.i199 to i8
  %224 = lshr i8 %223, 4
  %conv2.i.i.i200 = and i8 %224, 1
  %af.i.i.i201 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i200, ptr %af.i.i.i201, align 1
  %cmp.i.i.i.i202 = icmp eq i32 %add.i.i188, 0
  %call.i.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i202, i32 noundef %conv.i.i187, i32 noundef %217, i32 noundef %add.i.i188) #13
  %conv5.i.i.i204 = zext i1 %call.i.i.i.i203 to i8
  %zf.i.i.i205 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i204, ptr %zf.i.i.i205, align 1
  %cmp.i27.i.i.i206 = icmp slt i32 %add.i.i188, 0
  %call1.i.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i206, i32 noundef %conv.i.i187, i32 noundef %217, i32 noundef %add.i.i188) #13
  %conv8.i.i.i208 = zext i1 %call1.i.i.i.i207 to i8
  %sf.i.i.i209 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i208, ptr %sf.i.i.i209, align 1
  %shr8.i.i.i.i210 = xor i32 %add.i.i188, %conv.i.i187
  %xor.i28.i.i.i211 = lshr i32 %shr8.i.i.i.i210, 31
  %xor3.i.i.i.i212 = lshr i32 %xor.i.i.i.i198, 31
  %add.i.i.i.i213 = add nuw nsw i32 %xor.i28.i.i.i211, %xor3.i.i.i.i212
  %cmp.i29.i.i.i214 = icmp eq i32 %add.i.i.i.i213, 2
  %call.i30.i.i.i215 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i214, i32 noundef %conv.i.i187, i32 noundef %217, i32 noundef %add.i.i188) #13
  %conv11.i.i.i216 = zext i1 %call.i30.i.i.i215 to i8
  %of.i.i.i217 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i216, ptr %of.i.i.i217, align 1
  store ptr %219, ptr %MEMORY, align 8
  br label %225

225:                                              ; preds = %213
  %226 = load i64, ptr %NEXT_PC, align 8
  store i64 %226, ptr %PC, align 8
  %227 = add i64 %226, 3
  store i64 %227, ptr %NEXT_PC, align 8
  %228 = load i64, ptr %RBP, align 8
  %229 = sub i64 %228, 2
  %230 = load i8, ptr %AL, align 1
  %231 = zext i8 %230 to i64
  %232 = load ptr, ptr %MEMORY, align 8
  %call.i.i318 = call ptr @__remill_write_memory_8(ptr noundef %232, i64 noundef %229, i8 noundef zeroext %230) #13
  store ptr %call.i.i318, ptr %MEMORY, align 8
  br label %233

233:                                              ; preds = %225
  %234 = load i64, ptr %NEXT_PC, align 8
  store i64 %234, ptr %PC, align 8
  %235 = add i64 %234, 4
  store i64 %235, ptr %NEXT_PC, align 8
  %236 = load i64, ptr %RBP, align 8
  %237 = sub i64 %236, 4
  %238 = load ptr, ptr %MEMORY, align 8
  %call.i.i388 = call zeroext i8 @__remill_read_memory_8(ptr noundef %238, i64 noundef %237) #13
  %conv.i.i389 = zext i8 %call.i.i388 to i64
  store i64 %conv.i.i389, ptr %RAX, align 8
  store ptr %238, ptr %MEMORY, align 8
  br label %239

239:                                              ; preds = %233
  %240 = load i64, ptr %NEXT_PC, align 8
  store i64 %240, ptr %PC, align 8
  %241 = add i64 %240, 2
  store i64 %241, ptr %NEXT_PC, align 8
  %242 = load i32, ptr %EAX, align 4
  %243 = zext i32 %242 to i64
  %244 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %243, 4294967295
  store i64 %conv.i11.i, ptr %RDX, align 8
  store ptr %244, ptr %MEMORY, align 8
  br label %245

245:                                              ; preds = %239
  %246 = load i64, ptr %NEXT_PC, align 8
  store i64 %246, ptr %PC, align 8
  %247 = add i64 %246, 4
  store i64 %247, ptr %NEXT_PC, align 8
  %248 = load i64, ptr %RBP, align 8
  %249 = sub i64 %248, 3
  %250 = load ptr, ptr %MEMORY, align 8
  %call.i.i386 = call zeroext i8 @__remill_read_memory_8(ptr noundef %250, i64 noundef %249) #13
  %conv.i.i387 = zext i8 %call.i.i386 to i64
  store i64 %conv.i.i387, ptr %RAX, align 8
  store ptr %250, ptr %MEMORY, align 8
  br label %251

251:                                              ; preds = %245
  %252 = load i64, ptr %NEXT_PC, align 8
  store i64 %252, ptr %PC, align 8
  %253 = add i64 %252, 2
  store i64 %253, ptr %NEXT_PC, align 8
  %254 = load i64, ptr %RAX, align 8
  %255 = load i32, ptr %EDX, align 4
  %256 = zext i32 %255 to i64
  %257 = load ptr, ptr %MEMORY, align 8
  %conv.i.i156 = trunc i64 %254 to i32
  %add.i.i157 = add i32 %255, %conv.i.i156
  %conv.i22.i158 = zext i32 %add.i.i157 to i64
  store i64 %conv.i22.i158, ptr %RAX, align 8
  %cmp.i.i.i159 = icmp ult i32 %add.i.i157, %conv.i.i156
  %cmp1.i.i.i160 = icmp ult i32 %add.i.i157, %255
  %258 = or i1 %cmp.i.i.i159, %cmp1.i.i.i160
  %call.i.i.i161 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %258, i32 noundef %conv.i.i156, i32 noundef %255, i32 noundef %add.i.i157) #13
  %conv.i23.i162 = zext i1 %call.i.i.i161 to i8
  %cf.i.i163 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i162, ptr %cf.i.i163, align 1
  %conv.i.i.i.i164 = trunc i32 %add.i.i157 to i8
  %259 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i164)
  %260 = and i8 %259, 1
  %conv.i.i.i165 = xor i8 %260, 1
  %pf.i.i.i166 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i165, ptr %pf.i.i.i166, align 1
  %xor.i.i.i.i167 = xor i32 %add.i.i157, %255
  %xor1.i.i.i.i168 = xor i32 %xor.i.i.i.i167, %conv.i.i156
  %261 = trunc i32 %xor1.i.i.i.i168 to i8
  %262 = lshr i8 %261, 4
  %conv2.i.i.i169 = and i8 %262, 1
  %af.i.i.i170 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i169, ptr %af.i.i.i170, align 1
  %cmp.i.i.i.i171 = icmp eq i32 %add.i.i157, 0
  %call.i.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i171, i32 noundef %conv.i.i156, i32 noundef %255, i32 noundef %add.i.i157) #13
  %conv5.i.i.i173 = zext i1 %call.i.i.i.i172 to i8
  %zf.i.i.i174 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i173, ptr %zf.i.i.i174, align 1
  %cmp.i27.i.i.i175 = icmp slt i32 %add.i.i157, 0
  %call1.i.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i175, i32 noundef %conv.i.i156, i32 noundef %255, i32 noundef %add.i.i157) #13
  %conv8.i.i.i177 = zext i1 %call1.i.i.i.i176 to i8
  %sf.i.i.i178 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i177, ptr %sf.i.i.i178, align 1
  %shr8.i.i.i.i179 = xor i32 %add.i.i157, %conv.i.i156
  %xor.i28.i.i.i180 = lshr i32 %shr8.i.i.i.i179, 31
  %xor3.i.i.i.i181 = lshr i32 %xor.i.i.i.i167, 31
  %add.i.i.i.i182 = add nuw nsw i32 %xor.i28.i.i.i180, %xor3.i.i.i.i181
  %cmp.i29.i.i.i183 = icmp eq i32 %add.i.i.i.i182, 2
  %call.i30.i.i.i184 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i183, i32 noundef %conv.i.i156, i32 noundef %255, i32 noundef %add.i.i157) #13
  %conv11.i.i.i185 = zext i1 %call.i30.i.i.i184 to i8
  %of.i.i.i186 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i185, ptr %of.i.i.i186, align 1
  store ptr %257, ptr %MEMORY, align 8
  br label %263

263:                                              ; preds = %251
  %264 = load i64, ptr %NEXT_PC, align 8
  store i64 %264, ptr %PC, align 8
  %265 = add i64 %264, 3
  store i64 %265, ptr %NEXT_PC, align 8
  %266 = load i64, ptr %RBP, align 8
  %267 = sub i64 %266, 1
  %268 = load i8, ptr %AL, align 1
  %269 = zext i8 %268 to i64
  %270 = load ptr, ptr %MEMORY, align 8
  %call.i.i317 = call ptr @__remill_write_memory_8(ptr noundef %270, i64 noundef %267, i8 noundef zeroext %268) #13
  store ptr %call.i.i317, ptr %MEMORY, align 8
  br label %271

271:                                              ; preds = %263
  %272 = load i64, ptr %NEXT_PC, align 8
  store i64 %272, ptr %PC, align 8
  %273 = add i64 %272, 4
  store i64 %273, ptr %NEXT_PC, align 8
  %274 = load i64, ptr %RBP, align 8
  %275 = sub i64 %274, 5
  %276 = load ptr, ptr %MEMORY, align 8
  %call.i.i384 = call zeroext i8 @__remill_read_memory_8(ptr noundef %276, i64 noundef %275) #13
  %conv.i.i385 = zext i8 %call.i.i384 to i64
  store i64 %conv.i.i385, ptr %RAX, align 8
  store ptr %276, ptr %MEMORY, align 8
  br label %277

277:                                              ; preds = %271
  %278 = load i64, ptr %NEXT_PC, align 8
  store i64 %278, ptr %PC, align 8
  %279 = add i64 %278, 3
  store i64 %279, ptr %NEXT_PC, align 8
  %280 = load i8, ptr %AL, align 1
  %281 = zext i8 %280 to i64
  %282 = load ptr, ptr %MEMORY, align 8
  %conv.i.i411 = trunc i64 %281 to i32
  %sext.i412 = shl i32 %conv.i.i411, 24
  %conv.i12.i413 = ashr exact i32 %sext.i412, 24
  %conv.i13.i414 = zext i32 %conv.i12.i413 to i64
  store i64 %conv.i13.i414, ptr %RAX, align 8
  store ptr %282, ptr %MEMORY, align 8
  br label %283

283:                                              ; preds = %277
  %284 = load i64, ptr %NEXT_PC, align 8
  store i64 %284, ptr %PC, align 8
  %285 = add i64 %284, 3
  store i64 %285, ptr %NEXT_PC, align 8
  %286 = load i64, ptr %RBP, align 8
  %287 = sub i64 %286, 48
  %288 = load i32, ptr %EAX, align 4
  %289 = zext i32 %288 to i64
  %290 = load ptr, ptr %MEMORY, align 8
  %call.i.i329 = call ptr @__remill_write_memory_32(ptr noundef %290, i64 noundef %287, i32 noundef %288) #13
  store ptr %call.i.i329, ptr %MEMORY, align 8
  br label %291

291:                                              ; preds = %283
  %292 = load i64, ptr %NEXT_PC, align 8
  store i64 %292, ptr %PC, align 8
  %293 = add i64 %292, 4
  store i64 %293, ptr %NEXT_PC, align 8
  %294 = load i64, ptr %RBP, align 8
  %295 = sub i64 %294, 4
  %296 = load ptr, ptr %MEMORY, align 8
  %call.i.i382 = call zeroext i8 @__remill_read_memory_8(ptr noundef %296, i64 noundef %295) #13
  %conv.i.i383 = zext i8 %call.i.i382 to i64
  store i64 %conv.i.i383, ptr %RAX, align 8
  store ptr %296, ptr %MEMORY, align 8
  br label %297

297:                                              ; preds = %291
  %298 = load i64, ptr %NEXT_PC, align 8
  store i64 %298, ptr %PC, align 8
  %299 = add i64 %298, 3
  store i64 %299, ptr %NEXT_PC, align 8
  %300 = load i8, ptr %AL, align 1
  %301 = zext i8 %300 to i64
  %302 = load ptr, ptr %MEMORY, align 8
  %conv.i.i407 = trunc i64 %301 to i32
  %sext.i408 = shl i32 %conv.i.i407, 24
  %conv.i12.i409 = ashr exact i32 %sext.i408, 24
  %conv.i13.i410 = zext i32 %conv.i12.i409 to i64
  store i64 %conv.i13.i410, ptr %RAX, align 8
  store ptr %302, ptr %MEMORY, align 8
  br label %303

303:                                              ; preds = %297
  %304 = load i64, ptr %NEXT_PC, align 8
  store i64 %304, ptr %PC, align 8
  %305 = add i64 %304, 3
  store i64 %305, ptr %NEXT_PC, align 8
  %306 = load i64, ptr %RBP, align 8
  %307 = sub i64 %306, 44
  %308 = load i32, ptr %EAX, align 4
  %309 = zext i32 %308 to i64
  %310 = load ptr, ptr %MEMORY, align 8
  %call.i.i328 = call ptr @__remill_write_memory_32(ptr noundef %310, i64 noundef %307, i32 noundef %308) #13
  store ptr %call.i.i328, ptr %MEMORY, align 8
  br label %311

311:                                              ; preds = %303
  %312 = load i64, ptr %NEXT_PC, align 8
  store i64 %312, ptr %PC, align 8
  %313 = add i64 %312, 4
  store i64 %313, ptr %NEXT_PC, align 8
  %314 = load i64, ptr %RBP, align 8
  %315 = sub i64 %314, 3
  %316 = load ptr, ptr %MEMORY, align 8
  %call.i.i380 = call zeroext i8 @__remill_read_memory_8(ptr noundef %316, i64 noundef %315) #13
  %conv.i.i381 = zext i8 %call.i.i380 to i64
  store i64 %conv.i.i381, ptr %RAX, align 8
  store ptr %316, ptr %MEMORY, align 8
  br label %317

317:                                              ; preds = %311
  %318 = load i64, ptr %NEXT_PC, align 8
  store i64 %318, ptr %PC, align 8
  %319 = add i64 %318, 3
  store i64 %319, ptr %NEXT_PC, align 8
  %320 = load i8, ptr %AL, align 1
  %321 = zext i8 %320 to i64
  %322 = load ptr, ptr %MEMORY, align 8
  %conv.i.i403 = trunc i64 %321 to i32
  %sext.i404 = shl i32 %conv.i.i403, 24
  %conv.i12.i405 = ashr exact i32 %sext.i404, 24
  %conv.i13.i406 = zext i32 %conv.i12.i405 to i64
  store i64 %conv.i13.i406, ptr %RAX, align 8
  store ptr %322, ptr %MEMORY, align 8
  br label %323

323:                                              ; preds = %317
  %324 = load i64, ptr %NEXT_PC, align 8
  store i64 %324, ptr %PC, align 8
  %325 = add i64 %324, 3
  store i64 %325, ptr %NEXT_PC, align 8
  %326 = load i64, ptr %RBP, align 8
  %327 = sub i64 %326, 40
  %328 = load i32, ptr %EAX, align 4
  %329 = zext i32 %328 to i64
  %330 = load ptr, ptr %MEMORY, align 8
  %call.i.i327 = call ptr @__remill_write_memory_32(ptr noundef %330, i64 noundef %327, i32 noundef %328) #13
  store ptr %call.i.i327, ptr %MEMORY, align 8
  br label %331

331:                                              ; preds = %323
  %332 = load i64, ptr %NEXT_PC, align 8
  store i64 %332, ptr %PC, align 8
  %333 = add i64 %332, 4
  store i64 %333, ptr %NEXT_PC, align 8
  %334 = load i64, ptr %RBP, align 8
  %335 = sub i64 %334, 2
  %336 = load ptr, ptr %MEMORY, align 8
  %call.i.i378 = call zeroext i8 @__remill_read_memory_8(ptr noundef %336, i64 noundef %335) #13
  %conv.i.i379 = zext i8 %call.i.i378 to i64
  store i64 %conv.i.i379, ptr %RAX, align 8
  store ptr %336, ptr %MEMORY, align 8
  br label %337

337:                                              ; preds = %331
  %338 = load i64, ptr %NEXT_PC, align 8
  store i64 %338, ptr %PC, align 8
  %339 = add i64 %338, 3
  store i64 %339, ptr %NEXT_PC, align 8
  %340 = load i8, ptr %AL, align 1
  %341 = zext i8 %340 to i64
  %342 = load ptr, ptr %MEMORY, align 8
  %conv.i.i399 = trunc i64 %341 to i32
  %sext.i400 = shl i32 %conv.i.i399, 24
  %conv.i12.i401 = ashr exact i32 %sext.i400, 24
  %conv.i13.i402 = zext i32 %conv.i12.i401 to i64
  store i64 %conv.i13.i402, ptr %RAX, align 8
  store ptr %342, ptr %MEMORY, align 8
  br label %343

343:                                              ; preds = %337
  %344 = load i64, ptr %NEXT_PC, align 8
  store i64 %344, ptr %PC, align 8
  %345 = add i64 %344, 3
  store i64 %345, ptr %NEXT_PC, align 8
  %346 = load i64, ptr %RBP, align 8
  %347 = sub i64 %346, 36
  %348 = load i32, ptr %EAX, align 4
  %349 = zext i32 %348 to i64
  %350 = load ptr, ptr %MEMORY, align 8
  %call.i.i326 = call ptr @__remill_write_memory_32(ptr noundef %350, i64 noundef %347, i32 noundef %348) #13
  store ptr %call.i.i326, ptr %MEMORY, align 8
  br label %351

351:                                              ; preds = %343
  %352 = load i64, ptr %NEXT_PC, align 8
  store i64 %352, ptr %PC, align 8
  %353 = add i64 %352, 4
  store i64 %353, ptr %NEXT_PC, align 8
  %354 = load i64, ptr %RBP, align 8
  %355 = sub i64 %354, 1
  %356 = load ptr, ptr %MEMORY, align 8
  %call.i.i376 = call zeroext i8 @__remill_read_memory_8(ptr noundef %356, i64 noundef %355) #13
  %conv.i.i377 = zext i8 %call.i.i376 to i64
  store i64 %conv.i.i377, ptr %RAX, align 8
  store ptr %356, ptr %MEMORY, align 8
  br label %357

357:                                              ; preds = %351
  %358 = load i64, ptr %NEXT_PC, align 8
  store i64 %358, ptr %PC, align 8
  %359 = add i64 %358, 3
  store i64 %359, ptr %NEXT_PC, align 8
  %360 = load i8, ptr %AL, align 1
  %361 = zext i8 %360 to i64
  %362 = load ptr, ptr %MEMORY, align 8
  %conv.i.i395 = trunc i64 %361 to i32
  %sext.i396 = shl i32 %conv.i.i395, 24
  %conv.i12.i397 = ashr exact i32 %sext.i396, 24
  %conv.i13.i398 = zext i32 %conv.i12.i397 to i64
  store i64 %conv.i13.i398, ptr %RAX, align 8
  store ptr %362, ptr %MEMORY, align 8
  br label %363

363:                                              ; preds = %357
  %364 = load i64, ptr %NEXT_PC, align 8
  store i64 %364, ptr %PC, align 8
  %365 = add i64 %364, 3
  store i64 %365, ptr %NEXT_PC, align 8
  %366 = load i64, ptr %RBP, align 8
  %367 = sub i64 %366, 32
  %368 = load i32, ptr %EAX, align 4
  %369 = zext i32 %368 to i64
  %370 = load ptr, ptr %MEMORY, align 8
  %call.i.i325 = call ptr @__remill_write_memory_32(ptr noundef %370, i64 noundef %367, i32 noundef %368) #13
  store ptr %call.i.i325, ptr %MEMORY, align 8
  br label %371

371:                                              ; preds = %363
  %372 = load i64, ptr %NEXT_PC, align 8
  store i64 %372, ptr %PC, align 8
  %373 = add i64 %372, 3
  store i64 %373, ptr %NEXT_PC, align 8
  %374 = load i64, ptr %RBP, align 8
  %375 = sub i64 %374, 48
  %376 = load ptr, ptr %MEMORY, align 8
  %call.i.i357 = call i32 @__remill_read_memory_32(ptr noundef %376, i64 noundef %375) #13
  %conv.i.i358 = zext i32 %call.i.i357 to i64
  store i64 %conv.i.i358, ptr %RDX, align 8
  store ptr %376, ptr %MEMORY, align 8
  br label %377

377:                                              ; preds = %371
  %378 = load i64, ptr %NEXT_PC, align 8
  store i64 %378, ptr %PC, align 8
  %379 = add i64 %378, 3
  store i64 %379, ptr %NEXT_PC, align 8
  %380 = load i64, ptr %RBP, align 8
  %381 = sub i64 %380, 44
  %382 = load ptr, ptr %MEMORY, align 8
  %call.i.i355 = call i32 @__remill_read_memory_32(ptr noundef %382, i64 noundef %381) #13
  %conv.i.i356 = zext i32 %call.i.i355 to i64
  store i64 %conv.i.i356, ptr %RAX, align 8
  store ptr %382, ptr %MEMORY, align 8
  br label %383

383:                                              ; preds = %377
  %384 = load i64, ptr %NEXT_PC, align 8
  store i64 %384, ptr %PC, align 8
  %385 = add i64 %384, 2
  store i64 %385, ptr %NEXT_PC, align 8
  %386 = load i64, ptr %RAX, align 8
  %387 = load i32, ptr %EDX, align 4
  %388 = zext i32 %387 to i64
  %389 = load ptr, ptr %MEMORY, align 8
  %conv.i.i125 = trunc i64 %386 to i32
  %add.i.i126 = add i32 %387, %conv.i.i125
  %conv.i22.i127 = zext i32 %add.i.i126 to i64
  store i64 %conv.i22.i127, ptr %RAX, align 8
  %cmp.i.i.i128 = icmp ult i32 %add.i.i126, %conv.i.i125
  %cmp1.i.i.i129 = icmp ult i32 %add.i.i126, %387
  %390 = or i1 %cmp.i.i.i128, %cmp1.i.i.i129
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %390, i32 noundef %conv.i.i125, i32 noundef %387, i32 noundef %add.i.i126) #13
  %conv.i23.i131 = zext i1 %call.i.i.i130 to i8
  %cf.i.i132 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i131, ptr %cf.i.i132, align 1
  %conv.i.i.i.i133 = trunc i32 %add.i.i126 to i8
  %391 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i133)
  %392 = and i8 %391, 1
  %conv.i.i.i134 = xor i8 %392, 1
  %pf.i.i.i135 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i134, ptr %pf.i.i.i135, align 1
  %xor.i.i.i.i136 = xor i32 %add.i.i126, %387
  %xor1.i.i.i.i137 = xor i32 %xor.i.i.i.i136, %conv.i.i125
  %393 = trunc i32 %xor1.i.i.i.i137 to i8
  %394 = lshr i8 %393, 4
  %conv2.i.i.i138 = and i8 %394, 1
  %af.i.i.i139 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i138, ptr %af.i.i.i139, align 1
  %cmp.i.i.i.i140 = icmp eq i32 %add.i.i126, 0
  %call.i.i.i.i141 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i140, i32 noundef %conv.i.i125, i32 noundef %387, i32 noundef %add.i.i126) #13
  %conv5.i.i.i142 = zext i1 %call.i.i.i.i141 to i8
  %zf.i.i.i143 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i142, ptr %zf.i.i.i143, align 1
  %cmp.i27.i.i.i144 = icmp slt i32 %add.i.i126, 0
  %call1.i.i.i.i145 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i144, i32 noundef %conv.i.i125, i32 noundef %387, i32 noundef %add.i.i126) #13
  %conv8.i.i.i146 = zext i1 %call1.i.i.i.i145 to i8
  %sf.i.i.i147 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i146, ptr %sf.i.i.i147, align 1
  %shr8.i.i.i.i148 = xor i32 %add.i.i126, %conv.i.i125
  %xor.i28.i.i.i149 = lshr i32 %shr8.i.i.i.i148, 31
  %xor3.i.i.i.i150 = lshr i32 %xor.i.i.i.i136, 31
  %add.i.i.i.i151 = add nuw nsw i32 %xor.i28.i.i.i149, %xor3.i.i.i.i150
  %cmp.i29.i.i.i152 = icmp eq i32 %add.i.i.i.i151, 2
  %call.i30.i.i.i153 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i152, i32 noundef %conv.i.i125, i32 noundef %387, i32 noundef %add.i.i126) #13
  %conv11.i.i.i154 = zext i1 %call.i30.i.i.i153 to i8
  %of.i.i.i155 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i154, ptr %of.i.i.i155, align 1
  store ptr %389, ptr %MEMORY, align 8
  br label %395

395:                                              ; preds = %383
  %396 = load i64, ptr %NEXT_PC, align 8
  store i64 %396, ptr %PC, align 8
  %397 = add i64 %396, 3
  store i64 %397, ptr %NEXT_PC, align 8
  %398 = load i64, ptr %RBP, align 8
  %399 = sub i64 %398, 28
  %400 = load i32, ptr %EAX, align 4
  %401 = zext i32 %400 to i64
  %402 = load ptr, ptr %MEMORY, align 8
  %call.i.i324 = call ptr @__remill_write_memory_32(ptr noundef %402, i64 noundef %399, i32 noundef %400) #13
  store ptr %call.i.i324, ptr %MEMORY, align 8
  br label %403

403:                                              ; preds = %395
  %404 = load i64, ptr %NEXT_PC, align 8
  store i64 %404, ptr %PC, align 8
  %405 = add i64 %404, 3
  store i64 %405, ptr %NEXT_PC, align 8
  %406 = load i64, ptr %RBP, align 8
  %407 = sub i64 %406, 40
  %408 = load ptr, ptr %MEMORY, align 8
  %call.i.i353 = call i32 @__remill_read_memory_32(ptr noundef %408, i64 noundef %407) #13
  %conv.i.i354 = zext i32 %call.i.i353 to i64
  store i64 %conv.i.i354, ptr %RDX, align 8
  store ptr %408, ptr %MEMORY, align 8
  br label %409

409:                                              ; preds = %403
  %410 = load i64, ptr %NEXT_PC, align 8
  store i64 %410, ptr %PC, align 8
  %411 = add i64 %410, 3
  store i64 %411, ptr %NEXT_PC, align 8
  %412 = load i64, ptr %RBP, align 8
  %413 = sub i64 %412, 36
  %414 = load ptr, ptr %MEMORY, align 8
  %call.i.i351 = call i32 @__remill_read_memory_32(ptr noundef %414, i64 noundef %413) #13
  %conv.i.i352 = zext i32 %call.i.i351 to i64
  store i64 %conv.i.i352, ptr %RAX, align 8
  store ptr %414, ptr %MEMORY, align 8
  br label %415

415:                                              ; preds = %409
  %416 = load i64, ptr %NEXT_PC, align 8
  store i64 %416, ptr %PC, align 8
  %417 = add i64 %416, 2
  store i64 %417, ptr %NEXT_PC, align 8
  %418 = load i64, ptr %RAX, align 8
  %419 = load i32, ptr %EDX, align 4
  %420 = zext i32 %419 to i64
  %421 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %418 to i32
  %add.i.i95 = add i32 %419, %conv.i.i94
  %conv.i22.i96 = zext i32 %add.i.i95 to i64
  store i64 %conv.i22.i96, ptr %RAX, align 8
  %cmp.i.i.i97 = icmp ult i32 %add.i.i95, %conv.i.i94
  %cmp1.i.i.i98 = icmp ult i32 %add.i.i95, %419
  %422 = or i1 %cmp.i.i.i97, %cmp1.i.i.i98
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %422, i32 noundef %conv.i.i94, i32 noundef %419, i32 noundef %add.i.i95) #13
  %conv.i23.i100 = zext i1 %call.i.i.i99 to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i100, ptr %cf.i.i101, align 1
  %conv.i.i.i.i102 = trunc i32 %add.i.i95 to i8
  %423 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i102)
  %424 = and i8 %423, 1
  %conv.i.i.i103 = xor i8 %424, 1
  %pf.i.i.i104 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i103, ptr %pf.i.i.i104, align 1
  %xor.i.i.i.i105 = xor i32 %add.i.i95, %419
  %xor1.i.i.i.i106 = xor i32 %xor.i.i.i.i105, %conv.i.i94
  %425 = trunc i32 %xor1.i.i.i.i106 to i8
  %426 = lshr i8 %425, 4
  %conv2.i.i.i107 = and i8 %426, 1
  %af.i.i.i108 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i107, ptr %af.i.i.i108, align 1
  %cmp.i.i.i.i109 = icmp eq i32 %add.i.i95, 0
  %call.i.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i109, i32 noundef %conv.i.i94, i32 noundef %419, i32 noundef %add.i.i95) #13
  %conv5.i.i.i111 = zext i1 %call.i.i.i.i110 to i8
  %zf.i.i.i112 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i111, ptr %zf.i.i.i112, align 1
  %cmp.i27.i.i.i113 = icmp slt i32 %add.i.i95, 0
  %call1.i.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i113, i32 noundef %conv.i.i94, i32 noundef %419, i32 noundef %add.i.i95) #13
  %conv8.i.i.i115 = zext i1 %call1.i.i.i.i114 to i8
  %sf.i.i.i116 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i115, ptr %sf.i.i.i116, align 1
  %shr8.i.i.i.i117 = xor i32 %add.i.i95, %conv.i.i94
  %xor.i28.i.i.i118 = lshr i32 %shr8.i.i.i.i117, 31
  %xor3.i.i.i.i119 = lshr i32 %xor.i.i.i.i105, 31
  %add.i.i.i.i120 = add nuw nsw i32 %xor.i28.i.i.i118, %xor3.i.i.i.i119
  %cmp.i29.i.i.i121 = icmp eq i32 %add.i.i.i.i120, 2
  %call.i30.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i121, i32 noundef %conv.i.i94, i32 noundef %419, i32 noundef %add.i.i95) #13
  %conv11.i.i.i123 = zext i1 %call.i30.i.i.i122 to i8
  %of.i.i.i124 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i123, ptr %of.i.i.i124, align 1
  store ptr %421, ptr %MEMORY, align 8
  br label %427

427:                                              ; preds = %415
  %428 = load i64, ptr %NEXT_PC, align 8
  store i64 %428, ptr %PC, align 8
  %429 = add i64 %428, 3
  store i64 %429, ptr %NEXT_PC, align 8
  %430 = load i64, ptr %RBP, align 8
  %431 = sub i64 %430, 24
  %432 = load i32, ptr %EAX, align 4
  %433 = zext i32 %432 to i64
  %434 = load ptr, ptr %MEMORY, align 8
  %call.i.i323 = call ptr @__remill_write_memory_32(ptr noundef %434, i64 noundef %431, i32 noundef %432) #13
  store ptr %call.i.i323, ptr %MEMORY, align 8
  br label %435

435:                                              ; preds = %427
  %436 = load i64, ptr %NEXT_PC, align 8
  store i64 %436, ptr %PC, align 8
  %437 = add i64 %436, 3
  store i64 %437, ptr %NEXT_PC, align 8
  %438 = load i64, ptr %RBP, align 8
  %439 = sub i64 %438, 32
  %440 = load ptr, ptr %MEMORY, align 8
  %call.i.i349 = call i32 @__remill_read_memory_32(ptr noundef %440, i64 noundef %439) #13
  %conv.i.i350 = zext i32 %call.i.i349 to i64
  store i64 %conv.i.i350, ptr %RDX, align 8
  store ptr %440, ptr %MEMORY, align 8
  br label %441

441:                                              ; preds = %435
  %442 = load i64, ptr %NEXT_PC, align 8
  store i64 %442, ptr %PC, align 8
  %443 = add i64 %442, 3
  store i64 %443, ptr %NEXT_PC, align 8
  %444 = load i64, ptr %RBP, align 8
  %445 = sub i64 %444, 28
  %446 = load ptr, ptr %MEMORY, align 8
  %call.i.i347 = call i32 @__remill_read_memory_32(ptr noundef %446, i64 noundef %445) #13
  %conv.i.i348 = zext i32 %call.i.i347 to i64
  store i64 %conv.i.i348, ptr %RAX, align 8
  store ptr %446, ptr %MEMORY, align 8
  br label %447

447:                                              ; preds = %441
  %448 = load i64, ptr %NEXT_PC, align 8
  store i64 %448, ptr %PC, align 8
  %449 = add i64 %448, 2
  store i64 %449, ptr %NEXT_PC, align 8
  %450 = load i64, ptr %RDX, align 8
  %451 = load i32, ptr %EAX, align 4
  %452 = zext i32 %451 to i64
  %453 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %450 to i32
  %add.i.i64 = add i32 %451, %conv.i.i63
  %conv.i22.i65 = zext i32 %add.i.i64 to i64
  store i64 %conv.i22.i65, ptr %RDX, align 8
  %cmp.i.i.i66 = icmp ult i32 %add.i.i64, %conv.i.i63
  %cmp1.i.i.i67 = icmp ult i32 %add.i.i64, %451
  %454 = or i1 %cmp.i.i.i66, %cmp1.i.i.i67
  %call.i.i.i68 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %454, i32 noundef %conv.i.i63, i32 noundef %451, i32 noundef %add.i.i64) #13
  %conv.i23.i69 = zext i1 %call.i.i.i68 to i8
  %cf.i.i70 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i69, ptr %cf.i.i70, align 1
  %conv.i.i.i.i71 = trunc i32 %add.i.i64 to i8
  %455 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i71)
  %456 = and i8 %455, 1
  %conv.i.i.i72 = xor i8 %456, 1
  %pf.i.i.i73 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i72, ptr %pf.i.i.i73, align 1
  %xor.i.i.i.i74 = xor i32 %add.i.i64, %451
  %xor1.i.i.i.i75 = xor i32 %xor.i.i.i.i74, %conv.i.i63
  %457 = trunc i32 %xor1.i.i.i.i75 to i8
  %458 = lshr i8 %457, 4
  %conv2.i.i.i76 = and i8 %458, 1
  %af.i.i.i77 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i76, ptr %af.i.i.i77, align 1
  %cmp.i.i.i.i78 = icmp eq i32 %add.i.i64, 0
  %call.i.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i78, i32 noundef %conv.i.i63, i32 noundef %451, i32 noundef %add.i.i64) #13
  %conv5.i.i.i80 = zext i1 %call.i.i.i.i79 to i8
  %zf.i.i.i81 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i80, ptr %zf.i.i.i81, align 1
  %cmp.i27.i.i.i82 = icmp slt i32 %add.i.i64, 0
  %call1.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i82, i32 noundef %conv.i.i63, i32 noundef %451, i32 noundef %add.i.i64) #13
  %conv8.i.i.i84 = zext i1 %call1.i.i.i.i83 to i8
  %sf.i.i.i85 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i84, ptr %sf.i.i.i85, align 1
  %shr8.i.i.i.i86 = xor i32 %add.i.i64, %conv.i.i63
  %xor.i28.i.i.i87 = lshr i32 %shr8.i.i.i.i86, 31
  %xor3.i.i.i.i88 = lshr i32 %xor.i.i.i.i74, 31
  %add.i.i.i.i89 = add nuw nsw i32 %xor.i28.i.i.i87, %xor3.i.i.i.i88
  %cmp.i29.i.i.i90 = icmp eq i32 %add.i.i.i.i89, 2
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i90, i32 noundef %conv.i.i63, i32 noundef %451, i32 noundef %add.i.i64) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %453, ptr %MEMORY, align 8
  br label %459

459:                                              ; preds = %447
  %460 = load i64, ptr %NEXT_PC, align 8
  store i64 %460, ptr %PC, align 8
  %461 = add i64 %460, 3
  store i64 %461, ptr %NEXT_PC, align 8
  %462 = load i64, ptr %RBP, align 8
  %463 = sub i64 %462, 24
  %464 = load ptr, ptr %MEMORY, align 8
  %call.i.i345 = call i32 @__remill_read_memory_32(ptr noundef %464, i64 noundef %463) #13
  %conv.i.i346 = zext i32 %call.i.i345 to i64
  store i64 %conv.i.i346, ptr %RAX, align 8
  store ptr %464, ptr %MEMORY, align 8
  br label %465

465:                                              ; preds = %459
  %466 = load i64, ptr %NEXT_PC, align 8
  store i64 %466, ptr %PC, align 8
  %467 = add i64 %466, 2
  store i64 %467, ptr %NEXT_PC, align 8
  %468 = load i64, ptr %RAX, align 8
  %469 = load i32, ptr %EDX, align 4
  %470 = zext i32 %469 to i64
  %471 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %468 to i32
  %add.i.i33 = add i32 %469, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RAX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, %469
  %472 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %472, i32 noundef %conv.i.i32, i32 noundef %469, i32 noundef %add.i.i33) #13
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %473 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %474 = and i8 %473, 1
  %conv.i.i.i41 = xor i8 %474, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, %469
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %475 = trunc i32 %xor1.i.i.i.i44 to i8
  %476 = lshr i8 %475, 4
  %conv2.i.i.i45 = and i8 %476, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %469, i32 noundef %add.i.i33) #13
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef %469, i32 noundef %add.i.i33) #13
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef %469, i32 noundef %add.i.i33) #13
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %471, ptr %MEMORY, align 8
  br label %477

477:                                              ; preds = %465
  %478 = load i64, ptr %NEXT_PC, align 8
  store i64 %478, ptr %PC, align 8
  %479 = add i64 %478, 3
  store i64 %479, ptr %NEXT_PC, align 8
  %480 = load i64, ptr %RBP, align 8
  %481 = sub i64 %480, 20
  %482 = load i32, ptr %EAX, align 4
  %483 = zext i32 %482 to i64
  %484 = load ptr, ptr %MEMORY, align 8
  %call.i.i322 = call ptr @__remill_write_memory_32(ptr noundef %484, i64 noundef %481, i32 noundef %482) #13
  store ptr %call.i.i322, ptr %MEMORY, align 8
  br label %485

485:                                              ; preds = %477
  %486 = load i64, ptr %NEXT_PC, align 8
  store i64 %486, ptr %PC, align 8
  %487 = add i64 %486, 3
  store i64 %487, ptr %NEXT_PC, align 8
  %488 = load i64, ptr %RBP, align 8
  %489 = sub i64 %488, 52
  %490 = load ptr, ptr %MEMORY, align 8
  %call.i.i343 = call i32 @__remill_read_memory_32(ptr noundef %490, i64 noundef %489) #13
  %conv.i.i344 = zext i32 %call.i.i343 to i64
  store i64 %conv.i.i344, ptr %RAX, align 8
  store ptr %490, ptr %MEMORY, align 8
  br label %491

491:                                              ; preds = %485
  %492 = load i64, ptr %NEXT_PC, align 8
  store i64 %492, ptr %PC, align 8
  %493 = add i64 %492, 2
  store i64 %493, ptr %NEXT_PC, align 8
  %494 = load ptr, ptr %MEMORY, align 8
  %rax.i309 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %495 = load i32, ptr %rax.i309, align 8
  %conv.i.i310 = sext i32 %495 to i64
  store i64 %conv.i.i310, ptr %rax.i309, align 8
  store ptr %494, ptr %MEMORY, align 8
  br label %496

496:                                              ; preds = %491
  %497 = load i64, ptr %NEXT_PC, align 8
  store i64 %497, ptr %PC, align 8
  %498 = add i64 %497, 5
  store i64 %498, ptr %NEXT_PC, align 8
  %499 = load i64, ptr %RBP, align 8
  %500 = load i64, ptr %RAX, align 8
  %501 = mul i64 %500, 1
  %502 = add i64 %499, %501
  %503 = sub i64 %502, 5
  %504 = load ptr, ptr %MEMORY, align 8
  %call.i.i374 = call zeroext i8 @__remill_read_memory_8(ptr noundef %504, i64 noundef %503) #13
  %conv.i.i375 = zext i8 %call.i.i374 to i64
  store i64 %conv.i.i375, ptr %RAX, align 8
  store ptr %504, ptr %MEMORY, align 8
  br label %505

505:                                              ; preds = %496
  %506 = load i64, ptr %NEXT_PC, align 8
  store i64 %506, ptr %PC, align 8
  %507 = add i64 %506, 3
  store i64 %507, ptr %NEXT_PC, align 8
  %508 = load i8, ptr %AL, align 1
  %509 = zext i8 %508 to i64
  %510 = load ptr, ptr %MEMORY, align 8
  %conv.i.i394 = trunc i64 %509 to i32
  %sext.i = shl i32 %conv.i.i394, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RDX, align 8
  store ptr %510, ptr %MEMORY, align 8
  br label %511

511:                                              ; preds = %505
  %512 = load i64, ptr %NEXT_PC, align 8
  store i64 %512, ptr %PC, align 8
  %513 = add i64 %512, 3
  store i64 %513, ptr %NEXT_PC, align 8
  %514 = load i64, ptr %RBP, align 8
  %515 = sub i64 %514, 56
  %516 = load ptr, ptr %MEMORY, align 8
  %call.i.i341 = call i32 @__remill_read_memory_32(ptr noundef %516, i64 noundef %515) #13
  %conv.i.i342 = zext i32 %call.i.i341 to i64
  store i64 %conv.i.i342, ptr %RAX, align 8
  store ptr %516, ptr %MEMORY, align 8
  br label %517

517:                                              ; preds = %511
  %518 = load i64, ptr %NEXT_PC, align 8
  store i64 %518, ptr %PC, align 8
  %519 = add i64 %518, 2
  store i64 %519, ptr %NEXT_PC, align 8
  %520 = load ptr, ptr %MEMORY, align 8
  %rax.i307 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %521 = load i32, ptr %rax.i307, align 8
  %conv.i.i308 = sext i32 %521 to i64
  store i64 %conv.i.i308, ptr %rax.i307, align 8
  store ptr %520, ptr %MEMORY, align 8
  br label %522

522:                                              ; preds = %517
  %523 = load i64, ptr %NEXT_PC, align 8
  store i64 %523, ptr %PC, align 8
  %524 = add i64 %523, 4
  store i64 %524, ptr %NEXT_PC, align 8
  %525 = load i64, ptr %RBP, align 8
  %526 = load i64, ptr %RAX, align 8
  %527 = mul i64 %526, 4
  %528 = add i64 %525, %527
  %529 = sub i64 %528, 48
  %530 = load ptr, ptr %MEMORY, align 8
  %call.i.i339 = call i32 @__remill_read_memory_32(ptr noundef %530, i64 noundef %529) #13
  %conv.i.i340 = zext i32 %call.i.i339 to i64
  store i64 %conv.i.i340, ptr %RAX, align 8
  store ptr %530, ptr %MEMORY, align 8
  br label %531

531:                                              ; preds = %522
  %532 = load i64, ptr %NEXT_PC, align 8
  store i64 %532, ptr %PC, align 8
  %533 = add i64 %532, 2
  store i64 %533, ptr %NEXT_PC, align 8
  %534 = load i64, ptr %RDX, align 8
  %535 = load i32, ptr %EAX, align 4
  %536 = zext i32 %535 to i64
  %537 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %534 to i32
  %add.i.i2 = add i32 %535, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RDX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %535
  %538 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %538, i32 noundef %conv.i.i1, i32 noundef %535, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %539 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %540 = and i8 %539, 1
  %conv.i.i.i10 = xor i8 %540, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %535
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %541 = trunc i32 %xor1.i.i.i.i13 to i8
  %542 = lshr i8 %541, 4
  %conv2.i.i.i14 = and i8 %542, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef %535, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef %535, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef %535, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %537, ptr %MEMORY, align 8
  br label %543

543:                                              ; preds = %531
  %544 = load i64, ptr %NEXT_PC, align 8
  store i64 %544, ptr %PC, align 8
  %545 = add i64 %544, 3
  store i64 %545, ptr %NEXT_PC, align 8
  %546 = load i64, ptr %RBP, align 8
  %547 = sub i64 %546, 60
  %548 = load ptr, ptr %MEMORY, align 8
  %call.i.i337 = call i32 @__remill_read_memory_32(ptr noundef %548, i64 noundef %547) #13
  %conv.i.i338 = zext i32 %call.i.i337 to i64
  store i64 %conv.i.i338, ptr %RAX, align 8
  store ptr %548, ptr %MEMORY, align 8
  br label %549

549:                                              ; preds = %543
  %550 = load i64, ptr %NEXT_PC, align 8
  store i64 %550, ptr %PC, align 8
  %551 = add i64 %550, 2
  store i64 %551, ptr %NEXT_PC, align 8
  %552 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %553 = load i32, ptr %rax.i, align 8
  %conv.i.i306 = sext i32 %553 to i64
  store i64 %conv.i.i306, ptr %rax.i, align 8
  store ptr %552, ptr %MEMORY, align 8
  br label %554

554:                                              ; preds = %549
  %555 = load i64, ptr %NEXT_PC, align 8
  store i64 %555, ptr %PC, align 8
  %556 = add i64 %555, 4
  store i64 %556, ptr %NEXT_PC, align 8
  %557 = load i64, ptr %RBP, align 8
  %558 = load i64, ptr %RAX, align 8
  %559 = mul i64 %558, 4
  %560 = add i64 %557, %559
  %561 = sub i64 %560, 48
  %562 = load ptr, ptr %MEMORY, align 8
  %call.i.i335 = call i32 @__remill_read_memory_32(ptr noundef %562, i64 noundef %561) #13
  %conv.i.i336 = zext i32 %call.i.i335 to i64
  store i64 %conv.i.i336, ptr %RAX, align 8
  store ptr %562, ptr %MEMORY, align 8
  br label %563

563:                                              ; preds = %554
  %564 = load i64, ptr %NEXT_PC, align 8
  store i64 %564, ptr %PC, align 8
  %565 = add i64 %564, 2
  store i64 %565, ptr %NEXT_PC, align 8
  %566 = load i64, ptr %RAX, align 8
  %567 = load i32, ptr %EDX, align 4
  %568 = zext i32 %567 to i64
  %569 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %566 to i32
  %add.i.i = add i32 %567, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %567
  %570 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %570, i32 noundef %conv.i.i, i32 noundef %567, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %571 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %572 = and i8 %571, 1
  %conv.i.i.i = xor i8 %572, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %567
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %573 = trunc i32 %xor1.i.i.i.i to i8
  %574 = lshr i8 %573, 4
  %conv2.i.i.i = and i8 %574, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %567, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %567, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %567, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %569, ptr %MEMORY, align 8
  br label %575

575:                                              ; preds = %563
  %576 = load i64, ptr %NEXT_PC, align 8
  store i64 %576, ptr %PC, align 8
  %577 = add i64 %576, 1
  store i64 %577, ptr %NEXT_PC, align 8
  %578 = load ptr, ptr %MEMORY, align 8
  %rsp.i415 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 13
  %579 = load i64, ptr %rsp.i415, align 8
  %add.i.i416 = add i64 %579, 8
  store i64 %add.i.i416, ptr %rsp.i415, align 8
  %call.i.i417 = call i64 @__remill_read_memory_64(ptr noundef %578, i64 noundef %579) #13
  store i64 %call.i.i417, ptr %RBP, align 8
  store ptr %578, ptr %MEMORY, align 8
  br label %580

580:                                              ; preds = %575
  %581 = load i64, ptr %NEXT_PC, align 8
  store i64 %581, ptr %PC, align 8
  %582 = add i64 %581, 1
  store i64 %582, ptr %NEXT_PC, align 8
  %583 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 13
  %584 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %583, i64 noundef %584) #13
  %rip.i = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %585 = load i64, ptr %rsp.i, align 8
  %add.i.i305 = add i64 %585, 8
  store i64 %add.i.i305, ptr %rsp.i, align 8
  store ptr %583, ptr %MEMORY, align 8
  %586 = load ptr, ptr %MEMORY, align 8
  ret ptr %586
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.951, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.951) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #14
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.951) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4345, label %bb_10F9
  ]

dead_end:                                         ; preds = %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_10F9:                                          ; preds = %entry
  %block_pc = add i64 4345, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4345, ptr %1)
  %4 = call ptr @BB_10f9(ptr %state, i64 %2, ptr %1) #15
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  %6 = load ptr, ptr %mem_var, align 8
  ret ptr %6

return_bb:                                        ; No predecessors!
  %7 = load ptr, ptr %mem_var, align 8
  ret ptr %7
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4345, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() local_unnamed_addr #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.950, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #15 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
