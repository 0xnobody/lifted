; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.20708 = type { %struct.X86State.20707 }
%struct.X86State.20707 = type { %struct.ArchState.20676, [32 x %union.VectorReg.20679], %struct.ArithFlags.20680, %union.anon.20675, %struct.Segments.20682, %struct.AddressSpace.20684, %struct.GPR.20685, %struct.X87Stack.20688, %struct.MMX.20692, %struct.FPUStatusFlags.20693, %union.anon.20675, %union.FPU.20702, %struct.SegmentCaches.20704, %struct.K_REG.20706 }
%struct.ArchState.20676 = type { i32, i32, %union.anon.20675 }
%union.VectorReg.20679 = type { %union.vec512_t.20678 }
%union.vec512_t.20678 = type { %struct.uint64v8_t.20677 }
%struct.uint64v8_t.20677 = type { [8 x i64] }
%struct.ArithFlags.20680 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.20682 = type { i16, %union.SegmentSelector.20681, i16, %union.SegmentSelector.20681, i16, %union.SegmentSelector.20681, i16, %union.SegmentSelector.20681, i16, %union.SegmentSelector.20681, i16, %union.SegmentSelector.20681 }
%union.SegmentSelector.20681 = type { i16 }
%struct.AddressSpace.20684 = type { i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683 }
%struct.Reg.20683 = type { %union.anon.20675 }
%struct.GPR.20685 = type { i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683, i64, %struct.Reg.20683 }
%struct.X87Stack.20688 = type { [8 x %struct.anon.3.20687] }
%struct.anon.3.20687 = type { [6 x i8], %struct.float80_t.20686 }
%struct.float80_t.20686 = type { [10 x i8] }
%struct.MMX.20692 = type { [8 x %struct.anon.4.20691] }
%struct.anon.4.20691 = type { i64, %union.vec64_t.20690 }
%union.vec64_t.20690 = type { %struct.uint64v1_t.20689 }
%struct.uint64v1_t.20689 = type { [1 x i64] }
%struct.FPUStatusFlags.20693 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.20675 = type { i64 }
%union.FPU.20702 = type { %struct.anon.13.20701 }
%struct.anon.13.20701 = type { %struct.FpuFXSAVE.20700, [96 x i8] }
%struct.FpuFXSAVE.20700 = type { %union.SegmentSelector.20681, %union.SegmentSelector.20681, %union.FPUAbridgedTagWord.20694, i8, i16, i32, %union.SegmentSelector.20681, i16, i32, %union.SegmentSelector.20681, i16, %union.FPUControlStatus.20695, %union.FPUControlStatus.20695, [8 x %struct.FPUStackElem.20697], [16 x %union.vec128_t.20699] }
%union.FPUAbridgedTagWord.20694 = type { i8 }
%union.FPUControlStatus.20695 = type { i32 }
%struct.FPUStackElem.20697 = type { %union.anon.11.20696, [6 x i8] }
%union.anon.11.20696 = type { %struct.float80_t.20686 }
%union.vec128_t.20699 = type { %struct.uint128v1_t.20698 }
%struct.uint128v1_t.20698 = type { [1 x i128] }
%struct.SegmentCaches.20704 = type { %struct.SegmentShadow.20703, %struct.SegmentShadow.20703, %struct.SegmentShadow.20703, %struct.SegmentShadow.20703, %struct.SegmentShadow.20703, %struct.SegmentShadow.20703 }
%struct.SegmentShadow.20703 = type { %union.anon.20675, i32, i32 }
%struct.K_REG.20706 = type { [8 x %struct.anon.18.20705] }
%struct.anon.18.20705 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_11be(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 24
  %25 = load i64, ptr %RDI, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call ptr @__remill_write_memory_64(ptr noundef %26, i64 noundef %24, i64 noundef %25) #13
  store ptr %call.i.i3, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %20
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 4
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RBP, align 8
  %31 = sub i64 %30, 32
  %32 = load i64, ptr %RSI, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_64(ptr noundef %33, i64 noundef %31, i64 noundef %32) #13
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %27
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 7
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RBP, align 8
  %38 = sub i64 %37, 4
  %39 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %39, i64 noundef %38, i32 noundef 0) #13
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %34
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 7
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %RBP, align 8
  %44 = sub i64 %43, 8
  %45 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %45, i64 noundef %44, i32 noundef 0) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %40
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 2
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %NEXT_PC, align 8
  %50 = add i64 %49, 49
  %51 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  store i64 %50, ptr %rip.i, align 8
  store i64 %50, ptr %NEXT_PC, align 8
  store ptr %51, ptr %MEMORY, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  ret ptr %53
}

define ptr @BB_120f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i1 = zext i32 %call.i.i to i64
  store i64 %conv.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %11, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 24
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load i64, ptr %RDX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %23, %22
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %22
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %23
  %25 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %25, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %27 = and i8 %26, 1
  %conv.i.i.i = xor i8 %27, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %22
  %28 = trunc i64 %xor1.i.i.i.i to i8
  %29 = lshr i8 %28, 4
  %conv2.i.i.i = and i8 %29, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %22
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %19
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call zeroext i8 @__remill_read_memory_8(ptr noundef %34, i64 noundef %33) #13
  %conv.i.i4 = zext i8 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i8, ptr %AL, align 1
  %39 = zext i8 %38 to i64
  %40 = load i8, ptr %AL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 %41, %39
  %and3.i.i = trunc i64 %and3.i15.i to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i5, align 1
  %43 = call i8 @llvm.ctpop.i8(i8 %and3.i.i)
  %44 = and i8 %43, 1
  %conv.i14.i = xor i8 %44, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i, align 1
  %45 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i6 = and i32 %45, 255
  %cmp.i.i.i7 = icmp eq i8 %and3.i.i, 0
  %46 = trunc i64 %39 to i32
  %conv1.i.i.i = and i32 %46, 255
  %47 = trunc i64 %41 to i32
  %conv2.i.i.i8 = and i32 %47, 255
  %call.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i7, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv3.i.i = zext i1 %call.i.i.i9 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i8 %and3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv6.i.i = zext i1 %call4.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %35
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 2
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %NEXT_PC, align 8
  %52 = add i64 %51, 20
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  %55 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %55, 0
  %call8.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i) #14
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %52, i64 %53
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %54, ptr %MEMORY, align 8
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  ret ptr %57
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1237(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = add i64 %12, 47
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_1223(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i1 = zext i32 %call.i.i to i64
  store i64 %conv.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %11, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 32
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load i64, ptr %RDX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %23, %22
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %22
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %23
  %25 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %25, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %27 = and i8 %26, 1
  %conv.i.i.i = xor i8 %27, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %22
  %28 = trunc i64 %xor1.i.i.i.i to i8
  %29 = lshr i8 %28, 4
  %conv2.i.i.i = and i8 %29, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %22
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %19
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call zeroext i8 @__remill_read_memory_8(ptr noundef %34, i64 noundef %33) #13
  %conv.i.i4 = zext i8 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i8, ptr %AL, align 1
  %39 = zext i8 %38 to i64
  %40 = load i8, ptr %AL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 %41, %39
  %and3.i.i = trunc i64 %and3.i15.i to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i5, align 1
  %43 = call i8 @llvm.ctpop.i8(i8 %and3.i.i)
  %44 = and i8 %43, 1
  %conv.i14.i = xor i8 %44, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i, align 1
  %45 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i6 = and i32 %45, 255
  %cmp.i.i.i7 = icmp eq i8 %and3.i.i, 0
  %46 = trunc i64 %39 to i32
  %conv1.i.i.i = and i32 %46, 255
  %47 = trunc i64 %41 to i32
  %conv2.i.i.i8 = and i32 %47, 255
  %call.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i7, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv3.i.i = zext i1 %call.i.i.i9 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i8 %and3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv6.i.i = zext i1 %call4.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %35
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 2
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %NEXT_PC, align 8
  %52 = sub i64 %51, 89
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  %55 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %55, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %52, i64 %53
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %54, ptr %MEMORY, align 8
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  ret ptr %57
}

define ptr @BB_123d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i1 = zext i32 %call.i.i to i64
  store i64 %conv.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %11, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 24
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load i64, ptr %RDX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %23, %22
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %22
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %23
  %25 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %25, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %27 = and i8 %26, 1
  %conv.i.i.i = xor i8 %27, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %22
  %28 = trunc i64 %xor1.i.i.i.i to i8
  %29 = lshr i8 %28, 4
  %conv2.i.i.i = and i8 %29, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %22
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %19
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call zeroext i8 @__remill_read_memory_8(ptr noundef %34, i64 noundef %33) #13
  %conv.i.i4 = zext i8 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i8, ptr %AL, align 1
  %39 = zext i8 %38 to i64
  %40 = load i8, ptr %AL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 %41, %39
  %and3.i.i = trunc i64 %and3.i15.i to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i5, align 1
  %43 = call i8 @llvm.ctpop.i8(i8 %and3.i.i)
  %44 = and i8 %43, 1
  %conv.i14.i = xor i8 %44, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i, align 1
  %45 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i6 = and i32 %45, 255
  %cmp.i.i.i7 = icmp eq i8 %and3.i.i, 0
  %46 = trunc i64 %39 to i32
  %conv1.i.i.i = and i32 %46, 255
  %47 = trunc i64 %41 to i32
  %conv2.i.i.i8 = and i32 %47, 255
  %call.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i7, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv3.i.i = zext i1 %call.i.i.i9 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i8 %and3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv6.i.i = zext i1 %call4.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %35
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 2
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %NEXT_PC, align 8
  %52 = add i64 %51, 27
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  %55 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %55, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %52, i64 %53
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %54, ptr %MEMORY, align 8
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  ret ptr %57
}

define ptr @BB_11de(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %DL = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i46 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i47 = zext i32 %call.i.i46 to i64
  store i64 %conv.i.i47, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i55 = shl i64 %11, 32
  %conv.i12.i56 = ashr exact i64 %sext.i55, 32
  store i64 %conv.i12.i56, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 24
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i49, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load i64, ptr %RDX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 %23, %22
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %22
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, %23
  %25 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %25, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i1) #13
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %27 = and i8 %26, 1
  %conv.i.i.i8 = xor i8 %27, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, %23
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %22
  %28 = trunc i64 %xor1.i.i.i.i11 to i8
  %29 = lshr i8 %28, 4
  %conv2.i.i.i12 = and i8 %29, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i1) #13
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i1) #13
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %22
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i1) #13
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %19
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call zeroext i8 @__remill_read_memory_8(ptr noundef %34, i64 noundef %33) #13
  %conv.i.i53 = zext i8 %call.i.i52 to i64
  store i64 %conv.i.i53, ptr %RDX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 4
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %40, i64 noundef %39) #13
  %conv.i.i45 = zext i32 %call.i.i to i64
  store i64 %conv.i.i45, ptr %RAX, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i32, ptr %EAX, align 4
  %45 = zext i32 %44 to i64
  %46 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %45, 32
  %conv.i12.i54 = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i54, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 4
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RBP, align 8
  %51 = sub i64 %50, 32
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i48 = call i64 @__remill_read_memory_64(ptr noundef %52, i64 noundef %51) #13
  store i64 %call.i.i48, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load i64, ptr %RCX, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %57, %56
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %56
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %57
  %59 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %59, i64 noundef %56, i64 noundef %57, i64 noundef %add.i.i) #13
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %60 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %61 = and i8 %60, 1
  %conv.i.i.i = xor i8 %61, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %57
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %56
  %62 = trunc i64 %xor1.i.i.i.i to i8
  %63 = lshr i8 %62, 4
  %conv2.i.i.i = and i8 %63, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %56, i64 noundef %57, i64 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %56, i64 noundef %57, i64 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %56
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %56, i64 noundef %57, i64 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %58, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %53
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 3
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %RAX, align 8
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call zeroext i8 @__remill_read_memory_8(ptr noundef %68, i64 noundef %67) #13
  %conv.i.i51 = zext i8 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RAX, align 8
  store ptr %68, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %64
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 2
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i8, ptr %DL, align 1
  %73 = zext i8 %72 to i64
  %74 = load i8, ptr %AL, align 1
  %75 = zext i8 %74 to i64
  %76 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i8 %72, %74
  %77 = trunc i64 %73 to i32
  %conv.i.i.i30 = and i32 %77, 255
  %78 = trunc i64 %75 to i32
  %conv1.i.i.i = and i32 %78, 255
  %cmp.i.i.i31 = icmp ult i8 %72, %74
  %conv4.i.i.i = zext i8 %sub.i.i to i32
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i31, i32 noundef %conv.i.i.i30, i32 noundef %conv1.i.i.i, i32 noundef %conv4.i.i.i) #13
  %conv.i12.i = zext i1 %call.i.i.i32 to i8
  %cf.i.i33 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i33, align 1
  %79 = call i8 @llvm.ctpop.i8(i8 %sub.i.i)
  %80 = and i8 %79, 1
  %conv.i5.i.i = xor i8 %80, 1
  %pf.i.i.i34 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i5.i.i, ptr %pf.i.i.i34, align 1
  %xor4.i.i.i.i = xor i8 %74, %72
  %xor35.i.i.i.i = xor i8 %xor4.i.i.i.i, %sub.i.i
  %81 = lshr i8 %xor35.i.i.i.i, 4
  %.lobit.i.i.i = and i8 %81, 1
  %af.i.i.i35 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %.lobit.i.i.i, ptr %af.i.i.i35, align 1
  %cmp.i.i.i.i36 = icmp eq i8 %72, %74
  %call.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i36, i32 noundef %conv.i.i.i30, i32 noundef %conv1.i.i.i, i32 noundef %conv4.i.i.i) #13
  %conv5.i.i.i38 = zext i1 %call.i.i.i.i37 to i8
  %zf.i.i.i39 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i38, ptr %zf.i.i.i39, align 1
  %cmp.i27.i.i.i40 = icmp slt i8 %sub.i.i, 0
  %call4.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i40, i32 noundef %conv.i.i.i30, i32 noundef %conv1.i.i.i, i32 noundef %conv4.i.i.i) #13
  %conv8.i.i.i41 = zext i1 %call4.i.i.i.i to i8
  %sf.i.i.i42 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i41, ptr %sf.i.i.i42, align 1
  %xor20.i.i.i.i = lshr i8 %xor4.i.i.i.i, 7
  %shr23.i.i.i.i = xor i8 %sub.i.i, %72
  %xor1222.i.i.i.i = lshr i8 %shr23.i.i.i.i, 7
  %narrow.i.i.i.i = add nuw nsw i8 %xor1222.i.i.i.i, %xor20.i.i.i.i
  %cmp.i32.i.i.i = icmp eq i8 %narrow.i.i.i.i, 2
  %call.i33.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i32.i.i.i, i32 noundef %conv.i.i.i30, i32 noundef %conv1.i.i.i, i32 noundef %conv4.i.i.i) #13
  %conv11.i.i.i43 = zext i1 %call.i33.i.i.i to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %69
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 2
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %NEXT_PC, align 8
  %86 = add i64 %85, 9
  %87 = load i64, ptr %NEXT_PC, align 8
  %88 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  %89 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %89, 0
  %call8.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i) #14
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %86, i64 %87
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %88, ptr %MEMORY, align 8
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  ret ptr %91
}

define ptr @BB_1251(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i1 = zext i32 %call.i.i to i64
  store i64 %conv.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %11, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 32
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load i64, ptr %RDX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %23, %22
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %22
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %23
  %25 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %25, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %27 = and i8 %26, 1
  %conv.i.i.i = xor i8 %27, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %22
  %28 = trunc i64 %xor1.i.i.i.i to i8
  %29 = lshr i8 %28, 4
  %conv2.i.i.i = and i8 %29, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %22
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %22, i64 noundef %23, i64 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %19
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call zeroext i8 @__remill_read_memory_8(ptr noundef %34, i64 noundef %33) #13
  %conv.i.i4 = zext i8 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i8, ptr %AL, align 1
  %39 = zext i8 %38 to i64
  %40 = load i8, ptr %AL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 %41, %39
  %and3.i.i = trunc i64 %and3.i15.i to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i5, align 1
  %43 = call i8 @llvm.ctpop.i8(i8 %and3.i.i)
  %44 = and i8 %43, 1
  %conv.i14.i = xor i8 %44, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i, align 1
  %45 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i6 = and i32 %45, 255
  %cmp.i.i.i7 = icmp eq i8 %and3.i.i, 0
  %46 = trunc i64 %39 to i32
  %conv1.i.i.i = and i32 %46, 255
  %47 = trunc i64 %41 to i32
  %conv2.i.i.i8 = and i32 %47, 255
  %call.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i7, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv3.i.i = zext i1 %call.i.i.i9 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i8 %and3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i8, i32 noundef %conv.i.i.i6) #13
  %conv6.i.i = zext i1 %call4.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %35
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 2
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %NEXT_PC, align 8
  %52 = add i64 %51, 7
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  %55 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %55, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %52, i64 %53
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %54, ptr %MEMORY, align 8
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  ret ptr %57
}

define ptr @BB_120b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load i64, ptr %RBP, align 8
  %7 = sub i64 %6, 4
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %8, i64 noundef %7) #13
  %add.i.i = add i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %8, i64 noundef %5, i32 noundef %add.i.i) #13
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %9 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %9, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %10 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %11 = and i8 %10, 1
  %conv.i.i.i = xor i8 %11, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %12 = trunc i32 %xor1.i.i.i.i to i8
  %13 = lshr i8 %12, 4
  %conv2.i.i.i = and i8 %13, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %1
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1202(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %6, i64 noundef %5, i32 noundef 1) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = add i64 %10, 44
  %12 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store ptr %12, ptr %MEMORY, align 8
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  ret ptr %14
}

define ptr @BB_1265(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 2
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 5
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_126c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1271(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20708, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rsp.i1 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 13
  %5 = load i64, ptr %rsp.i1, align 8
  %add.i.i2 = add i64 %5, 8
  store i64 %add.i.i2, ptr %rsp.i1, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #13
  store i64 %call.i.i3, ptr %RBP, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #13
  %rip.i = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.20708, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.20708) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.20708) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4542, label %bb_11BE
    i64 4574, label %bb_11DE
    i64 4610, label %bb_1202
    i64 4619, label %bb_120B
    i64 4623, label %bb_120F
    i64 4643, label %bb_1223
    i64 4663, label %bb_1237
    i64 4669, label %bb_123D
    i64 4689, label %bb_1251
    i64 4709, label %bb_1265
    i64 4716, label %bb_126C
    i64 4721, label %bb_1271
  ]

dead_end:                                         ; preds = %bb_1265, %bb_1251, %bb_123D, %bb_1237, %bb_1223, %bb_120F, %bb_120B, %bb_1202, %bb_11DE, %bb_11BE, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_11BE:                                          ; preds = %entry
  %block_pc = add i64 4542, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4542, ptr %1)
  %4 = call ptr @BB_11be(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4623, label %bb_120F
  ]

bb_11DE:                                          ; preds = %bb_1223, %entry
  %block_pc1 = add i64 4574, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4574, ptr %6)
  %9 = call ptr @BB_11de(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4610, label %bb_1202
    i64 4619, label %bb_120B
  ]

bb_1202:                                          ; preds = %bb_11DE, %entry
  %block_pc3 = add i64 4610, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4610, ptr %11)
  %14 = call ptr @BB_1202(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4663, label %bb_1237
  ]

bb_120B:                                          ; preds = %bb_11DE, %entry
  %block_pc5 = add i64 4619, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4619, ptr %16)
  %19 = call ptr @BB_120b(ptr %state, i64 %17, ptr %16) #16
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4623, label %bb_120F
  ]

bb_120F:                                          ; preds = %bb_120B, %bb_11BE, %entry
  %block_pc7 = add i64 4623, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4623, ptr %21)
  %24 = call ptr @BB_120f(ptr %state, i64 %22, ptr %21) #16
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4643, label %bb_1223
    i64 4663, label %bb_1237
  ]

bb_1223:                                          ; preds = %bb_120F, %entry
  %block_pc9 = add i64 4643, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4643, ptr %26)
  %29 = call ptr @BB_1223(ptr %state, i64 %27, ptr %26) #16
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4574, label %bb_11DE
    i64 4663, label %bb_1237
  ]

bb_1237:                                          ; preds = %bb_1223, %bb_120F, %bb_1202, %entry
  %block_pc11 = add i64 4663, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4663, ptr %31)
  %34 = call ptr @BB_1237(ptr %state, i64 %32, ptr %31) #16
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4669, label %bb_123D
    i64 4716, label %bb_126C
  ]

bb_123D:                                          ; preds = %bb_1237, %entry
  %block_pc13 = add i64 4669, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4669, ptr %36)
  %39 = call ptr @BB_123d(ptr %state, i64 %37, ptr %36) #16
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4689, label %bb_1251
    i64 4716, label %bb_126C
  ]

bb_1251:                                          ; preds = %bb_123D, %entry
  %block_pc15 = add i64 4689, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4689, ptr %41)
  %44 = call ptr @BB_1251(ptr %state, i64 %42, ptr %41) #16
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4709, label %bb_1265
    i64 4716, label %bb_126C
  ]

bb_1265:                                          ; preds = %bb_1251, %entry
  %block_pc17 = add i64 4709, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4709, ptr %46)
  %49 = call ptr @BB_1265(ptr %state, i64 %47, ptr %46) #16
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4721, label %bb_1271
  ]

bb_126C:                                          ; preds = %bb_1251, %bb_123D, %bb_1237, %entry
  %block_pc19 = add i64 4716, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4716, ptr %51)
  %54 = call ptr @BB_126c(ptr %state, i64 %52, ptr %51) #16
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %return_bb [
    i64 4721, label %bb_1271
  ]

bb_1271:                                          ; preds = %bb_126C, %bb_1265, %entry
  %block_pc21 = add i64 4721, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 4721, ptr %56)
  %59 = call ptr @BB_1271(ptr %state, i64 %57, ptr %56) #16
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  %61 = load ptr, ptr %mem_var, align 8
  ret ptr %61

return_bb:                                        ; preds = %bb_126C
  %62 = load ptr, ptr %mem_var, align 8
  ret ptr %62
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4542, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.20707, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
