; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.1383 = type { %struct.X86State.1382 }
%struct.X86State.1382 = type { %struct.ArchState.1351, [32 x %union.VectorReg.1354], %struct.ArithFlags.1355, %union.anon.1350, %struct.Segments.1357, %struct.AddressSpace.1359, %struct.GPR.1360, %struct.X87Stack.1363, %struct.MMX.1367, %struct.FPUStatusFlags.1368, %union.anon.1350, %union.FPU.1377, %struct.SegmentCaches.1379, %struct.K_REG.1381 }
%struct.ArchState.1351 = type { i32, i32, %union.anon.1350 }
%union.VectorReg.1354 = type { %union.vec512_t.1353 }
%union.vec512_t.1353 = type { %struct.uint64v8_t.1352 }
%struct.uint64v8_t.1352 = type { [8 x i64] }
%struct.ArithFlags.1355 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.1357 = type { i16, %union.SegmentSelector.1356, i16, %union.SegmentSelector.1356, i16, %union.SegmentSelector.1356, i16, %union.SegmentSelector.1356, i16, %union.SegmentSelector.1356, i16, %union.SegmentSelector.1356 }
%union.SegmentSelector.1356 = type { i16 }
%struct.AddressSpace.1359 = type { i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358 }
%struct.Reg.1358 = type { %union.anon.1350 }
%struct.GPR.1360 = type { i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358, i64, %struct.Reg.1358 }
%struct.X87Stack.1363 = type { [8 x %struct.anon.3.1362] }
%struct.anon.3.1362 = type { [6 x i8], %struct.float80_t.1361 }
%struct.float80_t.1361 = type { [10 x i8] }
%struct.MMX.1367 = type { [8 x %struct.anon.4.1366] }
%struct.anon.4.1366 = type { i64, %union.vec64_t.1365 }
%union.vec64_t.1365 = type { %struct.uint64v1_t.1364 }
%struct.uint64v1_t.1364 = type { [1 x i64] }
%struct.FPUStatusFlags.1368 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.1350 = type { i64 }
%union.FPU.1377 = type { %struct.anon.13.1376 }
%struct.anon.13.1376 = type { %struct.FpuFXSAVE.1375, [96 x i8] }
%struct.FpuFXSAVE.1375 = type { %union.SegmentSelector.1356, %union.SegmentSelector.1356, %union.FPUAbridgedTagWord.1369, i8, i16, i32, %union.SegmentSelector.1356, i16, i32, %union.SegmentSelector.1356, i16, %union.FPUControlStatus.1370, %union.FPUControlStatus.1370, [8 x %struct.FPUStackElem.1372], [16 x %union.vec128_t.1374] }
%union.FPUAbridgedTagWord.1369 = type { i8 }
%union.FPUControlStatus.1370 = type { i32 }
%struct.FPUStackElem.1372 = type { %union.anon.11.1371, [6 x i8] }
%union.anon.11.1371 = type { %struct.float80_t.1361 }
%union.vec128_t.1374 = type { %struct.uint128v1_t.1373 }
%struct.uint128v1_t.1373 = type { [1 x i128] }
%struct.SegmentCaches.1379 = type { %struct.SegmentShadow.1378, %struct.SegmentShadow.1378, %struct.SegmentShadow.1378, %struct.SegmentShadow.1378, %struct.SegmentShadow.1378, %struct.SegmentShadow.1378 }
%struct.SegmentShadow.1378 = type { %union.anon.1350, i32, i32 }
%struct.K_REG.1381 = type { [8 x %struct.anon.18.1380] }
%struct.anon.18.1380 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_10f9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 20
  %25 = load i32, ptr %EDI, align 4
  %26 = zext i32 %25 to i64
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_32(ptr noundef %27, i64 noundef %24, i32 noundef %25) #13
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 7
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 4
  %33 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %33, i64 noundef %32, i32 noundef 0) #13
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %28
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 7
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RBP, align 8
  %38 = sub i64 %37, 8
  %39 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %39, i64 noundef %38, i32 noundef 0) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %34
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 2
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %NEXT_PC, align 8
  %44 = add i64 %43, 10
  %45 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 33
  store i64 %44, ptr %rip.i, align 8
  store i64 %44, ptr %NEXT_PC, align 8
  store ptr %45, ptr %MEMORY, align 8
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = load ptr, ptr %MEMORY, align 8
  ret ptr %47
}

define ptr @BB_111e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 20
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #13
  %sub.i.i = sub i32 %10, %call.i.i
  %cmp.i.i.i = icmp ugt i32 %call.i.i, %10
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %15 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %16 = and i8 %15, 1
  %conv.i.i.i = xor i8 %16, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, %10
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %17 = trunc i32 %xor1.i.i.i.i to i8
  %18 = lshr i8 %17, 4
  %conv2.i.i.i = and i8 %18, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, %10
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %10
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %7
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = sub i64 %22, 18
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 9
  %26 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %26, 0
  %of.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 13
  %27 = load i8, ptr %of.i, align 1
  %tobool9.i = icmp ne i8 %27, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool9.i
  %call11.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i) #14
  %frombool.i = zext i1 %call11.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call11.i, i64 %23, i64 %24
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %25, ptr %MEMORY, align 8
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  ret ptr %29
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1114(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i32 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 4
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 4
  %14 = load i32, ptr %EAX, align 4
  %15 = zext i32 %14 to i64
  %16 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %16, i64 noundef %13) #13
  %add.i.i2 = add i32 %call.i.i1, %14
  %call.i18.i3 = call ptr @__remill_write_memory_32(ptr noundef %16, i64 noundef %11, i32 noundef %add.i.i2) #13
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %call.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %14
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %call.i.i1, i32 noundef %14, i32 noundef %add.i.i2) #13
  %conv.i19.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %14
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %call.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %call.i.i1, i32 noundef %14, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %call.i.i1, i32 noundef %14, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %call.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %call.i.i1, i32 noundef %14, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %call.i18.i3, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %7
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 4
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RBP, align 8
  %26 = sub i64 %25, 8
  %27 = load i64, ptr %RBP, align 8
  %28 = sub i64 %27, 8
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %29, i64 noundef %28) #13
  %add.i.i = add i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %29, i64 noundef %26, i32 noundef %add.i.i) #13
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %30 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %30, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %31 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %32 = and i8 %31, 1
  %conv.i.i.i = xor i8 %32, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %33 = trunc i32 %xor1.i.i.i.i to i8
  %34 = lshr i8 %33, 4
  %conv2.i.i.i = and i8 %34, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %22
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1126(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.1383, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 1
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 13
  %11 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %11, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %10, i64 noundef %11) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #13
  %rip.i = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %17, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %15, ptr %MEMORY, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.1383, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.1383) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.1383) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4345, label %bb_10F9
    i64 4372, label %bb_1114
    i64 4382, label %bb_111E
    i64 4390, label %bb_1126
  ]

dead_end:                                         ; preds = %bb_111E, %bb_1114, %bb_10F9, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_10F9:                                          ; preds = %entry
  %block_pc = add i64 4345, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4345, ptr %1)
  %4 = call ptr @BB_10f9(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4382, label %bb_111E
  ]

bb_1114:                                          ; preds = %bb_111E, %entry
  %block_pc1 = add i64 4372, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4372, ptr %6)
  %9 = call ptr @BB_1114(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4382, label %bb_111E
  ]

bb_111E:                                          ; preds = %bb_1114, %bb_10F9, %entry
  %block_pc3 = add i64 4382, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4382, ptr %11)
  %14 = call ptr @BB_111e(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4372, label %bb_1114
    i64 4390, label %bb_1126
  ]

bb_1126:                                          ; preds = %bb_111E, %entry
  %block_pc5 = add i64 4390, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4390, ptr %16)
  %19 = call ptr @BB_1126(ptr %state, i64 %17, ptr %16) #16
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  %21 = load ptr, ptr %mem_var, align 8
  ret ptr %21

return_bb:                                        ; No predecessors!
  %22 = load ptr, ptr %mem_var, align 8
  ret ptr %22
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4345, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() local_unnamed_addr #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.1382, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
