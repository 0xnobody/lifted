; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.22004 = type { %struct.X86State.22003 }
%struct.X86State.22003 = type { %struct.ArchState.21972, [32 x %union.VectorReg.21975], %struct.ArithFlags.21976, %union.anon.21971, %struct.Segments.21978, %struct.AddressSpace.21980, %struct.GPR.21981, %struct.X87Stack.21984, %struct.MMX.21988, %struct.FPUStatusFlags.21989, %union.anon.21971, %union.FPU.21998, %struct.SegmentCaches.22000, %struct.K_REG.22002 }
%struct.ArchState.21972 = type { i32, i32, %union.anon.21971 }
%union.VectorReg.21975 = type { %union.vec512_t.21974 }
%union.vec512_t.21974 = type { %struct.uint64v8_t.21973 }
%struct.uint64v8_t.21973 = type { [8 x i64] }
%struct.ArithFlags.21976 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.21978 = type { i16, %union.SegmentSelector.21977, i16, %union.SegmentSelector.21977, i16, %union.SegmentSelector.21977, i16, %union.SegmentSelector.21977, i16, %union.SegmentSelector.21977, i16, %union.SegmentSelector.21977 }
%union.SegmentSelector.21977 = type { i16 }
%struct.AddressSpace.21980 = type { i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979 }
%struct.Reg.21979 = type { %union.anon.21971 }
%struct.GPR.21981 = type { i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979, i64, %struct.Reg.21979 }
%struct.X87Stack.21984 = type { [8 x %struct.anon.3.21983] }
%struct.anon.3.21983 = type { [6 x i8], %struct.float80_t.21982 }
%struct.float80_t.21982 = type { [10 x i8] }
%struct.MMX.21988 = type { [8 x %struct.anon.4.21987] }
%struct.anon.4.21987 = type { i64, %union.vec64_t.21986 }
%union.vec64_t.21986 = type { %struct.uint64v1_t.21985 }
%struct.uint64v1_t.21985 = type { [1 x i64] }
%struct.FPUStatusFlags.21989 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.21971 = type { i64 }
%union.FPU.21998 = type { %struct.anon.13.21997 }
%struct.anon.13.21997 = type { %struct.FpuFXSAVE.21996, [96 x i8] }
%struct.FpuFXSAVE.21996 = type { %union.SegmentSelector.21977, %union.SegmentSelector.21977, %union.FPUAbridgedTagWord.21990, i8, i16, i32, %union.SegmentSelector.21977, i16, i32, %union.SegmentSelector.21977, i16, %union.FPUControlStatus.21991, %union.FPUControlStatus.21991, [8 x %struct.FPUStackElem.21993], [16 x %union.vec128_t.21995] }
%union.FPUAbridgedTagWord.21990 = type { i8 }
%union.FPUControlStatus.21991 = type { i32 }
%struct.FPUStackElem.21993 = type { %union.anon.11.21992, [6 x i8] }
%union.anon.11.21992 = type { %struct.float80_t.21982 }
%union.vec128_t.21995 = type { %struct.uint128v1_t.21994 }
%struct.uint128v1_t.21994 = type { [1 x i128] }
%struct.SegmentCaches.22000 = type { %struct.SegmentShadow.21999, %struct.SegmentShadow.21999, %struct.SegmentShadow.21999, %struct.SegmentShadow.21999, %struct.SegmentShadow.21999, %struct.SegmentShadow.21999 }
%struct.SegmentShadow.21999 = type { %union.anon.21971, i32, i32 }
%struct.K_REG.22002 = type { [8 x %struct.anon.18.22001] }
%struct.anon.18.22001 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1179(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i30 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #18
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i30, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 48
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 48
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 48, i64 noundef %sub.i.i) #18
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 48, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 48
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 48, i64 noundef %sub.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 48, i64 noundef %sub.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 48, i64 noundef %sub.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 36
  %34 = load i32, ptr %EDI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #18
  store ptr %call.i.i28, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 48
  %42 = load i64, ptr %RSI, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #18
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 36
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %49, i64 noundef %48) #18
  %sub.i.i1 = sub i32 %call.i.i, 1
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, 1
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #18
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %51 = and i8 %50, 1
  %conv.i.i.i6 = xor i8 %51, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, 1
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %52 = trunc i32 %xor1.i.i.i.i9 to i8
  %53 = lshr i8 %52, 4
  %conv2.i.i.i10 = and i8 %53, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, 1
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #18
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #18
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #18
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %44
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  %58 = add i64 %57, 10
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  %61 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %61, 0
  %sf.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool10.i = icmp eq i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool12.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool10.i, %tobool12.i
  %64 = and i1 %tobool.not.i, %cmp.i.i
  %call15.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %64) #19
  %frombool.i = zext i1 %call15.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call15.i, i64 %58, i64 %59
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %60, ptr %MEMORY, align 8
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  ret ptr %66
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_119c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 8
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_64(ptr noundef %6, i64 noundef %5, i64 noundef 1) #18
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  store i64 %11, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RDI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 5
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = sub i64 %21, 256
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %25 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %25, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %24, i64 noundef %sub.i.i, i64 noundef %23) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %22, ptr %rip.i, align 8
  store i64 %22, ptr %NEXT_PC, align 8
  store i64 %23, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  ret ptr %26
}

define ptr @BB_1192(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 5
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 140
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_time(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_time(ptr, i64, ptr) #2

define ptr @BB_1228(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #18
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #18
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_11b0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EAX, align 4
  %5 = zext i32 %4 to i64
  %6 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %5, 4294967295
  store i64 %conv.i11.i, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = sub i64 %10, 279
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %14, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i, i64 noundef %12) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store i64 %12, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  ret ptr %15
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_srand(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_srand(ptr, i64, ptr) #4

define ptr @BB_11b7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i21 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i21, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 8, %10
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %10
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 8
  %12 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #18
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %14 = and i8 %13, 1
  %conv.i.i.i = xor i8 %14, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 8
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %10
  %15 = trunc i64 %xor1.i.i.i.i to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i = and i8 %16, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %10
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 3
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i64, ptr %RAX, align 8
  %21 = load ptr, ptr %MEMORY, align 8
  %call.i.i20 = call i64 @__remill_read_memory_64(ptr noundef %21, i64 noundef %20) #18
  store i64 %call.i.i20, ptr %RAX, align 8
  store ptr %21, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %17
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 3
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i22 = call zeroext i8 @__remill_read_memory_8(ptr noundef %26, i64 noundef %25) #18
  %conv.i.i23 = zext i8 %call.i.i22 to i64
  store i64 %conv.i.i23, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %22
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i8, ptr %AL, align 1
  %31 = zext i8 %30 to i64
  %32 = load ptr, ptr %MEMORY, align 8
  %conv.i.i24 = trunc i64 %31 to i32
  %sext.i = shl i32 %conv.i.i24, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RBP, align 8
  %37 = sub i64 %36, 20
  %38 = load i32, ptr %EAX, align 4
  %39 = zext i32 %38 to i64
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i19 = call ptr @__remill_write_memory_32(ptr noundef %40, i64 noundef %37, i32 noundef %38) #18
  store ptr %call.i.i19, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %33
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 4
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RBP, align 8
  %45 = sub i64 %44, 20
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #18
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i1 to i8
  %cf.i.i2 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i2, align 1
  %conv.i.i.i.i3 = trunc i32 %call.i.i to i8
  %47 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i3)
  %48 = and i8 %47, 1
  %conv.i.i.i4 = xor i8 %48, 1
  %pf.i.i.i5 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i4, ptr %pf.i.i.i5, align 1
  %af.i.i.i6 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i6, align 1
  %cmp.i.i.i.i7 = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i8 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i7, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #18
  %conv5.i.i.i9 = zext i1 %call.i.i.i.i8 to i8
  %zf.i.i.i10 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i9, ptr %zf.i.i.i10, align 1
  %cmp.i27.i.i.i11 = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i11, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #18
  %conv8.i.i.i13 = zext i1 %call1.i.i.i.i12 to i8
  %sf.i.i.i14 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i13, ptr %sf.i.i.i14, align 1
  %xor.i28.i.i.i15 = lshr i32 %call.i.i, 31
  %call.i30.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #18
  %conv11.i.i.i17 = zext i1 %call.i30.i.i.i16 to i8
  %of.i.i.i18 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i17, ptr %of.i.i.i18, align 1
  store ptr %46, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %41
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 2
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 17
  %54 = load i64, ptr %NEXT_PC, align 8
  %55 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  %56 = load i8, ptr %sf.i, align 1
  %tobool.not.i = icmp eq i8 %56, 0
  %frombool.i = zext i1 %tobool.not.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %tobool.not.i, i64 %53, i64 %54
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %55, ptr %MEMORY, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  ret ptr %58
}

define ptr @BB_11e2(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %6, i64 noundef %5, i32 noundef 1) #18
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = add i64 %10, 21
  %12 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store ptr %12, ptr %MEMORY, align 8
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  ret ptr %14
}

define ptr @BB_11d1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3624
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RDI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = sub i64 %15, 352
  %17 = load i64, ptr %NEXT_PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %19 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %19, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %18, i64 noundef %sub.i.i, i64 noundef %17) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %16, ptr %rip.i, align 8
  store i64 %16, ptr %NEXT_PC, align 8
  store i64 %17, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  ret ptr %20
}

define ptr @BB_1200(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #18
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 20
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #18
  %sub.i.i = sub i32 %10, %call.i.i
  %cmp.i.i.i = icmp ugt i32 %call.i.i, %10
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %15 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %16 = and i8 %15, 1
  %conv.i.i.i = xor i8 %16, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, %10
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %17 = trunc i32 %xor1.i.i.i.i to i8
  %18 = lshr i8 %17, 4
  %conv2.i.i.i = and i8 %18, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, %10
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %10
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %7
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = sub i64 %22, 29
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  %26 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %26, 0
  %sf.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  %27 = load i8, ptr %sf.i, align 1
  %tobool9.i = icmp ne i8 %27, 0
  %of.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  %28 = load i8, ptr %of.i, align 1
  %tobool11.i = icmp ne i8 %28, 0
  %cmp.i.i = xor i1 %tobool9.i, %tobool11.i
  %29 = or i1 %tobool.i, %cmp.i.i
  %call14.i = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %29) #19
  %frombool.i = zext i1 %call14.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call14.i, i64 %23, i64 %24
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %25, ptr %MEMORY, align 8
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  ret ptr %31
}

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #5 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_puts(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_puts(ptr, i64, ptr) #5

define ptr @BB_11eb(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #18
  %conv.i.i7 = zext i32 %call.i.i6 to i64
  store i64 %conv.i.i7, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 1
  %11 = load i32, ptr %rax.i, align 8
  %conv.i.i = sext i32 %11 to i64
  store i64 %conv.i.i, ptr %rax.i, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 16
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i8 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i8, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %24 = ashr i64 %21, 63
  %25 = ashr i64 %22, 63
  %L.sroa.2.0.insert.ext.i.i = zext i64 %24 to i128
  %L.sroa.2.0.insert.shift.i.i = shl nuw i128 %L.sroa.2.0.insert.ext.i.i, 64
  %L.sroa.0.0.insert.ext.i.i = zext i64 %21 to i128
  %L.sroa.0.0.insert.insert.i.i = or i128 %L.sroa.2.0.insert.shift.i.i, %L.sroa.0.0.insert.ext.i.i
  %R.sroa.2.0.insert.ext.i.i = zext i64 %25 to i128
  %R.sroa.2.0.insert.shift.i.i = shl nuw i128 %R.sroa.2.0.insert.ext.i.i, 64
  %R.sroa.0.0.insert.ext.i.i = zext i64 %22 to i128
  %R.sroa.0.0.insert.insert.i.i = or i128 %R.sroa.2.0.insert.shift.i.i, %R.sroa.0.0.insert.ext.i.i
  %mul.i.i = mul nsw i128 %R.sroa.0.0.insert.insert.i.i, %L.sroa.0.0.insert.insert.i.i
  %retval.sroa.0.0.extract.trunc.i.i = trunc i128 %mul.i.i to i64
  %retval.sroa.2.0.extract.shift.i.i = lshr i128 %mul.i.i, 64
  %retval.sroa.2.0.extract.trunc.i.i = trunc i128 %retval.sroa.2.0.extract.shift.i.i to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i, ptr %RAX, align 8
  %conv2.i.i.i1 = sext i64 %retval.sroa.0.0.extract.trunc.i.i to i128
  %cmp.i.i.i2 = icmp ne i128 %mul.i.i, %conv2.i.i.i1
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i2, i64 noundef %21, i64 noundef %22, i64 noundef %retval.sroa.0.0.extract.trunc.i.i, i64 noundef %retval.sroa.2.0.extract.trunc.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i4, align 1
  %call2.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %18
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 4
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RBP, align 8
  %30 = sub i64 %29, 16
  %31 = load i64, ptr %RAX, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call ptr @__remill_write_memory_64(ptr noundef %32, i64 noundef %30, i64 noundef %31) #18
  store ptr %call.i.i5, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %26
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 4
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RBP, align 8
  %37 = sub i64 %36, 4
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 4
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %40, i64 noundef %39) #18
  %add.i.i = add i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %40, i64 noundef %37, i32 noundef %add.i.i) #18
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %41 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %41, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %43 = and i8 %42, 1
  %conv.i.i.i = xor i8 %43, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %44 = trunc i32 %xor1.i.i.i.i to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i = and i8 %45, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %33
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1208(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 3615
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  store i64 %21, ptr %RDI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 5
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %23
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 5
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %NEXT_PC, align 8
  %31 = sub i64 %30, 403
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %34 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %34, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %33, i64 noundef %sub.i.i, i64 noundef %32) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %31, ptr %rip.i, align 8
  store i64 %31, ptr %NEXT_PC, align 8
  store i64 %32, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  ret ptr %35
}

define ptr @BB_11e0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 65
  %6 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store ptr %6, ptr %MEMORY, align 8
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  ret ptr %8
}

define ptr @BB_ffff000000000003_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #6 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !32)
  %rsp.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !35)
  %rip.i.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !38)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #6

define ptr @BB_1223(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.22004, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #7 {
entry:
  %agg.tmp = alloca %struct.State.22004, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.22004) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #20
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #8

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.22004) align 16, i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rip = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rax = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rax = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rip = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #12 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4473, label %bb_1179
    i64 4498, label %bb_1192
    i64 4508, label %bb_119C
    i64 4528, label %bb_11B0
    i64 4535, label %bb_11B7
    i64 4561, label %bb_11D1
    i64 4576, label %bb_11E0
    i64 4578, label %bb_11E2
    i64 4587, label %bb_11EB
    i64 4608, label %bb_1200
    i64 4616, label %bb_1208
    i64 4643, label %bb_1223
    i64 4648, label %bb_1228
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
    i64 -281474976710653, label %bb_FFFF000000000003
  ]

dead_end:                                         ; preds = %bb_FFFF000000000003, %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_1223, %bb_1208, %bb_1200, %bb_11EB, %bb_11E2, %bb_11E0, %bb_11D1, %bb_11B7, %bb_11B0, %bb_119C, %bb_1192, %bb_1179, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1179:                                          ; preds = %entry
  %block_pc = add i64 4473, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4473, ptr %1)
  %4 = call ptr @BB_1179(ptr %state, i64 %2, ptr %1) #21
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4498, label %bb_1192
    i64 4508, label %bb_119C
  ]

bb_1192:                                          ; preds = %bb_1179, %entry
  %block_pc1 = add i64 4498, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4498, ptr %6)
  %9 = call ptr @BB_1192(ptr %state, i64 %7, ptr %6) #21
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4648, label %bb_1228
  ]

bb_119C:                                          ; preds = %bb_1179, %entry
  %block_pc3 = add i64 4508, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4508, ptr %11)
  %14 = call ptr @BB_119c(ptr %state, i64 %12, ptr %11) #21
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4272, label %bb_FFFF000000000000
  ]

bb_11B0:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc5 = add i64 4528, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4528, ptr %16)
  %19 = call ptr @BB_11b0(ptr %state, i64 %17, ptr %16) #21
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4256, label %bb_FFFF000000000001
  ]

bb_11B7:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc7 = add i64 4535, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4535, ptr %21)
  %24 = call ptr @BB_11b7(ptr %state, i64 %22, ptr %21) #21
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4561, label %bb_11D1
    i64 4578, label %bb_11E2
  ]

bb_11D1:                                          ; preds = %bb_11B7, %entry
  %block_pc9 = add i64 4561, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4561, ptr %26)
  %29 = call ptr @BB_11d1(ptr %state, i64 %27, ptr %26) #21
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4224, label %bb_FFFF000000000002
  ]

bb_11E0:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc11 = add i64 4576, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4576, ptr %31)
  %34 = call ptr @BB_11e0(ptr %state, i64 %32, ptr %31) #21
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4643, label %bb_1223
  ]

bb_11E2:                                          ; preds = %bb_11B7, %entry
  %block_pc13 = add i64 4578, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4578, ptr %36)
  %39 = call ptr @BB_11e2(ptr %state, i64 %37, ptr %36) #21
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4608, label %bb_1200
  ]

bb_11EB:                                          ; preds = %bb_1200, %entry
  %block_pc15 = add i64 4587, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4587, ptr %41)
  %44 = call ptr @BB_11eb(ptr %state, i64 %42, ptr %41) #21
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4608, label %bb_1200
  ]

bb_1200:                                          ; preds = %bb_11EB, %bb_11E2, %entry
  %block_pc17 = add i64 4608, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4608, ptr %46)
  %49 = call ptr @BB_1200(ptr %state, i64 %47, ptr %46) #21
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4587, label %bb_11EB
    i64 4616, label %bb_1208
  ]

bb_1208:                                          ; preds = %bb_1200, %entry
  %block_pc19 = add i64 4616, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4616, ptr %51)
  %54 = call ptr @BB_1208(ptr %state, i64 %52, ptr %51) #21
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 4240, label %bb_FFFF000000000003
  ]

bb_1223:                                          ; preds = %bb_FFFF000000000003, %bb_11E0, %entry
  %block_pc21 = add i64 4643, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 4643, ptr %56)
  %59 = call ptr @BB_1223(ptr %state, i64 %57, ptr %56) #21
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4648, label %bb_1228
  ]

bb_1228:                                          ; preds = %bb_1223, %bb_1192, %entry
  %block_pc23 = add i64 4648, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 4648, ptr %61)
  %64 = call ptr @BB_1228(ptr %state, i64 %62, ptr %61) #21
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  %66 = load ptr, ptr %mem_var, align 8
  ret ptr %66

bb_FFFF000000000000:                              ; preds = %bb_119C, %entry
  %67 = load ptr, ptr %mem_var, align 8
  %68 = load i64, ptr %pc_var, align 4
  %69 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %68, ptr %67) #21
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva25 = sub i64 %70, %base
  switch i64 %next_rva25, label %dead_end [
    i64 4528, label %bb_11B0
  ]

bb_FFFF000000000001:                              ; preds = %bb_11B0, %entry
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %72, ptr %71) #21
  store ptr %73, ptr %mem_var, align 8
  %74 = call i64 @__extract_rip(ptr %state)
  store i64 %74, ptr %pc_var, align 4
  %next_rva26 = sub i64 %74, %base
  switch i64 %next_rva26, label %dead_end [
    i64 4535, label %bb_11B7
  ]

bb_FFFF000000000002:                              ; preds = %bb_11D1, %entry
  %75 = load ptr, ptr %mem_var, align 8
  %76 = load i64, ptr %pc_var, align 4
  %77 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %76, ptr %75) #21
  store ptr %77, ptr %mem_var, align 8
  %78 = call i64 @__extract_rip(ptr %state)
  store i64 %78, ptr %pc_var, align 4
  %next_rva27 = sub i64 %78, %base
  switch i64 %next_rva27, label %dead_end [
    i64 4576, label %bb_11E0
  ]

bb_FFFF000000000003:                              ; preds = %bb_1208, %entry
  %79 = load ptr, ptr %mem_var, align 8
  %80 = load i64, ptr %pc_var, align 4
  %81 = call ptr @BB_ffff000000000003_ext(ptr %state, i64 %80, ptr %79) #21
  store ptr %81, ptr %mem_var, align 8
  %82 = call i64 @__extract_rip(ptr %state)
  store i64 %82, ptr %pc_var, align 4
  %next_rva28 = sub i64 %82, %base
  switch i64 %next_rva28, label %dead_end [
    i64 4643, label %bb_1223
  ]

return_bb:                                        ; No predecessors!
  %83 = load ptr, ptr %mem_var, align 8
  ret ptr %83
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #13 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4473, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #14 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #14 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #14 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #14 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #14 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #15 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  %rip = getelementptr inbounds %struct.X86State.22003, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !41
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { "lifted.annotation_id"="5" "lifted.state_form"="folded" }
attributes #6 = { "lifted.annotation_id"="6" "lifted.state_form"="folded" }
attributes #7 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #13 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #18 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #19 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #20 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #21 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33}
!33 = distinct !{!33, !34, !"__extract_rsp: %state"}
!34 = distinct !{!34, !"__extract_rsp"}
!35 = !{!36}
!36 = distinct !{!36, !37, !"__store_rip: %state"}
!37 = distinct !{!37, !"__store_rip"}
!38 = !{!39}
!39 = distinct !{!39, !40, !"__store_rsp: %state"}
!40 = distinct !{!40, !"__store_rsp"}
!41 = !{!42, !42, i64 0}
!42 = !{!"omnipotent char", !43, i64 0}
!43 = !{!"Simple C++ TBAA"}
