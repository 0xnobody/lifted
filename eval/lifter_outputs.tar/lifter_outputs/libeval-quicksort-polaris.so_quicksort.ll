; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.379547 = type { %struct.X86State.379546 }
%struct.X86State.379546 = type { %struct.ArchState.379515, [32 x %union.VectorReg.379518], %struct.ArithFlags.379519, %union.anon.379514, %struct.Segments.379521, %struct.AddressSpace.379523, %struct.GPR.379524, %struct.X87Stack.379527, %struct.MMX.379531, %struct.FPUStatusFlags.379532, %union.anon.379514, %union.FPU.379541, %struct.SegmentCaches.379543, %struct.K_REG.379545 }
%struct.ArchState.379515 = type { i32, i32, %union.anon.379514 }
%union.VectorReg.379518 = type { %union.vec512_t.379517 }
%union.vec512_t.379517 = type { %struct.uint64v8_t.379516 }
%struct.uint64v8_t.379516 = type { [8 x i64] }
%struct.ArithFlags.379519 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.379521 = type { i16, %union.SegmentSelector.379520, i16, %union.SegmentSelector.379520, i16, %union.SegmentSelector.379520, i16, %union.SegmentSelector.379520, i16, %union.SegmentSelector.379520, i16, %union.SegmentSelector.379520 }
%union.SegmentSelector.379520 = type { i16 }
%struct.AddressSpace.379523 = type { i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522 }
%struct.Reg.379522 = type { %union.anon.379514 }
%struct.GPR.379524 = type { i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522, i64, %struct.Reg.379522 }
%struct.X87Stack.379527 = type { [8 x %struct.anon.3.379526] }
%struct.anon.3.379526 = type { [6 x i8], %struct.float80_t.379525 }
%struct.float80_t.379525 = type { [10 x i8] }
%struct.MMX.379531 = type { [8 x %struct.anon.4.379530] }
%struct.anon.4.379530 = type { i64, %union.vec64_t.379529 }
%union.vec64_t.379529 = type { %struct.uint64v1_t.379528 }
%struct.uint64v1_t.379528 = type { [1 x i64] }
%struct.FPUStatusFlags.379532 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.379514 = type { i64 }
%union.FPU.379541 = type { %struct.anon.13.379540 }
%struct.anon.13.379540 = type { %struct.FpuFXSAVE.379539, [96 x i8] }
%struct.FpuFXSAVE.379539 = type { %union.SegmentSelector.379520, %union.SegmentSelector.379520, %union.FPUAbridgedTagWord.379533, i8, i16, i32, %union.SegmentSelector.379520, i16, i32, %union.SegmentSelector.379520, i16, %union.FPUControlStatus.379534, %union.FPUControlStatus.379534, [8 x %struct.FPUStackElem.379536], [16 x %union.vec128_t.379538] }
%union.FPUAbridgedTagWord.379533 = type { i8 }
%union.FPUControlStatus.379534 = type { i32 }
%struct.FPUStackElem.379536 = type { %union.anon.11.379535, [6 x i8] }
%union.anon.11.379535 = type { %struct.float80_t.379525 }
%union.vec128_t.379538 = type { %struct.uint128v1_t.379537 }
%struct.uint128v1_t.379537 = type { [1 x i128] }
%struct.SegmentCaches.379543 = type { %struct.SegmentShadow.379542, %struct.SegmentShadow.379542, %struct.SegmentShadow.379542, %struct.SegmentShadow.379542, %struct.SegmentShadow.379542, %struct.SegmentShadow.379542 }
%struct.SegmentShadow.379542 = type { %union.anon.379514, i32, i32 }
%struct.K_REG.379545 = type { [8 x %struct.anon.18.379544] }
%struct.anon.18.379544 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_39d0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i122 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #16
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i122, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 192
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 192
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 192, i64 noundef %sub.i.i) #16
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 192, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 192
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 192, i64 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 192, i64 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 192, i64 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 4
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 16
  %26 = load i64, ptr %RDI, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call ptr @__remill_write_memory_64(ptr noundef %27, i64 noundef %25, i64 noundef %26) #16
  store ptr %call.i.i79, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %21
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 8
  %33 = load i32, ptr %ESI, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_32(ptr noundef %35, i64 noundef %32, i32 noundef %33) #16
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %28
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 4
  %41 = load i32, ptr %EDX, align 4
  %42 = zext i32 %41 to i64
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %43, i64 noundef %40, i32 noundef %41) #16
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %36
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 7
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = add i64 %47, 13116
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i83 = call i64 @__remill_read_memory_64(ptr noundef %49, i64 noundef %48) #16
  store i64 %call.i.i83, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 2
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RAX, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call i32 @__remill_read_memory_32(ptr noundef %54, i64 noundef %53) #16
  %conv.i.i81 = zext i32 %call.i.i80 to i64
  store i64 %conv.i.i81, ptr %RDX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %50
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 7
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %NEXT_PC, align 8
  %59 = add i64 %58, 13339
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %60, i64 noundef %59) #16
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %55
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 3
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %RAX, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %65, i64 noundef %64) #16
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %66 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %67 = and i8 %66, 1
  %conv.i.i.i32 = xor i8 %67, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %68 = trunc i32 %xor1.i.i.i.i35 to i8
  %69 = lshr i8 %68, 4
  %conv2.i.i.i36 = and i8 %69, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %61
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %74 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %74, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %75 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %75, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %73, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %70
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i32, ptr %EDX, align 4
  %80 = zext i32 %79 to i64
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %80, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %81, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RCX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %85 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %87 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %87, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %89 = and i8 %88, 1
  %conv.i.i.i = xor i8 %89, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %90 = trunc i32 %xor1.i.i.i.i to i8
  %91 = lshr i8 %90, 4
  %conv2.i.i.i = and i8 %91, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %82
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load i32, ptr %EDX, align 4
  %97 = zext i32 %96 to i64
  %98 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %95 to i32
  %sext.i = shl i64 %95, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %97, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %99 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %99, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %96, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %98, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %92
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 3
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %RCX, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %conv.i.i84 = trunc i64 %103 to i32
  %and3.i.i = and i32 1, %conv.i.i84
  %conv.i22.i85 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i85, ptr %RCX, align 8
  %cf.i.i86 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %conv.i.i.i87 = trunc i32 %and3.i.i to i8
  %105 = and i8 %conv.i.i.i87, 1
  %conv.i23.i88 = xor i8 %105, 1
  %pf.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i88, ptr %pf.i.i89, align 1
  %cmp.i.i.i90 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i90, i32 noundef %conv.i.i84, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i91 to i8
  %zf.i.i92 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i92, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i84, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i93, align 1
  %of.i.i94 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i94, align 1
  %af.i.i95 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i95, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %100
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i32, ptr %ECX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %109 to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %113 = and i8 %112, 1
  %conv.i.i.i57 = xor i8 %113, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %109, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %109, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %109, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %106
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %118 = load i8, ptr %zf.i, align 1
  store i8 %118, ptr %CL, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %114
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 2
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i8, ptr %AL, align 1
  %123 = zext i8 %122 to i64
  %124 = load i8, ptr %CL, align 1
  %125 = zext i8 %124 to i64
  %126 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %125, %123
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i96, align 1
  %127 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %128 = and i8 %127, 1
  %conv.i27.i = xor i8 %128, 1
  %pf.i.i97 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i97, align 1
  %129 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i98 = and i32 %129, 255
  %cmp.i.i.i99 = icmp eq i8 %or3.i.i, 0
  %130 = trunc i64 %123 to i32
  %conv1.i.i.i = and i32 %130, 255
  %131 = trunc i64 %125 to i32
  %conv2.i.i.i100 = and i32 %131, 255
  %call.i.i.i101 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i99, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i100, i32 noundef %conv.i.i.i98) #16
  %conv3.i.i102 = zext i1 %call.i.i.i101 to i8
  %zf.i.i103 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i102, ptr %zf.i.i103, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i100, i32 noundef %conv.i.i.i98) #16
  %conv6.i.i104 = zext i1 %call4.i.i.i to i8
  %sf.i.i105 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i104, ptr %sf.i.i105, align 1
  %of.i.i106 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i106, align 1
  %af.i.i107 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i107, align 1
  store ptr %126, ptr %MEMORY, align 8
  br label %132

132:                                              ; preds = %119
  %133 = load i64, ptr %NEXT_PC, align 8
  store i64 %133, ptr %PC, align 8
  %134 = add i64 %133, 2
  store i64 %134, ptr %NEXT_PC, align 8
  %135 = load i8, ptr %AL, align 1
  %136 = zext i8 %135 to i64
  %137 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %136
  %and3.i.i108 = trunc i64 %and3.i15.i to i8
  %cf.i.i109 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i109, align 1
  %138 = and i8 %and3.i.i108, 1
  %conv.i14.i = xor i8 %138, 1
  %pf.i.i110 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i110, align 1
  %139 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i111 = and i32 %139, 255
  %cmp.i.i.i112 = icmp eq i8 %and3.i.i108, 0
  %140 = trunc i64 %136 to i32
  %conv1.i.i.i113 = and i32 %140, 255
  %call.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i112, i32 noundef %conv1.i.i.i113, i32 noundef 1, i32 noundef %conv.i.i.i111) #16
  %conv3.i.i115 = zext i1 %call.i.i.i114 to i8
  %zf.i.i116 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i115, ptr %zf.i.i116, align 1
  %call4.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i113, i32 noundef 1, i32 noundef %conv.i.i.i111) #16
  %conv6.i.i118 = zext i1 %call4.i.i.i117 to i8
  %sf.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i118, ptr %sf.i.i119, align 1
  %of.i.i120 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i120, align 1
  %af.i.i121 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i121, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %141

141:                                              ; preds = %132
  %142 = load i64, ptr %NEXT_PC, align 8
  store i64 %142, ptr %PC, align 8
  %143 = add i64 %142, 6
  store i64 %143, ptr %NEXT_PC, align 8
  %144 = load i64, ptr %NEXT_PC, align 8
  %145 = add i64 %144, 5
  %146 = load i64, ptr %NEXT_PC, align 8
  %147 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %148 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %148, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %145, i64 %146
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %147, ptr %MEMORY, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = load ptr, ptr %MEMORY, align 8
  ret ptr %150
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_3a1b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R9 = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i368 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %conv.i.i369 = zext i32 %call.i.i368 to i64
  store i64 %conv.i.i369, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 8
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i366 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #16
  %conv.i.i367 = zext i32 %call.i.i366 to i64
  store i64 %conv.i.i367, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 16
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i373 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i373, ptr %R8, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RSP, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  store i64 %22, ptr %RDI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 4
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RDI, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %add.i.i175 = add i64 -16, %27
  store i64 %add.i.i175, ptr %RDI, align 8
  %cmp.i.i.i176 = icmp ult i64 %add.i.i175, %27
  %cmp1.i.i.i177 = icmp ult i64 %add.i.i175, -16
  %29 = or i1 %cmp.i.i.i176, %cmp1.i.i.i177
  %call.i.i.i178 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %29, i64 noundef %27, i64 noundef -16, i64 noundef %add.i.i175) #16
  %conv.i.i179 = zext i1 %call.i.i.i178 to i8
  %cf.i.i180 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i179, ptr %cf.i.i180, align 1
  %conv.i.i.i.i181 = trunc i64 %add.i.i175 to i8
  %30 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i181)
  %31 = and i8 %30, 1
  %conv.i.i.i182 = xor i8 %31, 1
  %pf.i.i.i183 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i182, ptr %pf.i.i.i183, align 1
  %xor.i.i.i.i184 = xor i64 %add.i.i175, -16
  %xor1.i.i.i.i185 = xor i64 %xor.i.i.i.i184, %27
  %32 = trunc i64 %xor1.i.i.i.i185 to i8
  %33 = lshr i8 %32, 4
  %conv2.i.i.i186 = and i8 %33, 1
  %af.i.i.i187 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i186, ptr %af.i.i.i187, align 1
  %cmp.i.i.i.i188 = icmp eq i64 %add.i.i175, 0
  %call.i.i.i.i189 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i188, i64 noundef %27, i64 noundef -16, i64 noundef %add.i.i175) #16
  %conv5.i.i.i190 = zext i1 %call.i.i.i.i189 to i8
  %zf.i.i.i191 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i190, ptr %zf.i.i.i191, align 1
  %cmp.i27.i.i.i192 = icmp slt i64 %add.i.i175, 0
  %call1.i.i.i.i193 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i192, i64 noundef %27, i64 noundef -16, i64 noundef %add.i.i175) #16
  %conv8.i.i.i194 = zext i1 %call1.i.i.i.i193 to i8
  %sf.i.i.i195 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i194, ptr %sf.i.i.i195, align 1
  %shr8.i.i.i.i196 = xor i64 %add.i.i175, %27
  %xor.i28.i.i.i197 = lshr i64 %shr8.i.i.i.i196, 63
  %xor3.i.i.i.i198 = lshr i64 %xor.i.i.i.i184, 63
  %add.i.i.i.i199 = add nuw nsw i64 %xor.i28.i.i.i197, %xor3.i.i.i.i198
  %cmp.i29.i.i.i200 = icmp eq i64 %add.i.i.i.i199, 2
  %call.i30.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i200, i64 noundef %27, i64 noundef -16, i64 noundef %add.i.i175) #16
  %conv11.i.i.i202 = zext i1 %call.i30.i.i.i201 to i8
  %of.i.i.i203 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i202, ptr %of.i.i.i203, align 1
  store ptr %28, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %24
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 4
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RBP, align 8
  %38 = sub i64 %37, 80
  %39 = load i64, ptr %RDI, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i359 = call ptr @__remill_write_memory_64(ptr noundef %40, i64 noundef %38, i64 noundef %39) #16
  store ptr %call.i.i359, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %34
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RDI, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  store i64 %44, ptr %RSP, align 8
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %41
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %RSP, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  store i64 %49, ptr %RCX, align 8
  store ptr %50, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %46
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 4
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RCX, align 8
  %55 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 -16, %54
  store i64 %add.i.i146, ptr %RCX, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %54
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, -16
  %56 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %56, i64 noundef %54, i64 noundef -16, i64 noundef %add.i.i146) #16
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %57 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %58 = and i8 %57, 1
  %conv.i.i.i153 = xor i8 %58, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, -16
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %54
  %59 = trunc i64 %xor1.i.i.i.i156 to i8
  %60 = lshr i8 %59, 4
  %conv2.i.i.i157 = and i8 %60, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %54, i64 noundef -16, i64 noundef %add.i.i146) #16
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %54, i64 noundef -16, i64 noundef %add.i.i146) #16
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %54
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %54, i64 noundef -16, i64 noundef %add.i.i146) #16
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %51
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 4
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %RBP, align 8
  %65 = sub i64 %64, 72
  %66 = load i64, ptr %RCX, align 8
  %67 = load ptr, ptr %MEMORY, align 8
  %call.i.i358 = call ptr @__remill_write_memory_64(ptr noundef %67, i64 noundef %65, i64 noundef %66) #16
  store ptr %call.i.i358, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %61
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RCX, align 8
  %72 = load ptr, ptr %MEMORY, align 8
  store i64 %71, ptr %RSP, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %68
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RSP, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  store i64 %76, ptr %RAX, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %73
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 4
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RAX, align 8
  %82 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %81
  store i64 %add.i.i117, ptr %RAX, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %81
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %83 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %83, i64 noundef %81, i64 noundef -16, i64 noundef %add.i.i117) #16
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %84 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %85 = and i8 %84, 1
  %conv.i.i.i124 = xor i8 %85, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %81
  %86 = trunc i64 %xor1.i.i.i.i127 to i8
  %87 = lshr i8 %86, 4
  %conv2.i.i.i128 = and i8 %87, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %81, i64 noundef -16, i64 noundef %add.i.i117) #16
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %81, i64 noundef -16, i64 noundef %add.i.i117) #16
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %81
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %81, i64 noundef -16, i64 noundef %add.i.i117) #16
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %82, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %78
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 4
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RBP, align 8
  %92 = sub i64 %91, 64
  %93 = load i64, ptr %RAX, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i357 = call ptr @__remill_write_memory_64(ptr noundef %94, i64 noundef %92, i64 noundef %93) #16
  store ptr %call.i.i357, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %88
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 3
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %RAX, align 8
  %99 = load ptr, ptr %MEMORY, align 8
  store i64 %98, ptr %RSP, align 8
  store ptr %99, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %95
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 3
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %RSP, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  store i64 %103, ptr %R9, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %100
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 4
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %R9, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %108
  store i64 %add.i.i88, ptr %R9, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %108
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %110 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %110, i64 noundef %108, i64 noundef -16, i64 noundef %add.i.i88) #16
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %111 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %112 = and i8 %111, 1
  %conv.i.i.i95 = xor i8 %112, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %108
  %113 = trunc i64 %xor1.i.i.i.i98 to i8
  %114 = lshr i8 %113, 4
  %conv2.i.i.i99 = and i8 %114, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %108, i64 noundef -16, i64 noundef %add.i.i88) #16
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %108, i64 noundef -16, i64 noundef %add.i.i88) #16
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %108
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %108, i64 noundef -16, i64 noundef %add.i.i88) #16
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %115

115:                                              ; preds = %105
  %116 = load i64, ptr %NEXT_PC, align 8
  store i64 %116, ptr %PC, align 8
  %117 = add i64 %116, 4
  store i64 %117, ptr %NEXT_PC, align 8
  %118 = load i64, ptr %RBP, align 8
  %119 = sub i64 %118, 56
  %120 = load i64, ptr %R9, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %call.i.i356 = call ptr @__remill_write_memory_64(ptr noundef %121, i64 noundef %119, i64 noundef %120) #16
  store ptr %call.i.i356, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %115
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 3
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load i64, ptr %R9, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  store i64 %125, ptr %RSP, align 8
  store ptr %126, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %122
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 3
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i64, ptr %RSP, align 8
  %131 = load ptr, ptr %MEMORY, align 8
  store i64 %130, ptr %R9, align 8
  store ptr %131, ptr %MEMORY, align 8
  br label %132

132:                                              ; preds = %127
  %133 = load i64, ptr %NEXT_PC, align 8
  store i64 %133, ptr %PC, align 8
  %134 = add i64 %133, 4
  store i64 %134, ptr %NEXT_PC, align 8
  %135 = load i64, ptr %R9, align 8
  %136 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %135
  store i64 %add.i.i59, ptr %R9, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %135
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %137 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %137, i64 noundef %135, i64 noundef -16, i64 noundef %add.i.i59) #16
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %138 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %139 = and i8 %138, 1
  %conv.i.i.i66 = xor i8 %139, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %135
  %140 = trunc i64 %xor1.i.i.i.i69 to i8
  %141 = lshr i8 %140, 4
  %conv2.i.i.i70 = and i8 %141, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %135, i64 noundef -16, i64 noundef %add.i.i59) #16
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %135, i64 noundef -16, i64 noundef %add.i.i59) #16
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %135
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %135, i64 noundef -16, i64 noundef %add.i.i59) #16
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %136, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %132
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 4
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RBP, align 8
  %146 = sub i64 %145, 48
  %147 = load i64, ptr %R9, align 8
  %148 = load ptr, ptr %MEMORY, align 8
  %call.i.i355 = call ptr @__remill_write_memory_64(ptr noundef %148, i64 noundef %146, i64 noundef %147) #16
  store ptr %call.i.i355, ptr %MEMORY, align 8
  br label %149

149:                                              ; preds = %142
  %150 = load i64, ptr %NEXT_PC, align 8
  store i64 %150, ptr %PC, align 8
  %151 = add i64 %150, 3
  store i64 %151, ptr %NEXT_PC, align 8
  %152 = load i64, ptr %R9, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  store i64 %152, ptr %RSP, align 8
  store ptr %153, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %149
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i64, ptr %RSP, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  store i64 %157, ptr %R9, align 8
  store ptr %158, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %154
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 4
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i64, ptr %R9, align 8
  %163 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %162
  store i64 %add.i.i30, ptr %R9, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %162
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %164 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %164, i64 noundef %162, i64 noundef -16, i64 noundef %add.i.i30) #16
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %165 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %166 = and i8 %165, 1
  %conv.i.i.i37 = xor i8 %166, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %162
  %167 = trunc i64 %xor1.i.i.i.i40 to i8
  %168 = lshr i8 %167, 4
  %conv2.i.i.i41 = and i8 %168, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %162, i64 noundef -16, i64 noundef %add.i.i30) #16
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %162, i64 noundef -16, i64 noundef %add.i.i30) #16
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %162
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %162, i64 noundef -16, i64 noundef %add.i.i30) #16
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %163, ptr %MEMORY, align 8
  br label %169

169:                                              ; preds = %159
  %170 = load i64, ptr %NEXT_PC, align 8
  store i64 %170, ptr %PC, align 8
  %171 = add i64 %170, 4
  store i64 %171, ptr %NEXT_PC, align 8
  %172 = load i64, ptr %RBP, align 8
  %173 = sub i64 %172, 40
  %174 = load i64, ptr %R9, align 8
  %175 = load ptr, ptr %MEMORY, align 8
  %call.i.i354 = call ptr @__remill_write_memory_64(ptr noundef %175, i64 noundef %173, i64 noundef %174) #16
  store ptr %call.i.i354, ptr %MEMORY, align 8
  br label %176

176:                                              ; preds = %169
  %177 = load i64, ptr %NEXT_PC, align 8
  store i64 %177, ptr %PC, align 8
  %178 = add i64 %177, 3
  store i64 %178, ptr %NEXT_PC, align 8
  %179 = load i64, ptr %R9, align 8
  %180 = load ptr, ptr %MEMORY, align 8
  store i64 %179, ptr %RSP, align 8
  store ptr %180, ptr %MEMORY, align 8
  br label %181

181:                                              ; preds = %176
  %182 = load i64, ptr %NEXT_PC, align 8
  store i64 %182, ptr %PC, align 8
  %183 = add i64 %182, 3
  store i64 %183, ptr %NEXT_PC, align 8
  %184 = load i64, ptr %RSP, align 8
  %185 = load ptr, ptr %MEMORY, align 8
  store i64 %184, ptr %R9, align 8
  store ptr %185, ptr %MEMORY, align 8
  br label %186

186:                                              ; preds = %181
  %187 = load i64, ptr %NEXT_PC, align 8
  store i64 %187, ptr %PC, align 8
  %188 = add i64 %187, 4
  store i64 %188, ptr %NEXT_PC, align 8
  %189 = load i64, ptr %R9, align 8
  %190 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %189
  store i64 %add.i.i1, ptr %R9, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %189
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %191 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %191, i64 noundef %189, i64 noundef -16, i64 noundef %add.i.i1) #16
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %192 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %193 = and i8 %192, 1
  %conv.i.i.i8 = xor i8 %193, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %189
  %194 = trunc i64 %xor1.i.i.i.i11 to i8
  %195 = lshr i8 %194, 4
  %conv2.i.i.i12 = and i8 %195, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %189, i64 noundef -16, i64 noundef %add.i.i1) #16
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %189, i64 noundef -16, i64 noundef %add.i.i1) #16
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %189
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %189, i64 noundef -16, i64 noundef %add.i.i1) #16
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %190, ptr %MEMORY, align 8
  br label %196

196:                                              ; preds = %186
  %197 = load i64, ptr %NEXT_PC, align 8
  store i64 %197, ptr %PC, align 8
  %198 = add i64 %197, 4
  store i64 %198, ptr %NEXT_PC, align 8
  %199 = load i64, ptr %RBP, align 8
  %200 = sub i64 %199, 32
  %201 = load i64, ptr %R9, align 8
  %202 = load ptr, ptr %MEMORY, align 8
  %call.i.i353 = call ptr @__remill_write_memory_64(ptr noundef %202, i64 noundef %200, i64 noundef %201) #16
  store ptr %call.i.i353, ptr %MEMORY, align 8
  br label %203

203:                                              ; preds = %196
  %204 = load i64, ptr %NEXT_PC, align 8
  store i64 %204, ptr %PC, align 8
  %205 = add i64 %204, 3
  store i64 %205, ptr %NEXT_PC, align 8
  %206 = load i64, ptr %R9, align 8
  %207 = load ptr, ptr %MEMORY, align 8
  store i64 %206, ptr %RSP, align 8
  store ptr %207, ptr %MEMORY, align 8
  br label %208

208:                                              ; preds = %203
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = add i64 %209, 3
  store i64 %210, ptr %NEXT_PC, align 8
  %211 = load i64, ptr %RDI, align 8
  %212 = load i64, ptr %R8, align 8
  %213 = load ptr, ptr %MEMORY, align 8
  %call.i.i352 = call ptr @__remill_write_memory_64(ptr noundef %213, i64 noundef %211, i64 noundef %212) #16
  store ptr %call.i.i352, ptr %MEMORY, align 8
  br label %214

214:                                              ; preds = %208
  %215 = load i64, ptr %NEXT_PC, align 8
  store i64 %215, ptr %PC, align 8
  %216 = add i64 %215, 2
  store i64 %216, ptr %NEXT_PC, align 8
  %217 = load i64, ptr %RCX, align 8
  %218 = load i32, ptr %ESI, align 4
  %219 = zext i32 %218 to i64
  %220 = load ptr, ptr %MEMORY, align 8
  %call.i.i350 = call ptr @__remill_write_memory_32(ptr noundef %220, i64 noundef %217, i32 noundef %218) #16
  store ptr %call.i.i350, ptr %MEMORY, align 8
  br label %221

221:                                              ; preds = %214
  %222 = load i64, ptr %NEXT_PC, align 8
  store i64 %222, ptr %PC, align 8
  %223 = add i64 %222, 2
  store i64 %223, ptr %NEXT_PC, align 8
  %224 = load i64, ptr %RAX, align 8
  %225 = load i32, ptr %EDX, align 4
  %226 = zext i32 %225 to i64
  %227 = load ptr, ptr %MEMORY, align 8
  %call.i.i349 = call ptr @__remill_write_memory_32(ptr noundef %227, i64 noundef %224, i32 noundef %225) #16
  store ptr %call.i.i349, ptr %MEMORY, align 8
  br label %228

228:                                              ; preds = %221
  %229 = load i64, ptr %NEXT_PC, align 8
  store i64 %229, ptr %PC, align 8
  %230 = add i64 %229, 2
  store i64 %230, ptr %NEXT_PC, align 8
  %231 = load i64, ptr %RCX, align 8
  %232 = load ptr, ptr %MEMORY, align 8
  %call.i.i364 = call i32 @__remill_read_memory_32(ptr noundef %232, i64 noundef %231) #16
  %conv.i.i365 = zext i32 %call.i.i364 to i64
  store i64 %conv.i.i365, ptr %RDX, align 8
  store ptr %232, ptr %MEMORY, align 8
  br label %233

233:                                              ; preds = %228
  %234 = load i64, ptr %NEXT_PC, align 8
  store i64 %234, ptr %PC, align 8
  %235 = add i64 %234, 2
  store i64 %235, ptr %NEXT_PC, align 8
  %236 = load i64, ptr %RAX, align 8
  %237 = load ptr, ptr %MEMORY, align 8
  %call.i.i362 = call i32 @__remill_read_memory_32(ptr noundef %237, i64 noundef %236) #16
  %conv.i.i363 = zext i32 %call.i.i362 to i64
  store i64 %conv.i.i363, ptr %RSI, align 8
  store ptr %237, ptr %MEMORY, align 8
  br label %238

238:                                              ; preds = %233
  %239 = load i64, ptr %NEXT_PC, align 8
  store i64 %239, ptr %PC, align 8
  %240 = add i64 %239, 5
  store i64 %240, ptr %NEXT_PC, align 8
  %241 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RCX, align 8
  store ptr %241, ptr %MEMORY, align 8
  br label %242

242:                                              ; preds = %238
  %243 = load i64, ptr %NEXT_PC, align 8
  store i64 %243, ptr %PC, align 8
  %244 = add i64 %243, 2
  store i64 %244, ptr %NEXT_PC, align 8
  %245 = load i64, ptr %RAX, align 8
  %246 = load i32, ptr %EAX, align 4
  %247 = zext i32 %246 to i64
  %248 = load ptr, ptr %MEMORY, align 8
  %conv.i.i417 = trunc i64 %245 to i32
  %xor3.i.i418 = xor i32 %246, %conv.i.i417
  %conv.i27.i419 = zext i32 %xor3.i.i418 to i64
  store i64 %conv.i27.i419, ptr %RAX, align 8
  %cf.i.i420 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i420, align 1
  %conv.i.i.i421 = trunc i32 %xor3.i.i418 to i8
  %249 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i421)
  %250 = and i8 %249, 1
  %conv.i28.i422 = xor i8 %250, 1
  %pf.i.i423 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i422, ptr %pf.i.i423, align 1
  %cmp.i.i.i424 = icmp eq i32 %xor3.i.i418, 0
  %call.i.i.i425 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i424, i32 noundef %conv.i.i417, i32 noundef %246, i32 noundef %xor3.i.i418) #16
  %conv3.i.i426 = zext i1 %call.i.i.i425 to i8
  %zf.i.i427 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i426, ptr %zf.i.i427, align 1
  %cmp.i19.i.i428 = icmp slt i32 %xor3.i.i418, 0
  %call1.i.i.i429 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i428, i32 noundef %conv.i.i417, i32 noundef %246, i32 noundef %xor3.i.i418) #16
  %conv6.i.i430 = zext i1 %call1.i.i.i429 to i8
  %sf.i.i431 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i430, ptr %sf.i.i431, align 1
  %of.i.i432 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i432, align 1
  %af.i.i433 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i434 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i434, ptr %af.i.i433, align 1
  store ptr %248, ptr %MEMORY, align 8
  br label %251

251:                                              ; preds = %242
  %252 = load i64, ptr %NEXT_PC, align 8
  store i64 %252, ptr %PC, align 8
  %253 = add i64 %252, 2
  store i64 %253, ptr %NEXT_PC, align 8
  %254 = load i32, ptr %EDX, align 4
  %255 = zext i32 %254 to i64
  %256 = load i32, ptr %ESI, align 4
  %257 = zext i32 %256 to i64
  %258 = load ptr, ptr %MEMORY, align 8
  %sub.i.i303 = sub i32 %254, %256
  %cmp.i.i.i304 = icmp ult i32 %254, %256
  %call.i.i.i305 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i304, i32 noundef %254, i32 noundef %256, i32 noundef %sub.i.i303) #16
  %conv.i12.i306 = zext i1 %call.i.i.i305 to i8
  %cf.i.i307 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i306, ptr %cf.i.i307, align 1
  %conv.i.i.i.i308 = trunc i32 %sub.i.i303 to i8
  %259 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i308)
  %260 = and i8 %259, 1
  %conv.i.i.i309 = xor i8 %260, 1
  %pf.i.i.i310 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i309, ptr %pf.i.i.i310, align 1
  %xor.i.i.i.i311 = xor i32 %256, %254
  %xor1.i.i.i.i312 = xor i32 %xor.i.i.i.i311, %sub.i.i303
  %261 = trunc i32 %xor1.i.i.i.i312 to i8
  %262 = lshr i8 %261, 4
  %conv2.i.i.i313 = and i8 %262, 1
  %af.i.i.i314 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i313, ptr %af.i.i.i314, align 1
  %cmp.i.i.i.i315 = icmp eq i32 %254, %256
  %call.i.i.i.i316 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i315, i32 noundef %254, i32 noundef %256, i32 noundef %sub.i.i303) #16
  %conv5.i.i.i317 = zext i1 %call.i.i.i.i316 to i8
  %zf.i.i.i318 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i317, ptr %zf.i.i.i318, align 1
  %cmp.i27.i.i.i319 = icmp slt i32 %sub.i.i303, 0
  %call1.i.i.i.i320 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i319, i32 noundef %254, i32 noundef %256, i32 noundef %sub.i.i303) #16
  %conv8.i.i.i321 = zext i1 %call1.i.i.i.i320 to i8
  %sf.i.i.i322 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i321, ptr %sf.i.i.i322, align 1
  %xor.i28.i.i.i323 = lshr i32 %xor.i.i.i.i311, 31
  %shr9.i.i.i.i324 = xor i32 %sub.i.i303, %254
  %xor3.i.i.i.i325 = lshr i32 %shr9.i.i.i.i324, 31
  %add.i.i.i.i326 = add nuw nsw i32 %xor3.i.i.i.i325, %xor.i28.i.i.i323
  %cmp.i29.i.i.i327 = icmp eq i32 %add.i.i.i.i326, 2
  %call.i30.i.i.i328 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i327, i32 noundef %254, i32 noundef %256, i32 noundef %sub.i.i303) #16
  %conv11.i.i.i329 = zext i1 %call.i30.i.i.i328 to i8
  %of.i.i.i330 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i329, ptr %of.i.i.i330, align 1
  store ptr %258, ptr %MEMORY, align 8
  br label %263

263:                                              ; preds = %251
  %264 = load i64, ptr %NEXT_PC, align 8
  store i64 %264, ptr %PC, align 8
  %265 = add i64 %264, 3
  store i64 %265, ptr %NEXT_PC, align 8
  %266 = load i32, ptr %EAX, align 4
  %267 = zext i32 %266 to i64
  %268 = load ptr, ptr %MEMORY, align 8
  %sf.i335 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %269 = load i8, ptr %sf.i335, align 1
  %tobool.i336 = icmp ne i8 %269, 0
  %of.i337 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %270 = load i8, ptr %of.i337, align 1
  %tobool4.i = icmp ne i8 %270, 0
  %cmp.i.i338 = xor i1 %tobool.i336, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i338) #17
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %267, i64 %dst.coerce.val.i
  %conv.i23.i339 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i339, ptr %RCX, align 8
  store ptr %268, ptr %MEMORY, align 8
  br label %271

271:                                              ; preds = %263
  %272 = load i64, ptr %NEXT_PC, align 8
  store i64 %272, ptr %PC, align 8
  %273 = add i64 %272, 7
  store i64 %273, ptr %NEXT_PC, align 8
  %274 = load i64, ptr %NEXT_PC, align 8
  %275 = add i64 %274, 13835
  %276 = load ptr, ptr %MEMORY, align 8
  store i64 %275, ptr %RAX, align 8
  store ptr %276, ptr %MEMORY, align 8
  br label %277

277:                                              ; preds = %271
  %278 = load i64, ptr %NEXT_PC, align 8
  store i64 %278, ptr %PC, align 8
  %279 = add i64 %278, 3
  store i64 %279, ptr %NEXT_PC, align 8
  %280 = load i32, ptr %ECX, align 4
  %281 = zext i32 %280 to i64
  %282 = load ptr, ptr %MEMORY, align 8
  %sext.i374 = shl i64 %281, 32
  %conv.i12.i375 = ashr exact i64 %sext.i374, 32
  store i64 %conv.i12.i375, ptr %RCX, align 8
  store ptr %282, ptr %MEMORY, align 8
  br label %283

283:                                              ; preds = %277
  %284 = load i64, ptr %NEXT_PC, align 8
  store i64 %284, ptr %PC, align 8
  %285 = add i64 %284, 4
  store i64 %285, ptr %NEXT_PC, align 8
  %286 = load i64, ptr %RAX, align 8
  %287 = load i64, ptr %RCX, align 8
  %288 = mul i64 %287, 8
  %289 = add i64 %286, %288
  %290 = load ptr, ptr %MEMORY, align 8
  %call.i.i372 = call i64 @__remill_read_memory_64(ptr noundef %290, i64 noundef %289) #16
  store i64 %call.i.i372, ptr %RAX, align 8
  store ptr %290, ptr %MEMORY, align 8
  br label %291

291:                                              ; preds = %283
  %292 = load i64, ptr %NEXT_PC, align 8
  store i64 %292, ptr %PC, align 8
  %293 = add i64 %292, 2
  store i64 %293, ptr %NEXT_PC, align 8
  %294 = load i64, ptr %RCX, align 8
  %295 = load i32, ptr %ECX, align 4
  %296 = zext i32 %295 to i64
  %297 = load ptr, ptr %MEMORY, align 8
  %conv.i.i400 = trunc i64 %294 to i32
  %xor3.i.i = xor i32 %295, %conv.i.i400
  %conv.i27.i401 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i401, ptr %RCX, align 8
  %cf.i.i402 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i402, align 1
  %conv.i.i.i403 = trunc i32 %xor3.i.i to i8
  %298 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i403)
  %299 = and i8 %298, 1
  %conv.i28.i404 = xor i8 %299, 1
  %pf.i.i405 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i404, ptr %pf.i.i405, align 1
  %cmp.i.i.i406 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i407 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i406, i32 noundef %conv.i.i400, i32 noundef %295, i32 noundef %xor3.i.i) #16
  %conv3.i.i408 = zext i1 %call.i.i.i407 to i8
  %zf.i.i409 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i408, ptr %zf.i.i409, align 1
  %cmp.i19.i.i410 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i411 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i410, i32 noundef %conv.i.i400, i32 noundef %295, i32 noundef %xor3.i.i) #16
  %conv6.i.i412 = zext i1 %call1.i.i.i411 to i8
  %sf.i.i413 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i412, ptr %sf.i.i413, align 1
  %of.i.i414 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i414, align 1
  %af.i.i415 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i416 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i416, ptr %af.i.i415, align 1
  store ptr %297, ptr %MEMORY, align 8
  br label %300

300:                                              ; preds = %291
  %301 = load i64, ptr %NEXT_PC, align 8
  store i64 %301, ptr %PC, align 8
  %302 = add i64 %301, 2
  store i64 %302, ptr %NEXT_PC, align 8
  %303 = load i32, ptr %EDX, align 4
  %304 = zext i32 %303 to i64
  %305 = load i32, ptr %ESI, align 4
  %306 = zext i32 %305 to i64
  %307 = load ptr, ptr %MEMORY, align 8
  %sub.i.i275 = sub i32 %303, %305
  %cmp.i.i.i276 = icmp ult i32 %303, %305
  %call.i.i.i277 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i276, i32 noundef %303, i32 noundef %305, i32 noundef %sub.i.i275) #16
  %conv.i12.i278 = zext i1 %call.i.i.i277 to i8
  %cf.i.i279 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i278, ptr %cf.i.i279, align 1
  %conv.i.i.i.i280 = trunc i32 %sub.i.i275 to i8
  %308 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i280)
  %309 = and i8 %308, 1
  %conv.i.i.i281 = xor i8 %309, 1
  %pf.i.i.i282 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i281, ptr %pf.i.i.i282, align 1
  %xor.i.i.i.i283 = xor i32 %305, %303
  %xor1.i.i.i.i284 = xor i32 %xor.i.i.i.i283, %sub.i.i275
  %310 = trunc i32 %xor1.i.i.i.i284 to i8
  %311 = lshr i8 %310, 4
  %conv2.i.i.i285 = and i8 %311, 1
  %af.i.i.i286 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i285, ptr %af.i.i.i286, align 1
  %cmp.i.i.i.i287 = icmp eq i32 %303, %305
  %call.i.i.i.i288 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i287, i32 noundef %303, i32 noundef %305, i32 noundef %sub.i.i275) #16
  %conv5.i.i.i289 = zext i1 %call.i.i.i.i288 to i8
  %zf.i.i.i290 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i289, ptr %zf.i.i.i290, align 1
  %cmp.i27.i.i.i291 = icmp slt i32 %sub.i.i275, 0
  %call1.i.i.i.i292 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i291, i32 noundef %303, i32 noundef %305, i32 noundef %sub.i.i275) #16
  %conv8.i.i.i293 = zext i1 %call1.i.i.i.i292 to i8
  %sf.i.i.i294 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i293, ptr %sf.i.i.i294, align 1
  %xor.i28.i.i.i295 = lshr i32 %xor.i.i.i.i283, 31
  %shr9.i.i.i.i296 = xor i32 %sub.i.i275, %303
  %xor3.i.i.i.i297 = lshr i32 %shr9.i.i.i.i296, 31
  %add.i.i.i.i298 = add nuw nsw i32 %xor3.i.i.i.i297, %xor.i28.i.i.i295
  %cmp.i29.i.i.i299 = icmp eq i32 %add.i.i.i.i298, 2
  %call.i30.i.i.i300 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i299, i32 noundef %303, i32 noundef %305, i32 noundef %sub.i.i275) #16
  %conv11.i.i.i301 = zext i1 %call.i30.i.i.i300 to i8
  %of.i.i.i302 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i301, ptr %of.i.i.i302, align 1
  store ptr %307, ptr %MEMORY, align 8
  br label %312

312:                                              ; preds = %300
  %313 = load i64, ptr %NEXT_PC, align 8
  store i64 %313, ptr %PC, align 8
  %314 = add i64 %313, 4
  store i64 %314, ptr %NEXT_PC, align 8
  %315 = load i64, ptr %RCX, align 8
  %316 = load ptr, ptr %MEMORY, align 8
  %sf.i340 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %317 = load i8, ptr %sf.i340, align 1
  %tobool.i341 = icmp ne i8 %317, 0
  %of.i342 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %318 = load i8, ptr %of.i342, align 1
  %tobool4.i343 = icmp ne i8 %318, 0
  %cmp.i.i344 = xor i1 %tobool.i341, %tobool4.i343
  %call5.i345 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i344) #17
  %dst.coerce.val.i346 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i345, i64 %315, i64 %dst.coerce.val.i346
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %316, ptr %MEMORY, align 8
  br label %319

319:                                              ; preds = %312
  %320 = load i64, ptr %NEXT_PC, align 8
  store i64 %320, ptr %PC, align 8
  %321 = add i64 %320, 3
  store i64 %321, ptr %NEXT_PC, align 8
  %322 = load i64, ptr %RAX, align 8
  %323 = load i64, ptr %RCX, align 8
  %324 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %322, %323
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i204 = icmp ult i64 %322, %323
  %call.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i204, i64 noundef %322, i64 noundef %323, i64 noundef %sub.i.i) #16
  %conv.i.i206 = zext i1 %call.i.i.i205 to i8
  %cf.i.i207 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i206, ptr %cf.i.i207, align 1
  %conv.i.i.i.i208 = trunc i64 %sub.i.i to i8
  %325 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i208)
  %326 = and i8 %325, 1
  %conv.i.i.i209 = xor i8 %326, 1
  %pf.i.i.i210 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i209, ptr %pf.i.i.i210, align 1
  %xor.i.i.i.i211 = xor i64 %323, %322
  %xor1.i.i.i.i212 = xor i64 %xor.i.i.i.i211, %sub.i.i
  %327 = trunc i64 %xor1.i.i.i.i212 to i8
  %328 = lshr i8 %327, 4
  %conv2.i.i.i213 = and i8 %328, 1
  %af.i.i.i214 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i213, ptr %af.i.i.i214, align 1
  %cmp.i.i.i.i215 = icmp eq i64 %322, %323
  %call.i.i.i.i216 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i215, i64 noundef %322, i64 noundef %323, i64 noundef %sub.i.i) #16
  %conv5.i.i.i217 = zext i1 %call.i.i.i.i216 to i8
  %zf.i.i.i218 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i217, ptr %zf.i.i.i218, align 1
  %cmp.i27.i.i.i219 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i220 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i219, i64 noundef %322, i64 noundef %323, i64 noundef %sub.i.i) #16
  %conv8.i.i.i221 = zext i1 %call1.i.i.i.i220 to i8
  %sf.i.i.i222 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i221, ptr %sf.i.i.i222, align 1
  %xor.i28.i.i.i223 = lshr i64 %xor.i.i.i.i211, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %322
  %xor3.i.i.i.i224 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i225 = add nuw nsw i64 %xor3.i.i.i.i224, %xor.i28.i.i.i223
  %cmp.i29.i.i.i226 = icmp eq i64 %add.i.i.i.i225, 2
  %call.i30.i.i.i227 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i226, i64 noundef %322, i64 noundef %323, i64 noundef %sub.i.i) #16
  %conv11.i.i.i228 = zext i1 %call.i30.i.i.i227 to i8
  %of.i.i.i229 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i228, ptr %of.i.i.i229, align 1
  store ptr %324, ptr %MEMORY, align 8
  br label %329

329:                                              ; preds = %319
  %330 = load i64, ptr %NEXT_PC, align 8
  store i64 %330, ptr %PC, align 8
  %331 = add i64 %330, 4
  store i64 %331, ptr %NEXT_PC, align 8
  %332 = load i64, ptr %RBP, align 8
  %333 = sub i64 %332, 24
  %334 = load i64, ptr %RAX, align 8
  %335 = load ptr, ptr %MEMORY, align 8
  %call.i.i351 = call ptr @__remill_write_memory_64(ptr noundef %335, i64 noundef %333, i64 noundef %334) #16
  store ptr %call.i.i351, ptr %MEMORY, align 8
  br label %336

336:                                              ; preds = %329
  %337 = load i64, ptr %NEXT_PC, align 8
  store i64 %337, ptr %PC, align 8
  %338 = add i64 %337, 7
  store i64 %338, ptr %NEXT_PC, align 8
  %339 = load i64, ptr %NEXT_PC, align 8
  %340 = add i64 %339, 12918
  %341 = load ptr, ptr %MEMORY, align 8
  %call.i.i371 = call i64 @__remill_read_memory_64(ptr noundef %341, i64 noundef %340) #16
  store i64 %call.i.i371, ptr %RAX, align 8
  store ptr %341, ptr %MEMORY, align 8
  br label %342

342:                                              ; preds = %336
  %343 = load i64, ptr %NEXT_PC, align 8
  store i64 %343, ptr %PC, align 8
  %344 = add i64 %343, 2
  store i64 %344, ptr %NEXT_PC, align 8
  %345 = load i64, ptr %RAX, align 8
  %346 = load ptr, ptr %MEMORY, align 8
  %call.i.i360 = call i32 @__remill_read_memory_32(ptr noundef %346, i64 noundef %345) #16
  %conv.i.i361 = zext i32 %call.i.i360 to i64
  store i64 %conv.i.i361, ptr %RDX, align 8
  store ptr %346, ptr %MEMORY, align 8
  br label %347

347:                                              ; preds = %342
  %348 = load i64, ptr %NEXT_PC, align 8
  store i64 %348, ptr %PC, align 8
  %349 = add i64 %348, 7
  store i64 %349, ptr %NEXT_PC, align 8
  %350 = load i64, ptr %NEXT_PC, align 8
  %351 = add i64 %350, 13109
  %352 = load ptr, ptr %MEMORY, align 8
  %call.i.i370 = call i64 @__remill_read_memory_64(ptr noundef %352, i64 noundef %351) #16
  store i64 %call.i.i370, ptr %RAX, align 8
  store ptr %352, ptr %MEMORY, align 8
  br label %353

353:                                              ; preds = %347
  %354 = load i64, ptr %NEXT_PC, align 8
  store i64 %354, ptr %PC, align 8
  %355 = add i64 %354, 3
  store i64 %355, ptr %NEXT_PC, align 8
  %356 = load i64, ptr %RAX, align 8
  %357 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %357, i64 noundef %356) #16
  %sub.i.i230 = sub i32 %call.i.i, 10
  %cmp.i.i.i231 = icmp ult i32 %call.i.i, 10
  %call.i.i.i232 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i231, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #16
  %conv.i9.i = zext i1 %call.i.i.i232 to i8
  %cf.i.i233 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i233, align 1
  %conv.i.i.i.i234 = trunc i32 %sub.i.i230 to i8
  %358 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i234)
  %359 = and i8 %358, 1
  %conv.i.i.i235 = xor i8 %359, 1
  %pf.i.i.i236 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i235, ptr %pf.i.i.i236, align 1
  %xor.i.i.i.i237 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i238 = xor i32 %xor.i.i.i.i237, %sub.i.i230
  %360 = trunc i32 %xor1.i.i.i.i238 to i8
  %361 = lshr i8 %360, 4
  %conv2.i.i.i239 = and i8 %361, 1
  %af.i.i.i240 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i239, ptr %af.i.i.i240, align 1
  %cmp.i.i.i.i241 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i242 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i241, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #16
  %conv5.i.i.i243 = zext i1 %call.i.i.i.i242 to i8
  %zf.i.i.i244 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i243, ptr %zf.i.i.i244, align 1
  %cmp.i27.i.i.i245 = icmp slt i32 %sub.i.i230, 0
  %call1.i.i.i.i246 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i245, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #16
  %conv8.i.i.i247 = zext i1 %call1.i.i.i.i246 to i8
  %sf.i.i.i248 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i247, ptr %sf.i.i.i248, align 1
  %xor.i28.i.i.i249 = lshr i32 %xor.i.i.i.i237, 31
  %shr9.i.i.i.i250 = xor i32 %sub.i.i230, %call.i.i
  %xor3.i.i.i.i251 = lshr i32 %shr9.i.i.i.i250, 31
  %add.i.i.i.i252 = add nuw nsw i32 %xor3.i.i.i.i251, %xor.i28.i.i.i249
  %cmp.i29.i.i.i253 = icmp eq i32 %add.i.i.i.i252, 2
  %call.i30.i.i.i254 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i253, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #16
  %conv11.i.i.i255 = zext i1 %call.i30.i.i.i254 to i8
  %of.i.i.i256 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i255, ptr %of.i.i.i256, align 1
  store ptr %357, ptr %MEMORY, align 8
  br label %362

362:                                              ; preds = %353
  %363 = load i64, ptr %NEXT_PC, align 8
  store i64 %363, ptr %PC, align 8
  %364 = add i64 %363, 3
  store i64 %364, ptr %NEXT_PC, align 8
  %365 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %366 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %366, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %367 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %367, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %365, ptr %MEMORY, align 8
  br label %368

368:                                              ; preds = %362
  %369 = load i64, ptr %NEXT_PC, align 8
  store i64 %369, ptr %PC, align 8
  %370 = add i64 %369, 2
  store i64 %370, ptr %NEXT_PC, align 8
  %371 = load i32, ptr %EDX, align 4
  %372 = zext i32 %371 to i64
  %373 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %372, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %373, ptr %MEMORY, align 8
  br label %374

374:                                              ; preds = %368
  %375 = load i64, ptr %NEXT_PC, align 8
  store i64 %375, ptr %PC, align 8
  %376 = add i64 %375, 3
  store i64 %376, ptr %NEXT_PC, align 8
  %377 = load i64, ptr %RCX, align 8
  %378 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %377 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %379 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %379, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %380 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %381 = and i8 %380, 1
  %conv.i.i.i = xor i8 %381, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %382 = trunc i32 %xor1.i.i.i.i to i8
  %383 = lshr i8 %382, 4
  %conv2.i.i.i = and i8 %383, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %378, ptr %MEMORY, align 8
  br label %384

384:                                              ; preds = %374
  %385 = load i64, ptr %NEXT_PC, align 8
  store i64 %385, ptr %PC, align 8
  %386 = add i64 %385, 3
  store i64 %386, ptr %NEXT_PC, align 8
  %387 = load i64, ptr %RCX, align 8
  %388 = load i32, ptr %EDX, align 4
  %389 = zext i32 %388 to i64
  %390 = load ptr, ptr %MEMORY, align 8
  %conv.i.i331 = trunc i64 %387 to i32
  %sext.i = shl i64 %387, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %389, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %391 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i332 = icmp ult i64 %391, -4294967296
  %call.i.i.i333 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i332, i32 noundef %conv.i.i331, i32 noundef %388, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i333 to i8
  %cf.i.i334 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i334, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %390, ptr %MEMORY, align 8
  br label %392

392:                                              ; preds = %384
  %393 = load i64, ptr %NEXT_PC, align 8
  store i64 %393, ptr %PC, align 8
  %394 = add i64 %393, 3
  store i64 %394, ptr %NEXT_PC, align 8
  %395 = load i64, ptr %RCX, align 8
  %396 = load ptr, ptr %MEMORY, align 8
  %conv.i.i376 = trunc i64 %395 to i32
  %and3.i.i = and i32 1, %conv.i.i376
  %conv.i22.i377 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i377, ptr %RCX, align 8
  %cf.i.i378 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i378, align 1
  %conv.i.i.i379 = trunc i32 %and3.i.i to i8
  %397 = and i8 %conv.i.i.i379, 1
  %conv.i23.i380 = xor i8 %397, 1
  %pf.i.i381 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i380, ptr %pf.i.i381, align 1
  %cmp.i.i.i382 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i383 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i382, i32 noundef %conv.i.i376, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i383 to i8
  %zf.i.i384 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i384, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i376, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i385 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i385, align 1
  %of.i.i386 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i386, align 1
  %af.i.i387 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i387, align 1
  store ptr %396, ptr %MEMORY, align 8
  br label %398

398:                                              ; preds = %392
  %399 = load i64, ptr %NEXT_PC, align 8
  store i64 %399, ptr %PC, align 8
  %400 = add i64 %399, 3
  store i64 %400, ptr %NEXT_PC, align 8
  %401 = load i32, ptr %ECX, align 4
  %402 = zext i32 %401 to i64
  %403 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i257 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %401, i32 noundef 0, i32 noundef %401) #16
  %conv.i12.i = zext i1 %call.i.i.i257 to i8
  %cf.i.i258 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i258, align 1
  %conv.i.i.i.i259 = trunc i32 %401 to i8
  %404 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i259)
  %405 = and i8 %404, 1
  %conv.i.i.i260 = xor i8 %405, 1
  %pf.i.i.i261 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i260, ptr %pf.i.i.i261, align 1
  %af.i.i.i262 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i262, align 1
  %cmp.i.i.i.i263 = icmp eq i32 %401, 0
  %call.i.i.i.i264 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i263, i32 noundef %401, i32 noundef 0, i32 noundef %401) #16
  %conv5.i.i.i265 = zext i1 %call.i.i.i.i264 to i8
  %zf.i.i.i266 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i265, ptr %zf.i.i.i266, align 1
  %cmp.i27.i.i.i267 = icmp slt i32 %401, 0
  %call1.i.i.i.i268 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i267, i32 noundef %401, i32 noundef 0, i32 noundef %401) #16
  %conv8.i.i.i269 = zext i1 %call1.i.i.i.i268 to i8
  %sf.i.i.i270 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i269, ptr %sf.i.i.i270, align 1
  %xor.i28.i.i.i271 = lshr i32 %401, 31
  %call.i30.i.i.i272 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %401, i32 noundef 0, i32 noundef %401) #16
  %conv11.i.i.i273 = zext i1 %call.i30.i.i.i272 to i8
  %of.i.i.i274 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i273, ptr %of.i.i.i274, align 1
  store ptr %403, ptr %MEMORY, align 8
  br label %406

406:                                              ; preds = %398
  %407 = load i64, ptr %NEXT_PC, align 8
  store i64 %407, ptr %PC, align 8
  %408 = add i64 %407, 3
  store i64 %408, ptr %NEXT_PC, align 8
  %409 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %410 = load i8, ptr %zf.i, align 1
  store i8 %410, ptr %CL, align 1
  store ptr %409, ptr %MEMORY, align 8
  br label %411

411:                                              ; preds = %406
  %412 = load i64, ptr %NEXT_PC, align 8
  store i64 %412, ptr %PC, align 8
  %413 = add i64 %412, 2
  store i64 %413, ptr %NEXT_PC, align 8
  %414 = load i8, ptr %AL, align 1
  %415 = zext i8 %414 to i64
  %416 = load i8, ptr %CL, align 1
  %417 = zext i8 %416 to i64
  %418 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %417, %415
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i388 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i388, align 1
  %419 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %420 = and i8 %419, 1
  %conv.i27.i = xor i8 %420, 1
  %pf.i.i389 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i389, align 1
  %421 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i390 = and i32 %421, 255
  %cmp.i.i.i391 = icmp eq i8 %or3.i.i, 0
  %422 = trunc i64 %415 to i32
  %conv1.i.i.i = and i32 %422, 255
  %423 = trunc i64 %417 to i32
  %conv2.i.i.i392 = and i32 %423, 255
  %call.i.i.i393 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i391, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i392, i32 noundef %conv.i.i.i390) #16
  %conv3.i.i394 = zext i1 %call.i.i.i393 to i8
  %zf.i.i395 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i394, ptr %zf.i.i395, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i392, i32 noundef %conv.i.i.i390) #16
  %conv6.i.i396 = zext i1 %call4.i.i.i to i8
  %sf.i.i397 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i396, ptr %sf.i.i397, align 1
  %of.i.i398 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i398, align 1
  %af.i.i399 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i399, align 1
  store ptr %418, ptr %MEMORY, align 8
  br label %424

424:                                              ; preds = %411
  %425 = load i64, ptr %NEXT_PC, align 8
  store i64 %425, ptr %PC, align 8
  %426 = add i64 %425, 2
  store i64 %426, ptr %NEXT_PC, align 8
  %427 = load i8, ptr %AL, align 1
  %428 = zext i8 %427 to i64
  %429 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %428
  %and3.i.i435 = trunc i64 %and3.i15.i to i8
  %cf.i.i436 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i436, align 1
  %430 = and i8 %and3.i.i435, 1
  %conv.i14.i = xor i8 %430, 1
  %pf.i.i437 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i437, align 1
  %431 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i438 = and i32 %431, 255
  %cmp.i.i.i439 = icmp eq i8 %and3.i.i435, 0
  %432 = trunc i64 %428 to i32
  %conv1.i.i.i440 = and i32 %432, 255
  %call.i.i.i441 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i439, i32 noundef %conv1.i.i.i440, i32 noundef 1, i32 noundef %conv.i.i.i438) #16
  %conv3.i.i442 = zext i1 %call.i.i.i441 to i8
  %zf.i.i443 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i442, ptr %zf.i.i443, align 1
  %call4.i.i.i444 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i440, i32 noundef 1, i32 noundef %conv.i.i.i438) #16
  %conv6.i.i445 = zext i1 %call4.i.i.i444 to i8
  %sf.i.i446 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i445, ptr %sf.i.i446, align 1
  %of.i.i447 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i447, align 1
  %af.i.i448 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i448, align 1
  store ptr %429, ptr %MEMORY, align 8
  br label %433

433:                                              ; preds = %424
  %434 = load i64, ptr %NEXT_PC, align 8
  store i64 %434, ptr %PC, align 8
  %435 = add i64 %434, 6
  store i64 %435, ptr %NEXT_PC, align 8
  %436 = load i64, ptr %NEXT_PC, align 8
  %437 = add i64 %436, 5
  %438 = load i64, ptr %NEXT_PC, align 8
  %439 = load ptr, ptr %MEMORY, align 8
  %zf.i347 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %440 = load i8, ptr %zf.i347, align 1
  %tobool.not.i = icmp eq i8 %440, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i348 = select i1 %call9.i, i64 %437, i64 %438
  store i64 %cond1.i.i348, ptr %NEXT_PC, align 8
  store ptr %439, ptr %MEMORY, align 8
  %441 = load i64, ptr %NEXT_PC, align 8
  store i64 %441, ptr %PC, align 8
  %442 = load ptr, ptr %MEMORY, align 8
  ret ptr %442
}

define ptr @BB_3af1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_3af7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12850
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 13081
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_42bd(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11292
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11491
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3b2d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i87 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i87, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 64
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i86 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i86, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 32
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i85 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i85, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 72
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i84 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #16
  store i64 %call.i.i84, ptr %RSI, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 4
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 56
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i83 = call i64 @__remill_read_memory_64(ptr noundef %30, i64 noundef %29) #16
  store i64 %call.i.i83, ptr %RDI, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %25
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 3
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %RSI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call i32 @__remill_read_memory_32(ptr noundef %35, i64 noundef %34) #16
  %conv.i.i79 = zext i32 %call.i.i78 to i64
  store i64 %conv.i.i79, ptr %R8, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %31
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RDI, align 8
  %40 = load i32, ptr %R8D, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call ptr @__remill_write_memory_32(ptr noundef %42, i64 noundef %39, i32 noundef %40) #16
  store ptr %call.i.i70, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %36
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 2
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RSI, align 8
  %47 = load ptr, ptr %MEMORY, align 8
  %call.i.i76 = call i32 @__remill_read_memory_32(ptr noundef %47, i64 noundef %46) #16
  %conv.i.i77 = zext i32 %call.i.i76 to i64
  store i64 %conv.i.i77, ptr %RSI, align 8
  store ptr %47, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %43
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 2
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RDX, align 8
  %52 = load i32, ptr %ESI, align 4
  %53 = zext i32 %52 to i64
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_32(ptr noundef %54, i64 noundef %51, i32 noundef %52) #16
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %48
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RCX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #16
  %conv.i.i75 = zext i32 %call.i.i74 to i64
  store i64 %conv.i.i75, ptr %RCX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 2
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RAX, align 8
  %64 = load i32, ptr %ECX, align 4
  %65 = zext i32 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_32(ptr noundef %66, i64 noundef %63, i32 noundef %64) #16
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %60
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 7
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %NEXT_PC, align 8
  %71 = add i64 %70, 13674
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %72, i64 noundef %71) #16
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 4
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  store i64 %76, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %76, i64 noundef 0, i64 noundef %76) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %76 to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %79 = and i8 %78, 1
  %conv.i.i.i5 = xor i8 %79, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %76, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %76, i64 noundef 0, i64 noundef %76) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %76, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %76, i64 noundef 0, i64 noundef %76) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %76, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %76, i64 noundef 0, i64 noundef %76) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %73
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 4
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RBP, align 8
  %84 = sub i64 %83, 88
  %85 = load i64, ptr %RAX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call ptr @__remill_write_memory_64(ptr noundef %86, i64 noundef %84, i64 noundef %85) #16
  store ptr %call.i.i71, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %80
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 7
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %NEXT_PC, align 8
  %91 = add i64 %90, 12723
  %92 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %92, i64 noundef %91) #16
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %92, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %87
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 2
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i32 @__remill_read_memory_32(ptr noundef %97, i64 noundef %96) #16
  %conv.i.i73 = zext i32 %call.i.i72 to i64
  store i64 %conv.i.i73, ptr %RDX, align 8
  store ptr %97, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %93
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 7
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 12970
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call i64 @__remill_read_memory_64(ptr noundef %103, i64 noundef %102) #16
  store i64 %call.i.i80, ptr %RAX, align 8
  store ptr %103, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %98
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 3
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i64, ptr %RAX, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %108, i64 noundef %107) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %109 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %110 = and i8 %109, 1
  %conv.i.i.i24 = xor i8 %110, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %111 = trunc i32 %xor1.i.i.i.i27 to i8
  %112 = lshr i8 %111, 4
  %conv2.i.i.i28 = and i8 %112, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %108, ptr %MEMORY, align 8
  br label %113

113:                                              ; preds = %104
  %114 = load i64, ptr %NEXT_PC, align 8
  store i64 %114, ptr %PC, align 8
  %115 = add i64 %114, 3
  store i64 %115, ptr %NEXT_PC, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %117 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %117, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %118 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %118, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %113
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 2
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i32, ptr %EDX, align 4
  %123 = zext i32 %122 to i64
  %124 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %123, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %124, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %119
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 3
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i64, ptr %RCX, align 8
  %129 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %128 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %130 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %130, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %131 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %132 = and i8 %131, 1
  %conv.i.i.i = xor i8 %132, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %133 = trunc i32 %xor1.i.i.i.i to i8
  %134 = lshr i8 %133, 4
  %conv2.i.i.i = and i8 %134, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %135

135:                                              ; preds = %125
  %136 = load i64, ptr %NEXT_PC, align 8
  store i64 %136, ptr %PC, align 8
  %137 = add i64 %136, 3
  store i64 %137, ptr %NEXT_PC, align 8
  %138 = load i64, ptr %RCX, align 8
  %139 = load i32, ptr %EDX, align 4
  %140 = zext i32 %139 to i64
  %141 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %138 to i32
  %sext.i = shl i64 %138, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %140, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %142 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %142, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %139, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %141, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %135
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 3
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %RCX, align 8
  %147 = load ptr, ptr %MEMORY, align 8
  %conv.i.i88 = trunc i64 %146 to i32
  %and3.i.i = and i32 1, %conv.i.i88
  %conv.i22.i89 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i89, ptr %RCX, align 8
  %cf.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i90, align 1
  %conv.i.i.i91 = trunc i32 %and3.i.i to i8
  %148 = and i8 %conv.i.i.i91, 1
  %conv.i23.i92 = xor i8 %148, 1
  %pf.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i92, ptr %pf.i.i93, align 1
  %cmp.i.i.i94 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i88, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i95 to i8
  %zf.i.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i96, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i88, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i97 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i97, align 1
  %of.i.i98 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i98, align 1
  %af.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i99, align 1
  store ptr %147, ptr %MEMORY, align 8
  br label %149

149:                                              ; preds = %143
  %150 = load i64, ptr %NEXT_PC, align 8
  store i64 %150, ptr %PC, align 8
  %151 = add i64 %150, 3
  store i64 %151, ptr %NEXT_PC, align 8
  %152 = load i32, ptr %ECX, align 4
  %153 = zext i32 %152 to i64
  %154 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %152, i32 noundef 0, i32 noundef %152) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %152 to i8
  %155 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %156 = and i8 %155, 1
  %conv.i.i.i48 = xor i8 %156, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %152, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %152, i32 noundef 0, i32 noundef %152) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %152, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %152, i32 noundef 0, i32 noundef %152) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %152, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %152, i32 noundef 0, i32 noundef %152) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %154, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %149
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 3
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %161 = load i8, ptr %zf.i, align 1
  store i8 %161, ptr %CL, align 1
  store ptr %160, ptr %MEMORY, align 8
  br label %162

162:                                              ; preds = %157
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = add i64 %163, 2
  store i64 %164, ptr %NEXT_PC, align 8
  %165 = load i8, ptr %AL, align 1
  %166 = zext i8 %165 to i64
  %167 = load i8, ptr %CL, align 1
  %168 = zext i8 %167 to i64
  %169 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %168, %166
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i100 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i100, align 1
  %170 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %171 = and i8 %170, 1
  %conv.i27.i = xor i8 %171, 1
  %pf.i.i101 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i101, align 1
  %172 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i102 = and i32 %172, 255
  %cmp.i.i.i103 = icmp eq i8 %or3.i.i, 0
  %173 = trunc i64 %166 to i32
  %conv1.i.i.i = and i32 %173, 255
  %174 = trunc i64 %168 to i32
  %conv2.i.i.i104 = and i32 %174, 255
  %call.i.i.i105 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i103, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i104, i32 noundef %conv.i.i.i102) #16
  %conv3.i.i106 = zext i1 %call.i.i.i105 to i8
  %zf.i.i107 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i106, ptr %zf.i.i107, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i104, i32 noundef %conv.i.i.i102) #16
  %conv6.i.i108 = zext i1 %call4.i.i.i to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i111, align 1
  store ptr %169, ptr %MEMORY, align 8
  br label %175

175:                                              ; preds = %162
  %176 = load i64, ptr %NEXT_PC, align 8
  store i64 %176, ptr %PC, align 8
  %177 = add i64 %176, 2
  store i64 %177, ptr %NEXT_PC, align 8
  %178 = load i8, ptr %AL, align 1
  %179 = zext i8 %178 to i64
  %180 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %179
  %and3.i.i112 = trunc i64 %and3.i15.i to i8
  %cf.i.i113 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i113, align 1
  %181 = and i8 %and3.i.i112, 1
  %conv.i14.i = xor i8 %181, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i114, align 1
  %182 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i115 = and i32 %182, 255
  %cmp.i.i.i116 = icmp eq i8 %and3.i.i112, 0
  %183 = trunc i64 %179 to i32
  %conv1.i.i.i117 = and i32 %183, 255
  %call.i.i.i118 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i116, i32 noundef %conv1.i.i.i117, i32 noundef 1, i32 noundef %conv.i.i.i115) #16
  %conv3.i.i119 = zext i1 %call.i.i.i118 to i8
  %zf.i.i120 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i119, ptr %zf.i.i120, align 1
  %call4.i.i.i121 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i117, i32 noundef 1, i32 noundef %conv.i.i.i115) #16
  %conv6.i.i122 = zext i1 %call4.i.i.i121 to i8
  %sf.i.i123 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i122, ptr %sf.i.i123, align 1
  %of.i.i124 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i124, align 1
  %af.i.i125 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i125, align 1
  store ptr %180, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %175
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 6
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i64, ptr %NEXT_PC, align 8
  %188 = add i64 %187, 5
  %189 = load i64, ptr %NEXT_PC, align 8
  %190 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %191 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %191, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %188, i64 %189
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %190, ptr %MEMORY, align 8
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = load ptr, ptr %MEMORY, align 8
  ret ptr %193
}

define ptr @BB_42f3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11150
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11093
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3b94(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 88
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_4329(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  store i64 %4, ptr %RSP, align 8
  store ptr %5, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i1 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i1, align 8
  %add.i.i2 = add i64 %10, 8
  store i64 %add.i.i2, ptr %rsp.i1, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #16
  store i64 %call.i.i3, ptr %RBP, align 8
  store ptr %9, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %6
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 1
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %15 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %14, i64 noundef %15) #16
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %16, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %14, ptr %MEMORY, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  ret ptr %17
}

define ptr @BB_3b9a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i36, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i35, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #16
  %conv.i.i33 = zext i32 %call.i.i32 to i64
  store i64 %conv.i.i33, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RCX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %conv.i.i31 = zext i32 %call.i.i to i64
  store i64 %conv.i.i31, ptr %RCX, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 2
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RAX, align 8
  %27 = load i32, ptr %ECX, align 4
  %28 = zext i32 %27 to i64
  %29 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %26 to i32
  %sub.i.i2 = sub i32 %conv.i.i1, %27
  %conv.i22.i3 = zext i32 %sub.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RAX, align 8
  %cmp.i.i.i4 = icmp ult i32 %conv.i.i1, %27
  %call.i.i.i5 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i4, i32 noundef %conv.i.i1, i32 noundef %27, i32 noundef %sub.i.i2) #16
  %conv.i23.i6 = zext i1 %call.i.i.i5 to i8
  %cf.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i6, ptr %cf.i.i7, align 1
  %conv.i.i.i.i8 = trunc i32 %sub.i.i2 to i8
  %30 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i8)
  %31 = and i8 %30, 1
  %conv.i.i.i9 = xor i8 %31, 1
  %pf.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i9, ptr %pf.i.i.i10, align 1
  %xor.i.i.i.i11 = xor i32 %27, %conv.i.i1
  %xor1.i.i.i.i12 = xor i32 %xor.i.i.i.i11, %sub.i.i2
  %32 = trunc i32 %xor1.i.i.i.i12 to i8
  %33 = lshr i8 %32, 4
  %conv2.i.i.i13 = and i8 %33, 1
  %af.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i13, ptr %af.i.i.i14, align 1
  %cmp.i.i.i.i15 = icmp eq i32 %conv.i.i1, %27
  %call.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i15, i32 noundef %conv.i.i1, i32 noundef %27, i32 noundef %sub.i.i2) #16
  %conv5.i.i.i17 = zext i1 %call.i.i.i.i16 to i8
  %zf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i17, ptr %zf.i.i.i18, align 1
  %cmp.i27.i.i.i19 = icmp slt i32 %sub.i.i2, 0
  %call1.i.i.i.i20 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i19, i32 noundef %conv.i.i1, i32 noundef %27, i32 noundef %sub.i.i2) #16
  %conv8.i.i.i21 = zext i1 %call1.i.i.i.i20 to i8
  %sf.i.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i21, ptr %sf.i.i.i22, align 1
  %xor.i28.i.i.i23 = lshr i32 %xor.i.i.i.i11, 31
  %shr9.i.i.i.i24 = xor i32 %sub.i.i2, %conv.i.i1
  %xor3.i.i.i.i25 = lshr i32 %shr9.i.i.i.i24, 31
  %add.i.i.i.i26 = add nuw nsw i32 %xor3.i.i.i.i25, %xor.i28.i.i.i23
  %cmp.i29.i.i.i27 = icmp eq i32 %add.i.i.i.i26, 2
  %call.i30.i.i.i28 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i27, i32 noundef %conv.i.i1, i32 noundef %27, i32 noundef %sub.i.i2) #16
  %conv11.i.i.i29 = zext i1 %call.i30.i.i.i28 to i8
  %of.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i29, ptr %of.i.i.i30, align 1
  store ptr %29, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %23
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 3
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %38 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %38, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %39 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %39, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %37, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %34
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i8, ptr %AL, align 1
  %44 = zext i8 %43 to i64
  %45 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i37 = and i64 %44, 255
  store i64 %conv.i11.i37, ptr %RCX, align 8
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %40
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 5
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  store i64 4, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %46
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 2
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RAX, align 8
  %54 = load i32, ptr %ECX, align 4
  %55 = zext i32 %54 to i64
  %56 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %53 to i32
  %sub.i.i = sub i32 %conv.i.i, %54
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %conv.i.i, %54
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef %54, i32 noundef %sub.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %57 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %58 = and i8 %57, 1
  %conv.i.i.i = xor i8 %58, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %54, %conv.i.i
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %59 = trunc i32 %xor1.i.i.i.i to i8
  %60 = lshr i8 %59, 4
  %conv2.i.i.i = and i8 %60, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %conv.i.i, %54
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %54, i32 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %54, i32 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %54, i32 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %56, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %50
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 2
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i32, ptr %EAX, align 4
  %65 = zext i32 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %65, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %61
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 7
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %NEXT_PC, align 8
  %71 = add i64 %70, 13554
  %72 = load ptr, ptr %MEMORY, align 8
  store i64 %71, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 4
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load i64, ptr %RCX, align 8
  %78 = mul i64 %77, 8
  %79 = add i64 %76, %78
  %80 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i64 @__remill_read_memory_64(ptr noundef %80, i64 noundef %79) #16
  store i64 %call.i.i34, ptr %RAX, align 8
  store ptr %80, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %73
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RAX, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %84, ptr %rip.i, align 8
  store i64 %84, ptr %NEXT_PC, align 8
  store ptr %85, ptr %MEMORY, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  ret ptr %86
}

define ptr @BB_3bc4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12629
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12820
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_41b7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11546
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11809
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3bfa(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 13527
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 96
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #16
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 13072
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #16
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #16
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 12695
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #16
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #16
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #16
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #16
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #16
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_41ed(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %R8D = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %R9D = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %R9 = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i53 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i53, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 80
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i52, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 72
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i51, ptr %RCX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 40
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #16
  store i64 %call.i.i50, ptr %RSI, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 4
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 56
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i64 @__remill_read_memory_64(ptr noundef %30, i64 noundef %29) #16
  store i64 %call.i.i49, ptr %R8, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %25
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 3
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %RDX, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i48 = call i64 @__remill_read_memory_64(ptr noundef %35, i64 noundef %34) #16
  store i64 %call.i.i48, ptr %RDI, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %31
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %R8, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i60 = call i32 @__remill_read_memory_32(ptr noundef %40, i64 noundef %39) #16
  %conv.i.i61 = sext i32 %call.i.i60 to i64
  store i64 %conv.i.i61, ptr %R9, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %36
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 4
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RDI, align 8
  %45 = load i64, ptr %R9, align 8
  %46 = mul i64 %45, 4
  %47 = add i64 %44, %46
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i41 = call i32 @__remill_read_memory_32(ptr noundef %48, i64 noundef %47) #16
  %conv.i.i42 = zext i32 %call.i.i41 to i64
  store i64 %conv.i.i42, ptr %RDI, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %41
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 2
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RSI, align 8
  %53 = load i32, ptr %EDI, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call ptr @__remill_write_memory_32(ptr noundef %55, i64 noundef %52, i32 noundef %53) #16
  store ptr %call.i.i32, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %49
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 3
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RDX, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i47 = call i64 @__remill_read_memory_64(ptr noundef %60, i64 noundef %59) #16
  store i64 %call.i.i47, ptr %RDI, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %56
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 3
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %RAX, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i58 = call i32 @__remill_read_memory_32(ptr noundef %65, i64 noundef %64) #16
  %conv.i.i59 = sext i32 %call.i.i58 to i64
  store i64 %conv.i.i59, ptr %R9, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %61
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 4
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RDI, align 8
  %70 = load i64, ptr %R9, align 8
  %71 = mul i64 %70, 4
  %72 = add i64 %69, %71
  %73 = load ptr, ptr %MEMORY, align 8
  %call.i.i39 = call i32 @__remill_read_memory_32(ptr noundef %73, i64 noundef %72) #16
  %conv.i.i40 = zext i32 %call.i.i39 to i64
  store i64 %conv.i.i40, ptr %R9, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %66
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RDX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %call.i.i46 = call i64 @__remill_read_memory_64(ptr noundef %78, i64 noundef %77) #16
  store i64 %call.i.i46, ptr %RDI, align 8
  store ptr %78, ptr %MEMORY, align 8
  br label %79

79:                                               ; preds = %74
  %80 = load i64, ptr %NEXT_PC, align 8
  store i64 %80, ptr %PC, align 8
  %81 = add i64 %80, 3
  store i64 %81, ptr %NEXT_PC, align 8
  %82 = load i64, ptr %R8, align 8
  %83 = load ptr, ptr %MEMORY, align 8
  %call.i.i56 = call i32 @__remill_read_memory_32(ptr noundef %83, i64 noundef %82) #16
  %conv.i.i57 = sext i32 %call.i.i56 to i64
  store i64 %conv.i.i57, ptr %R8, align 8
  store ptr %83, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %79
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 4
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RDI, align 8
  %88 = load i64, ptr %R8, align 8
  %89 = mul i64 %88, 4
  %90 = add i64 %87, %89
  %91 = load i32, ptr %R9D, align 4
  %92 = zext i32 %91 to i64
  %93 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call ptr @__remill_write_memory_32(ptr noundef %93, i64 noundef %90, i32 noundef %91) #16
  store ptr %call.i.i31, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %84
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i64, ptr %RSI, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  %call.i.i37 = call i32 @__remill_read_memory_32(ptr noundef %98, i64 noundef %97) #16
  %conv.i.i38 = zext i32 %call.i.i37 to i64
  store i64 %conv.i.i38, ptr %R8, align 8
  store ptr %98, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %94
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RDX, align 8
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i45 = call i64 @__remill_read_memory_64(ptr noundef %103, i64 noundef %102) #16
  store i64 %call.i.i45, ptr %RSI, align 8
  store ptr %103, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %99
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 3
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i64, ptr %RAX, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i32 @__remill_read_memory_32(ptr noundef %108, i64 noundef %107) #16
  %conv.i.i55 = sext i32 %call.i.i54 to i64
  store i64 %conv.i.i55, ptr %RDI, align 8
  store ptr %108, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %104
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 4
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RSI, align 8
  %113 = load i64, ptr %RDI, align 8
  %114 = mul i64 %113, 4
  %115 = add i64 %112, %114
  %116 = load i32, ptr %R8D, align 4
  %117 = zext i32 %116 to i64
  %118 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_32(ptr noundef %118, i64 noundef %115, i32 noundef %116) #16
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %109
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RDX, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %call.i.i44 = call i64 @__remill_read_memory_64(ptr noundef %123, i64 noundef %122) #16
  store i64 %call.i.i44, ptr %RDI, align 8
  store ptr %123, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RCX, align 8
  %128 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i32 @__remill_read_memory_32(ptr noundef %128, i64 noundef %127) #16
  %conv.i.i36 = zext i32 %call.i.i35 to i64
  store i64 %conv.i.i36, ptr %RSI, align 8
  store ptr %128, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %124
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 2
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %RAX, align 8
  %133 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i32 @__remill_read_memory_32(ptr noundef %133, i64 noundef %132) #16
  %conv.i.i34 = zext i32 %call.i.i33 to i64
  store i64 %conv.i.i34, ptr %RDX, align 8
  store ptr %133, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %129
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 3
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RDX, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %137 to i32
  %sub.i.i = sub i32 %conv.i.i, 1
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RDX, align 8
  %cmp.i.i.i = icmp ult i32 %conv.i.i, 1
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %139 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %140 = and i8 %139, 1
  %conv.i.i.i = xor i8 %140, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 1, %conv.i.i
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %141 = trunc i32 %xor1.i.i.i.i to i8
  %142 = lshr i8 %141, 4
  %conv2.i.i.i = and i8 %142, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %conv.i.i, 1
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %138, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %134
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 7
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %NEXT_PC, align 8
  %147 = add i64 %146, 11769
  %148 = load ptr, ptr %MEMORY, align 8
  %call.i.i43 = call i64 @__remill_read_memory_64(ptr noundef %148, i64 noundef %147) #16
  store i64 %call.i.i43, ptr %RAX, align 8
  store ptr %148, ptr %MEMORY, align 8
  br label %149

149:                                              ; preds = %143
  %150 = load i64, ptr %NEXT_PC, align 8
  store i64 %150, ptr %PC, align 8
  %151 = add i64 %150, 6
  store i64 %151, ptr %NEXT_PC, align 8
  %152 = load i64, ptr %RAX, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  %sub.i.i1 = sub i64 %152, 173495804
  store i64 %sub.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %152, 173495804
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i64 noundef %152, i64 noundef 173495804, i64 noundef %sub.i.i1) #16
  %conv.i.i4 = zext i1 %call.i.i.i3 to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i4, ptr %cf.i.i5, align 1
  %conv.i.i.i.i6 = trunc i64 %sub.i.i1 to i8
  %154 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i6)
  %155 = and i8 %154, 1
  %conv.i.i.i7 = xor i8 %155, 1
  %pf.i.i.i8 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i7, ptr %pf.i.i.i8, align 1
  %xor.i.i.i.i9 = xor i64 173495804, %152
  %xor1.i.i.i.i10 = xor i64 %xor.i.i.i.i9, %sub.i.i1
  %156 = trunc i64 %xor1.i.i.i.i10 to i8
  %157 = lshr i8 %156, 4
  %conv2.i.i.i11 = and i8 %157, 1
  %af.i.i.i12 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i11, ptr %af.i.i.i12, align 1
  %cmp.i.i.i.i13 = icmp eq i64 %152, 173495804
  %call.i.i.i.i14 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i13, i64 noundef %152, i64 noundef 173495804, i64 noundef %sub.i.i1) #16
  %conv5.i.i.i15 = zext i1 %call.i.i.i.i14 to i8
  %zf.i.i.i16 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i15, ptr %zf.i.i.i16, align 1
  %cmp.i27.i.i.i17 = icmp slt i64 %sub.i.i1, 0
  %call1.i.i.i.i18 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i17, i64 noundef %152, i64 noundef 173495804, i64 noundef %sub.i.i1) #16
  %conv8.i.i.i19 = zext i1 %call1.i.i.i.i18 to i8
  %sf.i.i.i20 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i19, ptr %sf.i.i.i20, align 1
  %xor.i28.i.i.i21 = lshr i64 %xor.i.i.i.i9, 63
  %shr9.i.i.i.i22 = xor i64 %sub.i.i1, %152
  %xor3.i.i.i.i23 = lshr i64 %shr9.i.i.i.i22, 63
  %add.i.i.i.i24 = add nuw nsw i64 %xor3.i.i.i.i23, %xor.i28.i.i.i21
  %cmp.i29.i.i.i25 = icmp eq i64 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i64 noundef %152, i64 noundef 173495804, i64 noundef %sub.i.i1) #16
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %153, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %149
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 2
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RAX, align 8
  %162 = load i64, ptr %NEXT_PC, align 8
  %163 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %164 = load i64, ptr %rsp.i, align 8
  %sub.i.i29 = add i64 %164, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %163, i64 noundef %sub.i.i29, i64 noundef %162) #16
  store i64 %sub.i.i29, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %161, ptr %rip.i, align 8
  store i64 %161, ptr %NEXT_PC, align 8
  store i64 %162, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %165 = load ptr, ptr %MEMORY, align 8
  ret ptr %165
}

define ptr @BB_3c3f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 96
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000000_recur(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_recursive_call(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_recursive_call(ptr noundef, i64 noundef, ptr noundef) local_unnamed_addr #4

define ptr @BB_3c45(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 13028
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12627
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_4247(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i36, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i35, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 64
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i34, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %22) #16
  store i64 %call.i.i33, ptr %RDI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 2
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RCX, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call i32 @__remill_read_memory_32(ptr noundef %28, i64 noundef %27) #16
  %conv.i.i31 = zext i32 %call.i.i30 to i64
  store i64 %conv.i.i31, ptr %RSI, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RSI, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %32 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RSI, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %34 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %34, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %35 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %36 = and i8 %35, 1
  %conv.i.i.i = xor i8 %36, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %37 = trunc i32 %xor1.i.i.i.i to i8
  %38 = lshr i8 %37, 4
  %conv2.i.i.i = and i8 %38, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %33, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %29
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 2
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RAX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call i32 @__remill_read_memory_32(ptr noundef %43, i64 noundef %42) #16
  %conv.i.i29 = zext i32 %call.i.i28 to i64
  store i64 %conv.i.i29, ptr %RDX, align 8
  store ptr %43, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %39
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 7
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = add i64 %47, 11740
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call i64 @__remill_read_memory_64(ptr noundef %49, i64 noundef %48) #16
  store i64 %call.i.i32, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 6
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RAX, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %53, 1838726149
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %53, 1838726149
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %53, i64 noundef 1838726149, i64 noundef %sub.i.i) #16
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %55 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %56 = and i8 %55, 1
  %conv.i.i.i6 = xor i8 %56, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 1838726149, %53
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %57 = trunc i64 %xor1.i.i.i.i9 to i8
  %58 = lshr i8 %57, 4
  %conv2.i.i.i10 = and i8 %58, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %53, 1838726149
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %53, i64 noundef 1838726149, i64 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %53, i64 noundef 1838726149, i64 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %53
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %53, i64 noundef 1838726149, i64 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %54, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %50
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 2
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RAX, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %65 = load i64, ptr %rsp.i, align 8
  %sub.i.i27 = add i64 %65, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %64, i64 noundef %sub.i.i27, i64 noundef %63) #16
  store i64 %sub.i.i27, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %62, ptr %rip.i, align 8
  store i64 %62, ptr %NEXT_PC, align 8
  store i64 %63, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  ret ptr %66
}

define ptr @BB_3c7b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i162 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i162, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 80
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i161 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i161, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 32
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i160 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i160, ptr %RSI, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i159 = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %22) #16
  store i64 %call.i.i159, ptr %RDX, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RSI, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i165 = call i32 @__remill_read_memory_32(ptr noundef %28, i64 noundef %27) #16
  %conv.i.i166 = sext i32 %call.i.i165 to i64
  store i64 %conv.i.i166, ptr %RSI, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RDX, align 8
  %33 = load i64, ptr %RSI, align 8
  %34 = mul i64 %33, 4
  %35 = add i64 %32, %34
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i32 @__remill_read_memory_32(ptr noundef %36, i64 noundef %35) #16
  %conv.i.i154 = zext i32 %call.i.i153 to i64
  store i64 %conv.i.i154, ptr %RDX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i158 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #16
  store i64 %call.i.i158, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %37
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RCX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i163 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #16
  %conv.i.i164 = sext i32 %call.i.i163 to i64
  store i64 %conv.i.i164, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load i64, ptr %RCX, align 8
  %52 = mul i64 %51, 4
  %53 = add i64 %50, %52
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i32 @__remill_read_memory_32(ptr noundef %54, i64 noundef %53) #16
  %conv.i.i152 = zext i32 %call.i.i151 to i64
  store i64 %conv.i.i152, ptr %RSI, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %47
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 5
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  store i64 7, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %55
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 5
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  store i64 6, ptr %RAX, align 8
  store ptr %62, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %59
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 2
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %EDX, align 4
  %67 = zext i32 %66 to i64
  %68 = load i32, ptr %ESI, align 4
  %69 = zext i32 %68 to i64
  %70 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %66, %68
  %cmp.i.i.i101 = icmp ult i32 %66, %68
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %72 = and i8 %71, 1
  %conv.i.i.i106 = xor i8 %72, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %68, %66
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %73 = trunc i32 %xor1.i.i.i.i109 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i110 = and i8 %74, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %66, %68
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %66
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %63
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i32, ptr %EAX, align 4
  %79 = zext i32 %78 to i64
  %80 = load ptr, ptr %MEMORY, align 8
  %zf.i132 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %81 = load i8, ptr %zf.i132, align 1
  %tobool.i133 = icmp ne i8 %81, 0
  %sf.i134 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %82 = load i8, ptr %sf.i134, align 1
  %tobool4.i = icmp ne i8 %82, 0
  %of.i135 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %83 = load i8, ptr %of.i135, align 1
  %tobool6.i = icmp ne i8 %83, 0
  %cmp.i.i136 = xor i1 %tobool4.i, %tobool6.i
  %84 = or i1 %tobool.i133, %cmp.i.i136
  %call8.i = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %84) #17
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call8.i, i64 %79, i64 %dst.coerce.val.i
  %conv.i27.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i27.i, ptr %RCX, align 8
  store ptr %80, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %75
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 7
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %NEXT_PC, align 8
  %89 = add i64 %88, 13313
  %90 = load ptr, ptr %MEMORY, align 8
  store i64 %89, ptr %RAX, align 8
  store ptr %90, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %85
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i32, ptr %ECX, align 4
  %95 = zext i32 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %sext.i167 = shl i64 %95, 32
  %conv.i12.i168 = ashr exact i64 %sext.i167, 32
  store i64 %conv.i12.i168, ptr %RCX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %91
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 4
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RAX, align 8
  %101 = load i64, ptr %RCX, align 8
  %102 = mul i64 %101, 8
  %103 = add i64 %100, %102
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %104, i64 noundef %103) #16
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 2
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load i32, ptr %ECX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %conv.i.i194 = trunc i64 %108 to i32
  %xor3.i.i = xor i32 %109, %conv.i.i194
  %conv.i27.i195 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i195, ptr %RCX, align 8
  %cf.i.i196 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i196, align 1
  %conv.i.i.i197 = trunc i32 %xor3.i.i to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i197)
  %113 = and i8 %112, 1
  %conv.i28.i198 = xor i8 %113, 1
  %pf.i.i199 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i198, ptr %pf.i.i199, align 1
  %cmp.i.i.i200 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i200, i32 noundef %conv.i.i194, i32 noundef %109, i32 noundef %xor3.i.i) #16
  %conv3.i.i202 = zext i1 %call.i.i.i201 to i8
  %zf.i.i203 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i202, ptr %zf.i.i203, align 1
  %cmp.i19.i.i204 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i204, i32 noundef %conv.i.i194, i32 noundef %109, i32 noundef %xor3.i.i) #16
  %conv6.i.i206 = zext i1 %call1.i.i.i205 to i8
  %sf.i.i207 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i206, ptr %sf.i.i207, align 1
  %of.i.i208 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i208, align 1
  %af.i.i209 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i210 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i210, ptr %af.i.i209, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %105
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 2
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i32, ptr %EDX, align 4
  %118 = zext i32 %117 to i64
  %119 = load i32, ptr %ESI, align 4
  %120 = zext i32 %119 to i64
  %121 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %117, %119
  %cmp.i.i.i73 = icmp ult i32 %117, %119
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %122 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %123 = and i8 %122, 1
  %conv.i.i.i78 = xor i8 %123, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %119, %117
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %124 = trunc i32 %xor1.i.i.i.i81 to i8
  %125 = lshr i8 %124, 4
  %conv2.i.i.i82 = and i8 %125, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %117, %119
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %117
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %121, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %114
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 4
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RCX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %zf.i137 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %131 = load i8, ptr %zf.i137, align 1
  %tobool.i138 = icmp ne i8 %131, 0
  %sf.i139 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %132 = load i8, ptr %sf.i139, align 1
  %tobool4.i140 = icmp ne i8 %132, 0
  %of.i141 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %133 = load i8, ptr %of.i141, align 1
  %tobool6.i142 = icmp ne i8 %133, 0
  %cmp.i.i143 = xor i1 %tobool4.i140, %tobool6.i142
  %134 = or i1 %tobool.i138, %cmp.i.i143
  %call8.i144 = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %134) #17
  %dst.coerce.val.i145 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call8.i144, i64 %129, i64 %dst.coerce.val.i145
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %130, ptr %MEMORY, align 8
  br label %135

135:                                              ; preds = %126
  %136 = load i64, ptr %NEXT_PC, align 8
  store i64 %136, ptr %PC, align 8
  %137 = add i64 %136, 3
  store i64 %137, ptr %NEXT_PC, align 8
  %138 = load i64, ptr %RAX, align 8
  %139 = load i64, ptr %RCX, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %138, %139
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %138, %139
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %141 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %142 = and i8 %141, 1
  %conv.i.i.i6 = xor i8 %142, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %139, %138
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %143 = trunc i64 %xor1.i.i.i.i9 to i8
  %144 = lshr i8 %143, 4
  %conv2.i.i.i10 = and i8 %144, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %138, %139
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %138
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %145

145:                                              ; preds = %135
  %146 = load i64, ptr %NEXT_PC, align 8
  store i64 %146, ptr %PC, align 8
  %147 = add i64 %146, 4
  store i64 %147, ptr %NEXT_PC, align 8
  %148 = load i64, ptr %RBP, align 8
  %149 = sub i64 %148, 104
  %150 = load i64, ptr %RAX, align 8
  %151 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call ptr @__remill_write_memory_64(ptr noundef %151, i64 noundef %149, i64 noundef %150) #16
  store ptr %call.i.i148, ptr %MEMORY, align 8
  br label %152

152:                                              ; preds = %145
  %153 = load i64, ptr %NEXT_PC, align 8
  store i64 %153, ptr %PC, align 8
  %154 = add i64 %153, 7
  store i64 %154, ptr %NEXT_PC, align 8
  %155 = load i64, ptr %NEXT_PC, align 8
  %156 = add i64 %155, 12892
  %157 = load ptr, ptr %MEMORY, align 8
  %call.i.i156 = call i64 @__remill_read_memory_64(ptr noundef %157, i64 noundef %156) #16
  store i64 %call.i.i156, ptr %RAX, align 8
  store ptr %157, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %152
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 2
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RAX, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i32 @__remill_read_memory_32(ptr noundef %162, i64 noundef %161) #16
  %conv.i.i150 = zext i32 %call.i.i149 to i64
  store i64 %conv.i.i150, ptr %RDX, align 8
  store ptr %162, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %158
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 7
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %NEXT_PC, align 8
  %167 = add i64 %166, 12475
  %168 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i64 @__remill_read_memory_64(ptr noundef %168, i64 noundef %167) #16
  store i64 %call.i.i155, ptr %RAX, align 8
  store ptr %168, ptr %MEMORY, align 8
  br label %169

169:                                              ; preds = %163
  %170 = load i64, ptr %NEXT_PC, align 8
  store i64 %170, ptr %PC, align 8
  %171 = add i64 %170, 3
  store i64 %171, ptr %NEXT_PC, align 8
  %172 = load i64, ptr %RAX, align 8
  %173 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %173, i64 noundef %172) #16
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %174 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %175 = and i8 %174, 1
  %conv.i.i.i32 = xor i8 %175, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %176 = trunc i32 %xor1.i.i.i.i35 to i8
  %177 = lshr i8 %176, 4
  %conv2.i.i.i36 = and i8 %177, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %173, ptr %MEMORY, align 8
  br label %178

178:                                              ; preds = %169
  %179 = load i64, ptr %NEXT_PC, align 8
  store i64 %179, ptr %PC, align 8
  %180 = add i64 %179, 3
  store i64 %180, ptr %NEXT_PC, align 8
  %181 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %182 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %182, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %183 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %183, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %181, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %178
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 2
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i32, ptr %EDX, align 4
  %188 = zext i32 %187 to i64
  %189 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %188, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %189, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %184
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 3
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %RCX, align 8
  %194 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %193 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %195 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %195, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %196 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %197 = and i8 %196, 1
  %conv.i.i.i = xor i8 %197, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %198 = trunc i32 %xor1.i.i.i.i to i8
  %199 = lshr i8 %198, 4
  %conv2.i.i.i = and i8 %199, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %194, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %190
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 3
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i64, ptr %RCX, align 8
  %204 = load i32, ptr %EDX, align 4
  %205 = zext i32 %204 to i64
  %206 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %203 to i32
  %sext.i = shl i64 %203, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %205, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %207 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %207, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %204, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %206, ptr %MEMORY, align 8
  br label %208

208:                                              ; preds = %200
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = add i64 %209, 3
  store i64 %210, ptr %NEXT_PC, align 8
  %211 = load i64, ptr %RCX, align 8
  %212 = load ptr, ptr %MEMORY, align 8
  %conv.i.i169 = trunc i64 %211 to i32
  %and3.i.i = and i32 1, %conv.i.i169
  %conv.i22.i170 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i170, ptr %RCX, align 8
  %cf.i.i171 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i171, align 1
  %conv.i.i.i172 = trunc i32 %and3.i.i to i8
  %213 = and i8 %conv.i.i.i172, 1
  %conv.i23.i173 = xor i8 %213, 1
  %pf.i.i174 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i173, ptr %pf.i.i174, align 1
  %cmp.i.i.i175 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i175, i32 noundef %conv.i.i169, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i176 to i8
  %zf.i.i177 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i177, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i169, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i178 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i178, align 1
  %of.i.i179 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i179, align 1
  %af.i.i180 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i180, align 1
  store ptr %212, ptr %MEMORY, align 8
  br label %214

214:                                              ; preds = %208
  %215 = load i64, ptr %NEXT_PC, align 8
  store i64 %215, ptr %PC, align 8
  %216 = add i64 %215, 3
  store i64 %216, ptr %NEXT_PC, align 8
  %217 = load i32, ptr %ECX, align 4
  %218 = zext i32 %217 to i64
  %219 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %217 to i8
  %220 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %221 = and i8 %220, 1
  %conv.i.i.i57 = xor i8 %221, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %217, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %217, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %217, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %219, ptr %MEMORY, align 8
  br label %222

222:                                              ; preds = %214
  %223 = load i64, ptr %NEXT_PC, align 8
  store i64 %223, ptr %PC, align 8
  %224 = add i64 %223, 3
  store i64 %224, ptr %NEXT_PC, align 8
  %225 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %226 = load i8, ptr %zf.i, align 1
  store i8 %226, ptr %CL, align 1
  store ptr %225, ptr %MEMORY, align 8
  br label %227

227:                                              ; preds = %222
  %228 = load i64, ptr %NEXT_PC, align 8
  store i64 %228, ptr %PC, align 8
  %229 = add i64 %228, 2
  store i64 %229, ptr %NEXT_PC, align 8
  %230 = load i8, ptr %AL, align 1
  %231 = zext i8 %230 to i64
  %232 = load i8, ptr %CL, align 1
  %233 = zext i8 %232 to i64
  %234 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %233, %231
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i181 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i181, align 1
  %235 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %236 = and i8 %235, 1
  %conv.i27.i182 = xor i8 %236, 1
  %pf.i.i183 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i182, ptr %pf.i.i183, align 1
  %237 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i184 = and i32 %237, 255
  %cmp.i.i.i185 = icmp eq i8 %or3.i.i, 0
  %238 = trunc i64 %231 to i32
  %conv1.i.i.i = and i32 %238, 255
  %239 = trunc i64 %233 to i32
  %conv2.i.i.i186 = and i32 %239, 255
  %call.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i185, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i186, i32 noundef %conv.i.i.i184) #16
  %conv3.i.i188 = zext i1 %call.i.i.i187 to i8
  %zf.i.i189 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i188, ptr %zf.i.i189, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i186, i32 noundef %conv.i.i.i184) #16
  %conv6.i.i190 = zext i1 %call4.i.i.i to i8
  %sf.i.i191 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i190, ptr %sf.i.i191, align 1
  %of.i.i192 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i192, align 1
  %af.i.i193 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i193, align 1
  store ptr %234, ptr %MEMORY, align 8
  br label %240

240:                                              ; preds = %227
  %241 = load i64, ptr %NEXT_PC, align 8
  store i64 %241, ptr %PC, align 8
  %242 = add i64 %241, 2
  store i64 %242, ptr %NEXT_PC, align 8
  %243 = load i8, ptr %AL, align 1
  %244 = zext i8 %243 to i64
  %245 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %244
  %and3.i.i211 = trunc i64 %and3.i15.i to i8
  %cf.i.i212 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i212, align 1
  %246 = and i8 %and3.i.i211, 1
  %conv.i14.i = xor i8 %246, 1
  %pf.i.i213 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i213, align 1
  %247 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i214 = and i32 %247, 255
  %cmp.i.i.i215 = icmp eq i8 %and3.i.i211, 0
  %248 = trunc i64 %244 to i32
  %conv1.i.i.i216 = and i32 %248, 255
  %call.i.i.i217 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i215, i32 noundef %conv1.i.i.i216, i32 noundef 1, i32 noundef %conv.i.i.i214) #16
  %conv3.i.i218 = zext i1 %call.i.i.i217 to i8
  %zf.i.i219 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i218, ptr %zf.i.i219, align 1
  %call4.i.i.i220 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i216, i32 noundef 1, i32 noundef %conv.i.i.i214) #16
  %conv6.i.i221 = zext i1 %call4.i.i.i220 to i8
  %sf.i.i222 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i221, ptr %sf.i.i222, align 1
  %of.i.i223 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i223, align 1
  %af.i.i224 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i224, align 1
  store ptr %245, ptr %MEMORY, align 8
  br label %249

249:                                              ; preds = %240
  %250 = load i64, ptr %NEXT_PC, align 8
  store i64 %250, ptr %PC, align 8
  %251 = add i64 %250, 6
  store i64 %251, ptr %NEXT_PC, align 8
  %252 = load i64, ptr %NEXT_PC, align 8
  %253 = add i64 %252, 5
  %254 = load i64, ptr %NEXT_PC, align 8
  %255 = load ptr, ptr %MEMORY, align 8
  %zf.i146 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %256 = load i8, ptr %zf.i146, align 1
  %tobool.not.i = icmp eq i8 %256, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i147 = select i1 %call9.i, i64 %253, i64 %254
  store i64 %cond1.i.i147, ptr %NEXT_PC, align 8
  store ptr %255, ptr %MEMORY, align 8
  %257 = load i64, ptr %NEXT_PC, align 8
  store i64 %257, ptr %PC, align 8
  %258 = load ptr, ptr %MEMORY, align 8
  ret ptr %258
}

define ptr @BB_ffff000000000001_recur(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_recursive_call(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_3cfb(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 104
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RCX, align 8
  %11 = load i32, ptr %ECX, align 4
  %12 = zext i32 %11 to i64
  %13 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %xor3.i.i = xor i32 %11, %conv.i.i
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RCX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %xor3.i.i to i8
  %14 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %15 = and i8 %14, 1
  %conv.i28.i = xor i8 %15, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %13, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %7
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 3
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %RBP, align 8
  %20 = sub i64 %19, 105
  %21 = load i8, ptr %CL, align 1
  %22 = zext i8 %21 to i64
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_8(ptr noundef %23, i64 noundef %20, i8 noundef zeroext %21) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %16
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 2
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RAX, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %27, ptr %rip.i, align 8
  store i64 %27, ptr %NEXT_PC, align 8
  store ptr %28, ptr %MEMORY, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  ret ptr %29
}

define ptr @BB_426c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11845
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 7
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 184
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #16
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 11331
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #16
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #16
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 11618
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #16
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #16
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #16
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #16
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #16
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_3d06(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12803
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12418
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_42b4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 184
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_3d3c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i113 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i113, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i112 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i112, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #16
  %conv.i.i108 = zext i32 %call.i.i107 to i64
  store i64 %conv.i.i108, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i32, ptr %EAX, align 4
  %22 = zext i32 %21 to i64
  %23 = load i64, ptr %RCX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i63 = call i32 @__remill_read_memory_32(ptr noundef %24, i64 noundef %23) #16
  %sub.i.i64 = sub i32 %21, %call.i.i63
  %cmp.i.i.i65 = icmp ugt i32 %call.i.i63, %21
  %call.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i65, i32 noundef %21, i32 noundef %call.i.i63, i32 noundef %sub.i.i64) #16
  %conv.i9.i67 = zext i1 %call.i.i.i66 to i8
  %cf.i.i68 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i67, ptr %cf.i.i68, align 1
  %conv.i.i.i.i69 = trunc i32 %sub.i.i64 to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i69)
  %26 = and i8 %25, 1
  %conv.i.i.i70 = xor i8 %26, 1
  %pf.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i70, ptr %pf.i.i.i71, align 1
  %xor.i.i.i.i72 = xor i32 %call.i.i63, %21
  %xor1.i.i.i.i73 = xor i32 %xor.i.i.i.i72, %sub.i.i64
  %27 = trunc i32 %xor1.i.i.i.i73 to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i74 = and i8 %28, 1
  %af.i.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i74, ptr %af.i.i.i75, align 1
  %cmp.i.i.i.i76 = icmp eq i32 %call.i.i63, %21
  %call.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i76, i32 noundef %21, i32 noundef %call.i.i63, i32 noundef %sub.i.i64) #16
  %conv5.i.i.i78 = zext i1 %call.i.i.i.i77 to i8
  %zf.i.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i78, ptr %zf.i.i.i79, align 1
  %cmp.i27.i.i.i80 = icmp slt i32 %sub.i.i64, 0
  %call1.i.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i80, i32 noundef %21, i32 noundef %call.i.i63, i32 noundef %sub.i.i64) #16
  %conv8.i.i.i82 = zext i1 %call1.i.i.i.i81 to i8
  %sf.i.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i82, ptr %sf.i.i.i83, align 1
  %xor.i28.i.i.i84 = lshr i32 %xor.i.i.i.i72, 31
  %shr9.i.i.i.i85 = xor i32 %sub.i.i64, %21
  %xor3.i.i.i.i86 = lshr i32 %shr9.i.i.i.i85, 31
  %add.i.i.i.i87 = add nuw nsw i32 %xor3.i.i.i.i86, %xor.i28.i.i.i84
  %cmp.i29.i.i.i88 = icmp eq i32 %add.i.i.i.i87, 2
  %call.i30.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i88, i32 noundef %21, i32 noundef %call.i.i63, i32 noundef %sub.i.i64) #16
  %conv11.i.i.i90 = zext i1 %call.i30.i.i.i89 to i8
  %of.i.i.i91 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i90, ptr %of.i.i.i91, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %18
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  %sf.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %33 = load i8, ptr %sf.i96, align 1
  %tobool.i97 = icmp ne i8 %33, 0
  %of.i98 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %34 = load i8, ptr %of.i98, align 1
  %tobool2.i99 = icmp ne i8 %34, 0
  %cmp.i.i100 = xor i1 %tobool.i97, %tobool2.i99
  %conv.i101 = zext i1 %cmp.i.i100 to i8
  store i8 %conv.i101, ptr %AL, align 1
  store ptr %32, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 121
  %40 = load i8, ptr %AL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call ptr @__remill_write_memory_8(ptr noundef %42, i64 noundef %39, i8 noundef zeroext %40) #16
  store ptr %call.i.i103, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %35
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 7
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %NEXT_PC, align 8
  %47 = add i64 %46, 13203
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i111 = call i64 @__remill_read_memory_64(ptr noundef %48, i64 noundef %47) #16
  store i64 %call.i.i111, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 4
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  store i64 %52, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %52, i64 noundef 0, i64 noundef %52) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %52 to i8
  %54 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %55 = and i8 %54, 1
  %conv.i.i.i5 = xor i8 %55, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %52, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %52, i64 noundef 0, i64 noundef %52) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %52, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %52, i64 noundef 0, i64 noundef %52) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %52, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %52, i64 noundef 0, i64 noundef %52) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %53, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %49
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 4
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RBP, align 8
  %60 = sub i64 %59, 120
  %61 = load i64, ptr %RAX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call ptr @__remill_write_memory_64(ptr noundef %62, i64 noundef %60, i64 noundef %61) #16
  store ptr %call.i.i104, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %56
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 7
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %NEXT_PC, align 8
  %67 = add i64 %66, 12724
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i110 = call i64 @__remill_read_memory_64(ptr noundef %68, i64 noundef %67) #16
  store i64 %call.i.i110, ptr %RAX, align 8
  store ptr %68, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %63
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 2
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RAX, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i32 @__remill_read_memory_32(ptr noundef %73, i64 noundef %72) #16
  %conv.i.i106 = zext i32 %call.i.i105 to i64
  store i64 %conv.i.i106, ptr %RDX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %69
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 7
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %NEXT_PC, align 8
  %78 = add i64 %77, 12387
  %79 = load ptr, ptr %MEMORY, align 8
  %call.i.i109 = call i64 @__remill_read_memory_64(ptr noundef %79, i64 noundef %78) #16
  store i64 %call.i.i109, ptr %RAX, align 8
  store ptr %79, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %74
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RAX, align 8
  %84 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %84, i64 noundef %83) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %85 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %86 = and i8 %85, 1
  %conv.i.i.i24 = xor i8 %86, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %87 = trunc i32 %xor1.i.i.i.i27 to i8
  %88 = lshr i8 %87, 4
  %conv2.i.i.i28 = and i8 %88, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %84, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %80
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 3
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %93 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %93, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %94 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %94, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %89
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i32, ptr %EDX, align 4
  %99 = zext i32 %98 to i64
  %100 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %99, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %100, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %95
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 3
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RCX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %104 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %106 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %106, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %107 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %108 = and i8 %107, 1
  %conv.i.i.i = xor i8 %108, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %109 = trunc i32 %xor1.i.i.i.i to i8
  %110 = lshr i8 %109, 4
  %conv2.i.i.i = and i8 %110, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %105, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %101
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i64, ptr %RCX, align 8
  %115 = load i32, ptr %EDX, align 4
  %116 = zext i32 %115 to i64
  %117 = load ptr, ptr %MEMORY, align 8
  %conv.i.i92 = trunc i64 %114 to i32
  %sext.i = shl i64 %114, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %116, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %118 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i93 = icmp ult i64 %118, -4294967296
  %call.i.i.i94 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i93, i32 noundef %conv.i.i92, i32 noundef %115, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i94 to i8
  %cf.i.i95 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i95, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RCX, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %conv.i.i114 = trunc i64 %122 to i32
  %and3.i.i = and i32 1, %conv.i.i114
  %conv.i22.i115 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i115, ptr %RCX, align 8
  %cf.i.i116 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i116, align 1
  %conv.i.i.i117 = trunc i32 %and3.i.i to i8
  %124 = and i8 %conv.i.i.i117, 1
  %conv.i23.i118 = xor i8 %124, 1
  %pf.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i118, ptr %pf.i.i119, align 1
  %cmp.i.i.i120 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i121 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i120, i32 noundef %conv.i.i114, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i121 to i8
  %zf.i.i122 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i122, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i114, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i123 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i123, align 1
  %of.i.i124 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i124, align 1
  %af.i.i125 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i125, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %119
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 3
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i32, ptr %ECX, align 4
  %129 = zext i32 %128 to i64
  %130 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %128, i32 noundef 0, i32 noundef %128) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %128 to i8
  %131 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %132 = and i8 %131, 1
  %conv.i.i.i48 = xor i8 %132, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %128, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %128, i32 noundef 0, i32 noundef %128) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %128, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %128, i32 noundef 0, i32 noundef %128) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %128, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %128, i32 noundef 0, i32 noundef %128) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %130, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %125
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 3
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %137 = load i8, ptr %zf.i, align 1
  store i8 %137, ptr %CL, align 1
  store ptr %136, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %133
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 2
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i8, ptr %AL, align 1
  %142 = zext i8 %141 to i64
  %143 = load i8, ptr %CL, align 1
  %144 = zext i8 %143 to i64
  %145 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %144, %142
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i126 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i126, align 1
  %146 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %147 = and i8 %146, 1
  %conv.i27.i = xor i8 %147, 1
  %pf.i.i127 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i127, align 1
  %148 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i128 = and i32 %148, 255
  %cmp.i.i.i129 = icmp eq i8 %or3.i.i, 0
  %149 = trunc i64 %142 to i32
  %conv1.i.i.i = and i32 %149, 255
  %150 = trunc i64 %144 to i32
  %conv2.i.i.i130 = and i32 %150, 255
  %call.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i130, i32 noundef %conv.i.i.i128) #16
  %conv3.i.i132 = zext i1 %call.i.i.i131 to i8
  %zf.i.i133 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i132, ptr %zf.i.i133, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i130, i32 noundef %conv.i.i.i128) #16
  %conv6.i.i134 = zext i1 %call4.i.i.i to i8
  %sf.i.i135 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i134, ptr %sf.i.i135, align 1
  %of.i.i136 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i136, align 1
  %af.i.i137 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i137, align 1
  store ptr %145, ptr %MEMORY, align 8
  br label %151

151:                                              ; preds = %138
  %152 = load i64, ptr %NEXT_PC, align 8
  store i64 %152, ptr %PC, align 8
  %153 = add i64 %152, 2
  store i64 %153, ptr %NEXT_PC, align 8
  %154 = load i8, ptr %AL, align 1
  %155 = zext i8 %154 to i64
  %156 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %155
  %and3.i.i138 = trunc i64 %and3.i15.i to i8
  %cf.i.i139 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i139, align 1
  %157 = and i8 %and3.i.i138, 1
  %conv.i14.i = xor i8 %157, 1
  %pf.i.i140 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i140, align 1
  %158 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i141 = and i32 %158, 255
  %cmp.i.i.i142 = icmp eq i8 %and3.i.i138, 0
  %159 = trunc i64 %155 to i32
  %conv1.i.i.i143 = and i32 %159, 255
  %call.i.i.i144 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i142, i32 noundef %conv1.i.i.i143, i32 noundef 1, i32 noundef %conv.i.i.i141) #16
  %conv3.i.i145 = zext i1 %call.i.i.i144 to i8
  %zf.i.i146 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i145, ptr %zf.i.i146, align 1
  %call4.i.i.i147 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i143, i32 noundef 1, i32 noundef %conv.i.i.i141) #16
  %conv6.i.i148 = zext i1 %call4.i.i.i147 to i8
  %sf.i.i149 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i148, ptr %sf.i.i149, align 1
  %of.i.i150 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i150, align 1
  %af.i.i151 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i151, align 1
  store ptr %156, ptr %MEMORY, align 8
  br label %160

160:                                              ; preds = %151
  %161 = load i64, ptr %NEXT_PC, align 8
  store i64 %161, ptr %PC, align 8
  %162 = add i64 %161, 6
  store i64 %162, ptr %NEXT_PC, align 8
  %163 = load i64, ptr %NEXT_PC, align 8
  %164 = add i64 %163, 5
  %165 = load i64, ptr %NEXT_PC, align 8
  %166 = load ptr, ptr %MEMORY, align 8
  %zf.i102 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %167 = load i8, ptr %zf.i102, align 1
  %tobool.not.i = icmp eq i8 %167, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %164, i64 %165
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %166, ptr %MEMORY, align 8
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = load ptr, ptr %MEMORY, align 8
  ret ptr %169
}

define ptr @BB_3d93(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 120
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 121
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call zeroext i8 @__remill_read_memory_8(ptr noundef %12, i64 noundef %11) #16
  store i8 %call.i.i1, ptr %CL, align 1
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 105
  %18 = load i8, ptr %CL, align 1
  %19 = zext i8 %18 to i64
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_8(ptr noundef %20, i64 noundef %17, i8 noundef zeroext %18) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RAX, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %24, ptr %rip.i, align 8
  store i64 %24, ptr %NEXT_PC, align 8
  store ptr %25, ptr %MEMORY, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  ret ptr %26
}

define ptr @BB_3d9f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 105
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call zeroext i8 @__remill_read_memory_8(ptr noundef %6, i64 noundef %5) #16
  store i8 %call.i.i50, ptr %AL, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 122
  %12 = load i8, ptr %AL, align 1
  %13 = zext i8 %12 to i64
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_8(ptr noundef %14, i64 noundef %11, i8 noundef zeroext %12) #16
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %7
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 7
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %NEXT_PC, align 8
  %19 = add i64 %18, 12332
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %19) #16
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %20, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %15
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RAX, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i32 @__remill_read_memory_32(ptr noundef %25, i64 noundef %24) #16
  %conv.i.i52 = zext i32 %call.i.i51 to i64
  store i64 %conv.i.i52, ptr %RDX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %21
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 7
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %NEXT_PC, align 8
  %30 = add i64 %29, 12603
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i53 = call i64 @__remill_read_memory_64(ptr noundef %31, i64 noundef %30) #16
  store i64 %call.i.i53, ptr %RAX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %26
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 3
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RAX, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %36, i64 noundef %35) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %37 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %38 = and i8 %37, 1
  %conv.i.i.i5 = xor i8 %38, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %39 = trunc i32 %xor1.i.i.i.i8 to i8
  %40 = lshr i8 %39, 4
  %conv2.i.i.i9 = and i8 %40, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %36, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %32
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %45 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %45, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %46 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %46, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %44, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i32, ptr %EDX, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %51, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RCX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %56 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %58 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %58, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %59 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %60 = and i8 %59, 1
  %conv.i.i.i = xor i8 %60, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %61 = trunc i32 %xor1.i.i.i.i to i8
  %62 = lshr i8 %61, 4
  %conv2.i.i.i = and i8 %62, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %53
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %RCX, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %66 to i32
  %sext.i = shl i64 %66, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %68, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %70 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %70, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %67, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load i64, ptr %RCX, align 8
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i55 = trunc i64 %74 to i32
  %and3.i.i = and i32 1, %conv.i.i55
  %conv.i22.i56 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i56, ptr %RCX, align 8
  %cf.i.i57 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i57, align 1
  %conv.i.i.i58 = trunc i32 %and3.i.i to i8
  %76 = and i8 %conv.i.i.i58, 1
  %conv.i23.i59 = xor i8 %76, 1
  %pf.i.i60 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i59, ptr %pf.i.i60, align 1
  %cmp.i.i.i61 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i61, i32 noundef %conv.i.i55, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i62 to i8
  %zf.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i63, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i55, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i64, align 1
  %of.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i65, align 1
  %af.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i66, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %71
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i32, ptr %ECX, align 4
  %81 = zext i32 %80 to i64
  %82 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %80, i32 noundef 0, i32 noundef %80) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %80 to i8
  %83 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %84 = and i8 %83, 1
  %conv.i.i.i29 = xor i8 %84, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %80, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %80, i32 noundef 0, i32 noundef %80) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %80, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %80, i32 noundef 0, i32 noundef %80) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %80, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %80, i32 noundef 0, i32 noundef %80) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %82, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %77
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %89 = load i8, ptr %zf.i, align 1
  store i8 %89, ptr %CL, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %85
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 2
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load i8, ptr %AL, align 1
  %94 = zext i8 %93 to i64
  %95 = load i8, ptr %CL, align 1
  %96 = zext i8 %95 to i64
  %97 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %96, %94
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i67, align 1
  %98 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %99 = and i8 %98, 1
  %conv.i27.i = xor i8 %99, 1
  %pf.i.i68 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i68, align 1
  %100 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i69 = and i32 %100, 255
  %cmp.i.i.i70 = icmp eq i8 %or3.i.i, 0
  %101 = trunc i64 %94 to i32
  %conv1.i.i.i = and i32 %101, 255
  %102 = trunc i64 %96 to i32
  %conv2.i.i.i71 = and i32 %102, 255
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i70, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i71, i32 noundef %conv.i.i.i69) #16
  %conv3.i.i73 = zext i1 %call.i.i.i72 to i8
  %zf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i73, ptr %zf.i.i74, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i71, i32 noundef %conv.i.i.i69) #16
  %conv6.i.i75 = zext i1 %call4.i.i.i to i8
  %sf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i75, ptr %sf.i.i76, align 1
  %of.i.i77 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i77, align 1
  %af.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i78, align 1
  store ptr %97, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %90
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 2
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i8, ptr %AL, align 1
  %107 = zext i8 %106 to i64
  %108 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %107
  %and3.i.i79 = trunc i64 %and3.i15.i to i8
  %cf.i.i80 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i80, align 1
  %109 = and i8 %and3.i.i79, 1
  %conv.i14.i = xor i8 %109, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i81, align 1
  %110 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i82 = and i32 %110, 255
  %cmp.i.i.i83 = icmp eq i8 %and3.i.i79, 0
  %111 = trunc i64 %107 to i32
  %conv1.i.i.i84 = and i32 %111, 255
  %call.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i83, i32 noundef %conv1.i.i.i84, i32 noundef 1, i32 noundef %conv.i.i.i82) #16
  %conv3.i.i86 = zext i1 %call.i.i.i85 to i8
  %zf.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i86, ptr %zf.i.i87, align 1
  %call4.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i84, i32 noundef 1, i32 noundef %conv.i.i.i82) #16
  %conv6.i.i89 = zext i1 %call4.i.i.i88 to i8
  %sf.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i89, ptr %sf.i.i90, align 1
  %of.i.i91 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i91, align 1
  %af.i.i92 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i92, align 1
  store ptr %108, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %103
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 6
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %NEXT_PC, align 8
  %116 = add i64 %115, 5
  %117 = load i64, ptr %NEXT_PC, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %119 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %119, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %116, i64 %117
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %118, ptr %MEMORY, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  ret ptr %121
}

define ptr @BB_3ddb(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %DL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 122
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i85 = call zeroext i8 @__remill_read_memory_8(ptr noundef %6, i64 noundef %5) #16
  store i8 %call.i.i85, ptr %DL, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i64 9, ptr %RCX, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 5
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  store i64 8, ptr %RAX, align 8
  store ptr %14, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %11
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i8, ptr %DL, align 1
  %19 = zext i8 %18 to i64
  %20 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i165 = and i64 1, %19
  %and3.i.i166 = trunc i64 %and3.i15.i165 to i8
  %cf.i.i167 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i167, align 1
  %21 = and i8 %and3.i.i166, 1
  %conv.i14.i168 = xor i8 %21, 1
  %pf.i.i169 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i168, ptr %pf.i.i169, align 1
  %22 = trunc i64 %and3.i15.i165 to i32
  %conv.i.i.i170 = and i32 %22, 255
  %cmp.i.i.i171 = icmp eq i8 %and3.i.i166, 0
  %23 = trunc i64 %19 to i32
  %conv1.i.i.i172 = and i32 %23, 255
  %call.i.i.i173 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i171, i32 noundef %conv1.i.i.i172, i32 noundef 1, i32 noundef %conv.i.i.i170) #16
  %conv3.i.i174 = zext i1 %call.i.i.i173 to i8
  %zf.i.i175 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i174, ptr %zf.i.i175, align 1
  %call4.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i172, i32 noundef 1, i32 noundef %conv.i.i.i170) #16
  %conv6.i.i177 = zext i1 %call4.i.i.i176 to i8
  %sf.i.i178 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i177, ptr %sf.i.i178, align 1
  %of.i.i179 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i179, align 1
  %af.i.i180 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i181 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i181, ptr %af.i.i180, align 1
  store ptr %20, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %15
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i32, ptr %EAX, align 4
  %28 = zext i32 %27 to i64
  %29 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %30 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %30, 0
  %call3.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call3.i, i64 %28, i64 %dst.coerce.val.i
  %conv.i20.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i20.i, ptr %RCX, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %24
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 12987
  %36 = load ptr, ptr %MEMORY, align 8
  store i64 %35, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i32, ptr %ECX, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %sext.i91 = shl i64 %41, 32
  %conv.i12.i92 = ashr exact i64 %sext.i91, 32
  store i64 %conv.i12.i92, ptr %RCX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %37
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RAX, align 8
  %47 = load i64, ptr %RCX, align 8
  %48 = mul i64 %47, 8
  %49 = add i64 %46, %48
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i90 = call i64 @__remill_read_memory_64(ptr noundef %50, i64 noundef %49) #16
  store i64 %call.i.i90, ptr %RAX, align 8
  store ptr %50, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %43
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 2
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RCX, align 8
  %55 = load i32, ptr %ECX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i117 = trunc i64 %54 to i32
  %xor3.i.i = xor i32 %55, %conv.i.i117
  %conv.i27.i118 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i118, ptr %RCX, align 8
  %cf.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i119, align 1
  %conv.i.i.i120 = trunc i32 %xor3.i.i to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i120)
  %59 = and i8 %58, 1
  %conv.i28.i121 = xor i8 %59, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i121, ptr %pf.i.i122, align 1
  %cmp.i.i.i123 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i124 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i123, i32 noundef %conv.i.i117, i32 noundef %55, i32 noundef %xor3.i.i) #16
  %conv3.i.i125 = zext i1 %call.i.i.i124 to i8
  %zf.i.i126 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i125, ptr %zf.i.i126, align 1
  %cmp.i19.i.i127 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i128 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i127, i32 noundef %conv.i.i117, i32 noundef %55, i32 noundef %xor3.i.i) #16
  %conv6.i.i129 = zext i1 %call1.i.i.i128 to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i133 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i133, ptr %af.i.i132, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %51
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 3
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i8, ptr %DL, align 1
  %64 = zext i8 %63 to i64
  %65 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i148 = and i64 1, %64
  %and3.i.i149 = trunc i64 %and3.i15.i148 to i8
  %cf.i.i150 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i150, align 1
  %66 = and i8 %and3.i.i149, 1
  %conv.i14.i151 = xor i8 %66, 1
  %pf.i.i152 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i151, ptr %pf.i.i152, align 1
  %67 = trunc i64 %and3.i15.i148 to i32
  %conv.i.i.i153 = and i32 %67, 255
  %cmp.i.i.i154 = icmp eq i8 %and3.i.i149, 0
  %68 = trunc i64 %64 to i32
  %conv1.i.i.i155 = and i32 %68, 255
  %call.i.i.i156 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i154, i32 noundef %conv1.i.i.i155, i32 noundef 1, i32 noundef %conv.i.i.i153) #16
  %conv3.i.i157 = zext i1 %call.i.i.i156 to i8
  %zf.i.i158 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i157, ptr %zf.i.i158, align 1
  %call4.i.i.i159 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i155, i32 noundef 1, i32 noundef %conv.i.i.i153) #16
  %conv6.i.i160 = zext i1 %call4.i.i.i159 to i8
  %sf.i.i161 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i160, ptr %sf.i.i161, align 1
  %of.i.i162 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i162, align 1
  %af.i.i163 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i164 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i164, ptr %af.i.i163, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %60
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 4
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %zf.i77 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %74 = load i8, ptr %zf.i77, align 1
  %tobool.not.i78 = icmp eq i8 %74, 0
  %call3.i79 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i78) #17
  %dst.coerce.val.i80 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call3.i79, i64 %72, i64 %dst.coerce.val.i80
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %69
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RAX, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %78, %79
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %78, %79
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #16
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %81 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %82 = and i8 %81, 1
  %conv.i.i.i6 = xor i8 %82, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %79, %78
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %83 = trunc i64 %xor1.i.i.i.i9 to i8
  %84 = lshr i8 %83, 4
  %conv2.i.i.i10 = and i8 %84, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %78, %79
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %78
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %75
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 7
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RBP, align 8
  %89 = sub i64 %88, 136
  %90 = load i64, ptr %RAX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %call.i.i84 = call ptr @__remill_write_memory_64(ptr noundef %91, i64 noundef %89, i64 noundef %90) #16
  store ptr %call.i.i84, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %85
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 7
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %NEXT_PC, align 8
  %96 = add i64 %95, 12250
  %97 = load ptr, ptr %MEMORY, align 8
  %call.i.i89 = call i64 @__remill_read_memory_64(ptr noundef %97, i64 noundef %96) #16
  store i64 %call.i.i89, ptr %RAX, align 8
  store ptr %97, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 2
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RAX, align 8
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i86 = call i32 @__remill_read_memory_32(ptr noundef %102, i64 noundef %101) #16
  %conv.i.i87 = zext i32 %call.i.i86 to i64
  store i64 %conv.i.i87, ptr %RDX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %98
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 7
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  %107 = add i64 %106, 12521
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i88 = call i64 @__remill_read_memory_64(ptr noundef %108, i64 noundef %107) #16
  store i64 %call.i.i88, ptr %RAX, align 8
  store ptr %108, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %103
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 3
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RAX, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %113, i64 noundef %112) #16
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %114 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %115 = and i8 %114, 1
  %conv.i.i.i32 = xor i8 %115, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %116 = trunc i32 %xor1.i.i.i.i35 to i8
  %117 = lshr i8 %116, 4
  %conv2.i.i.i36 = and i8 %117, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 3
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %122 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %122, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %123 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %123, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %121, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %118
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i32, ptr %EDX, align 4
  %128 = zext i32 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %128, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %129, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %124
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 3
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load i64, ptr %RCX, align 8
  %134 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %133 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %135 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %135, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %136 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %137 = and i8 %136, 1
  %conv.i.i.i = xor i8 %137, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %138 = trunc i32 %xor1.i.i.i.i to i8
  %139 = lshr i8 %138, 4
  %conv2.i.i.i = and i8 %139, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %134, ptr %MEMORY, align 8
  br label %140

140:                                              ; preds = %130
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = add i64 %141, 3
  store i64 %142, ptr %NEXT_PC, align 8
  %143 = load i64, ptr %RCX, align 8
  %144 = load i32, ptr %EDX, align 4
  %145 = zext i32 %144 to i64
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %143 to i32
  %sext.i = shl i64 %143, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %145, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %147 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %147, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %144, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %140
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RCX, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %151 to i32
  %and3.i.i = and i32 1, %conv.i.i93
  %conv.i22.i94 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i94, ptr %RCX, align 8
  %cf.i.i95 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %conv.i.i.i96 = trunc i32 %and3.i.i to i8
  %153 = and i8 %conv.i.i.i96, 1
  %conv.i23.i97 = xor i8 %153, 1
  %pf.i.i98 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i97, ptr %pf.i.i98, align 1
  %cmp.i.i.i99 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i99, i32 noundef %conv.i.i93, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i100 to i8
  %zf.i.i101 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i101, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i93, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i102 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i102, align 1
  %of.i.i103 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i103, align 1
  %af.i.i104 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i104, align 1
  store ptr %152, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %148
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i32, ptr %ECX, align 4
  %158 = zext i32 %157 to i64
  %159 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %157, i32 noundef 0, i32 noundef %157) #16
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %157 to i8
  %160 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %161 = and i8 %160, 1
  %conv.i.i.i57 = xor i8 %161, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %157, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %157, i32 noundef 0, i32 noundef %157) #16
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %157, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %157, i32 noundef 0, i32 noundef %157) #16
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %157, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %157, i32 noundef 0, i32 noundef %157) #16
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %159, ptr %MEMORY, align 8
  br label %162

162:                                              ; preds = %154
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = add i64 %163, 3
  store i64 %164, ptr %NEXT_PC, align 8
  %165 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %166 = load i8, ptr %zf.i, align 1
  store i8 %166, ptr %CL, align 1
  store ptr %165, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %162
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 2
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i8, ptr %AL, align 1
  %171 = zext i8 %170 to i64
  %172 = load i8, ptr %CL, align 1
  %173 = zext i8 %172 to i64
  %174 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %173, %171
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i105 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i105, align 1
  %175 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %176 = and i8 %175, 1
  %conv.i27.i = xor i8 %176, 1
  %pf.i.i106 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i106, align 1
  %177 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i107 = and i32 %177, 255
  %cmp.i.i.i108 = icmp eq i8 %or3.i.i, 0
  %178 = trunc i64 %171 to i32
  %conv1.i.i.i = and i32 %178, 255
  %179 = trunc i64 %173 to i32
  %conv2.i.i.i109 = and i32 %179, 255
  %call.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i108, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i109, i32 noundef %conv.i.i.i107) #16
  %conv3.i.i111 = zext i1 %call.i.i.i110 to i8
  %zf.i.i112 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i111, ptr %zf.i.i112, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i109, i32 noundef %conv.i.i.i107) #16
  %conv6.i.i113 = zext i1 %call4.i.i.i to i8
  %sf.i.i114 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i113, ptr %sf.i.i114, align 1
  %of.i.i115 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i115, align 1
  %af.i.i116 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i116, align 1
  store ptr %174, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %167
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 2
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i8, ptr %AL, align 1
  %184 = zext i8 %183 to i64
  %185 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %184
  %and3.i.i134 = trunc i64 %and3.i15.i to i8
  %cf.i.i135 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i135, align 1
  %186 = and i8 %and3.i.i134, 1
  %conv.i14.i = xor i8 %186, 1
  %pf.i.i136 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i136, align 1
  %187 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i137 = and i32 %187, 255
  %cmp.i.i.i138 = icmp eq i8 %and3.i.i134, 0
  %188 = trunc i64 %184 to i32
  %conv1.i.i.i139 = and i32 %188, 255
  %call.i.i.i140 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i138, i32 noundef %conv1.i.i.i139, i32 noundef 1, i32 noundef %conv.i.i.i137) #16
  %conv3.i.i141 = zext i1 %call.i.i.i140 to i8
  %zf.i.i142 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i141, ptr %zf.i.i142, align 1
  %call4.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i139, i32 noundef 1, i32 noundef %conv.i.i.i137) #16
  %conv6.i.i144 = zext i1 %call4.i.i.i143 to i8
  %sf.i.i145 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i144, ptr %sf.i.i145, align 1
  %of.i.i146 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i146, align 1
  %af.i.i147 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i147, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %180
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 6
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i64, ptr %NEXT_PC, align 8
  %193 = add i64 %192, 5
  %194 = load i64, ptr %NEXT_PC, align 8
  %195 = load ptr, ptr %MEMORY, align 8
  %zf.i81 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %196 = load i8, ptr %zf.i81, align 1
  %tobool.not.i82 = icmp eq i8 %196, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i82) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i83 = select i1 %call9.i, i64 %193, i64 %194
  store i64 %cond1.i.i83, ptr %NEXT_PC, align 8
  store ptr %195, ptr %MEMORY, align 8
  %197 = load i64, ptr %NEXT_PC, align 8
  store i64 %197, ptr %PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  ret ptr %198
}

define ptr @BB_3e45(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 136
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_3e4e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12171
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12450
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3ee0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12065
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12280
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3e84(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #16
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #16
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #16
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #16
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #16
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 12866
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #16
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #16
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #16
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #16
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #16
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 7
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 144
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #16
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 12112
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #16
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #16
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 12319
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #16
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #16
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #16
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #16
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #16
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #16
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #16
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #16
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #16
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_3f16(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12771
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 7
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 152
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #16
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 11665
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #16
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #16
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 12072
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #16
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #16
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #16
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #16
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #16
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_3ed7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 144
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_3f5e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 152
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_3f67(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11626
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12025
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3f9d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i164 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i164, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 80
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i163 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i163, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 48
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i162 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i162, ptr %RSI, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i161 = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %22) #16
  store i64 %call.i.i161, ptr %RDX, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RSI, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i167 = call i32 @__remill_read_memory_32(ptr noundef %28, i64 noundef %27) #16
  %conv.i.i168 = sext i32 %call.i.i167 to i64
  store i64 %conv.i.i168, ptr %RSI, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RDX, align 8
  %33 = load i64, ptr %RSI, align 8
  %34 = mul i64 %33, 4
  %35 = add i64 %32, %34
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i32 @__remill_read_memory_32(ptr noundef %36, i64 noundef %35) #16
  %conv.i.i156 = zext i32 %call.i.i155 to i64
  store i64 %conv.i.i156, ptr %RDX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i160 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #16
  store i64 %call.i.i160, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %37
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RCX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i165 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #16
  %conv.i.i166 = sext i32 %call.i.i165 to i64
  store i64 %conv.i.i166, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load i64, ptr %RCX, align 8
  %52 = mul i64 %51, 4
  %53 = add i64 %50, %52
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i32 @__remill_read_memory_32(ptr noundef %54, i64 noundef %53) #16
  %conv.i.i154 = zext i32 %call.i.i153 to i64
  store i64 %conv.i.i154, ptr %RSI, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %47
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 5
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  store i64 12, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %55
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 5
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  store i64 11, ptr %RAX, align 8
  store ptr %62, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %59
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 2
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %EDX, align 4
  %67 = zext i32 %66 to i64
  %68 = load i32, ptr %ESI, align 4
  %69 = zext i32 %68 to i64
  %70 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %66, %68
  %cmp.i.i.i101 = icmp ult i32 %66, %68
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %72 = and i8 %71, 1
  %conv.i.i.i106 = xor i8 %72, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %68, %66
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %73 = trunc i32 %xor1.i.i.i.i109 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i110 = and i8 %74, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %66, %68
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %66
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %66, i32 noundef %68, i32 noundef %sub.i.i100) #16
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %63
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i32, ptr %EAX, align 4
  %79 = zext i32 %78 to i64
  %80 = load ptr, ptr %MEMORY, align 8
  %zf.i132 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %81 = load i8, ptr %zf.i132, align 1
  %tobool.not.i = icmp eq i8 %81, 0
  %sf.i133 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %82 = load i8, ptr %sf.i133, align 1
  %tobool4.i = icmp eq i8 %82, 0
  %of.i134 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %83 = load i8, ptr %of.i134, align 1
  %tobool6.i = icmp ne i8 %83, 0
  %cmp.i.i135 = xor i1 %tobool4.i, %tobool6.i
  %84 = and i1 %tobool.not.i, %cmp.i.i135
  %call9.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %84) #17
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call9.i, i64 %79, i64 %dst.coerce.val.i
  %conv.i28.i136 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i28.i136, ptr %RCX, align 8
  store ptr %80, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %75
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 7
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %NEXT_PC, align 8
  %89 = add i64 %88, 12511
  %90 = load ptr, ptr %MEMORY, align 8
  store i64 %89, ptr %RAX, align 8
  store ptr %90, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %85
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i32, ptr %ECX, align 4
  %95 = zext i32 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %sext.i169 = shl i64 %95, 32
  %conv.i12.i170 = ashr exact i64 %sext.i169, 32
  store i64 %conv.i12.i170, ptr %RCX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %91
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 4
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RAX, align 8
  %101 = load i64, ptr %RCX, align 8
  %102 = mul i64 %101, 8
  %103 = add i64 %100, %102
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i159 = call i64 @__remill_read_memory_64(ptr noundef %104, i64 noundef %103) #16
  store i64 %call.i.i159, ptr %RAX, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 2
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load i32, ptr %ECX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %conv.i.i195 = trunc i64 %108 to i32
  %xor3.i.i = xor i32 %109, %conv.i.i195
  %conv.i27.i196 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i196, ptr %RCX, align 8
  %cf.i.i197 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i197, align 1
  %conv.i.i.i198 = trunc i32 %xor3.i.i to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i198)
  %113 = and i8 %112, 1
  %conv.i28.i199 = xor i8 %113, 1
  %pf.i.i200 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i199, ptr %pf.i.i200, align 1
  %cmp.i.i.i201 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i202 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i201, i32 noundef %conv.i.i195, i32 noundef %109, i32 noundef %xor3.i.i) #16
  %conv3.i.i203 = zext i1 %call.i.i.i202 to i8
  %zf.i.i204 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i203, ptr %zf.i.i204, align 1
  %cmp.i19.i.i205 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i206 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i205, i32 noundef %conv.i.i195, i32 noundef %109, i32 noundef %xor3.i.i) #16
  %conv6.i.i207 = zext i1 %call1.i.i.i206 to i8
  %sf.i.i208 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i207, ptr %sf.i.i208, align 1
  %of.i.i209 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i209, align 1
  %af.i.i210 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i211 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i211, ptr %af.i.i210, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %105
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 2
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i32, ptr %EDX, align 4
  %118 = zext i32 %117 to i64
  %119 = load i32, ptr %ESI, align 4
  %120 = zext i32 %119 to i64
  %121 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %117, %119
  %cmp.i.i.i73 = icmp ult i32 %117, %119
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %122 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %123 = and i8 %122, 1
  %conv.i.i.i78 = xor i8 %123, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %119, %117
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %124 = trunc i32 %xor1.i.i.i.i81 to i8
  %125 = lshr i8 %124, 4
  %conv2.i.i.i82 = and i8 %125, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %117, %119
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %117
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %117, i32 noundef %119, i32 noundef %sub.i.i72) #16
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %121, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %114
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 4
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RCX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %zf.i137 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %131 = load i8, ptr %zf.i137, align 1
  %tobool.not.i138 = icmp eq i8 %131, 0
  %sf.i139 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %132 = load i8, ptr %sf.i139, align 1
  %tobool4.i140 = icmp eq i8 %132, 0
  %of.i141 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %133 = load i8, ptr %of.i141, align 1
  %tobool6.i142 = icmp ne i8 %133, 0
  %cmp.i.i143 = xor i1 %tobool4.i140, %tobool6.i142
  %134 = and i1 %tobool.not.i138, %cmp.i.i143
  %call9.i144 = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %134) #17
  %dst.coerce.val.i145 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call9.i144, i64 %129, i64 %dst.coerce.val.i145
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %130, ptr %MEMORY, align 8
  br label %135

135:                                              ; preds = %126
  %136 = load i64, ptr %NEXT_PC, align 8
  store i64 %136, ptr %PC, align 8
  %137 = add i64 %136, 3
  store i64 %137, ptr %NEXT_PC, align 8
  %138 = load i64, ptr %RAX, align 8
  %139 = load i64, ptr %RCX, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %138, %139
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %138, %139
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %141 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %142 = and i8 %141, 1
  %conv.i.i.i6 = xor i8 %142, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %139, %138
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %143 = trunc i64 %xor1.i.i.i.i9 to i8
  %144 = lshr i8 %143, 4
  %conv2.i.i.i10 = and i8 %144, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %138, %139
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %138
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %138, i64 noundef %139, i64 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %145

145:                                              ; preds = %135
  %146 = load i64, ptr %NEXT_PC, align 8
  store i64 %146, ptr %PC, align 8
  %147 = add i64 %146, 7
  store i64 %147, ptr %NEXT_PC, align 8
  %148 = load i64, ptr %RBP, align 8
  %149 = sub i64 %148, 160
  %150 = load i64, ptr %RAX, align 8
  %151 = load ptr, ptr %MEMORY, align 8
  %call.i.i150 = call ptr @__remill_write_memory_64(ptr noundef %151, i64 noundef %149, i64 noundef %150) #16
  store ptr %call.i.i150, ptr %MEMORY, align 8
  br label %152

152:                                              ; preds = %145
  %153 = load i64, ptr %NEXT_PC, align 8
  store i64 %153, ptr %PC, align 8
  %154 = add i64 %153, 7
  store i64 %154, ptr %NEXT_PC, align 8
  %155 = load i64, ptr %NEXT_PC, align 8
  %156 = add i64 %155, 11479
  %157 = load ptr, ptr %MEMORY, align 8
  %call.i.i158 = call i64 @__remill_read_memory_64(ptr noundef %157, i64 noundef %156) #16
  store i64 %call.i.i158, ptr %RAX, align 8
  store ptr %157, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %152
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 2
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RAX, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i32 @__remill_read_memory_32(ptr noundef %162, i64 noundef %161) #16
  %conv.i.i152 = zext i32 %call.i.i151 to i64
  store i64 %conv.i.i152, ptr %RDX, align 8
  store ptr %162, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %158
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 7
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %NEXT_PC, align 8
  %167 = add i64 %166, 11886
  %168 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %168, i64 noundef %167) #16
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %168, ptr %MEMORY, align 8
  br label %169

169:                                              ; preds = %163
  %170 = load i64, ptr %NEXT_PC, align 8
  store i64 %170, ptr %PC, align 8
  %171 = add i64 %170, 3
  store i64 %171, ptr %NEXT_PC, align 8
  %172 = load i64, ptr %RAX, align 8
  %173 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %173, i64 noundef %172) #16
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %174 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %175 = and i8 %174, 1
  %conv.i.i.i32 = xor i8 %175, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %176 = trunc i32 %xor1.i.i.i.i35 to i8
  %177 = lshr i8 %176, 4
  %conv2.i.i.i36 = and i8 %177, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %173, ptr %MEMORY, align 8
  br label %178

178:                                              ; preds = %169
  %179 = load i64, ptr %NEXT_PC, align 8
  store i64 %179, ptr %PC, align 8
  %180 = add i64 %179, 3
  store i64 %180, ptr %NEXT_PC, align 8
  %181 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %182 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %182, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %183 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %183, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %181, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %178
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 2
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i32, ptr %EDX, align 4
  %188 = zext i32 %187 to i64
  %189 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %188, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %189, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %184
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 3
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %RCX, align 8
  %194 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %193 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %195 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %195, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %196 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %197 = and i8 %196, 1
  %conv.i.i.i = xor i8 %197, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %198 = trunc i32 %xor1.i.i.i.i to i8
  %199 = lshr i8 %198, 4
  %conv2.i.i.i = and i8 %199, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %194, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %190
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 3
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i64, ptr %RCX, align 8
  %204 = load i32, ptr %EDX, align 4
  %205 = zext i32 %204 to i64
  %206 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %203 to i32
  %sext.i = shl i64 %203, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %205, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %207 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %207, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %204, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %206, ptr %MEMORY, align 8
  br label %208

208:                                              ; preds = %200
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = add i64 %209, 3
  store i64 %210, ptr %NEXT_PC, align 8
  %211 = load i64, ptr %RCX, align 8
  %212 = load ptr, ptr %MEMORY, align 8
  %conv.i.i171 = trunc i64 %211 to i32
  %and3.i.i = and i32 1, %conv.i.i171
  %conv.i22.i172 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i172, ptr %RCX, align 8
  %cf.i.i173 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i173, align 1
  %conv.i.i.i174 = trunc i32 %and3.i.i to i8
  %213 = and i8 %conv.i.i.i174, 1
  %conv.i23.i175 = xor i8 %213, 1
  %pf.i.i176 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i175, ptr %pf.i.i176, align 1
  %cmp.i.i.i177 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i178 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i177, i32 noundef %conv.i.i171, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i178 to i8
  %zf.i.i179 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i179, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i171, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i180 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i180, align 1
  %of.i.i181 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i181, align 1
  %af.i.i182 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i182, align 1
  store ptr %212, ptr %MEMORY, align 8
  br label %214

214:                                              ; preds = %208
  %215 = load i64, ptr %NEXT_PC, align 8
  store i64 %215, ptr %PC, align 8
  %216 = add i64 %215, 3
  store i64 %216, ptr %NEXT_PC, align 8
  %217 = load i32, ptr %ECX, align 4
  %218 = zext i32 %217 to i64
  %219 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %217 to i8
  %220 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %221 = and i8 %220, 1
  %conv.i.i.i57 = xor i8 %221, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %217, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %217, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %217, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %217, i32 noundef 0, i32 noundef %217) #16
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %219, ptr %MEMORY, align 8
  br label %222

222:                                              ; preds = %214
  %223 = load i64, ptr %NEXT_PC, align 8
  store i64 %223, ptr %PC, align 8
  %224 = add i64 %223, 3
  store i64 %224, ptr %NEXT_PC, align 8
  %225 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %226 = load i8, ptr %zf.i, align 1
  store i8 %226, ptr %CL, align 1
  store ptr %225, ptr %MEMORY, align 8
  br label %227

227:                                              ; preds = %222
  %228 = load i64, ptr %NEXT_PC, align 8
  store i64 %228, ptr %PC, align 8
  %229 = add i64 %228, 2
  store i64 %229, ptr %NEXT_PC, align 8
  %230 = load i8, ptr %AL, align 1
  %231 = zext i8 %230 to i64
  %232 = load i8, ptr %CL, align 1
  %233 = zext i8 %232 to i64
  %234 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %233, %231
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i183 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i183, align 1
  %235 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %236 = and i8 %235, 1
  %conv.i27.i = xor i8 %236, 1
  %pf.i.i184 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i184, align 1
  %237 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i185 = and i32 %237, 255
  %cmp.i.i.i186 = icmp eq i8 %or3.i.i, 0
  %238 = trunc i64 %231 to i32
  %conv1.i.i.i = and i32 %238, 255
  %239 = trunc i64 %233 to i32
  %conv2.i.i.i187 = and i32 %239, 255
  %call.i.i.i188 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i186, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i187, i32 noundef %conv.i.i.i185) #16
  %conv3.i.i189 = zext i1 %call.i.i.i188 to i8
  %zf.i.i190 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i189, ptr %zf.i.i190, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i187, i32 noundef %conv.i.i.i185) #16
  %conv6.i.i191 = zext i1 %call4.i.i.i to i8
  %sf.i.i192 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i191, ptr %sf.i.i192, align 1
  %of.i.i193 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i193, align 1
  %af.i.i194 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i194, align 1
  store ptr %234, ptr %MEMORY, align 8
  br label %240

240:                                              ; preds = %227
  %241 = load i64, ptr %NEXT_PC, align 8
  store i64 %241, ptr %PC, align 8
  %242 = add i64 %241, 2
  store i64 %242, ptr %NEXT_PC, align 8
  %243 = load i8, ptr %AL, align 1
  %244 = zext i8 %243 to i64
  %245 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %244
  %and3.i.i212 = trunc i64 %and3.i15.i to i8
  %cf.i.i213 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i213, align 1
  %246 = and i8 %and3.i.i212, 1
  %conv.i14.i = xor i8 %246, 1
  %pf.i.i214 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i214, align 1
  %247 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i215 = and i32 %247, 255
  %cmp.i.i.i216 = icmp eq i8 %and3.i.i212, 0
  %248 = trunc i64 %244 to i32
  %conv1.i.i.i217 = and i32 %248, 255
  %call.i.i.i218 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i216, i32 noundef %conv1.i.i.i217, i32 noundef 1, i32 noundef %conv.i.i.i215) #16
  %conv3.i.i219 = zext i1 %call.i.i.i218 to i8
  %zf.i.i220 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i219, ptr %zf.i.i220, align 1
  %call4.i.i.i221 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i217, i32 noundef 1, i32 noundef %conv.i.i.i215) #16
  %conv6.i.i222 = zext i1 %call4.i.i.i221 to i8
  %sf.i.i223 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i222, ptr %sf.i.i223, align 1
  %of.i.i224 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i224, align 1
  %af.i.i225 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i225, align 1
  store ptr %245, ptr %MEMORY, align 8
  br label %249

249:                                              ; preds = %240
  %250 = load i64, ptr %NEXT_PC, align 8
  store i64 %250, ptr %PC, align 8
  %251 = add i64 %250, 6
  store i64 %251, ptr %NEXT_PC, align 8
  %252 = load i64, ptr %NEXT_PC, align 8
  %253 = add i64 %252, 5
  %254 = load i64, ptr %NEXT_PC, align 8
  %255 = load ptr, ptr %MEMORY, align 8
  %zf.i146 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %256 = load i8, ptr %zf.i146, align 1
  %tobool.not.i147 = icmp eq i8 %256, 0
  %call9.i148 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i147) #17
  %frombool.i = zext i1 %call9.i148 to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i149 = select i1 %call9.i148, i64 %253, i64 %254
  store i64 %cond1.i.i149, ptr %NEXT_PC, align 8
  store ptr %255, ptr %MEMORY, align 8
  %257 = load i64, ptr %NEXT_PC, align 8
  store i64 %257, ptr %PC, align 8
  %258 = load ptr, ptr %MEMORY, align 8
  ret ptr %258
}

define ptr @BB_4020(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 160
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_4029(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i2 = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i2, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 2
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %15 to i32
  %sub.i.i = add i32 %conv.i.i, -1
  %conv.i16.i = zext i32 %sub.i.i to i64
  store i64 %conv.i16.i, ptr %RCX, align 8
  %conv.i.i.i = trunc i32 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %18 = and i8 %17, 1
  %conv.i17.i = xor i8 %18, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i17.i, ptr %pf.i.i, align 1
  %xor1.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %19 = trunc i32 %xor1.i.i.i to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i = and i8 %20, 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i, ptr %af.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %sub.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv5.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i, ptr %zf.i.i, align 1
  %cmp.i27.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv8.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i, ptr %sf.i.i, align 1
  %xor.i28.i.i = lshr i32 %conv.i.i, 31
  %xor3.i.i.i = lshr i32 %xor1.i.i.i, 31
  %add.i.i.i = add nuw nsw i32 %xor3.i.i.i, %xor.i28.i.i
  %cmp.i29.i.i = icmp eq i32 %add.i.i.i, 2
  %call.i30.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv11.i.i = zext i1 %call.i30.i.i to i8
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i, ptr %of.i.i, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RAX, align 8
  %25 = load i32, ptr %ECX, align 4
  %26 = zext i32 %25 to i64
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %27, i64 noundef %24, i32 noundef %25) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %21
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 7
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %NEXT_PC, align 8
  %32 = add i64 %31, 12486
  %33 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %33, i64 noundef %32) #16
  store i64 %call.i.i3, ptr %RAX, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %28
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 2
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RAX, align 8
  %38 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %37, ptr %rip.i, align 8
  store i64 %37, ptr %NEXT_PC, align 8
  store ptr %38, ptr %MEMORY, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  ret ptr %39
}

define ptr @BB_403c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11429
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11820
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_4072(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i156 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i156, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #16
  %conv.i.i152 = zext i32 %call.i.i151 to i64
  store i64 %conv.i.i152, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %conv.i.i150 = zext i32 %call.i.i149 to i64
  store i64 %conv.i.i150, ptr %RSI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 5
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  store i64 14, ptr %RCX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %23
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 5
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  store i64 13, ptr %RAX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %27
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 2
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i32, ptr %EDX, align 4
  %35 = zext i32 %34 to i64
  %36 = load i32, ptr %ESI, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %34, %36
  %cmp.i.i.i101 = icmp ult i32 %34, %36
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #16
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %39 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %40 = and i8 %39, 1
  %conv.i.i.i106 = xor i8 %40, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %36, %34
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %41 = trunc i32 %xor1.i.i.i.i109 to i8
  %42 = lshr i8 %41, 4
  %conv2.i.i.i110 = and i8 %42, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %34, %36
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #16
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #16
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %34
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #16
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %38, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %31
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 3
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i32, ptr %EAX, align 4
  %47 = zext i32 %46 to i64
  %48 = load ptr, ptr %MEMORY, align 8
  %sf.i132 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %49 = load i8, ptr %sf.i132, align 1
  %tobool.i133 = icmp ne i8 %49, 0
  %of.i134 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %50 = load i8, ptr %of.i134, align 1
  %tobool4.i = icmp ne i8 %50, 0
  %cmp.i.i135 = xor i1 %tobool.i133, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i135) #17
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %47, i64 %dst.coerce.val.i
  %conv.i23.i136 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i136, ptr %RCX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %43
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 7
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %NEXT_PC, align 8
  %55 = add i64 %54, 12316
  %56 = load ptr, ptr %MEMORY, align 8
  store i64 %55, ptr %RAX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %51
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i32, ptr %ECX, align 4
  %61 = zext i32 %60 to i64
  %62 = load ptr, ptr %MEMORY, align 8
  %sext.i158 = shl i64 %61, 32
  %conv.i12.i159 = ashr exact i64 %sext.i158, 32
  store i64 %conv.i12.i159, ptr %RCX, align 8
  store ptr %62, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 4
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %RAX, align 8
  %67 = load i64, ptr %RCX, align 8
  %68 = mul i64 %67, 8
  %69 = add i64 %66, %68
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i64 @__remill_read_memory_64(ptr noundef %70, i64 noundef %69) #16
  store i64 %call.i.i155, ptr %RAX, align 8
  store ptr %70, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 2
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load i64, ptr %RCX, align 8
  %75 = load i32, ptr %ECX, align 4
  %76 = zext i32 %75 to i64
  %77 = load ptr, ptr %MEMORY, align 8
  %conv.i.i184 = trunc i64 %74 to i32
  %xor3.i.i = xor i32 %75, %conv.i.i184
  %conv.i27.i185 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i185, ptr %RCX, align 8
  %cf.i.i186 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i186, align 1
  %conv.i.i.i187 = trunc i32 %xor3.i.i to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i187)
  %79 = and i8 %78, 1
  %conv.i28.i188 = xor i8 %79, 1
  %pf.i.i189 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i188, ptr %pf.i.i189, align 1
  %cmp.i.i.i190 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i191 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i190, i32 noundef %conv.i.i184, i32 noundef %75, i32 noundef %xor3.i.i) #16
  %conv3.i.i192 = zext i1 %call.i.i.i191 to i8
  %zf.i.i193 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i192, ptr %zf.i.i193, align 1
  %cmp.i19.i.i194 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i195 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i194, i32 noundef %conv.i.i184, i32 noundef %75, i32 noundef %xor3.i.i) #16
  %conv6.i.i196 = zext i1 %call1.i.i.i195 to i8
  %sf.i.i197 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i196, ptr %sf.i.i197, align 1
  %of.i.i198 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i198, align 1
  %af.i.i199 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i200 = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i200, ptr %af.i.i199, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %71
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 2
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i32, ptr %EDX, align 4
  %84 = zext i32 %83 to i64
  %85 = load i32, ptr %ESI, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %83, %85
  %cmp.i.i.i73 = icmp ult i32 %83, %85
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #16
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %89 = and i8 %88, 1
  %conv.i.i.i78 = xor i8 %89, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %85, %83
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %90 = trunc i32 %xor1.i.i.i.i81 to i8
  %91 = lshr i8 %90, 4
  %conv2.i.i.i82 = and i8 %91, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %83, %85
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #16
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #16
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %83
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #16
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %80
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 4
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %sf.i137 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %97 = load i8, ptr %sf.i137, align 1
  %tobool.i138 = icmp ne i8 %97, 0
  %of.i139 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %98 = load i8, ptr %of.i139, align 1
  %tobool4.i140 = icmp ne i8 %98, 0
  %cmp.i.i141 = xor i1 %tobool.i138, %tobool4.i140
  %call5.i142 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i141) #17
  %dst.coerce.val.i143 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i142, i64 %95, i64 %dst.coerce.val.i143
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %92
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RAX, align 8
  %103 = load i64, ptr %RCX, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %102, %103
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %102, %103
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #16
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %106 = and i8 %105, 1
  %conv.i.i.i6 = xor i8 %106, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %103, %102
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %107 = trunc i64 %xor1.i.i.i.i9 to i8
  %108 = lshr i8 %107, 4
  %conv2.i.i.i10 = and i8 %108, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %102, %103
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %102
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %99
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 7
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RBP, align 8
  %113 = sub i64 %112, 168
  %114 = load i64, ptr %RAX, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %call.i.i146 = call ptr @__remill_write_memory_64(ptr noundef %115, i64 noundef %113, i64 noundef %114) #16
  store ptr %call.i.i146, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %109
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 7
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %NEXT_PC, align 8
  %120 = add i64 %119, 11324
  %121 = load ptr, ptr %MEMORY, align 8
  %call.i.i154 = call i64 @__remill_read_memory_64(ptr noundef %121, i64 noundef %120) #16
  store i64 %call.i.i154, ptr %RAX, align 8
  store ptr %121, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %116
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 2
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load i64, ptr %RAX, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  %call.i.i147 = call i32 @__remill_read_memory_32(ptr noundef %126, i64 noundef %125) #16
  %conv.i.i148 = zext i32 %call.i.i147 to i64
  store i64 %conv.i.i148, ptr %RDX, align 8
  store ptr %126, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %122
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 7
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i64, ptr %NEXT_PC, align 8
  %131 = add i64 %130, 11715
  %132 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i64 @__remill_read_memory_64(ptr noundef %132, i64 noundef %131) #16
  store i64 %call.i.i153, ptr %RAX, align 8
  store ptr %132, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %127
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 3
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %RAX, align 8
  %137 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %137, i64 noundef %136) #16
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %138 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %139 = and i8 %138, 1
  %conv.i.i.i32 = xor i8 %139, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %140 = trunc i32 %xor1.i.i.i.i35 to i8
  %141 = lshr i8 %140, 4
  %conv2.i.i.i36 = and i8 %141, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #16
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %133
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %146 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %146, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %147 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %147, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %145, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 2
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i32, ptr %EDX, align 4
  %152 = zext i32 %151 to i64
  %153 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %152, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %153, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %148
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i64, ptr %RCX, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %157 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %159 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %159, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %160 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %161 = and i8 %160, 1
  %conv.i.i.i = xor i8 %161, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %162 = trunc i32 %xor1.i.i.i.i to i8
  %163 = lshr i8 %162, 4
  %conv2.i.i.i = and i8 %163, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %158, ptr %MEMORY, align 8
  br label %164

164:                                              ; preds = %154
  %165 = load i64, ptr %NEXT_PC, align 8
  store i64 %165, ptr %PC, align 8
  %166 = add i64 %165, 3
  store i64 %166, ptr %NEXT_PC, align 8
  %167 = load i64, ptr %RCX, align 8
  %168 = load i32, ptr %EDX, align 4
  %169 = zext i32 %168 to i64
  %170 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %167 to i32
  %sext.i = shl i64 %167, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %169, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %171 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %171, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %168, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %170, ptr %MEMORY, align 8
  br label %172

172:                                              ; preds = %164
  %173 = load i64, ptr %NEXT_PC, align 8
  store i64 %173, ptr %PC, align 8
  %174 = add i64 %173, 3
  store i64 %174, ptr %NEXT_PC, align 8
  %175 = load i64, ptr %RCX, align 8
  %176 = load ptr, ptr %MEMORY, align 8
  %conv.i.i160 = trunc i64 %175 to i32
  %and3.i.i = and i32 1, %conv.i.i160
  %conv.i22.i161 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i161, ptr %RCX, align 8
  %cf.i.i162 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i162, align 1
  %conv.i.i.i163 = trunc i32 %and3.i.i to i8
  %177 = and i8 %conv.i.i.i163, 1
  %conv.i23.i164 = xor i8 %177, 1
  %pf.i.i165 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i164, ptr %pf.i.i165, align 1
  %cmp.i.i.i166 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i167 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i166, i32 noundef %conv.i.i160, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i167 to i8
  %zf.i.i168 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i168, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i160, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i169 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i169, align 1
  %of.i.i170 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i170, align 1
  %af.i.i171 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i171, align 1
  store ptr %176, ptr %MEMORY, align 8
  br label %178

178:                                              ; preds = %172
  %179 = load i64, ptr %NEXT_PC, align 8
  store i64 %179, ptr %PC, align 8
  %180 = add i64 %179, 3
  store i64 %180, ptr %NEXT_PC, align 8
  %181 = load i32, ptr %ECX, align 4
  %182 = zext i32 %181 to i64
  %183 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %181, i32 noundef 0, i32 noundef %181) #16
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %181 to i8
  %184 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %185 = and i8 %184, 1
  %conv.i.i.i57 = xor i8 %185, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %181, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %181, i32 noundef 0, i32 noundef %181) #16
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %181, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %181, i32 noundef 0, i32 noundef %181) #16
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %181, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %181, i32 noundef 0, i32 noundef %181) #16
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %183, ptr %MEMORY, align 8
  br label %186

186:                                              ; preds = %178
  %187 = load i64, ptr %NEXT_PC, align 8
  store i64 %187, ptr %PC, align 8
  %188 = add i64 %187, 3
  store i64 %188, ptr %NEXT_PC, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %190 = load i8, ptr %zf.i, align 1
  store i8 %190, ptr %CL, align 1
  store ptr %189, ptr %MEMORY, align 8
  br label %191

191:                                              ; preds = %186
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = add i64 %192, 2
  store i64 %193, ptr %NEXT_PC, align 8
  %194 = load i8, ptr %AL, align 1
  %195 = zext i8 %194 to i64
  %196 = load i8, ptr %CL, align 1
  %197 = zext i8 %196 to i64
  %198 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %197, %195
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i172 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i172, align 1
  %199 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %200 = and i8 %199, 1
  %conv.i27.i = xor i8 %200, 1
  %pf.i.i173 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i173, align 1
  %201 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i174 = and i32 %201, 255
  %cmp.i.i.i175 = icmp eq i8 %or3.i.i, 0
  %202 = trunc i64 %195 to i32
  %conv1.i.i.i = and i32 %202, 255
  %203 = trunc i64 %197 to i32
  %conv2.i.i.i176 = and i32 %203, 255
  %call.i.i.i177 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i175, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i176, i32 noundef %conv.i.i.i174) #16
  %conv3.i.i178 = zext i1 %call.i.i.i177 to i8
  %zf.i.i179 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i178, ptr %zf.i.i179, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i176, i32 noundef %conv.i.i.i174) #16
  %conv6.i.i180 = zext i1 %call4.i.i.i to i8
  %sf.i.i181 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i180, ptr %sf.i.i181, align 1
  %of.i.i182 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i182, align 1
  %af.i.i183 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i183, align 1
  store ptr %198, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %191
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 2
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i8, ptr %AL, align 1
  %208 = zext i8 %207 to i64
  %209 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %208
  %and3.i.i201 = trunc i64 %and3.i15.i to i8
  %cf.i.i202 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i202, align 1
  %210 = and i8 %and3.i.i201, 1
  %conv.i14.i = xor i8 %210, 1
  %pf.i.i203 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i203, align 1
  %211 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i204 = and i32 %211, 255
  %cmp.i.i.i205 = icmp eq i8 %and3.i.i201, 0
  %212 = trunc i64 %208 to i32
  %conv1.i.i.i206 = and i32 %212, 255
  %call.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i205, i32 noundef %conv1.i.i.i206, i32 noundef 1, i32 noundef %conv.i.i.i204) #16
  %conv3.i.i208 = zext i1 %call.i.i.i207 to i8
  %zf.i.i209 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i208, ptr %zf.i.i209, align 1
  %call4.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i206, i32 noundef 1, i32 noundef %conv.i.i.i204) #16
  %conv6.i.i211 = zext i1 %call4.i.i.i210 to i8
  %sf.i.i212 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i211, ptr %sf.i.i212, align 1
  %of.i.i213 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i213, align 1
  %af.i.i214 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i214, align 1
  store ptr %209, ptr %MEMORY, align 8
  br label %213

213:                                              ; preds = %204
  %214 = load i64, ptr %NEXT_PC, align 8
  store i64 %214, ptr %PC, align 8
  %215 = add i64 %214, 6
  store i64 %215, ptr %NEXT_PC, align 8
  %216 = load i64, ptr %NEXT_PC, align 8
  %217 = add i64 %216, 5
  %218 = load i64, ptr %NEXT_PC, align 8
  %219 = load ptr, ptr %MEMORY, align 8
  %zf.i144 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %220 = load i8, ptr %zf.i144, align 1
  %tobool.not.i = icmp eq i8 %220, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i145 = select i1 %call9.i, i64 %217, i64 %218
  store i64 %cond1.i.i145, ptr %NEXT_PC, align 8
  store ptr %219, ptr %MEMORY, align 8
  %221 = load i64, ptr %NEXT_PC, align 8
  store i64 %221, ptr %PC, align 8
  %222 = load ptr, ptr %MEMORY, align 8
  ret ptr %222
}

define ptr @BB_40e3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 168
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_40ec(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11709
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12004
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_41ae(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12043
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_4122(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i90 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i90, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 80
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i89 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i89, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 40
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i88 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i88, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 32
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i87 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #16
  store i64 %call.i.i87, ptr %RDI, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RAX, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i86 = call i64 @__remill_read_memory_64(ptr noundef %29, i64 noundef %28) #16
  store i64 %call.i.i86, ptr %RSI, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %25
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RDI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i97 = call i32 @__remill_read_memory_32(ptr noundef %34, i64 noundef %33) #16
  %conv.i.i98 = sext i32 %call.i.i97 to i64
  store i64 %conv.i.i98, ptr %R8, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RSI, align 8
  %39 = load i64, ptr %R8, align 8
  %40 = mul i64 %39, 4
  %41 = add i64 %38, %40
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #16
  %conv.i.i79 = zext i32 %call.i.i78 to i64
  store i64 %conv.i.i79, ptr %RSI, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %35
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 2
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RDX, align 8
  %47 = load i32, ptr %ESI, align 4
  %48 = zext i32 %47 to i64
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call ptr @__remill_write_memory_32(ptr noundef %49, i64 noundef %46, i32 noundef %47) #16
  store ptr %call.i.i70, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %43
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 3
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RAX, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i85 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #16
  store i64 %call.i.i85, ptr %RSI, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %50
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RCX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i95 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #16
  %conv.i.i96 = sext i32 %call.i.i95 to i64
  store i64 %conv.i.i96, ptr %R8, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 4
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RSI, align 8
  %64 = load i64, ptr %R8, align 8
  %65 = mul i64 %64, 4
  %66 = add i64 %63, %65
  %67 = load ptr, ptr %MEMORY, align 8
  %call.i.i76 = call i32 @__remill_read_memory_32(ptr noundef %67, i64 noundef %66) #16
  %conv.i.i77 = zext i32 %call.i.i76 to i64
  store i64 %conv.i.i77, ptr %R8, align 8
  store ptr %67, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %60
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RAX, align 8
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i84 = call i64 @__remill_read_memory_64(ptr noundef %72, i64 noundef %71) #16
  store i64 %call.i.i84, ptr %RSI, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %68
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RDI, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i93 = call i32 @__remill_read_memory_32(ptr noundef %77, i64 noundef %76) #16
  %conv.i.i94 = sext i32 %call.i.i93 to i64
  store i64 %conv.i.i94, ptr %RDI, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %73
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 4
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RSI, align 8
  %82 = load i64, ptr %RDI, align 8
  %83 = mul i64 %82, 4
  %84 = add i64 %81, %83
  %85 = load i32, ptr %R8D, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_32(ptr noundef %87, i64 noundef %84, i32 noundef %85) #16
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %78
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 2
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RDX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i32 @__remill_read_memory_32(ptr noundef %92, i64 noundef %91) #16
  %conv.i.i75 = zext i32 %call.i.i74 to i64
  store i64 %conv.i.i75, ptr %RDX, align 8
  store ptr %92, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %88
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 3
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load ptr, ptr %MEMORY, align 8
  %call.i.i83 = call i64 @__remill_read_memory_64(ptr noundef %97, i64 noundef %96) #16
  store i64 %call.i.i83, ptr %RAX, align 8
  store ptr %97, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %93
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RCX, align 8
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i91 = call i32 @__remill_read_memory_32(ptr noundef %102, i64 noundef %101) #16
  %conv.i.i92 = sext i32 %call.i.i91 to i64
  store i64 %conv.i.i92, ptr %RCX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %98
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 3
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RAX, align 8
  %107 = load i64, ptr %RCX, align 8
  %108 = mul i64 %107, 4
  %109 = add i64 %106, %108
  %110 = load i32, ptr %EDX, align 4
  %111 = zext i32 %110 to i64
  %112 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_32(ptr noundef %112, i64 noundef %109, i32 noundef %110) #16
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %113

113:                                              ; preds = %103
  %114 = load i64, ptr %NEXT_PC, align 8
  store i64 %114, ptr %PC, align 8
  %115 = add i64 %114, 7
  store i64 %115, ptr %NEXT_PC, align 8
  %116 = load i64, ptr %NEXT_PC, align 8
  %117 = add i64 %116, 12220
  %118 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %118, i64 noundef %117) #16
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %118, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %113
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 4
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RAX, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  store i64 %122, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %122, i64 noundef 0, i64 noundef %122) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %122 to i8
  %124 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %125 = and i8 %124, 1
  %conv.i.i.i5 = xor i8 %125, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %122, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %122, i64 noundef 0, i64 noundef %122) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %122, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %122, i64 noundef 0, i64 noundef %122) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %122, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %122, i64 noundef 0, i64 noundef %122) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %119
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 7
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RBP, align 8
  %130 = sub i64 %129, 176
  %131 = load i64, ptr %RAX, align 8
  %132 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call ptr @__remill_write_memory_64(ptr noundef %132, i64 noundef %130, i64 noundef %131) #16
  store ptr %call.i.i71, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %126
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 7
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %NEXT_PC, align 8
  %137 = add i64 %136, 11594
  %138 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %138, i64 noundef %137) #16
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %138, ptr %MEMORY, align 8
  br label %139

139:                                              ; preds = %133
  %140 = load i64, ptr %NEXT_PC, align 8
  store i64 %140, ptr %PC, align 8
  %141 = add i64 %140, 2
  store i64 %141, ptr %NEXT_PC, align 8
  %142 = load i64, ptr %RAX, align 8
  %143 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i32 @__remill_read_memory_32(ptr noundef %143, i64 noundef %142) #16
  %conv.i.i73 = zext i32 %call.i.i72 to i64
  store i64 %conv.i.i73, ptr %RDX, align 8
  store ptr %143, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %139
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 7
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i64, ptr %NEXT_PC, align 8
  %148 = add i64 %147, 11865
  %149 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call i64 @__remill_read_memory_64(ptr noundef %149, i64 noundef %148) #16
  store i64 %call.i.i80, ptr %RAX, align 8
  store ptr %149, ptr %MEMORY, align 8
  br label %150

150:                                              ; preds = %144
  %151 = load i64, ptr %NEXT_PC, align 8
  store i64 %151, ptr %PC, align 8
  %152 = add i64 %151, 3
  store i64 %152, ptr %NEXT_PC, align 8
  %153 = load i64, ptr %RAX, align 8
  %154 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %154, i64 noundef %153) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %155 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %156 = and i8 %155, 1
  %conv.i.i.i24 = xor i8 %156, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %157 = trunc i32 %xor1.i.i.i.i27 to i8
  %158 = lshr i8 %157, 4
  %conv2.i.i.i28 = and i8 %158, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %154, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %150
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 3
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  %163 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %163, 0
  %of.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  %164 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %164, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %162, ptr %MEMORY, align 8
  br label %165

165:                                              ; preds = %159
  %166 = load i64, ptr %NEXT_PC, align 8
  store i64 %166, ptr %PC, align 8
  %167 = add i64 %166, 2
  store i64 %167, ptr %NEXT_PC, align 8
  %168 = load i32, ptr %EDX, align 4
  %169 = zext i32 %168 to i64
  %170 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %169, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %170, ptr %MEMORY, align 8
  br label %171

171:                                              ; preds = %165
  %172 = load i64, ptr %NEXT_PC, align 8
  store i64 %172, ptr %PC, align 8
  %173 = add i64 %172, 3
  store i64 %173, ptr %NEXT_PC, align 8
  %174 = load i64, ptr %RCX, align 8
  %175 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %174 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %176 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %176, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %177 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %178 = and i8 %177, 1
  %conv.i.i.i = xor i8 %178, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %179 = trunc i32 %xor1.i.i.i.i to i8
  %180 = lshr i8 %179, 4
  %conv2.i.i.i = and i8 %180, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %175, ptr %MEMORY, align 8
  br label %181

181:                                              ; preds = %171
  %182 = load i64, ptr %NEXT_PC, align 8
  store i64 %182, ptr %PC, align 8
  %183 = add i64 %182, 3
  store i64 %183, ptr %NEXT_PC, align 8
  %184 = load i64, ptr %RCX, align 8
  %185 = load i32, ptr %EDX, align 4
  %186 = zext i32 %185 to i64
  %187 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %184 to i32
  %sext.i = shl i64 %184, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %186, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %188 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %188, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %185, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %187, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %181
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 3
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i64, ptr %RCX, align 8
  %193 = load ptr, ptr %MEMORY, align 8
  %conv.i.i99 = trunc i64 %192 to i32
  %and3.i.i = and i32 1, %conv.i.i99
  %conv.i22.i100 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i100, ptr %RCX, align 8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i101, align 1
  %conv.i.i.i102 = trunc i32 %and3.i.i to i8
  %194 = and i8 %conv.i.i.i102, 1
  %conv.i23.i103 = xor i8 %194, 1
  %pf.i.i104 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i103, ptr %pf.i.i104, align 1
  %cmp.i.i.i105 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i105, i32 noundef %conv.i.i99, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i106 to i8
  %zf.i.i107 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i107, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i99, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i108 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i108, align 1
  %of.i.i109 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i109, align 1
  %af.i.i110 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i110, align 1
  store ptr %193, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %189
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 3
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i32, ptr %ECX, align 4
  %199 = zext i32 %198 to i64
  %200 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %198, i32 noundef 0, i32 noundef %198) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %198 to i8
  %201 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %202 = and i8 %201, 1
  %conv.i.i.i48 = xor i8 %202, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %198, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %198, i32 noundef 0, i32 noundef %198) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %198, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %198, i32 noundef 0, i32 noundef %198) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %198, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %198, i32 noundef 0, i32 noundef %198) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %200, ptr %MEMORY, align 8
  br label %203

203:                                              ; preds = %195
  %204 = load i64, ptr %NEXT_PC, align 8
  store i64 %204, ptr %PC, align 8
  %205 = add i64 %204, 3
  store i64 %205, ptr %NEXT_PC, align 8
  %206 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %207 = load i8, ptr %zf.i, align 1
  store i8 %207, ptr %CL, align 1
  store ptr %206, ptr %MEMORY, align 8
  br label %208

208:                                              ; preds = %203
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = add i64 %209, 2
  store i64 %210, ptr %NEXT_PC, align 8
  %211 = load i8, ptr %AL, align 1
  %212 = zext i8 %211 to i64
  %213 = load i8, ptr %CL, align 1
  %214 = zext i8 %213 to i64
  %215 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %214, %212
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i111 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %216 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %217 = and i8 %216, 1
  %conv.i27.i = xor i8 %217, 1
  %pf.i.i112 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i112, align 1
  %218 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i113 = and i32 %218, 255
  %cmp.i.i.i114 = icmp eq i8 %or3.i.i, 0
  %219 = trunc i64 %212 to i32
  %conv1.i.i.i = and i32 %219, 255
  %220 = trunc i64 %214 to i32
  %conv2.i.i.i115 = and i32 %220, 255
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i114, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i115, i32 noundef %conv.i.i.i113) #16
  %conv3.i.i117 = zext i1 %call.i.i.i116 to i8
  %zf.i.i118 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i117, ptr %zf.i.i118, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i115, i32 noundef %conv.i.i.i113) #16
  %conv6.i.i119 = zext i1 %call4.i.i.i to i8
  %sf.i.i120 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i119, ptr %sf.i.i120, align 1
  %of.i.i121 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i121, align 1
  %af.i.i122 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i122, align 1
  store ptr %215, ptr %MEMORY, align 8
  br label %221

221:                                              ; preds = %208
  %222 = load i64, ptr %NEXT_PC, align 8
  store i64 %222, ptr %PC, align 8
  %223 = add i64 %222, 2
  store i64 %223, ptr %NEXT_PC, align 8
  %224 = load i8, ptr %AL, align 1
  %225 = zext i8 %224 to i64
  %226 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %225
  %and3.i.i123 = trunc i64 %and3.i15.i to i8
  %cf.i.i124 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i124, align 1
  %227 = and i8 %and3.i.i123, 1
  %conv.i14.i = xor i8 %227, 1
  %pf.i.i125 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i125, align 1
  %228 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i126 = and i32 %228, 255
  %cmp.i.i.i127 = icmp eq i8 %and3.i.i123, 0
  %229 = trunc i64 %225 to i32
  %conv1.i.i.i128 = and i32 %229, 255
  %call.i.i.i129 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i127, i32 noundef %conv1.i.i.i128, i32 noundef 1, i32 noundef %conv.i.i.i126) #16
  %conv3.i.i130 = zext i1 %call.i.i.i129 to i8
  %zf.i.i131 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i130, ptr %zf.i.i131, align 1
  %call4.i.i.i132 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i128, i32 noundef 1, i32 noundef %conv.i.i.i126) #16
  %conv6.i.i133 = zext i1 %call4.i.i.i132 to i8
  %sf.i.i134 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i133, ptr %sf.i.i134, align 1
  %of.i.i135 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i135, align 1
  %af.i.i136 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i136, align 1
  store ptr %226, ptr %MEMORY, align 8
  br label %230

230:                                              ; preds = %221
  %231 = load i64, ptr %NEXT_PC, align 8
  store i64 %231, ptr %PC, align 8
  %232 = add i64 %231, 6
  store i64 %232, ptr %NEXT_PC, align 8
  %233 = load i64, ptr %NEXT_PC, align 8
  %234 = add i64 %233, 5
  %235 = load i64, ptr %NEXT_PC, align 8
  %236 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 2, i32 7
  %237 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %237, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %234, i64 %235
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %236, ptr %MEMORY, align 8
  %238 = load i64, ptr %NEXT_PC, align 8
  store i64 %238, ptr %PC, align 8
  %239 = load ptr, ptr %MEMORY, align 8
  ret ptr %239
}

define ptr @BB_41a5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.379547, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 176
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #5 {
entry:
  %agg.tmp = alloca %struct.State.379547, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.379547) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #18
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.379547) align 16, i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rax = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #10 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 14800, label %bb_39D0
    i64 14875, label %bb_3A1B
    i64 15089, label %bb_3AF1
    i64 15095, label %bb_3AF7
    i64 15149, label %bb_3B2D
    i64 15252, label %bb_3B94
    i64 15258, label %bb_3B9A
    i64 15300, label %bb_3BC4
    i64 15354, label %bb_3BFA
    i64 15423, label %bb_3C3F
    i64 15429, label %bb_3C45
    i64 15483, label %bb_3C7B
    i64 15611, label %bb_3CFB
    i64 15622, label %bb_3D06
    i64 15676, label %bb_3D3C
    i64 15763, label %bb_3D93
    i64 15775, label %bb_3D9F
    i64 15835, label %bb_3DDB
    i64 15941, label %bb_3E45
    i64 15950, label %bb_3E4E
    i64 16004, label %bb_3E84
    i64 16087, label %bb_3ED7
    i64 16096, label %bb_3EE0
    i64 16150, label %bb_3F16
    i64 16222, label %bb_3F5E
    i64 16231, label %bb_3F67
    i64 16285, label %bb_3F9D
    i64 16416, label %bb_4020
    i64 16425, label %bb_4029
    i64 16444, label %bb_403C
    i64 16498, label %bb_4072
    i64 16611, label %bb_40E3
    i64 16620, label %bb_40EC
    i64 16674, label %bb_4122
    i64 16805, label %bb_41A5
    i64 16814, label %bb_41AE
    i64 16823, label %bb_41B7
    i64 16877, label %bb_41ED
    i64 16967, label %bb_4247
    i64 17004, label %bb_426C
    i64 17076, label %bb_42B4
    i64 17085, label %bb_42BD
    i64 17139, label %bb_42F3
    i64 17193, label %bb_4329
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
  ]

dead_end:                                         ; preds = %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_42F3, %bb_42BD, %bb_42B4, %bb_426C, %bb_4247, %bb_41ED, %bb_41B7, %bb_41AE, %bb_41A5, %bb_4122, %bb_40EC, %bb_40E3, %bb_4072, %bb_403C, %bb_4029, %bb_4020, %bb_3F9D, %bb_3F67, %bb_3F5E, %bb_3F16, %bb_3EE0, %bb_3ED7, %bb_3E84, %bb_3E4E, %bb_3E45, %bb_3DDB, %bb_3D9F, %bb_3D93, %bb_3D3C, %bb_3D06, %bb_3CFB, %bb_3C7B, %bb_3C45, %bb_3C3F, %bb_3BFA, %bb_3BC4, %bb_3B9A, %bb_3B94, %bb_3B2D, %bb_3AF7, %bb_3AF1, %bb_3A1B, %bb_39D0, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_39D0:                                          ; preds = %entry
  %block_pc = add i64 14800, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 14800, ptr %1)
  %4 = call ptr @BB_39d0(ptr %state, i64 %2, ptr %1) #19
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 14875, label %bb_3A1B
  ]

bb_3A1B:                                          ; preds = %bb_39D0, %entry
  %block_pc1 = add i64 14875, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 14875, ptr %6)
  %9 = call ptr @BB_3a1b(ptr %state, i64 %7, ptr %6) #19
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 15089, label %bb_3AF1
  ]

bb_3AF1:                                          ; preds = %bb_3A1B, %entry
  %block_pc3 = add i64 15089, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 15089, ptr %11)
  %14 = call ptr @BB_3af1(ptr %state, i64 %12, ptr %11) #19
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 15095, label %bb_3AF7
    i64 17085, label %bb_42BD
  ]

bb_3AF7:                                          ; preds = %bb_3AF1, %entry
  %block_pc5 = add i64 15095, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 15095, ptr %16)
  %19 = call ptr @BB_3af7(ptr %state, i64 %17, ptr %16) #19
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 15149, label %bb_3B2D
  ]

bb_3B2D:                                          ; preds = %bb_3AF7, %entry
  %block_pc7 = add i64 15149, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 15149, ptr %21)
  %24 = call ptr @BB_3b2d(ptr %state, i64 %22, ptr %21) #19
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 15252, label %bb_3B94
  ]

bb_3B94:                                          ; preds = %bb_3B2D, %entry
  %block_pc9 = add i64 15252, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 15252, ptr %26)
  %29 = call ptr @BB_3b94(ptr %state, i64 %27, ptr %26) #19
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 15258, label %bb_3B9A
  ]

bb_3B9A:                                          ; preds = %bb_41AE, %bb_3B94, %entry
  %block_pc11 = add i64 15258, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 15258, ptr %31)
  %34 = call ptr @BB_3b9a(ptr %state, i64 %32, ptr %31) #19
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 15300, label %bb_3BC4
    i64 16823, label %bb_41B7
  ]

bb_3BC4:                                          ; preds = %bb_3B9A, %entry
  %block_pc13 = add i64 15300, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 15300, ptr %36)
  %39 = call ptr @BB_3bc4(ptr %state, i64 %37, ptr %36) #19
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 15354, label %bb_3BFA
  ]

bb_3BFA:                                          ; preds = %bb_3BC4, %entry
  %block_pc15 = add i64 15354, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 15354, ptr %41)
  %44 = call ptr @BB_3bfa(ptr %state, i64 %42, ptr %41) #19
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 15423, label %bb_3C3F
  ]

bb_3C3F:                                          ; preds = %bb_3BFA, %entry
  %block_pc17 = add i64 15423, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 15423, ptr %46)
  %49 = call ptr @BB_3c3f(ptr %state, i64 %47, ptr %46) #19
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 15429, label %bb_3C45
  ]

bb_3C45:                                          ; preds = %bb_3ED7, %bb_3C3F, %entry
  %block_pc19 = add i64 15429, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 15429, ptr %51)
  %54 = call ptr @BB_3c45(ptr %state, i64 %52, ptr %51) #19
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 15483, label %bb_3C7B
  ]

bb_3C7B:                                          ; preds = %bb_3C45, %entry
  %block_pc21 = add i64 15483, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 15483, ptr %56)
  %59 = call ptr @BB_3c7b(ptr %state, i64 %57, ptr %56) #19
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 15611, label %bb_3CFB
  ]

bb_3CFB:                                          ; preds = %bb_3C7B, %entry
  %block_pc23 = add i64 15611, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 15611, ptr %61)
  %64 = call ptr @BB_3cfb(ptr %state, i64 %62, ptr %61) #19
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 15622, label %bb_3D06
    i64 15775, label %bb_3D9F
  ]

bb_3D06:                                          ; preds = %bb_3CFB, %entry
  %block_pc25 = add i64 15622, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 15622, ptr %66)
  %69 = call ptr @BB_3d06(ptr %state, i64 %67, ptr %66) #19
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 15676, label %bb_3D3C
  ]

bb_3D3C:                                          ; preds = %bb_3D06, %entry
  %block_pc27 = add i64 15676, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 15676, ptr %71)
  %74 = call ptr @BB_3d3c(ptr %state, i64 %72, ptr %71) #19
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 15763, label %bb_3D93
  ]

bb_3D93:                                          ; preds = %bb_3D3C, %entry
  %block_pc29 = add i64 15763, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 15763, ptr %76)
  %79 = call ptr @BB_3d93(ptr %state, i64 %77, ptr %76) #19
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 15775, label %bb_3D9F
  ]

bb_3D9F:                                          ; preds = %bb_3D93, %bb_3CFB, %entry
  %block_pc31 = add i64 15775, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 15775, ptr %81)
  %84 = call ptr @BB_3d9f(ptr %state, i64 %82, ptr %81) #19
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 15835, label %bb_3DDB
  ]

bb_3DDB:                                          ; preds = %bb_3D9F, %entry
  %block_pc33 = add i64 15835, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 15835, ptr %86)
  %89 = call ptr @BB_3ddb(ptr %state, i64 %87, ptr %86) #19
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  switch i64 %next_rva34, label %dead_end [
    i64 15941, label %bb_3E45
  ]

bb_3E45:                                          ; preds = %bb_3DDB, %entry
  %block_pc35 = add i64 15941, %base
  store i64 %block_pc35, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc35)
  %91 = load ptr, ptr %mem_var, align 8
  %92 = load i64, ptr %pc_var, align 4
  %93 = call ptr @__lifted_bb_entered(ptr %state, i64 15941, ptr %91)
  %94 = call ptr @BB_3e45(ptr %state, i64 %92, ptr %91) #19
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva36 = sub i64 %95, %base
  switch i64 %next_rva36, label %dead_end [
    i64 15950, label %bb_3E4E
    i64 16096, label %bb_3EE0
  ]

bb_3E4E:                                          ; preds = %bb_3E45, %entry
  %block_pc37 = add i64 15950, %base
  store i64 %block_pc37, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc37)
  %96 = load ptr, ptr %mem_var, align 8
  %97 = load i64, ptr %pc_var, align 4
  %98 = call ptr @__lifted_bb_entered(ptr %state, i64 15950, ptr %96)
  %99 = call ptr @BB_3e4e(ptr %state, i64 %97, ptr %96) #19
  store ptr %99, ptr %mem_var, align 8
  %100 = call i64 @__extract_rip(ptr %state)
  store i64 %100, ptr %pc_var, align 4
  %next_rva38 = sub i64 %100, %base
  switch i64 %next_rva38, label %dead_end [
    i64 16004, label %bb_3E84
  ]

bb_3E84:                                          ; preds = %bb_3E4E, %entry
  %block_pc39 = add i64 16004, %base
  store i64 %block_pc39, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc39)
  %101 = load ptr, ptr %mem_var, align 8
  %102 = load i64, ptr %pc_var, align 4
  %103 = call ptr @__lifted_bb_entered(ptr %state, i64 16004, ptr %101)
  %104 = call ptr @BB_3e84(ptr %state, i64 %102, ptr %101) #19
  store ptr %104, ptr %mem_var, align 8
  %105 = call i64 @__extract_rip(ptr %state)
  store i64 %105, ptr %pc_var, align 4
  %next_rva40 = sub i64 %105, %base
  switch i64 %next_rva40, label %dead_end [
    i64 16087, label %bb_3ED7
  ]

bb_3ED7:                                          ; preds = %bb_3E84, %entry
  %block_pc41 = add i64 16087, %base
  store i64 %block_pc41, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc41)
  %106 = load ptr, ptr %mem_var, align 8
  %107 = load i64, ptr %pc_var, align 4
  %108 = call ptr @__lifted_bb_entered(ptr %state, i64 16087, ptr %106)
  %109 = call ptr @BB_3ed7(ptr %state, i64 %107, ptr %106) #19
  store ptr %109, ptr %mem_var, align 8
  %110 = call i64 @__extract_rip(ptr %state)
  store i64 %110, ptr %pc_var, align 4
  %next_rva42 = sub i64 %110, %base
  switch i64 %next_rva42, label %dead_end [
    i64 15429, label %bb_3C45
  ]

bb_3EE0:                                          ; preds = %bb_3E45, %entry
  %block_pc43 = add i64 16096, %base
  store i64 %block_pc43, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc43)
  %111 = load ptr, ptr %mem_var, align 8
  %112 = load i64, ptr %pc_var, align 4
  %113 = call ptr @__lifted_bb_entered(ptr %state, i64 16096, ptr %111)
  %114 = call ptr @BB_3ee0(ptr %state, i64 %112, ptr %111) #19
  store ptr %114, ptr %mem_var, align 8
  %115 = call i64 @__extract_rip(ptr %state)
  store i64 %115, ptr %pc_var, align 4
  %next_rva44 = sub i64 %115, %base
  switch i64 %next_rva44, label %dead_end [
    i64 16150, label %bb_3F16
  ]

bb_3F16:                                          ; preds = %bb_3EE0, %entry
  %block_pc45 = add i64 16150, %base
  store i64 %block_pc45, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc45)
  %116 = load ptr, ptr %mem_var, align 8
  %117 = load i64, ptr %pc_var, align 4
  %118 = call ptr @__lifted_bb_entered(ptr %state, i64 16150, ptr %116)
  %119 = call ptr @BB_3f16(ptr %state, i64 %117, ptr %116) #19
  store ptr %119, ptr %mem_var, align 8
  %120 = call i64 @__extract_rip(ptr %state)
  store i64 %120, ptr %pc_var, align 4
  %next_rva46 = sub i64 %120, %base
  switch i64 %next_rva46, label %dead_end [
    i64 16222, label %bb_3F5E
  ]

bb_3F5E:                                          ; preds = %bb_3F16, %entry
  %block_pc47 = add i64 16222, %base
  store i64 %block_pc47, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc47)
  %121 = load ptr, ptr %mem_var, align 8
  %122 = load i64, ptr %pc_var, align 4
  %123 = call ptr @__lifted_bb_entered(ptr %state, i64 16222, ptr %121)
  %124 = call ptr @BB_3f5e(ptr %state, i64 %122, ptr %121) #19
  store ptr %124, ptr %mem_var, align 8
  %125 = call i64 @__extract_rip(ptr %state)
  store i64 %125, ptr %pc_var, align 4
  %next_rva48 = sub i64 %125, %base
  switch i64 %next_rva48, label %dead_end [
    i64 16231, label %bb_3F67
  ]

bb_3F67:                                          ; preds = %bb_4029, %bb_3F5E, %entry
  %block_pc49 = add i64 16231, %base
  store i64 %block_pc49, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc49)
  %126 = load ptr, ptr %mem_var, align 8
  %127 = load i64, ptr %pc_var, align 4
  %128 = call ptr @__lifted_bb_entered(ptr %state, i64 16231, ptr %126)
  %129 = call ptr @BB_3f67(ptr %state, i64 %127, ptr %126) #19
  store ptr %129, ptr %mem_var, align 8
  %130 = call i64 @__extract_rip(ptr %state)
  store i64 %130, ptr %pc_var, align 4
  %next_rva50 = sub i64 %130, %base
  switch i64 %next_rva50, label %dead_end [
    i64 16285, label %bb_3F9D
  ]

bb_3F9D:                                          ; preds = %bb_3F67, %entry
  %block_pc51 = add i64 16285, %base
  store i64 %block_pc51, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc51)
  %131 = load ptr, ptr %mem_var, align 8
  %132 = load i64, ptr %pc_var, align 4
  %133 = call ptr @__lifted_bb_entered(ptr %state, i64 16285, ptr %131)
  %134 = call ptr @BB_3f9d(ptr %state, i64 %132, ptr %131) #19
  store ptr %134, ptr %mem_var, align 8
  %135 = call i64 @__extract_rip(ptr %state)
  store i64 %135, ptr %pc_var, align 4
  %next_rva52 = sub i64 %135, %base
  switch i64 %next_rva52, label %dead_end [
    i64 16416, label %bb_4020
  ]

bb_4020:                                          ; preds = %bb_3F9D, %entry
  %block_pc53 = add i64 16416, %base
  store i64 %block_pc53, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc53)
  %136 = load ptr, ptr %mem_var, align 8
  %137 = load i64, ptr %pc_var, align 4
  %138 = call ptr @__lifted_bb_entered(ptr %state, i64 16416, ptr %136)
  %139 = call ptr @BB_4020(ptr %state, i64 %137, ptr %136) #19
  store ptr %139, ptr %mem_var, align 8
  %140 = call i64 @__extract_rip(ptr %state)
  store i64 %140, ptr %pc_var, align 4
  %next_rva54 = sub i64 %140, %base
  switch i64 %next_rva54, label %dead_end [
    i64 16425, label %bb_4029
    i64 16444, label %bb_403C
  ]

bb_4029:                                          ; preds = %bb_4020, %entry
  %block_pc55 = add i64 16425, %base
  store i64 %block_pc55, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc55)
  %141 = load ptr, ptr %mem_var, align 8
  %142 = load i64, ptr %pc_var, align 4
  %143 = call ptr @__lifted_bb_entered(ptr %state, i64 16425, ptr %141)
  %144 = call ptr @BB_4029(ptr %state, i64 %142, ptr %141) #19
  store ptr %144, ptr %mem_var, align 8
  %145 = call i64 @__extract_rip(ptr %state)
  store i64 %145, ptr %pc_var, align 4
  %next_rva56 = sub i64 %145, %base
  switch i64 %next_rva56, label %dead_end [
    i64 16231, label %bb_3F67
  ]

bb_403C:                                          ; preds = %bb_4020, %entry
  %block_pc57 = add i64 16444, %base
  store i64 %block_pc57, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc57)
  %146 = load ptr, ptr %mem_var, align 8
  %147 = load i64, ptr %pc_var, align 4
  %148 = call ptr @__lifted_bb_entered(ptr %state, i64 16444, ptr %146)
  %149 = call ptr @BB_403c(ptr %state, i64 %147, ptr %146) #19
  store ptr %149, ptr %mem_var, align 8
  %150 = call i64 @__extract_rip(ptr %state)
  store i64 %150, ptr %pc_var, align 4
  %next_rva58 = sub i64 %150, %base
  switch i64 %next_rva58, label %dead_end [
    i64 16498, label %bb_4072
  ]

bb_4072:                                          ; preds = %bb_403C, %entry
  %block_pc59 = add i64 16498, %base
  store i64 %block_pc59, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc59)
  %151 = load ptr, ptr %mem_var, align 8
  %152 = load i64, ptr %pc_var, align 4
  %153 = call ptr @__lifted_bb_entered(ptr %state, i64 16498, ptr %151)
  %154 = call ptr @BB_4072(ptr %state, i64 %152, ptr %151) #19
  store ptr %154, ptr %mem_var, align 8
  %155 = call i64 @__extract_rip(ptr %state)
  store i64 %155, ptr %pc_var, align 4
  %next_rva60 = sub i64 %155, %base
  switch i64 %next_rva60, label %dead_end [
    i64 16611, label %bb_40E3
  ]

bb_40E3:                                          ; preds = %bb_4072, %entry
  %block_pc61 = add i64 16611, %base
  store i64 %block_pc61, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc61)
  %156 = load ptr, ptr %mem_var, align 8
  %157 = load i64, ptr %pc_var, align 4
  %158 = call ptr @__lifted_bb_entered(ptr %state, i64 16611, ptr %156)
  %159 = call ptr @BB_40e3(ptr %state, i64 %157, ptr %156) #19
  store ptr %159, ptr %mem_var, align 8
  %160 = call i64 @__extract_rip(ptr %state)
  store i64 %160, ptr %pc_var, align 4
  %next_rva62 = sub i64 %160, %base
  switch i64 %next_rva62, label %dead_end [
    i64 16620, label %bb_40EC
    i64 16814, label %bb_41AE
  ]

bb_40EC:                                          ; preds = %bb_40E3, %entry
  %block_pc63 = add i64 16620, %base
  store i64 %block_pc63, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc63)
  %161 = load ptr, ptr %mem_var, align 8
  %162 = load i64, ptr %pc_var, align 4
  %163 = call ptr @__lifted_bb_entered(ptr %state, i64 16620, ptr %161)
  %164 = call ptr @BB_40ec(ptr %state, i64 %162, ptr %161) #19
  store ptr %164, ptr %mem_var, align 8
  %165 = call i64 @__extract_rip(ptr %state)
  store i64 %165, ptr %pc_var, align 4
  %next_rva64 = sub i64 %165, %base
  switch i64 %next_rva64, label %dead_end [
    i64 16674, label %bb_4122
  ]

bb_4122:                                          ; preds = %bb_40EC, %entry
  %block_pc65 = add i64 16674, %base
  store i64 %block_pc65, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc65)
  %166 = load ptr, ptr %mem_var, align 8
  %167 = load i64, ptr %pc_var, align 4
  %168 = call ptr @__lifted_bb_entered(ptr %state, i64 16674, ptr %166)
  %169 = call ptr @BB_4122(ptr %state, i64 %167, ptr %166) #19
  store ptr %169, ptr %mem_var, align 8
  %170 = call i64 @__extract_rip(ptr %state)
  store i64 %170, ptr %pc_var, align 4
  %next_rva66 = sub i64 %170, %base
  switch i64 %next_rva66, label %dead_end [
    i64 16805, label %bb_41A5
  ]

bb_41A5:                                          ; preds = %bb_4122, %entry
  %block_pc67 = add i64 16805, %base
  store i64 %block_pc67, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc67)
  %171 = load ptr, ptr %mem_var, align 8
  %172 = load i64, ptr %pc_var, align 4
  %173 = call ptr @__lifted_bb_entered(ptr %state, i64 16805, ptr %171)
  %174 = call ptr @BB_41a5(ptr %state, i64 %172, ptr %171) #19
  store ptr %174, ptr %mem_var, align 8
  %175 = call i64 @__extract_rip(ptr %state)
  store i64 %175, ptr %pc_var, align 4
  %next_rva68 = sub i64 %175, %base
  switch i64 %next_rva68, label %dead_end [
    i64 16814, label %bb_41AE
  ]

bb_41AE:                                          ; preds = %bb_41A5, %bb_40E3, %entry
  %block_pc69 = add i64 16814, %base
  store i64 %block_pc69, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc69)
  %176 = load ptr, ptr %mem_var, align 8
  %177 = load i64, ptr %pc_var, align 4
  %178 = call ptr @__lifted_bb_entered(ptr %state, i64 16814, ptr %176)
  %179 = call ptr @BB_41ae(ptr %state, i64 %177, ptr %176) #19
  store ptr %179, ptr %mem_var, align 8
  %180 = call i64 @__extract_rip(ptr %state)
  store i64 %180, ptr %pc_var, align 4
  %next_rva70 = sub i64 %180, %base
  switch i64 %next_rva70, label %dead_end [
    i64 15258, label %bb_3B9A
  ]

bb_41B7:                                          ; preds = %bb_3B9A, %entry
  %block_pc71 = add i64 16823, %base
  store i64 %block_pc71, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc71)
  %181 = load ptr, ptr %mem_var, align 8
  %182 = load i64, ptr %pc_var, align 4
  %183 = call ptr @__lifted_bb_entered(ptr %state, i64 16823, ptr %181)
  %184 = call ptr @BB_41b7(ptr %state, i64 %182, ptr %181) #19
  store ptr %184, ptr %mem_var, align 8
  %185 = call i64 @__extract_rip(ptr %state)
  store i64 %185, ptr %pc_var, align 4
  %next_rva72 = sub i64 %185, %base
  switch i64 %next_rva72, label %dead_end [
    i64 16877, label %bb_41ED
  ]

bb_41ED:                                          ; preds = %bb_41B7, %entry
  %block_pc73 = add i64 16877, %base
  store i64 %block_pc73, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc73)
  %186 = load ptr, ptr %mem_var, align 8
  %187 = load i64, ptr %pc_var, align 4
  %188 = call ptr @__lifted_bb_entered(ptr %state, i64 16877, ptr %186)
  %189 = call ptr @BB_41ed(ptr %state, i64 %187, ptr %186) #19
  store ptr %189, ptr %mem_var, align 8
  %190 = call i64 @__extract_rip(ptr %state)
  store i64 %190, ptr %pc_var, align 4
  %next_rva74 = sub i64 %190, %base
  switch i64 %next_rva74, label %dead_end [
    i64 14800, label %bb_FFFF000000000000
  ]

bb_4247:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc75 = add i64 16967, %base
  store i64 %block_pc75, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc75)
  %191 = load ptr, ptr %mem_var, align 8
  %192 = load i64, ptr %pc_var, align 4
  %193 = call ptr @__lifted_bb_entered(ptr %state, i64 16967, ptr %191)
  %194 = call ptr @BB_4247(ptr %state, i64 %192, ptr %191) #19
  store ptr %194, ptr %mem_var, align 8
  %195 = call i64 @__extract_rip(ptr %state)
  store i64 %195, ptr %pc_var, align 4
  %next_rva76 = sub i64 %195, %base
  switch i64 %next_rva76, label %dead_end [
    i64 14800, label %bb_FFFF000000000001
  ]

bb_426C:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc77 = add i64 17004, %base
  store i64 %block_pc77, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc77)
  %196 = load ptr, ptr %mem_var, align 8
  %197 = load i64, ptr %pc_var, align 4
  %198 = call ptr @__lifted_bb_entered(ptr %state, i64 17004, ptr %196)
  %199 = call ptr @BB_426c(ptr %state, i64 %197, ptr %196) #19
  store ptr %199, ptr %mem_var, align 8
  %200 = call i64 @__extract_rip(ptr %state)
  store i64 %200, ptr %pc_var, align 4
  %next_rva78 = sub i64 %200, %base
  switch i64 %next_rva78, label %dead_end [
    i64 17076, label %bb_42B4
  ]

bb_42B4:                                          ; preds = %bb_426C, %entry
  %block_pc79 = add i64 17076, %base
  store i64 %block_pc79, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc79)
  %201 = load ptr, ptr %mem_var, align 8
  %202 = load i64, ptr %pc_var, align 4
  %203 = call ptr @__lifted_bb_entered(ptr %state, i64 17076, ptr %201)
  %204 = call ptr @BB_42b4(ptr %state, i64 %202, ptr %201) #19
  store ptr %204, ptr %mem_var, align 8
  %205 = call i64 @__extract_rip(ptr %state)
  store i64 %205, ptr %pc_var, align 4
  %next_rva80 = sub i64 %205, %base
  switch i64 %next_rva80, label %dead_end [
    i64 17085, label %bb_42BD
  ]

bb_42BD:                                          ; preds = %bb_42B4, %bb_3AF1, %entry
  %block_pc81 = add i64 17085, %base
  store i64 %block_pc81, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc81)
  %206 = load ptr, ptr %mem_var, align 8
  %207 = load i64, ptr %pc_var, align 4
  %208 = call ptr @__lifted_bb_entered(ptr %state, i64 17085, ptr %206)
  %209 = call ptr @BB_42bd(ptr %state, i64 %207, ptr %206) #19
  store ptr %209, ptr %mem_var, align 8
  %210 = call i64 @__extract_rip(ptr %state)
  store i64 %210, ptr %pc_var, align 4
  %next_rva82 = sub i64 %210, %base
  switch i64 %next_rva82, label %dead_end [
    i64 17139, label %bb_42F3
  ]

bb_42F3:                                          ; preds = %bb_42BD, %entry
  %block_pc83 = add i64 17139, %base
  store i64 %block_pc83, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc83)
  %211 = load ptr, ptr %mem_var, align 8
  %212 = load i64, ptr %pc_var, align 4
  %213 = call ptr @__lifted_bb_entered(ptr %state, i64 17139, ptr %211)
  %214 = call ptr @BB_42f3(ptr %state, i64 %212, ptr %211) #19
  store ptr %214, ptr %mem_var, align 8
  %215 = call i64 @__extract_rip(ptr %state)
  store i64 %215, ptr %pc_var, align 4
  %next_rva84 = sub i64 %215, %base
  switch i64 %next_rva84, label %dead_end [
    i64 17193, label %bb_4329
  ]

bb_4329:                                          ; preds = %bb_42F3, %entry
  %block_pc85 = add i64 17193, %base
  store i64 %block_pc85, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc85)
  %216 = load ptr, ptr %mem_var, align 8
  %217 = load i64, ptr %pc_var, align 4
  %218 = call ptr @__lifted_bb_entered(ptr %state, i64 17193, ptr %216)
  %219 = call ptr @BB_4329(ptr %state, i64 %217, ptr %216) #19
  store ptr %219, ptr %mem_var, align 8
  %220 = call i64 @__extract_rip(ptr %state)
  store i64 %220, ptr %pc_var, align 4
  %next_rva86 = sub i64 %220, %base
  %221 = load ptr, ptr %mem_var, align 8
  ret ptr %221

bb_FFFF000000000000:                              ; preds = %bb_41ED, %entry
  %222 = load ptr, ptr %mem_var, align 8
  %223 = load i64, ptr %pc_var, align 4
  %224 = call ptr @BB_ffff000000000000_recur(ptr %state, i64 %223, ptr %222) #19
  store ptr %224, ptr %mem_var, align 8
  %225 = call i64 @__extract_rip(ptr %state)
  store i64 %225, ptr %pc_var, align 4
  %next_rva87 = sub i64 %225, %base
  switch i64 %next_rva87, label %dead_end [
    i64 16967, label %bb_4247
  ]

bb_FFFF000000000001:                              ; preds = %bb_4247, %entry
  %226 = load ptr, ptr %mem_var, align 8
  %227 = load i64, ptr %pc_var, align 4
  %228 = call ptr @BB_ffff000000000001_recur(ptr %state, i64 %227, ptr %226) #19
  store ptr %228, ptr %mem_var, align 8
  %229 = call i64 @__extract_rip(ptr %state)
  store i64 %229, ptr %pc_var, align 4
  %next_rva88 = sub i64 %229, %base
  switch i64 %next_rva88, label %dead_end [
    i64 17004, label %bb_426C
  ]

return_bb:                                        ; No predecessors!
  %230 = load ptr, ptr %mem_var, align 8
  ret ptr %230
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #11 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 14800, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #12 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #12 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #12 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #12 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #12 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #13 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.379546, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !23
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "disable-tail-calls"="true" "lifted.annotation_id"="2" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #18 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #19 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24, !24, i64 0}
!24 = !{!"omnipotent char", !25, i64 0}
!25 = !{!"Simple C++ TBAA"}
