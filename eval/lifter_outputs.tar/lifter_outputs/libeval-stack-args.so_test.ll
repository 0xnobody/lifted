; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.1599 = type { %struct.X86State.1598 }
%struct.X86State.1598 = type { %struct.ArchState.1567, [32 x %union.VectorReg.1570], %struct.ArithFlags.1571, %union.anon.1566, %struct.Segments.1573, %struct.AddressSpace.1575, %struct.GPR.1576, %struct.X87Stack.1579, %struct.MMX.1583, %struct.FPUStatusFlags.1584, %union.anon.1566, %union.FPU.1593, %struct.SegmentCaches.1595, %struct.K_REG.1597 }
%struct.ArchState.1567 = type { i32, i32, %union.anon.1566 }
%union.VectorReg.1570 = type { %union.vec512_t.1569 }
%union.vec512_t.1569 = type { %struct.uint64v8_t.1568 }
%struct.uint64v8_t.1568 = type { [8 x i64] }
%struct.ArithFlags.1571 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.1573 = type { i16, %union.SegmentSelector.1572, i16, %union.SegmentSelector.1572, i16, %union.SegmentSelector.1572, i16, %union.SegmentSelector.1572, i16, %union.SegmentSelector.1572, i16, %union.SegmentSelector.1572 }
%union.SegmentSelector.1572 = type { i16 }
%struct.AddressSpace.1575 = type { i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574 }
%struct.Reg.1574 = type { %union.anon.1566 }
%struct.GPR.1576 = type { i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574, i64, %struct.Reg.1574 }
%struct.X87Stack.1579 = type { [8 x %struct.anon.3.1578] }
%struct.anon.3.1578 = type { [6 x i8], %struct.float80_t.1577 }
%struct.float80_t.1577 = type { [10 x i8] }
%struct.MMX.1583 = type { [8 x %struct.anon.4.1582] }
%struct.anon.4.1582 = type { i64, %union.vec64_t.1581 }
%union.vec64_t.1581 = type { %struct.uint64v1_t.1580 }
%struct.uint64v1_t.1580 = type { [1 x i64] }
%struct.FPUStatusFlags.1584 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.1566 = type { i64 }
%union.FPU.1593 = type { %struct.anon.13.1592 }
%struct.anon.13.1592 = type { %struct.FpuFXSAVE.1591, [96 x i8] }
%struct.FpuFXSAVE.1591 = type { %union.SegmentSelector.1572, %union.SegmentSelector.1572, %union.FPUAbridgedTagWord.1585, i8, i16, i32, %union.SegmentSelector.1572, i16, i32, %union.SegmentSelector.1572, i16, %union.FPUControlStatus.1586, %union.FPUControlStatus.1586, [8 x %struct.FPUStackElem.1588], [16 x %union.vec128_t.1590] }
%union.FPUAbridgedTagWord.1585 = type { i8 }
%union.FPUControlStatus.1586 = type { i32 }
%struct.FPUStackElem.1588 = type { %union.anon.11.1587, [6 x i8] }
%union.anon.11.1587 = type { %struct.float80_t.1577 }
%union.vec128_t.1590 = type { %struct.uint128v1_t.1589 }
%struct.uint128v1_t.1589 = type { [1 x i128] }
%struct.SegmentCaches.1595 = type { %struct.SegmentShadow.1594, %struct.SegmentShadow.1594, %struct.SegmentShadow.1594, %struct.SegmentShadow.1594, %struct.SegmentShadow.1594, %struct.SegmentShadow.1594 }
%struct.SegmentShadow.1594 = type { %union.anon.1566, i32, i32 }
%struct.K_REG.1597 = type { [8 x %struct.anon.18.1596] }
%struct.anon.18.1596 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_10f9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %R9D = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.1599, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i279 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i279, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 4
  %25 = load i32, ptr %EDI, align 4
  %26 = zext i32 %25 to i64
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i255 = call ptr @__remill_write_memory_32(ptr noundef %27, i64 noundef %24, i32 noundef %25) #13
  store ptr %call.i.i255, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 8
  %33 = load i32, ptr %ESI, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i254 = call ptr @__remill_write_memory_32(ptr noundef %35, i64 noundef %32, i32 noundef %33) #13
  store ptr %call.i.i254, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %28
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 12
  %41 = load i32, ptr %EDX, align 4
  %42 = zext i32 %41 to i64
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i253 = call ptr @__remill_write_memory_32(ptr noundef %43, i64 noundef %40, i32 noundef %41) #13
  store ptr %call.i.i253, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %36
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 3
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 16
  %49 = load i32, ptr %ECX, align 4
  %50 = zext i32 %49 to i64
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i252 = call ptr @__remill_write_memory_32(ptr noundef %51, i64 noundef %48, i32 noundef %49) #13
  store ptr %call.i.i252, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %44
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 4
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RBP, align 8
  %56 = sub i64 %55, 20
  %57 = load i32, ptr %R8D, align 4
  %58 = zext i32 %57 to i64
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i251 = call ptr @__remill_write_memory_32(ptr noundef %59, i64 noundef %56, i32 noundef %57) #13
  store ptr %call.i.i251, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %52
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 4
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RBP, align 8
  %64 = sub i64 %63, 24
  %65 = load i32, ptr %R9D, align 4
  %66 = zext i32 %65 to i64
  %67 = load ptr, ptr %MEMORY, align 8
  %call.i.i250 = call ptr @__remill_write_memory_32(ptr noundef %67, i64 noundef %64, i32 noundef %65) #13
  store ptr %call.i.i250, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %60
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RBP, align 8
  %72 = sub i64 %71, 4
  %73 = load ptr, ptr %MEMORY, align 8
  %call.i.i274 = call i32 @__remill_read_memory_32(ptr noundef %73, i64 noundef %72) #13
  %conv.i.i275 = zext i32 %call.i.i274 to i64
  store i64 %conv.i.i275, ptr %RDX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RBP, align 8
  %78 = sub i64 %77, 8
  %79 = load ptr, ptr %MEMORY, align 8
  %call.i.i272 = call i32 @__remill_read_memory_32(ptr noundef %79, i64 noundef %78) #13
  %conv.i.i273 = zext i32 %call.i.i272 to i64
  store i64 %conv.i.i273, ptr %RAX, align 8
  store ptr %79, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %74
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 2
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RDX, align 8
  %84 = load i32, ptr %EAX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i218 = trunc i64 %83 to i32
  %add.i.i219 = add i32 %84, %conv.i.i218
  %conv.i22.i220 = zext i32 %add.i.i219 to i64
  store i64 %conv.i22.i220, ptr %RDX, align 8
  %cmp.i.i.i221 = icmp ult i32 %add.i.i219, %conv.i.i218
  %cmp1.i.i.i222 = icmp ult i32 %add.i.i219, %84
  %87 = or i1 %cmp.i.i.i221, %cmp1.i.i.i222
  %call.i.i.i223 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %87, i32 noundef %conv.i.i218, i32 noundef %84, i32 noundef %add.i.i219) #13
  %conv.i23.i224 = zext i1 %call.i.i.i223 to i8
  %cf.i.i225 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i224, ptr %cf.i.i225, align 1
  %conv.i.i.i.i226 = trunc i32 %add.i.i219 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i226)
  %89 = and i8 %88, 1
  %conv.i.i.i227 = xor i8 %89, 1
  %pf.i.i.i228 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i227, ptr %pf.i.i.i228, align 1
  %xor.i.i.i.i229 = xor i32 %add.i.i219, %84
  %xor1.i.i.i.i230 = xor i32 %xor.i.i.i.i229, %conv.i.i218
  %90 = trunc i32 %xor1.i.i.i.i230 to i8
  %91 = lshr i8 %90, 4
  %conv2.i.i.i231 = and i8 %91, 1
  %af.i.i.i232 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i231, ptr %af.i.i.i232, align 1
  %cmp.i.i.i.i233 = icmp eq i32 %add.i.i219, 0
  %call.i.i.i.i234 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i233, i32 noundef %conv.i.i218, i32 noundef %84, i32 noundef %add.i.i219) #13
  %conv5.i.i.i235 = zext i1 %call.i.i.i.i234 to i8
  %zf.i.i.i236 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i235, ptr %zf.i.i.i236, align 1
  %cmp.i27.i.i.i237 = icmp slt i32 %add.i.i219, 0
  %call1.i.i.i.i238 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i237, i32 noundef %conv.i.i218, i32 noundef %84, i32 noundef %add.i.i219) #13
  %conv8.i.i.i239 = zext i1 %call1.i.i.i.i238 to i8
  %sf.i.i.i240 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i239, ptr %sf.i.i.i240, align 1
  %shr8.i.i.i.i241 = xor i32 %add.i.i219, %conv.i.i218
  %xor.i28.i.i.i242 = lshr i32 %shr8.i.i.i.i241, 31
  %xor3.i.i.i.i243 = lshr i32 %xor.i.i.i.i229, 31
  %add.i.i.i.i244 = add nuw nsw i32 %xor.i28.i.i.i242, %xor3.i.i.i.i243
  %cmp.i29.i.i.i245 = icmp eq i32 %add.i.i.i.i244, 2
  %call.i30.i.i.i246 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i245, i32 noundef %conv.i.i218, i32 noundef %84, i32 noundef %add.i.i219) #13
  %conv11.i.i.i247 = zext i1 %call.i30.i.i.i246 to i8
  %of.i.i.i248 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i247, ptr %of.i.i.i248, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %80
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RBP, align 8
  %96 = sub i64 %95, 12
  %97 = load ptr, ptr %MEMORY, align 8
  %call.i.i270 = call i32 @__remill_read_memory_32(ptr noundef %97, i64 noundef %96) #13
  %conv.i.i271 = zext i32 %call.i.i270 to i64
  store i64 %conv.i.i271, ptr %RAX, align 8
  store ptr %97, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 2
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RDX, align 8
  %102 = load i32, ptr %EAX, align 4
  %103 = zext i32 %102 to i64
  %104 = load ptr, ptr %MEMORY, align 8
  %conv.i.i187 = trunc i64 %101 to i32
  %add.i.i188 = add i32 %102, %conv.i.i187
  %conv.i22.i189 = zext i32 %add.i.i188 to i64
  store i64 %conv.i22.i189, ptr %RDX, align 8
  %cmp.i.i.i190 = icmp ult i32 %add.i.i188, %conv.i.i187
  %cmp1.i.i.i191 = icmp ult i32 %add.i.i188, %102
  %105 = or i1 %cmp.i.i.i190, %cmp1.i.i.i191
  %call.i.i.i192 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %105, i32 noundef %conv.i.i187, i32 noundef %102, i32 noundef %add.i.i188) #13
  %conv.i23.i193 = zext i1 %call.i.i.i192 to i8
  %cf.i.i194 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i193, ptr %cf.i.i194, align 1
  %conv.i.i.i.i195 = trunc i32 %add.i.i188 to i8
  %106 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i195)
  %107 = and i8 %106, 1
  %conv.i.i.i196 = xor i8 %107, 1
  %pf.i.i.i197 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i196, ptr %pf.i.i.i197, align 1
  %xor.i.i.i.i198 = xor i32 %add.i.i188, %102
  %xor1.i.i.i.i199 = xor i32 %xor.i.i.i.i198, %conv.i.i187
  %108 = trunc i32 %xor1.i.i.i.i199 to i8
  %109 = lshr i8 %108, 4
  %conv2.i.i.i200 = and i8 %109, 1
  %af.i.i.i201 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i200, ptr %af.i.i.i201, align 1
  %cmp.i.i.i.i202 = icmp eq i32 %add.i.i188, 0
  %call.i.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i202, i32 noundef %conv.i.i187, i32 noundef %102, i32 noundef %add.i.i188) #13
  %conv5.i.i.i204 = zext i1 %call.i.i.i.i203 to i8
  %zf.i.i.i205 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i204, ptr %zf.i.i.i205, align 1
  %cmp.i27.i.i.i206 = icmp slt i32 %add.i.i188, 0
  %call1.i.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i206, i32 noundef %conv.i.i187, i32 noundef %102, i32 noundef %add.i.i188) #13
  %conv8.i.i.i208 = zext i1 %call1.i.i.i.i207 to i8
  %sf.i.i.i209 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i208, ptr %sf.i.i.i209, align 1
  %shr8.i.i.i.i210 = xor i32 %add.i.i188, %conv.i.i187
  %xor.i28.i.i.i211 = lshr i32 %shr8.i.i.i.i210, 31
  %xor3.i.i.i.i212 = lshr i32 %xor.i.i.i.i198, 31
  %add.i.i.i.i213 = add nuw nsw i32 %xor.i28.i.i.i211, %xor3.i.i.i.i212
  %cmp.i29.i.i.i214 = icmp eq i32 %add.i.i.i.i213, 2
  %call.i30.i.i.i215 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i214, i32 noundef %conv.i.i187, i32 noundef %102, i32 noundef %add.i.i188) #13
  %conv11.i.i.i216 = zext i1 %call.i30.i.i.i215 to i8
  %of.i.i.i217 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i216, ptr %of.i.i.i217, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %110

110:                                              ; preds = %98
  %111 = load i64, ptr %NEXT_PC, align 8
  store i64 %111, ptr %PC, align 8
  %112 = add i64 %111, 3
  store i64 %112, ptr %NEXT_PC, align 8
  %113 = load i64, ptr %RBP, align 8
  %114 = sub i64 %113, 16
  %115 = load ptr, ptr %MEMORY, align 8
  %call.i.i268 = call i32 @__remill_read_memory_32(ptr noundef %115, i64 noundef %114) #13
  %conv.i.i269 = zext i32 %call.i.i268 to i64
  store i64 %conv.i.i269, ptr %RAX, align 8
  store ptr %115, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %110
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 2
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %RDX, align 8
  %120 = load i32, ptr %EAX, align 4
  %121 = zext i32 %120 to i64
  %122 = load ptr, ptr %MEMORY, align 8
  %conv.i.i156 = trunc i64 %119 to i32
  %add.i.i157 = add i32 %120, %conv.i.i156
  %conv.i22.i158 = zext i32 %add.i.i157 to i64
  store i64 %conv.i22.i158, ptr %RDX, align 8
  %cmp.i.i.i159 = icmp ult i32 %add.i.i157, %conv.i.i156
  %cmp1.i.i.i160 = icmp ult i32 %add.i.i157, %120
  %123 = or i1 %cmp.i.i.i159, %cmp1.i.i.i160
  %call.i.i.i161 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %123, i32 noundef %conv.i.i156, i32 noundef %120, i32 noundef %add.i.i157) #13
  %conv.i23.i162 = zext i1 %call.i.i.i161 to i8
  %cf.i.i163 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i162, ptr %cf.i.i163, align 1
  %conv.i.i.i.i164 = trunc i32 %add.i.i157 to i8
  %124 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i164)
  %125 = and i8 %124, 1
  %conv.i.i.i165 = xor i8 %125, 1
  %pf.i.i.i166 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i165, ptr %pf.i.i.i166, align 1
  %xor.i.i.i.i167 = xor i32 %add.i.i157, %120
  %xor1.i.i.i.i168 = xor i32 %xor.i.i.i.i167, %conv.i.i156
  %126 = trunc i32 %xor1.i.i.i.i168 to i8
  %127 = lshr i8 %126, 4
  %conv2.i.i.i169 = and i8 %127, 1
  %af.i.i.i170 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i169, ptr %af.i.i.i170, align 1
  %cmp.i.i.i.i171 = icmp eq i32 %add.i.i157, 0
  %call.i.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i171, i32 noundef %conv.i.i156, i32 noundef %120, i32 noundef %add.i.i157) #13
  %conv5.i.i.i173 = zext i1 %call.i.i.i.i172 to i8
  %zf.i.i.i174 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i173, ptr %zf.i.i.i174, align 1
  %cmp.i27.i.i.i175 = icmp slt i32 %add.i.i157, 0
  %call1.i.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i175, i32 noundef %conv.i.i156, i32 noundef %120, i32 noundef %add.i.i157) #13
  %conv8.i.i.i177 = zext i1 %call1.i.i.i.i176 to i8
  %sf.i.i.i178 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i177, ptr %sf.i.i.i178, align 1
  %shr8.i.i.i.i179 = xor i32 %add.i.i157, %conv.i.i156
  %xor.i28.i.i.i180 = lshr i32 %shr8.i.i.i.i179, 31
  %xor3.i.i.i.i181 = lshr i32 %xor.i.i.i.i167, 31
  %add.i.i.i.i182 = add nuw nsw i32 %xor.i28.i.i.i180, %xor3.i.i.i.i181
  %cmp.i29.i.i.i183 = icmp eq i32 %add.i.i.i.i182, 2
  %call.i30.i.i.i184 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i183, i32 noundef %conv.i.i156, i32 noundef %120, i32 noundef %add.i.i157) #13
  %conv11.i.i.i185 = zext i1 %call.i30.i.i.i184 to i8
  %of.i.i.i186 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i185, ptr %of.i.i.i186, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %116
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 3
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load i64, ptr %RBP, align 8
  %132 = sub i64 %131, 20
  %133 = load ptr, ptr %MEMORY, align 8
  %call.i.i266 = call i32 @__remill_read_memory_32(ptr noundef %133, i64 noundef %132) #13
  %conv.i.i267 = zext i32 %call.i.i266 to i64
  store i64 %conv.i.i267, ptr %RAX, align 8
  store ptr %133, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %128
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 2
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RDX, align 8
  %138 = load i32, ptr %EAX, align 4
  %139 = zext i32 %138 to i64
  %140 = load ptr, ptr %MEMORY, align 8
  %conv.i.i125 = trunc i64 %137 to i32
  %add.i.i126 = add i32 %138, %conv.i.i125
  %conv.i22.i127 = zext i32 %add.i.i126 to i64
  store i64 %conv.i22.i127, ptr %RDX, align 8
  %cmp.i.i.i128 = icmp ult i32 %add.i.i126, %conv.i.i125
  %cmp1.i.i.i129 = icmp ult i32 %add.i.i126, %138
  %141 = or i1 %cmp.i.i.i128, %cmp1.i.i.i129
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %141, i32 noundef %conv.i.i125, i32 noundef %138, i32 noundef %add.i.i126) #13
  %conv.i23.i131 = zext i1 %call.i.i.i130 to i8
  %cf.i.i132 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i131, ptr %cf.i.i132, align 1
  %conv.i.i.i.i133 = trunc i32 %add.i.i126 to i8
  %142 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i133)
  %143 = and i8 %142, 1
  %conv.i.i.i134 = xor i8 %143, 1
  %pf.i.i.i135 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i134, ptr %pf.i.i.i135, align 1
  %xor.i.i.i.i136 = xor i32 %add.i.i126, %138
  %xor1.i.i.i.i137 = xor i32 %xor.i.i.i.i136, %conv.i.i125
  %144 = trunc i32 %xor1.i.i.i.i137 to i8
  %145 = lshr i8 %144, 4
  %conv2.i.i.i138 = and i8 %145, 1
  %af.i.i.i139 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i138, ptr %af.i.i.i139, align 1
  %cmp.i.i.i.i140 = icmp eq i32 %add.i.i126, 0
  %call.i.i.i.i141 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i140, i32 noundef %conv.i.i125, i32 noundef %138, i32 noundef %add.i.i126) #13
  %conv5.i.i.i142 = zext i1 %call.i.i.i.i141 to i8
  %zf.i.i.i143 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i142, ptr %zf.i.i.i143, align 1
  %cmp.i27.i.i.i144 = icmp slt i32 %add.i.i126, 0
  %call1.i.i.i.i145 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i144, i32 noundef %conv.i.i125, i32 noundef %138, i32 noundef %add.i.i126) #13
  %conv8.i.i.i146 = zext i1 %call1.i.i.i.i145 to i8
  %sf.i.i.i147 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i146, ptr %sf.i.i.i147, align 1
  %shr8.i.i.i.i148 = xor i32 %add.i.i126, %conv.i.i125
  %xor.i28.i.i.i149 = lshr i32 %shr8.i.i.i.i148, 31
  %xor3.i.i.i.i150 = lshr i32 %xor.i.i.i.i136, 31
  %add.i.i.i.i151 = add nuw nsw i32 %xor.i28.i.i.i149, %xor3.i.i.i.i150
  %cmp.i29.i.i.i152 = icmp eq i32 %add.i.i.i.i151, 2
  %call.i30.i.i.i153 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i152, i32 noundef %conv.i.i125, i32 noundef %138, i32 noundef %add.i.i126) #13
  %conv11.i.i.i154 = zext i1 %call.i30.i.i.i153 to i8
  %of.i.i.i155 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i154, ptr %of.i.i.i155, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %134
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 3
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %RBP, align 8
  %150 = sub i64 %149, 24
  %151 = load ptr, ptr %MEMORY, align 8
  %call.i.i264 = call i32 @__remill_read_memory_32(ptr noundef %151, i64 noundef %150) #13
  %conv.i.i265 = zext i32 %call.i.i264 to i64
  store i64 %conv.i.i265, ptr %RAX, align 8
  store ptr %151, ptr %MEMORY, align 8
  br label %152

152:                                              ; preds = %146
  %153 = load i64, ptr %NEXT_PC, align 8
  store i64 %153, ptr %PC, align 8
  %154 = add i64 %153, 2
  store i64 %154, ptr %NEXT_PC, align 8
  %155 = load i64, ptr %RDX, align 8
  %156 = load i32, ptr %EAX, align 4
  %157 = zext i32 %156 to i64
  %158 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %155 to i32
  %add.i.i95 = add i32 %156, %conv.i.i94
  %conv.i22.i96 = zext i32 %add.i.i95 to i64
  store i64 %conv.i22.i96, ptr %RDX, align 8
  %cmp.i.i.i97 = icmp ult i32 %add.i.i95, %conv.i.i94
  %cmp1.i.i.i98 = icmp ult i32 %add.i.i95, %156
  %159 = or i1 %cmp.i.i.i97, %cmp1.i.i.i98
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %159, i32 noundef %conv.i.i94, i32 noundef %156, i32 noundef %add.i.i95) #13
  %conv.i23.i100 = zext i1 %call.i.i.i99 to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i100, ptr %cf.i.i101, align 1
  %conv.i.i.i.i102 = trunc i32 %add.i.i95 to i8
  %160 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i102)
  %161 = and i8 %160, 1
  %conv.i.i.i103 = xor i8 %161, 1
  %pf.i.i.i104 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i103, ptr %pf.i.i.i104, align 1
  %xor.i.i.i.i105 = xor i32 %add.i.i95, %156
  %xor1.i.i.i.i106 = xor i32 %xor.i.i.i.i105, %conv.i.i94
  %162 = trunc i32 %xor1.i.i.i.i106 to i8
  %163 = lshr i8 %162, 4
  %conv2.i.i.i107 = and i8 %163, 1
  %af.i.i.i108 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i107, ptr %af.i.i.i108, align 1
  %cmp.i.i.i.i109 = icmp eq i32 %add.i.i95, 0
  %call.i.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i109, i32 noundef %conv.i.i94, i32 noundef %156, i32 noundef %add.i.i95) #13
  %conv5.i.i.i111 = zext i1 %call.i.i.i.i110 to i8
  %zf.i.i.i112 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i111, ptr %zf.i.i.i112, align 1
  %cmp.i27.i.i.i113 = icmp slt i32 %add.i.i95, 0
  %call1.i.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i113, i32 noundef %conv.i.i94, i32 noundef %156, i32 noundef %add.i.i95) #13
  %conv8.i.i.i115 = zext i1 %call1.i.i.i.i114 to i8
  %sf.i.i.i116 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i115, ptr %sf.i.i.i116, align 1
  %shr8.i.i.i.i117 = xor i32 %add.i.i95, %conv.i.i94
  %xor.i28.i.i.i118 = lshr i32 %shr8.i.i.i.i117, 31
  %xor3.i.i.i.i119 = lshr i32 %xor.i.i.i.i105, 31
  %add.i.i.i.i120 = add nuw nsw i32 %xor.i28.i.i.i118, %xor3.i.i.i.i119
  %cmp.i29.i.i.i121 = icmp eq i32 %add.i.i.i.i120, 2
  %call.i30.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i121, i32 noundef %conv.i.i94, i32 noundef %156, i32 noundef %add.i.i95) #13
  %conv11.i.i.i123 = zext i1 %call.i30.i.i.i122 to i8
  %of.i.i.i124 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i123, ptr %of.i.i.i124, align 1
  store ptr %158, ptr %MEMORY, align 8
  br label %164

164:                                              ; preds = %152
  %165 = load i64, ptr %NEXT_PC, align 8
  store i64 %165, ptr %PC, align 8
  %166 = add i64 %165, 3
  store i64 %166, ptr %NEXT_PC, align 8
  %167 = load i64, ptr %RBP, align 8
  %168 = add i64 %167, 16
  %169 = load ptr, ptr %MEMORY, align 8
  %call.i.i262 = call i32 @__remill_read_memory_32(ptr noundef %169, i64 noundef %168) #13
  %conv.i.i263 = zext i32 %call.i.i262 to i64
  store i64 %conv.i.i263, ptr %RAX, align 8
  store ptr %169, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %164
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 2
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i64, ptr %RDX, align 8
  %174 = load i32, ptr %EAX, align 4
  %175 = zext i32 %174 to i64
  %176 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %173 to i32
  %add.i.i64 = add i32 %174, %conv.i.i63
  %conv.i22.i65 = zext i32 %add.i.i64 to i64
  store i64 %conv.i22.i65, ptr %RDX, align 8
  %cmp.i.i.i66 = icmp ult i32 %add.i.i64, %conv.i.i63
  %cmp1.i.i.i67 = icmp ult i32 %add.i.i64, %174
  %177 = or i1 %cmp.i.i.i66, %cmp1.i.i.i67
  %call.i.i.i68 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %177, i32 noundef %conv.i.i63, i32 noundef %174, i32 noundef %add.i.i64) #13
  %conv.i23.i69 = zext i1 %call.i.i.i68 to i8
  %cf.i.i70 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i69, ptr %cf.i.i70, align 1
  %conv.i.i.i.i71 = trunc i32 %add.i.i64 to i8
  %178 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i71)
  %179 = and i8 %178, 1
  %conv.i.i.i72 = xor i8 %179, 1
  %pf.i.i.i73 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i72, ptr %pf.i.i.i73, align 1
  %xor.i.i.i.i74 = xor i32 %add.i.i64, %174
  %xor1.i.i.i.i75 = xor i32 %xor.i.i.i.i74, %conv.i.i63
  %180 = trunc i32 %xor1.i.i.i.i75 to i8
  %181 = lshr i8 %180, 4
  %conv2.i.i.i76 = and i8 %181, 1
  %af.i.i.i77 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i76, ptr %af.i.i.i77, align 1
  %cmp.i.i.i.i78 = icmp eq i32 %add.i.i64, 0
  %call.i.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i78, i32 noundef %conv.i.i63, i32 noundef %174, i32 noundef %add.i.i64) #13
  %conv5.i.i.i80 = zext i1 %call.i.i.i.i79 to i8
  %zf.i.i.i81 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i80, ptr %zf.i.i.i81, align 1
  %cmp.i27.i.i.i82 = icmp slt i32 %add.i.i64, 0
  %call1.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i82, i32 noundef %conv.i.i63, i32 noundef %174, i32 noundef %add.i.i64) #13
  %conv8.i.i.i84 = zext i1 %call1.i.i.i.i83 to i8
  %sf.i.i.i85 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i84, ptr %sf.i.i.i85, align 1
  %shr8.i.i.i.i86 = xor i32 %add.i.i64, %conv.i.i63
  %xor.i28.i.i.i87 = lshr i32 %shr8.i.i.i.i86, 31
  %xor3.i.i.i.i88 = lshr i32 %xor.i.i.i.i74, 31
  %add.i.i.i.i89 = add nuw nsw i32 %xor.i28.i.i.i87, %xor3.i.i.i.i88
  %cmp.i29.i.i.i90 = icmp eq i32 %add.i.i.i.i89, 2
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i90, i32 noundef %conv.i.i63, i32 noundef %174, i32 noundef %add.i.i64) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %176, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %170
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 3
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load i64, ptr %RBP, align 8
  %186 = add i64 %185, 24
  %187 = load ptr, ptr %MEMORY, align 8
  %call.i.i260 = call i32 @__remill_read_memory_32(ptr noundef %187, i64 noundef %186) #13
  %conv.i.i261 = zext i32 %call.i.i260 to i64
  store i64 %conv.i.i261, ptr %RAX, align 8
  store ptr %187, ptr %MEMORY, align 8
  br label %188

188:                                              ; preds = %182
  %189 = load i64, ptr %NEXT_PC, align 8
  store i64 %189, ptr %PC, align 8
  %190 = add i64 %189, 2
  store i64 %190, ptr %NEXT_PC, align 8
  %191 = load i64, ptr %RDX, align 8
  %192 = load i32, ptr %EAX, align 4
  %193 = zext i32 %192 to i64
  %194 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %191 to i32
  %add.i.i33 = add i32 %192, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RDX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, %192
  %195 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %195, i32 noundef %conv.i.i32, i32 noundef %192, i32 noundef %add.i.i33) #13
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %196 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %197 = and i8 %196, 1
  %conv.i.i.i41 = xor i8 %197, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, %192
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %198 = trunc i32 %xor1.i.i.i.i44 to i8
  %199 = lshr i8 %198, 4
  %conv2.i.i.i45 = and i8 %199, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %192, i32 noundef %add.i.i33) #13
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef %192, i32 noundef %add.i.i33) #13
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef %192, i32 noundef %add.i.i33) #13
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %194, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %188
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 3
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i64, ptr %RBP, align 8
  %204 = add i64 %203, 32
  %205 = load ptr, ptr %MEMORY, align 8
  %call.i.i258 = call i32 @__remill_read_memory_32(ptr noundef %205, i64 noundef %204) #13
  %conv.i.i259 = zext i32 %call.i.i258 to i64
  store i64 %conv.i.i259, ptr %RAX, align 8
  store ptr %205, ptr %MEMORY, align 8
  br label %206

206:                                              ; preds = %200
  %207 = load i64, ptr %NEXT_PC, align 8
  store i64 %207, ptr %PC, align 8
  %208 = add i64 %207, 2
  store i64 %208, ptr %NEXT_PC, align 8
  %209 = load i64, ptr %RDX, align 8
  %210 = load i32, ptr %EAX, align 4
  %211 = zext i32 %210 to i64
  %212 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %209 to i32
  %add.i.i2 = add i32 %210, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RDX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %210
  %213 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %213, i32 noundef %conv.i.i1, i32 noundef %210, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %214 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %215 = and i8 %214, 1
  %conv.i.i.i10 = xor i8 %215, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %210
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %216 = trunc i32 %xor1.i.i.i.i13 to i8
  %217 = lshr i8 %216, 4
  %conv2.i.i.i14 = and i8 %217, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef %210, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef %210, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef %210, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %212, ptr %MEMORY, align 8
  br label %218

218:                                              ; preds = %206
  %219 = load i64, ptr %NEXT_PC, align 8
  store i64 %219, ptr %PC, align 8
  %220 = add i64 %219, 3
  store i64 %220, ptr %NEXT_PC, align 8
  %221 = load i64, ptr %RBP, align 8
  %222 = add i64 %221, 40
  %223 = load ptr, ptr %MEMORY, align 8
  %call.i.i256 = call i32 @__remill_read_memory_32(ptr noundef %223, i64 noundef %222) #13
  %conv.i.i257 = zext i32 %call.i.i256 to i64
  store i64 %conv.i.i257, ptr %RAX, align 8
  store ptr %223, ptr %MEMORY, align 8
  br label %224

224:                                              ; preds = %218
  %225 = load i64, ptr %NEXT_PC, align 8
  store i64 %225, ptr %PC, align 8
  %226 = add i64 %225, 2
  store i64 %226, ptr %NEXT_PC, align 8
  %227 = load i64, ptr %RAX, align 8
  %228 = load i32, ptr %EDX, align 4
  %229 = zext i32 %228 to i64
  %230 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %227 to i32
  %add.i.i = add i32 %228, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %228
  %231 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %231, i32 noundef %conv.i.i, i32 noundef %228, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %232 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %233 = and i8 %232, 1
  %conv.i.i.i = xor i8 %233, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %228
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %234 = trunc i32 %xor1.i.i.i.i to i8
  %235 = lshr i8 %234, 4
  %conv2.i.i.i = and i8 %235, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %228, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %228, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %228, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %230, ptr %MEMORY, align 8
  br label %236

236:                                              ; preds = %224
  %237 = load i64, ptr %NEXT_PC, align 8
  store i64 %237, ptr %PC, align 8
  %238 = add i64 %237, 1
  store i64 %238, ptr %NEXT_PC, align 8
  %239 = load ptr, ptr %MEMORY, align 8
  %rsp.i276 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 13
  %240 = load i64, ptr %rsp.i276, align 8
  %add.i.i277 = add i64 %240, 8
  store i64 %add.i.i277, ptr %rsp.i276, align 8
  %call.i.i278 = call i64 @__remill_read_memory_64(ptr noundef %239, i64 noundef %240) #13
  store i64 %call.i.i278, ptr %RBP, align 8
  store ptr %239, ptr %MEMORY, align 8
  br label %241

241:                                              ; preds = %236
  %242 = load i64, ptr %NEXT_PC, align 8
  store i64 %242, ptr %PC, align 8
  %243 = add i64 %242, 1
  store i64 %243, ptr %NEXT_PC, align 8
  %244 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 13
  %245 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %244, i64 noundef %245) #13
  %rip.i = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %246 = load i64, ptr %rsp.i, align 8
  %add.i.i249 = add i64 %246, 8
  store i64 %add.i.i249, ptr %rsp.i, align 8
  store ptr %244, ptr %MEMORY, align 8
  %247 = load ptr, ptr %MEMORY, align 8
  ret ptr %247
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.1599, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.1599) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #14
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.1599) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4345, label %bb_10F9
  ]

dead_end:                                         ; preds = %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_10F9:                                          ; preds = %entry
  %block_pc = add i64 4345, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4345, ptr %1)
  %4 = call ptr @BB_10f9(ptr %state, i64 %2, ptr %1) #15
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  %6 = load ptr, ptr %mem_var, align 8
  ret ptr %6

return_bb:                                        ; No predecessors!
  %7 = load ptr, ptr %mem_var, align 8
  ret ptr %7
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4345, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() local_unnamed_addr #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.1598, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #15 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
