; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.70402 = type { %struct.X86State.70401 }
%struct.X86State.70401 = type { %struct.ArchState.70370, [32 x %union.VectorReg.70373], %struct.ArithFlags.70374, %union.anon.70369, %struct.Segments.70376, %struct.AddressSpace.70378, %struct.GPR.70379, %struct.X87Stack.70382, %struct.MMX.70386, %struct.FPUStatusFlags.70387, %union.anon.70369, %union.FPU.70396, %struct.SegmentCaches.70398, %struct.K_REG.70400 }
%struct.ArchState.70370 = type { i32, i32, %union.anon.70369 }
%union.VectorReg.70373 = type { %union.vec512_t.70372 }
%union.vec512_t.70372 = type { %struct.uint64v8_t.70371 }
%struct.uint64v8_t.70371 = type { [8 x i64] }
%struct.ArithFlags.70374 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.70376 = type { i16, %union.SegmentSelector.70375, i16, %union.SegmentSelector.70375, i16, %union.SegmentSelector.70375, i16, %union.SegmentSelector.70375, i16, %union.SegmentSelector.70375, i16, %union.SegmentSelector.70375 }
%union.SegmentSelector.70375 = type { i16 }
%struct.AddressSpace.70378 = type { i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377 }
%struct.Reg.70377 = type { %union.anon.70369 }
%struct.GPR.70379 = type { i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377, i64, %struct.Reg.70377 }
%struct.X87Stack.70382 = type { [8 x %struct.anon.3.70381] }
%struct.anon.3.70381 = type { [6 x i8], %struct.float80_t.70380 }
%struct.float80_t.70380 = type { [10 x i8] }
%struct.MMX.70386 = type { [8 x %struct.anon.4.70385] }
%struct.anon.4.70385 = type { i64, %union.vec64_t.70384 }
%union.vec64_t.70384 = type { %struct.uint64v1_t.70383 }
%struct.uint64v1_t.70383 = type { [1 x i64] }
%struct.FPUStatusFlags.70387 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.70369 = type { i64 }
%union.FPU.70396 = type { %struct.anon.13.70395 }
%struct.anon.13.70395 = type { %struct.FpuFXSAVE.70394, [96 x i8] }
%struct.FpuFXSAVE.70394 = type { %union.SegmentSelector.70375, %union.SegmentSelector.70375, %union.FPUAbridgedTagWord.70388, i8, i16, i32, %union.SegmentSelector.70375, i16, i32, %union.SegmentSelector.70375, i16, %union.FPUControlStatus.70389, %union.FPUControlStatus.70389, [8 x %struct.FPUStackElem.70391], [16 x %union.vec128_t.70393] }
%union.FPUAbridgedTagWord.70388 = type { i8 }
%union.FPUControlStatus.70389 = type { i32 }
%struct.FPUStackElem.70391 = type { %union.anon.11.70390, [6 x i8] }
%union.anon.11.70390 = type { %struct.float80_t.70380 }
%union.vec128_t.70393 = type { %struct.uint128v1_t.70392 }
%struct.uint128v1_t.70392 = type { [1 x i128] }
%struct.SegmentCaches.70398 = type { %struct.SegmentShadow.70397, %struct.SegmentShadow.70397, %struct.SegmentShadow.70397, %struct.SegmentShadow.70397, %struct.SegmentShadow.70397, %struct.SegmentShadow.70397 }
%struct.SegmentShadow.70397 = type { %union.anon.70369, i32, i32 }
%struct.K_REG.70400 = type { [8 x %struct.anon.18.70399] }
%struct.anon.18.70399 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1110(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.70402, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i39 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i39, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i1 = sub i64 %15, 48
  store i64 %sub.i.i1, ptr %RSP, align 8
  %cmp.i.i.i2 = icmp ult i64 %15, 48
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #13
  %conv.i.i4 = zext i1 %call.i.i.i3 to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i4, ptr %cf.i.i5, align 1
  %conv.i.i.i.i6 = trunc i64 %sub.i.i1 to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i6)
  %18 = and i8 %17, 1
  %conv.i.i.i7 = xor i8 %18, 1
  %pf.i.i.i8 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i7, ptr %pf.i.i.i8, align 1
  %xor.i.i.i.i9 = xor i64 48, %15
  %xor1.i.i.i.i10 = xor i64 %xor.i.i.i.i9, %sub.i.i1
  %19 = trunc i64 %xor1.i.i.i.i10 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i11 = and i8 %20, 1
  %af.i.i.i12 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i11, ptr %af.i.i.i12, align 1
  %cmp.i.i.i.i13 = icmp eq i64 %15, 48
  %call.i.i.i.i14 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i13, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #13
  %conv5.i.i.i15 = zext i1 %call.i.i.i.i14 to i8
  %zf.i.i.i16 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i15, ptr %zf.i.i.i16, align 1
  %cmp.i27.i.i.i17 = icmp slt i64 %sub.i.i1, 0
  %call1.i.i.i.i18 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i17, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #13
  %conv8.i.i.i19 = zext i1 %call1.i.i.i.i18 to i8
  %sf.i.i.i20 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i19, ptr %sf.i.i.i20, align 1
  %xor.i28.i.i.i21 = lshr i64 %xor.i.i.i.i9, 63
  %shr9.i.i.i.i22 = xor i64 %sub.i.i1, %15
  %xor3.i.i.i.i23 = lshr i64 %shr9.i.i.i.i22, 63
  %add.i.i.i.i24 = add nuw nsw i64 %xor3.i.i.i.i23, %xor.i28.i.i.i21
  %cmp.i29.i.i.i25 = icmp eq i64 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #13
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 4
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %26, i64 noundef %25, i32 noundef 0) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RBP, align 8
  %31 = sub i64 %30, 8
  %32 = load i32, ptr %EDI, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_32(ptr noundef %34, i64 noundef %31, i32 noundef %32) #13
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %27
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 16
  %40 = load i64, ptr %RSI, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call ptr @__remill_write_memory_64(ptr noundef %41, i64 noundef %39, i64 noundef %40) #13
  store ptr %call.i.i31, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 16
  %47 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %47, i64 noundef %46) #13
  store i64 %call.i.i35, ptr %RAX, align 8
  store ptr %47, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %42
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 4
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RAX, align 8
  %52 = add i64 %51, 8
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i64 @__remill_read_memory_64(ptr noundef %53, i64 noundef %52) #13
  store i64 %call.i.i34, ptr %RAX, align 8
  store ptr %53, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %48
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %RAX, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call zeroext i8 @__remill_read_memory_8(ptr noundef %58, i64 noundef %57) #13
  store i8 %call.i.i32, ptr %AL, align 1
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %54
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RBP, align 8
  %63 = sub i64 %62, 18
  %64 = load i8, ptr %AL, align 1
  %65 = zext i8 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_8(ptr noundef %66, i64 noundef %63, i8 noundef zeroext %64) #13
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %59
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 4
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RBP, align 8
  %71 = sub i64 %70, 18
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call zeroext i8 @__remill_read_memory_8(ptr noundef %72, i64 noundef %71) #13
  %conv.i.i37 = zext i8 %call.i.i36 to i64
  store i64 %conv.i.i37, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 5
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %76 to i32
  %sub.i.i = sub i32 %conv.i.i, 128
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %conv.i.i, 128
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 128, i32 noundef %sub.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %79 = and i8 %78, 1
  %conv.i.i.i = xor i8 %79, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 128, %conv.i.i
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %80 = trunc i32 %xor1.i.i.i.i to i8
  %81 = lshr i8 %80, 4
  %conv2.i.i.i = and i8 %81, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %conv.i.i, 128
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 128, i32 noundef %sub.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 128, i32 noundef %sub.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 128, i32 noundef %sub.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %73
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 9
  %86 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %86, 0
  %of.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 2, i32 13
  %87 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %87, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %85, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %82
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i8, ptr %AL, align 1
  %92 = zext i8 %91 to i64
  %93 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i38 = and i64 %92, 255
  store i64 %conv.i11.i38, ptr %RAX, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 2
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i32, ptr %EAX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %98, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %99, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %94
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 7
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = add i64 %103, 12005
  %105 = load ptr, ptr %MEMORY, align 8
  store i64 %104, ptr %RAX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %100
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 4
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RAX, align 8
  %110 = load i64, ptr %RCX, align 8
  %111 = mul i64 %110, 8
  %112 = add i64 %109, %111
  %113 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i64 @__remill_read_memory_64(ptr noundef %113, i64 noundef %112) #13
  store i64 %call.i.i33, ptr %RAX, align 8
  store ptr %113, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %106
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 2
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RAX, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 33
  store i64 %117, ptr %rip.i, align 8
  store i64 %117, ptr %NEXT_PC, align 8
  store ptr %118, ptr %MEMORY, align 8
  %119 = load ptr, ptr %MEMORY, align 8
  ret ptr %119
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.70402, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.70402) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #14
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.70402) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4368, label %bb_1110
  ]

dead_end:                                         ; preds = %bb_1110, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1110:                                          ; preds = %entry
  %block_pc = add i64 4368, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4368, ptr %1)
  %4 = call ptr @BB_1110(ptr %state, i64 %2, ptr %1) #15
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  br label %dead_end

return_bb:                                        ; No predecessors!
  %6 = load ptr, ptr %mem_var, align 8
  ret ptr %6
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4368, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() local_unnamed_addr #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.70401, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #15 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
