; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.27505 = type { %struct.X86State.27504 }
%struct.X86State.27504 = type { %struct.ArchState.27473, [32 x %union.VectorReg.27476], %struct.ArithFlags.27477, %union.anon.27472, %struct.Segments.27479, %struct.AddressSpace.27481, %struct.GPR.27482, %struct.X87Stack.27485, %struct.MMX.27489, %struct.FPUStatusFlags.27490, %union.anon.27472, %union.FPU.27499, %struct.SegmentCaches.27501, %struct.K_REG.27503 }
%struct.ArchState.27473 = type { i32, i32, %union.anon.27472 }
%union.VectorReg.27476 = type { %union.vec512_t.27475 }
%union.vec512_t.27475 = type { %struct.uint64v8_t.27474 }
%struct.uint64v8_t.27474 = type { [8 x i64] }
%struct.ArithFlags.27477 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.27479 = type { i16, %union.SegmentSelector.27478, i16, %union.SegmentSelector.27478, i16, %union.SegmentSelector.27478, i16, %union.SegmentSelector.27478, i16, %union.SegmentSelector.27478, i16, %union.SegmentSelector.27478 }
%union.SegmentSelector.27478 = type { i16 }
%struct.AddressSpace.27481 = type { i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480 }
%struct.Reg.27480 = type { %union.anon.27472 }
%struct.GPR.27482 = type { i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480, i64, %struct.Reg.27480 }
%struct.X87Stack.27485 = type { [8 x %struct.anon.3.27484] }
%struct.anon.3.27484 = type { [6 x i8], %struct.float80_t.27483 }
%struct.float80_t.27483 = type { [10 x i8] }
%struct.MMX.27489 = type { [8 x %struct.anon.4.27488] }
%struct.anon.4.27488 = type { i64, %union.vec64_t.27487 }
%union.vec64_t.27487 = type { %struct.uint64v1_t.27486 }
%struct.uint64v1_t.27486 = type { [1 x i64] }
%struct.FPUStatusFlags.27490 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.27472 = type { i64 }
%union.FPU.27499 = type { %struct.anon.13.27498 }
%struct.anon.13.27498 = type { %struct.FpuFXSAVE.27497, [96 x i8] }
%struct.FpuFXSAVE.27497 = type { %union.SegmentSelector.27478, %union.SegmentSelector.27478, %union.FPUAbridgedTagWord.27491, i8, i16, i32, %union.SegmentSelector.27478, i16, i32, %union.SegmentSelector.27478, i16, %union.FPUControlStatus.27492, %union.FPUControlStatus.27492, [8 x %struct.FPUStackElem.27494], [16 x %union.vec128_t.27496] }
%union.FPUAbridgedTagWord.27491 = type { i8 }
%union.FPUControlStatus.27492 = type { i32 }
%struct.FPUStackElem.27494 = type { %union.anon.11.27493, [6 x i8] }
%union.anon.11.27493 = type { %struct.float80_t.27483 }
%union.vec128_t.27496 = type { %struct.uint128v1_t.27495 }
%struct.uint128v1_t.27495 = type { [1 x i128] }
%struct.SegmentCaches.27501 = type { %struct.SegmentShadow.27500, %struct.SegmentShadow.27500, %struct.SegmentShadow.27500, %struct.SegmentShadow.27500, %struct.SegmentShadow.27500, %struct.SegmentShadow.27500 }
%struct.SegmentShadow.27500 = type { %union.anon.27472, i32, i32 }
%struct.K_REG.27503 = type { [8 x %struct.anon.18.27502] }
%struct.anon.18.27502 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1119(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i30 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i30, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 32
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 32
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 32, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 32
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 20
  %34 = load i32, ptr %EDI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #15
  store ptr %call.i.i28, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 32
  %42 = load i64, ptr %RSI, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #15
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 20
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %49, i64 noundef %48) #15
  %sub.i.i1 = sub i32 %call.i.i, 1
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, 1
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %51 = and i8 %50, 1
  %conv.i.i.i6 = xor i8 %51, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, 1
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %52 = trunc i32 %xor1.i.i.i.i9 to i8
  %53 = lshr i8 %52, 4
  %conv2.i.i.i10 = and i8 %53, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, 1
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %44
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  %58 = add i64 %57, 10
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %61 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %61, 0
  %sf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool10.i = icmp eq i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool12.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool10.i, %tobool12.i
  %64 = and i1 %tobool.not.i, %cmp.i.i
  %call15.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %64) #16
  %frombool.i = zext i1 %call15.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call15.i, i64 %58, i64 %59
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %60, ptr %MEMORY, align 8
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  ret ptr %66
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_113c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %6, i64 noundef %5, i32 noundef 0) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i6, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 8, %16
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %16
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 8
  %18 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %18, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %19 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %20 = and i8 %19, 1
  %conv.i.i.i = xor i8 %20, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 8
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %16
  %21 = trunc i64 %xor1.i.i.i.i to i8
  %22 = lshr i8 %21, 4
  %conv2.i.i.i = and i8 %22, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %16
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %13
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 3
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RAX, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %27, i64 noundef %26) #15
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %27, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %23
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RAX, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  %call.i.i7 = call zeroext i8 @__remill_read_memory_8(ptr noundef %32, i64 noundef %31) #15
  %conv.i.i8 = zext i8 %call.i.i7 to i64
  store i64 %conv.i.i8, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %28
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i8, ptr %AL, align 1
  %37 = zext i8 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i.i9 = trunc i64 %37 to i32
  %sext.i = shl i32 %conv.i.i9, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RBP, align 8
  %43 = sub i64 %42, 12
  %44 = load i32, ptr %EAX, align 4
  %45 = zext i32 %44 to i64
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_32(ptr noundef %46, i64 noundef %43, i32 noundef %44) #15
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %39
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RBP, align 8
  %51 = sub i64 %50, 12
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i32 @__remill_read_memory_32(ptr noundef %52, i64 noundef %51) #15
  %conv.i.i4 = zext i32 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RBP, align 8
  %57 = sub i64 %56, 8
  %58 = load i32, ptr %EAX, align 4
  %59 = zext i32 %58 to i64
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %60, i64 noundef %57, i32 noundef %58) #15
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %53
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 2
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %NEXT_PC, align 8
  %65 = add i64 %64, 97
  %66 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %65, ptr %rip.i, align 8
  store i64 %65, ptr %NEXT_PC, align 8
  store ptr %66, ptr %MEMORY, align 8
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = load ptr, ptr %MEMORY, align 8
  ret ptr %68
}

define ptr @BB_1132(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 5
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 203
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_11c0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 103
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_1207(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #15
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #15
  %rip.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_115f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %ECX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i250 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i251 = zext i32 %call.i.i250 to i64
  store i64 %conv.i.i251, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EDX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i252 = shl i64 %11, 32
  %conv.i12.i253 = ashr exact i64 %sext.i252, 32
  store i64 %conv.i12.i253, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %18 = ashr i64 %16, 63
  %L.sroa.2.0.insert.ext.i.i217 = zext i64 %18 to i128
  %L.sroa.2.0.insert.shift.i.i218 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i217, 64
  %L.sroa.0.0.insert.ext.i.i219 = zext i64 %16 to i128
  %L.sroa.0.0.insert.insert.i.i220 = or i128 %L.sroa.2.0.insert.shift.i.i218, %L.sroa.0.0.insert.ext.i.i219
  %mul.i.i221 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i220
  %retval.sroa.0.0.extract.trunc.i.i222 = trunc i128 %mul.i.i221 to i64
  %retval.sroa.2.0.extract.shift.i.i223 = lshr i128 %mul.i.i221, 64
  %retval.sroa.2.0.extract.trunc.i.i224 = trunc i128 %retval.sroa.2.0.extract.shift.i.i223 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i222, ptr %RAX, align 8
  %conv2.i.i.i225 = sext i64 %retval.sroa.0.0.extract.trunc.i.i222 to i128
  %cmp.i.i.i226 = icmp ne i128 %mul.i.i221, %conv2.i.i.i225
  %call.i.i.i227 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i226, i64 noundef %16, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i222, i64 noundef %retval.sroa.2.0.extract.trunc.i.i224) #15
  %frombool.i.i228 = zext i1 %call.i.i.i227 to i8
  %cf.i.i229 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i228, ptr %cf.i.i229, align 1
  %call2.i.i230 = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i231 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i230, ptr %pf.i.i231, align 1
  %af.i.i232 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i230, ptr %af.i.i232, align 1
  %zf.i.i233 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i230, ptr %zf.i.i233, align 1
  %sf.i.i234 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i230, ptr %sf.i.i234, align 1
  %of.i.i235 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i228, ptr %of.i.i235, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i255 = lshr i64 %22, 31
  %call34.i256 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i257 = icmp ne i8 %call34.i256, 0
  %new_val.0.i258 = lshr i64 %shr.i136.i255, 1
  store i64 %new_val.0.i258, ptr %RAX, align 8
  %cf.i259 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %24 = trunc i64 %shr.i136.i255 to i8
  %conv.i260 = and i8 %24, 1
  store i8 %conv.i260, ptr %cf.i259, align 1
  %pf.i261 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i262 = trunc i64 %new_val.0.i258 to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i262)
  %26 = and i8 %25, 1
  %conv67.i263 = xor i8 %26, 1
  store i8 %conv67.i263, ptr %pf.i261, align 1
  %af.i264 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i256, ptr %af.i264, align 1
  %zf.i265 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i266 = icmp ult i64 %shr.i136.i255, 2
  %conv80.i267 = zext i1 %cmp.i140.i266 to i8
  store i8 %conv80.i267, ptr %zf.i265, align 1
  %sf.i268 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i268, align 1
  %of.i269 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  %conv92.i270 = zext i1 %tobool.i257 to i8
  store i8 %conv92.i270, ptr %of.i269, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %19
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %sext167.i322 = shl i64 %30, 32
  %conv.i155.i323 = ashr exact i64 %sext167.i322, 32
  %shr.i156.i324 = ashr i64 %conv.i155.i323, 1
  %call36.i325 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i326 = icmp ne i8 %call36.i325, 0
  %shr.i160.i327 = ashr i64 %shr.i156.i324, 1
  %32 = zext i1 %tobool.i326 to i8
  %new_val.0.i328 = trunc i64 %shr.i160.i327 to i32
  %conv.i163.i329 = and i64 %shr.i160.i327, 4294967295
  store i64 %conv.i163.i329, ptr %RAX, align 8
  %cf.i330 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %33 = trunc i64 %shr.i156.i324 to i8
  %conv.i331 = and i8 %33, 1
  store i8 %conv.i331, ptr %cf.i330, align 1
  %pf.i332 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i333 = trunc i64 %shr.i160.i327 to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i333)
  %35 = and i8 %34, 1
  %conv75.i334 = xor i8 %35, 1
  store i8 %conv75.i334, ptr %pf.i332, align 1
  %af.i335 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i325, ptr %af.i335, align 1
  %zf.i336 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i337 = icmp eq i32 %new_val.0.i328, 0
  %conv88.i338 = zext i1 %cmp.i165.i337 to i8
  store i8 %conv88.i338, ptr %zf.i336, align 1
  %sf.i339 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i340 = lshr i32 %new_val.0.i328, 31
  %conv95.i341 = trunc i32 %new_val.0.lobit.i340 to i8
  store i8 %conv95.i341, ptr %sf.i339, align 1
  %of.i342 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %32, ptr %of.i342, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %27
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 2
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i32, ptr %EDX, align 4
  %40 = zext i32 %39 to i64
  %41 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i243 = and i64 %40, 4294967295
  store i64 %conv.i11.i243, ptr %RSI, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RSI, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %sext167.i301 = shl i64 %45, 32
  %conv.i155.i302 = ashr exact i64 %sext167.i301, 32
  %shr.i156.i303 = ashr i64 %conv.i155.i302, 30
  %call36.i304 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i305 = icmp ne i8 %call36.i304, 0
  %shr.i160.i306 = ashr i64 %shr.i156.i303, 1
  %47 = zext i1 %tobool.i305 to i8
  %new_val.0.i307 = trunc i64 %shr.i160.i306 to i32
  %conv.i163.i308 = and i64 %shr.i160.i306, 4294967295
  store i64 %conv.i163.i308, ptr %RSI, align 8
  %cf.i309 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %48 = trunc i64 %shr.i156.i303 to i8
  %conv.i310 = and i8 %48, 1
  store i8 %conv.i310, ptr %cf.i309, align 1
  %pf.i311 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i312 = trunc i64 %shr.i160.i306 to i8
  %49 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i312)
  %50 = and i8 %49, 1
  %conv75.i313 = xor i8 %50, 1
  store i8 %conv75.i313, ptr %pf.i311, align 1
  %af.i314 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i304, ptr %af.i314, align 1
  %zf.i315 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i316 = icmp eq i32 %new_val.0.i307, 0
  %conv88.i317 = zext i1 %cmp.i165.i316 to i8
  store i8 %conv88.i317, ptr %zf.i315, align 1
  %sf.i318 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i319 = lshr i32 %new_val.0.i307, 31
  %conv95.i320 = trunc i32 %new_val.0.lobit.i319 to i8
  store i8 %conv95.i320, ptr %sf.i318, align 1
  %of.i321 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %47, ptr %of.i321, align 1
  store ptr %46, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %42
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 2
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RAX, align 8
  %55 = load i32, ptr %ESI, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i183 = trunc i64 %54 to i32
  %sub.i.i184 = sub i32 %conv.i.i183, %55
  %conv.i22.i185 = zext i32 %sub.i.i184 to i64
  store i64 %conv.i22.i185, ptr %RAX, align 8
  %cmp.i.i.i186 = icmp ult i32 %conv.i.i183, %55
  %call.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i186, i32 noundef %conv.i.i183, i32 noundef %55, i32 noundef %sub.i.i184) #15
  %conv.i23.i188 = zext i1 %call.i.i.i187 to i8
  %cf.i.i189 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i188, ptr %cf.i.i189, align 1
  %conv.i.i.i.i190 = trunc i32 %sub.i.i184 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i190)
  %59 = and i8 %58, 1
  %conv.i.i.i191 = xor i8 %59, 1
  %pf.i.i.i192 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i191, ptr %pf.i.i.i192, align 1
  %xor.i.i.i.i193 = xor i32 %55, %conv.i.i183
  %xor1.i.i.i.i194 = xor i32 %xor.i.i.i.i193, %sub.i.i184
  %60 = trunc i32 %xor1.i.i.i.i194 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i195 = and i8 %61, 1
  %af.i.i.i196 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i195, ptr %af.i.i.i196, align 1
  %cmp.i.i.i.i197 = icmp eq i32 %conv.i.i183, %55
  %call.i.i.i.i198 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i197, i32 noundef %conv.i.i183, i32 noundef %55, i32 noundef %sub.i.i184) #15
  %conv5.i.i.i199 = zext i1 %call.i.i.i.i198 to i8
  %zf.i.i.i200 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i199, ptr %zf.i.i.i200, align 1
  %cmp.i27.i.i.i201 = icmp slt i32 %sub.i.i184, 0
  %call1.i.i.i.i202 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i201, i32 noundef %conv.i.i183, i32 noundef %55, i32 noundef %sub.i.i184) #15
  %conv8.i.i.i203 = zext i1 %call1.i.i.i.i202 to i8
  %sf.i.i.i204 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i203, ptr %sf.i.i.i204, align 1
  %xor.i28.i.i.i205 = lshr i32 %xor.i.i.i.i193, 31
  %shr9.i.i.i.i206 = xor i32 %sub.i.i184, %conv.i.i183
  %xor3.i.i.i.i207 = lshr i32 %shr9.i.i.i.i206, 31
  %add.i.i.i.i208 = add nuw nsw i32 %xor3.i.i.i.i207, %xor.i28.i.i.i205
  %cmp.i29.i.i.i209 = icmp eq i32 %add.i.i.i.i208, 2
  %call.i30.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i209, i32 noundef %conv.i.i183, i32 noundef %55, i32 noundef %sub.i.i184) #15
  %conv11.i.i.i211 = zext i1 %call.i30.i.i.i210 to i8
  %of.i.i.i212 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i211, ptr %of.i.i.i212, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %51
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 2
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i32, ptr %EAX, align 4
  %66 = zext i32 %65 to i64
  %67 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i242 = and i64 %66, 4294967295
  store i64 %conv.i11.i242, ptr %RCX, align 8
  store ptr %67, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %ECX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i241 = and i64 %72, 4294967295
  store i64 %conv.i11.i241, ptr %RAX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RAX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i354 = shl i64 %77, 1
  %conv2.i150.i355 = trunc i64 %shl.i149.i354 to i32
  %call42.i356 = call zeroext i8 @__remill_undefined_8() #16
  %tobool43.i357 = icmp ne i8 %call42.i356, 0
  %conv2.i154.i358 = shl i32 %conv2.i150.i355, 1
  %conv.i155.i360 = zext i32 %conv2.i154.i358 to i64
  store i64 %conv.i155.i360, ptr %RAX, align 8
  %cf.i361 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i362 = lshr i32 %conv2.i150.i355, 31
  %conv.i363 = trunc i32 %new_cf.0.shrunk.in.lobit.i362 to i8
  store i8 %conv.i363, ptr %cf.i361, align 1
  %pf.i364 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i365 = trunc i32 %conv2.i154.i358 to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i365)
  %80 = and i8 %79, 1
  %conv72.i366 = xor i8 %80, 1
  store i8 %conv72.i366, ptr %pf.i364, align 1
  %af.i367 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i356, ptr %af.i367, align 1
  %zf.i368 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i369 = icmp eq i32 %conv2.i154.i358, 0
  %conv85.i370 = zext i1 %cmp.i157.i369 to i8
  store i8 %conv85.i370, ptr %zf.i368, align 1
  %sf.i371 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i372 = lshr i32 %conv2.i154.i358, 31
  %conv92.i373 = trunc i32 %new_val.0.lobit.i372 to i8
  store i8 %conv92.i373, ptr %sf.i371, align 1
  %of.i374 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  %conv99.i375 = zext i1 %tobool43.i357 to i8
  store i8 %conv99.i375, ptr %of.i374, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %74
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RAX, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %84 to i32
  %add.i.i95 = add i32 %85, %conv.i.i94
  %conv.i22.i96 = zext i32 %add.i.i95 to i64
  store i64 %conv.i22.i96, ptr %RAX, align 8
  %cmp.i.i.i97 = icmp ult i32 %add.i.i95, %conv.i.i94
  %cmp1.i.i.i98 = icmp ult i32 %add.i.i95, %85
  %88 = or i1 %cmp.i.i.i97, %cmp1.i.i.i98
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %88, i32 noundef %conv.i.i94, i32 noundef %85, i32 noundef %add.i.i95) #15
  %conv.i23.i100 = zext i1 %call.i.i.i99 to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i100, ptr %cf.i.i101, align 1
  %conv.i.i.i.i102 = trunc i32 %add.i.i95 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i102)
  %90 = and i8 %89, 1
  %conv.i.i.i103 = xor i8 %90, 1
  %pf.i.i.i104 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i103, ptr %pf.i.i.i104, align 1
  %xor.i.i.i.i105 = xor i32 %add.i.i95, %85
  %xor1.i.i.i.i106 = xor i32 %xor.i.i.i.i105, %conv.i.i94
  %91 = trunc i32 %xor1.i.i.i.i106 to i8
  %92 = lshr i8 %91, 4
  %conv2.i.i.i107 = and i8 %92, 1
  %af.i.i.i108 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i107, ptr %af.i.i.i108, align 1
  %cmp.i.i.i.i109 = icmp eq i32 %add.i.i95, 0
  %call.i.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i109, i32 noundef %conv.i.i94, i32 noundef %85, i32 noundef %add.i.i95) #15
  %conv5.i.i.i111 = zext i1 %call.i.i.i.i110 to i8
  %zf.i.i.i112 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i111, ptr %zf.i.i.i112, align 1
  %cmp.i27.i.i.i113 = icmp slt i32 %add.i.i95, 0
  %call1.i.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i113, i32 noundef %conv.i.i94, i32 noundef %85, i32 noundef %add.i.i95) #15
  %conv8.i.i.i115 = zext i1 %call1.i.i.i.i114 to i8
  %sf.i.i.i116 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i115, ptr %sf.i.i.i116, align 1
  %shr8.i.i.i.i117 = xor i32 %add.i.i95, %conv.i.i94
  %xor.i28.i.i.i118 = lshr i32 %shr8.i.i.i.i117, 31
  %xor3.i.i.i.i119 = lshr i32 %xor.i.i.i.i105, 31
  %add.i.i.i.i120 = add nuw nsw i32 %xor.i28.i.i.i118, %xor3.i.i.i.i119
  %cmp.i29.i.i.i121 = icmp eq i32 %add.i.i.i.i120, 2
  %call.i30.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i121, i32 noundef %conv.i.i94, i32 noundef %85, i32 noundef %add.i.i95) #15
  %conv11.i.i.i123 = zext i1 %call.i30.i.i.i122 to i8
  %of.i.i.i124 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i123, ptr %of.i.i.i124, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %81
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 2
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load i32, ptr %EAX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %96 to i32
  %add.i.i64 = add i32 %97, %conv.i.i63
  %conv.i22.i65 = zext i32 %add.i.i64 to i64
  store i64 %conv.i22.i65, ptr %RAX, align 8
  %cmp.i.i.i66 = icmp ult i32 %add.i.i64, %conv.i.i63
  %cmp1.i.i.i67 = icmp ult i32 %add.i.i64, %97
  %100 = or i1 %cmp.i.i.i66, %cmp1.i.i.i67
  %call.i.i.i68 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %100, i32 noundef %conv.i.i63, i32 noundef %97, i32 noundef %add.i.i64) #15
  %conv.i23.i69 = zext i1 %call.i.i.i68 to i8
  %cf.i.i70 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i69, ptr %cf.i.i70, align 1
  %conv.i.i.i.i71 = trunc i32 %add.i.i64 to i8
  %101 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i71)
  %102 = and i8 %101, 1
  %conv.i.i.i72 = xor i8 %102, 1
  %pf.i.i.i73 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i72, ptr %pf.i.i.i73, align 1
  %xor.i.i.i.i74 = xor i32 %add.i.i64, %97
  %xor1.i.i.i.i75 = xor i32 %xor.i.i.i.i74, %conv.i.i63
  %103 = trunc i32 %xor1.i.i.i.i75 to i8
  %104 = lshr i8 %103, 4
  %conv2.i.i.i76 = and i8 %104, 1
  %af.i.i.i77 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i76, ptr %af.i.i.i77, align 1
  %cmp.i.i.i.i78 = icmp eq i32 %add.i.i64, 0
  %call.i.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i78, i32 noundef %conv.i.i63, i32 noundef %97, i32 noundef %add.i.i64) #15
  %conv5.i.i.i80 = zext i1 %call.i.i.i.i79 to i8
  %zf.i.i.i81 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i80, ptr %zf.i.i.i81, align 1
  %cmp.i27.i.i.i82 = icmp slt i32 %add.i.i64, 0
  %call1.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i82, i32 noundef %conv.i.i63, i32 noundef %97, i32 noundef %add.i.i64) #15
  %conv8.i.i.i84 = zext i1 %call1.i.i.i.i83 to i8
  %sf.i.i.i85 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i84, ptr %sf.i.i.i85, align 1
  %shr8.i.i.i.i86 = xor i32 %add.i.i64, %conv.i.i63
  %xor.i28.i.i.i87 = lshr i32 %shr8.i.i.i.i86, 31
  %xor3.i.i.i.i88 = lshr i32 %xor.i.i.i.i74, 31
  %add.i.i.i.i89 = add nuw nsw i32 %xor.i28.i.i.i87, %xor3.i.i.i.i88
  %cmp.i29.i.i.i90 = icmp eq i32 %add.i.i.i.i89, 2
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i90, i32 noundef %conv.i.i63, i32 noundef %97, i32 noundef %add.i.i64) #15
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %93
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 2
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RDX, align 8
  %109 = load i32, ptr %EAX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %conv.i.i153 = trunc i64 %108 to i32
  %sub.i.i154 = sub i32 %conv.i.i153, %109
  %conv.i22.i155 = zext i32 %sub.i.i154 to i64
  store i64 %conv.i22.i155, ptr %RDX, align 8
  %cmp.i.i.i156 = icmp ult i32 %conv.i.i153, %109
  %call.i.i.i157 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i156, i32 noundef %conv.i.i153, i32 noundef %109, i32 noundef %sub.i.i154) #15
  %conv.i23.i158 = zext i1 %call.i.i.i157 to i8
  %cf.i.i159 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i158, ptr %cf.i.i159, align 1
  %conv.i.i.i.i160 = trunc i32 %sub.i.i154 to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i160)
  %113 = and i8 %112, 1
  %conv.i.i.i161 = xor i8 %113, 1
  %pf.i.i.i162 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i161, ptr %pf.i.i.i162, align 1
  %xor.i.i.i.i163 = xor i32 %109, %conv.i.i153
  %xor1.i.i.i.i164 = xor i32 %xor.i.i.i.i163, %sub.i.i154
  %114 = trunc i32 %xor1.i.i.i.i164 to i8
  %115 = lshr i8 %114, 4
  %conv2.i.i.i165 = and i8 %115, 1
  %af.i.i.i166 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i165, ptr %af.i.i.i166, align 1
  %cmp.i.i.i.i167 = icmp eq i32 %conv.i.i153, %109
  %call.i.i.i.i168 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i167, i32 noundef %conv.i.i153, i32 noundef %109, i32 noundef %sub.i.i154) #15
  %conv5.i.i.i169 = zext i1 %call.i.i.i.i168 to i8
  %zf.i.i.i170 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i169, ptr %zf.i.i.i170, align 1
  %cmp.i27.i.i.i171 = icmp slt i32 %sub.i.i154, 0
  %call1.i.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i171, i32 noundef %conv.i.i153, i32 noundef %109, i32 noundef %sub.i.i154) #15
  %conv8.i.i.i173 = zext i1 %call1.i.i.i.i172 to i8
  %sf.i.i.i174 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i173, ptr %sf.i.i.i174, align 1
  %xor.i28.i.i.i175 = lshr i32 %xor.i.i.i.i163, 31
  %shr9.i.i.i.i176 = xor i32 %sub.i.i154, %conv.i.i153
  %xor3.i.i.i.i177 = lshr i32 %shr9.i.i.i.i176, 31
  %add.i.i.i.i178 = add nuw nsw i32 %xor3.i.i.i.i177, %xor.i28.i.i.i175
  %cmp.i29.i.i.i179 = icmp eq i32 %add.i.i.i.i178, 2
  %call.i30.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i179, i32 noundef %conv.i.i153, i32 noundef %109, i32 noundef %sub.i.i154) #15
  %conv11.i.i.i181 = zext i1 %call.i30.i.i.i180 to i8
  %of.i.i.i182 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i181, ptr %of.i.i.i182, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %105
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 3
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %RBP, align 8
  %120 = sub i64 %119, 16
  %121 = load i32, ptr %EDX, align 4
  %122 = zext i32 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %call.i.i237 = call ptr @__remill_write_memory_32(ptr noundef %123, i64 noundef %120, i32 noundef %121) #15
  store ptr %call.i.i237, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %116
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 3
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RBP, align 8
  %128 = sub i64 %127, 4
  %129 = load ptr, ptr %MEMORY, align 8
  %call.i.i248 = call i32 @__remill_read_memory_32(ptr noundef %129, i64 noundef %128) #15
  %conv.i.i249 = zext i32 %call.i.i248 to i64
  store i64 %conv.i.i249, ptr %RDX, align 8
  store ptr %129, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %124
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 2
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load i32, ptr %EDX, align 4
  %134 = zext i32 %133 to i64
  %135 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i240 = and i64 %134, 4294967295
  store i64 %conv.i11.i240, ptr %RAX, align 8
  store ptr %135, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %130
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 3
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %RAX, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i = shl i64 %139, 1
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  %conv.i155.i344 = zext i32 %conv2.i154.i to i64
  store i64 %conv.i155.i344, ptr %RAX, align 8
  %cf.i345 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv2.i150.i, 31
  %conv.i346 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i346, ptr %cf.i345, align 1
  %pf.i347 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i154.i to i8
  %141 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %142 = and i8 %141, 1
  %conv72.i = xor i8 %142, 1
  store i8 %conv72.i, ptr %pf.i347, align 1
  %af.i348 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i348, align 1
  %zf.i349 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i154.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i349, align 1
  %sf.i350 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i351 = lshr i32 %conv2.i154.i, 31
  %conv92.i352 = trunc i32 %new_val.0.lobit.i351 to i8
  store i8 %conv92.i352, ptr %sf.i350, align 1
  %of.i353 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i353, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %136
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 2
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %RAX, align 8
  %147 = load i32, ptr %EDX, align 4
  %148 = zext i32 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %146 to i32
  %add.i.i33 = add i32 %147, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RAX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, %147
  %150 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %150, i32 noundef %conv.i.i32, i32 noundef %147, i32 noundef %add.i.i33) #15
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %151 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %152 = and i8 %151, 1
  %conv.i.i.i41 = xor i8 %152, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, %147
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %153 = trunc i32 %xor1.i.i.i.i44 to i8
  %154 = lshr i8 %153, 4
  %conv2.i.i.i45 = and i8 %154, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %147, i32 noundef %add.i.i33) #15
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef %147, i32 noundef %add.i.i33) #15
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef %147, i32 noundef %add.i.i33) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %155

155:                                              ; preds = %143
  %156 = load i64, ptr %NEXT_PC, align 8
  store i64 %156, ptr %PC, align 8
  %157 = add i64 %156, 2
  store i64 %157, ptr %NEXT_PC, align 8
  %158 = load i64, ptr %RAX, align 8
  %159 = load i32, ptr %EAX, align 4
  %160 = zext i32 %159 to i64
  %161 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %158 to i32
  %add.i.i2 = add i32 %159, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RAX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %159
  %162 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %162, i32 noundef %conv.i.i1, i32 noundef %159, i32 noundef %add.i.i2) #15
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %163 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %164 = and i8 %163, 1
  %conv.i.i.i10 = xor i8 %164, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %159
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %165 = trunc i32 %xor1.i.i.i.i13 to i8
  %166 = lshr i8 %165, 4
  %conv2.i.i.i14 = and i8 %166, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef %159, i32 noundef %add.i.i2) #15
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef %159, i32 noundef %add.i.i2) #15
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef %159, i32 noundef %add.i.i2) #15
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %161, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %155
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 2
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i32, ptr %EAX, align 4
  %171 = zext i32 %170 to i64
  %172 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i239 = and i64 %171, 4294967295
  store i64 %conv.i11.i239, ptr %RDX, align 8
  store ptr %172, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %167
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 3
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i64, ptr %RBP, align 8
  %177 = sub i64 %176, 16
  %178 = load ptr, ptr %MEMORY, align 8
  %call.i.i246 = call i32 @__remill_read_memory_32(ptr noundef %178, i64 noundef %177) #15
  %conv.i.i247 = zext i32 %call.i.i246 to i64
  store i64 %conv.i.i247, ptr %RAX, align 8
  store ptr %178, ptr %MEMORY, align 8
  br label %179

179:                                              ; preds = %173
  %180 = load i64, ptr %NEXT_PC, align 8
  store i64 %180, ptr %PC, align 8
  %181 = add i64 %180, 2
  store i64 %181, ptr %NEXT_PC, align 8
  %182 = load i64, ptr %RAX, align 8
  %183 = load i32, ptr %EDX, align 4
  %184 = zext i32 %183 to i64
  %185 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %182 to i32
  %add.i.i = add i32 %183, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %183
  %186 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %186, i32 noundef %conv.i.i, i32 noundef %183, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %187 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %188 = and i8 %187, 1
  %conv.i.i.i = xor i8 %188, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %183
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %189 = trunc i32 %xor1.i.i.i.i to i8
  %190 = lshr i8 %189, 4
  %conv2.i.i.i = and i8 %190, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %183, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %183, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %183, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %191

191:                                              ; preds = %179
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = add i64 %192, 3
  store i64 %193, ptr %NEXT_PC, align 8
  %194 = load i64, ptr %RBP, align 8
  %195 = sub i64 %194, 4
  %196 = load i32, ptr %EAX, align 4
  %197 = zext i32 %196 to i64
  %198 = load ptr, ptr %MEMORY, align 8
  %call.i.i236 = call ptr @__remill_write_memory_32(ptr noundef %198, i64 noundef %195, i32 noundef %196) #15
  store ptr %call.i.i236, ptr %MEMORY, align 8
  br label %199

199:                                              ; preds = %191
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = add i64 %200, 3
  store i64 %201, ptr %NEXT_PC, align 8
  %202 = load i64, ptr %RBP, align 8
  %203 = sub i64 %202, 8
  %204 = load ptr, ptr %MEMORY, align 8
  %call.i.i244 = call i32 @__remill_read_memory_32(ptr noundef %204, i64 noundef %203) #15
  %conv.i.i245 = zext i32 %call.i.i244 to i64
  store i64 %conv.i.i245, ptr %RAX, align 8
  store ptr %204, ptr %MEMORY, align 8
  br label %205

205:                                              ; preds = %199
  %206 = load i64, ptr %NEXT_PC, align 8
  store i64 %206, ptr %PC, align 8
  %207 = add i64 %206, 3
  store i64 %207, ptr %NEXT_PC, align 8
  %208 = load i32, ptr %EAX, align 4
  %209 = zext i32 %208 to i64
  %210 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %209, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %210, ptr %MEMORY, align 8
  br label %211

211:                                              ; preds = %205
  %212 = load i64, ptr %NEXT_PC, align 8
  store i64 %212, ptr %PC, align 8
  %213 = add i64 %212, 7
  store i64 %213, ptr %NEXT_PC, align 8
  %214 = load i64, ptr %RDX, align 8
  %215 = load ptr, ptr %MEMORY, align 8
  %216 = ashr i64 %214, 63
  %L.sroa.2.0.insert.ext.i.i = zext i64 %216 to i128
  %L.sroa.2.0.insert.shift.i.i = shl nuw i128 %L.sroa.2.0.insert.ext.i.i, 64
  %L.sroa.0.0.insert.ext.i.i = zext i64 %214 to i128
  %L.sroa.0.0.insert.insert.i.i = or i128 %L.sroa.2.0.insert.shift.i.i, %L.sroa.0.0.insert.ext.i.i
  %mul.i.i = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i
  %retval.sroa.0.0.extract.trunc.i.i = trunc i128 %mul.i.i to i64
  %retval.sroa.2.0.extract.shift.i.i = lshr i128 %mul.i.i, 64
  %retval.sroa.2.0.extract.trunc.i.i = trunc i128 %retval.sroa.2.0.extract.shift.i.i to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i, ptr %RDX, align 8
  %conv2.i.i.i213 = sext i64 %retval.sroa.0.0.extract.trunc.i.i to i128
  %cmp.i.i.i214 = icmp ne i128 %mul.i.i, %conv2.i.i.i213
  %call.i.i.i215 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i214, i64 noundef %214, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i, i64 noundef %retval.sroa.2.0.extract.trunc.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i215 to i8
  %cf.i.i216 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i216, align 1
  %call2.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %215, ptr %MEMORY, align 8
  br label %217

217:                                              ; preds = %211
  %218 = load i64, ptr %NEXT_PC, align 8
  store i64 %218, ptr %PC, align 8
  %219 = add i64 %218, 4
  store i64 %219, ptr %NEXT_PC, align 8
  %220 = load i64, ptr %RDX, align 8
  %221 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i = lshr i64 %220, 31
  %call34.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i64 %shr.i136.i, 1
  store i64 %new_val.0.i, ptr %RDX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %222 = trunc i64 %shr.i136.i to i8
  %conv.i = and i8 %222, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i254 = trunc i64 %new_val.0.i to i8
  %223 = call i8 @llvm.ctpop.i8(i8 %conv.i.i254)
  %224 = and i8 %223, 1
  %conv67.i = xor i8 %224, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i = icmp ult i64 %shr.i136.i, 2
  %conv80.i = zext i1 %cmp.i140.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %221, ptr %MEMORY, align 8
  br label %225

225:                                              ; preds = %217
  %226 = load i64, ptr %NEXT_PC, align 8
  store i64 %226, ptr %PC, align 8
  %227 = add i64 %226, 3
  store i64 %227, ptr %NEXT_PC, align 8
  %228 = load i64, ptr %RDX, align 8
  %229 = load ptr, ptr %MEMORY, align 8
  %sext167.i280 = shl i64 %228, 32
  %conv.i155.i281 = ashr exact i64 %sext167.i280, 32
  %shr.i156.i282 = ashr i64 %conv.i155.i281, 1
  %call36.i283 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i284 = icmp ne i8 %call36.i283, 0
  %shr.i160.i285 = ashr i64 %shr.i156.i282, 1
  %230 = zext i1 %tobool.i284 to i8
  %new_val.0.i286 = trunc i64 %shr.i160.i285 to i32
  %conv.i163.i287 = and i64 %shr.i160.i285, 4294967295
  store i64 %conv.i163.i287, ptr %RDX, align 8
  %cf.i288 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %231 = trunc i64 %shr.i156.i282 to i8
  %conv.i289 = and i8 %231, 1
  store i8 %conv.i289, ptr %cf.i288, align 1
  %pf.i290 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i291 = trunc i64 %shr.i160.i285 to i8
  %232 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i291)
  %233 = and i8 %232, 1
  %conv75.i292 = xor i8 %233, 1
  store i8 %conv75.i292, ptr %pf.i290, align 1
  %af.i293 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i283, ptr %af.i293, align 1
  %zf.i294 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i295 = icmp eq i32 %new_val.0.i286, 0
  %conv88.i296 = zext i1 %cmp.i165.i295 to i8
  store i8 %conv88.i296, ptr %zf.i294, align 1
  %sf.i297 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i298 = lshr i32 %new_val.0.i286, 31
  %conv95.i299 = trunc i32 %new_val.0.lobit.i298 to i8
  store i8 %conv95.i299, ptr %sf.i297, align 1
  %of.i300 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %230, ptr %of.i300, align 1
  store ptr %229, ptr %MEMORY, align 8
  br label %234

234:                                              ; preds = %225
  %235 = load i64, ptr %NEXT_PC, align 8
  store i64 %235, ptr %PC, align 8
  %236 = add i64 %235, 3
  store i64 %236, ptr %NEXT_PC, align 8
  %237 = load i64, ptr %RAX, align 8
  %238 = load ptr, ptr %MEMORY, align 8
  %sext167.i = shl i64 %237, 32
  %conv.i155.i = ashr exact i64 %sext167.i, 32
  %shr.i156.i = ashr i64 %conv.i155.i, 30
  %call36.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i271 = icmp ne i8 %call36.i, 0
  %shr.i160.i = ashr i64 %shr.i156.i, 1
  %239 = zext i1 %tobool.i271 to i8
  %new_val.0.i272 = trunc i64 %shr.i160.i to i32
  %conv.i163.i = and i64 %shr.i160.i, 4294967295
  store i64 %conv.i163.i, ptr %RAX, align 8
  %cf.i273 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  %240 = trunc i64 %shr.i156.i to i8
  %conv.i274 = and i8 %240, 1
  store i8 %conv.i274, ptr %cf.i273, align 1
  %pf.i275 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i = trunc i64 %shr.i160.i to i8
  %241 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i)
  %242 = and i8 %241, 1
  %conv75.i = xor i8 %242, 1
  store i8 %conv75.i, ptr %pf.i275, align 1
  %af.i276 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i, ptr %af.i276, align 1
  %zf.i277 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i = icmp eq i32 %new_val.0.i272, 0
  %conv88.i = zext i1 %cmp.i165.i to i8
  store i8 %conv88.i, ptr %zf.i277, align 1
  %sf.i278 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %new_val.0.i272, 31
  %conv95.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv95.i, ptr %sf.i278, align 1
  %of.i279 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %239, ptr %of.i279, align 1
  store ptr %238, ptr %MEMORY, align 8
  br label %243

243:                                              ; preds = %234
  %244 = load i64, ptr %NEXT_PC, align 8
  store i64 %244, ptr %PC, align 8
  %245 = add i64 %244, 2
  store i64 %245, ptr %NEXT_PC, align 8
  %246 = load i32, ptr %EAX, align 4
  %247 = zext i32 %246 to i64
  %248 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i238 = and i64 %247, 4294967295
  store i64 %conv.i11.i238, ptr %RCX, align 8
  store ptr %248, ptr %MEMORY, align 8
  br label %249

249:                                              ; preds = %243
  %250 = load i64, ptr %NEXT_PC, align 8
  store i64 %250, ptr %PC, align 8
  %251 = add i64 %250, 2
  store i64 %251, ptr %NEXT_PC, align 8
  %252 = load i32, ptr %EDX, align 4
  %253 = zext i32 %252 to i64
  %254 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %253, 4294967295
  store i64 %conv.i11.i, ptr %RAX, align 8
  store ptr %254, ptr %MEMORY, align 8
  br label %255

255:                                              ; preds = %249
  %256 = load i64, ptr %NEXT_PC, align 8
  store i64 %256, ptr %PC, align 8
  %257 = add i64 %256, 2
  store i64 %257, ptr %NEXT_PC, align 8
  %258 = load i64, ptr %RAX, align 8
  %259 = load i32, ptr %ECX, align 4
  %260 = zext i32 %259 to i64
  %261 = load ptr, ptr %MEMORY, align 8
  %conv.i.i125 = trunc i64 %258 to i32
  %sub.i.i = sub i32 %conv.i.i125, %259
  %conv.i22.i126 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i126, ptr %RAX, align 8
  %cmp.i.i.i127 = icmp ult i32 %conv.i.i125, %259
  %call.i.i.i128 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i127, i32 noundef %conv.i.i125, i32 noundef %259, i32 noundef %sub.i.i) #15
  %conv.i23.i129 = zext i1 %call.i.i.i128 to i8
  %cf.i.i130 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i129, ptr %cf.i.i130, align 1
  %conv.i.i.i.i131 = trunc i32 %sub.i.i to i8
  %262 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i131)
  %263 = and i8 %262, 1
  %conv.i.i.i132 = xor i8 %263, 1
  %pf.i.i.i133 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i132, ptr %pf.i.i.i133, align 1
  %xor.i.i.i.i134 = xor i32 %259, %conv.i.i125
  %xor1.i.i.i.i135 = xor i32 %xor.i.i.i.i134, %sub.i.i
  %264 = trunc i32 %xor1.i.i.i.i135 to i8
  %265 = lshr i8 %264, 4
  %conv2.i.i.i136 = and i8 %265, 1
  %af.i.i.i137 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i136, ptr %af.i.i.i137, align 1
  %cmp.i.i.i.i138 = icmp eq i32 %conv.i.i125, %259
  %call.i.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i138, i32 noundef %conv.i.i125, i32 noundef %259, i32 noundef %sub.i.i) #15
  %conv5.i.i.i140 = zext i1 %call.i.i.i.i139 to i8
  %zf.i.i.i141 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i140, ptr %zf.i.i.i141, align 1
  %cmp.i27.i.i.i142 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i142, i32 noundef %conv.i.i125, i32 noundef %259, i32 noundef %sub.i.i) #15
  %conv8.i.i.i144 = zext i1 %call1.i.i.i.i143 to i8
  %sf.i.i.i145 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i144, ptr %sf.i.i.i145, align 1
  %xor.i28.i.i.i146 = lshr i32 %xor.i.i.i.i134, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i125
  %xor3.i.i.i.i147 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i148 = add nuw nsw i32 %xor3.i.i.i.i147, %xor.i28.i.i.i146
  %cmp.i29.i.i.i149 = icmp eq i32 %add.i.i.i.i148, 2
  %call.i30.i.i.i150 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i149, i32 noundef %conv.i.i125, i32 noundef %259, i32 noundef %sub.i.i) #15
  %conv11.i.i.i151 = zext i1 %call.i30.i.i.i150 to i8
  %of.i.i.i152 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i151, ptr %of.i.i.i152, align 1
  store ptr %261, ptr %MEMORY, align 8
  br label %266

266:                                              ; preds = %255
  %267 = load i64, ptr %NEXT_PC, align 8
  store i64 %267, ptr %PC, align 8
  %268 = add i64 %267, 3
  store i64 %268, ptr %NEXT_PC, align 8
  %269 = load i64, ptr %RBP, align 8
  %270 = sub i64 %269, 8
  %271 = load i32, ptr %EAX, align 4
  %272 = zext i32 %271 to i64
  %273 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %273, i64 noundef %270, i32 noundef %271) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %274

274:                                              ; preds = %266
  %275 = load i64, ptr %NEXT_PC, align 8
  store i64 %275, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_11c6(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 12
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #15
  %sub.i.i = sub i32 %10, %call.i.i
  %cmp.i.i.i = icmp ugt i32 %call.i.i, %10
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %15 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %16 = and i8 %15, 1
  %conv.i.i.i = xor i8 %16, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, %10
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %17 = trunc i32 %xor1.i.i.i.i to i8
  %18 = lshr i8 %17, 4
  %conv2.i.i.i = and i8 %18, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, %10
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %10
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %7
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = add i64 %22, 27
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 2, i32 7
  %26 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %26, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %23, i64 %24
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %25, ptr %MEMORY, align 8
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  ret ptr %28
}

define ptr @BB_11e9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 12
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %11, 4294967295
  store i64 %conv.i11.i, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = add i64 %16, 3616
  %18 = load ptr, ptr %MEMORY, align 8
  store i64 %17, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  store i64 %22, ptr %RDI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 5
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %27, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %24
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 5
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %NEXT_PC, align 8
  %32 = sub i64 %31, 434
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %35 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %35, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %sub.i.i, i64 noundef %33) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %32, ptr %rip.i, align 8
  store i64 %32, ptr %NEXT_PC, align 8
  store i64 %33, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  ret ptr %36
}

define ptr @BB_11ce(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 12
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %11, 4294967295
  store i64 %conv.i11.i, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = add i64 %16, 3622
  %18 = load ptr, ptr %MEMORY, align 8
  store i64 %17, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  store i64 %22, ptr %RDI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 5
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %27, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %24
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 5
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %NEXT_PC, align 8
  %32 = sub i64 %31, 407
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %35 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %35, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %sub.i.i, i64 noundef %33) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %32, ptr %rip.i, align 8
  store i64 %32, ptr %NEXT_PC, align 8
  store i64 %33, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  ret ptr %36
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_1202(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_11e7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.27505, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 25
  %6 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store ptr %6, ptr %MEMORY, align 8
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  ret ptr %8
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.27505, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.27505) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #17
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.27505) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4377, label %bb_1119
    i64 4402, label %bb_1132
    i64 4412, label %bb_113C
    i64 4447, label %bb_115F
    i64 4544, label %bb_11C0
    i64 4550, label %bb_11C6
    i64 4558, label %bb_11CE
    i64 4583, label %bb_11E7
    i64 4585, label %bb_11E9
    i64 4610, label %bb_1202
    i64 4615, label %bb_1207
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
  ]

dead_end:                                         ; preds = %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_1202, %bb_11E9, %bb_11E7, %bb_11CE, %bb_11C6, %bb_11C0, %bb_115F, %bb_113C, %bb_1132, %bb_1119, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1119:                                          ; preds = %entry
  %block_pc = add i64 4377, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4377, ptr %1)
  %4 = call ptr @BB_1119(ptr %state, i64 %2, ptr %1) #18
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4402, label %bb_1132
    i64 4412, label %bb_113C
  ]

bb_1132:                                          ; preds = %bb_1119, %entry
  %block_pc1 = add i64 4402, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4402, ptr %6)
  %9 = call ptr @BB_1132(ptr %state, i64 %7, ptr %6) #18
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4615, label %bb_1207
  ]

bb_113C:                                          ; preds = %bb_1119, %entry
  %block_pc3 = add i64 4412, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4412, ptr %11)
  %14 = call ptr @BB_113c(ptr %state, i64 %12, ptr %11) #18
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4544, label %bb_11C0
  ]

bb_115F:                                          ; preds = %bb_11C0, %entry
  %block_pc5 = add i64 4447, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4447, ptr %16)
  %19 = call ptr @BB_115f(ptr %state, i64 %17, ptr %16) #18
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4544, label %bb_11C0
  ]

bb_11C0:                                          ; preds = %bb_115F, %bb_113C, %entry
  %block_pc7 = add i64 4544, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4544, ptr %21)
  %24 = call ptr @BB_11c0(ptr %state, i64 %22, ptr %21) #18
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4447, label %bb_115F
    i64 4550, label %bb_11C6
  ]

bb_11C6:                                          ; preds = %bb_11C0, %entry
  %block_pc9 = add i64 4550, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4550, ptr %26)
  %29 = call ptr @BB_11c6(ptr %state, i64 %27, ptr %26) #18
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4558, label %bb_11CE
    i64 4585, label %bb_11E9
  ]

bb_11CE:                                          ; preds = %bb_11C6, %entry
  %block_pc11 = add i64 4558, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4558, ptr %31)
  %34 = call ptr @BB_11ce(ptr %state, i64 %32, ptr %31) #18
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4176, label %bb_FFFF000000000001
  ]

bb_11E7:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc13 = add i64 4583, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4583, ptr %36)
  %39 = call ptr @BB_11e7(ptr %state, i64 %37, ptr %36) #18
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4610, label %bb_1202
  ]

bb_11E9:                                          ; preds = %bb_11C6, %entry
  %block_pc15 = add i64 4585, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4585, ptr %41)
  %44 = call ptr @BB_11e9(ptr %state, i64 %42, ptr %41) #18
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4176, label %bb_FFFF000000000000
  ]

bb_1202:                                          ; preds = %bb_FFFF000000000000, %bb_11E7, %entry
  %block_pc17 = add i64 4610, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4610, ptr %46)
  %49 = call ptr @BB_1202(ptr %state, i64 %47, ptr %46) #18
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4615, label %bb_1207
  ]

bb_1207:                                          ; preds = %bb_1202, %bb_1132, %entry
  %block_pc19 = add i64 4615, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4615, ptr %51)
  %54 = call ptr @BB_1207(ptr %state, i64 %52, ptr %51) #18
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  %56 = load ptr, ptr %mem_var, align 8
  ret ptr %56

bb_FFFF000000000000:                              ; preds = %bb_11E9, %entry
  %57 = load ptr, ptr %mem_var, align 8
  %58 = load i64, ptr %pc_var, align 4
  %59 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %58, ptr %57) #18
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva21 = sub i64 %60, %base
  switch i64 %next_rva21, label %dead_end [
    i64 4610, label %bb_1202
  ]

bb_FFFF000000000001:                              ; preds = %bb_11CE, %entry
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %62, ptr %61) #18
  store ptr %63, ptr %mem_var, align 8
  %64 = call i64 @__extract_rip(ptr %state)
  store i64 %64, ptr %pc_var, align 4
  %next_rva22 = sub i64 %64, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4583, label %bb_11E7
  ]

return_bb:                                        ; No predecessors!
  %65 = load ptr, ptr %mem_var, align 8
  ret ptr %65
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4377, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.27504, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !23
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #18 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24, !24, i64 0}
!24 = !{!"omnipotent char", !25, i64 0}
!25 = !{!"Simple C++ TBAA"}
