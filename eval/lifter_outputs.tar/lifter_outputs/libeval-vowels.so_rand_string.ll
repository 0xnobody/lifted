; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.31609 = type { %struct.X86State.31608 }
%struct.X86State.31608 = type { %struct.ArchState.31577, [32 x %union.VectorReg.31580], %struct.ArithFlags.31581, %union.anon.31576, %struct.Segments.31583, %struct.AddressSpace.31585, %struct.GPR.31586, %struct.X87Stack.31589, %struct.MMX.31593, %struct.FPUStatusFlags.31594, %union.anon.31576, %union.FPU.31603, %struct.SegmentCaches.31605, %struct.K_REG.31607 }
%struct.ArchState.31577 = type { i32, i32, %union.anon.31576 }
%union.VectorReg.31580 = type { %union.vec512_t.31579 }
%union.vec512_t.31579 = type { %struct.uint64v8_t.31578 }
%struct.uint64v8_t.31578 = type { [8 x i64] }
%struct.ArithFlags.31581 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.31583 = type { i16, %union.SegmentSelector.31582, i16, %union.SegmentSelector.31582, i16, %union.SegmentSelector.31582, i16, %union.SegmentSelector.31582, i16, %union.SegmentSelector.31582, i16, %union.SegmentSelector.31582 }
%union.SegmentSelector.31582 = type { i16 }
%struct.AddressSpace.31585 = type { i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584 }
%struct.Reg.31584 = type { %union.anon.31576 }
%struct.GPR.31586 = type { i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584, i64, %struct.Reg.31584 }
%struct.X87Stack.31589 = type { [8 x %struct.anon.3.31588] }
%struct.anon.3.31588 = type { [6 x i8], %struct.float80_t.31587 }
%struct.float80_t.31587 = type { [10 x i8] }
%struct.MMX.31593 = type { [8 x %struct.anon.4.31592] }
%struct.anon.4.31592 = type { i64, %union.vec64_t.31591 }
%union.vec64_t.31591 = type { %struct.uint64v1_t.31590 }
%struct.uint64v1_t.31590 = type { [1 x i64] }
%struct.FPUStatusFlags.31594 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.31576 = type { i64 }
%union.FPU.31603 = type { %struct.anon.13.31602 }
%struct.anon.13.31602 = type { %struct.FpuFXSAVE.31601, [96 x i8] }
%struct.FpuFXSAVE.31601 = type { %union.SegmentSelector.31582, %union.SegmentSelector.31582, %union.FPUAbridgedTagWord.31595, i8, i16, i32, %union.SegmentSelector.31582, i16, i32, %union.SegmentSelector.31582, i16, %union.FPUControlStatus.31596, %union.FPUControlStatus.31596, [8 x %struct.FPUStackElem.31598], [16 x %union.vec128_t.31600] }
%union.FPUAbridgedTagWord.31595 = type { i8 }
%union.FPUControlStatus.31596 = type { i32 }
%struct.FPUStackElem.31598 = type { %union.anon.11.31597, [6 x i8] }
%union.anon.11.31597 = type { %struct.float80_t.31587 }
%union.vec128_t.31600 = type { %struct.uint128v1_t.31599 }
%struct.uint128v1_t.31599 = type { [1 x i128] }
%struct.SegmentCaches.31605 = type { %struct.SegmentShadow.31604, %struct.SegmentShadow.31604, %struct.SegmentShadow.31604, %struct.SegmentShadow.31604, %struct.SegmentShadow.31604, %struct.SegmentShadow.31604 }
%struct.SegmentShadow.31604 = type { %union.anon.31576, i32, i32 }
%struct.K_REG.31607 = type { [8 x %struct.anon.18.31606] }
%struct.anon.18.31606 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_13de(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i28 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i28, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 80
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 80
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 80, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 80
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 72
  %34 = load i64, ptr %RDI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i27 = call ptr @__remill_write_memory_64(ptr noundef %35, i64 noundef %33, i64 noundef %34) #15
  store ptr %call.i.i27, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 4
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 80
  %41 = load i64, ptr %RSI, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i26 = call ptr @__remill_write_memory_64(ptr noundef %42, i64 noundef %40, i64 noundef %41) #15
  store ptr %call.i.i26, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %36
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 10
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  store i64 7523094288207667809, ptr %RAX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %43
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 10
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  store i64 8101815670912281193, ptr %RDX, align 8
  store ptr %50, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %47
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 4
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RBP, align 8
  %55 = sub i64 %54, 64
  %56 = load i64, ptr %RAX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i25 = call ptr @__remill_write_memory_64(ptr noundef %57, i64 noundef %55, i64 noundef %56) #15
  store ptr %call.i.i25, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %51
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 4
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RBP, align 8
  %62 = sub i64 %61, 56
  %63 = load i64, ptr %RDX, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  %call.i.i24 = call ptr @__remill_write_memory_64(ptr noundef %64, i64 noundef %62, i64 noundef %63) #15
  store ptr %call.i.i24, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %58
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 10
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load ptr, ptr %MEMORY, align 8
  store i64 8680537053616894577, ptr %RAX, align 8
  store ptr %68, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %65
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 10
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load ptr, ptr %MEMORY, align 8
  store i64 3906085646303853177, ptr %RDX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %69
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 4
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RBP, align 8
  %77 = sub i64 %76, 48
  %78 = load i64, ptr %RAX, align 8
  %79 = load ptr, ptr %MEMORY, align 8
  %call.i.i23 = call ptr @__remill_write_memory_64(ptr noundef %79, i64 noundef %77, i64 noundef %78) #15
  store ptr %call.i.i23, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %73
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 4
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RBP, align 8
  %84 = sub i64 %83, 40
  %85 = load i64, ptr %RDX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  %call.i.i22 = call ptr @__remill_write_memory_64(ptr noundef %86, i64 noundef %84, i64 noundef %85) #15
  store ptr %call.i.i22, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %80
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 7
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RBP, align 8
  %91 = sub i64 %90, 32
  %92 = load ptr, ptr %MEMORY, align 8
  %call.i.i21 = call ptr @__remill_write_memory_32(ptr noundef %92, i64 noundef %91, i32 noundef 809056311) #15
  store ptr %call.i.i21, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %87
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 4
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RBP, align 8
  %97 = sub i64 %96, 28
  %98 = load ptr, ptr %MEMORY, align 8
  %call.i.i20 = call ptr @__remill_write_memory_8(ptr noundef %98, i64 noundef %97, i8 noundef zeroext 0) #15
  store ptr %call.i.i20, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %93
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 5
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RBP, align 8
  %103 = sub i64 %102, 80
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %104, i64 noundef %103) #15
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %call.i.i to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %106 = and i8 %105, 1
  %conv.i.i.i5 = xor i8 %106, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %call.i.i, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %call.i.i, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %call.i.i, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %99
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 2
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i64, ptr %NEXT_PC, align 8
  %111 = add i64 %110, 119
  %112 = load i64, ptr %NEXT_PC, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  %114 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %114, 0
  %call8.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i) #16
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %111, i64 %112
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %113, ptr %MEMORY, align 8
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  ret ptr %116
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_14b3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 1
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 15
  %11 = load i64, ptr %rbp.i, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %10, i64 noundef %11) #15
  store i64 %call.i.i2, ptr %rbp.i, align 8
  %rsp.i3 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  %add.i.i4 = add i64 %11, 8
  store i64 %add.i.i4, ptr %rsp.i3, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #15
  %rip.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %17, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %15, ptr %MEMORY, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_143c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load i64, ptr %RBP, align 8
  %7 = sub i64 %6, 80
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %8, i64 noundef %7) #15
  %sub.i.i = sub i64 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_64(ptr noundef %8, i64 noundef %5, i64 noundef %sub.i.i) #15
  %cmp.i.i.i = icmp ult i64 %call.i.i, 1
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %sub.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %9 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %10 = and i8 %9, 1
  %conv.i.i.i = xor i8 %10, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %call.i.i, 1
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %11 = trunc i64 %xor1.i.i.i.i to i8
  %12 = lshr i8 %11, 4
  %conv2.i.i.i = and i8 %12, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %call.i.i, 1
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %call.i.i
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %1
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 8
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 8
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_64(ptr noundef %18, i64 noundef %17, i64 noundef 0) #15
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = add i64 %22, 80
  %24 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  store i64 %23, ptr %rip.i, align 8
  store i64 %23, ptr %NEXT_PC, align 8
  store ptr %24, ptr %MEMORY, align 8
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  ret ptr %26
}

define ptr @BB_149b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load i64, ptr %RBP, align 8
  %12 = sub i64 %11, 80
  %13 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %13, i64 noundef %12) #15
  %sub.i.i = sub i64 %10, %call.i.i
  %cmp.i.i.i = icmp ugt i64 %call.i.i, %10
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %10, i64 noundef %call.i.i, i64 noundef %sub.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %14 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %15 = and i8 %14, 1
  %conv.i.i.i = xor i8 %15, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %call.i.i, %10
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %16 = trunc i64 %xor1.i.i.i.i to i8
  %17 = lshr i8 %16, 4
  %conv2.i.i.i = and i8 %17, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %call.i.i, %10
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %10, i64 noundef %call.i.i, i64 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %10, i64 noundef %call.i.i, i64 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %10
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %10, i64 noundef %call.i.i, i64 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %13, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %7
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = sub i64 %21, 90
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %cf.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  %25 = load i8, ptr %cf.i, align 1
  %tobool.i = icmp ne i8 %25, 0
  %call8.i = call zeroext i1 @__remill_compare_ult(i1 noundef zeroext %tobool.i) #16
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %22, i64 %23
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %24, ptr %MEMORY, align 8
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  ret ptr %27
}

define ptr @BB_144b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = sub i64 %4, 928
  %6 = load i64, ptr %NEXT_PC, align 8
  %7 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  %8 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %8, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %7, i64 noundef %sub.i.i, i64 noundef %6) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store i64 %6, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  ret ptr %9
}

define ptr @BB_14a5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i2, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 80
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RDX, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %17, %16
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %16
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %17
  %19 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %19, i64 noundef %16, i64 noundef %17, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %20 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %21 = and i8 %20, 1
  %conv.i.i.i = xor i8 %21, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %17
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %16
  %22 = trunc i64 %xor1.i.i.i.i to i8
  %23 = lshr i8 %22, 4
  %conv2.i.i.i = and i8 %23, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %16
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %18, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %13
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RAX, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_8(ptr noundef %28, i64 noundef %27, i8 noundef zeroext 0) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_rand(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_rand(ptr, i64, ptr) #2

define ptr @BB_1450(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.31609, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EAX, align 4
  %5 = zext i32 %4 to i64
  %6 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i126 = and i64 %5, 4294967295
  store i64 %conv.i11.i126, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EDX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %11, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %18 = ashr i64 %16, 63
  %L.sroa.2.0.insert.ext.i.i = zext i64 %18 to i128
  %L.sroa.2.0.insert.shift.i.i = shl nuw i128 %L.sroa.2.0.insert.ext.i.i, 64
  %L.sroa.0.0.insert.ext.i.i = zext i64 %16 to i128
  %L.sroa.0.0.insert.insert.i.i = or i128 %L.sroa.2.0.insert.shift.i.i, %L.sroa.0.0.insert.ext.i.i
  %mul.i.i = mul nsw i128 954437177, %L.sroa.0.0.insert.insert.i.i
  %retval.sroa.0.0.extract.trunc.i.i = trunc i128 %mul.i.i to i64
  %retval.sroa.2.0.extract.shift.i.i = lshr i128 %mul.i.i, 64
  %retval.sroa.2.0.extract.trunc.i.i = trunc i128 %retval.sroa.2.0.extract.shift.i.i to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i, ptr %RAX, align 8
  %conv2.i.i.i117 = sext i64 %retval.sroa.0.0.extract.trunc.i.i to i128
  %cmp.i.i.i118 = icmp ne i128 %mul.i.i, %conv2.i.i.i117
  %call.i.i.i119 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i118, i64 noundef %16, i64 noundef 954437177, i64 noundef %retval.sroa.0.0.extract.trunc.i.i, i64 noundef %retval.sroa.2.0.extract.trunc.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i119 to i8
  %cf.i.i120 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i120, align 1
  %call2.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i = lshr i64 %22, 31
  %call34.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i64 %shr.i136.i, 1
  store i64 %new_val.0.i, ptr %RAX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  %24 = trunc i64 %shr.i136.i to i8
  %conv.i = and i8 %24, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i135 = trunc i64 %new_val.0.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i135)
  %26 = and i8 %25, 1
  %conv67.i = xor i8 %26, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i = icmp ult i64 %shr.i136.i, 2
  %conv80.i = zext i1 %cmp.i140.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %19
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %sext167.i145 = shl i64 %30, 32
  %conv.i155.i146 = ashr exact i64 %sext167.i145, 32
  %shr.i156.i147 = ashr i64 %conv.i155.i146, 2
  %call36.i148 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i149 = icmp ne i8 %call36.i148, 0
  %shr.i160.i150 = ashr i64 %shr.i156.i147, 1
  %32 = zext i1 %tobool.i149 to i8
  %new_val.0.i151 = trunc i64 %shr.i160.i150 to i32
  %conv.i163.i152 = and i64 %shr.i160.i150, 4294967295
  store i64 %conv.i163.i152, ptr %RAX, align 8
  %cf.i153 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  %33 = trunc i64 %shr.i156.i147 to i8
  %conv.i154 = and i8 %33, 1
  store i8 %conv.i154, ptr %cf.i153, align 1
  %pf.i155 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i156 = trunc i64 %shr.i160.i150 to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i156)
  %35 = and i8 %34, 1
  %conv75.i157 = xor i8 %35, 1
  store i8 %conv75.i157, ptr %pf.i155, align 1
  %af.i158 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i148, ptr %af.i158, align 1
  %zf.i159 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i160 = icmp eq i32 %new_val.0.i151, 0
  %conv88.i161 = zext i1 %cmp.i165.i160 to i8
  store i8 %conv88.i161, ptr %zf.i159, align 1
  %sf.i162 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i163 = lshr i32 %new_val.0.i151, 31
  %conv95.i164 = trunc i32 %new_val.0.lobit.i163 to i8
  store i8 %conv95.i164, ptr %sf.i162, align 1
  %of.i165 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %32, ptr %of.i165, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %27
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 2
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i32, ptr %EDX, align 4
  %40 = zext i32 %39 to i64
  %41 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i125 = and i64 %40, 4294967295
  store i64 %conv.i11.i125, ptr %RCX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RCX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %sext167.i = shl i64 %45, 32
  %conv.i155.i = ashr exact i64 %sext167.i, 32
  %shr.i156.i = ashr i64 %conv.i155.i, 30
  %call36.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i136 = icmp ne i8 %call36.i, 0
  %shr.i160.i = ashr i64 %shr.i156.i, 1
  %47 = zext i1 %tobool.i136 to i8
  %new_val.0.i137 = trunc i64 %shr.i160.i to i32
  %conv.i163.i = and i64 %shr.i160.i, 4294967295
  store i64 %conv.i163.i, ptr %RCX, align 8
  %cf.i138 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  %48 = trunc i64 %shr.i156.i to i8
  %conv.i139 = and i8 %48, 1
  store i8 %conv.i139, ptr %cf.i138, align 1
  %pf.i140 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i = trunc i64 %shr.i160.i to i8
  %49 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i)
  %50 = and i8 %49, 1
  %conv75.i = xor i8 %50, 1
  store i8 %conv75.i, ptr %pf.i140, align 1
  %af.i141 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i, ptr %af.i141, align 1
  %zf.i142 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i = icmp eq i32 %new_val.0.i137, 0
  %conv88.i = zext i1 %cmp.i165.i to i8
  store i8 %conv88.i, ptr %zf.i142, align 1
  %sf.i143 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %new_val.0.i137, 31
  %conv95.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv95.i, ptr %sf.i143, align 1
  %of.i144 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %47, ptr %of.i144, align 1
  store ptr %46, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %42
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 2
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RAX, align 8
  %55 = load i32, ptr %ECX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i87 = trunc i64 %54 to i32
  %sub.i.i88 = sub i32 %conv.i.i87, %55
  %conv.i22.i89 = zext i32 %sub.i.i88 to i64
  store i64 %conv.i22.i89, ptr %RAX, align 8
  %cmp.i.i.i90 = icmp ult i32 %conv.i.i87, %55
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i90, i32 noundef %conv.i.i87, i32 noundef %55, i32 noundef %sub.i.i88) #15
  %conv.i23.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i32 %sub.i.i88 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %59 = and i8 %58, 1
  %conv.i.i.i95 = xor i8 %59, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i32 %55, %conv.i.i87
  %xor1.i.i.i.i98 = xor i32 %xor.i.i.i.i97, %sub.i.i88
  %60 = trunc i32 %xor1.i.i.i.i98 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i99 = and i8 %61, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i32 %conv.i.i87, %55
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i32 noundef %conv.i.i87, i32 noundef %55, i32 noundef %sub.i.i88) #15
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i32 %sub.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i32 noundef %conv.i.i87, i32 noundef %55, i32 noundef %sub.i.i88) #15
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %xor.i28.i.i.i109 = lshr i32 %xor.i.i.i.i97, 31
  %shr9.i.i.i.i110 = xor i32 %sub.i.i88, %conv.i.i87
  %xor3.i.i.i.i111 = lshr i32 %shr9.i.i.i.i110, 31
  %add.i.i.i.i112 = add nuw nsw i32 %xor3.i.i.i.i111, %xor.i28.i.i.i109
  %cmp.i29.i.i.i113 = icmp eq i32 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i32 noundef %conv.i.i87, i32 noundef %55, i32 noundef %sub.i.i88) #15
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %51
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RBP, align 8
  %66 = sub i64 %65, 12
  %67 = load i32, ptr %EAX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %call.i.i124 = call ptr @__remill_write_memory_32(ptr noundef %69, i64 noundef %66, i32 noundef %67) #15
  store ptr %call.i.i124, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %62
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RBP, align 8
  %74 = sub i64 %73, 12
  %75 = load ptr, ptr %MEMORY, align 8
  %call.i.i129 = call i32 @__remill_read_memory_32(ptr noundef %75, i64 noundef %74) #15
  %conv.i.i130 = zext i32 %call.i.i129 to i64
  store i64 %conv.i.i130, ptr %RCX, align 8
  store ptr %75, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %70
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i32, ptr %ECX, align 4
  %80 = zext i32 %79 to i64
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %80, 4294967295
  store i64 %conv.i11.i, ptr %RAX, align 8
  store ptr %81, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RAX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i177 = shl i64 %85, 2
  %conv2.i150.i178 = trunc i64 %shl.i149.i177 to i32
  %call42.i179 = call zeroext i8 @__remill_undefined_8() #16
  %tobool43.i180 = icmp ne i8 %call42.i179, 0
  %conv2.i154.i181 = shl i32 %conv2.i150.i178, 1
  %conv.i155.i183 = zext i32 %conv2.i154.i181 to i64
  store i64 %conv.i155.i183, ptr %RAX, align 8
  %cf.i184 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i185 = lshr i32 %conv2.i150.i178, 31
  %conv.i186 = trunc i32 %new_cf.0.shrunk.in.lobit.i185 to i8
  store i8 %conv.i186, ptr %cf.i184, align 1
  %pf.i187 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i188 = trunc i32 %conv2.i154.i181 to i8
  %87 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i188)
  %88 = and i8 %87, 1
  %conv72.i189 = xor i8 %88, 1
  store i8 %conv72.i189, ptr %pf.i187, align 1
  %af.i190 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i179, ptr %af.i190, align 1
  %zf.i191 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i192 = icmp eq i32 %conv2.i154.i181, 0
  %conv85.i193 = zext i1 %cmp.i157.i192 to i8
  store i8 %conv85.i193, ptr %zf.i191, align 1
  %sf.i194 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i195 = lshr i32 %conv2.i154.i181, 31
  %conv92.i196 = trunc i32 %new_val.0.lobit.i195 to i8
  store i8 %conv92.i196, ptr %sf.i194, align 1
  %of.i197 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  %conv99.i198 = zext i1 %tobool43.i180 to i8
  store i8 %conv99.i198, ptr %of.i197, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %82
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RAX, align 8
  %93 = load i32, ptr %ECX, align 4
  %94 = zext i32 %93 to i64
  %95 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %92 to i32
  %add.i.i2 = add i32 %93, %conv.i.i1
  %conv.i22.i = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i3 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i4 = icmp ult i32 %add.i.i2, %93
  %96 = or i1 %cmp.i.i.i3, %cmp1.i.i.i4
  %call.i.i.i5 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %96, i32 noundef %conv.i.i1, i32 noundef %93, i32 noundef %add.i.i2) #15
  %conv.i23.i = zext i1 %call.i.i.i5 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %add.i.i2 to i8
  %97 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %98 = and i8 %97, 1
  %conv.i.i.i8 = xor i8 %98, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 %add.i.i2, %93
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %conv.i.i1
  %99 = trunc i32 %xor1.i.i.i.i11 to i8
  %100 = lshr i8 %99, 4
  %conv2.i.i.i12 = and i8 %100, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef %93, i32 noundef %add.i.i2) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef %93, i32 noundef %add.i.i2) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i23 = lshr i32 %shr8.i.i.i.i22, 31
  %xor3.i.i.i.i24 = lshr i32 %xor.i.i.i.i10, 31
  %add.i.i.i.i25 = add nuw nsw i32 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i32 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i32 noundef %conv.i.i1, i32 noundef %93, i32 noundef %add.i.i2) #15
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %95, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %89
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 3
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RAX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i = shl i64 %104, 1
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  %conv.i155.i167 = zext i32 %conv2.i154.i to i64
  store i64 %conv.i155.i167, ptr %RAX, align 8
  %cf.i168 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv2.i150.i, 31
  %conv.i169 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i169, ptr %cf.i168, align 1
  %pf.i170 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i154.i to i8
  %106 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %107 = and i8 %106, 1
  %conv72.i = xor i8 %107, 1
  store i8 %conv72.i, ptr %pf.i170, align 1
  %af.i171 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i171, align 1
  %zf.i172 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i154.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i172, align 1
  %sf.i173 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i174 = lshr i32 %conv2.i154.i, 31
  %conv92.i175 = trunc i32 %new_val.0.lobit.i174 to i8
  store i8 %conv92.i175, ptr %sf.i173, align 1
  %of.i176 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i176, align 1
  store ptr %105, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %101
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 2
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i64, ptr %RDX, align 8
  %112 = load i32, ptr %EAX, align 4
  %113 = zext i32 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %conv.i.i59 = trunc i64 %111 to i32
  %sub.i.i = sub i32 %conv.i.i59, %112
  %conv.i22.i60 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i60, ptr %RDX, align 8
  %cmp.i.i.i61 = icmp ult i32 %conv.i.i59, %112
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i61, i32 noundef %conv.i.i59, i32 noundef %112, i32 noundef %sub.i.i) #15
  %conv.i23.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i32 %sub.i.i to i8
  %115 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %116 = and i8 %115, 1
  %conv.i.i.i66 = xor i8 %116, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i32 %112, %conv.i.i59
  %xor1.i.i.i.i69 = xor i32 %xor.i.i.i.i68, %sub.i.i
  %117 = trunc i32 %xor1.i.i.i.i69 to i8
  %118 = lshr i8 %117, 4
  %conv2.i.i.i70 = and i8 %118, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i32 %conv.i.i59, %112
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i32 noundef %conv.i.i59, i32 noundef %112, i32 noundef %sub.i.i) #15
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i32 noundef %conv.i.i59, i32 noundef %112, i32 noundef %sub.i.i) #15
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %xor.i28.i.i.i80 = lshr i32 %xor.i.i.i.i68, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i59
  %xor3.i.i.i.i81 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i82 = add nuw nsw i32 %xor3.i.i.i.i81, %xor.i28.i.i.i80
  %cmp.i29.i.i.i83 = icmp eq i32 %add.i.i.i.i82, 2
  %call.i30.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i83, i32 noundef %conv.i.i59, i32 noundef %112, i32 noundef %sub.i.i) #15
  %conv11.i.i.i85 = zext i1 %call.i30.i.i.i84 to i8
  %of.i.i.i86 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i85, ptr %of.i.i.i86, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %108
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RBP, align 8
  %123 = sub i64 %122, 12
  %124 = load i32, ptr %EDX, align 4
  %125 = zext i32 %124 to i64
  %126 = load ptr, ptr %MEMORY, align 8
  %call.i.i123 = call ptr @__remill_write_memory_32(ptr noundef %126, i64 noundef %123, i32 noundef %124) #15
  store ptr %call.i.i123, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %119
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 4
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i64, ptr %RBP, align 8
  %131 = sub i64 %130, 72
  %132 = load ptr, ptr %MEMORY, align 8
  %call.i.i132 = call i64 @__remill_read_memory_64(ptr noundef %132, i64 noundef %131) #15
  store i64 %call.i.i132, ptr %RDX, align 8
  store ptr %132, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %127
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 4
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %RBP, align 8
  %137 = sub i64 %136, 8
  %138 = load ptr, ptr %MEMORY, align 8
  %call.i.i131 = call i64 @__remill_read_memory_64(ptr noundef %138, i64 noundef %137) #15
  store i64 %call.i.i131, ptr %RAX, align 8
  store ptr %138, ptr %MEMORY, align 8
  br label %139

139:                                              ; preds = %133
  %140 = load i64, ptr %NEXT_PC, align 8
  store i64 %140, ptr %PC, align 8
  %141 = add i64 %140, 3
  store i64 %141, ptr %NEXT_PC, align 8
  %142 = load i64, ptr %RDX, align 8
  %143 = load i64, ptr %RAX, align 8
  %144 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 %143, %142
  store i64 %add.i.i30, ptr %RDX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %142
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, %143
  %145 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %145, i64 noundef %142, i64 noundef %143, i64 noundef %add.i.i30) #15
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %146 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %147 = and i8 %146, 1
  %conv.i.i.i37 = xor i8 %147, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, %143
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %142
  %148 = trunc i64 %xor1.i.i.i.i40 to i8
  %149 = lshr i8 %148, 4
  %conv2.i.i.i41 = and i8 %149, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %142, i64 noundef %143, i64 noundef %add.i.i30) #15
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %142, i64 noundef %143, i64 noundef %add.i.i30) #15
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %142
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %142, i64 noundef %143, i64 noundef %add.i.i30) #15
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %144, ptr %MEMORY, align 8
  br label %150

150:                                              ; preds = %139
  %151 = load i64, ptr %NEXT_PC, align 8
  store i64 %151, ptr %PC, align 8
  %152 = add i64 %151, 3
  store i64 %152, ptr %NEXT_PC, align 8
  %153 = load i64, ptr %RBP, align 8
  %154 = sub i64 %153, 12
  %155 = load ptr, ptr %MEMORY, align 8
  %call.i.i127 = call i32 @__remill_read_memory_32(ptr noundef %155, i64 noundef %154) #15
  %conv.i.i128 = zext i32 %call.i.i127 to i64
  store i64 %conv.i.i128, ptr %RAX, align 8
  store ptr %155, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %150
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 2
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 1
  %160 = load i32, ptr %rax.i, align 8
  %conv.i.i121 = sext i32 %160 to i64
  store i64 %conv.i.i121, ptr %rax.i, align 8
  store ptr %159, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %156
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 5
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i64, ptr %RBP, align 8
  %165 = load i64, ptr %RAX, align 8
  %166 = mul i64 %165, 1
  %167 = add i64 %164, %166
  %168 = sub i64 %167, 64
  %169 = load ptr, ptr %MEMORY, align 8
  %call.i.i133 = call zeroext i8 @__remill_read_memory_8(ptr noundef %169, i64 noundef %168) #15
  %conv.i.i134 = zext i8 %call.i.i133 to i64
  store i64 %conv.i.i134, ptr %RAX, align 8
  store ptr %169, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %161
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 2
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i64, ptr %RDX, align 8
  %174 = load i8, ptr %AL, align 1
  %175 = zext i8 %174 to i64
  %176 = load ptr, ptr %MEMORY, align 8
  %call.i.i122 = call ptr @__remill_write_memory_8(ptr noundef %176, i64 noundef %173, i8 noundef zeroext %174) #15
  store ptr %call.i.i122, ptr %MEMORY, align 8
  br label %177

177:                                              ; preds = %170
  %178 = load i64, ptr %NEXT_PC, align 8
  store i64 %178, ptr %PC, align 8
  %179 = add i64 %178, 5
  store i64 %179, ptr %NEXT_PC, align 8
  %180 = load i64, ptr %RBP, align 8
  %181 = sub i64 %180, 8
  %182 = load i64, ptr %RBP, align 8
  %183 = sub i64 %182, 8
  %184 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %184, i64 noundef %183) #15
  %add.i.i = add i64 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_64(ptr noundef %184, i64 noundef %181, i64 noundef %add.i.i) #15
  %cmp.i.i.i = icmp ult i64 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 1
  %185 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %185, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %186 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %187 = and i8 %186, 1
  %conv.i.i.i = xor i8 %187, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 1
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %call.i.i
  %188 = trunc i64 %xor1.i.i.i.i to i8
  %189 = lshr i8 %188, 4
  %conv2.i.i.i = and i8 %189, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %call.i.i, i64 noundef 1, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %177
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  ret ptr %memory
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.31609, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.31609) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #17
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.31609) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 5086, label %bb_13DE
    i64 5180, label %bb_143C
    i64 5195, label %bb_144B
    i64 5200, label %bb_1450
    i64 5275, label %bb_149B
    i64 5285, label %bb_14A5
    i64 5299, label %bb_14B3
    i64 -281474976710656, label %bb_FFFF000000000000
  ]

dead_end:                                         ; preds = %bb_FFFF000000000000, %bb_14A5, %bb_149B, %bb_1450, %bb_144B, %bb_143C, %bb_13DE, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_13DE:                                          ; preds = %entry
  %block_pc = add i64 5086, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 5086, ptr %1)
  %4 = call ptr @BB_13de(ptr %state, i64 %2, ptr %1) #18
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 5180, label %bb_143C
    i64 5299, label %bb_14B3
  ]

bb_143C:                                          ; preds = %bb_13DE, %entry
  %block_pc1 = add i64 5180, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 5180, ptr %6)
  %9 = call ptr @BB_143c(ptr %state, i64 %7, ptr %6) #18
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 5275, label %bb_149B
  ]

bb_144B:                                          ; preds = %bb_149B, %entry
  %block_pc3 = add i64 5195, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 5195, ptr %11)
  %14 = call ptr @BB_144b(ptr %state, i64 %12, ptr %11) #18
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4272, label %bb_FFFF000000000000
  ]

bb_1450:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc5 = add i64 5200, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 5200, ptr %16)
  %19 = call ptr @BB_1450(ptr %state, i64 %17, ptr %16) #18
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 5275, label %bb_149B
  ]

bb_149B:                                          ; preds = %bb_1450, %bb_143C, %entry
  %block_pc7 = add i64 5275, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 5275, ptr %21)
  %24 = call ptr @BB_149b(ptr %state, i64 %22, ptr %21) #18
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 5195, label %bb_144B
    i64 5285, label %bb_14A5
  ]

bb_14A5:                                          ; preds = %bb_149B, %entry
  %block_pc9 = add i64 5285, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 5285, ptr %26)
  %29 = call ptr @BB_14a5(ptr %state, i64 %27, ptr %26) #18
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 5299, label %bb_14B3
  ]

bb_14B3:                                          ; preds = %bb_14A5, %bb_13DE, %entry
  %block_pc11 = add i64 5299, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 5299, ptr %31)
  %34 = call ptr @BB_14b3(ptr %state, i64 %32, ptr %31) #18
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  %36 = load ptr, ptr %mem_var, align 8
  ret ptr %36

bb_FFFF000000000000:                              ; preds = %bb_144B, %entry
  %37 = load ptr, ptr %mem_var, align 8
  %38 = load i64, ptr %pc_var, align 4
  %39 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %38, ptr %37) #18
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva13 = sub i64 %40, %base
  switch i64 %next_rva13, label %dead_end [
    i64 5200, label %bb_1450
  ]

return_bb:                                        ; No predecessors!
  %41 = load ptr, ptr %mem_var, align 8
  ret ptr %41
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 5086, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.31608, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !14
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #18 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15, !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C++ TBAA"}
