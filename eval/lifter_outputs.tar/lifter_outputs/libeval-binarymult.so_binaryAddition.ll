; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.18980 = type { %struct.X86State.18979 }
%struct.X86State.18979 = type { %struct.ArchState.18948, [32 x %union.VectorReg.18951], %struct.ArithFlags.18952, %union.anon.18947, %struct.Segments.18954, %struct.AddressSpace.18956, %struct.GPR.18957, %struct.X87Stack.18960, %struct.MMX.18964, %struct.FPUStatusFlags.18965, %union.anon.18947, %union.FPU.18974, %struct.SegmentCaches.18976, %struct.K_REG.18978 }
%struct.ArchState.18948 = type { i32, i32, %union.anon.18947 }
%union.VectorReg.18951 = type { %union.vec512_t.18950 }
%union.vec512_t.18950 = type { %struct.uint64v8_t.18949 }
%struct.uint64v8_t.18949 = type { [8 x i64] }
%struct.ArithFlags.18952 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.18954 = type { i16, %union.SegmentSelector.18953, i16, %union.SegmentSelector.18953, i16, %union.SegmentSelector.18953, i16, %union.SegmentSelector.18953, i16, %union.SegmentSelector.18953, i16, %union.SegmentSelector.18953 }
%union.SegmentSelector.18953 = type { i16 }
%struct.AddressSpace.18956 = type { i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955 }
%struct.Reg.18955 = type { %union.anon.18947 }
%struct.GPR.18957 = type { i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955, i64, %struct.Reg.18955 }
%struct.X87Stack.18960 = type { [8 x %struct.anon.3.18959] }
%struct.anon.3.18959 = type { [6 x i8], %struct.float80_t.18958 }
%struct.float80_t.18958 = type { [10 x i8] }
%struct.MMX.18964 = type { [8 x %struct.anon.4.18963] }
%struct.anon.4.18963 = type { i64, %union.vec64_t.18962 }
%union.vec64_t.18962 = type { %struct.uint64v1_t.18961 }
%struct.uint64v1_t.18961 = type { [1 x i64] }
%struct.FPUStatusFlags.18965 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.18947 = type { i64 }
%union.FPU.18974 = type { %struct.anon.13.18973 }
%struct.anon.13.18973 = type { %struct.FpuFXSAVE.18972, [96 x i8] }
%struct.FpuFXSAVE.18972 = type { %union.SegmentSelector.18953, %union.SegmentSelector.18953, %union.FPUAbridgedTagWord.18966, i8, i16, i32, %union.SegmentSelector.18953, i16, i32, %union.SegmentSelector.18953, i16, %union.FPUControlStatus.18967, %union.FPUControlStatus.18967, [8 x %struct.FPUStackElem.18969], [16 x %union.vec128_t.18971] }
%union.FPUAbridgedTagWord.18966 = type { i8 }
%union.FPUControlStatus.18967 = type { i32 }
%struct.FPUStackElem.18969 = type { %union.anon.11.18968, [6 x i8] }
%union.anon.11.18968 = type { %struct.float80_t.18958 }
%union.vec128_t.18971 = type { %struct.uint128v1_t.18970 }
%struct.uint128v1_t.18970 = type { [1 x i128] }
%struct.SegmentCaches.18976 = type { %struct.SegmentShadow.18975, %struct.SegmentShadow.18975, %struct.SegmentShadow.18975, %struct.SegmentShadow.18975, %struct.SegmentShadow.18975, %struct.SegmentShadow.18975 }
%struct.SegmentShadow.18975 = type { %union.anon.18947, i32, i32 }
%struct.K_REG.18978 = type { [8 x %struct.anon.18.18977] }
%struct.anon.18.18977 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_127a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %ESI = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 100
  %25 = load i32, ptr %EDI, align 4
  %26 = zext i32 %25 to i64
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call ptr @__remill_write_memory_32(ptr noundef %27, i64 noundef %24, i32 noundef %25) #13
  store ptr %call.i.i4, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 104
  %33 = load i32, ptr %ESI, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call ptr @__remill_write_memory_32(ptr noundef %35, i64 noundef %32, i32 noundef %33) #13
  store ptr %call.i.i3, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %28
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 4
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_32(ptr noundef %41, i64 noundef %40, i32 noundef 0) #13
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 7
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 8
  %47 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %47, i64 noundef %46, i32 noundef 0) #13
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %42
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 7
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RBP, align 8
  %52 = sub i64 %51, 12
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %53, i64 noundef %52, i32 noundef 0) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %48
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 5
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  %58 = add i64 %57, 290
  %59 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 33
  store i64 %58, ptr %rip.i, align 8
  store i64 %58, ptr %NEXT_PC, align 8
  store ptr %59, ptr %MEMORY, align 8
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  ret ptr %61
}

define ptr @BB_13c4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 100
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 6
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 300
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_12a2(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDI = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 100
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i811 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i812 = zext i32 %call.i.i811 to i64
  store i64 %conv.i.i812, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EDX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i821 = shl i64 %11, 32
  %conv.i12.i822 = ashr exact i64 %sext.i821, 32
  store i64 %conv.i12.i822, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %18 = ashr i64 %16, 63
  %L.sroa.2.0.insert.ext.i.i750 = zext i64 %18 to i128
  %L.sroa.2.0.insert.shift.i.i751 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i750, 64
  %L.sroa.0.0.insert.ext.i.i752 = zext i64 %16 to i128
  %L.sroa.0.0.insert.insert.i.i753 = or i128 %L.sroa.2.0.insert.shift.i.i751, %L.sroa.0.0.insert.ext.i.i752
  %mul.i.i754 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i753
  %retval.sroa.0.0.extract.trunc.i.i755 = trunc i128 %mul.i.i754 to i64
  %retval.sroa.2.0.extract.shift.i.i756 = lshr i128 %mul.i.i754, 64
  %retval.sroa.2.0.extract.trunc.i.i757 = trunc i128 %retval.sroa.2.0.extract.shift.i.i756 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i755, ptr %RAX, align 8
  %conv2.i.i.i758 = sext i64 %retval.sroa.0.0.extract.trunc.i.i755 to i128
  %cmp.i.i.i759 = icmp ne i128 %mul.i.i754, %conv2.i.i.i758
  %call.i.i.i760 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i759, i64 noundef %16, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i755, i64 noundef %retval.sroa.2.0.extract.trunc.i.i757) #13
  %frombool.i.i761 = zext i1 %call.i.i.i760 to i8
  %cf.i.i762 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i761, ptr %cf.i.i762, align 1
  %call2.i.i763 = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i764 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i763, ptr %pf.i.i764, align 1
  %af.i.i765 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i763, ptr %af.i.i765, align 1
  %zf.i.i766 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i763, ptr %zf.i.i766, align 1
  %sf.i.i767 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i763, ptr %sf.i.i767, align 1
  %of.i.i768 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i761, ptr %of.i.i768, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i935 = lshr i64 %22, 31
  %call34.i936 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i937 = icmp ne i8 %call34.i936, 0
  %new_val.0.i938 = lshr i64 %shr.i136.i935, 1
  store i64 %new_val.0.i938, ptr %RAX, align 8
  %cf.i939 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %24 = trunc i64 %shr.i136.i935 to i8
  %conv.i940 = and i8 %24, 1
  store i8 %conv.i940, ptr %cf.i939, align 1
  %pf.i941 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i942 = trunc i64 %new_val.0.i938 to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i942)
  %26 = and i8 %25, 1
  %conv67.i943 = xor i8 %26, 1
  store i8 %conv67.i943, ptr %pf.i941, align 1
  %af.i944 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i936, ptr %af.i944, align 1
  %zf.i945 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i946 = icmp ult i64 %shr.i136.i935, 2
  %conv80.i947 = zext i1 %cmp.i140.i946 to i8
  store i8 %conv80.i947, ptr %zf.i945, align 1
  %sf.i948 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i948, align 1
  %of.i949 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i950 = zext i1 %tobool.i937 to i8
  store i8 %conv92.i950, ptr %of.i949, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %19
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %sext167.i1207 = shl i64 %30, 32
  %conv.i155.i1208 = ashr exact i64 %sext167.i1207, 32
  %shr.i156.i1209 = ashr i64 %conv.i155.i1208, 1
  %call36.i1210 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1211 = icmp ne i8 %call36.i1210, 0
  %shr.i160.i1212 = ashr i64 %shr.i156.i1209, 1
  %32 = zext i1 %tobool.i1211 to i8
  %new_val.0.i1213 = trunc i64 %shr.i160.i1212 to i32
  %conv.i163.i1214 = and i64 %shr.i160.i1212, 4294967295
  store i64 %conv.i163.i1214, ptr %RAX, align 8
  %cf.i1215 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %33 = trunc i64 %shr.i156.i1209 to i8
  %conv.i1216 = and i8 %33, 1
  store i8 %conv.i1216, ptr %cf.i1215, align 1
  %pf.i1217 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1218 = trunc i64 %shr.i160.i1212 to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1218)
  %35 = and i8 %34, 1
  %conv75.i1219 = xor i8 %35, 1
  store i8 %conv75.i1219, ptr %pf.i1217, align 1
  %af.i1220 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1210, ptr %af.i1220, align 1
  %zf.i1221 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1222 = icmp eq i32 %new_val.0.i1213, 0
  %conv88.i1223 = zext i1 %cmp.i165.i1222 to i8
  store i8 %conv88.i1223, ptr %zf.i1221, align 1
  %sf.i1224 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1225 = lshr i32 %new_val.0.i1213, 31
  %conv95.i1226 = trunc i32 %new_val.0.lobit.i1225 to i8
  store i8 %conv95.i1226, ptr %sf.i1224, align 1
  %of.i1227 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %32, ptr %of.i1227, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %27
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 2
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i32, ptr %EDX, align 4
  %40 = zext i32 %39 to i64
  %41 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i794 = and i64 %40, 4294967295
  store i64 %conv.i11.i794, ptr %RCX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RCX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %sext167.i1186 = shl i64 %45, 32
  %conv.i155.i1187 = ashr exact i64 %sext167.i1186, 32
  %shr.i156.i1188 = ashr i64 %conv.i155.i1187, 30
  %call36.i1189 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1190 = icmp ne i8 %call36.i1189, 0
  %shr.i160.i1191 = ashr i64 %shr.i156.i1188, 1
  %47 = zext i1 %tobool.i1190 to i8
  %new_val.0.i1192 = trunc i64 %shr.i160.i1191 to i32
  %conv.i163.i1193 = and i64 %shr.i160.i1191, 4294967295
  store i64 %conv.i163.i1193, ptr %RCX, align 8
  %cf.i1194 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %48 = trunc i64 %shr.i156.i1188 to i8
  %conv.i1195 = and i8 %48, 1
  store i8 %conv.i1195, ptr %cf.i1194, align 1
  %pf.i1196 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1197 = trunc i64 %shr.i160.i1191 to i8
  %49 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1197)
  %50 = and i8 %49, 1
  %conv75.i1198 = xor i8 %50, 1
  store i8 %conv75.i1198, ptr %pf.i1196, align 1
  %af.i1199 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1189, ptr %af.i1199, align 1
  %zf.i1200 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1201 = icmp eq i32 %new_val.0.i1192, 0
  %conv88.i1202 = zext i1 %cmp.i165.i1201 to i8
  store i8 %conv88.i1202, ptr %zf.i1200, align 1
  %sf.i1203 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1204 = lshr i32 %new_val.0.i1192, 31
  %conv95.i1205 = trunc i32 %new_val.0.lobit.i1204 to i8
  store i8 %conv95.i1205, ptr %sf.i1203, align 1
  %of.i1206 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %47, ptr %of.i1206, align 1
  store ptr %46, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %42
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 2
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RAX, align 8
  %55 = load i32, ptr %ECX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i640 = trunc i64 %54 to i32
  %sub.i.i641 = sub i32 %conv.i.i640, %55
  %conv.i22.i642 = zext i32 %sub.i.i641 to i64
  store i64 %conv.i22.i642, ptr %RAX, align 8
  %cmp.i.i.i643 = icmp ult i32 %conv.i.i640, %55
  %call.i.i.i644 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i643, i32 noundef %conv.i.i640, i32 noundef %55, i32 noundef %sub.i.i641) #13
  %conv.i23.i645 = zext i1 %call.i.i.i644 to i8
  %cf.i.i646 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i645, ptr %cf.i.i646, align 1
  %conv.i.i.i.i647 = trunc i32 %sub.i.i641 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i647)
  %59 = and i8 %58, 1
  %conv.i.i.i648 = xor i8 %59, 1
  %pf.i.i.i649 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i648, ptr %pf.i.i.i649, align 1
  %xor.i.i.i.i650 = xor i32 %55, %conv.i.i640
  %xor1.i.i.i.i651 = xor i32 %xor.i.i.i.i650, %sub.i.i641
  %60 = trunc i32 %xor1.i.i.i.i651 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i652 = and i8 %61, 1
  %af.i.i.i653 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i652, ptr %af.i.i.i653, align 1
  %cmp.i.i.i.i654 = icmp eq i32 %conv.i.i640, %55
  %call.i.i.i.i655 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i654, i32 noundef %conv.i.i640, i32 noundef %55, i32 noundef %sub.i.i641) #13
  %conv5.i.i.i656 = zext i1 %call.i.i.i.i655 to i8
  %zf.i.i.i657 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i656, ptr %zf.i.i.i657, align 1
  %cmp.i27.i.i.i658 = icmp slt i32 %sub.i.i641, 0
  %call1.i.i.i.i659 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i658, i32 noundef %conv.i.i640, i32 noundef %55, i32 noundef %sub.i.i641) #13
  %conv8.i.i.i660 = zext i1 %call1.i.i.i.i659 to i8
  %sf.i.i.i661 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i660, ptr %sf.i.i.i661, align 1
  %xor.i28.i.i.i662 = lshr i32 %xor.i.i.i.i650, 31
  %shr9.i.i.i.i663 = xor i32 %sub.i.i641, %conv.i.i640
  %xor3.i.i.i.i664 = lshr i32 %shr9.i.i.i.i663, 31
  %add.i.i.i.i665 = add nuw nsw i32 %xor3.i.i.i.i664, %xor.i28.i.i.i662
  %cmp.i29.i.i.i666 = icmp eq i32 %add.i.i.i.i665, 2
  %call.i30.i.i.i667 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i666, i32 noundef %conv.i.i640, i32 noundef %55, i32 noundef %sub.i.i641) #13
  %conv11.i.i.i668 = zext i1 %call.i30.i.i.i667 to i8
  %of.i.i.i669 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i668, ptr %of.i.i.i669, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %51
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 2
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i32, ptr %EAX, align 4
  %66 = zext i32 %65 to i64
  %67 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i793 = and i64 %66, 4294967295
  store i64 %conv.i11.i793, ptr %RSI, align 8
  store ptr %67, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %ESI, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i792 = and i64 %72, 4294967295
  store i64 %conv.i11.i792, ptr %RAX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RAX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i1283 = shl i64 %77, 1
  %conv2.i150.i1284 = trunc i64 %shl.i149.i1283 to i32
  %call42.i1285 = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i1286 = icmp ne i8 %call42.i1285, 0
  %conv2.i154.i1287 = shl i32 %conv2.i150.i1284, 1
  %conv.i155.i1289 = zext i32 %conv2.i154.i1287 to i64
  store i64 %conv.i155.i1289, ptr %RAX, align 8
  %cf.i1290 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i1291 = lshr i32 %conv2.i150.i1284, 31
  %conv.i1292 = trunc i32 %new_cf.0.shrunk.in.lobit.i1291 to i8
  store i8 %conv.i1292, ptr %cf.i1290, align 1
  %pf.i1293 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i1294 = trunc i32 %conv2.i154.i1287 to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i1294)
  %80 = and i8 %79, 1
  %conv72.i1295 = xor i8 %80, 1
  store i8 %conv72.i1295, ptr %pf.i1293, align 1
  %af.i1296 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i1285, ptr %af.i1296, align 1
  %zf.i1297 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1298 = icmp eq i32 %conv2.i154.i1287, 0
  %conv85.i1299 = zext i1 %cmp.i157.i1298 to i8
  store i8 %conv85.i1299, ptr %zf.i1297, align 1
  %sf.i1300 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1301 = lshr i32 %conv2.i154.i1287, 31
  %conv92.i1302 = trunc i32 %new_val.0.lobit.i1301 to i8
  store i8 %conv92.i1302, ptr %sf.i1300, align 1
  %of.i1303 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv99.i1304 = zext i1 %tobool43.i1286 to i8
  store i8 %conv99.i1304, ptr %of.i1303, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %74
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RAX, align 8
  %85 = load i32, ptr %ESI, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %conv.i.i311 = trunc i64 %84 to i32
  %add.i.i312 = add i32 %85, %conv.i.i311
  %conv.i22.i313 = zext i32 %add.i.i312 to i64
  store i64 %conv.i22.i313, ptr %RAX, align 8
  %cmp.i.i.i314 = icmp ult i32 %add.i.i312, %conv.i.i311
  %cmp1.i.i.i315 = icmp ult i32 %add.i.i312, %85
  %88 = or i1 %cmp.i.i.i314, %cmp1.i.i.i315
  %call.i.i.i316 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %88, i32 noundef %conv.i.i311, i32 noundef %85, i32 noundef %add.i.i312) #13
  %conv.i23.i317 = zext i1 %call.i.i.i316 to i8
  %cf.i.i318 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i317, ptr %cf.i.i318, align 1
  %conv.i.i.i.i319 = trunc i32 %add.i.i312 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i319)
  %90 = and i8 %89, 1
  %conv.i.i.i320 = xor i8 %90, 1
  %pf.i.i.i321 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i320, ptr %pf.i.i.i321, align 1
  %xor.i.i.i.i322 = xor i32 %add.i.i312, %85
  %xor1.i.i.i.i323 = xor i32 %xor.i.i.i.i322, %conv.i.i311
  %91 = trunc i32 %xor1.i.i.i.i323 to i8
  %92 = lshr i8 %91, 4
  %conv2.i.i.i324 = and i8 %92, 1
  %af.i.i.i325 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i324, ptr %af.i.i.i325, align 1
  %cmp.i.i.i.i326 = icmp eq i32 %add.i.i312, 0
  %call.i.i.i.i327 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i326, i32 noundef %conv.i.i311, i32 noundef %85, i32 noundef %add.i.i312) #13
  %conv5.i.i.i328 = zext i1 %call.i.i.i.i327 to i8
  %zf.i.i.i329 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i328, ptr %zf.i.i.i329, align 1
  %cmp.i27.i.i.i330 = icmp slt i32 %add.i.i312, 0
  %call1.i.i.i.i331 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i330, i32 noundef %conv.i.i311, i32 noundef %85, i32 noundef %add.i.i312) #13
  %conv8.i.i.i332 = zext i1 %call1.i.i.i.i331 to i8
  %sf.i.i.i333 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i332, ptr %sf.i.i.i333, align 1
  %shr8.i.i.i.i334 = xor i32 %add.i.i312, %conv.i.i311
  %xor.i28.i.i.i335 = lshr i32 %shr8.i.i.i.i334, 31
  %xor3.i.i.i.i336 = lshr i32 %xor.i.i.i.i322, 31
  %add.i.i.i.i337 = add nuw nsw i32 %xor.i28.i.i.i335, %xor3.i.i.i.i336
  %cmp.i29.i.i.i338 = icmp eq i32 %add.i.i.i.i337, 2
  %call.i30.i.i.i339 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i338, i32 noundef %conv.i.i311, i32 noundef %85, i32 noundef %add.i.i312) #13
  %conv11.i.i.i340 = zext i1 %call.i30.i.i.i339 to i8
  %of.i.i.i341 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i340, ptr %of.i.i.i341, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %81
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 2
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load i32, ptr %EAX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %conv.i.i280 = trunc i64 %96 to i32
  %add.i.i281 = add i32 %97, %conv.i.i280
  %conv.i22.i282 = zext i32 %add.i.i281 to i64
  store i64 %conv.i22.i282, ptr %RAX, align 8
  %cmp.i.i.i283 = icmp ult i32 %add.i.i281, %conv.i.i280
  %cmp1.i.i.i284 = icmp ult i32 %add.i.i281, %97
  %100 = or i1 %cmp.i.i.i283, %cmp1.i.i.i284
  %call.i.i.i285 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %100, i32 noundef %conv.i.i280, i32 noundef %97, i32 noundef %add.i.i281) #13
  %conv.i23.i286 = zext i1 %call.i.i.i285 to i8
  %cf.i.i287 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i286, ptr %cf.i.i287, align 1
  %conv.i.i.i.i288 = trunc i32 %add.i.i281 to i8
  %101 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i288)
  %102 = and i8 %101, 1
  %conv.i.i.i289 = xor i8 %102, 1
  %pf.i.i.i290 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i289, ptr %pf.i.i.i290, align 1
  %xor.i.i.i.i291 = xor i32 %add.i.i281, %97
  %xor1.i.i.i.i292 = xor i32 %xor.i.i.i.i291, %conv.i.i280
  %103 = trunc i32 %xor1.i.i.i.i292 to i8
  %104 = lshr i8 %103, 4
  %conv2.i.i.i293 = and i8 %104, 1
  %af.i.i.i294 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i293, ptr %af.i.i.i294, align 1
  %cmp.i.i.i.i295 = icmp eq i32 %add.i.i281, 0
  %call.i.i.i.i296 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i295, i32 noundef %conv.i.i280, i32 noundef %97, i32 noundef %add.i.i281) #13
  %conv5.i.i.i297 = zext i1 %call.i.i.i.i296 to i8
  %zf.i.i.i298 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i297, ptr %zf.i.i.i298, align 1
  %cmp.i27.i.i.i299 = icmp slt i32 %add.i.i281, 0
  %call1.i.i.i.i300 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i299, i32 noundef %conv.i.i280, i32 noundef %97, i32 noundef %add.i.i281) #13
  %conv8.i.i.i301 = zext i1 %call1.i.i.i.i300 to i8
  %sf.i.i.i302 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i301, ptr %sf.i.i.i302, align 1
  %shr8.i.i.i.i303 = xor i32 %add.i.i281, %conv.i.i280
  %xor.i28.i.i.i304 = lshr i32 %shr8.i.i.i.i303, 31
  %xor3.i.i.i.i305 = lshr i32 %xor.i.i.i.i291, 31
  %add.i.i.i.i306 = add nuw nsw i32 %xor.i28.i.i.i304, %xor3.i.i.i.i305
  %cmp.i29.i.i.i307 = icmp eq i32 %add.i.i.i.i306, 2
  %call.i30.i.i.i308 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i307, i32 noundef %conv.i.i280, i32 noundef %97, i32 noundef %add.i.i281) #13
  %conv11.i.i.i309 = zext i1 %call.i30.i.i.i308 to i8
  %of.i.i.i310 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i309, ptr %of.i.i.i310, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %93
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 2
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i32, ptr %EDX, align 4
  %109 = zext i32 %108 to i64
  %110 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i791 = and i64 %109, 4294967295
  store i64 %conv.i11.i791, ptr %RSI, align 8
  store ptr %110, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 2
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i64, ptr %RSI, align 8
  %115 = load i32, ptr %EAX, align 4
  %116 = zext i32 %115 to i64
  %117 = load ptr, ptr %MEMORY, align 8
  %conv.i.i610 = trunc i64 %114 to i32
  %sub.i.i611 = sub i32 %conv.i.i610, %115
  %conv.i22.i612 = zext i32 %sub.i.i611 to i64
  store i64 %conv.i22.i612, ptr %RSI, align 8
  %cmp.i.i.i613 = icmp ult i32 %conv.i.i610, %115
  %call.i.i.i614 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i613, i32 noundef %conv.i.i610, i32 noundef %115, i32 noundef %sub.i.i611) #13
  %conv.i23.i615 = zext i1 %call.i.i.i614 to i8
  %cf.i.i616 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i615, ptr %cf.i.i616, align 1
  %conv.i.i.i.i617 = trunc i32 %sub.i.i611 to i8
  %118 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i617)
  %119 = and i8 %118, 1
  %conv.i.i.i618 = xor i8 %119, 1
  %pf.i.i.i619 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i618, ptr %pf.i.i.i619, align 1
  %xor.i.i.i.i620 = xor i32 %115, %conv.i.i610
  %xor1.i.i.i.i621 = xor i32 %xor.i.i.i.i620, %sub.i.i611
  %120 = trunc i32 %xor1.i.i.i.i621 to i8
  %121 = lshr i8 %120, 4
  %conv2.i.i.i622 = and i8 %121, 1
  %af.i.i.i623 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i622, ptr %af.i.i.i623, align 1
  %cmp.i.i.i.i624 = icmp eq i32 %conv.i.i610, %115
  %call.i.i.i.i625 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i624, i32 noundef %conv.i.i610, i32 noundef %115, i32 noundef %sub.i.i611) #13
  %conv5.i.i.i626 = zext i1 %call.i.i.i.i625 to i8
  %zf.i.i.i627 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i626, ptr %zf.i.i.i627, align 1
  %cmp.i27.i.i.i628 = icmp slt i32 %sub.i.i611, 0
  %call1.i.i.i.i629 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i628, i32 noundef %conv.i.i610, i32 noundef %115, i32 noundef %sub.i.i611) #13
  %conv8.i.i.i630 = zext i1 %call1.i.i.i.i629 to i8
  %sf.i.i.i631 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i630, ptr %sf.i.i.i631, align 1
  %xor.i28.i.i.i632 = lshr i32 %xor.i.i.i.i620, 31
  %shr9.i.i.i.i633 = xor i32 %sub.i.i611, %conv.i.i610
  %xor3.i.i.i.i634 = lshr i32 %shr9.i.i.i.i633, 31
  %add.i.i.i.i635 = add nuw nsw i32 %xor3.i.i.i.i634, %xor.i28.i.i.i632
  %cmp.i29.i.i.i636 = icmp eq i32 %add.i.i.i.i635, 2
  %call.i30.i.i.i637 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i636, i32 noundef %conv.i.i610, i32 noundef %115, i32 noundef %sub.i.i611) #13
  %conv11.i.i.i638 = zext i1 %call.i30.i.i.i637 to i8
  %of.i.i.i639 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i638, ptr %of.i.i.i639, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %111
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 3
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load i64, ptr %RBP, align 8
  %126 = sub i64 %125, 104
  %127 = load ptr, ptr %MEMORY, align 8
  %call.i.i809 = call i32 @__remill_read_memory_32(ptr noundef %127, i64 noundef %126) #13
  %conv.i.i810 = zext i32 %call.i.i809 to i64
  store i64 %conv.i.i810, ptr %RDX, align 8
  store ptr %127, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %122
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 3
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load i32, ptr %EDX, align 4
  %132 = zext i32 %131 to i64
  %133 = load ptr, ptr %MEMORY, align 8
  %sext.i819 = shl i64 %132, 32
  %conv.i12.i820 = ashr exact i64 %sext.i819, 32
  store i64 %conv.i12.i820, ptr %RAX, align 8
  store ptr %133, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %128
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 7
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RAX, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  %139 = ashr i64 %137, 63
  %L.sroa.2.0.insert.ext.i.i731 = zext i64 %139 to i128
  %L.sroa.2.0.insert.shift.i.i732 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i731, 64
  %L.sroa.0.0.insert.ext.i.i733 = zext i64 %137 to i128
  %L.sroa.0.0.insert.insert.i.i734 = or i128 %L.sroa.2.0.insert.shift.i.i732, %L.sroa.0.0.insert.ext.i.i733
  %mul.i.i735 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i734
  %retval.sroa.0.0.extract.trunc.i.i736 = trunc i128 %mul.i.i735 to i64
  %retval.sroa.2.0.extract.shift.i.i737 = lshr i128 %mul.i.i735, 64
  %retval.sroa.2.0.extract.trunc.i.i738 = trunc i128 %retval.sroa.2.0.extract.shift.i.i737 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i736, ptr %RAX, align 8
  %conv2.i.i.i739 = sext i64 %retval.sroa.0.0.extract.trunc.i.i736 to i128
  %cmp.i.i.i740 = icmp ne i128 %mul.i.i735, %conv2.i.i.i739
  %call.i.i.i741 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i740, i64 noundef %137, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i736, i64 noundef %retval.sroa.2.0.extract.trunc.i.i738) #13
  %frombool.i.i742 = zext i1 %call.i.i.i741 to i8
  %cf.i.i743 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i742, ptr %cf.i.i743, align 1
  %call2.i.i744 = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i745 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i744, ptr %pf.i.i745, align 1
  %af.i.i746 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i744, ptr %af.i.i746, align 1
  %zf.i.i747 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i744, ptr %zf.i.i747, align 1
  %sf.i.i748 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i744, ptr %sf.i.i748, align 1
  %of.i.i749 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i742, ptr %of.i.i749, align 1
  store ptr %138, ptr %MEMORY, align 8
  br label %140

140:                                              ; preds = %134
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = add i64 %141, 4
  store i64 %142, ptr %NEXT_PC, align 8
  %143 = load i64, ptr %RAX, align 8
  %144 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i919 = lshr i64 %143, 31
  %call34.i920 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i921 = icmp ne i8 %call34.i920, 0
  %new_val.0.i922 = lshr i64 %shr.i136.i919, 1
  store i64 %new_val.0.i922, ptr %RAX, align 8
  %cf.i923 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %145 = trunc i64 %shr.i136.i919 to i8
  %conv.i924 = and i8 %145, 1
  store i8 %conv.i924, ptr %cf.i923, align 1
  %pf.i925 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i926 = trunc i64 %new_val.0.i922 to i8
  %146 = call i8 @llvm.ctpop.i8(i8 %conv.i.i926)
  %147 = and i8 %146, 1
  %conv67.i927 = xor i8 %147, 1
  store i8 %conv67.i927, ptr %pf.i925, align 1
  %af.i928 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i920, ptr %af.i928, align 1
  %zf.i929 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i930 = icmp ult i64 %shr.i136.i919, 2
  %conv80.i931 = zext i1 %cmp.i140.i930 to i8
  store i8 %conv80.i931, ptr %zf.i929, align 1
  %sf.i932 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i932, align 1
  %of.i933 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i934 = zext i1 %tobool.i921 to i8
  store i8 %conv92.i934, ptr %of.i933, align 1
  store ptr %144, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %140
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RAX, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %sext167.i1165 = shl i64 %151, 32
  %conv.i155.i1166 = ashr exact i64 %sext167.i1165, 32
  %shr.i156.i1167 = ashr i64 %conv.i155.i1166, 1
  %call36.i1168 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1169 = icmp ne i8 %call36.i1168, 0
  %shr.i160.i1170 = ashr i64 %shr.i156.i1167, 1
  %153 = zext i1 %tobool.i1169 to i8
  %new_val.0.i1171 = trunc i64 %shr.i160.i1170 to i32
  %conv.i163.i1172 = and i64 %shr.i160.i1170, 4294967295
  store i64 %conv.i163.i1172, ptr %RAX, align 8
  %cf.i1173 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %154 = trunc i64 %shr.i156.i1167 to i8
  %conv.i1174 = and i8 %154, 1
  store i8 %conv.i1174, ptr %cf.i1173, align 1
  %pf.i1175 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1176 = trunc i64 %shr.i160.i1170 to i8
  %155 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1176)
  %156 = and i8 %155, 1
  %conv75.i1177 = xor i8 %156, 1
  store i8 %conv75.i1177, ptr %pf.i1175, align 1
  %af.i1178 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1168, ptr %af.i1178, align 1
  %zf.i1179 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1180 = icmp eq i32 %new_val.0.i1171, 0
  %conv88.i1181 = zext i1 %cmp.i165.i1180 to i8
  store i8 %conv88.i1181, ptr %zf.i1179, align 1
  %sf.i1182 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1183 = lshr i32 %new_val.0.i1171, 31
  %conv95.i1184 = trunc i32 %new_val.0.lobit.i1183 to i8
  store i8 %conv95.i1184, ptr %sf.i1182, align 1
  %of.i1185 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %153, ptr %of.i1185, align 1
  store ptr %152, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %148
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 2
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load i32, ptr %EDX, align 4
  %161 = zext i32 %160 to i64
  %162 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i790 = and i64 %161, 4294967295
  store i64 %conv.i11.i790, ptr %RDI, align 8
  store ptr %162, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %157
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 3
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %RDI, align 8
  %167 = load ptr, ptr %MEMORY, align 8
  %sext167.i1144 = shl i64 %166, 32
  %conv.i155.i1145 = ashr exact i64 %sext167.i1144, 32
  %shr.i156.i1146 = ashr i64 %conv.i155.i1145, 30
  %call36.i1147 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1148 = icmp ne i8 %call36.i1147, 0
  %shr.i160.i1149 = ashr i64 %shr.i156.i1146, 1
  %168 = zext i1 %tobool.i1148 to i8
  %new_val.0.i1150 = trunc i64 %shr.i160.i1149 to i32
  %conv.i163.i1151 = and i64 %shr.i160.i1149, 4294967295
  store i64 %conv.i163.i1151, ptr %RDI, align 8
  %cf.i1152 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %169 = trunc i64 %shr.i156.i1146 to i8
  %conv.i1153 = and i8 %169, 1
  store i8 %conv.i1153, ptr %cf.i1152, align 1
  %pf.i1154 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1155 = trunc i64 %shr.i160.i1149 to i8
  %170 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1155)
  %171 = and i8 %170, 1
  %conv75.i1156 = xor i8 %171, 1
  store i8 %conv75.i1156, ptr %pf.i1154, align 1
  %af.i1157 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1147, ptr %af.i1157, align 1
  %zf.i1158 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1159 = icmp eq i32 %new_val.0.i1150, 0
  %conv88.i1160 = zext i1 %cmp.i165.i1159 to i8
  store i8 %conv88.i1160, ptr %zf.i1158, align 1
  %sf.i1161 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1162 = lshr i32 %new_val.0.i1150, 31
  %conv95.i1163 = trunc i32 %new_val.0.lobit.i1162 to i8
  store i8 %conv95.i1163, ptr %sf.i1161, align 1
  %of.i1164 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %168, ptr %of.i1164, align 1
  store ptr %167, ptr %MEMORY, align 8
  br label %172

172:                                              ; preds = %163
  %173 = load i64, ptr %NEXT_PC, align 8
  store i64 %173, ptr %PC, align 8
  %174 = add i64 %173, 2
  store i64 %174, ptr %NEXT_PC, align 8
  %175 = load i64, ptr %RAX, align 8
  %176 = load i32, ptr %EDI, align 4
  %177 = zext i32 %176 to i64
  %178 = load ptr, ptr %MEMORY, align 8
  %conv.i.i580 = trunc i64 %175 to i32
  %sub.i.i581 = sub i32 %conv.i.i580, %176
  %conv.i22.i582 = zext i32 %sub.i.i581 to i64
  store i64 %conv.i22.i582, ptr %RAX, align 8
  %cmp.i.i.i583 = icmp ult i32 %conv.i.i580, %176
  %call.i.i.i584 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i583, i32 noundef %conv.i.i580, i32 noundef %176, i32 noundef %sub.i.i581) #13
  %conv.i23.i585 = zext i1 %call.i.i.i584 to i8
  %cf.i.i586 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i585, ptr %cf.i.i586, align 1
  %conv.i.i.i.i587 = trunc i32 %sub.i.i581 to i8
  %179 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i587)
  %180 = and i8 %179, 1
  %conv.i.i.i588 = xor i8 %180, 1
  %pf.i.i.i589 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i588, ptr %pf.i.i.i589, align 1
  %xor.i.i.i.i590 = xor i32 %176, %conv.i.i580
  %xor1.i.i.i.i591 = xor i32 %xor.i.i.i.i590, %sub.i.i581
  %181 = trunc i32 %xor1.i.i.i.i591 to i8
  %182 = lshr i8 %181, 4
  %conv2.i.i.i592 = and i8 %182, 1
  %af.i.i.i593 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i592, ptr %af.i.i.i593, align 1
  %cmp.i.i.i.i594 = icmp eq i32 %conv.i.i580, %176
  %call.i.i.i.i595 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i594, i32 noundef %conv.i.i580, i32 noundef %176, i32 noundef %sub.i.i581) #13
  %conv5.i.i.i596 = zext i1 %call.i.i.i.i595 to i8
  %zf.i.i.i597 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i596, ptr %zf.i.i.i597, align 1
  %cmp.i27.i.i.i598 = icmp slt i32 %sub.i.i581, 0
  %call1.i.i.i.i599 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i598, i32 noundef %conv.i.i580, i32 noundef %176, i32 noundef %sub.i.i581) #13
  %conv8.i.i.i600 = zext i1 %call1.i.i.i.i599 to i8
  %sf.i.i.i601 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i600, ptr %sf.i.i.i601, align 1
  %xor.i28.i.i.i602 = lshr i32 %xor.i.i.i.i590, 31
  %shr9.i.i.i.i603 = xor i32 %sub.i.i581, %conv.i.i580
  %xor3.i.i.i.i604 = lshr i32 %shr9.i.i.i.i603, 31
  %add.i.i.i.i605 = add nuw nsw i32 %xor3.i.i.i.i604, %xor.i28.i.i.i602
  %cmp.i29.i.i.i606 = icmp eq i32 %add.i.i.i.i605, 2
  %call.i30.i.i.i607 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i606, i32 noundef %conv.i.i580, i32 noundef %176, i32 noundef %sub.i.i581) #13
  %conv11.i.i.i608 = zext i1 %call.i30.i.i.i607 to i8
  %of.i.i.i609 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i608, ptr %of.i.i.i609, align 1
  store ptr %178, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %172
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 2
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i32, ptr %EAX, align 4
  %187 = zext i32 %186 to i64
  %188 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i789 = and i64 %187, 4294967295
  store i64 %conv.i11.i789, ptr %RCX, align 8
  store ptr %188, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %183
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 2
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i32, ptr %ECX, align 4
  %193 = zext i32 %192 to i64
  %194 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i788 = and i64 %193, 4294967295
  store i64 %conv.i11.i788, ptr %RAX, align 8
  store ptr %194, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %189
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 3
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i64, ptr %RAX, align 8
  %199 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i1261 = shl i64 %198, 1
  %conv2.i150.i1262 = trunc i64 %shl.i149.i1261 to i32
  %call42.i1263 = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i1264 = icmp ne i8 %call42.i1263, 0
  %conv2.i154.i1265 = shl i32 %conv2.i150.i1262, 1
  %conv.i155.i1267 = zext i32 %conv2.i154.i1265 to i64
  store i64 %conv.i155.i1267, ptr %RAX, align 8
  %cf.i1268 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i1269 = lshr i32 %conv2.i150.i1262, 31
  %conv.i1270 = trunc i32 %new_cf.0.shrunk.in.lobit.i1269 to i8
  store i8 %conv.i1270, ptr %cf.i1268, align 1
  %pf.i1271 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i1272 = trunc i32 %conv2.i154.i1265 to i8
  %200 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i1272)
  %201 = and i8 %200, 1
  %conv72.i1273 = xor i8 %201, 1
  store i8 %conv72.i1273, ptr %pf.i1271, align 1
  %af.i1274 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i1263, ptr %af.i1274, align 1
  %zf.i1275 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1276 = icmp eq i32 %conv2.i154.i1265, 0
  %conv85.i1277 = zext i1 %cmp.i157.i1276 to i8
  store i8 %conv85.i1277, ptr %zf.i1275, align 1
  %sf.i1278 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1279 = lshr i32 %conv2.i154.i1265, 31
  %conv92.i1280 = trunc i32 %new_val.0.lobit.i1279 to i8
  store i8 %conv92.i1280, ptr %sf.i1278, align 1
  %of.i1281 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv99.i1282 = zext i1 %tobool43.i1264 to i8
  store i8 %conv99.i1282, ptr %of.i1281, align 1
  store ptr %199, ptr %MEMORY, align 8
  br label %202

202:                                              ; preds = %195
  %203 = load i64, ptr %NEXT_PC, align 8
  store i64 %203, ptr %PC, align 8
  %204 = add i64 %203, 2
  store i64 %204, ptr %NEXT_PC, align 8
  %205 = load i64, ptr %RAX, align 8
  %206 = load i32, ptr %ECX, align 4
  %207 = zext i32 %206 to i64
  %208 = load ptr, ptr %MEMORY, align 8
  %conv.i.i249 = trunc i64 %205 to i32
  %add.i.i250 = add i32 %206, %conv.i.i249
  %conv.i22.i251 = zext i32 %add.i.i250 to i64
  store i64 %conv.i22.i251, ptr %RAX, align 8
  %cmp.i.i.i252 = icmp ult i32 %add.i.i250, %conv.i.i249
  %cmp1.i.i.i253 = icmp ult i32 %add.i.i250, %206
  %209 = or i1 %cmp.i.i.i252, %cmp1.i.i.i253
  %call.i.i.i254 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %209, i32 noundef %conv.i.i249, i32 noundef %206, i32 noundef %add.i.i250) #13
  %conv.i23.i255 = zext i1 %call.i.i.i254 to i8
  %cf.i.i256 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i255, ptr %cf.i.i256, align 1
  %conv.i.i.i.i257 = trunc i32 %add.i.i250 to i8
  %210 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i257)
  %211 = and i8 %210, 1
  %conv.i.i.i258 = xor i8 %211, 1
  %pf.i.i.i259 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i258, ptr %pf.i.i.i259, align 1
  %xor.i.i.i.i260 = xor i32 %add.i.i250, %206
  %xor1.i.i.i.i261 = xor i32 %xor.i.i.i.i260, %conv.i.i249
  %212 = trunc i32 %xor1.i.i.i.i261 to i8
  %213 = lshr i8 %212, 4
  %conv2.i.i.i262 = and i8 %213, 1
  %af.i.i.i263 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i262, ptr %af.i.i.i263, align 1
  %cmp.i.i.i.i264 = icmp eq i32 %add.i.i250, 0
  %call.i.i.i.i265 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i264, i32 noundef %conv.i.i249, i32 noundef %206, i32 noundef %add.i.i250) #13
  %conv5.i.i.i266 = zext i1 %call.i.i.i.i265 to i8
  %zf.i.i.i267 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i266, ptr %zf.i.i.i267, align 1
  %cmp.i27.i.i.i268 = icmp slt i32 %add.i.i250, 0
  %call1.i.i.i.i269 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i268, i32 noundef %conv.i.i249, i32 noundef %206, i32 noundef %add.i.i250) #13
  %conv8.i.i.i270 = zext i1 %call1.i.i.i.i269 to i8
  %sf.i.i.i271 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i270, ptr %sf.i.i.i271, align 1
  %shr8.i.i.i.i272 = xor i32 %add.i.i250, %conv.i.i249
  %xor.i28.i.i.i273 = lshr i32 %shr8.i.i.i.i272, 31
  %xor3.i.i.i.i274 = lshr i32 %xor.i.i.i.i260, 31
  %add.i.i.i.i275 = add nuw nsw i32 %xor.i28.i.i.i273, %xor3.i.i.i.i274
  %cmp.i29.i.i.i276 = icmp eq i32 %add.i.i.i.i275, 2
  %call.i30.i.i.i277 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i276, i32 noundef %conv.i.i249, i32 noundef %206, i32 noundef %add.i.i250) #13
  %conv11.i.i.i278 = zext i1 %call.i30.i.i.i277 to i8
  %of.i.i.i279 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i278, ptr %of.i.i.i279, align 1
  store ptr %208, ptr %MEMORY, align 8
  br label %214

214:                                              ; preds = %202
  %215 = load i64, ptr %NEXT_PC, align 8
  store i64 %215, ptr %PC, align 8
  %216 = add i64 %215, 2
  store i64 %216, ptr %NEXT_PC, align 8
  %217 = load i64, ptr %RAX, align 8
  %218 = load i32, ptr %EAX, align 4
  %219 = zext i32 %218 to i64
  %220 = load ptr, ptr %MEMORY, align 8
  %conv.i.i218 = trunc i64 %217 to i32
  %add.i.i219 = add i32 %218, %conv.i.i218
  %conv.i22.i220 = zext i32 %add.i.i219 to i64
  store i64 %conv.i22.i220, ptr %RAX, align 8
  %cmp.i.i.i221 = icmp ult i32 %add.i.i219, %conv.i.i218
  %cmp1.i.i.i222 = icmp ult i32 %add.i.i219, %218
  %221 = or i1 %cmp.i.i.i221, %cmp1.i.i.i222
  %call.i.i.i223 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %221, i32 noundef %conv.i.i218, i32 noundef %218, i32 noundef %add.i.i219) #13
  %conv.i23.i224 = zext i1 %call.i.i.i223 to i8
  %cf.i.i225 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i224, ptr %cf.i.i225, align 1
  %conv.i.i.i.i226 = trunc i32 %add.i.i219 to i8
  %222 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i226)
  %223 = and i8 %222, 1
  %conv.i.i.i227 = xor i8 %223, 1
  %pf.i.i.i228 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i227, ptr %pf.i.i.i228, align 1
  %xor.i.i.i.i229 = xor i32 %add.i.i219, %218
  %xor1.i.i.i.i230 = xor i32 %xor.i.i.i.i229, %conv.i.i218
  %224 = trunc i32 %xor1.i.i.i.i230 to i8
  %225 = lshr i8 %224, 4
  %conv2.i.i.i231 = and i8 %225, 1
  %af.i.i.i232 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i231, ptr %af.i.i.i232, align 1
  %cmp.i.i.i.i233 = icmp eq i32 %add.i.i219, 0
  %call.i.i.i.i234 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i233, i32 noundef %conv.i.i218, i32 noundef %218, i32 noundef %add.i.i219) #13
  %conv5.i.i.i235 = zext i1 %call.i.i.i.i234 to i8
  %zf.i.i.i236 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i235, ptr %zf.i.i.i236, align 1
  %cmp.i27.i.i.i237 = icmp slt i32 %add.i.i219, 0
  %call1.i.i.i.i238 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i237, i32 noundef %conv.i.i218, i32 noundef %218, i32 noundef %add.i.i219) #13
  %conv8.i.i.i239 = zext i1 %call1.i.i.i.i238 to i8
  %sf.i.i.i240 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i239, ptr %sf.i.i.i240, align 1
  %shr8.i.i.i.i241 = xor i32 %add.i.i219, %conv.i.i218
  %xor.i28.i.i.i242 = lshr i32 %shr8.i.i.i.i241, 31
  %xor3.i.i.i.i243 = lshr i32 %xor.i.i.i.i229, 31
  %add.i.i.i.i244 = add nuw nsw i32 %xor.i28.i.i.i242, %xor3.i.i.i.i243
  %cmp.i29.i.i.i245 = icmp eq i32 %add.i.i.i.i244, 2
  %call.i30.i.i.i246 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i245, i32 noundef %conv.i.i218, i32 noundef %218, i32 noundef %add.i.i219) #13
  %conv11.i.i.i247 = zext i1 %call.i30.i.i.i246 to i8
  %of.i.i.i248 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i247, ptr %of.i.i.i248, align 1
  store ptr %220, ptr %MEMORY, align 8
  br label %226

226:                                              ; preds = %214
  %227 = load i64, ptr %NEXT_PC, align 8
  store i64 %227, ptr %PC, align 8
  %228 = add i64 %227, 2
  store i64 %228, ptr %NEXT_PC, align 8
  %229 = load i32, ptr %EDX, align 4
  %230 = zext i32 %229 to i64
  %231 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i787 = and i64 %230, 4294967295
  store i64 %conv.i11.i787, ptr %RCX, align 8
  store ptr %231, ptr %MEMORY, align 8
  br label %232

232:                                              ; preds = %226
  %233 = load i64, ptr %NEXT_PC, align 8
  store i64 %233, ptr %PC, align 8
  %234 = add i64 %233, 2
  store i64 %234, ptr %NEXT_PC, align 8
  %235 = load i64, ptr %RCX, align 8
  %236 = load i32, ptr %EAX, align 4
  %237 = zext i32 %236 to i64
  %238 = load ptr, ptr %MEMORY, align 8
  %conv.i.i550 = trunc i64 %235 to i32
  %sub.i.i551 = sub i32 %conv.i.i550, %236
  %conv.i22.i552 = zext i32 %sub.i.i551 to i64
  store i64 %conv.i22.i552, ptr %RCX, align 8
  %cmp.i.i.i553 = icmp ult i32 %conv.i.i550, %236
  %call.i.i.i554 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i553, i32 noundef %conv.i.i550, i32 noundef %236, i32 noundef %sub.i.i551) #13
  %conv.i23.i555 = zext i1 %call.i.i.i554 to i8
  %cf.i.i556 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i555, ptr %cf.i.i556, align 1
  %conv.i.i.i.i557 = trunc i32 %sub.i.i551 to i8
  %239 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i557)
  %240 = and i8 %239, 1
  %conv.i.i.i558 = xor i8 %240, 1
  %pf.i.i.i559 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i558, ptr %pf.i.i.i559, align 1
  %xor.i.i.i.i560 = xor i32 %236, %conv.i.i550
  %xor1.i.i.i.i561 = xor i32 %xor.i.i.i.i560, %sub.i.i551
  %241 = trunc i32 %xor1.i.i.i.i561 to i8
  %242 = lshr i8 %241, 4
  %conv2.i.i.i562 = and i8 %242, 1
  %af.i.i.i563 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i562, ptr %af.i.i.i563, align 1
  %cmp.i.i.i.i564 = icmp eq i32 %conv.i.i550, %236
  %call.i.i.i.i565 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i564, i32 noundef %conv.i.i550, i32 noundef %236, i32 noundef %sub.i.i551) #13
  %conv5.i.i.i566 = zext i1 %call.i.i.i.i565 to i8
  %zf.i.i.i567 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i566, ptr %zf.i.i.i567, align 1
  %cmp.i27.i.i.i568 = icmp slt i32 %sub.i.i551, 0
  %call1.i.i.i.i569 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i568, i32 noundef %conv.i.i550, i32 noundef %236, i32 noundef %sub.i.i551) #13
  %conv8.i.i.i570 = zext i1 %call1.i.i.i.i569 to i8
  %sf.i.i.i571 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i570, ptr %sf.i.i.i571, align 1
  %xor.i28.i.i.i572 = lshr i32 %xor.i.i.i.i560, 31
  %shr9.i.i.i.i573 = xor i32 %sub.i.i551, %conv.i.i550
  %xor3.i.i.i.i574 = lshr i32 %shr9.i.i.i.i573, 31
  %add.i.i.i.i575 = add nuw nsw i32 %xor3.i.i.i.i574, %xor.i28.i.i.i572
  %cmp.i29.i.i.i576 = icmp eq i32 %add.i.i.i.i575, 2
  %call.i30.i.i.i577 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i576, i32 noundef %conv.i.i550, i32 noundef %236, i32 noundef %sub.i.i551) #13
  %conv11.i.i.i578 = zext i1 %call.i30.i.i.i577 to i8
  %of.i.i.i579 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i578, ptr %of.i.i.i579, align 1
  store ptr %238, ptr %MEMORY, align 8
  br label %243

243:                                              ; preds = %232
  %244 = load i64, ptr %NEXT_PC, align 8
  store i64 %244, ptr %PC, align 8
  %245 = add i64 %244, 3
  store i64 %245, ptr %NEXT_PC, align 8
  %246 = load i64, ptr %RSI, align 8
  %247 = load i64, ptr %RCX, align 8
  %248 = mul i64 %247, 1
  %249 = add i64 %246, %248
  %250 = load ptr, ptr %MEMORY, align 8
  %conv.i.i837 = and i64 %249, 4294967295
  store i64 %conv.i.i837, ptr %RDX, align 8
  store ptr %250, ptr %MEMORY, align 8
  br label %251

251:                                              ; preds = %243
  %252 = load i64, ptr %NEXT_PC, align 8
  store i64 %252, ptr %PC, align 8
  %253 = add i64 %252, 3
  store i64 %253, ptr %NEXT_PC, align 8
  %254 = load i64, ptr %RBP, align 8
  %255 = sub i64 %254, 8
  %256 = load ptr, ptr %MEMORY, align 8
  %call.i.i807 = call i32 @__remill_read_memory_32(ptr noundef %256, i64 noundef %255) #13
  %conv.i.i808 = zext i32 %call.i.i807 to i64
  store i64 %conv.i.i808, ptr %RAX, align 8
  store ptr %256, ptr %MEMORY, align 8
  br label %257

257:                                              ; preds = %251
  %258 = load i64, ptr %NEXT_PC, align 8
  store i64 %258, ptr %PC, align 8
  %259 = add i64 %258, 2
  store i64 %259, ptr %NEXT_PC, align 8
  %260 = load i64, ptr %RDX, align 8
  %261 = load i32, ptr %EAX, align 4
  %262 = zext i32 %261 to i64
  %263 = load ptr, ptr %MEMORY, align 8
  %conv.i.i187 = trunc i64 %260 to i32
  %add.i.i188 = add i32 %261, %conv.i.i187
  %conv.i22.i189 = zext i32 %add.i.i188 to i64
  store i64 %conv.i22.i189, ptr %RDX, align 8
  %cmp.i.i.i190 = icmp ult i32 %add.i.i188, %conv.i.i187
  %cmp1.i.i.i191 = icmp ult i32 %add.i.i188, %261
  %264 = or i1 %cmp.i.i.i190, %cmp1.i.i.i191
  %call.i.i.i192 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %264, i32 noundef %conv.i.i187, i32 noundef %261, i32 noundef %add.i.i188) #13
  %conv.i23.i193 = zext i1 %call.i.i.i192 to i8
  %cf.i.i194 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i193, ptr %cf.i.i194, align 1
  %conv.i.i.i.i195 = trunc i32 %add.i.i188 to i8
  %265 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i195)
  %266 = and i8 %265, 1
  %conv.i.i.i196 = xor i8 %266, 1
  %pf.i.i.i197 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i196, ptr %pf.i.i.i197, align 1
  %xor.i.i.i.i198 = xor i32 %add.i.i188, %261
  %xor1.i.i.i.i199 = xor i32 %xor.i.i.i.i198, %conv.i.i187
  %267 = trunc i32 %xor1.i.i.i.i199 to i8
  %268 = lshr i8 %267, 4
  %conv2.i.i.i200 = and i8 %268, 1
  %af.i.i.i201 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i200, ptr %af.i.i.i201, align 1
  %cmp.i.i.i.i202 = icmp eq i32 %add.i.i188, 0
  %call.i.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i202, i32 noundef %conv.i.i187, i32 noundef %261, i32 noundef %add.i.i188) #13
  %conv5.i.i.i204 = zext i1 %call.i.i.i.i203 to i8
  %zf.i.i.i205 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i204, ptr %zf.i.i.i205, align 1
  %cmp.i27.i.i.i206 = icmp slt i32 %add.i.i188, 0
  %call1.i.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i206, i32 noundef %conv.i.i187, i32 noundef %261, i32 noundef %add.i.i188) #13
  %conv8.i.i.i208 = zext i1 %call1.i.i.i.i207 to i8
  %sf.i.i.i209 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i208, ptr %sf.i.i.i209, align 1
  %shr8.i.i.i.i210 = xor i32 %add.i.i188, %conv.i.i187
  %xor.i28.i.i.i211 = lshr i32 %shr8.i.i.i.i210, 31
  %xor3.i.i.i.i212 = lshr i32 %xor.i.i.i.i198, 31
  %add.i.i.i.i213 = add nuw nsw i32 %xor.i28.i.i.i211, %xor3.i.i.i.i212
  %cmp.i29.i.i.i214 = icmp eq i32 %add.i.i.i.i213, 2
  %call.i30.i.i.i215 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i214, i32 noundef %conv.i.i187, i32 noundef %261, i32 noundef %add.i.i188) #13
  %conv11.i.i.i216 = zext i1 %call.i30.i.i.i215 to i8
  %of.i.i.i217 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i216, ptr %of.i.i.i217, align 1
  store ptr %263, ptr %MEMORY, align 8
  br label %269

269:                                              ; preds = %257
  %270 = load i64, ptr %NEXT_PC, align 8
  store i64 %270, ptr %PC, align 8
  %271 = add i64 %270, 3
  store i64 %271, ptr %NEXT_PC, align 8
  %272 = load i64, ptr %RBP, align 8
  %273 = sub i64 %272, 4
  %274 = load ptr, ptr %MEMORY, align 8
  %call.i.i805 = call i32 @__remill_read_memory_32(ptr noundef %274, i64 noundef %273) #13
  %conv.i.i806 = zext i32 %call.i.i805 to i64
  store i64 %conv.i.i806, ptr %RAX, align 8
  store ptr %274, ptr %MEMORY, align 8
  br label %275

275:                                              ; preds = %269
  %276 = load i64, ptr %NEXT_PC, align 8
  store i64 %276, ptr %PC, align 8
  %277 = add i64 %276, 3
  store i64 %277, ptr %NEXT_PC, align 8
  %278 = load i64, ptr %RAX, align 8
  %279 = add i64 %278, 1
  %280 = load ptr, ptr %MEMORY, align 8
  %conv.i.i836 = and i64 %279, 4294967295
  store i64 %conv.i.i836, ptr %RCX, align 8
  store ptr %280, ptr %MEMORY, align 8
  br label %281

281:                                              ; preds = %275
  %282 = load i64, ptr %NEXT_PC, align 8
  store i64 %282, ptr %PC, align 8
  %283 = add i64 %282, 3
  store i64 %283, ptr %NEXT_PC, align 8
  %284 = load i64, ptr %RBP, align 8
  %285 = sub i64 %284, 4
  %286 = load i32, ptr %ECX, align 4
  %287 = zext i32 %286 to i64
  %288 = load ptr, ptr %MEMORY, align 8
  %call.i.i773 = call ptr @__remill_write_memory_32(ptr noundef %288, i64 noundef %285, i32 noundef %286) #13
  store ptr %call.i.i773, ptr %MEMORY, align 8
  br label %289

289:                                              ; preds = %281
  %290 = load i64, ptr %NEXT_PC, align 8
  store i64 %290, ptr %PC, align 8
  %291 = add i64 %290, 2
  store i64 %291, ptr %NEXT_PC, align 8
  %292 = load i32, ptr %EDX, align 4
  %293 = zext i32 %292 to i64
  %294 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i786 = and i64 %293, 4294967295
  store i64 %conv.i11.i786, ptr %RCX, align 8
  store ptr %294, ptr %MEMORY, align 8
  br label %295

295:                                              ; preds = %289
  %296 = load i64, ptr %NEXT_PC, align 8
  store i64 %296, ptr %PC, align 8
  %297 = add i64 %296, 3
  store i64 %297, ptr %NEXT_PC, align 8
  %298 = load i64, ptr %RCX, align 8
  %299 = load ptr, ptr %MEMORY, align 8
  %sext167.i1123 = shl i64 %298, 32
  %conv.i155.i1124 = ashr exact i64 %sext167.i1123, 32
  %shr.i156.i1125 = ashr i64 %conv.i155.i1124, 30
  %call36.i1126 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1127 = icmp ne i8 %call36.i1126, 0
  %shr.i160.i1128 = ashr i64 %shr.i156.i1125, 1
  %300 = zext i1 %tobool.i1127 to i8
  %new_val.0.i1129 = trunc i64 %shr.i160.i1128 to i32
  %conv.i163.i1130 = and i64 %shr.i160.i1128, 4294967295
  store i64 %conv.i163.i1130, ptr %RCX, align 8
  %cf.i1131 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %301 = trunc i64 %shr.i156.i1125 to i8
  %conv.i1132 = and i8 %301, 1
  store i8 %conv.i1132, ptr %cf.i1131, align 1
  %pf.i1133 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1134 = trunc i64 %shr.i160.i1128 to i8
  %302 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1134)
  %303 = and i8 %302, 1
  %conv75.i1135 = xor i8 %303, 1
  store i8 %conv75.i1135, ptr %pf.i1133, align 1
  %af.i1136 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1126, ptr %af.i1136, align 1
  %zf.i1137 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1138 = icmp eq i32 %new_val.0.i1129, 0
  %conv88.i1139 = zext i1 %cmp.i165.i1138 to i8
  store i8 %conv88.i1139, ptr %zf.i1137, align 1
  %sf.i1140 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1141 = lshr i32 %new_val.0.i1129, 31
  %conv95.i1142 = trunc i32 %new_val.0.lobit.i1141 to i8
  store i8 %conv95.i1142, ptr %sf.i1140, align 1
  %of.i1143 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %300, ptr %of.i1143, align 1
  store ptr %299, ptr %MEMORY, align 8
  br label %304

304:                                              ; preds = %295
  %305 = load i64, ptr %NEXT_PC, align 8
  store i64 %305, ptr %PC, align 8
  %306 = add i64 %305, 3
  store i64 %306, ptr %NEXT_PC, align 8
  %307 = load i64, ptr %RCX, align 8
  %308 = load ptr, ptr %MEMORY, align 8
  %conv.i139.i838 = and i64 %307, 4294967295
  %shr.i140.i839 = lshr i64 %conv.i139.i838, 30
  %conv2.i141.i840 = trunc i64 %shr.i140.i839 to i32
  %call34.i841 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i842 = icmp ne i8 %call34.i841, 0
  %new_val.0.i843 = lshr i32 %conv2.i141.i840, 1
  %conv.i147.i844 = zext i32 %new_val.0.i843 to i64
  store i64 %conv.i147.i844, ptr %RCX, align 8
  %cf.i845 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %309 = trunc i32 %conv2.i141.i840 to i8
  %conv.i846 = and i8 %309, 1
  store i8 %conv.i846, ptr %cf.i845, align 1
  %pf.i847 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i148.i848 = trunc i32 %new_val.0.i843 to i8
  %310 = call i8 @llvm.ctpop.i8(i8 %conv.i148.i848)
  %311 = and i8 %310, 1
  %conv67.i849 = xor i8 %311, 1
  store i8 %conv67.i849, ptr %pf.i847, align 1
  %af.i850 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i841, ptr %af.i850, align 1
  %zf.i851 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i149.i852 = icmp ult i32 %conv2.i141.i840, 2
  %conv80.i853 = zext i1 %cmp.i149.i852 to i8
  store i8 %conv80.i853, ptr %zf.i851, align 1
  %sf.i854 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i854, align 1
  %of.i855 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i856 = zext i1 %tobool.i842 to i8
  store i8 %conv92.i856, ptr %of.i855, align 1
  store ptr %308, ptr %MEMORY, align 8
  br label %312

312:                                              ; preds = %304
  %313 = load i64, ptr %NEXT_PC, align 8
  store i64 %313, ptr %PC, align 8
  %314 = add i64 %313, 2
  store i64 %314, ptr %NEXT_PC, align 8
  %315 = load i64, ptr %RDX, align 8
  %316 = load i32, ptr %ECX, align 4
  %317 = zext i32 %316 to i64
  %318 = load ptr, ptr %MEMORY, align 8
  %conv.i.i156 = trunc i64 %315 to i32
  %add.i.i157 = add i32 %316, %conv.i.i156
  %conv.i22.i158 = zext i32 %add.i.i157 to i64
  store i64 %conv.i22.i158, ptr %RDX, align 8
  %cmp.i.i.i159 = icmp ult i32 %add.i.i157, %conv.i.i156
  %cmp1.i.i.i160 = icmp ult i32 %add.i.i157, %316
  %319 = or i1 %cmp.i.i.i159, %cmp1.i.i.i160
  %call.i.i.i161 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %319, i32 noundef %conv.i.i156, i32 noundef %316, i32 noundef %add.i.i157) #13
  %conv.i23.i162 = zext i1 %call.i.i.i161 to i8
  %cf.i.i163 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i162, ptr %cf.i.i163, align 1
  %conv.i.i.i.i164 = trunc i32 %add.i.i157 to i8
  %320 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i164)
  %321 = and i8 %320, 1
  %conv.i.i.i165 = xor i8 %321, 1
  %pf.i.i.i166 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i165, ptr %pf.i.i.i166, align 1
  %xor.i.i.i.i167 = xor i32 %add.i.i157, %316
  %xor1.i.i.i.i168 = xor i32 %xor.i.i.i.i167, %conv.i.i156
  %322 = trunc i32 %xor1.i.i.i.i168 to i8
  %323 = lshr i8 %322, 4
  %conv2.i.i.i169 = and i8 %323, 1
  %af.i.i.i170 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i169, ptr %af.i.i.i170, align 1
  %cmp.i.i.i.i171 = icmp eq i32 %add.i.i157, 0
  %call.i.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i171, i32 noundef %conv.i.i156, i32 noundef %316, i32 noundef %add.i.i157) #13
  %conv5.i.i.i173 = zext i1 %call.i.i.i.i172 to i8
  %zf.i.i.i174 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i173, ptr %zf.i.i.i174, align 1
  %cmp.i27.i.i.i175 = icmp slt i32 %add.i.i157, 0
  %call1.i.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i175, i32 noundef %conv.i.i156, i32 noundef %316, i32 noundef %add.i.i157) #13
  %conv8.i.i.i177 = zext i1 %call1.i.i.i.i176 to i8
  %sf.i.i.i178 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i177, ptr %sf.i.i.i178, align 1
  %shr8.i.i.i.i179 = xor i32 %add.i.i157, %conv.i.i156
  %xor.i28.i.i.i180 = lshr i32 %shr8.i.i.i.i179, 31
  %xor3.i.i.i.i181 = lshr i32 %xor.i.i.i.i167, 31
  %add.i.i.i.i182 = add nuw nsw i32 %xor.i28.i.i.i180, %xor3.i.i.i.i181
  %cmp.i29.i.i.i183 = icmp eq i32 %add.i.i.i.i182, 2
  %call.i30.i.i.i184 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i183, i32 noundef %conv.i.i156, i32 noundef %316, i32 noundef %add.i.i157) #13
  %conv11.i.i.i185 = zext i1 %call.i30.i.i.i184 to i8
  %of.i.i.i186 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i185, ptr %of.i.i.i186, align 1
  store ptr %318, ptr %MEMORY, align 8
  br label %324

324:                                              ; preds = %312
  %325 = load i64, ptr %NEXT_PC, align 8
  store i64 %325, ptr %PC, align 8
  %326 = add i64 %325, 3
  store i64 %326, ptr %NEXT_PC, align 8
  %327 = load i64, ptr %RDX, align 8
  %328 = load ptr, ptr %MEMORY, align 8
  %conv.i.i823 = trunc i64 %327 to i32
  %and3.i.i = and i32 1, %conv.i.i823
  %conv.i22.i824 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i824, ptr %RDX, align 8
  %cf.i.i825 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i825, align 1
  %conv.i.i.i826 = trunc i32 %and3.i.i to i8
  %329 = and i8 %conv.i.i.i826, 1
  %conv.i23.i827 = xor i8 %329, 1
  %pf.i.i828 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i827, ptr %pf.i.i828, align 1
  %cmp.i.i.i829 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i830 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i829, i32 noundef %conv.i.i823, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i830 to i8
  %zf.i.i831 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i831, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i823, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i832 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i832, align 1
  %of.i.i833 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i833, align 1
  %af.i.i834 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i834, align 1
  store ptr %328, ptr %MEMORY, align 8
  br label %330

330:                                              ; preds = %324
  %331 = load i64, ptr %NEXT_PC, align 8
  store i64 %331, ptr %PC, align 8
  %332 = add i64 %331, 2
  store i64 %332, ptr %NEXT_PC, align 8
  %333 = load i64, ptr %RDX, align 8
  %334 = load i32, ptr %ECX, align 4
  %335 = zext i32 %334 to i64
  %336 = load ptr, ptr %MEMORY, align 8
  %conv.i.i520 = trunc i64 %333 to i32
  %sub.i.i521 = sub i32 %conv.i.i520, %334
  %conv.i22.i522 = zext i32 %sub.i.i521 to i64
  store i64 %conv.i22.i522, ptr %RDX, align 8
  %cmp.i.i.i523 = icmp ult i32 %conv.i.i520, %334
  %call.i.i.i524 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i523, i32 noundef %conv.i.i520, i32 noundef %334, i32 noundef %sub.i.i521) #13
  %conv.i23.i525 = zext i1 %call.i.i.i524 to i8
  %cf.i.i526 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i525, ptr %cf.i.i526, align 1
  %conv.i.i.i.i527 = trunc i32 %sub.i.i521 to i8
  %337 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i527)
  %338 = and i8 %337, 1
  %conv.i.i.i528 = xor i8 %338, 1
  %pf.i.i.i529 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i528, ptr %pf.i.i.i529, align 1
  %xor.i.i.i.i530 = xor i32 %334, %conv.i.i520
  %xor1.i.i.i.i531 = xor i32 %xor.i.i.i.i530, %sub.i.i521
  %339 = trunc i32 %xor1.i.i.i.i531 to i8
  %340 = lshr i8 %339, 4
  %conv2.i.i.i532 = and i8 %340, 1
  %af.i.i.i533 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i532, ptr %af.i.i.i533, align 1
  %cmp.i.i.i.i534 = icmp eq i32 %conv.i.i520, %334
  %call.i.i.i.i535 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i534, i32 noundef %conv.i.i520, i32 noundef %334, i32 noundef %sub.i.i521) #13
  %conv5.i.i.i536 = zext i1 %call.i.i.i.i535 to i8
  %zf.i.i.i537 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i536, ptr %zf.i.i.i537, align 1
  %cmp.i27.i.i.i538 = icmp slt i32 %sub.i.i521, 0
  %call1.i.i.i.i539 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i538, i32 noundef %conv.i.i520, i32 noundef %334, i32 noundef %sub.i.i521) #13
  %conv8.i.i.i540 = zext i1 %call1.i.i.i.i539 to i8
  %sf.i.i.i541 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i540, ptr %sf.i.i.i541, align 1
  %xor.i28.i.i.i542 = lshr i32 %xor.i.i.i.i530, 31
  %shr9.i.i.i.i543 = xor i32 %sub.i.i521, %conv.i.i520
  %xor3.i.i.i.i544 = lshr i32 %shr9.i.i.i.i543, 31
  %add.i.i.i.i545 = add nuw nsw i32 %xor3.i.i.i.i544, %xor.i28.i.i.i542
  %cmp.i29.i.i.i546 = icmp eq i32 %add.i.i.i.i545, 2
  %call.i30.i.i.i547 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i546, i32 noundef %conv.i.i520, i32 noundef %334, i32 noundef %sub.i.i521) #13
  %conv11.i.i.i548 = zext i1 %call.i30.i.i.i547 to i8
  %of.i.i.i549 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i548, ptr %of.i.i.i549, align 1
  store ptr %336, ptr %MEMORY, align 8
  br label %341

341:                                              ; preds = %330
  %342 = load i64, ptr %NEXT_PC, align 8
  store i64 %342, ptr %PC, align 8
  %343 = add i64 %342, 2
  store i64 %343, ptr %NEXT_PC, align 8
  %344 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 1
  %345 = load i32, ptr %rax.i, align 8
  %conv.i.i769 = sext i32 %345 to i64
  store i64 %conv.i.i769, ptr %rax.i, align 8
  store ptr %344, ptr %MEMORY, align 8
  br label %346

346:                                              ; preds = %341
  %347 = load i64, ptr %NEXT_PC, align 8
  store i64 %347, ptr %PC, align 8
  %348 = add i64 %347, 4
  store i64 %348, ptr %NEXT_PC, align 8
  %349 = load i64, ptr %RBP, align 8
  %350 = load i64, ptr %RAX, align 8
  %351 = mul i64 %350, 4
  %352 = add i64 %349, %351
  %353 = sub i64 %352, 96
  %354 = load i32, ptr %EDX, align 4
  %355 = zext i32 %354 to i64
  %356 = load ptr, ptr %MEMORY, align 8
  %call.i.i772 = call ptr @__remill_write_memory_32(ptr noundef %356, i64 noundef %353, i32 noundef %354) #13
  store ptr %call.i.i772, ptr %MEMORY, align 8
  br label %357

357:                                              ; preds = %346
  %358 = load i64, ptr %NEXT_PC, align 8
  store i64 %358, ptr %PC, align 8
  %359 = add i64 %358, 3
  store i64 %359, ptr %NEXT_PC, align 8
  %360 = load i64, ptr %RBP, align 8
  %361 = sub i64 %360, 100
  %362 = load ptr, ptr %MEMORY, align 8
  %call.i.i803 = call i32 @__remill_read_memory_32(ptr noundef %362, i64 noundef %361) #13
  %conv.i.i804 = zext i32 %call.i.i803 to i64
  store i64 %conv.i.i804, ptr %RDX, align 8
  store ptr %362, ptr %MEMORY, align 8
  br label %363

363:                                              ; preds = %357
  %364 = load i64, ptr %NEXT_PC, align 8
  store i64 %364, ptr %PC, align 8
  %365 = add i64 %364, 3
  store i64 %365, ptr %NEXT_PC, align 8
  %366 = load i32, ptr %EDX, align 4
  %367 = zext i32 %366 to i64
  %368 = load ptr, ptr %MEMORY, align 8
  %sext.i817 = shl i64 %367, 32
  %conv.i12.i818 = ashr exact i64 %sext.i817, 32
  store i64 %conv.i12.i818, ptr %RAX, align 8
  store ptr %368, ptr %MEMORY, align 8
  br label %369

369:                                              ; preds = %363
  %370 = load i64, ptr %NEXT_PC, align 8
  store i64 %370, ptr %PC, align 8
  %371 = add i64 %370, 7
  store i64 %371, ptr %NEXT_PC, align 8
  %372 = load i64, ptr %RAX, align 8
  %373 = load ptr, ptr %MEMORY, align 8
  %374 = ashr i64 %372, 63
  %L.sroa.2.0.insert.ext.i.i712 = zext i64 %374 to i128
  %L.sroa.2.0.insert.shift.i.i713 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i712, 64
  %L.sroa.0.0.insert.ext.i.i714 = zext i64 %372 to i128
  %L.sroa.0.0.insert.insert.i.i715 = or i128 %L.sroa.2.0.insert.shift.i.i713, %L.sroa.0.0.insert.ext.i.i714
  %mul.i.i716 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i715
  %retval.sroa.0.0.extract.trunc.i.i717 = trunc i128 %mul.i.i716 to i64
  %retval.sroa.2.0.extract.shift.i.i718 = lshr i128 %mul.i.i716, 64
  %retval.sroa.2.0.extract.trunc.i.i719 = trunc i128 %retval.sroa.2.0.extract.shift.i.i718 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i717, ptr %RAX, align 8
  %conv2.i.i.i720 = sext i64 %retval.sroa.0.0.extract.trunc.i.i717 to i128
  %cmp.i.i.i721 = icmp ne i128 %mul.i.i716, %conv2.i.i.i720
  %call.i.i.i722 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i721, i64 noundef %372, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i717, i64 noundef %retval.sroa.2.0.extract.trunc.i.i719) #13
  %frombool.i.i723 = zext i1 %call.i.i.i722 to i8
  %cf.i.i724 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i723, ptr %cf.i.i724, align 1
  %call2.i.i725 = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i726 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i725, ptr %pf.i.i726, align 1
  %af.i.i727 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i725, ptr %af.i.i727, align 1
  %zf.i.i728 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i725, ptr %zf.i.i728, align 1
  %sf.i.i729 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i725, ptr %sf.i.i729, align 1
  %of.i.i730 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i723, ptr %of.i.i730, align 1
  store ptr %373, ptr %MEMORY, align 8
  br label %375

375:                                              ; preds = %369
  %376 = load i64, ptr %NEXT_PC, align 8
  store i64 %376, ptr %PC, align 8
  %377 = add i64 %376, 4
  store i64 %377, ptr %NEXT_PC, align 8
  %378 = load i64, ptr %RAX, align 8
  %379 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i903 = lshr i64 %378, 31
  %call34.i904 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i905 = icmp ne i8 %call34.i904, 0
  %new_val.0.i906 = lshr i64 %shr.i136.i903, 1
  store i64 %new_val.0.i906, ptr %RAX, align 8
  %cf.i907 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %380 = trunc i64 %shr.i136.i903 to i8
  %conv.i908 = and i8 %380, 1
  store i8 %conv.i908, ptr %cf.i907, align 1
  %pf.i909 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i910 = trunc i64 %new_val.0.i906 to i8
  %381 = call i8 @llvm.ctpop.i8(i8 %conv.i.i910)
  %382 = and i8 %381, 1
  %conv67.i911 = xor i8 %382, 1
  store i8 %conv67.i911, ptr %pf.i909, align 1
  %af.i912 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i904, ptr %af.i912, align 1
  %zf.i913 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i914 = icmp ult i64 %shr.i136.i903, 2
  %conv80.i915 = zext i1 %cmp.i140.i914 to i8
  store i8 %conv80.i915, ptr %zf.i913, align 1
  %sf.i916 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i916, align 1
  %of.i917 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i918 = zext i1 %tobool.i905 to i8
  store i8 %conv92.i918, ptr %of.i917, align 1
  store ptr %379, ptr %MEMORY, align 8
  br label %383

383:                                              ; preds = %375
  %384 = load i64, ptr %NEXT_PC, align 8
  store i64 %384, ptr %PC, align 8
  %385 = add i64 %384, 3
  store i64 %385, ptr %NEXT_PC, align 8
  %386 = load i64, ptr %RAX, align 8
  %387 = load ptr, ptr %MEMORY, align 8
  %sext167.i1102 = shl i64 %386, 32
  %conv.i155.i1103 = ashr exact i64 %sext167.i1102, 32
  %shr.i156.i1104 = ashr i64 %conv.i155.i1103, 1
  %call36.i1105 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1106 = icmp ne i8 %call36.i1105, 0
  %shr.i160.i1107 = ashr i64 %shr.i156.i1104, 1
  %388 = zext i1 %tobool.i1106 to i8
  %new_val.0.i1108 = trunc i64 %shr.i160.i1107 to i32
  %conv.i163.i1109 = and i64 %shr.i160.i1107, 4294967295
  store i64 %conv.i163.i1109, ptr %RAX, align 8
  %cf.i1110 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %389 = trunc i64 %shr.i156.i1104 to i8
  %conv.i1111 = and i8 %389, 1
  store i8 %conv.i1111, ptr %cf.i1110, align 1
  %pf.i1112 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1113 = trunc i64 %shr.i160.i1107 to i8
  %390 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1113)
  %391 = and i8 %390, 1
  %conv75.i1114 = xor i8 %391, 1
  store i8 %conv75.i1114, ptr %pf.i1112, align 1
  %af.i1115 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1105, ptr %af.i1115, align 1
  %zf.i1116 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1117 = icmp eq i32 %new_val.0.i1108, 0
  %conv88.i1118 = zext i1 %cmp.i165.i1117 to i8
  store i8 %conv88.i1118, ptr %zf.i1116, align 1
  %sf.i1119 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1120 = lshr i32 %new_val.0.i1108, 31
  %conv95.i1121 = trunc i32 %new_val.0.lobit.i1120 to i8
  store i8 %conv95.i1121, ptr %sf.i1119, align 1
  %of.i1122 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %388, ptr %of.i1122, align 1
  store ptr %387, ptr %MEMORY, align 8
  br label %392

392:                                              ; preds = %383
  %393 = load i64, ptr %NEXT_PC, align 8
  store i64 %393, ptr %PC, align 8
  %394 = add i64 %393, 2
  store i64 %394, ptr %NEXT_PC, align 8
  %395 = load i32, ptr %EDX, align 4
  %396 = zext i32 %395 to i64
  %397 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i785 = and i64 %396, 4294967295
  store i64 %conv.i11.i785, ptr %RCX, align 8
  store ptr %397, ptr %MEMORY, align 8
  br label %398

398:                                              ; preds = %392
  %399 = load i64, ptr %NEXT_PC, align 8
  store i64 %399, ptr %PC, align 8
  %400 = add i64 %399, 3
  store i64 %400, ptr %NEXT_PC, align 8
  %401 = load i64, ptr %RCX, align 8
  %402 = load ptr, ptr %MEMORY, align 8
  %sext167.i1081 = shl i64 %401, 32
  %conv.i155.i1082 = ashr exact i64 %sext167.i1081, 32
  %shr.i156.i1083 = ashr i64 %conv.i155.i1082, 30
  %call36.i1084 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1085 = icmp ne i8 %call36.i1084, 0
  %shr.i160.i1086 = ashr i64 %shr.i156.i1083, 1
  %403 = zext i1 %tobool.i1085 to i8
  %new_val.0.i1087 = trunc i64 %shr.i160.i1086 to i32
  %conv.i163.i1088 = and i64 %shr.i160.i1086, 4294967295
  store i64 %conv.i163.i1088, ptr %RCX, align 8
  %cf.i1089 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %404 = trunc i64 %shr.i156.i1083 to i8
  %conv.i1090 = and i8 %404, 1
  store i8 %conv.i1090, ptr %cf.i1089, align 1
  %pf.i1091 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1092 = trunc i64 %shr.i160.i1086 to i8
  %405 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1092)
  %406 = and i8 %405, 1
  %conv75.i1093 = xor i8 %406, 1
  store i8 %conv75.i1093, ptr %pf.i1091, align 1
  %af.i1094 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1084, ptr %af.i1094, align 1
  %zf.i1095 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1096 = icmp eq i32 %new_val.0.i1087, 0
  %conv88.i1097 = zext i1 %cmp.i165.i1096 to i8
  store i8 %conv88.i1097, ptr %zf.i1095, align 1
  %sf.i1098 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1099 = lshr i32 %new_val.0.i1087, 31
  %conv95.i1100 = trunc i32 %new_val.0.lobit.i1099 to i8
  store i8 %conv95.i1100, ptr %sf.i1098, align 1
  %of.i1101 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %403, ptr %of.i1101, align 1
  store ptr %402, ptr %MEMORY, align 8
  br label %407

407:                                              ; preds = %398
  %408 = load i64, ptr %NEXT_PC, align 8
  store i64 %408, ptr %PC, align 8
  %409 = add i64 %408, 2
  store i64 %409, ptr %NEXT_PC, align 8
  %410 = load i64, ptr %RAX, align 8
  %411 = load i32, ptr %ECX, align 4
  %412 = zext i32 %411 to i64
  %413 = load ptr, ptr %MEMORY, align 8
  %conv.i.i490 = trunc i64 %410 to i32
  %sub.i.i491 = sub i32 %conv.i.i490, %411
  %conv.i22.i492 = zext i32 %sub.i.i491 to i64
  store i64 %conv.i22.i492, ptr %RAX, align 8
  %cmp.i.i.i493 = icmp ult i32 %conv.i.i490, %411
  %call.i.i.i494 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i493, i32 noundef %conv.i.i490, i32 noundef %411, i32 noundef %sub.i.i491) #13
  %conv.i23.i495 = zext i1 %call.i.i.i494 to i8
  %cf.i.i496 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i495, ptr %cf.i.i496, align 1
  %conv.i.i.i.i497 = trunc i32 %sub.i.i491 to i8
  %414 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i497)
  %415 = and i8 %414, 1
  %conv.i.i.i498 = xor i8 %415, 1
  %pf.i.i.i499 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i498, ptr %pf.i.i.i499, align 1
  %xor.i.i.i.i500 = xor i32 %411, %conv.i.i490
  %xor1.i.i.i.i501 = xor i32 %xor.i.i.i.i500, %sub.i.i491
  %416 = trunc i32 %xor1.i.i.i.i501 to i8
  %417 = lshr i8 %416, 4
  %conv2.i.i.i502 = and i8 %417, 1
  %af.i.i.i503 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i502, ptr %af.i.i.i503, align 1
  %cmp.i.i.i.i504 = icmp eq i32 %conv.i.i490, %411
  %call.i.i.i.i505 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i504, i32 noundef %conv.i.i490, i32 noundef %411, i32 noundef %sub.i.i491) #13
  %conv5.i.i.i506 = zext i1 %call.i.i.i.i505 to i8
  %zf.i.i.i507 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i506, ptr %zf.i.i.i507, align 1
  %cmp.i27.i.i.i508 = icmp slt i32 %sub.i.i491, 0
  %call1.i.i.i.i509 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i508, i32 noundef %conv.i.i490, i32 noundef %411, i32 noundef %sub.i.i491) #13
  %conv8.i.i.i510 = zext i1 %call1.i.i.i.i509 to i8
  %sf.i.i.i511 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i510, ptr %sf.i.i.i511, align 1
  %xor.i28.i.i.i512 = lshr i32 %xor.i.i.i.i500, 31
  %shr9.i.i.i.i513 = xor i32 %sub.i.i491, %conv.i.i490
  %xor3.i.i.i.i514 = lshr i32 %shr9.i.i.i.i513, 31
  %add.i.i.i.i515 = add nuw nsw i32 %xor3.i.i.i.i514, %xor.i28.i.i.i512
  %cmp.i29.i.i.i516 = icmp eq i32 %add.i.i.i.i515, 2
  %call.i30.i.i.i517 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i516, i32 noundef %conv.i.i490, i32 noundef %411, i32 noundef %sub.i.i491) #13
  %conv11.i.i.i518 = zext i1 %call.i30.i.i.i517 to i8
  %of.i.i.i519 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i518, ptr %of.i.i.i519, align 1
  store ptr %413, ptr %MEMORY, align 8
  br label %418

418:                                              ; preds = %407
  %419 = load i64, ptr %NEXT_PC, align 8
  store i64 %419, ptr %PC, align 8
  %420 = add i64 %419, 2
  store i64 %420, ptr %NEXT_PC, align 8
  %421 = load i32, ptr %EAX, align 4
  %422 = zext i32 %421 to i64
  %423 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i784 = and i64 %422, 4294967295
  store i64 %conv.i11.i784, ptr %RSI, align 8
  store ptr %423, ptr %MEMORY, align 8
  br label %424

424:                                              ; preds = %418
  %425 = load i64, ptr %NEXT_PC, align 8
  store i64 %425, ptr %PC, align 8
  %426 = add i64 %425, 2
  store i64 %426, ptr %NEXT_PC, align 8
  %427 = load i32, ptr %ESI, align 4
  %428 = zext i32 %427 to i64
  %429 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i783 = and i64 %428, 4294967295
  store i64 %conv.i11.i783, ptr %RAX, align 8
  store ptr %429, ptr %MEMORY, align 8
  br label %430

430:                                              ; preds = %424
  %431 = load i64, ptr %NEXT_PC, align 8
  store i64 %431, ptr %PC, align 8
  %432 = add i64 %431, 3
  store i64 %432, ptr %NEXT_PC, align 8
  %433 = load i64, ptr %RAX, align 8
  %434 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i1239 = shl i64 %433, 1
  %conv2.i150.i1240 = trunc i64 %shl.i149.i1239 to i32
  %call42.i1241 = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i1242 = icmp ne i8 %call42.i1241, 0
  %conv2.i154.i1243 = shl i32 %conv2.i150.i1240, 1
  %conv.i155.i1245 = zext i32 %conv2.i154.i1243 to i64
  store i64 %conv.i155.i1245, ptr %RAX, align 8
  %cf.i1246 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i1247 = lshr i32 %conv2.i150.i1240, 31
  %conv.i1248 = trunc i32 %new_cf.0.shrunk.in.lobit.i1247 to i8
  store i8 %conv.i1248, ptr %cf.i1246, align 1
  %pf.i1249 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i1250 = trunc i32 %conv2.i154.i1243 to i8
  %435 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i1250)
  %436 = and i8 %435, 1
  %conv72.i1251 = xor i8 %436, 1
  store i8 %conv72.i1251, ptr %pf.i1249, align 1
  %af.i1252 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i1241, ptr %af.i1252, align 1
  %zf.i1253 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1254 = icmp eq i32 %conv2.i154.i1243, 0
  %conv85.i1255 = zext i1 %cmp.i157.i1254 to i8
  store i8 %conv85.i1255, ptr %zf.i1253, align 1
  %sf.i1256 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1257 = lshr i32 %conv2.i154.i1243, 31
  %conv92.i1258 = trunc i32 %new_val.0.lobit.i1257 to i8
  store i8 %conv92.i1258, ptr %sf.i1256, align 1
  %of.i1259 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv99.i1260 = zext i1 %tobool43.i1242 to i8
  store i8 %conv99.i1260, ptr %of.i1259, align 1
  store ptr %434, ptr %MEMORY, align 8
  br label %437

437:                                              ; preds = %430
  %438 = load i64, ptr %NEXT_PC, align 8
  store i64 %438, ptr %PC, align 8
  %439 = add i64 %438, 2
  store i64 %439, ptr %NEXT_PC, align 8
  %440 = load i64, ptr %RAX, align 8
  %441 = load i32, ptr %ESI, align 4
  %442 = zext i32 %441 to i64
  %443 = load ptr, ptr %MEMORY, align 8
  %conv.i.i125 = trunc i64 %440 to i32
  %add.i.i126 = add i32 %441, %conv.i.i125
  %conv.i22.i127 = zext i32 %add.i.i126 to i64
  store i64 %conv.i22.i127, ptr %RAX, align 8
  %cmp.i.i.i128 = icmp ult i32 %add.i.i126, %conv.i.i125
  %cmp1.i.i.i129 = icmp ult i32 %add.i.i126, %441
  %444 = or i1 %cmp.i.i.i128, %cmp1.i.i.i129
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %444, i32 noundef %conv.i.i125, i32 noundef %441, i32 noundef %add.i.i126) #13
  %conv.i23.i131 = zext i1 %call.i.i.i130 to i8
  %cf.i.i132 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i131, ptr %cf.i.i132, align 1
  %conv.i.i.i.i133 = trunc i32 %add.i.i126 to i8
  %445 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i133)
  %446 = and i8 %445, 1
  %conv.i.i.i134 = xor i8 %446, 1
  %pf.i.i.i135 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i134, ptr %pf.i.i.i135, align 1
  %xor.i.i.i.i136 = xor i32 %add.i.i126, %441
  %xor1.i.i.i.i137 = xor i32 %xor.i.i.i.i136, %conv.i.i125
  %447 = trunc i32 %xor1.i.i.i.i137 to i8
  %448 = lshr i8 %447, 4
  %conv2.i.i.i138 = and i8 %448, 1
  %af.i.i.i139 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i138, ptr %af.i.i.i139, align 1
  %cmp.i.i.i.i140 = icmp eq i32 %add.i.i126, 0
  %call.i.i.i.i141 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i140, i32 noundef %conv.i.i125, i32 noundef %441, i32 noundef %add.i.i126) #13
  %conv5.i.i.i142 = zext i1 %call.i.i.i.i141 to i8
  %zf.i.i.i143 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i142, ptr %zf.i.i.i143, align 1
  %cmp.i27.i.i.i144 = icmp slt i32 %add.i.i126, 0
  %call1.i.i.i.i145 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i144, i32 noundef %conv.i.i125, i32 noundef %441, i32 noundef %add.i.i126) #13
  %conv8.i.i.i146 = zext i1 %call1.i.i.i.i145 to i8
  %sf.i.i.i147 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i146, ptr %sf.i.i.i147, align 1
  %shr8.i.i.i.i148 = xor i32 %add.i.i126, %conv.i.i125
  %xor.i28.i.i.i149 = lshr i32 %shr8.i.i.i.i148, 31
  %xor3.i.i.i.i150 = lshr i32 %xor.i.i.i.i136, 31
  %add.i.i.i.i151 = add nuw nsw i32 %xor.i28.i.i.i149, %xor3.i.i.i.i150
  %cmp.i29.i.i.i152 = icmp eq i32 %add.i.i.i.i151, 2
  %call.i30.i.i.i153 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i152, i32 noundef %conv.i.i125, i32 noundef %441, i32 noundef %add.i.i126) #13
  %conv11.i.i.i154 = zext i1 %call.i30.i.i.i153 to i8
  %of.i.i.i155 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i154, ptr %of.i.i.i155, align 1
  store ptr %443, ptr %MEMORY, align 8
  br label %449

449:                                              ; preds = %437
  %450 = load i64, ptr %NEXT_PC, align 8
  store i64 %450, ptr %PC, align 8
  %451 = add i64 %450, 2
  store i64 %451, ptr %NEXT_PC, align 8
  %452 = load i64, ptr %RAX, align 8
  %453 = load i32, ptr %EAX, align 4
  %454 = zext i32 %453 to i64
  %455 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %452 to i32
  %add.i.i95 = add i32 %453, %conv.i.i94
  %conv.i22.i96 = zext i32 %add.i.i95 to i64
  store i64 %conv.i22.i96, ptr %RAX, align 8
  %cmp.i.i.i97 = icmp ult i32 %add.i.i95, %conv.i.i94
  %cmp1.i.i.i98 = icmp ult i32 %add.i.i95, %453
  %456 = or i1 %cmp.i.i.i97, %cmp1.i.i.i98
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %456, i32 noundef %conv.i.i94, i32 noundef %453, i32 noundef %add.i.i95) #13
  %conv.i23.i100 = zext i1 %call.i.i.i99 to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i100, ptr %cf.i.i101, align 1
  %conv.i.i.i.i102 = trunc i32 %add.i.i95 to i8
  %457 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i102)
  %458 = and i8 %457, 1
  %conv.i.i.i103 = xor i8 %458, 1
  %pf.i.i.i104 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i103, ptr %pf.i.i.i104, align 1
  %xor.i.i.i.i105 = xor i32 %add.i.i95, %453
  %xor1.i.i.i.i106 = xor i32 %xor.i.i.i.i105, %conv.i.i94
  %459 = trunc i32 %xor1.i.i.i.i106 to i8
  %460 = lshr i8 %459, 4
  %conv2.i.i.i107 = and i8 %460, 1
  %af.i.i.i108 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i107, ptr %af.i.i.i108, align 1
  %cmp.i.i.i.i109 = icmp eq i32 %add.i.i95, 0
  %call.i.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i109, i32 noundef %conv.i.i94, i32 noundef %453, i32 noundef %add.i.i95) #13
  %conv5.i.i.i111 = zext i1 %call.i.i.i.i110 to i8
  %zf.i.i.i112 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i111, ptr %zf.i.i.i112, align 1
  %cmp.i27.i.i.i113 = icmp slt i32 %add.i.i95, 0
  %call1.i.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i113, i32 noundef %conv.i.i94, i32 noundef %453, i32 noundef %add.i.i95) #13
  %conv8.i.i.i115 = zext i1 %call1.i.i.i.i114 to i8
  %sf.i.i.i116 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i115, ptr %sf.i.i.i116, align 1
  %shr8.i.i.i.i117 = xor i32 %add.i.i95, %conv.i.i94
  %xor.i28.i.i.i118 = lshr i32 %shr8.i.i.i.i117, 31
  %xor3.i.i.i.i119 = lshr i32 %xor.i.i.i.i105, 31
  %add.i.i.i.i120 = add nuw nsw i32 %xor.i28.i.i.i118, %xor3.i.i.i.i119
  %cmp.i29.i.i.i121 = icmp eq i32 %add.i.i.i.i120, 2
  %call.i30.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i121, i32 noundef %conv.i.i94, i32 noundef %453, i32 noundef %add.i.i95) #13
  %conv11.i.i.i123 = zext i1 %call.i30.i.i.i122 to i8
  %of.i.i.i124 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i123, ptr %of.i.i.i124, align 1
  store ptr %455, ptr %MEMORY, align 8
  br label %461

461:                                              ; preds = %449
  %462 = load i64, ptr %NEXT_PC, align 8
  store i64 %462, ptr %PC, align 8
  %463 = add i64 %462, 2
  store i64 %463, ptr %NEXT_PC, align 8
  %464 = load i32, ptr %EDX, align 4
  %465 = zext i32 %464 to i64
  %466 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i782 = and i64 %465, 4294967295
  store i64 %conv.i11.i782, ptr %RSI, align 8
  store ptr %466, ptr %MEMORY, align 8
  br label %467

467:                                              ; preds = %461
  %468 = load i64, ptr %NEXT_PC, align 8
  store i64 %468, ptr %PC, align 8
  %469 = add i64 %468, 2
  store i64 %469, ptr %NEXT_PC, align 8
  %470 = load i64, ptr %RSI, align 8
  %471 = load i32, ptr %EAX, align 4
  %472 = zext i32 %471 to i64
  %473 = load ptr, ptr %MEMORY, align 8
  %conv.i.i460 = trunc i64 %470 to i32
  %sub.i.i461 = sub i32 %conv.i.i460, %471
  %conv.i22.i462 = zext i32 %sub.i.i461 to i64
  store i64 %conv.i22.i462, ptr %RSI, align 8
  %cmp.i.i.i463 = icmp ult i32 %conv.i.i460, %471
  %call.i.i.i464 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i463, i32 noundef %conv.i.i460, i32 noundef %471, i32 noundef %sub.i.i461) #13
  %conv.i23.i465 = zext i1 %call.i.i.i464 to i8
  %cf.i.i466 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i465, ptr %cf.i.i466, align 1
  %conv.i.i.i.i467 = trunc i32 %sub.i.i461 to i8
  %474 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i467)
  %475 = and i8 %474, 1
  %conv.i.i.i468 = xor i8 %475, 1
  %pf.i.i.i469 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i468, ptr %pf.i.i.i469, align 1
  %xor.i.i.i.i470 = xor i32 %471, %conv.i.i460
  %xor1.i.i.i.i471 = xor i32 %xor.i.i.i.i470, %sub.i.i461
  %476 = trunc i32 %xor1.i.i.i.i471 to i8
  %477 = lshr i8 %476, 4
  %conv2.i.i.i472 = and i8 %477, 1
  %af.i.i.i473 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i472, ptr %af.i.i.i473, align 1
  %cmp.i.i.i.i474 = icmp eq i32 %conv.i.i460, %471
  %call.i.i.i.i475 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i474, i32 noundef %conv.i.i460, i32 noundef %471, i32 noundef %sub.i.i461) #13
  %conv5.i.i.i476 = zext i1 %call.i.i.i.i475 to i8
  %zf.i.i.i477 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i476, ptr %zf.i.i.i477, align 1
  %cmp.i27.i.i.i478 = icmp slt i32 %sub.i.i461, 0
  %call1.i.i.i.i479 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i478, i32 noundef %conv.i.i460, i32 noundef %471, i32 noundef %sub.i.i461) #13
  %conv8.i.i.i480 = zext i1 %call1.i.i.i.i479 to i8
  %sf.i.i.i481 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i480, ptr %sf.i.i.i481, align 1
  %xor.i28.i.i.i482 = lshr i32 %xor.i.i.i.i470, 31
  %shr9.i.i.i.i483 = xor i32 %sub.i.i461, %conv.i.i460
  %xor3.i.i.i.i484 = lshr i32 %shr9.i.i.i.i483, 31
  %add.i.i.i.i485 = add nuw nsw i32 %xor3.i.i.i.i484, %xor.i28.i.i.i482
  %cmp.i29.i.i.i486 = icmp eq i32 %add.i.i.i.i485, 2
  %call.i30.i.i.i487 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i486, i32 noundef %conv.i.i460, i32 noundef %471, i32 noundef %sub.i.i461) #13
  %conv11.i.i.i488 = zext i1 %call.i30.i.i.i487 to i8
  %of.i.i.i489 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i488, ptr %of.i.i.i489, align 1
  store ptr %473, ptr %MEMORY, align 8
  br label %478

478:                                              ; preds = %467
  %479 = load i64, ptr %NEXT_PC, align 8
  store i64 %479, ptr %PC, align 8
  %480 = add i64 %479, 3
  store i64 %480, ptr %NEXT_PC, align 8
  %481 = load i64, ptr %RBP, align 8
  %482 = sub i64 %481, 104
  %483 = load ptr, ptr %MEMORY, align 8
  %call.i.i801 = call i32 @__remill_read_memory_32(ptr noundef %483, i64 noundef %482) #13
  %conv.i.i802 = zext i32 %call.i.i801 to i64
  store i64 %conv.i.i802, ptr %RDX, align 8
  store ptr %483, ptr %MEMORY, align 8
  br label %484

484:                                              ; preds = %478
  %485 = load i64, ptr %NEXT_PC, align 8
  store i64 %485, ptr %PC, align 8
  %486 = add i64 %485, 3
  store i64 %486, ptr %NEXT_PC, align 8
  %487 = load i32, ptr %EDX, align 4
  %488 = zext i32 %487 to i64
  %489 = load ptr, ptr %MEMORY, align 8
  %sext.i815 = shl i64 %488, 32
  %conv.i12.i816 = ashr exact i64 %sext.i815, 32
  store i64 %conv.i12.i816, ptr %RAX, align 8
  store ptr %489, ptr %MEMORY, align 8
  br label %490

490:                                              ; preds = %484
  %491 = load i64, ptr %NEXT_PC, align 8
  store i64 %491, ptr %PC, align 8
  %492 = add i64 %491, 7
  store i64 %492, ptr %NEXT_PC, align 8
  %493 = load i64, ptr %RAX, align 8
  %494 = load ptr, ptr %MEMORY, align 8
  %495 = ashr i64 %493, 63
  %L.sroa.2.0.insert.ext.i.i693 = zext i64 %495 to i128
  %L.sroa.2.0.insert.shift.i.i694 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i693, 64
  %L.sroa.0.0.insert.ext.i.i695 = zext i64 %493 to i128
  %L.sroa.0.0.insert.insert.i.i696 = or i128 %L.sroa.2.0.insert.shift.i.i694, %L.sroa.0.0.insert.ext.i.i695
  %mul.i.i697 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i696
  %retval.sroa.0.0.extract.trunc.i.i698 = trunc i128 %mul.i.i697 to i64
  %retval.sroa.2.0.extract.shift.i.i699 = lshr i128 %mul.i.i697, 64
  %retval.sroa.2.0.extract.trunc.i.i700 = trunc i128 %retval.sroa.2.0.extract.shift.i.i699 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i698, ptr %RAX, align 8
  %conv2.i.i.i701 = sext i64 %retval.sroa.0.0.extract.trunc.i.i698 to i128
  %cmp.i.i.i702 = icmp ne i128 %mul.i.i697, %conv2.i.i.i701
  %call.i.i.i703 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i702, i64 noundef %493, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i698, i64 noundef %retval.sroa.2.0.extract.trunc.i.i700) #13
  %frombool.i.i704 = zext i1 %call.i.i.i703 to i8
  %cf.i.i705 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i704, ptr %cf.i.i705, align 1
  %call2.i.i706 = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i707 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i706, ptr %pf.i.i707, align 1
  %af.i.i708 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i706, ptr %af.i.i708, align 1
  %zf.i.i709 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i706, ptr %zf.i.i709, align 1
  %sf.i.i710 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i706, ptr %sf.i.i710, align 1
  %of.i.i711 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i704, ptr %of.i.i711, align 1
  store ptr %494, ptr %MEMORY, align 8
  br label %496

496:                                              ; preds = %490
  %497 = load i64, ptr %NEXT_PC, align 8
  store i64 %497, ptr %PC, align 8
  %498 = add i64 %497, 4
  store i64 %498, ptr %NEXT_PC, align 8
  %499 = load i64, ptr %RAX, align 8
  %500 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i887 = lshr i64 %499, 31
  %call34.i888 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i889 = icmp ne i8 %call34.i888, 0
  %new_val.0.i890 = lshr i64 %shr.i136.i887, 1
  store i64 %new_val.0.i890, ptr %RAX, align 8
  %cf.i891 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %501 = trunc i64 %shr.i136.i887 to i8
  %conv.i892 = and i8 %501, 1
  store i8 %conv.i892, ptr %cf.i891, align 1
  %pf.i893 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i894 = trunc i64 %new_val.0.i890 to i8
  %502 = call i8 @llvm.ctpop.i8(i8 %conv.i.i894)
  %503 = and i8 %502, 1
  %conv67.i895 = xor i8 %503, 1
  store i8 %conv67.i895, ptr %pf.i893, align 1
  %af.i896 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i888, ptr %af.i896, align 1
  %zf.i897 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i898 = icmp ult i64 %shr.i136.i887, 2
  %conv80.i899 = zext i1 %cmp.i140.i898 to i8
  store i8 %conv80.i899, ptr %zf.i897, align 1
  %sf.i900 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i900, align 1
  %of.i901 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i902 = zext i1 %tobool.i889 to i8
  store i8 %conv92.i902, ptr %of.i901, align 1
  store ptr %500, ptr %MEMORY, align 8
  br label %504

504:                                              ; preds = %496
  %505 = load i64, ptr %NEXT_PC, align 8
  store i64 %505, ptr %PC, align 8
  %506 = add i64 %505, 3
  store i64 %506, ptr %NEXT_PC, align 8
  %507 = load i64, ptr %RAX, align 8
  %508 = load ptr, ptr %MEMORY, align 8
  %sext167.i1060 = shl i64 %507, 32
  %conv.i155.i1061 = ashr exact i64 %sext167.i1060, 32
  %shr.i156.i1062 = ashr i64 %conv.i155.i1061, 1
  %call36.i1063 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1064 = icmp ne i8 %call36.i1063, 0
  %shr.i160.i1065 = ashr i64 %shr.i156.i1062, 1
  %509 = zext i1 %tobool.i1064 to i8
  %new_val.0.i1066 = trunc i64 %shr.i160.i1065 to i32
  %conv.i163.i1067 = and i64 %shr.i160.i1065, 4294967295
  store i64 %conv.i163.i1067, ptr %RAX, align 8
  %cf.i1068 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %510 = trunc i64 %shr.i156.i1062 to i8
  %conv.i1069 = and i8 %510, 1
  store i8 %conv.i1069, ptr %cf.i1068, align 1
  %pf.i1070 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1071 = trunc i64 %shr.i160.i1065 to i8
  %511 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1071)
  %512 = and i8 %511, 1
  %conv75.i1072 = xor i8 %512, 1
  store i8 %conv75.i1072, ptr %pf.i1070, align 1
  %af.i1073 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1063, ptr %af.i1073, align 1
  %zf.i1074 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1075 = icmp eq i32 %new_val.0.i1066, 0
  %conv88.i1076 = zext i1 %cmp.i165.i1075 to i8
  store i8 %conv88.i1076, ptr %zf.i1074, align 1
  %sf.i1077 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1078 = lshr i32 %new_val.0.i1066, 31
  %conv95.i1079 = trunc i32 %new_val.0.lobit.i1078 to i8
  store i8 %conv95.i1079, ptr %sf.i1077, align 1
  %of.i1080 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %509, ptr %of.i1080, align 1
  store ptr %508, ptr %MEMORY, align 8
  br label %513

513:                                              ; preds = %504
  %514 = load i64, ptr %NEXT_PC, align 8
  store i64 %514, ptr %PC, align 8
  %515 = add i64 %514, 2
  store i64 %515, ptr %NEXT_PC, align 8
  %516 = load i32, ptr %EDX, align 4
  %517 = zext i32 %516 to i64
  %518 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i781 = and i64 %517, 4294967295
  store i64 %conv.i11.i781, ptr %RDI, align 8
  store ptr %518, ptr %MEMORY, align 8
  br label %519

519:                                              ; preds = %513
  %520 = load i64, ptr %NEXT_PC, align 8
  store i64 %520, ptr %PC, align 8
  %521 = add i64 %520, 3
  store i64 %521, ptr %NEXT_PC, align 8
  %522 = load i64, ptr %RDI, align 8
  %523 = load ptr, ptr %MEMORY, align 8
  %sext167.i1039 = shl i64 %522, 32
  %conv.i155.i1040 = ashr exact i64 %sext167.i1039, 32
  %shr.i156.i1041 = ashr i64 %conv.i155.i1040, 30
  %call36.i1042 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1043 = icmp ne i8 %call36.i1042, 0
  %shr.i160.i1044 = ashr i64 %shr.i156.i1041, 1
  %524 = zext i1 %tobool.i1043 to i8
  %new_val.0.i1045 = trunc i64 %shr.i160.i1044 to i32
  %conv.i163.i1046 = and i64 %shr.i160.i1044, 4294967295
  store i64 %conv.i163.i1046, ptr %RDI, align 8
  %cf.i1047 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %525 = trunc i64 %shr.i156.i1041 to i8
  %conv.i1048 = and i8 %525, 1
  store i8 %conv.i1048, ptr %cf.i1047, align 1
  %pf.i1049 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1050 = trunc i64 %shr.i160.i1044 to i8
  %526 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1050)
  %527 = and i8 %526, 1
  %conv75.i1051 = xor i8 %527, 1
  store i8 %conv75.i1051, ptr %pf.i1049, align 1
  %af.i1052 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1042, ptr %af.i1052, align 1
  %zf.i1053 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1054 = icmp eq i32 %new_val.0.i1045, 0
  %conv88.i1055 = zext i1 %cmp.i165.i1054 to i8
  store i8 %conv88.i1055, ptr %zf.i1053, align 1
  %sf.i1056 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1057 = lshr i32 %new_val.0.i1045, 31
  %conv95.i1058 = trunc i32 %new_val.0.lobit.i1057 to i8
  store i8 %conv95.i1058, ptr %sf.i1056, align 1
  %of.i1059 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %524, ptr %of.i1059, align 1
  store ptr %523, ptr %MEMORY, align 8
  br label %528

528:                                              ; preds = %519
  %529 = load i64, ptr %NEXT_PC, align 8
  store i64 %529, ptr %PC, align 8
  %530 = add i64 %529, 2
  store i64 %530, ptr %NEXT_PC, align 8
  %531 = load i64, ptr %RAX, align 8
  %532 = load i32, ptr %EDI, align 4
  %533 = zext i32 %532 to i64
  %534 = load ptr, ptr %MEMORY, align 8
  %conv.i.i430 = trunc i64 %531 to i32
  %sub.i.i431 = sub i32 %conv.i.i430, %532
  %conv.i22.i432 = zext i32 %sub.i.i431 to i64
  store i64 %conv.i22.i432, ptr %RAX, align 8
  %cmp.i.i.i433 = icmp ult i32 %conv.i.i430, %532
  %call.i.i.i434 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i433, i32 noundef %conv.i.i430, i32 noundef %532, i32 noundef %sub.i.i431) #13
  %conv.i23.i435 = zext i1 %call.i.i.i434 to i8
  %cf.i.i436 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i435, ptr %cf.i.i436, align 1
  %conv.i.i.i.i437 = trunc i32 %sub.i.i431 to i8
  %535 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i437)
  %536 = and i8 %535, 1
  %conv.i.i.i438 = xor i8 %536, 1
  %pf.i.i.i439 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i438, ptr %pf.i.i.i439, align 1
  %xor.i.i.i.i440 = xor i32 %532, %conv.i.i430
  %xor1.i.i.i.i441 = xor i32 %xor.i.i.i.i440, %sub.i.i431
  %537 = trunc i32 %xor1.i.i.i.i441 to i8
  %538 = lshr i8 %537, 4
  %conv2.i.i.i442 = and i8 %538, 1
  %af.i.i.i443 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i442, ptr %af.i.i.i443, align 1
  %cmp.i.i.i.i444 = icmp eq i32 %conv.i.i430, %532
  %call.i.i.i.i445 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i444, i32 noundef %conv.i.i430, i32 noundef %532, i32 noundef %sub.i.i431) #13
  %conv5.i.i.i446 = zext i1 %call.i.i.i.i445 to i8
  %zf.i.i.i447 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i446, ptr %zf.i.i.i447, align 1
  %cmp.i27.i.i.i448 = icmp slt i32 %sub.i.i431, 0
  %call1.i.i.i.i449 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i448, i32 noundef %conv.i.i430, i32 noundef %532, i32 noundef %sub.i.i431) #13
  %conv8.i.i.i450 = zext i1 %call1.i.i.i.i449 to i8
  %sf.i.i.i451 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i450, ptr %sf.i.i.i451, align 1
  %xor.i28.i.i.i452 = lshr i32 %xor.i.i.i.i440, 31
  %shr9.i.i.i.i453 = xor i32 %sub.i.i431, %conv.i.i430
  %xor3.i.i.i.i454 = lshr i32 %shr9.i.i.i.i453, 31
  %add.i.i.i.i455 = add nuw nsw i32 %xor3.i.i.i.i454, %xor.i28.i.i.i452
  %cmp.i29.i.i.i456 = icmp eq i32 %add.i.i.i.i455, 2
  %call.i30.i.i.i457 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i456, i32 noundef %conv.i.i430, i32 noundef %532, i32 noundef %sub.i.i431) #13
  %conv11.i.i.i458 = zext i1 %call.i30.i.i.i457 to i8
  %of.i.i.i459 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i458, ptr %of.i.i.i459, align 1
  store ptr %534, ptr %MEMORY, align 8
  br label %539

539:                                              ; preds = %528
  %540 = load i64, ptr %NEXT_PC, align 8
  store i64 %540, ptr %PC, align 8
  %541 = add i64 %540, 2
  store i64 %541, ptr %NEXT_PC, align 8
  %542 = load i32, ptr %EAX, align 4
  %543 = zext i32 %542 to i64
  %544 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i780 = and i64 %543, 4294967295
  store i64 %conv.i11.i780, ptr %RCX, align 8
  store ptr %544, ptr %MEMORY, align 8
  br label %545

545:                                              ; preds = %539
  %546 = load i64, ptr %NEXT_PC, align 8
  store i64 %546, ptr %PC, align 8
  %547 = add i64 %546, 2
  store i64 %547, ptr %NEXT_PC, align 8
  %548 = load i32, ptr %ECX, align 4
  %549 = zext i32 %548 to i64
  %550 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i779 = and i64 %549, 4294967295
  store i64 %conv.i11.i779, ptr %RAX, align 8
  store ptr %550, ptr %MEMORY, align 8
  br label %551

551:                                              ; preds = %545
  %552 = load i64, ptr %NEXT_PC, align 8
  store i64 %552, ptr %PC, align 8
  %553 = add i64 %552, 3
  store i64 %553, ptr %NEXT_PC, align 8
  %554 = load i64, ptr %RAX, align 8
  %555 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i = shl i64 %554, 1
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  %conv.i155.i1229 = zext i32 %conv2.i154.i to i64
  store i64 %conv.i155.i1229, ptr %RAX, align 8
  %cf.i1230 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv2.i150.i, 31
  %conv.i1231 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i1231, ptr %cf.i1230, align 1
  %pf.i1232 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i154.i to i8
  %556 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %557 = and i8 %556, 1
  %conv72.i = xor i8 %557, 1
  store i8 %conv72.i, ptr %pf.i1232, align 1
  %af.i1233 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i1233, align 1
  %zf.i1234 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i154.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i1234, align 1
  %sf.i1235 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1236 = lshr i32 %conv2.i154.i, 31
  %conv92.i1237 = trunc i32 %new_val.0.lobit.i1236 to i8
  store i8 %conv92.i1237, ptr %sf.i1235, align 1
  %of.i1238 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i1238, align 1
  store ptr %555, ptr %MEMORY, align 8
  br label %558

558:                                              ; preds = %551
  %559 = load i64, ptr %NEXT_PC, align 8
  store i64 %559, ptr %PC, align 8
  %560 = add i64 %559, 2
  store i64 %560, ptr %NEXT_PC, align 8
  %561 = load i64, ptr %RAX, align 8
  %562 = load i32, ptr %ECX, align 4
  %563 = zext i32 %562 to i64
  %564 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %561 to i32
  %add.i.i64 = add i32 %562, %conv.i.i63
  %conv.i22.i65 = zext i32 %add.i.i64 to i64
  store i64 %conv.i22.i65, ptr %RAX, align 8
  %cmp.i.i.i66 = icmp ult i32 %add.i.i64, %conv.i.i63
  %cmp1.i.i.i67 = icmp ult i32 %add.i.i64, %562
  %565 = or i1 %cmp.i.i.i66, %cmp1.i.i.i67
  %call.i.i.i68 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %565, i32 noundef %conv.i.i63, i32 noundef %562, i32 noundef %add.i.i64) #13
  %conv.i23.i69 = zext i1 %call.i.i.i68 to i8
  %cf.i.i70 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i69, ptr %cf.i.i70, align 1
  %conv.i.i.i.i71 = trunc i32 %add.i.i64 to i8
  %566 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i71)
  %567 = and i8 %566, 1
  %conv.i.i.i72 = xor i8 %567, 1
  %pf.i.i.i73 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i72, ptr %pf.i.i.i73, align 1
  %xor.i.i.i.i74 = xor i32 %add.i.i64, %562
  %xor1.i.i.i.i75 = xor i32 %xor.i.i.i.i74, %conv.i.i63
  %568 = trunc i32 %xor1.i.i.i.i75 to i8
  %569 = lshr i8 %568, 4
  %conv2.i.i.i76 = and i8 %569, 1
  %af.i.i.i77 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i76, ptr %af.i.i.i77, align 1
  %cmp.i.i.i.i78 = icmp eq i32 %add.i.i64, 0
  %call.i.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i78, i32 noundef %conv.i.i63, i32 noundef %562, i32 noundef %add.i.i64) #13
  %conv5.i.i.i80 = zext i1 %call.i.i.i.i79 to i8
  %zf.i.i.i81 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i80, ptr %zf.i.i.i81, align 1
  %cmp.i27.i.i.i82 = icmp slt i32 %add.i.i64, 0
  %call1.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i82, i32 noundef %conv.i.i63, i32 noundef %562, i32 noundef %add.i.i64) #13
  %conv8.i.i.i84 = zext i1 %call1.i.i.i.i83 to i8
  %sf.i.i.i85 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i84, ptr %sf.i.i.i85, align 1
  %shr8.i.i.i.i86 = xor i32 %add.i.i64, %conv.i.i63
  %xor.i28.i.i.i87 = lshr i32 %shr8.i.i.i.i86, 31
  %xor3.i.i.i.i88 = lshr i32 %xor.i.i.i.i74, 31
  %add.i.i.i.i89 = add nuw nsw i32 %xor.i28.i.i.i87, %xor3.i.i.i.i88
  %cmp.i29.i.i.i90 = icmp eq i32 %add.i.i.i.i89, 2
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i90, i32 noundef %conv.i.i63, i32 noundef %562, i32 noundef %add.i.i64) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %564, ptr %MEMORY, align 8
  br label %570

570:                                              ; preds = %558
  %571 = load i64, ptr %NEXT_PC, align 8
  store i64 %571, ptr %PC, align 8
  %572 = add i64 %571, 2
  store i64 %572, ptr %NEXT_PC, align 8
  %573 = load i64, ptr %RAX, align 8
  %574 = load i32, ptr %EAX, align 4
  %575 = zext i32 %574 to i64
  %576 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %573 to i32
  %add.i.i33 = add i32 %574, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RAX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, %574
  %577 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %577, i32 noundef %conv.i.i32, i32 noundef %574, i32 noundef %add.i.i33) #13
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %578 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %579 = and i8 %578, 1
  %conv.i.i.i41 = xor i8 %579, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, %574
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %580 = trunc i32 %xor1.i.i.i.i44 to i8
  %581 = lshr i8 %580, 4
  %conv2.i.i.i45 = and i8 %581, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %574, i32 noundef %add.i.i33) #13
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef %574, i32 noundef %add.i.i33) #13
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef %574, i32 noundef %add.i.i33) #13
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %576, ptr %MEMORY, align 8
  br label %582

582:                                              ; preds = %570
  %583 = load i64, ptr %NEXT_PC, align 8
  store i64 %583, ptr %PC, align 8
  %584 = add i64 %583, 2
  store i64 %584, ptr %NEXT_PC, align 8
  %585 = load i32, ptr %EDX, align 4
  %586 = zext i32 %585 to i64
  %587 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i778 = and i64 %586, 4294967295
  store i64 %conv.i11.i778, ptr %RCX, align 8
  store ptr %587, ptr %MEMORY, align 8
  br label %588

588:                                              ; preds = %582
  %589 = load i64, ptr %NEXT_PC, align 8
  store i64 %589, ptr %PC, align 8
  %590 = add i64 %589, 2
  store i64 %590, ptr %NEXT_PC, align 8
  %591 = load i64, ptr %RCX, align 8
  %592 = load i32, ptr %EAX, align 4
  %593 = zext i32 %592 to i64
  %594 = load ptr, ptr %MEMORY, align 8
  %conv.i.i400 = trunc i64 %591 to i32
  %sub.i.i401 = sub i32 %conv.i.i400, %592
  %conv.i22.i402 = zext i32 %sub.i.i401 to i64
  store i64 %conv.i22.i402, ptr %RCX, align 8
  %cmp.i.i.i403 = icmp ult i32 %conv.i.i400, %592
  %call.i.i.i404 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i403, i32 noundef %conv.i.i400, i32 noundef %592, i32 noundef %sub.i.i401) #13
  %conv.i23.i405 = zext i1 %call.i.i.i404 to i8
  %cf.i.i406 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i405, ptr %cf.i.i406, align 1
  %conv.i.i.i.i407 = trunc i32 %sub.i.i401 to i8
  %595 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i407)
  %596 = and i8 %595, 1
  %conv.i.i.i408 = xor i8 %596, 1
  %pf.i.i.i409 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i408, ptr %pf.i.i.i409, align 1
  %xor.i.i.i.i410 = xor i32 %592, %conv.i.i400
  %xor1.i.i.i.i411 = xor i32 %xor.i.i.i.i410, %sub.i.i401
  %597 = trunc i32 %xor1.i.i.i.i411 to i8
  %598 = lshr i8 %597, 4
  %conv2.i.i.i412 = and i8 %598, 1
  %af.i.i.i413 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i412, ptr %af.i.i.i413, align 1
  %cmp.i.i.i.i414 = icmp eq i32 %conv.i.i400, %592
  %call.i.i.i.i415 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i414, i32 noundef %conv.i.i400, i32 noundef %592, i32 noundef %sub.i.i401) #13
  %conv5.i.i.i416 = zext i1 %call.i.i.i.i415 to i8
  %zf.i.i.i417 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i416, ptr %zf.i.i.i417, align 1
  %cmp.i27.i.i.i418 = icmp slt i32 %sub.i.i401, 0
  %call1.i.i.i.i419 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i418, i32 noundef %conv.i.i400, i32 noundef %592, i32 noundef %sub.i.i401) #13
  %conv8.i.i.i420 = zext i1 %call1.i.i.i.i419 to i8
  %sf.i.i.i421 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i420, ptr %sf.i.i.i421, align 1
  %xor.i28.i.i.i422 = lshr i32 %xor.i.i.i.i410, 31
  %shr9.i.i.i.i423 = xor i32 %sub.i.i401, %conv.i.i400
  %xor3.i.i.i.i424 = lshr i32 %shr9.i.i.i.i423, 31
  %add.i.i.i.i425 = add nuw nsw i32 %xor3.i.i.i.i424, %xor.i28.i.i.i422
  %cmp.i29.i.i.i426 = icmp eq i32 %add.i.i.i.i425, 2
  %call.i30.i.i.i427 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i426, i32 noundef %conv.i.i400, i32 noundef %592, i32 noundef %sub.i.i401) #13
  %conv11.i.i.i428 = zext i1 %call.i30.i.i.i427 to i8
  %of.i.i.i429 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i428, ptr %of.i.i.i429, align 1
  store ptr %594, ptr %MEMORY, align 8
  br label %599

599:                                              ; preds = %588
  %600 = load i64, ptr %NEXT_PC, align 8
  store i64 %600, ptr %PC, align 8
  %601 = add i64 %600, 3
  store i64 %601, ptr %NEXT_PC, align 8
  %602 = load i64, ptr %RSI, align 8
  %603 = load i64, ptr %RCX, align 8
  %604 = mul i64 %603, 1
  %605 = add i64 %602, %604
  %606 = load ptr, ptr %MEMORY, align 8
  %conv.i.i835 = and i64 %605, 4294967295
  store i64 %conv.i.i835, ptr %RDX, align 8
  store ptr %606, ptr %MEMORY, align 8
  br label %607

607:                                              ; preds = %599
  %608 = load i64, ptr %NEXT_PC, align 8
  store i64 %608, ptr %PC, align 8
  %609 = add i64 %608, 3
  store i64 %609, ptr %NEXT_PC, align 8
  %610 = load i64, ptr %RBP, align 8
  %611 = sub i64 %610, 8
  %612 = load ptr, ptr %MEMORY, align 8
  %call.i.i799 = call i32 @__remill_read_memory_32(ptr noundef %612, i64 noundef %611) #13
  %conv.i.i800 = zext i32 %call.i.i799 to i64
  store i64 %conv.i.i800, ptr %RAX, align 8
  store ptr %612, ptr %MEMORY, align 8
  br label %613

613:                                              ; preds = %607
  %614 = load i64, ptr %NEXT_PC, align 8
  store i64 %614, ptr %PC, align 8
  %615 = add i64 %614, 2
  store i64 %615, ptr %NEXT_PC, align 8
  %616 = load i64, ptr %RAX, align 8
  %617 = load i32, ptr %EDX, align 4
  %618 = zext i32 %617 to i64
  %619 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %616 to i32
  %add.i.i2 = add i32 %617, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RAX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %617
  %620 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %620, i32 noundef %conv.i.i1, i32 noundef %617, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %621 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %622 = and i8 %621, 1
  %conv.i.i.i10 = xor i8 %622, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %617
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %623 = trunc i32 %xor1.i.i.i.i13 to i8
  %624 = lshr i8 %623, 4
  %conv2.i.i.i14 = and i8 %624, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef %617, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef %617, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef %617, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %619, ptr %MEMORY, align 8
  br label %625

625:                                              ; preds = %613
  %626 = load i64, ptr %NEXT_PC, align 8
  store i64 %626, ptr %PC, align 8
  %627 = add i64 %626, 2
  store i64 %627, ptr %NEXT_PC, align 8
  %628 = load i32, ptr %EAX, align 4
  %629 = zext i32 %628 to i64
  %630 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i777 = and i64 %629, 4294967295
  store i64 %conv.i11.i777, ptr %RDX, align 8
  store ptr %630, ptr %MEMORY, align 8
  br label %631

631:                                              ; preds = %625
  %632 = load i64, ptr %NEXT_PC, align 8
  store i64 %632, ptr %PC, align 8
  %633 = add i64 %632, 3
  store i64 %633, ptr %NEXT_PC, align 8
  %634 = load i64, ptr %RDX, align 8
  %635 = load ptr, ptr %MEMORY, align 8
  %conv.i139.i = and i64 %634, 4294967295
  %shr.i140.i = lshr i64 %conv.i139.i, 30
  %conv2.i141.i = trunc i64 %shr.i140.i to i32
  %call34.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i32 %conv2.i141.i, 1
  %conv.i147.i = zext i32 %new_val.0.i to i64
  store i64 %conv.i147.i, ptr %RDX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %636 = trunc i32 %conv2.i141.i to i8
  %conv.i = and i8 %636, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i148.i = trunc i32 %new_val.0.i to i8
  %637 = call i8 @llvm.ctpop.i8(i8 %conv.i148.i)
  %638 = and i8 %637, 1
  %conv67.i = xor i8 %638, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i149.i = icmp ult i32 %conv2.i141.i, 2
  %conv80.i = zext i1 %cmp.i149.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %635, ptr %MEMORY, align 8
  br label %639

639:                                              ; preds = %631
  %640 = load i64, ptr %NEXT_PC, align 8
  store i64 %640, ptr %PC, align 8
  %641 = add i64 %640, 2
  store i64 %641, ptr %NEXT_PC, align 8
  %642 = load i64, ptr %RAX, align 8
  %643 = load i32, ptr %EDX, align 4
  %644 = zext i32 %643 to i64
  %645 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %642 to i32
  %add.i.i = add i32 %643, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %643
  %646 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %646, i32 noundef %conv.i.i, i32 noundef %643, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %647 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %648 = and i8 %647, 1
  %conv.i.i.i = xor i8 %648, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %643
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %649 = trunc i32 %xor1.i.i.i.i to i8
  %650 = lshr i8 %649, 4
  %conv2.i.i.i = and i8 %650, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %643, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %643, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %643, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %645, ptr %MEMORY, align 8
  br label %651

651:                                              ; preds = %639
  %652 = load i64, ptr %NEXT_PC, align 8
  store i64 %652, ptr %PC, align 8
  %653 = add i64 %652, 2
  store i64 %653, ptr %NEXT_PC, align 8
  %654 = load i64, ptr %RAX, align 8
  %655 = load ptr, ptr %MEMORY, align 8
  %sext.i1023 = shl i64 %654, 32
  %shr.i.i = ashr i64 %sext.i1023, 33
  %.pre.i = call zeroext i8 @__remill_undefined_8() #14
  %new_val.0.i1024 = trunc i64 %shr.i.i to i32
  %conv.i163.i1025 = and i64 %shr.i.i, 4294967295
  store i64 %conv.i163.i1025, ptr %RAX, align 8
  %cf.i1026 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %656 = trunc i64 %654 to i8
  %conv.i1027 = and i8 %656, 1
  store i8 %conv.i1027, ptr %cf.i1026, align 1
  %pf.i1028 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1029 = trunc i64 %shr.i.i to i8
  %657 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1029)
  %658 = and i8 %657, 1
  %conv75.i1030 = xor i8 %658, 1
  store i8 %conv75.i1030, ptr %pf.i1028, align 1
  %af.i1031 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %.pre.i, ptr %af.i1031, align 1
  %zf.i1032 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1033 = icmp eq i32 %new_val.0.i1024, 0
  %conv88.i1034 = zext i1 %cmp.i165.i1033 to i8
  store i8 %conv88.i1034, ptr %zf.i1032, align 1
  %sf.i1035 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1036 = lshr i32 %new_val.0.i1024, 31
  %conv95.i1037 = trunc i32 %new_val.0.lobit.i1036 to i8
  store i8 %conv95.i1037, ptr %sf.i1035, align 1
  %of.i1038 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i1038, align 1
  store ptr %655, ptr %MEMORY, align 8
  br label %659

659:                                              ; preds = %651
  %660 = load i64, ptr %NEXT_PC, align 8
  store i64 %660, ptr %PC, align 8
  %661 = add i64 %660, 3
  store i64 %661, ptr %NEXT_PC, align 8
  %662 = load i64, ptr %RBP, align 8
  %663 = sub i64 %662, 8
  %664 = load i32, ptr %EAX, align 4
  %665 = zext i32 %664 to i64
  %666 = load ptr, ptr %MEMORY, align 8
  %call.i.i771 = call ptr @__remill_write_memory_32(ptr noundef %666, i64 noundef %663, i32 noundef %664) #13
  store ptr %call.i.i771, ptr %MEMORY, align 8
  br label %667

667:                                              ; preds = %659
  %668 = load i64, ptr %NEXT_PC, align 8
  store i64 %668, ptr %PC, align 8
  %669 = add i64 %668, 3
  store i64 %669, ptr %NEXT_PC, align 8
  %670 = load i64, ptr %RBP, align 8
  %671 = sub i64 %670, 100
  %672 = load ptr, ptr %MEMORY, align 8
  %call.i.i797 = call i32 @__remill_read_memory_32(ptr noundef %672, i64 noundef %671) #13
  %conv.i.i798 = zext i32 %call.i.i797 to i64
  store i64 %conv.i.i798, ptr %RAX, align 8
  store ptr %672, ptr %MEMORY, align 8
  br label %673

673:                                              ; preds = %667
  %674 = load i64, ptr %NEXT_PC, align 8
  store i64 %674, ptr %PC, align 8
  %675 = add i64 %674, 3
  store i64 %675, ptr %NEXT_PC, align 8
  %676 = load i32, ptr %EAX, align 4
  %677 = zext i32 %676 to i64
  %678 = load ptr, ptr %MEMORY, align 8
  %sext.i813 = shl i64 %677, 32
  %conv.i12.i814 = ashr exact i64 %sext.i813, 32
  store i64 %conv.i12.i814, ptr %RDX, align 8
  store ptr %678, ptr %MEMORY, align 8
  br label %679

679:                                              ; preds = %673
  %680 = load i64, ptr %NEXT_PC, align 8
  store i64 %680, ptr %PC, align 8
  %681 = add i64 %680, 7
  store i64 %681, ptr %NEXT_PC, align 8
  %682 = load i64, ptr %RDX, align 8
  %683 = load ptr, ptr %MEMORY, align 8
  %684 = ashr i64 %682, 63
  %L.sroa.2.0.insert.ext.i.i674 = zext i64 %684 to i128
  %L.sroa.2.0.insert.shift.i.i675 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i674, 64
  %L.sroa.0.0.insert.ext.i.i676 = zext i64 %682 to i128
  %L.sroa.0.0.insert.insert.i.i677 = or i128 %L.sroa.2.0.insert.shift.i.i675, %L.sroa.0.0.insert.ext.i.i676
  %mul.i.i678 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i677
  %retval.sroa.0.0.extract.trunc.i.i679 = trunc i128 %mul.i.i678 to i64
  %retval.sroa.2.0.extract.shift.i.i680 = lshr i128 %mul.i.i678, 64
  %retval.sroa.2.0.extract.trunc.i.i681 = trunc i128 %retval.sroa.2.0.extract.shift.i.i680 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i679, ptr %RDX, align 8
  %conv2.i.i.i682 = sext i64 %retval.sroa.0.0.extract.trunc.i.i679 to i128
  %cmp.i.i.i683 = icmp ne i128 %mul.i.i678, %conv2.i.i.i682
  %call.i.i.i684 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i683, i64 noundef %682, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i679, i64 noundef %retval.sroa.2.0.extract.trunc.i.i681) #13
  %frombool.i.i685 = zext i1 %call.i.i.i684 to i8
  %cf.i.i686 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i685, ptr %cf.i.i686, align 1
  %call2.i.i687 = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i688 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i687, ptr %pf.i.i688, align 1
  %af.i.i689 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i687, ptr %af.i.i689, align 1
  %zf.i.i690 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i687, ptr %zf.i.i690, align 1
  %sf.i.i691 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i687, ptr %sf.i.i691, align 1
  %of.i.i692 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i685, ptr %of.i.i692, align 1
  store ptr %683, ptr %MEMORY, align 8
  br label %685

685:                                              ; preds = %679
  %686 = load i64, ptr %NEXT_PC, align 8
  store i64 %686, ptr %PC, align 8
  %687 = add i64 %686, 4
  store i64 %687, ptr %NEXT_PC, align 8
  %688 = load i64, ptr %RDX, align 8
  %689 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i871 = lshr i64 %688, 31
  %call34.i872 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i873 = icmp ne i8 %call34.i872, 0
  %new_val.0.i874 = lshr i64 %shr.i136.i871, 1
  store i64 %new_val.0.i874, ptr %RDX, align 8
  %cf.i875 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %690 = trunc i64 %shr.i136.i871 to i8
  %conv.i876 = and i8 %690, 1
  store i8 %conv.i876, ptr %cf.i875, align 1
  %pf.i877 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i878 = trunc i64 %new_val.0.i874 to i8
  %691 = call i8 @llvm.ctpop.i8(i8 %conv.i.i878)
  %692 = and i8 %691, 1
  %conv67.i879 = xor i8 %692, 1
  store i8 %conv67.i879, ptr %pf.i877, align 1
  %af.i880 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i872, ptr %af.i880, align 1
  %zf.i881 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i882 = icmp ult i64 %shr.i136.i871, 2
  %conv80.i883 = zext i1 %cmp.i140.i882 to i8
  store i8 %conv80.i883, ptr %zf.i881, align 1
  %sf.i884 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i884, align 1
  %of.i885 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i886 = zext i1 %tobool.i873 to i8
  store i8 %conv92.i886, ptr %of.i885, align 1
  store ptr %689, ptr %MEMORY, align 8
  br label %693

693:                                              ; preds = %685
  %694 = load i64, ptr %NEXT_PC, align 8
  store i64 %694, ptr %PC, align 8
  %695 = add i64 %694, 3
  store i64 %695, ptr %NEXT_PC, align 8
  %696 = load i64, ptr %RDX, align 8
  %697 = load ptr, ptr %MEMORY, align 8
  %sext167.i1002 = shl i64 %696, 32
  %conv.i155.i1003 = ashr exact i64 %sext167.i1002, 32
  %shr.i156.i1004 = ashr i64 %conv.i155.i1003, 1
  %call36.i1005 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i1006 = icmp ne i8 %call36.i1005, 0
  %shr.i160.i1007 = ashr i64 %shr.i156.i1004, 1
  %698 = zext i1 %tobool.i1006 to i8
  %new_val.0.i1008 = trunc i64 %shr.i160.i1007 to i32
  %conv.i163.i1009 = and i64 %shr.i160.i1007, 4294967295
  store i64 %conv.i163.i1009, ptr %RDX, align 8
  %cf.i1010 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %699 = trunc i64 %shr.i156.i1004 to i8
  %conv.i1011 = and i8 %699, 1
  store i8 %conv.i1011, ptr %cf.i1010, align 1
  %pf.i1012 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i1013 = trunc i64 %shr.i160.i1007 to i8
  %700 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i1013)
  %701 = and i8 %700, 1
  %conv75.i1014 = xor i8 %701, 1
  store i8 %conv75.i1014, ptr %pf.i1012, align 1
  %af.i1015 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1005, ptr %af.i1015, align 1
  %zf.i1016 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i1017 = icmp eq i32 %new_val.0.i1008, 0
  %conv88.i1018 = zext i1 %cmp.i165.i1017 to i8
  store i8 %conv88.i1018, ptr %zf.i1016, align 1
  %sf.i1019 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1020 = lshr i32 %new_val.0.i1008, 31
  %conv95.i1021 = trunc i32 %new_val.0.lobit.i1020 to i8
  store i8 %conv95.i1021, ptr %sf.i1019, align 1
  %of.i1022 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %698, ptr %of.i1022, align 1
  store ptr %697, ptr %MEMORY, align 8
  br label %702

702:                                              ; preds = %693
  %703 = load i64, ptr %NEXT_PC, align 8
  store i64 %703, ptr %PC, align 8
  %704 = add i64 %703, 3
  store i64 %704, ptr %NEXT_PC, align 8
  %705 = load i64, ptr %RAX, align 8
  %706 = load ptr, ptr %MEMORY, align 8
  %sext167.i981 = shl i64 %705, 32
  %conv.i155.i982 = ashr exact i64 %sext167.i981, 32
  %shr.i156.i983 = ashr i64 %conv.i155.i982, 30
  %call36.i984 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i985 = icmp ne i8 %call36.i984, 0
  %shr.i160.i986 = ashr i64 %shr.i156.i983, 1
  %707 = zext i1 %tobool.i985 to i8
  %new_val.0.i987 = trunc i64 %shr.i160.i986 to i32
  %conv.i163.i988 = and i64 %shr.i160.i986, 4294967295
  store i64 %conv.i163.i988, ptr %RAX, align 8
  %cf.i989 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %708 = trunc i64 %shr.i156.i983 to i8
  %conv.i990 = and i8 %708, 1
  store i8 %conv.i990, ptr %cf.i989, align 1
  %pf.i991 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i992 = trunc i64 %shr.i160.i986 to i8
  %709 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i992)
  %710 = and i8 %709, 1
  %conv75.i993 = xor i8 %710, 1
  store i8 %conv75.i993, ptr %pf.i991, align 1
  %af.i994 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i984, ptr %af.i994, align 1
  %zf.i995 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i996 = icmp eq i32 %new_val.0.i987, 0
  %conv88.i997 = zext i1 %cmp.i165.i996 to i8
  store i8 %conv88.i997, ptr %zf.i995, align 1
  %sf.i998 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i999 = lshr i32 %new_val.0.i987, 31
  %conv95.i1000 = trunc i32 %new_val.0.lobit.i999 to i8
  store i8 %conv95.i1000, ptr %sf.i998, align 1
  %of.i1001 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %707, ptr %of.i1001, align 1
  store ptr %706, ptr %MEMORY, align 8
  br label %711

711:                                              ; preds = %702
  %712 = load i64, ptr %NEXT_PC, align 8
  store i64 %712, ptr %PC, align 8
  %713 = add i64 %712, 2
  store i64 %713, ptr %NEXT_PC, align 8
  %714 = load i32, ptr %EAX, align 4
  %715 = zext i32 %714 to i64
  %716 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i776 = and i64 %715, 4294967295
  store i64 %conv.i11.i776, ptr %RCX, align 8
  store ptr %716, ptr %MEMORY, align 8
  br label %717

717:                                              ; preds = %711
  %718 = load i64, ptr %NEXT_PC, align 8
  store i64 %718, ptr %PC, align 8
  %719 = add i64 %718, 2
  store i64 %719, ptr %NEXT_PC, align 8
  %720 = load i32, ptr %EDX, align 4
  %721 = zext i32 %720 to i64
  %722 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i775 = and i64 %721, 4294967295
  store i64 %conv.i11.i775, ptr %RAX, align 8
  store ptr %722, ptr %MEMORY, align 8
  br label %723

723:                                              ; preds = %717
  %724 = load i64, ptr %NEXT_PC, align 8
  store i64 %724, ptr %PC, align 8
  %725 = add i64 %724, 2
  store i64 %725, ptr %NEXT_PC, align 8
  %726 = load i64, ptr %RAX, align 8
  %727 = load i32, ptr %ECX, align 4
  %728 = zext i32 %727 to i64
  %729 = load ptr, ptr %MEMORY, align 8
  %conv.i.i370 = trunc i64 %726 to i32
  %sub.i.i371 = sub i32 %conv.i.i370, %727
  %conv.i22.i372 = zext i32 %sub.i.i371 to i64
  store i64 %conv.i22.i372, ptr %RAX, align 8
  %cmp.i.i.i373 = icmp ult i32 %conv.i.i370, %727
  %call.i.i.i374 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i373, i32 noundef %conv.i.i370, i32 noundef %727, i32 noundef %sub.i.i371) #13
  %conv.i23.i375 = zext i1 %call.i.i.i374 to i8
  %cf.i.i376 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i375, ptr %cf.i.i376, align 1
  %conv.i.i.i.i377 = trunc i32 %sub.i.i371 to i8
  %730 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i377)
  %731 = and i8 %730, 1
  %conv.i.i.i378 = xor i8 %731, 1
  %pf.i.i.i379 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i378, ptr %pf.i.i.i379, align 1
  %xor.i.i.i.i380 = xor i32 %727, %conv.i.i370
  %xor1.i.i.i.i381 = xor i32 %xor.i.i.i.i380, %sub.i.i371
  %732 = trunc i32 %xor1.i.i.i.i381 to i8
  %733 = lshr i8 %732, 4
  %conv2.i.i.i382 = and i8 %733, 1
  %af.i.i.i383 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i382, ptr %af.i.i.i383, align 1
  %cmp.i.i.i.i384 = icmp eq i32 %conv.i.i370, %727
  %call.i.i.i.i385 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i384, i32 noundef %conv.i.i370, i32 noundef %727, i32 noundef %sub.i.i371) #13
  %conv5.i.i.i386 = zext i1 %call.i.i.i.i385 to i8
  %zf.i.i.i387 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i386, ptr %zf.i.i.i387, align 1
  %cmp.i27.i.i.i388 = icmp slt i32 %sub.i.i371, 0
  %call1.i.i.i.i389 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i388, i32 noundef %conv.i.i370, i32 noundef %727, i32 noundef %sub.i.i371) #13
  %conv8.i.i.i390 = zext i1 %call1.i.i.i.i389 to i8
  %sf.i.i.i391 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i390, ptr %sf.i.i.i391, align 1
  %xor.i28.i.i.i392 = lshr i32 %xor.i.i.i.i380, 31
  %shr9.i.i.i.i393 = xor i32 %sub.i.i371, %conv.i.i370
  %xor3.i.i.i.i394 = lshr i32 %shr9.i.i.i.i393, 31
  %add.i.i.i.i395 = add nuw nsw i32 %xor3.i.i.i.i394, %xor.i28.i.i.i392
  %cmp.i29.i.i.i396 = icmp eq i32 %add.i.i.i.i395, 2
  %call.i30.i.i.i397 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i396, i32 noundef %conv.i.i370, i32 noundef %727, i32 noundef %sub.i.i371) #13
  %conv11.i.i.i398 = zext i1 %call.i30.i.i.i397 to i8
  %of.i.i.i399 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i398, ptr %of.i.i.i399, align 1
  store ptr %729, ptr %MEMORY, align 8
  br label %734

734:                                              ; preds = %723
  %735 = load i64, ptr %NEXT_PC, align 8
  store i64 %735, ptr %PC, align 8
  %736 = add i64 %735, 3
  store i64 %736, ptr %NEXT_PC, align 8
  %737 = load i64, ptr %RBP, align 8
  %738 = sub i64 %737, 100
  %739 = load i32, ptr %EAX, align 4
  %740 = zext i32 %739 to i64
  %741 = load ptr, ptr %MEMORY, align 8
  %call.i.i770 = call ptr @__remill_write_memory_32(ptr noundef %741, i64 noundef %738, i32 noundef %739) #13
  store ptr %call.i.i770, ptr %MEMORY, align 8
  br label %742

742:                                              ; preds = %734
  %743 = load i64, ptr %NEXT_PC, align 8
  store i64 %743, ptr %PC, align 8
  %744 = add i64 %743, 3
  store i64 %744, ptr %NEXT_PC, align 8
  %745 = load i64, ptr %RBP, align 8
  %746 = sub i64 %745, 104
  %747 = load ptr, ptr %MEMORY, align 8
  %call.i.i795 = call i32 @__remill_read_memory_32(ptr noundef %747, i64 noundef %746) #13
  %conv.i.i796 = zext i32 %call.i.i795 to i64
  store i64 %conv.i.i796, ptr %RAX, align 8
  store ptr %747, ptr %MEMORY, align 8
  br label %748

748:                                              ; preds = %742
  %749 = load i64, ptr %NEXT_PC, align 8
  store i64 %749, ptr %PC, align 8
  %750 = add i64 %749, 3
  store i64 %750, ptr %NEXT_PC, align 8
  %751 = load i32, ptr %EAX, align 4
  %752 = zext i32 %751 to i64
  %753 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %752, 32
  %conv.i12.i = ashr exact i64 %sext.i, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %753, ptr %MEMORY, align 8
  br label %754

754:                                              ; preds = %748
  %755 = load i64, ptr %NEXT_PC, align 8
  store i64 %755, ptr %PC, align 8
  %756 = add i64 %755, 7
  store i64 %756, ptr %NEXT_PC, align 8
  %757 = load i64, ptr %RDX, align 8
  %758 = load ptr, ptr %MEMORY, align 8
  %759 = ashr i64 %757, 63
  %L.sroa.2.0.insert.ext.i.i = zext i64 %759 to i128
  %L.sroa.2.0.insert.shift.i.i = shl nuw i128 %L.sroa.2.0.insert.ext.i.i, 64
  %L.sroa.0.0.insert.ext.i.i = zext i64 %757 to i128
  %L.sroa.0.0.insert.insert.i.i = or i128 %L.sroa.2.0.insert.shift.i.i, %L.sroa.0.0.insert.ext.i.i
  %mul.i.i = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i
  %retval.sroa.0.0.extract.trunc.i.i = trunc i128 %mul.i.i to i64
  %retval.sroa.2.0.extract.shift.i.i = lshr i128 %mul.i.i, 64
  %retval.sroa.2.0.extract.trunc.i.i = trunc i128 %retval.sroa.2.0.extract.shift.i.i to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i, ptr %RDX, align 8
  %conv2.i.i.i670 = sext i64 %retval.sroa.0.0.extract.trunc.i.i to i128
  %cmp.i.i.i671 = icmp ne i128 %mul.i.i, %conv2.i.i.i670
  %call.i.i.i672 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i671, i64 noundef %757, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i, i64 noundef %retval.sroa.2.0.extract.trunc.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i672 to i8
  %cf.i.i673 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i673, align 1
  %call2.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %758, ptr %MEMORY, align 8
  br label %760

760:                                              ; preds = %754
  %761 = load i64, ptr %NEXT_PC, align 8
  store i64 %761, ptr %PC, align 8
  %762 = add i64 %761, 4
  store i64 %762, ptr %NEXT_PC, align 8
  %763 = load i64, ptr %RDX, align 8
  %764 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i = lshr i64 %763, 31
  %call34.i857 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i858 = icmp ne i8 %call34.i857, 0
  %new_val.0.i859 = lshr i64 %shr.i136.i, 1
  store i64 %new_val.0.i859, ptr %RDX, align 8
  %cf.i860 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %765 = trunc i64 %shr.i136.i to i8
  %conv.i861 = and i8 %765, 1
  store i8 %conv.i861, ptr %cf.i860, align 1
  %pf.i862 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i863 = trunc i64 %new_val.0.i859 to i8
  %766 = call i8 @llvm.ctpop.i8(i8 %conv.i.i863)
  %767 = and i8 %766, 1
  %conv67.i864 = xor i8 %767, 1
  store i8 %conv67.i864, ptr %pf.i862, align 1
  %af.i865 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i857, ptr %af.i865, align 1
  %zf.i866 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i = icmp ult i64 %shr.i136.i, 2
  %conv80.i867 = zext i1 %cmp.i140.i to i8
  store i8 %conv80.i867, ptr %zf.i866, align 1
  %sf.i868 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i868, align 1
  %of.i869 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv92.i870 = zext i1 %tobool.i858 to i8
  store i8 %conv92.i870, ptr %of.i869, align 1
  store ptr %764, ptr %MEMORY, align 8
  br label %768

768:                                              ; preds = %760
  %769 = load i64, ptr %NEXT_PC, align 8
  store i64 %769, ptr %PC, align 8
  %770 = add i64 %769, 3
  store i64 %770, ptr %NEXT_PC, align 8
  %771 = load i64, ptr %RDX, align 8
  %772 = load ptr, ptr %MEMORY, align 8
  %sext167.i960 = shl i64 %771, 32
  %conv.i155.i961 = ashr exact i64 %sext167.i960, 32
  %shr.i156.i962 = ashr i64 %conv.i155.i961, 1
  %call36.i963 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i964 = icmp ne i8 %call36.i963, 0
  %shr.i160.i965 = ashr i64 %shr.i156.i962, 1
  %773 = zext i1 %tobool.i964 to i8
  %new_val.0.i966 = trunc i64 %shr.i160.i965 to i32
  %conv.i163.i967 = and i64 %shr.i160.i965, 4294967295
  store i64 %conv.i163.i967, ptr %RDX, align 8
  %cf.i968 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %774 = trunc i64 %shr.i156.i962 to i8
  %conv.i969 = and i8 %774, 1
  store i8 %conv.i969, ptr %cf.i968, align 1
  %pf.i970 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i971 = trunc i64 %shr.i160.i965 to i8
  %775 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i971)
  %776 = and i8 %775, 1
  %conv75.i972 = xor i8 %776, 1
  store i8 %conv75.i972, ptr %pf.i970, align 1
  %af.i973 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i963, ptr %af.i973, align 1
  %zf.i974 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i975 = icmp eq i32 %new_val.0.i966, 0
  %conv88.i976 = zext i1 %cmp.i165.i975 to i8
  store i8 %conv88.i976, ptr %zf.i974, align 1
  %sf.i977 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i978 = lshr i32 %new_val.0.i966, 31
  %conv95.i979 = trunc i32 %new_val.0.lobit.i978 to i8
  store i8 %conv95.i979, ptr %sf.i977, align 1
  %of.i980 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %773, ptr %of.i980, align 1
  store ptr %772, ptr %MEMORY, align 8
  br label %777

777:                                              ; preds = %768
  %778 = load i64, ptr %NEXT_PC, align 8
  store i64 %778, ptr %PC, align 8
  %779 = add i64 %778, 3
  store i64 %779, ptr %NEXT_PC, align 8
  %780 = load i64, ptr %RAX, align 8
  %781 = load ptr, ptr %MEMORY, align 8
  %sext167.i = shl i64 %780, 32
  %conv.i155.i = ashr exact i64 %sext167.i, 32
  %shr.i156.i = ashr i64 %conv.i155.i, 30
  %call36.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i951 = icmp ne i8 %call36.i, 0
  %shr.i160.i = ashr i64 %shr.i156.i, 1
  %782 = zext i1 %tobool.i951 to i8
  %new_val.0.i952 = trunc i64 %shr.i160.i to i32
  %conv.i163.i = and i64 %shr.i160.i, 4294967295
  store i64 %conv.i163.i, ptr %RAX, align 8
  %cf.i953 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %783 = trunc i64 %shr.i156.i to i8
  %conv.i954 = and i8 %783, 1
  store i8 %conv.i954, ptr %cf.i953, align 1
  %pf.i955 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i = trunc i64 %shr.i160.i to i8
  %784 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i)
  %785 = and i8 %784, 1
  %conv75.i = xor i8 %785, 1
  store i8 %conv75.i, ptr %pf.i955, align 1
  %af.i956 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i, ptr %af.i956, align 1
  %zf.i957 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i = icmp eq i32 %new_val.0.i952, 0
  %conv88.i = zext i1 %cmp.i165.i to i8
  store i8 %conv88.i, ptr %zf.i957, align 1
  %sf.i958 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %new_val.0.i952, 31
  %conv95.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv95.i, ptr %sf.i958, align 1
  %of.i959 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %782, ptr %of.i959, align 1
  store ptr %781, ptr %MEMORY, align 8
  br label %786

786:                                              ; preds = %777
  %787 = load i64, ptr %NEXT_PC, align 8
  store i64 %787, ptr %PC, align 8
  %788 = add i64 %787, 2
  store i64 %788, ptr %NEXT_PC, align 8
  %789 = load i32, ptr %EAX, align 4
  %790 = zext i32 %789 to i64
  %791 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i774 = and i64 %790, 4294967295
  store i64 %conv.i11.i774, ptr %RCX, align 8
  store ptr %791, ptr %MEMORY, align 8
  br label %792

792:                                              ; preds = %786
  %793 = load i64, ptr %NEXT_PC, align 8
  store i64 %793, ptr %PC, align 8
  %794 = add i64 %793, 2
  store i64 %794, ptr %NEXT_PC, align 8
  %795 = load i32, ptr %EDX, align 4
  %796 = zext i32 %795 to i64
  %797 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %796, 4294967295
  store i64 %conv.i11.i, ptr %RAX, align 8
  store ptr %797, ptr %MEMORY, align 8
  br label %798

798:                                              ; preds = %792
  %799 = load i64, ptr %NEXT_PC, align 8
  store i64 %799, ptr %PC, align 8
  %800 = add i64 %799, 2
  store i64 %800, ptr %NEXT_PC, align 8
  %801 = load i64, ptr %RAX, align 8
  %802 = load i32, ptr %ECX, align 4
  %803 = zext i32 %802 to i64
  %804 = load ptr, ptr %MEMORY, align 8
  %conv.i.i342 = trunc i64 %801 to i32
  %sub.i.i = sub i32 %conv.i.i342, %802
  %conv.i22.i343 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i343, ptr %RAX, align 8
  %cmp.i.i.i344 = icmp ult i32 %conv.i.i342, %802
  %call.i.i.i345 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i344, i32 noundef %conv.i.i342, i32 noundef %802, i32 noundef %sub.i.i) #13
  %conv.i23.i346 = zext i1 %call.i.i.i345 to i8
  %cf.i.i347 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i346, ptr %cf.i.i347, align 1
  %conv.i.i.i.i348 = trunc i32 %sub.i.i to i8
  %805 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i348)
  %806 = and i8 %805, 1
  %conv.i.i.i349 = xor i8 %806, 1
  %pf.i.i.i350 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i349, ptr %pf.i.i.i350, align 1
  %xor.i.i.i.i351 = xor i32 %802, %conv.i.i342
  %xor1.i.i.i.i352 = xor i32 %xor.i.i.i.i351, %sub.i.i
  %807 = trunc i32 %xor1.i.i.i.i352 to i8
  %808 = lshr i8 %807, 4
  %conv2.i.i.i353 = and i8 %808, 1
  %af.i.i.i354 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i353, ptr %af.i.i.i354, align 1
  %cmp.i.i.i.i355 = icmp eq i32 %conv.i.i342, %802
  %call.i.i.i.i356 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i355, i32 noundef %conv.i.i342, i32 noundef %802, i32 noundef %sub.i.i) #13
  %conv5.i.i.i357 = zext i1 %call.i.i.i.i356 to i8
  %zf.i.i.i358 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i357, ptr %zf.i.i.i358, align 1
  %cmp.i27.i.i.i359 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i360 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i359, i32 noundef %conv.i.i342, i32 noundef %802, i32 noundef %sub.i.i) #13
  %conv8.i.i.i361 = zext i1 %call1.i.i.i.i360 to i8
  %sf.i.i.i362 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i361, ptr %sf.i.i.i362, align 1
  %xor.i28.i.i.i363 = lshr i32 %xor.i.i.i.i351, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i342
  %xor3.i.i.i.i364 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i365 = add nuw nsw i32 %xor3.i.i.i.i364, %xor.i28.i.i.i363
  %cmp.i29.i.i.i366 = icmp eq i32 %add.i.i.i.i365, 2
  %call.i30.i.i.i367 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i366, i32 noundef %conv.i.i342, i32 noundef %802, i32 noundef %sub.i.i) #13
  %conv11.i.i.i368 = zext i1 %call.i30.i.i.i367 to i8
  %of.i.i.i369 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i368, ptr %of.i.i.i369, align 1
  store ptr %804, ptr %MEMORY, align 8
  br label %809

809:                                              ; preds = %798
  %810 = load i64, ptr %NEXT_PC, align 8
  store i64 %810, ptr %PC, align 8
  %811 = add i64 %810, 3
  store i64 %811, ptr %NEXT_PC, align 8
  %812 = load i64, ptr %RBP, align 8
  %813 = sub i64 %812, 104
  %814 = load i32, ptr %EAX, align 4
  %815 = zext i32 %814 to i64
  %816 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %816, i64 noundef %813, i32 noundef %814) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %817

817:                                              ; preds = %809
  %818 = load i64, ptr %NEXT_PC, align 8
  store i64 %818, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_13ce(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 104
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 6
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 310
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_13d8(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = add i64 %12, 18
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %16, 0
  %call8.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i) #14
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_13f0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load i64, ptr %RBP, align 8
  %7 = sub i64 %6, 4
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %8, i64 noundef %7) #13
  %sub.i.i = sub i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %8, i64 noundef %5, i32 noundef %sub.i.i) #13
  %cmp.i.i.i = icmp ult i32 %call.i.i, 1
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #13
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %9 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %10 = and i8 %9, 1
  %conv.i.i.i = xor i8 %10, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %11 = trunc i32 %xor1.i.i.i.i to i8
  %12 = lshr i8 %11, 4
  %conv2.i.i.i = and i8 %12, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 1
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %1
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = add i64 %16, 34
  %18 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 33
  store i64 %17, ptr %rip.i, align 8
  store i64 %17, ptr %NEXT_PC, align 8
  store ptr %18, ptr %MEMORY, align 8
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  ret ptr %20
}

define ptr @BB_13de(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i5 = zext i32 %call.i.i4 to i64
  store i64 %conv.i.i5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = add i64 %10, 1
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i.i6 = and i64 %11, 4294967295
  store i64 %conv.i.i6, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 4
  %18 = load i32, ptr %EDX, align 4
  %19 = zext i32 %18 to i64
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %20, i64 noundef %17, i32 noundef %18) #13
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 1
  %25 = load i32, ptr %rax.i, align 8
  %conv.i.i = sext i32 %25 to i64
  store i64 %conv.i.i, ptr %rax.i, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %21
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 3
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RBP, align 8
  %30 = sub i64 %29, 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #13
  %conv.i.i3 = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i3, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %26
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 4
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RBP, align 8
  %36 = load i64, ptr %RAX, align 8
  %37 = mul i64 %36, 4
  %38 = add i64 %35, %37
  %39 = sub i64 %38, 96
  %40 = load i32, ptr %EDX, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %42, i64 noundef %39, i32 noundef %40) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %32
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1418(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 40
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %16 = load i8, ptr %sf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %frombool.i = zext i1 %tobool.not.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %tobool.not.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_13f6(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %ECX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 12
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EDX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i65 = and i64 %11, 4294967295
  store i64 %conv.i11.i65, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i = shl i64 %16, 1
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  %conv.i155.i = zext i32 %conv2.i154.i to i64
  store i64 %conv.i155.i, ptr %RAX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv2.i150.i, 31
  %conv.i = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i154.i to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %19 = and i8 %18, 1
  %conv72.i = xor i8 %19, 1
  store i8 %conv72.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i154.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %conv2.i154.i, 31
  %conv92.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv92.i, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %13
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 2
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RAX, align 8
  %24 = load i32, ptr %EDX, align 4
  %25 = zext i32 %24 to i64
  %26 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %23 to i32
  %add.i.i33 = add i32 %24, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RAX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, %24
  %27 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %27, i32 noundef %conv.i.i32, i32 noundef %24, i32 noundef %add.i.i33) #13
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %28 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %29 = and i8 %28, 1
  %conv.i.i.i41 = xor i8 %29, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, %24
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %30 = trunc i32 %xor1.i.i.i.i44 to i8
  %31 = lshr i8 %30, 4
  %conv2.i.i.i45 = and i8 %31, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %24, i32 noundef %add.i.i33) #13
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef %24, i32 noundef %add.i.i33) #13
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef %24, i32 noundef %add.i.i33) #13
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %26, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %20
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 2
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RAX, align 8
  %36 = load i32, ptr %EAX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %35 to i32
  %add.i.i2 = add i32 %36, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RAX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %36
  %39 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %39, i32 noundef %conv.i.i1, i32 noundef %36, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %41 = and i8 %40, 1
  %conv.i.i.i10 = xor i8 %41, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %36
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %42 = trunc i32 %xor1.i.i.i.i13 to i8
  %43 = lshr i8 %42, 4
  %conv2.i.i.i14 = and i8 %43, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef %36, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef %36, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef %36, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %38, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %32
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 2
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i32, ptr %EAX, align 4
  %48 = zext i32 %47 to i64
  %49 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %48, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 3
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RBP, align 8
  %54 = sub i64 %53, 4
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call i32 @__remill_read_memory_32(ptr noundef %55, i64 noundef %54) #13
  %conv.i.i69 = zext i32 %call.i.i68 to i64
  store i64 %conv.i.i69, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 3
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = sub i64 %59, 1
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = and i64 %60, 4294967295
  store i64 %conv.i.i72, ptr %RDX, align 8
  store ptr %61, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %56
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RBP, align 8
  %66 = sub i64 %65, 4
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %call.i.i64 = call ptr @__remill_write_memory_32(ptr noundef %69, i64 noundef %66, i32 noundef %67) #13
  store ptr %call.i.i64, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %62
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 2
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 1
  %74 = load i32, ptr %rax.i, align 8
  %conv.i.i63 = sext i32 %74 to i64
  store i64 %conv.i.i63, ptr %rax.i, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %70
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 4
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RBP, align 8
  %79 = load i64, ptr %RAX, align 8
  %80 = mul i64 %79, 4
  %81 = add i64 %78, %80
  %82 = sub i64 %81, 96
  %83 = load ptr, ptr %MEMORY, align 8
  %call.i.i66 = call i32 @__remill_read_memory_32(ptr noundef %83, i64 noundef %82) #13
  %conv.i.i67 = zext i32 %call.i.i66 to i64
  store i64 %conv.i.i67, ptr %RAX, align 8
  store ptr %83, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %75
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 2
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RAX, align 8
  %88 = load i32, ptr %ECX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %87 to i32
  %add.i.i = add i32 %88, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %88
  %91 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %91, i32 noundef %conv.i.i, i32 noundef %88, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %92 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %93 = and i8 %92, 1
  %conv.i.i.i = xor i8 %93, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %88
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %94 = trunc i32 %xor1.i.i.i.i to i8
  %95 = lshr i8 %94, 4
  %conv2.i.i.i = and i8 %95, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %88, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %88, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %88, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %84
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 3
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i64, ptr %RBP, align 8
  %100 = sub i64 %99, 12
  %101 = load i32, ptr %EAX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %103, i64 noundef %100, i32 noundef %101) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %96
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_141e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18980, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 12
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 1
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 13
  %11 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %11, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %10, i64 noundef %11) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #13
  %rip.i = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %17, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %15, ptr %MEMORY, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.18980, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.18980) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.18980) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4730, label %bb_127A
    i64 4770, label %bb_12A2
    i64 5060, label %bb_13C4
    i64 5070, label %bb_13CE
    i64 5080, label %bb_13D8
    i64 5086, label %bb_13DE
    i64 5104, label %bb_13F0
    i64 5110, label %bb_13F6
    i64 5144, label %bb_1418
    i64 5150, label %bb_141E
  ]

dead_end:                                         ; preds = %bb_1418, %bb_13F6, %bb_13F0, %bb_13DE, %bb_13D8, %bb_13CE, %bb_13C4, %bb_12A2, %bb_127A, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_127A:                                          ; preds = %entry
  %block_pc = add i64 4730, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4730, ptr %1)
  %4 = call ptr @BB_127a(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 5060, label %bb_13C4
  ]

bb_12A2:                                          ; preds = %bb_13CE, %bb_13C4, %entry
  %block_pc1 = add i64 4770, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4770, ptr %6)
  %9 = call ptr @BB_12a2(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 5060, label %bb_13C4
  ]

bb_13C4:                                          ; preds = %bb_12A2, %bb_127A, %entry
  %block_pc3 = add i64 5060, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 5060, ptr %11)
  %14 = call ptr @BB_13c4(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4770, label %bb_12A2
    i64 5070, label %bb_13CE
  ]

bb_13CE:                                          ; preds = %bb_13C4, %entry
  %block_pc5 = add i64 5070, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 5070, ptr %16)
  %19 = call ptr @BB_13ce(ptr %state, i64 %17, ptr %16) #16
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4770, label %bb_12A2
    i64 5080, label %bb_13D8
  ]

bb_13D8:                                          ; preds = %bb_13CE, %entry
  %block_pc7 = add i64 5080, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 5080, ptr %21)
  %24 = call ptr @BB_13d8(ptr %state, i64 %22, ptr %21) #16
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 5086, label %bb_13DE
    i64 5104, label %bb_13F0
  ]

bb_13DE:                                          ; preds = %bb_13D8, %entry
  %block_pc9 = add i64 5086, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 5086, ptr %26)
  %29 = call ptr @BB_13de(ptr %state, i64 %27, ptr %26) #16
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 5104, label %bb_13F0
  ]

bb_13F0:                                          ; preds = %bb_13DE, %bb_13D8, %entry
  %block_pc11 = add i64 5104, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 5104, ptr %31)
  %34 = call ptr @BB_13f0(ptr %state, i64 %32, ptr %31) #16
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 5144, label %bb_1418
  ]

bb_13F6:                                          ; preds = %bb_1418, %entry
  %block_pc13 = add i64 5110, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 5110, ptr %36)
  %39 = call ptr @BB_13f6(ptr %state, i64 %37, ptr %36) #16
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 5144, label %bb_1418
  ]

bb_1418:                                          ; preds = %bb_13F6, %bb_13F0, %entry
  %block_pc15 = add i64 5144, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 5144, ptr %41)
  %44 = call ptr @BB_1418(ptr %state, i64 %42, ptr %41) #16
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 5110, label %bb_13F6
    i64 5150, label %bb_141E
  ]

bb_141E:                                          ; preds = %bb_1418, %entry
  %block_pc17 = add i64 5150, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 5150, ptr %46)
  %49 = call ptr @BB_141e(ptr %state, i64 %47, ptr %46) #16
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  %51 = load ptr, ptr %mem_var, align 8
  ret ptr %51

return_bb:                                        ; No predecessors!
  %52 = load ptr, ptr %mem_var, align 8
  ret ptr %52
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4730, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18979, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
