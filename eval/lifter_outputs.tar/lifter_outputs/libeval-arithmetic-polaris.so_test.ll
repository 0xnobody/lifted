; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.202 = type { %struct.X86State.201 }
%struct.X86State.201 = type { %struct.ArchState.170, [32 x %union.VectorReg.173], %struct.ArithFlags.174, %union.anon.169, %struct.Segments.176, %struct.AddressSpace.178, %struct.GPR.179, %struct.X87Stack.182, %struct.MMX.186, %struct.FPUStatusFlags.187, %union.anon.169, %union.FPU.196, %struct.SegmentCaches.198, %struct.K_REG.200 }
%struct.ArchState.170 = type { i32, i32, %union.anon.169 }
%union.VectorReg.173 = type { %union.vec512_t.172 }
%union.vec512_t.172 = type { %struct.uint64v8_t.171 }
%struct.uint64v8_t.171 = type { [8 x i64] }
%struct.ArithFlags.174 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.176 = type { i16, %union.SegmentSelector.175, i16, %union.SegmentSelector.175, i16, %union.SegmentSelector.175, i16, %union.SegmentSelector.175, i16, %union.SegmentSelector.175, i16, %union.SegmentSelector.175 }
%union.SegmentSelector.175 = type { i16 }
%struct.AddressSpace.178 = type { i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177 }
%struct.Reg.177 = type { %union.anon.169 }
%struct.GPR.179 = type { i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177, i64, %struct.Reg.177 }
%struct.X87Stack.182 = type { [8 x %struct.anon.3.181] }
%struct.anon.3.181 = type { [6 x i8], %struct.float80_t.180 }
%struct.float80_t.180 = type { [10 x i8] }
%struct.MMX.186 = type { [8 x %struct.anon.4.185] }
%struct.anon.4.185 = type { i64, %union.vec64_t.184 }
%union.vec64_t.184 = type { %struct.uint64v1_t.183 }
%struct.uint64v1_t.183 = type { [1 x i64] }
%struct.FPUStatusFlags.187 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.169 = type { i64 }
%union.FPU.196 = type { %struct.anon.13.195 }
%struct.anon.13.195 = type { %struct.FpuFXSAVE.194, [96 x i8] }
%struct.FpuFXSAVE.194 = type { %union.SegmentSelector.175, %union.SegmentSelector.175, %union.FPUAbridgedTagWord.188, i8, i16, i32, %union.SegmentSelector.175, i16, i32, %union.SegmentSelector.175, i16, %union.FPUControlStatus.189, %union.FPUControlStatus.189, [8 x %struct.FPUStackElem.191], [16 x %union.vec128_t.193] }
%union.FPUAbridgedTagWord.188 = type { i8 }
%union.FPUControlStatus.189 = type { i32 }
%struct.FPUStackElem.191 = type { %union.anon.11.190, [6 x i8] }
%union.anon.11.190 = type { %struct.float80_t.180 }
%union.vec128_t.193 = type { %struct.uint128v1_t.192 }
%struct.uint128v1_t.192 = type { [1 x i128] }
%struct.SegmentCaches.198 = type { %struct.SegmentShadow.197, %struct.SegmentShadow.197, %struct.SegmentShadow.197, %struct.SegmentShadow.197, %struct.SegmentShadow.197, %struct.SegmentShadow.197 }
%struct.SegmentShadow.197 = type { %union.anon.169, i32, i32 }
%struct.K_REG.200 = type { [8 x %struct.anon.18.199] }
%struct.anon.18.199 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1100(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i120 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i120, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 16
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 16
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 16, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 16, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 16
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 16, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 16, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 16, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 4
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #13
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 11958
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #13
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call i32 @__remill_read_memory_32(ptr noundef %39, i64 noundef %38) #13
  %conv.i.i79 = zext i32 %call.i.i78 to i64
  store i64 %conv.i.i79, ptr %RDX, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 7
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %NEXT_PC, align 8
  %44 = add i64 %43, 11973
  %45 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call i64 @__remill_read_memory_64(ptr noundef %45, i64 noundef %44) #13
  store i64 %call.i.i80, ptr %RAX, align 8
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %40
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %RAX, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %50, i64 noundef %49) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %52 = and i8 %51, 1
  %conv.i.i.i32 = xor i8 %52, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %53 = trunc i32 %xor1.i.i.i.i35 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i36 = and i8 %54, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %46
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  %59 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %59, 0
  %of.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  %60 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %60, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %58, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %55
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 2
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i32, ptr %EDX, align 4
  %65 = zext i32 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %65, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %61
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RCX, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %70 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %72 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %72, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %73 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %74 = and i8 %73, 1
  %conv.i.i.i = xor i8 %74, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %75 = trunc i32 %xor1.i.i.i.i to i8
  %76 = lshr i8 %75, 4
  %conv2.i.i.i = and i8 %76, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %71, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %67
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load i32, ptr %EDX, align 4
  %82 = zext i32 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %80 to i32
  %sext.i = shl i64 %80, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %82, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %84 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %84, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %81, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %77
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RCX, align 8
  %89 = load ptr, ptr %MEMORY, align 8
  %conv.i.i82 = trunc i64 %88 to i32
  %and3.i.i = and i32 1, %conv.i.i82
  %conv.i22.i83 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i83, ptr %RCX, align 8
  %cf.i.i84 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i84, align 1
  %conv.i.i.i85 = trunc i32 %and3.i.i to i8
  %90 = and i8 %conv.i.i.i85, 1
  %conv.i23.i86 = xor i8 %90, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i86, ptr %pf.i.i87, align 1
  %cmp.i.i.i88 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i88, i32 noundef %conv.i.i82, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i89 to i8
  %zf.i.i90 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i90, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i82, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i91 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i91, align 1
  %of.i.i92 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i92, align 1
  %af.i.i93 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i93, align 1
  store ptr %89, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %85
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i32, ptr %ECX, align 4
  %95 = zext i32 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %94 to i8
  %97 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %98 = and i8 %97, 1
  %conv.i.i.i57 = xor i8 %98, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %94, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %94, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %94, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %91
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  %103 = load i8, ptr %zf.i, align 1
  store i8 %103, ptr %CL, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %99
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 2
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i8, ptr %AL, align 1
  %108 = zext i8 %107 to i64
  %109 = load i8, ptr %CL, align 1
  %110 = zext i8 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %110, %108
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i94 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i94, align 1
  %112 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %113 = and i8 %112, 1
  %conv.i27.i = xor i8 %113, 1
  %pf.i.i95 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i95, align 1
  %114 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i96 = and i32 %114, 255
  %cmp.i.i.i97 = icmp eq i8 %or3.i.i, 0
  %115 = trunc i64 %108 to i32
  %conv1.i.i.i = and i32 %115, 255
  %116 = trunc i64 %110 to i32
  %conv2.i.i.i98 = and i32 %116, 255
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i97, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i98, i32 noundef %conv.i.i.i96) #13
  %conv3.i.i100 = zext i1 %call.i.i.i99 to i8
  %zf.i.i101 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i100, ptr %zf.i.i101, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i98, i32 noundef %conv.i.i.i96) #13
  %conv6.i.i102 = zext i1 %call4.i.i.i to i8
  %sf.i.i103 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i102, ptr %sf.i.i103, align 1
  %of.i.i104 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i104, align 1
  %af.i.i105 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i105, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %104
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 2
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i8, ptr %AL, align 1
  %121 = zext i8 %120 to i64
  %122 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %121
  %and3.i.i106 = trunc i64 %and3.i15.i to i8
  %cf.i.i107 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i107, align 1
  %123 = and i8 %and3.i.i106, 1
  %conv.i14.i = xor i8 %123, 1
  %pf.i.i108 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i108, align 1
  %124 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i109 = and i32 %124, 255
  %cmp.i.i.i110 = icmp eq i8 %and3.i.i106, 0
  %125 = trunc i64 %121 to i32
  %conv1.i.i.i111 = and i32 %125, 255
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i110, i32 noundef %conv1.i.i.i111, i32 noundef 1, i32 noundef %conv.i.i.i109) #13
  %conv3.i.i113 = zext i1 %call.i.i.i112 to i8
  %zf.i.i114 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i113, ptr %zf.i.i114, align 1
  %call4.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i111, i32 noundef 1, i32 noundef %conv.i.i.i109) #13
  %conv6.i.i116 = zext i1 %call4.i.i.i115 to i8
  %sf.i.i117 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i116, ptr %sf.i.i117, align 1
  %of.i.i118 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i118, align 1
  %af.i.i119 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i119, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %117
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 6
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %NEXT_PC, align 8
  %130 = add i64 %129, 5
  %131 = load i64, ptr %NEXT_PC, align 8
  %132 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  %133 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %133, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %130, i64 %131
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %132, ptr %MEMORY, align 8
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  ret ptr %135
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1141(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i117 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i118 = zext i32 %call.i.i117 to i64
  store i64 %conv.i.i118, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %add.i.i32 = add i64 -16, %15
  store i64 %add.i.i32, ptr %RCX, align 8
  %cmp.i.i.i33 = icmp ult i64 %add.i.i32, %15
  %cmp1.i.i.i34 = icmp ult i64 %add.i.i32, -16
  %17 = or i1 %cmp.i.i.i33, %cmp1.i.i.i34
  %call.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i32) #13
  %conv.i.i36 = zext i1 %call.i.i.i35 to i8
  %cf.i.i37 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i36, ptr %cf.i.i37, align 1
  %conv.i.i.i.i38 = trunc i64 %add.i.i32 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i38)
  %19 = and i8 %18, 1
  %conv.i.i.i39 = xor i8 %19, 1
  %pf.i.i.i40 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i39, ptr %pf.i.i.i40, align 1
  %xor.i.i.i.i41 = xor i64 %add.i.i32, -16
  %xor1.i.i.i.i42 = xor i64 %xor.i.i.i.i41, %15
  %20 = trunc i64 %xor1.i.i.i.i42 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i43 = and i8 %21, 1
  %af.i.i.i44 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i43, ptr %af.i.i.i44, align 1
  %cmp.i.i.i.i45 = icmp eq i64 %add.i.i32, 0
  %call.i.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i45, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i32) #13
  %conv5.i.i.i47 = zext i1 %call.i.i.i.i46 to i8
  %zf.i.i.i48 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i47, ptr %zf.i.i.i48, align 1
  %cmp.i27.i.i.i49 = icmp slt i64 %add.i.i32, 0
  %call1.i.i.i.i50 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i49, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i32) #13
  %conv8.i.i.i51 = zext i1 %call1.i.i.i.i50 to i8
  %sf.i.i.i52 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i51, ptr %sf.i.i.i52, align 1
  %shr8.i.i.i.i53 = xor i64 %add.i.i32, %15
  %xor.i28.i.i.i54 = lshr i64 %shr8.i.i.i.i53, 63
  %xor3.i.i.i.i55 = lshr i64 %xor.i.i.i.i41, 63
  %add.i.i.i.i56 = add nuw nsw i64 %xor.i28.i.i.i54, %xor3.i.i.i.i55
  %cmp.i29.i.i.i57 = icmp eq i64 %add.i.i.i.i56, 2
  %call.i30.i.i.i58 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i57, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i32) #13
  %conv11.i.i.i59 = zext i1 %call.i30.i.i.i58 to i8
  %of.i.i.i60 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i59, ptr %of.i.i.i60, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 3
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RCX, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  store i64 %25, ptr %RSP, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %22
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RCX, align 8
  %31 = load i32, ptr %EAX, align 4
  %32 = zext i32 %31 to i64
  %33 = load ptr, ptr %MEMORY, align 8
  %call.i.i110 = call ptr @__remill_write_memory_32(ptr noundef %33, i64 noundef %30, i32 noundef %31) #13
  store ptr %call.i.i110, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %27
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 2
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RCX, align 8
  %38 = load ptr, ptr %MEMORY, align 8
  %call.i.i115 = call i32 @__remill_read_memory_32(ptr noundef %38, i64 noundef %37) #13
  %conv.i.i116 = zext i32 %call.i.i115 to i64
  store i64 %conv.i.i116, ptr %RAX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %34
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RAX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i193 = trunc i64 %42 to i32
  %conv2.i.i = shl i32 %conv.i.i193, 1
  %44 = xor i32 %conv2.i.i, %conv.i.i193
  %cmp.i146.i = icmp slt i32 %44, 0
  %.pre.i = call zeroext i8 @__remill_undefined_8() #14
  %conv.i155.i = zext i32 %conv2.i.i to i64
  store i64 %conv.i155.i, ptr %RAX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv.i.i193, 31
  %conv.i194 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i194, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %46 = and i8 %45, 1
  %conv72.i = xor i8 %46, 1
  store i8 %conv72.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %.pre.i, ptr %af.i, align 1
  %zf.i195 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i195, align 1
  %sf.i196 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %conv2.i.i, 31
  %conv92.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv92.i, ptr %sf.i196, align 1
  %of.i197 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %cmp.i146.i to i8
  store i8 %conv99.i, ptr %of.i197, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %39
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RCX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i113 = call i32 @__remill_read_memory_32(ptr noundef %51, i64 noundef %50) #13
  %conv.i.i114 = zext i32 %call.i.i113 to i64
  store i64 %conv.i.i114, ptr %RCX, align 8
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %47
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 6
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RCX, align 8
  %56 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %55 to i32
  %add.i.i2 = add i32 442, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 442
  %57 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %57, i32 noundef %conv.i.i1, i32 noundef 442, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %59 = and i8 %58, 1
  %conv.i.i.i10 = xor i8 %59, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 442
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %60 = trunc i32 %xor1.i.i.i.i13 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i14 = and i8 %61, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 442, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 442, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 442, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %56, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %52
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 6
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RCX, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  %conv.i.i133 = trunc i64 %65 to i32
  %and3.i.i134 = and i32 7772, %conv.i.i133
  %conv.i22.i135 = zext i32 %and3.i.i134 to i64
  store i64 %conv.i22.i135, ptr %RCX, align 8
  %cf.i.i136 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i136, align 1
  %conv.i.i.i137 = trunc i32 %and3.i.i134 to i8
  %67 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i137)
  %68 = and i8 %67, 1
  %conv.i23.i138 = xor i8 %68, 1
  %pf.i.i139 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i138, ptr %pf.i.i139, align 1
  %cmp.i.i.i140 = icmp eq i32 %and3.i.i134, 0
  %call.i.i.i141 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i140, i32 noundef %conv.i.i133, i32 noundef 7772, i32 noundef %and3.i.i134) #13
  %conv3.i.i142 = zext i1 %call.i.i.i141 to i8
  %zf.i.i143 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i142, ptr %zf.i.i143, align 1
  %call1.i.i.i144 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i133, i32 noundef 7772, i32 noundef %and3.i.i134) #13
  %conv6.i.i145 = zext i1 %call1.i.i.i144 to i8
  %sf.i.i146 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i145, ptr %sf.i.i146, align 1
  %of.i.i147 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i147, align 1
  %af.i.i148 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i148, align 1
  store ptr %66, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %62
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 2
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RAX, align 8
  %73 = load i32, ptr %ECX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i161 = trunc i64 %72 to i32
  %or3.i.i162 = or i32 %73, %conv.i.i161
  %conv.i27.i163 = zext i32 %or3.i.i162 to i64
  store i64 %conv.i27.i163, ptr %RAX, align 8
  %cf.i.i164 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i164, align 1
  %conv.i.i.i165 = trunc i32 %or3.i.i162 to i8
  %76 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i165)
  %77 = and i8 %76, 1
  %conv.i28.i166 = xor i8 %77, 1
  %pf.i.i167 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i166, ptr %pf.i.i167, align 1
  %cmp.i.i.i168 = icmp eq i32 %or3.i.i162, 0
  %call.i.i.i169 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i168, i32 noundef %conv.i.i161, i32 noundef %73, i32 noundef %or3.i.i162) #13
  %conv3.i.i170 = zext i1 %call.i.i.i169 to i8
  %zf.i.i171 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i170, ptr %zf.i.i171, align 1
  %cmp.i19.i.i172 = icmp slt i32 %or3.i.i162, 0
  %call1.i.i.i173 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i172, i32 noundef %conv.i.i161, i32 noundef %73, i32 noundef %or3.i.i162) #13
  %conv6.i.i174 = zext i1 %call1.i.i.i173 to i8
  %sf.i.i175 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i174, ptr %sf.i.i175, align 1
  %of.i.i176 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i176, align 1
  %af.i.i177 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  %call16.i178 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i178, ptr %af.i.i177, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %69
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 3
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RBP, align 8
  %82 = sub i64 %81, 8
  %83 = load i32, ptr %EAX, align 4
  %84 = zext i32 %83 to i64
  %85 = load ptr, ptr %MEMORY, align 8
  %call.i.i109 = call ptr @__remill_write_memory_32(ptr noundef %85, i64 noundef %82, i32 noundef %83) #13
  store ptr %call.i.i109, ptr %MEMORY, align 8
  br label %86

86:                                               ; preds = %78
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = add i64 %87, 7
  store i64 %88, ptr %NEXT_PC, align 8
  %89 = load i64, ptr %NEXT_PC, align 8
  %90 = add i64 %89, 11897
  %91 = load ptr, ptr %MEMORY, align 8
  %call.i.i120 = call i64 @__remill_read_memory_64(ptr noundef %91, i64 noundef %90) #13
  store i64 %call.i.i120, ptr %RAX, align 8
  store ptr %91, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %86
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 2
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RAX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i111 = call i32 @__remill_read_memory_32(ptr noundef %96, i64 noundef %95) #13
  %conv.i.i112 = zext i32 %call.i.i111 to i64
  store i64 %conv.i.i112, ptr %RDX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %92
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 7
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %NEXT_PC, align 8
  %101 = add i64 %100, 11864
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i119 = call i64 @__remill_read_memory_64(ptr noundef %102, i64 noundef %101) #13
  store i64 %call.i.i119, ptr %RAX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %97
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 3
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RAX, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %107, i64 noundef %106) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i61 = icmp ult i32 %call.i.i, 10
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i62 to i8
  %cf.i.i63 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i63, align 1
  %conv.i.i.i.i64 = trunc i32 %sub.i.i to i8
  %108 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i64)
  %109 = and i8 %108, 1
  %conv.i.i.i65 = xor i8 %109, 1
  %pf.i.i.i66 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i65, ptr %pf.i.i.i66, align 1
  %xor.i.i.i.i67 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i68 = xor i32 %xor.i.i.i.i67, %sub.i.i
  %110 = trunc i32 %xor1.i.i.i.i68 to i8
  %111 = lshr i8 %110, 4
  %conv2.i.i.i69 = and i8 %111, 1
  %af.i.i.i70 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i69, ptr %af.i.i.i70, align 1
  %cmp.i.i.i.i71 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i71, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i73 = zext i1 %call.i.i.i.i72 to i8
  %zf.i.i.i74 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i73, ptr %zf.i.i.i74, align 1
  %cmp.i27.i.i.i75 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i75, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i77 = zext i1 %call1.i.i.i.i76 to i8
  %sf.i.i.i78 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i77, ptr %sf.i.i.i78, align 1
  %xor.i28.i.i.i79 = lshr i32 %xor.i.i.i.i67, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i80 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i81 = add nuw nsw i32 %xor3.i.i.i.i80, %xor.i28.i.i.i79
  %cmp.i29.i.i.i82 = icmp eq i32 %add.i.i.i.i81, 2
  %call.i30.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i82, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i84 = zext i1 %call.i30.i.i.i83 to i8
  %of.i.i.i85 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i84, ptr %of.i.i.i85, align 1
  store ptr %107, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %103
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  %116 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %116, 0
  %of.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  %117 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %117, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %115, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %112
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 2
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i32, ptr %EDX, align 4
  %122 = zext i32 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %122, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %123, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %118
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 3
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RCX, align 8
  %128 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %127 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %129 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %129, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %130 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %131 = and i8 %130, 1
  %conv.i.i.i = xor i8 %131, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %132 = trunc i32 %xor1.i.i.i.i to i8
  %133 = lshr i8 %132, 4
  %conv2.i.i.i = and i8 %133, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %128, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %124
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 3
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RCX, align 8
  %138 = load i32, ptr %EDX, align 4
  %139 = zext i32 %138 to i64
  %140 = load ptr, ptr %MEMORY, align 8
  %conv.i.i104 = trunc i64 %137 to i32
  %sext.i = shl i64 %137, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %139, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %141 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i105 = icmp ult i64 %141, -4294967296
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i105, i32 noundef %conv.i.i104, i32 noundef %138, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i106 to i8
  %cf.i.i107 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i107, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %134
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RCX, align 8
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i121 = trunc i64 %145 to i32
  %and3.i.i = and i32 1, %conv.i.i121
  %conv.i22.i122 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i122, ptr %RCX, align 8
  %cf.i.i123 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i123, align 1
  %conv.i.i.i124 = trunc i32 %and3.i.i to i8
  %147 = and i8 %conv.i.i.i124, 1
  %conv.i23.i125 = xor i8 %147, 1
  %pf.i.i126 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i125, ptr %pf.i.i126, align 1
  %cmp.i.i.i127 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i128 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i127, i32 noundef %conv.i.i121, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i128 to i8
  %zf.i.i129 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i129, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i121, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i132, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i32, ptr %ECX, align 4
  %152 = zext i32 %151 to i64
  %153 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv.i12.i = zext i1 %call.i.i.i86 to i8
  %cf.i.i87 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i87, align 1
  %conv.i.i.i.i88 = trunc i32 %151 to i8
  %154 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i88)
  %155 = and i8 %154, 1
  %conv.i.i.i89 = xor i8 %155, 1
  %pf.i.i.i90 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i89, ptr %pf.i.i.i90, align 1
  %af.i.i.i91 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i91, align 1
  %cmp.i.i.i.i92 = icmp eq i32 %151, 0
  %call.i.i.i.i93 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i92, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv5.i.i.i94 = zext i1 %call.i.i.i.i93 to i8
  %zf.i.i.i95 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i94, ptr %zf.i.i.i95, align 1
  %cmp.i27.i.i.i96 = icmp slt i32 %151, 0
  %call1.i.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i96, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv8.i.i.i98 = zext i1 %call1.i.i.i.i97 to i8
  %sf.i.i.i99 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i98, ptr %sf.i.i.i99, align 1
  %xor.i28.i.i.i100 = lshr i32 %151, 31
  %call.i30.i.i.i101 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv11.i.i.i102 = zext i1 %call.i30.i.i.i101 to i8
  %of.i.i.i103 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i102, ptr %of.i.i.i103, align 1
  store ptr %153, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %148
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 3
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  %160 = load i8, ptr %zf.i, align 1
  store i8 %160, ptr %CL, align 1
  store ptr %159, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %156
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 2
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i8, ptr %AL, align 1
  %165 = zext i8 %164 to i64
  %166 = load i8, ptr %CL, align 1
  %167 = zext i8 %166 to i64
  %168 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %167, %165
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i149 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i149, align 1
  %169 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %170 = and i8 %169, 1
  %conv.i27.i = xor i8 %170, 1
  %pf.i.i150 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i150, align 1
  %171 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i151 = and i32 %171, 255
  %cmp.i.i.i152 = icmp eq i8 %or3.i.i, 0
  %172 = trunc i64 %165 to i32
  %conv1.i.i.i = and i32 %172, 255
  %173 = trunc i64 %167 to i32
  %conv2.i.i.i153 = and i32 %173, 255
  %call.i.i.i154 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i152, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i153, i32 noundef %conv.i.i.i151) #13
  %conv3.i.i155 = zext i1 %call.i.i.i154 to i8
  %zf.i.i156 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i155, ptr %zf.i.i156, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i153, i32 noundef %conv.i.i.i151) #13
  %conv6.i.i157 = zext i1 %call4.i.i.i to i8
  %sf.i.i158 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i157, ptr %sf.i.i158, align 1
  %of.i.i159 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i159, align 1
  %af.i.i160 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i160, align 1
  store ptr %168, ptr %MEMORY, align 8
  br label %174

174:                                              ; preds = %161
  %175 = load i64, ptr %NEXT_PC, align 8
  store i64 %175, ptr %PC, align 8
  %176 = add i64 %175, 2
  store i64 %176, ptr %NEXT_PC, align 8
  %177 = load i8, ptr %AL, align 1
  %178 = zext i8 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %178
  %and3.i.i179 = trunc i64 %and3.i15.i to i8
  %cf.i.i180 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i180, align 1
  %180 = and i8 %and3.i.i179, 1
  %conv.i14.i = xor i8 %180, 1
  %pf.i.i181 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i181, align 1
  %181 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i182 = and i32 %181, 255
  %cmp.i.i.i183 = icmp eq i8 %and3.i.i179, 0
  %182 = trunc i64 %178 to i32
  %conv1.i.i.i184 = and i32 %182, 255
  %call.i.i.i185 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i183, i32 noundef %conv1.i.i.i184, i32 noundef 1, i32 noundef %conv.i.i.i182) #13
  %conv3.i.i186 = zext i1 %call.i.i.i185 to i8
  %zf.i.i187 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i186, ptr %zf.i.i187, align 1
  %call4.i.i.i188 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i184, i32 noundef 1, i32 noundef %conv.i.i.i182) #13
  %conv6.i.i189 = zext i1 %call4.i.i.i188 to i8
  %sf.i.i190 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i189, ptr %sf.i.i190, align 1
  %of.i.i191 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i191, align 1
  %af.i.i192 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i192, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %174
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 6
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i64, ptr %NEXT_PC, align 8
  %187 = add i64 %186, 5
  %188 = load i64, ptr %NEXT_PC, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %zf.i108 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 2, i32 7
  %190 = load i8, ptr %zf.i108, align 1
  %tobool.not.i = icmp eq i8 %190, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %187, i64 %188
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %189, ptr %MEMORY, align 8
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = load ptr, ptr %MEMORY, align 8
  ret ptr %192
}

define ptr @BB_119e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.202, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %16, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %12
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #13
  %rip.i = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %22, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %20, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.202, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.202) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.202) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4352, label %bb_1100
    i64 4417, label %bb_1141
    i64 4510, label %bb_119E
  ]

dead_end:                                         ; preds = %bb_1141, %bb_1100, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1100:                                          ; preds = %entry
  %block_pc = add i64 4352, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4352, ptr %1)
  %4 = call ptr @BB_1100(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4417, label %bb_1141
  ]

bb_1141:                                          ; preds = %bb_1100, %entry
  %block_pc1 = add i64 4417, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4417, ptr %6)
  %9 = call ptr @BB_1141(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4510, label %bb_119E
  ]

bb_119E:                                          ; preds = %bb_1141, %entry
  %block_pc3 = add i64 4510, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4510, ptr %11)
  %14 = call ptr @BB_119e(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  %16 = load ptr, ptr %mem_var, align 8
  ret ptr %16

return_bb:                                        ; No predecessors!
  %17 = load ptr, ptr %mem_var, align 8
  ret ptr %17
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4352, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.201, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
