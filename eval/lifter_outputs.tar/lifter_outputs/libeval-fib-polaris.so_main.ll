; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.254476 = type { %struct.X86State.254475 }
%struct.X86State.254475 = type { %struct.ArchState.254444, [32 x %union.VectorReg.254447], %struct.ArithFlags.254448, %union.anon.254443, %struct.Segments.254450, %struct.AddressSpace.254452, %struct.GPR.254453, %struct.X87Stack.254456, %struct.MMX.254460, %struct.FPUStatusFlags.254461, %union.anon.254443, %union.FPU.254470, %struct.SegmentCaches.254472, %struct.K_REG.254474 }
%struct.ArchState.254444 = type { i32, i32, %union.anon.254443 }
%union.VectorReg.254447 = type { %union.vec512_t.254446 }
%union.vec512_t.254446 = type { %struct.uint64v8_t.254445 }
%struct.uint64v8_t.254445 = type { [8 x i64] }
%struct.ArithFlags.254448 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.254450 = type { i16, %union.SegmentSelector.254449, i16, %union.SegmentSelector.254449, i16, %union.SegmentSelector.254449, i16, %union.SegmentSelector.254449, i16, %union.SegmentSelector.254449, i16, %union.SegmentSelector.254449 }
%union.SegmentSelector.254449 = type { i16 }
%struct.AddressSpace.254452 = type { i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451 }
%struct.Reg.254451 = type { %union.anon.254443 }
%struct.GPR.254453 = type { i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451, i64, %struct.Reg.254451 }
%struct.X87Stack.254456 = type { [8 x %struct.anon.3.254455] }
%struct.anon.3.254455 = type { [6 x i8], %struct.float80_t.254454 }
%struct.float80_t.254454 = type { [10 x i8] }
%struct.MMX.254460 = type { [8 x %struct.anon.4.254459] }
%struct.anon.4.254459 = type { i64, %union.vec64_t.254458 }
%union.vec64_t.254458 = type { %struct.uint64v1_t.254457 }
%struct.uint64v1_t.254457 = type { [1 x i64] }
%struct.FPUStatusFlags.254461 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.254443 = type { i64 }
%union.FPU.254470 = type { %struct.anon.13.254469 }
%struct.anon.13.254469 = type { %struct.FpuFXSAVE.254468, [96 x i8] }
%struct.FpuFXSAVE.254468 = type { %union.SegmentSelector.254449, %union.SegmentSelector.254449, %union.FPUAbridgedTagWord.254462, i8, i16, i32, %union.SegmentSelector.254449, i16, i32, %union.SegmentSelector.254449, i16, %union.FPUControlStatus.254463, %union.FPUControlStatus.254463, [8 x %struct.FPUStackElem.254465], [16 x %union.vec128_t.254467] }
%union.FPUAbridgedTagWord.254462 = type { i8 }
%union.FPUControlStatus.254463 = type { i32 }
%struct.FPUStackElem.254465 = type { %union.anon.11.254464, [6 x i8] }
%union.anon.11.254464 = type { %struct.float80_t.254454 }
%union.vec128_t.254467 = type { %struct.uint128v1_t.254466 }
%struct.uint128v1_t.254466 = type { [1 x i128] }
%struct.SegmentCaches.254472 = type { %struct.SegmentShadow.254471, %struct.SegmentShadow.254471, %struct.SegmentShadow.254471, %struct.SegmentShadow.254471, %struct.SegmentShadow.254471, %struct.SegmentShadow.254471 }
%struct.SegmentShadow.254471 = type { %union.anon.254443, i32, i32 }
%struct.K_REG.254474 = type { [8 x %struct.anon.18.254473] }
%struct.anon.18.254473 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_14f0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i121 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #18
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i121, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 96
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 96
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #18
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 96, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 96
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #18
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #18
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #18
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 12
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #18
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 8
  %34 = load i64, ptr %RSI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_64(ptr noundef %35, i64 noundef %33, i64 noundef %34) #18
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 10938
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #18
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #18
  %conv.i.i80 = zext i32 %call.i.i79 to i64
  store i64 %conv.i.i80, ptr %RDX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 7
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %NEXT_PC, align 8
  %51 = add i64 %50, 10737
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %52, i64 noundef %51) #18
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %57, i64 noundef %56) #18
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %59 = and i8 %58, 1
  %conv.i.i.i32 = xor i8 %59, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %60 = trunc i32 %xor1.i.i.i.i35 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i36 = and i8 %61, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %53
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %66 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %66, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %67 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %67, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %EDX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %72, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RCX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %77 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %79 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %79, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %80 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %81 = and i8 %80, 1
  %conv.i.i.i = xor i8 %81, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %82 = trunc i32 %xor1.i.i.i.i to i8
  %83 = lshr i8 %82, 4
  %conv2.i.i.i = and i8 %83, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %74
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 3
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RCX, align 8
  %88 = load i32, ptr %EDX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %87 to i32
  %sext.i = shl i64 %87, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %89, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %91 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %91, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %88, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %84
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %conv.i.i83 = trunc i64 %95 to i32
  %and3.i.i = and i32 1, %conv.i.i83
  %conv.i22.i84 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i84, ptr %RCX, align 8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i85, align 1
  %conv.i.i.i86 = trunc i32 %and3.i.i to i8
  %97 = and i8 %conv.i.i.i86, 1
  %conv.i23.i87 = xor i8 %97, 1
  %pf.i.i88 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i87, ptr %pf.i.i88, align 1
  %cmp.i.i.i89 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i90 to i8
  %zf.i.i91 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i91, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i94, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i32, ptr %ECX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %101 to i8
  %104 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %105 = and i8 %104, 1
  %conv.i.i.i57 = xor i8 %105, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %101, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %101, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %101, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %98
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %110 = load i8, ptr %zf.i, align 1
  store i8 %110, ptr %CL, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %106
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 2
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i8, ptr %AL, align 1
  %115 = zext i8 %114 to i64
  %116 = load i8, ptr %CL, align 1
  %117 = zext i8 %116 to i64
  %118 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %117, %115
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i95 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %119 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %120 = and i8 %119, 1
  %conv.i27.i = xor i8 %120, 1
  %pf.i.i96 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i96, align 1
  %121 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i97 = and i32 %121, 255
  %cmp.i.i.i98 = icmp eq i8 %or3.i.i, 0
  %122 = trunc i64 %115 to i32
  %conv1.i.i.i = and i32 %122, 255
  %123 = trunc i64 %117 to i32
  %conv2.i.i.i99 = and i32 %123, 255
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i98, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #18
  %conv3.i.i101 = zext i1 %call.i.i.i100 to i8
  %zf.i.i102 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i101, ptr %zf.i.i102, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #18
  %conv6.i.i103 = zext i1 %call4.i.i.i to i8
  %sf.i.i104 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i103, ptr %sf.i.i104, align 1
  %of.i.i105 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i105, align 1
  %af.i.i106 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i106, align 1
  store ptr %118, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %111
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %128
  %and3.i.i107 = trunc i64 %and3.i15.i to i8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i108, align 1
  %130 = and i8 %and3.i.i107, 1
  %conv.i14.i = xor i8 %130, 1
  %pf.i.i109 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i109, align 1
  %131 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i110 = and i32 %131, 255
  %cmp.i.i.i111 = icmp eq i8 %and3.i.i107, 0
  %132 = trunc i64 %128 to i32
  %conv1.i.i.i112 = and i32 %132, 255
  %call.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #18
  %conv3.i.i114 = zext i1 %call.i.i.i113 to i8
  %zf.i.i115 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i114, ptr %zf.i.i115, align 1
  %call4.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #18
  %conv6.i.i117 = zext i1 %call4.i.i.i116 to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i117, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i120, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %124
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 6
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %NEXT_PC, align 8
  %137 = add i64 %136, 5
  %138 = load i64, ptr %NEXT_PC, align 8
  %139 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %140 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %140, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %137, i64 %138
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %139, ptr %MEMORY, align 8
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  ret ptr %142
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1535(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i338 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i338, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 12
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i333 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #18
  %conv.i.i334 = zext i32 %call.i.i333 to i64
  store i64 %conv.i.i334, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RSP, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RDI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RDI, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 -16, %21
  store i64 %add.i.i146, ptr %RDI, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %21
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, -16
  %23 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %23, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %25 = and i8 %24, 1
  %conv.i.i.i153 = xor i8 %25, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, -16
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %21
  %26 = trunc i64 %xor1.i.i.i.i156 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i157 = and i8 %27, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %21
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %18
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 4
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 64
  %33 = load i64, ptr %RDI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i328 = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %32, i64 noundef %33) #18
  store ptr %call.i.i328, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RDI, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RSP, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %RSP, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  store i64 %43, ptr %RAX, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %40
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 4
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RAX, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %48
  store i64 %add.i.i117, ptr %RAX, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %48
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %50 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %50, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %52 = and i8 %51, 1
  %conv.i.i.i124 = xor i8 %52, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %48
  %53 = trunc i64 %xor1.i.i.i.i127 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i128 = and i8 %54, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %48
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %45
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  store i64 %58, ptr %RSP, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 3
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RSP, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  store i64 %63, ptr %RCX, align 8
  store ptr %64, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %60
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 4
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RCX, align 8
  %69 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %68
  store i64 %add.i.i88, ptr %RCX, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %68
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %70 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %70, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %72 = and i8 %71, 1
  %conv.i.i.i95 = xor i8 %72, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %68
  %73 = trunc i64 %xor1.i.i.i.i98 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i99 = and i8 %74, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %68
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %65
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 4
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RBP, align 8
  %79 = sub i64 %78, 56
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %call.i.i327 = call ptr @__remill_write_memory_64(ptr noundef %81, i64 noundef %79, i64 noundef %80) #18
  store ptr %call.i.i327, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %75
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RCX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  store i64 %85, ptr %RSP, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %82
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RSP, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  store i64 %90, ptr %R8, align 8
  store ptr %91, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %87
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 4
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %R8, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %95
  store i64 %add.i.i59, ptr %R8, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %95
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %97 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %97, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %98 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %99 = and i8 %98, 1
  %conv.i.i.i66 = xor i8 %99, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %95
  %100 = trunc i64 %xor1.i.i.i.i69 to i8
  %101 = lshr i8 %100, 4
  %conv2.i.i.i70 = and i8 %101, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %95
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %92
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 4
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load i64, ptr %RBP, align 8
  %106 = sub i64 %105, 48
  %107 = load i64, ptr %R8, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i326 = call ptr @__remill_write_memory_64(ptr noundef %108, i64 noundef %106, i64 noundef %107) #18
  store ptr %call.i.i326, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %102
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 3
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %R8, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  store i64 %112, ptr %RSP, align 8
  store ptr %113, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %109
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RSP, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  store i64 %117, ptr %R8, align 8
  store ptr %118, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %114
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 4
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %R8, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %122
  store i64 %add.i.i30, ptr %R8, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %122
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %124 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %124, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %125 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %126 = and i8 %125, 1
  %conv.i.i.i37 = xor i8 %126, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %122
  %127 = trunc i64 %xor1.i.i.i.i40 to i8
  %128 = lshr i8 %127, 4
  %conv2.i.i.i41 = and i8 %128, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %122
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %119
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 4
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %RBP, align 8
  %133 = sub i64 %132, 40
  %134 = load i64, ptr %R8, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %call.i.i325 = call ptr @__remill_write_memory_64(ptr noundef %135, i64 noundef %133, i64 noundef %134) #18
  store ptr %call.i.i325, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %129
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 3
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %R8, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  store i64 %139, ptr %RSP, align 8
  store ptr %140, ptr %MEMORY, align 8
  br label %141

141:                                              ; preds = %136
  %142 = load i64, ptr %NEXT_PC, align 8
  store i64 %142, ptr %PC, align 8
  %143 = add i64 %142, 3
  store i64 %143, ptr %NEXT_PC, align 8
  %144 = load i64, ptr %RSP, align 8
  %145 = load ptr, ptr %MEMORY, align 8
  store i64 %144, ptr %R8, align 8
  store ptr %145, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %141
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 4
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %R8, align 8
  %150 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %149
  store i64 %add.i.i1, ptr %R8, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %149
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %151 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %151, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %152 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %153 = and i8 %152, 1
  %conv.i.i.i8 = xor i8 %153, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %149
  %154 = trunc i64 %xor1.i.i.i.i11 to i8
  %155 = lshr i8 %154, 4
  %conv2.i.i.i12 = and i8 %155, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %149
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %150, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %146
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 4
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load i64, ptr %RBP, align 8
  %160 = sub i64 %159, 32
  %161 = load i64, ptr %R8, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i324 = call ptr @__remill_write_memory_64(ptr noundef %162, i64 noundef %160, i64 noundef %161) #18
  store ptr %call.i.i324, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %156
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 3
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %R8, align 8
  %167 = load ptr, ptr %MEMORY, align 8
  store i64 %166, ptr %RSP, align 8
  store ptr %167, ptr %MEMORY, align 8
  br label %168

168:                                              ; preds = %163
  %169 = load i64, ptr %NEXT_PC, align 8
  store i64 %169, ptr %PC, align 8
  %170 = add i64 %169, 6
  store i64 %170, ptr %NEXT_PC, align 8
  %171 = load i64, ptr %RDI, align 8
  %172 = load ptr, ptr %MEMORY, align 8
  %call.i.i320 = call ptr @__remill_write_memory_32(ptr noundef %172, i64 noundef %171, i32 noundef 0) #18
  store ptr %call.i.i320, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %168
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 2
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i64, ptr %RAX, align 8
  %177 = load i32, ptr %ESI, align 4
  %178 = zext i32 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %call.i.i321 = call ptr @__remill_write_memory_32(ptr noundef %179, i64 noundef %176, i32 noundef %177) #18
  store ptr %call.i.i321, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %173
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 3
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i64, ptr %RCX, align 8
  %184 = load i64, ptr %RDX, align 8
  %185 = load ptr, ptr %MEMORY, align 8
  %call.i.i323 = call ptr @__remill_write_memory_64(ptr noundef %185, i64 noundef %183, i64 noundef %184) #18
  store ptr %call.i.i323, ptr %MEMORY, align 8
  br label %186

186:                                              ; preds = %180
  %187 = load i64, ptr %NEXT_PC, align 8
  store i64 %187, ptr %PC, align 8
  %188 = add i64 %187, 2
  store i64 %188, ptr %NEXT_PC, align 8
  %189 = load i64, ptr %RAX, align 8
  %190 = load ptr, ptr %MEMORY, align 8
  %call.i.i331 = call i32 @__remill_read_memory_32(ptr noundef %190, i64 noundef %189) #18
  %conv.i.i332 = zext i32 %call.i.i331 to i64
  store i64 %conv.i.i332, ptr %RDX, align 8
  store ptr %190, ptr %MEMORY, align 8
  br label %191

191:                                              ; preds = %186
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = add i64 %192, 5
  store i64 %193, ptr %NEXT_PC, align 8
  %194 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RCX, align 8
  store ptr %194, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %191
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 2
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i64, ptr %RAX, align 8
  %199 = load i32, ptr %EAX, align 4
  %200 = zext i32 %199 to i64
  %201 = load ptr, ptr %MEMORY, align 8
  %conv.i.i382 = trunc i64 %198 to i32
  %xor3.i.i383 = xor i32 %199, %conv.i.i382
  %conv.i27.i384 = zext i32 %xor3.i.i383 to i64
  store i64 %conv.i27.i384, ptr %RAX, align 8
  %cf.i.i385 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i385, align 1
  %conv.i.i.i386 = trunc i32 %xor3.i.i383 to i8
  %202 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i386)
  %203 = and i8 %202, 1
  %conv.i28.i387 = xor i8 %203, 1
  %pf.i.i388 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i387, ptr %pf.i.i388, align 1
  %cmp.i.i.i389 = icmp eq i32 %xor3.i.i383, 0
  %call.i.i.i390 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i389, i32 noundef %conv.i.i382, i32 noundef %199, i32 noundef %xor3.i.i383) #18
  %conv3.i.i391 = zext i1 %call.i.i.i390 to i8
  %zf.i.i392 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i391, ptr %zf.i.i392, align 1
  %cmp.i19.i.i393 = icmp slt i32 %xor3.i.i383, 0
  %call1.i.i.i394 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i393, i32 noundef %conv.i.i382, i32 noundef %199, i32 noundef %xor3.i.i383) #18
  %conv6.i.i395 = zext i1 %call1.i.i.i394 to i8
  %sf.i.i396 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i395, ptr %sf.i.i396, align 1
  %of.i.i397 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i397, align 1
  %af.i.i398 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i399 = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i399, ptr %af.i.i398, align 1
  store ptr %201, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %195
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 3
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i32, ptr %EDX, align 4
  %208 = zext i32 %207 to i64
  %209 = load ptr, ptr %MEMORY, align 8
  %sub.i.i274 = sub i32 %207, 2
  %cmp.i.i.i275 = icmp ult i32 %207, 2
  %call.i.i.i276 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i275, i32 noundef %207, i32 noundef 2, i32 noundef %sub.i.i274) #18
  %conv.i12.i277 = zext i1 %call.i.i.i276 to i8
  %cf.i.i278 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i277, ptr %cf.i.i278, align 1
  %conv.i.i.i.i279 = trunc i32 %sub.i.i274 to i8
  %210 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i279)
  %211 = and i8 %210, 1
  %conv.i.i.i280 = xor i8 %211, 1
  %pf.i.i.i281 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i280, ptr %pf.i.i.i281, align 1
  %xor.i.i.i.i282 = xor i32 2, %207
  %xor1.i.i.i.i283 = xor i32 %xor.i.i.i.i282, %sub.i.i274
  %212 = trunc i32 %xor1.i.i.i.i283 to i8
  %213 = lshr i8 %212, 4
  %conv2.i.i.i284 = and i8 %213, 1
  %af.i.i.i285 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i284, ptr %af.i.i.i285, align 1
  %cmp.i.i.i.i286 = icmp eq i32 %207, 2
  %call.i.i.i.i287 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i286, i32 noundef %207, i32 noundef 2, i32 noundef %sub.i.i274) #18
  %conv5.i.i.i288 = zext i1 %call.i.i.i.i287 to i8
  %zf.i.i.i289 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i288, ptr %zf.i.i.i289, align 1
  %cmp.i27.i.i.i290 = icmp slt i32 %sub.i.i274, 0
  %call1.i.i.i.i291 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i290, i32 noundef %207, i32 noundef 2, i32 noundef %sub.i.i274) #18
  %conv8.i.i.i292 = zext i1 %call1.i.i.i.i291 to i8
  %sf.i.i.i293 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i292, ptr %sf.i.i.i293, align 1
  %xor.i28.i.i.i294 = lshr i32 %xor.i.i.i.i282, 31
  %shr9.i.i.i.i295 = xor i32 %sub.i.i274, %207
  %xor3.i.i.i.i296 = lshr i32 %shr9.i.i.i.i295, 31
  %add.i.i.i.i297 = add nuw nsw i32 %xor3.i.i.i.i296, %xor.i28.i.i.i294
  %cmp.i29.i.i.i298 = icmp eq i32 %add.i.i.i.i297, 2
  %call.i30.i.i.i299 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i298, i32 noundef %207, i32 noundef 2, i32 noundef %sub.i.i274) #18
  %conv11.i.i.i300 = zext i1 %call.i30.i.i.i299 to i8
  %of.i.i.i301 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i300, ptr %of.i.i.i301, align 1
  store ptr %209, ptr %MEMORY, align 8
  br label %214

214:                                              ; preds = %204
  %215 = load i64, ptr %NEXT_PC, align 8
  store i64 %215, ptr %PC, align 8
  %216 = add i64 %215, 3
  store i64 %216, ptr %NEXT_PC, align 8
  %217 = load i32, ptr %EAX, align 4
  %218 = zext i32 %217 to i64
  %219 = load ptr, ptr %MEMORY, align 8
  %sf.i306 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %220 = load i8, ptr %sf.i306, align 1
  %tobool.i307 = icmp ne i8 %220, 0
  %of.i308 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %221 = load i8, ptr %of.i308, align 1
  %tobool4.i = icmp ne i8 %221, 0
  %cmp.i.i309 = xor i1 %tobool.i307, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i309) #19
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %218, i64 %dst.coerce.val.i
  %conv.i23.i310 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i310, ptr %RCX, align 8
  store ptr %219, ptr %MEMORY, align 8
  br label %222

222:                                              ; preds = %214
  %223 = load i64, ptr %NEXT_PC, align 8
  store i64 %223, ptr %PC, align 8
  %224 = add i64 %223, 7
  store i64 %224, ptr %NEXT_PC, align 8
  %225 = load i64, ptr %NEXT_PC, align 8
  %226 = add i64 %225, 10947
  %227 = load ptr, ptr %MEMORY, align 8
  store i64 %226, ptr %RAX, align 8
  store ptr %227, ptr %MEMORY, align 8
  br label %228

228:                                              ; preds = %222
  %229 = load i64, ptr %NEXT_PC, align 8
  store i64 %229, ptr %PC, align 8
  %230 = add i64 %229, 3
  store i64 %230, ptr %NEXT_PC, align 8
  %231 = load i32, ptr %ECX, align 4
  %232 = zext i32 %231 to i64
  %233 = load ptr, ptr %MEMORY, align 8
  %sext.i339 = shl i64 %232, 32
  %conv.i12.i340 = ashr exact i64 %sext.i339, 32
  store i64 %conv.i12.i340, ptr %RCX, align 8
  store ptr %233, ptr %MEMORY, align 8
  br label %234

234:                                              ; preds = %228
  %235 = load i64, ptr %NEXT_PC, align 8
  store i64 %235, ptr %PC, align 8
  %236 = add i64 %235, 4
  store i64 %236, ptr %NEXT_PC, align 8
  %237 = load i64, ptr %RAX, align 8
  %238 = load i64, ptr %RCX, align 8
  %239 = mul i64 %238, 8
  %240 = add i64 %237, %239
  %241 = load ptr, ptr %MEMORY, align 8
  %call.i.i337 = call i64 @__remill_read_memory_64(ptr noundef %241, i64 noundef %240) #18
  store i64 %call.i.i337, ptr %RAX, align 8
  store ptr %241, ptr %MEMORY, align 8
  br label %242

242:                                              ; preds = %234
  %243 = load i64, ptr %NEXT_PC, align 8
  store i64 %243, ptr %PC, align 8
  %244 = add i64 %243, 2
  store i64 %244, ptr %NEXT_PC, align 8
  %245 = load i64, ptr %RCX, align 8
  %246 = load i32, ptr %ECX, align 4
  %247 = zext i32 %246 to i64
  %248 = load ptr, ptr %MEMORY, align 8
  %conv.i.i365 = trunc i64 %245 to i32
  %xor3.i.i = xor i32 %246, %conv.i.i365
  %conv.i27.i366 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i366, ptr %RCX, align 8
  %cf.i.i367 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i367, align 1
  %conv.i.i.i368 = trunc i32 %xor3.i.i to i8
  %249 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i368)
  %250 = and i8 %249, 1
  %conv.i28.i369 = xor i8 %250, 1
  %pf.i.i370 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i369, ptr %pf.i.i370, align 1
  %cmp.i.i.i371 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i372 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i371, i32 noundef %conv.i.i365, i32 noundef %246, i32 noundef %xor3.i.i) #18
  %conv3.i.i373 = zext i1 %call.i.i.i372 to i8
  %zf.i.i374 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i373, ptr %zf.i.i374, align 1
  %cmp.i19.i.i375 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i376 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i375, i32 noundef %conv.i.i365, i32 noundef %246, i32 noundef %xor3.i.i) #18
  %conv6.i.i377 = zext i1 %call1.i.i.i376 to i8
  %sf.i.i378 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i377, ptr %sf.i.i378, align 1
  %of.i.i379 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i379, align 1
  %af.i.i380 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i381 = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i381, ptr %af.i.i380, align 1
  store ptr %248, ptr %MEMORY, align 8
  br label %251

251:                                              ; preds = %242
  %252 = load i64, ptr %NEXT_PC, align 8
  store i64 %252, ptr %PC, align 8
  %253 = add i64 %252, 3
  store i64 %253, ptr %NEXT_PC, align 8
  %254 = load i32, ptr %EDX, align 4
  %255 = zext i32 %254 to i64
  %256 = load ptr, ptr %MEMORY, align 8
  %sub.i.i246 = sub i32 %254, 2
  %cmp.i.i.i247 = icmp ult i32 %254, 2
  %call.i.i.i248 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i247, i32 noundef %254, i32 noundef 2, i32 noundef %sub.i.i246) #18
  %conv.i12.i249 = zext i1 %call.i.i.i248 to i8
  %cf.i.i250 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i249, ptr %cf.i.i250, align 1
  %conv.i.i.i.i251 = trunc i32 %sub.i.i246 to i8
  %257 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i251)
  %258 = and i8 %257, 1
  %conv.i.i.i252 = xor i8 %258, 1
  %pf.i.i.i253 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i252, ptr %pf.i.i.i253, align 1
  %xor.i.i.i.i254 = xor i32 2, %254
  %xor1.i.i.i.i255 = xor i32 %xor.i.i.i.i254, %sub.i.i246
  %259 = trunc i32 %xor1.i.i.i.i255 to i8
  %260 = lshr i8 %259, 4
  %conv2.i.i.i256 = and i8 %260, 1
  %af.i.i.i257 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i256, ptr %af.i.i.i257, align 1
  %cmp.i.i.i.i258 = icmp eq i32 %254, 2
  %call.i.i.i.i259 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i258, i32 noundef %254, i32 noundef 2, i32 noundef %sub.i.i246) #18
  %conv5.i.i.i260 = zext i1 %call.i.i.i.i259 to i8
  %zf.i.i.i261 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i260, ptr %zf.i.i.i261, align 1
  %cmp.i27.i.i.i262 = icmp slt i32 %sub.i.i246, 0
  %call1.i.i.i.i263 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i262, i32 noundef %254, i32 noundef 2, i32 noundef %sub.i.i246) #18
  %conv8.i.i.i264 = zext i1 %call1.i.i.i.i263 to i8
  %sf.i.i.i265 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i264, ptr %sf.i.i.i265, align 1
  %xor.i28.i.i.i266 = lshr i32 %xor.i.i.i.i254, 31
  %shr9.i.i.i.i267 = xor i32 %sub.i.i246, %254
  %xor3.i.i.i.i268 = lshr i32 %shr9.i.i.i.i267, 31
  %add.i.i.i.i269 = add nuw nsw i32 %xor3.i.i.i.i268, %xor.i28.i.i.i266
  %cmp.i29.i.i.i270 = icmp eq i32 %add.i.i.i.i269, 2
  %call.i30.i.i.i271 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i270, i32 noundef %254, i32 noundef 2, i32 noundef %sub.i.i246) #18
  %conv11.i.i.i272 = zext i1 %call.i30.i.i.i271 to i8
  %of.i.i.i273 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i272, ptr %of.i.i.i273, align 1
  store ptr %256, ptr %MEMORY, align 8
  br label %261

261:                                              ; preds = %251
  %262 = load i64, ptr %NEXT_PC, align 8
  store i64 %262, ptr %PC, align 8
  %263 = add i64 %262, 4
  store i64 %263, ptr %NEXT_PC, align 8
  %264 = load i64, ptr %RCX, align 8
  %265 = load ptr, ptr %MEMORY, align 8
  %sf.i311 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %266 = load i8, ptr %sf.i311, align 1
  %tobool.i312 = icmp ne i8 %266, 0
  %of.i313 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %267 = load i8, ptr %of.i313, align 1
  %tobool4.i314 = icmp ne i8 %267, 0
  %cmp.i.i315 = xor i1 %tobool.i312, %tobool4.i314
  %call5.i316 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i315) #19
  %dst.coerce.val.i317 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i316, i64 %264, i64 %dst.coerce.val.i317
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %265, ptr %MEMORY, align 8
  br label %268

268:                                              ; preds = %261
  %269 = load i64, ptr %NEXT_PC, align 8
  store i64 %269, ptr %PC, align 8
  %270 = add i64 %269, 3
  store i64 %270, ptr %NEXT_PC, align 8
  %271 = load i64, ptr %RAX, align 8
  %272 = load i64, ptr %RCX, align 8
  %273 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %271, %272
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i175 = icmp ult i64 %271, %272
  %call.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i175, i64 noundef %271, i64 noundef %272, i64 noundef %sub.i.i) #18
  %conv.i.i177 = zext i1 %call.i.i.i176 to i8
  %cf.i.i178 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i177, ptr %cf.i.i178, align 1
  %conv.i.i.i.i179 = trunc i64 %sub.i.i to i8
  %274 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i179)
  %275 = and i8 %274, 1
  %conv.i.i.i180 = xor i8 %275, 1
  %pf.i.i.i181 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i180, ptr %pf.i.i.i181, align 1
  %xor.i.i.i.i182 = xor i64 %272, %271
  %xor1.i.i.i.i183 = xor i64 %xor.i.i.i.i182, %sub.i.i
  %276 = trunc i64 %xor1.i.i.i.i183 to i8
  %277 = lshr i8 %276, 4
  %conv2.i.i.i184 = and i8 %277, 1
  %af.i.i.i185 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i184, ptr %af.i.i.i185, align 1
  %cmp.i.i.i.i186 = icmp eq i64 %271, %272
  %call.i.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i186, i64 noundef %271, i64 noundef %272, i64 noundef %sub.i.i) #18
  %conv5.i.i.i188 = zext i1 %call.i.i.i.i187 to i8
  %zf.i.i.i189 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i188, ptr %zf.i.i.i189, align 1
  %cmp.i27.i.i.i190 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i191 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i190, i64 noundef %271, i64 noundef %272, i64 noundef %sub.i.i) #18
  %conv8.i.i.i192 = zext i1 %call1.i.i.i.i191 to i8
  %sf.i.i.i193 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i192, ptr %sf.i.i.i193, align 1
  %xor.i28.i.i.i194 = lshr i64 %xor.i.i.i.i182, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %271
  %xor3.i.i.i.i195 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i196 = add nuw nsw i64 %xor3.i.i.i.i195, %xor.i28.i.i.i194
  %cmp.i29.i.i.i197 = icmp eq i64 %add.i.i.i.i196, 2
  %call.i30.i.i.i198 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i197, i64 noundef %271, i64 noundef %272, i64 noundef %sub.i.i) #18
  %conv11.i.i.i199 = zext i1 %call.i30.i.i.i198 to i8
  %of.i.i.i200 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i199, ptr %of.i.i.i200, align 1
  store ptr %273, ptr %MEMORY, align 8
  br label %278

278:                                              ; preds = %268
  %279 = load i64, ptr %NEXT_PC, align 8
  store i64 %279, ptr %PC, align 8
  %280 = add i64 %279, 4
  store i64 %280, ptr %NEXT_PC, align 8
  %281 = load i64, ptr %RBP, align 8
  %282 = sub i64 %281, 24
  %283 = load i64, ptr %RAX, align 8
  %284 = load ptr, ptr %MEMORY, align 8
  %call.i.i322 = call ptr @__remill_write_memory_64(ptr noundef %284, i64 noundef %282, i64 noundef %283) #18
  store ptr %call.i.i322, ptr %MEMORY, align 8
  br label %285

285:                                              ; preds = %278
  %286 = load i64, ptr %NEXT_PC, align 8
  store i64 %286, ptr %PC, align 8
  %287 = add i64 %286, 7
  store i64 %287, ptr %NEXT_PC, align 8
  %288 = load i64, ptr %NEXT_PC, align 8
  %289 = add i64 %288, 10733
  %290 = load ptr, ptr %MEMORY, align 8
  %call.i.i336 = call i64 @__remill_read_memory_64(ptr noundef %290, i64 noundef %289) #18
  store i64 %call.i.i336, ptr %RAX, align 8
  store ptr %290, ptr %MEMORY, align 8
  br label %291

291:                                              ; preds = %285
  %292 = load i64, ptr %NEXT_PC, align 8
  store i64 %292, ptr %PC, align 8
  %293 = add i64 %292, 2
  store i64 %293, ptr %NEXT_PC, align 8
  %294 = load i64, ptr %RAX, align 8
  %295 = load ptr, ptr %MEMORY, align 8
  %call.i.i329 = call i32 @__remill_read_memory_32(ptr noundef %295, i64 noundef %294) #18
  %conv.i.i330 = zext i32 %call.i.i329 to i64
  store i64 %conv.i.i330, ptr %RDX, align 8
  store ptr %295, ptr %MEMORY, align 8
  br label %296

296:                                              ; preds = %291
  %297 = load i64, ptr %NEXT_PC, align 8
  store i64 %297, ptr %PC, align 8
  %298 = add i64 %297, 7
  store i64 %298, ptr %NEXT_PC, align 8
  %299 = load i64, ptr %NEXT_PC, align 8
  %300 = add i64 %299, 10532
  %301 = load ptr, ptr %MEMORY, align 8
  %call.i.i335 = call i64 @__remill_read_memory_64(ptr noundef %301, i64 noundef %300) #18
  store i64 %call.i.i335, ptr %RAX, align 8
  store ptr %301, ptr %MEMORY, align 8
  br label %302

302:                                              ; preds = %296
  %303 = load i64, ptr %NEXT_PC, align 8
  store i64 %303, ptr %PC, align 8
  %304 = add i64 %303, 3
  store i64 %304, ptr %NEXT_PC, align 8
  %305 = load i64, ptr %RAX, align 8
  %306 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %306, i64 noundef %305) #18
  %sub.i.i201 = sub i32 %call.i.i, 10
  %cmp.i.i.i202 = icmp ult i32 %call.i.i, 10
  %call.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i202, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i201) #18
  %conv.i9.i = zext i1 %call.i.i.i203 to i8
  %cf.i.i204 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i204, align 1
  %conv.i.i.i.i205 = trunc i32 %sub.i.i201 to i8
  %307 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i205)
  %308 = and i8 %307, 1
  %conv.i.i.i206 = xor i8 %308, 1
  %pf.i.i.i207 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i206, ptr %pf.i.i.i207, align 1
  %xor.i.i.i.i208 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i209 = xor i32 %xor.i.i.i.i208, %sub.i.i201
  %309 = trunc i32 %xor1.i.i.i.i209 to i8
  %310 = lshr i8 %309, 4
  %conv2.i.i.i210 = and i8 %310, 1
  %af.i.i.i211 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i210, ptr %af.i.i.i211, align 1
  %cmp.i.i.i.i212 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i213 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i212, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i201) #18
  %conv5.i.i.i214 = zext i1 %call.i.i.i.i213 to i8
  %zf.i.i.i215 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i214, ptr %zf.i.i.i215, align 1
  %cmp.i27.i.i.i216 = icmp slt i32 %sub.i.i201, 0
  %call1.i.i.i.i217 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i216, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i201) #18
  %conv8.i.i.i218 = zext i1 %call1.i.i.i.i217 to i8
  %sf.i.i.i219 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i218, ptr %sf.i.i.i219, align 1
  %xor.i28.i.i.i220 = lshr i32 %xor.i.i.i.i208, 31
  %shr9.i.i.i.i221 = xor i32 %sub.i.i201, %call.i.i
  %xor3.i.i.i.i222 = lshr i32 %shr9.i.i.i.i221, 31
  %add.i.i.i.i223 = add nuw nsw i32 %xor3.i.i.i.i222, %xor.i28.i.i.i220
  %cmp.i29.i.i.i224 = icmp eq i32 %add.i.i.i.i223, 2
  %call.i30.i.i.i225 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i224, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i201) #18
  %conv11.i.i.i226 = zext i1 %call.i30.i.i.i225 to i8
  %of.i.i.i227 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i226, ptr %of.i.i.i227, align 1
  store ptr %306, ptr %MEMORY, align 8
  br label %311

311:                                              ; preds = %302
  %312 = load i64, ptr %NEXT_PC, align 8
  store i64 %312, ptr %PC, align 8
  %313 = add i64 %312, 3
  store i64 %313, ptr %NEXT_PC, align 8
  %314 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %315 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %315, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %316 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %316, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %314, ptr %MEMORY, align 8
  br label %317

317:                                              ; preds = %311
  %318 = load i64, ptr %NEXT_PC, align 8
  store i64 %318, ptr %PC, align 8
  %319 = add i64 %318, 2
  store i64 %319, ptr %NEXT_PC, align 8
  %320 = load i32, ptr %EDX, align 4
  %321 = zext i32 %320 to i64
  %322 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %321, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %322, ptr %MEMORY, align 8
  br label %323

323:                                              ; preds = %317
  %324 = load i64, ptr %NEXT_PC, align 8
  store i64 %324, ptr %PC, align 8
  %325 = add i64 %324, 3
  store i64 %325, ptr %NEXT_PC, align 8
  %326 = load i64, ptr %RCX, align 8
  %327 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %326 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %328 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %328, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %329 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %330 = and i8 %329, 1
  %conv.i.i.i = xor i8 %330, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %331 = trunc i32 %xor1.i.i.i.i to i8
  %332 = lshr i8 %331, 4
  %conv2.i.i.i = and i8 %332, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %327, ptr %MEMORY, align 8
  br label %333

333:                                              ; preds = %323
  %334 = load i64, ptr %NEXT_PC, align 8
  store i64 %334, ptr %PC, align 8
  %335 = add i64 %334, 3
  store i64 %335, ptr %NEXT_PC, align 8
  %336 = load i64, ptr %RCX, align 8
  %337 = load i32, ptr %EDX, align 4
  %338 = zext i32 %337 to i64
  %339 = load ptr, ptr %MEMORY, align 8
  %conv.i.i302 = trunc i64 %336 to i32
  %sext.i = shl i64 %336, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %338, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %340 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i303 = icmp ult i64 %340, -4294967296
  %call.i.i.i304 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i303, i32 noundef %conv.i.i302, i32 noundef %337, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i304 to i8
  %cf.i.i305 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i305, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %339, ptr %MEMORY, align 8
  br label %341

341:                                              ; preds = %333
  %342 = load i64, ptr %NEXT_PC, align 8
  store i64 %342, ptr %PC, align 8
  %343 = add i64 %342, 3
  store i64 %343, ptr %NEXT_PC, align 8
  %344 = load i64, ptr %RCX, align 8
  %345 = load ptr, ptr %MEMORY, align 8
  %conv.i.i341 = trunc i64 %344 to i32
  %and3.i.i = and i32 1, %conv.i.i341
  %conv.i22.i342 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i342, ptr %RCX, align 8
  %cf.i.i343 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i343, align 1
  %conv.i.i.i344 = trunc i32 %and3.i.i to i8
  %346 = and i8 %conv.i.i.i344, 1
  %conv.i23.i345 = xor i8 %346, 1
  %pf.i.i346 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i345, ptr %pf.i.i346, align 1
  %cmp.i.i.i347 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i348 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i347, i32 noundef %conv.i.i341, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i348 to i8
  %zf.i.i349 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i349, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i341, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i350 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i350, align 1
  %of.i.i351 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i351, align 1
  %af.i.i352 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i352, align 1
  store ptr %345, ptr %MEMORY, align 8
  br label %347

347:                                              ; preds = %341
  %348 = load i64, ptr %NEXT_PC, align 8
  store i64 %348, ptr %PC, align 8
  %349 = add i64 %348, 3
  store i64 %349, ptr %NEXT_PC, align 8
  %350 = load i32, ptr %ECX, align 4
  %351 = zext i32 %350 to i64
  %352 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i228 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %350, i32 noundef 0, i32 noundef %350) #18
  %conv.i12.i = zext i1 %call.i.i.i228 to i8
  %cf.i.i229 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i229, align 1
  %conv.i.i.i.i230 = trunc i32 %350 to i8
  %353 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i230)
  %354 = and i8 %353, 1
  %conv.i.i.i231 = xor i8 %354, 1
  %pf.i.i.i232 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i231, ptr %pf.i.i.i232, align 1
  %af.i.i.i233 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i233, align 1
  %cmp.i.i.i.i234 = icmp eq i32 %350, 0
  %call.i.i.i.i235 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i234, i32 noundef %350, i32 noundef 0, i32 noundef %350) #18
  %conv5.i.i.i236 = zext i1 %call.i.i.i.i235 to i8
  %zf.i.i.i237 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i236, ptr %zf.i.i.i237, align 1
  %cmp.i27.i.i.i238 = icmp slt i32 %350, 0
  %call1.i.i.i.i239 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i238, i32 noundef %350, i32 noundef 0, i32 noundef %350) #18
  %conv8.i.i.i240 = zext i1 %call1.i.i.i.i239 to i8
  %sf.i.i.i241 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i240, ptr %sf.i.i.i241, align 1
  %xor.i28.i.i.i242 = lshr i32 %350, 31
  %call.i30.i.i.i243 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %350, i32 noundef 0, i32 noundef %350) #18
  %conv11.i.i.i244 = zext i1 %call.i30.i.i.i243 to i8
  %of.i.i.i245 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i244, ptr %of.i.i.i245, align 1
  store ptr %352, ptr %MEMORY, align 8
  br label %355

355:                                              ; preds = %347
  %356 = load i64, ptr %NEXT_PC, align 8
  store i64 %356, ptr %PC, align 8
  %357 = add i64 %356, 3
  store i64 %357, ptr %NEXT_PC, align 8
  %358 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %359 = load i8, ptr %zf.i, align 1
  store i8 %359, ptr %CL, align 1
  store ptr %358, ptr %MEMORY, align 8
  br label %360

360:                                              ; preds = %355
  %361 = load i64, ptr %NEXT_PC, align 8
  store i64 %361, ptr %PC, align 8
  %362 = add i64 %361, 2
  store i64 %362, ptr %NEXT_PC, align 8
  %363 = load i8, ptr %AL, align 1
  %364 = zext i8 %363 to i64
  %365 = load i8, ptr %CL, align 1
  %366 = zext i8 %365 to i64
  %367 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %366, %364
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i353 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i353, align 1
  %368 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %369 = and i8 %368, 1
  %conv.i27.i = xor i8 %369, 1
  %pf.i.i354 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i354, align 1
  %370 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i355 = and i32 %370, 255
  %cmp.i.i.i356 = icmp eq i8 %or3.i.i, 0
  %371 = trunc i64 %364 to i32
  %conv1.i.i.i = and i32 %371, 255
  %372 = trunc i64 %366 to i32
  %conv2.i.i.i357 = and i32 %372, 255
  %call.i.i.i358 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i356, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i357, i32 noundef %conv.i.i.i355) #18
  %conv3.i.i359 = zext i1 %call.i.i.i358 to i8
  %zf.i.i360 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i359, ptr %zf.i.i360, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i357, i32 noundef %conv.i.i.i355) #18
  %conv6.i.i361 = zext i1 %call4.i.i.i to i8
  %sf.i.i362 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i361, ptr %sf.i.i362, align 1
  %of.i.i363 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i363, align 1
  %af.i.i364 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i364, align 1
  store ptr %367, ptr %MEMORY, align 8
  br label %373

373:                                              ; preds = %360
  %374 = load i64, ptr %NEXT_PC, align 8
  store i64 %374, ptr %PC, align 8
  %375 = add i64 %374, 2
  store i64 %375, ptr %NEXT_PC, align 8
  %376 = load i8, ptr %AL, align 1
  %377 = zext i8 %376 to i64
  %378 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %377
  %and3.i.i400 = trunc i64 %and3.i15.i to i8
  %cf.i.i401 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i401, align 1
  %379 = and i8 %and3.i.i400, 1
  %conv.i14.i = xor i8 %379, 1
  %pf.i.i402 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i402, align 1
  %380 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i403 = and i32 %380, 255
  %cmp.i.i.i404 = icmp eq i8 %and3.i.i400, 0
  %381 = trunc i64 %377 to i32
  %conv1.i.i.i405 = and i32 %381, 255
  %call.i.i.i406 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i404, i32 noundef %conv1.i.i.i405, i32 noundef 1, i32 noundef %conv.i.i.i403) #18
  %conv3.i.i407 = zext i1 %call.i.i.i406 to i8
  %zf.i.i408 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i407, ptr %zf.i.i408, align 1
  %call4.i.i.i409 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i405, i32 noundef 1, i32 noundef %conv.i.i.i403) #18
  %conv6.i.i410 = zext i1 %call4.i.i.i409 to i8
  %sf.i.i411 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i410, ptr %sf.i.i411, align 1
  %of.i.i412 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i412, align 1
  %af.i.i413 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i413, align 1
  store ptr %378, ptr %MEMORY, align 8
  br label %382

382:                                              ; preds = %373
  %383 = load i64, ptr %NEXT_PC, align 8
  store i64 %383, ptr %PC, align 8
  %384 = add i64 %383, 6
  store i64 %384, ptr %NEXT_PC, align 8
  %385 = load i64, ptr %NEXT_PC, align 8
  %386 = add i64 %385, 5
  %387 = load i64, ptr %NEXT_PC, align 8
  %388 = load ptr, ptr %MEMORY, align 8
  %zf.i318 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %389 = load i8, ptr %zf.i318, align 1
  %tobool.not.i = icmp eq i8 %389, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i319 = select i1 %call9.i, i64 %386, i64 %387
  store i64 %cond1.i.i319, ptr %NEXT_PC, align 8
  store ptr %388, ptr %MEMORY, align 8
  %390 = load i64, ptr %NEXT_PC, align 8
  store i64 %390, ptr %PC, align 8
  %391 = load ptr, ptr %MEMORY, align 8
  ret ptr %391
}

define ptr @BB_15fa(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1600(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10697
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10496
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_168b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10526
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10509
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1636(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i75 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i75, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 1) #18
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10809
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i74, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  store i64 %21, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #18
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %21 to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %21, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %21, i64 noundef 0, i64 noundef %21) #18
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %21, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %21, i64 noundef 0, i64 noundef %21) #18
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %21, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #18
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %18
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 4
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 72
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_64(ptr noundef %31, i64 noundef %29, i64 noundef %30) #18
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %25
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 10610
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #18
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 2
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #18
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RDX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %38
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 7
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %NEXT_PC, align 8
  %47 = add i64 %46, 10409
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %48, i64 noundef %47) #18
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %53, i64 noundef %52) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %54 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %55 = and i8 %54, 1
  %conv.i.i.i24 = xor i8 %55, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %56 = trunc i32 %xor1.i.i.i.i27 to i8
  %57 = lshr i8 %56, 4
  %conv2.i.i.i28 = and i8 %57, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %53, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %49
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 2
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %68, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RCX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %73 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %75 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %75, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %76 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %77 = and i8 %76, 1
  %conv.i.i.i = xor i8 %77, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %78 = trunc i32 %xor1.i.i.i.i to i8
  %79 = lshr i8 %78, 4
  %conv2.i.i.i = and i8 %79, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %70
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RCX, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %83 to i32
  %sext.i = shl i64 %83, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %85, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %87 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %87, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %84, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %80
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %conv.i.i76 = trunc i64 %91 to i32
  %and3.i.i = and i32 1, %conv.i.i76
  %conv.i22.i77 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i77, ptr %RCX, align 8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %conv.i.i.i79 = trunc i32 %and3.i.i to i8
  %93 = and i8 %conv.i.i.i79, 1
  %conv.i23.i80 = xor i8 %93, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i80, ptr %pf.i.i81, align 1
  %cmp.i.i.i82 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i82, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i83 to i8
  %zf.i.i84 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i84, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i85 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i85, align 1
  %of.i.i86 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i86, align 1
  %af.i.i87 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i87, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i32, ptr %ECX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #18
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %97 to i8
  %100 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %101 = and i8 %100, 1
  %conv.i.i.i48 = xor i8 %101, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %97, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %97, i32 noundef 0, i32 noundef %97) #18
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %97, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %97, i32 noundef 0, i32 noundef %97) #18
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %97, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #18
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %94
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 3
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %106 = load i8, ptr %zf.i, align 1
  store i8 %106, ptr %CL, align 1
  store ptr %105, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %102
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 2
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i8, ptr %AL, align 1
  %111 = zext i8 %110 to i64
  %112 = load i8, ptr %CL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %113, %111
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i88 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i88, align 1
  %115 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %116 = and i8 %115, 1
  %conv.i27.i = xor i8 %116, 1
  %pf.i.i89 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i89, align 1
  %117 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i90 = and i32 %117, 255
  %cmp.i.i.i91 = icmp eq i8 %or3.i.i, 0
  %118 = trunc i64 %111 to i32
  %conv1.i.i.i = and i32 %118, 255
  %119 = trunc i64 %113 to i32
  %conv2.i.i.i92 = and i32 %119, 255
  %call.i.i.i93 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i91, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #18
  %conv3.i.i94 = zext i1 %call.i.i.i93 to i8
  %zf.i.i95 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i94, ptr %zf.i.i95, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #18
  %conv6.i.i96 = zext i1 %call4.i.i.i to i8
  %sf.i.i97 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i96, ptr %sf.i.i97, align 1
  %of.i.i98 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i98, align 1
  %af.i.i99 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i99, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %107
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 2
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i8, ptr %AL, align 1
  %124 = zext i8 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %124
  %and3.i.i100 = trunc i64 %and3.i15.i to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i101, align 1
  %126 = and i8 %and3.i.i100, 1
  %conv.i14.i = xor i8 %126, 1
  %pf.i.i102 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i102, align 1
  %127 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i103 = and i32 %127, 255
  %cmp.i.i.i104 = icmp eq i8 %and3.i.i100, 0
  %128 = trunc i64 %124 to i32
  %conv1.i.i.i105 = and i32 %128, 255
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i104, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #18
  %conv3.i.i107 = zext i1 %call.i.i.i106 to i8
  %zf.i.i108 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i107, ptr %zf.i.i108, align 1
  %call4.i.i.i109 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #18
  %conv6.i.i110 = zext i1 %call4.i.i.i109 to i8
  %sf.i.i111 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i110, ptr %sf.i.i111, align 1
  %of.i.i112 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i112, align 1
  %af.i.i113 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i113, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %120
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 6
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %NEXT_PC, align 8
  %133 = add i64 %132, 5
  %134 = load i64, ptr %NEXT_PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %136 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %136, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %133, i64 %134
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %135, ptr %MEMORY, align 8
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  ret ptr %138
}

define ptr @BB_16c1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i1, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = sub i64 %10, 1658
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %14, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i, i64 noundef %12) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store i64 %12, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  ret ptr %15
}

define ptr @BB_1685(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_time(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_time(ptr, i64, ptr) #2

define ptr @BB_175f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10218
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10273
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_16ca(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EAX, align 4
  %5 = zext i32 %4 to i64
  %6 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %5, 4294967295
  store i64 %conv.i11.i, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = sub i64 %10, 1681
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %14, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i, i64 noundef %12) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store i64 %12, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  ret ptr %15
}

define ptr @BB_1795(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i56 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i56, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i53 = zext i32 %call.i.i52 to i64
  store i64 %conv.i.i53, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 84
  %17 = load i32, ptr %EAX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_32(ptr noundef %19, i64 noundef %16, i32 noundef %17) #18
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %12
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 7
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = add i64 %23, 10147
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i55 = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %24) #18
  store i64 %call.i.i55, ptr %RAX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RAX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #18
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 10226
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %36, i64 noundef %35) #18
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %41, i64 noundef %40) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %43 = and i8 %42, 1
  %conv.i.i.i5 = xor i8 %43, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %44 = trunc i32 %xor1.i.i.i.i8 to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i9 = and i8 %45, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %41, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %37
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %50 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %50, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %51 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %51, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EDX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %56, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RCX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %61 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %63 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %63, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %64 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %65 = and i8 %64, 1
  %conv.i.i.i = xor i8 %65, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %66 = trunc i32 %xor1.i.i.i.i to i8
  %67 = lshr i8 %66, 4
  %conv2.i.i.i = and i8 %67, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RCX, align 8
  %72 = load i32, ptr %EDX, align 4
  %73 = zext i32 %72 to i64
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %71 to i32
  %sext.i = shl i64 %71, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %73, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %75 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %75, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %72, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %68
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %conv.i.i57 = trunc i64 %79 to i32
  %and3.i.i = and i32 1, %conv.i.i57
  %conv.i22.i58 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i58, ptr %RCX, align 8
  %cf.i.i59 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i59, align 1
  %conv.i.i.i60 = trunc i32 %and3.i.i to i8
  %81 = and i8 %conv.i.i.i60, 1
  %conv.i23.i61 = xor i8 %81, 1
  %pf.i.i62 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i61, ptr %pf.i.i62, align 1
  %cmp.i.i.i63 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i63, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i64 to i8
  %zf.i.i65 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i65, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i66 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i66, align 1
  %of.i.i67 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i67, align 1
  %af.i.i68 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i68, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %85 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %89 = and i8 %88, 1
  %conv.i.i.i29 = xor i8 %89, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %85, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %85, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %85, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %82
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 3
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %94 = load i8, ptr %zf.i, align 1
  store i8 %94, ptr %CL, align 1
  store ptr %93, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %90
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i8, ptr %AL, align 1
  %99 = zext i8 %98 to i64
  %100 = load i8, ptr %CL, align 1
  %101 = zext i8 %100 to i64
  %102 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %101, %99
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i69 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i69, align 1
  %103 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %104 = and i8 %103, 1
  %conv.i27.i = xor i8 %104, 1
  %pf.i.i70 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i70, align 1
  %105 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i71 = and i32 %105, 255
  %cmp.i.i.i72 = icmp eq i8 %or3.i.i, 0
  %106 = trunc i64 %99 to i32
  %conv1.i.i.i = and i32 %106, 255
  %107 = trunc i64 %101 to i32
  %conv2.i.i.i73 = and i32 %107, 255
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i72, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #18
  %conv3.i.i75 = zext i1 %call.i.i.i74 to i8
  %zf.i.i76 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i75, ptr %zf.i.i76, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #18
  %conv6.i.i77 = zext i1 %call4.i.i.i to i8
  %sf.i.i78 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i77, ptr %sf.i.i78, align 1
  %of.i.i79 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i79, align 1
  %af.i.i80 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i80, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %95
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 2
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i8, ptr %AL, align 1
  %112 = zext i8 %111 to i64
  %113 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %112
  %and3.i.i81 = trunc i64 %and3.i15.i to i8
  %cf.i.i82 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i82, align 1
  %114 = and i8 %and3.i.i81, 1
  %conv.i14.i = xor i8 %114, 1
  %pf.i.i83 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i83, align 1
  %115 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i84 = and i32 %115, 255
  %cmp.i.i.i85 = icmp eq i8 %and3.i.i81, 0
  %116 = trunc i64 %112 to i32
  %conv1.i.i.i86 = and i32 %116, 255
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i85, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #18
  %conv3.i.i88 = zext i1 %call.i.i.i87 to i8
  %zf.i.i89 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i88, ptr %zf.i.i89, align 1
  %call4.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #18
  %conv6.i.i91 = zext i1 %call4.i.i.i90 to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i91, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i94, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %108
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 6
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  %121 = add i64 %120, 5
  %122 = load i64, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %124, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %121, i64 %122
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %123, ptr %MEMORY, align 8
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  ret ptr %126
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_srand(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_srand(ptr, i64, ptr) #4

define ptr @BB_17d4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 84
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #18
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %16, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #18
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %12
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #18
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %22, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %20, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

define ptr @BB_16d1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i9 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i9, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 40
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i8 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #18
  store i64 %call.i.i8, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i7 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i7, ptr %RCX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RCX, align 8
  %22 = add i64 %21, 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %22) #18
  store i64 %call.i.i6, ptr %RCX, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %18
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RCX, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i10 = call zeroext i8 @__remill_read_memory_8(ptr noundef %28, i64 noundef %27) #18
  %conv.i.i11 = sext i8 %call.i.i10 to i64
  %conv.i10.i = and i64 %conv.i.i11, 4294967295
  store i64 %conv.i10.i, ptr %RCX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load i32, ptr %ECX, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_32(ptr noundef %35, i64 noundef %32, i32 noundef %33) #18
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 2
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RAX, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i32 @__remill_read_memory_32(ptr noundef %40, i64 noundef %39) #18
  %conv.i.i4 = zext i32 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RDI, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %36
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 7
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %NEXT_PC, align 8
  %45 = add i64 %44, 10578
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %46, i64 noundef %45) #18
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 6
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %50, 1718175621
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %50, 1718175621
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %50, i64 noundef 1718175621, i64 noundef %sub.i.i) #18
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %52 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %53 = and i8 %52, 1
  %conv.i.i.i = xor i8 %53, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 1718175621, %50
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %54 = trunc i64 %xor1.i.i.i.i to i8
  %55 = lshr i8 %54, 4
  %conv2.i.i.i = and i8 %55, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %50, 1718175621
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %50, i64 noundef 1718175621, i64 noundef %sub.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %50, i64 noundef 1718175621, i64 noundef %sub.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %50
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %50, i64 noundef 1718175621, i64 noundef %sub.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %51, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %47
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load i64, ptr %NEXT_PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %62 = load i64, ptr %rsp.i, align 8
  %sub.i.i1 = add i64 %62, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %61, i64 noundef %sub.i.i1, i64 noundef %60) #18
  store i64 %sub.i.i1, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %59, ptr %rip.i, align 8
  store i64 %59, ptr %NEXT_PC, align 8
  store i64 %60, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  ret ptr %63
}

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #5 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_fib(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_fib(ptr, i64, ptr) #5

define ptr @BB_16f6(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i6, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %11, 4294967295
  store i64 %conv.i11.i, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 32
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #18
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load i32, ptr %EDX, align 4
  %24 = zext i32 %23 to i64
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %25, i64 noundef %22, i32 noundef %23) #18
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %19
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RCX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #18
  %conv.i.i4 = zext i32 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RSI, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 2
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %RAX, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %35, i64 noundef %34) #18
  %conv.i.i = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i, ptr %RDX, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %31
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 2291
  %41 = load ptr, ptr %MEMORY, align 8
  store i64 %40, ptr %RDI, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %42
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 5
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %NEXT_PC, align 8
  %50 = sub i64 %49, 1764
  %51 = load i64, ptr %NEXT_PC, align 8
  %52 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %53 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %53, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %52, i64 noundef %sub.i.i, i64 noundef %51) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %50, ptr %rip.i, align 8
  store i64 %50, ptr %NEXT_PC, align 8
  store i64 %51, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  ret ptr %54
}

define ptr @BB_ffff000000000003_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #6 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !32)
  %rsp.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !35)
  %rip.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !38)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #6

define ptr @BB_1714(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10597
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 80
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #18
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 10262
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #18
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #18
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 10341
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #18
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #18
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #18
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #18
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #18
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_1759(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.254476, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #7 {
entry:
  %agg.tmp = alloca %struct.State.254476, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.254476) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #20
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #8

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.254476) align 16, i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rip = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rax = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rax = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rip = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #12 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 5360, label %bb_14F0
    i64 5429, label %bb_1535
    i64 5626, label %bb_15FA
    i64 5632, label %bb_1600
    i64 5686, label %bb_1636
    i64 5765, label %bb_1685
    i64 5771, label %bb_168B
    i64 5825, label %bb_16C1
    i64 5834, label %bb_16CA
    i64 5841, label %bb_16D1
    i64 5878, label %bb_16F6
    i64 5908, label %bb_1714
    i64 5977, label %bb_1759
    i64 5983, label %bb_175F
    i64 6037, label %bb_1795
    i64 6100, label %bb_17D4
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
    i64 -281474976710653, label %bb_FFFF000000000003
  ]

dead_end:                                         ; preds = %bb_FFFF000000000003, %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_1795, %bb_175F, %bb_1759, %bb_1714, %bb_16F6, %bb_16D1, %bb_16CA, %bb_16C1, %bb_168B, %bb_1685, %bb_1636, %bb_1600, %bb_15FA, %bb_1535, %bb_14F0, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_14F0:                                          ; preds = %entry
  %block_pc = add i64 5360, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 5360, ptr %1)
  %4 = call ptr @BB_14f0(ptr %state, i64 %2, ptr %1) #21
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 5429, label %bb_1535
  ]

bb_1535:                                          ; preds = %bb_14F0, %entry
  %block_pc1 = add i64 5429, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 5429, ptr %6)
  %9 = call ptr @BB_1535(ptr %state, i64 %7, ptr %6) #21
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 5626, label %bb_15FA
  ]

bb_15FA:                                          ; preds = %bb_1535, %entry
  %block_pc3 = add i64 5626, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 5626, ptr %11)
  %14 = call ptr @BB_15fa(ptr %state, i64 %12, ptr %11) #21
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 5632, label %bb_1600
    i64 5771, label %bb_168B
  ]

bb_1600:                                          ; preds = %bb_15FA, %entry
  %block_pc5 = add i64 5632, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 5632, ptr %16)
  %19 = call ptr @BB_1600(ptr %state, i64 %17, ptr %16) #21
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 5686, label %bb_1636
  ]

bb_1636:                                          ; preds = %bb_1600, %entry
  %block_pc7 = add i64 5686, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 5686, ptr %21)
  %24 = call ptr @BB_1636(ptr %state, i64 %22, ptr %21) #21
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 5765, label %bb_1685
  ]

bb_1685:                                          ; preds = %bb_1636, %entry
  %block_pc9 = add i64 5765, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 5765, ptr %26)
  %29 = call ptr @BB_1685(ptr %state, i64 %27, ptr %26) #21
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 5983, label %bb_175F
  ]

bb_168B:                                          ; preds = %bb_15FA, %entry
  %block_pc11 = add i64 5771, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 5771, ptr %31)
  %34 = call ptr @BB_168b(ptr %state, i64 %32, ptr %31) #21
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 5825, label %bb_16C1
  ]

bb_16C1:                                          ; preds = %bb_168B, %entry
  %block_pc13 = add i64 5825, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 5825, ptr %36)
  %39 = call ptr @BB_16c1(ptr %state, i64 %37, ptr %36) #21
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4176, label %bb_FFFF000000000000
  ]

bb_16CA:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc15 = add i64 5834, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 5834, ptr %41)
  %44 = call ptr @BB_16ca(ptr %state, i64 %42, ptr %41) #21
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4160, label %bb_FFFF000000000001
  ]

bb_16D1:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc17 = add i64 5841, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 5841, ptr %46)
  %49 = call ptr @BB_16d1(ptr %state, i64 %47, ptr %46) #21
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4400, label %bb_FFFF000000000002
  ]

bb_16F6:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc19 = add i64 5878, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 5878, ptr %51)
  %54 = call ptr @BB_16f6(ptr %state, i64 %52, ptr %51) #21
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 4144, label %bb_FFFF000000000003
  ]

bb_1714:                                          ; preds = %bb_FFFF000000000003, %entry
  %block_pc21 = add i64 5908, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 5908, ptr %56)
  %59 = call ptr @BB_1714(ptr %state, i64 %57, ptr %56) #21
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 5977, label %bb_1759
  ]

bb_1759:                                          ; preds = %bb_1714, %entry
  %block_pc23 = add i64 5977, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 5977, ptr %61)
  %64 = call ptr @BB_1759(ptr %state, i64 %62, ptr %61) #21
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 5983, label %bb_175F
  ]

bb_175F:                                          ; preds = %bb_1759, %bb_1685, %entry
  %block_pc25 = add i64 5983, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 5983, ptr %66)
  %69 = call ptr @BB_175f(ptr %state, i64 %67, ptr %66) #21
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 6037, label %bb_1795
  ]

bb_1795:                                          ; preds = %bb_175F, %entry
  %block_pc27 = add i64 6037, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 6037, ptr %71)
  %74 = call ptr @BB_1795(ptr %state, i64 %72, ptr %71) #21
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 6100, label %bb_17D4
  ]

bb_17D4:                                          ; preds = %bb_1795, %entry
  %block_pc29 = add i64 6100, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 6100, ptr %76)
  %79 = call ptr @BB_17d4(ptr %state, i64 %77, ptr %76) #21
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  %81 = load ptr, ptr %mem_var, align 8
  ret ptr %81

bb_FFFF000000000000:                              ; preds = %bb_16C1, %entry
  %82 = load ptr, ptr %mem_var, align 8
  %83 = load i64, ptr %pc_var, align 4
  %84 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %83, ptr %82) #21
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva31 = sub i64 %85, %base
  switch i64 %next_rva31, label %dead_end [
    i64 5834, label %bb_16CA
  ]

bb_FFFF000000000001:                              ; preds = %bb_16CA, %entry
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %87, ptr %86) #21
  store ptr %88, ptr %mem_var, align 8
  %89 = call i64 @__extract_rip(ptr %state)
  store i64 %89, ptr %pc_var, align 4
  %next_rva32 = sub i64 %89, %base
  switch i64 %next_rva32, label %dead_end [
    i64 5841, label %bb_16D1
  ]

bb_FFFF000000000002:                              ; preds = %bb_16D1, %entry
  %90 = load ptr, ptr %mem_var, align 8
  %91 = load i64, ptr %pc_var, align 4
  %92 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %91, ptr %90) #21
  store ptr %92, ptr %mem_var, align 8
  %93 = call i64 @__extract_rip(ptr %state)
  store i64 %93, ptr %pc_var, align 4
  %next_rva33 = sub i64 %93, %base
  switch i64 %next_rva33, label %dead_end [
    i64 5878, label %bb_16F6
  ]

bb_FFFF000000000003:                              ; preds = %bb_16F6, %entry
  %94 = load ptr, ptr %mem_var, align 8
  %95 = load i64, ptr %pc_var, align 4
  %96 = call ptr @BB_ffff000000000003_ext(ptr %state, i64 %95, ptr %94) #21
  store ptr %96, ptr %mem_var, align 8
  %97 = call i64 @__extract_rip(ptr %state)
  store i64 %97, ptr %pc_var, align 4
  %next_rva34 = sub i64 %97, %base
  switch i64 %next_rva34, label %dead_end [
    i64 5908, label %bb_1714
  ]

return_bb:                                        ; No predecessors!
  %98 = load ptr, ptr %mem_var, align 8
  ret ptr %98
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #13 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 5360, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #14 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #14 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #14 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #14 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #14 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #15 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  %rip = getelementptr inbounds %struct.X86State.254475, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !41
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { "lifted.annotation_id"="5" "lifted.state_form"="folded" }
attributes #6 = { "lifted.annotation_id"="6" "lifted.state_form"="folded" }
attributes #7 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #13 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #18 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #19 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #20 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #21 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33}
!33 = distinct !{!33, !34, !"__extract_rsp: %state"}
!34 = distinct !{!34, !"__extract_rsp"}
!35 = !{!36}
!36 = distinct !{!36, !37, !"__store_rip: %state"}
!37 = distinct !{!37, !"__store_rip"}
!38 = !{!39}
!39 = distinct !{!39, !40, !"__store_rsp: %state"}
!40 = distinct !{!40, !"__store_rsp"}
!41 = !{!42, !42, i64 0}
!42 = !{!"omnipotent char", !43, i64 0}
!43 = !{!"Simple C++ TBAA"}
