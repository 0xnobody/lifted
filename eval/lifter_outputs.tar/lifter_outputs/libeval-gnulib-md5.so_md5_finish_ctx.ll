; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.32041 = type { %struct.X86State.32040 }
%struct.X86State.32040 = type { %struct.ArchState.32009, [32 x %union.VectorReg.32012], %struct.ArithFlags.32013, %union.anon.32008, %struct.Segments.32015, %struct.AddressSpace.32017, %struct.GPR.32018, %struct.X87Stack.32021, %struct.MMX.32025, %struct.FPUStatusFlags.32026, %union.anon.32008, %union.FPU.32035, %struct.SegmentCaches.32037, %struct.K_REG.32039 }
%struct.ArchState.32009 = type { i32, i32, %union.anon.32008 }
%union.VectorReg.32012 = type { %union.vec512_t.32011 }
%union.vec512_t.32011 = type { %struct.uint64v8_t.32010 }
%struct.uint64v8_t.32010 = type { [8 x i64] }
%struct.ArithFlags.32013 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.32015 = type { i16, %union.SegmentSelector.32014, i16, %union.SegmentSelector.32014, i16, %union.SegmentSelector.32014, i16, %union.SegmentSelector.32014, i16, %union.SegmentSelector.32014, i16, %union.SegmentSelector.32014 }
%union.SegmentSelector.32014 = type { i16 }
%struct.AddressSpace.32017 = type { i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016 }
%struct.Reg.32016 = type { %union.anon.32008 }
%struct.GPR.32018 = type { i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016, i64, %struct.Reg.32016 }
%struct.X87Stack.32021 = type { [8 x %struct.anon.3.32020] }
%struct.anon.3.32020 = type { [6 x i8], %struct.float80_t.32019 }
%struct.float80_t.32019 = type { [10 x i8] }
%struct.MMX.32025 = type { [8 x %struct.anon.4.32024] }
%struct.anon.4.32024 = type { i64, %union.vec64_t.32023 }
%union.vec64_t.32023 = type { %struct.uint64v1_t.32022 }
%struct.uint64v1_t.32022 = type { [1 x i64] }
%struct.FPUStatusFlags.32026 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.32008 = type { i64 }
%union.FPU.32035 = type { %struct.anon.13.32034 }
%struct.anon.13.32034 = type { %struct.FpuFXSAVE.32033, [96 x i8] }
%struct.FpuFXSAVE.32033 = type { %union.SegmentSelector.32014, %union.SegmentSelector.32014, %union.FPUAbridgedTagWord.32027, i8, i16, i32, %union.SegmentSelector.32014, i16, i32, %union.SegmentSelector.32014, i16, %union.FPUControlStatus.32028, %union.FPUControlStatus.32028, [8 x %struct.FPUStackElem.32030], [16 x %union.vec128_t.32032] }
%union.FPUAbridgedTagWord.32027 = type { i8 }
%union.FPUControlStatus.32028 = type { i32 }
%struct.FPUStackElem.32030 = type { %union.anon.11.32029, [6 x i8] }
%union.anon.11.32029 = type { %struct.float80_t.32019 }
%union.vec128_t.32032 = type { %struct.uint128v1_t.32031 }
%struct.uint128v1_t.32031 = type { [1 x i128] }
%struct.SegmentCaches.32037 = type { %struct.SegmentShadow.32036, %struct.SegmentShadow.32036, %struct.SegmentShadow.32036, %struct.SegmentShadow.32036, %struct.SegmentShadow.32036, %struct.SegmentShadow.32036 }
%struct.SegmentShadow.32036 = type { %union.anon.32008, i32, i32 }
%struct.K_REG.32039 = type { [8 x %struct.anon.18.32038] }
%struct.anon.18.32038 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_12b3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i34 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #17
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i34, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 32
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 32
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #17
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 32, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 32
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #17
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #17
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #17
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 24
  %34 = load i64, ptr %RDI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_64(ptr noundef %35, i64 noundef %33, i64 noundef %34) #17
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 4
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 32
  %41 = load i64, ptr %RSI, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_64(ptr noundef %42, i64 noundef %40, i64 noundef %41) #17
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %36
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RBP, align 8
  %47 = sub i64 %46, 24
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i64 @__remill_read_memory_64(ptr noundef %48, i64 noundef %47) #17
  store i64 %call.i.i33, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = add i64 %52, 24
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call i32 @__remill_read_memory_32(ptr noundef %54, i64 noundef %53) #17
  %conv.i.i32 = zext i32 %call.i.i31 to i64
  store i64 %conv.i.i32, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RBP, align 8
  %59 = sub i64 %58, 4
  %60 = load i32, ptr %EAX, align 4
  %61 = zext i32 %60 to i64
  %62 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call ptr @__remill_write_memory_32(ptr noundef %62, i64 noundef %59, i32 noundef %60) #17
  store ptr %call.i.i28, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %55
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 4
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %RBP, align 8
  %67 = sub i64 %66, 4
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %68, i64 noundef %67) #17
  %sub.i.i1 = sub i32 %call.i.i, 55
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, 55
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef 55, i32 noundef %sub.i.i1) #17
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %70 = and i8 %69, 1
  %conv.i.i.i6 = xor i8 %70, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, 55
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %71 = trunc i32 %xor1.i.i.i.i9 to i8
  %72 = lshr i8 %71, 4
  %conv2.i.i.i10 = and i8 %72, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, 55
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef 55, i32 noundef %sub.i.i1) #17
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef 55, i32 noundef %sub.i.i1) #17
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef 55, i32 noundef %sub.i.i1) #17
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %63
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 2
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %NEXT_PC, align 8
  %77 = add i64 %76, 7
  %78 = load i64, ptr %NEXT_PC, align 8
  %79 = load ptr, ptr %MEMORY, align 8
  %cf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  %80 = load i8, ptr %cf.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  %81 = load i8, ptr %zf.i, align 1
  %82 = or i8 %81, %80
  %.not.i = icmp eq i8 %82, 0
  %call12.i = call zeroext i1 @__remill_compare_ugt(i1 noundef zeroext %.not.i) #18
  %frombool.i = zext i1 %call12.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call12.i, i64 %77, i64 %78
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %79, ptr %MEMORY, align 8
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = load ptr, ptr %MEMORY, align 8
  ret ptr %84
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_12d7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 16, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 2
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 5
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1317(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i162 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #17
  store i64 %call.i.i162, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = add i64 %10, 16
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i152 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #17
  %conv.i.i153 = zext i32 %call.i.i152 to i64
  store i64 %conv.i.i153, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 16
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i161 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #17
  store i64 %call.i.i161, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %sub.i.i85 = sub i64 %22, 2
  store i64 %sub.i.i85, ptr %RDX, align 8
  %cmp.i.i.i86 = icmp ult i64 %22, 2
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i86, i64 noundef %22, i64 noundef 2, i64 noundef %sub.i.i85) #17
  %conv.i.i88 = zext i1 %call.i.i.i87 to i8
  %cf.i.i89 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i88, ptr %cf.i.i89, align 1
  %conv.i.i.i.i90 = trunc i64 %sub.i.i85 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i90)
  %25 = and i8 %24, 1
  %conv.i.i.i91 = xor i8 %25, 1
  %pf.i.i.i92 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i91, ptr %pf.i.i.i92, align 1
  %xor.i.i.i.i93 = xor i64 2, %22
  %xor1.i.i.i.i94 = xor i64 %xor.i.i.i.i93, %sub.i.i85
  %26 = trunc i64 %xor1.i.i.i.i94 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i95 = and i8 %27, 1
  %af.i.i.i96 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i95, ptr %af.i.i.i96, align 1
  %cmp.i.i.i.i97 = icmp eq i64 %22, 2
  %call.i.i.i.i98 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i97, i64 noundef %22, i64 noundef 2, i64 noundef %sub.i.i85) #17
  %conv5.i.i.i99 = zext i1 %call.i.i.i.i98 to i8
  %zf.i.i.i100 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i99, ptr %zf.i.i.i100, align 1
  %cmp.i27.i.i.i101 = icmp slt i64 %sub.i.i85, 0
  %call1.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i101, i64 noundef %22, i64 noundef 2, i64 noundef %sub.i.i85) #17
  %conv8.i.i.i103 = zext i1 %call1.i.i.i.i102 to i8
  %sf.i.i.i104 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i103, ptr %sf.i.i.i104, align 1
  %xor.i28.i.i.i105 = lshr i64 %xor.i.i.i.i93, 63
  %shr9.i.i.i.i106 = xor i64 %sub.i.i85, %22
  %xor3.i.i.i.i107 = lshr i64 %shr9.i.i.i.i106, 63
  %add.i.i.i.i108 = add nuw nsw i64 %xor3.i.i.i.i107, %xor.i28.i.i.i105
  %cmp.i29.i.i.i109 = icmp eq i64 %add.i.i.i.i108, 2
  %call.i30.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i109, i64 noundef %22, i64 noundef 2, i64 noundef %sub.i.i85) #17
  %conv11.i.i.i111 = zext i1 %call.i30.i.i.i110 to i8
  %of.i.i.i112 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i111, ptr %of.i.i.i112, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %19
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 7
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RAX, align 8
  %32 = mul i64 %31, 8
  %33 = add i64 0, %32
  %34 = load ptr, ptr %MEMORY, align 8
  %conv.i.i169 = and i64 %33, 4294967295
  store i64 %conv.i.i169, ptr %RCX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 24
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i160 = call i64 @__remill_read_memory_64(ptr noundef %40, i64 noundef %39) #17
  store i64 %call.i.i160, ptr %RAX, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 4
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RDX, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 4, %44
  store i64 %add.i.i1, ptr %RDX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %44
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, 4
  %46 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %46, i64 noundef %44, i64 noundef 4, i64 noundef %add.i.i1) #17
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %47 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %48 = and i8 %47, 1
  %conv.i.i.i8 = xor i8 %48, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, 4
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %44
  %49 = trunc i64 %xor1.i.i.i.i11 to i8
  %50 = lshr i8 %49, 4
  %conv2.i.i.i12 = and i8 %50, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %44, i64 noundef 4, i64 noundef %add.i.i1) #17
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %44, i64 noundef 4, i64 noundef %add.i.i1) #17
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %44
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %44, i64 noundef 4, i64 noundef %add.i.i1) #17
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %45, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %41
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 4
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RAX, align 8
  %55 = load i64, ptr %RDX, align 8
  %56 = mul i64 %55, 4
  %57 = add i64 %54, %56
  %58 = add i64 %57, 12
  %59 = load i32, ptr %ECX, align 4
  %60 = zext i32 %59 to i64
  %61 = load ptr, ptr %MEMORY, align 8
  %call.i.i143 = call ptr @__remill_write_memory_32(ptr noundef %61, i64 noundef %58, i32 noundef %59) #17
  store ptr %call.i.i143, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %51
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 4
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RBP, align 8
  %66 = sub i64 %65, 24
  %67 = load ptr, ptr %MEMORY, align 8
  %call.i.i159 = call i64 @__remill_read_memory_64(ptr noundef %67, i64 noundef %66) #17
  store i64 %call.i.i159, ptr %RAX, align 8
  store ptr %67, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RAX, align 8
  %72 = add i64 %71, 20
  %73 = load ptr, ptr %MEMORY, align 8
  %call.i.i150 = call i32 @__remill_read_memory_32(ptr noundef %73, i64 noundef %72) #17
  %conv.i.i151 = zext i32 %call.i.i150 to i64
  store i64 %conv.i.i151, ptr %RAX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 7
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RAX, align 8
  %78 = mul i64 %77, 8
  %79 = add i64 0, %78
  %80 = load ptr, ptr %MEMORY, align 8
  %conv.i.i168 = and i64 %79, 4294967295
  store i64 %conv.i.i168, ptr %RSI, align 8
  store ptr %80, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %74
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 4
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RBP, align 8
  %85 = sub i64 %84, 24
  %86 = load ptr, ptr %MEMORY, align 8
  %call.i.i158 = call i64 @__remill_read_memory_64(ptr noundef %86, i64 noundef %85) #17
  store i64 %call.i.i158, ptr %RAX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RAX, align 8
  %91 = add i64 %90, 16
  %92 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call i32 @__remill_read_memory_32(ptr noundef %92, i64 noundef %91) #17
  %conv.i.i149 = zext i32 %call.i.i148 to i64
  store i64 %conv.i.i149, ptr %RAX, align 8
  store ptr %92, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %87
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 3
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load ptr, ptr %MEMORY, align 8
  %conv.i139.i = and i64 %96, 4294967295
  %shr.i140.i = lshr i64 %conv.i139.i, 28
  %conv2.i141.i = trunc i64 %shr.i140.i to i32
  %call34.i = call zeroext i8 @__remill_undefined_8() #18
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i32 %conv2.i141.i, 1
  %conv.i147.i = zext i32 %new_val.0.i to i64
  store i64 %conv.i147.i, ptr %RAX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  %98 = trunc i32 %conv2.i141.i to i8
  %conv.i = and i8 %98, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  %conv.i148.i = trunc i32 %new_val.0.i to i8
  %99 = call i8 @llvm.ctpop.i8(i8 %conv.i148.i)
  %100 = and i8 %99, 1
  %conv67.i = xor i8 %100, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  %cmp.i149.i = icmp ult i32 %conv2.i141.i, 2
  %conv80.i = zext i1 %cmp.i149.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %97, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %93
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 2
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i32, ptr %EAX, align 4
  %105 = zext i32 %104 to i64
  %106 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %105, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %106, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %101
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 4
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i64, ptr %RBP, align 8
  %111 = sub i64 %110, 16
  %112 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %112, i64 noundef %111) #17
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %112, ptr %MEMORY, align 8
  br label %113

113:                                              ; preds = %107
  %114 = load i64, ptr %NEXT_PC, align 8
  store i64 %114, ptr %PC, align 8
  %115 = add i64 %114, 4
  store i64 %115, ptr %NEXT_PC, align 8
  %116 = load i64, ptr %RAX, align 8
  %117 = sub i64 %116, 1
  %118 = load ptr, ptr %MEMORY, align 8
  store i64 %117, ptr %RDX, align 8
  store ptr %118, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %113
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 2
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RCX, align 8
  %123 = load i32, ptr %ESI, align 4
  %124 = zext i32 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %conv.i.i163 = trunc i64 %122 to i32
  %or3.i.i = or i32 %123, %conv.i.i163
  %conv.i27.i = zext i32 %or3.i.i to i64
  store i64 %conv.i27.i, ptr %RCX, align 8
  %cf.i.i164 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i164, align 1
  %conv.i.i.i165 = trunc i32 %or3.i.i to i8
  %126 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i165)
  %127 = and i8 %126, 1
  %conv.i28.i = xor i8 %127, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i166 = icmp eq i32 %or3.i.i, 0
  %call.i.i.i167 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i166, i32 noundef %conv.i.i163, i32 noundef %123, i32 noundef %or3.i.i) #17
  %conv3.i.i = zext i1 %call.i.i.i167 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %or3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i163, i32 noundef %123, i32 noundef %or3.i.i) #17
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #18
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %119
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 4
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load i64, ptr %RBP, align 8
  %132 = sub i64 %131, 24
  %133 = load ptr, ptr %MEMORY, align 8
  %call.i.i156 = call i64 @__remill_read_memory_64(ptr noundef %133, i64 noundef %132) #17
  store i64 %call.i.i156, ptr %RAX, align 8
  store ptr %133, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %128
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 4
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RDX, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 4, %137
  store i64 %add.i.i, ptr %RDX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %137
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 4
  %139 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %139, i64 noundef %137, i64 noundef 4, i64 noundef %add.i.i) #17
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %140 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %141 = and i8 %140, 1
  %conv.i.i.i = xor i8 %141, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 4
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %137
  %142 = trunc i64 %xor1.i.i.i.i to i8
  %143 = lshr i8 %142, 4
  %conv2.i.i.i = and i8 %143, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %137, i64 noundef 4, i64 noundef %add.i.i) #17
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %137, i64 noundef 4, i64 noundef %add.i.i) #17
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %137
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %137, i64 noundef 4, i64 noundef %add.i.i) #17
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %138, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %134
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 4
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i64, ptr %RAX, align 8
  %148 = load i64, ptr %RDX, align 8
  %149 = mul i64 %148, 4
  %150 = add i64 %147, %149
  %151 = add i64 %150, 12
  %152 = load i32, ptr %ECX, align 4
  %153 = zext i32 %152 to i64
  %154 = load ptr, ptr %MEMORY, align 8
  %call.i.i142 = call ptr @__remill_write_memory_32(ptr noundef %154, i64 noundef %151, i32 noundef %152) #17
  store ptr %call.i.i142, ptr %MEMORY, align 8
  br label %155

155:                                              ; preds = %144
  %156 = load i64, ptr %NEXT_PC, align 8
  store i64 %156, ptr %PC, align 8
  %157 = add i64 %156, 4
  store i64 %157, ptr %NEXT_PC, align 8
  %158 = load i64, ptr %RBP, align 8
  %159 = sub i64 %158, 16
  %160 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i64 @__remill_read_memory_64(ptr noundef %160, i64 noundef %159) #17
  store i64 %call.i.i155, ptr %RAX, align 8
  store ptr %160, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %155
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 4
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i64, ptr %RAX, align 8
  %165 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %164, 2
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i59 = icmp ult i64 %164, 2
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i59, i64 noundef %164, i64 noundef 2, i64 noundef %sub.i.i) #17
  %conv.i.i61 = zext i1 %call.i.i.i60 to i8
  %cf.i.i62 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i61, ptr %cf.i.i62, align 1
  %conv.i.i.i.i63 = trunc i64 %sub.i.i to i8
  %166 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i63)
  %167 = and i8 %166, 1
  %conv.i.i.i64 = xor i8 %167, 1
  %pf.i.i.i65 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i64, ptr %pf.i.i.i65, align 1
  %xor.i.i.i.i66 = xor i64 2, %164
  %xor1.i.i.i.i67 = xor i64 %xor.i.i.i.i66, %sub.i.i
  %168 = trunc i64 %xor1.i.i.i.i67 to i8
  %169 = lshr i8 %168, 4
  %conv2.i.i.i68 = and i8 %169, 1
  %af.i.i.i69 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i68, ptr %af.i.i.i69, align 1
  %cmp.i.i.i.i70 = icmp eq i64 %164, 2
  %call.i.i.i.i71 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i70, i64 noundef %164, i64 noundef 2, i64 noundef %sub.i.i) #17
  %conv5.i.i.i72 = zext i1 %call.i.i.i.i71 to i8
  %zf.i.i.i73 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i72, ptr %zf.i.i.i73, align 1
  %cmp.i27.i.i.i74 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i74, i64 noundef %164, i64 noundef 2, i64 noundef %sub.i.i) #17
  %conv8.i.i.i76 = zext i1 %call1.i.i.i.i75 to i8
  %sf.i.i.i77 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i76, ptr %sf.i.i.i77, align 1
  %xor.i28.i.i.i78 = lshr i64 %xor.i.i.i.i66, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %164
  %xor3.i.i.i.i79 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i80 = add nuw nsw i64 %xor3.i.i.i.i79, %xor.i28.i.i.i78
  %cmp.i29.i.i.i81 = icmp eq i64 %add.i.i.i.i80, 2
  %call.i30.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i81, i64 noundef %164, i64 noundef 2, i64 noundef %sub.i.i) #17
  %conv11.i.i.i83 = zext i1 %call.i30.i.i.i82 to i8
  %of.i.i.i84 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i83, ptr %of.i.i.i84, align 1
  store ptr %165, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %161
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 4
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i64, ptr %RAX, align 8
  %174 = load ptr, ptr %MEMORY, align 8
  %shl.i145.i = shl i64 %173, 1
  %call42.i = call zeroext i8 @__remill_undefined_8() #18
  %tobool43.i = icmp ne i8 %call42.i, 0
  %shl.i147.i = shl i64 %shl.i145.i, 1
  store i64 %shl.i147.i, ptr %RAX, align 8
  %cf.i171 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i64 %shl.i145.i, 63
  %conv.i172 = trunc i64 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i172, ptr %cf.i171, align 1
  %pf.i173 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i174 = trunc i64 %shl.i147.i to i8
  %175 = call i8 @llvm.ctpop.i8(i8 %conv.i.i174)
  %176 = and i8 %175, 1
  %conv72.i = xor i8 %176, 1
  store i8 %conv72.i, ptr %pf.i173, align 1
  %af.i175 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i175, align 1
  %zf.i176 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  %cmp.i148.i = icmp eq i64 %shl.i147.i, 0
  %conv85.i = zext i1 %cmp.i148.i to i8
  store i8 %conv85.i, ptr %zf.i176, align 1
  %sf.i177 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i64 %shl.i147.i, 63
  %conv92.i178 = trunc i64 %new_val.0.lobit.i to i8
  store i8 %conv92.i178, ptr %sf.i177, align 1
  %of.i179 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i179, align 1
  store ptr %174, ptr %MEMORY, align 8
  br label %177

177:                                              ; preds = %170
  %178 = load i64, ptr %NEXT_PC, align 8
  store i64 %178, ptr %PC, align 8
  %179 = add i64 %178, 3
  store i64 %179, ptr %NEXT_PC, align 8
  %180 = load i64, ptr %RBP, align 8
  %181 = sub i64 %180, 4
  %182 = load ptr, ptr %MEMORY, align 8
  %call.i.i146 = call i32 @__remill_read_memory_32(ptr noundef %182, i64 noundef %181) #17
  %conv.i.i147 = zext i32 %call.i.i146 to i64
  store i64 %conv.i.i147, ptr %RCX, align 8
  store ptr %182, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %177
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 3
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i64, ptr %RAX, align 8
  %187 = load i64, ptr %RCX, align 8
  %188 = load ptr, ptr %MEMORY, align 8
  %sub.i.i113 = sub i64 %186, %187
  store i64 %sub.i.i113, ptr %RAX, align 8
  %cmp.i.i.i114 = icmp ult i64 %186, %187
  %call.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i114, i64 noundef %186, i64 noundef %187, i64 noundef %sub.i.i113) #17
  %conv.i.i116 = zext i1 %call.i.i.i115 to i8
  %cf.i.i117 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i116, ptr %cf.i.i117, align 1
  %conv.i.i.i.i118 = trunc i64 %sub.i.i113 to i8
  %189 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i118)
  %190 = and i8 %189, 1
  %conv.i.i.i119 = xor i8 %190, 1
  %pf.i.i.i120 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i119, ptr %pf.i.i.i120, align 1
  %xor.i.i.i.i121 = xor i64 %187, %186
  %xor1.i.i.i.i122 = xor i64 %xor.i.i.i.i121, %sub.i.i113
  %191 = trunc i64 %xor1.i.i.i.i122 to i8
  %192 = lshr i8 %191, 4
  %conv2.i.i.i123 = and i8 %192, 1
  %af.i.i.i124 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i123, ptr %af.i.i.i124, align 1
  %cmp.i.i.i.i125 = icmp eq i64 %186, %187
  %call.i.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i125, i64 noundef %186, i64 noundef %187, i64 noundef %sub.i.i113) #17
  %conv5.i.i.i127 = zext i1 %call.i.i.i.i126 to i8
  %zf.i.i.i128 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i127, ptr %zf.i.i.i128, align 1
  %cmp.i27.i.i.i129 = icmp slt i64 %sub.i.i113, 0
  %call1.i.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i129, i64 noundef %186, i64 noundef %187, i64 noundef %sub.i.i113) #17
  %conv8.i.i.i131 = zext i1 %call1.i.i.i.i130 to i8
  %sf.i.i.i132 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i131, ptr %sf.i.i.i132, align 1
  %xor.i28.i.i.i133 = lshr i64 %xor.i.i.i.i121, 63
  %shr9.i.i.i.i134 = xor i64 %sub.i.i113, %186
  %xor3.i.i.i.i135 = lshr i64 %shr9.i.i.i.i134, 63
  %add.i.i.i.i136 = add nuw nsw i64 %xor3.i.i.i.i135, %xor.i28.i.i.i133
  %cmp.i29.i.i.i137 = icmp eq i64 %add.i.i.i.i136, 2
  %call.i30.i.i.i138 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i137, i64 noundef %186, i64 noundef %187, i64 noundef %sub.i.i113) #17
  %conv11.i.i.i139 = zext i1 %call.i30.i.i.i138 to i8
  %of.i.i.i140 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i139, ptr %of.i.i.i140, align 1
  store ptr %188, ptr %MEMORY, align 8
  br label %193

193:                                              ; preds = %183
  %194 = load i64, ptr %NEXT_PC, align 8
  store i64 %194, ptr %PC, align 8
  %195 = add i64 %194, 3
  store i64 %195, ptr %NEXT_PC, align 8
  %196 = load i64, ptr %RAX, align 8
  %197 = load ptr, ptr %MEMORY, align 8
  store i64 %196, ptr %RDX, align 8
  store ptr %197, ptr %MEMORY, align 8
  br label %198

198:                                              ; preds = %193
  %199 = load i64, ptr %NEXT_PC, align 8
  store i64 %199, ptr %PC, align 8
  %200 = add i64 %199, 4
  store i64 %200, ptr %NEXT_PC, align 8
  %201 = load i64, ptr %RBP, align 8
  %202 = sub i64 %201, 24
  %203 = load ptr, ptr %MEMORY, align 8
  %call.i.i154 = call i64 @__remill_read_memory_64(ptr noundef %203, i64 noundef %202) #17
  store i64 %call.i.i154, ptr %RAX, align 8
  store ptr %203, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %198
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 4
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i64, ptr %RAX, align 8
  %208 = add i64 %207, 28
  %209 = load ptr, ptr %MEMORY, align 8
  store i64 %208, ptr %RCX, align 8
  store ptr %209, ptr %MEMORY, align 8
  br label %210

210:                                              ; preds = %204
  %211 = load i64, ptr %NEXT_PC, align 8
  store i64 %211, ptr %PC, align 8
  %212 = add i64 %211, 3
  store i64 %212, ptr %NEXT_PC, align 8
  %213 = load i64, ptr %RBP, align 8
  %214 = sub i64 %213, 4
  %215 = load ptr, ptr %MEMORY, align 8
  %call.i.i144 = call i32 @__remill_read_memory_32(ptr noundef %215, i64 noundef %214) #17
  %conv.i.i145 = zext i32 %call.i.i144 to i64
  store i64 %conv.i.i145, ptr %RAX, align 8
  store ptr %215, ptr %MEMORY, align 8
  br label %216

216:                                              ; preds = %210
  %217 = load i64, ptr %NEXT_PC, align 8
  store i64 %217, ptr %PC, align 8
  %218 = add i64 %217, 3
  store i64 %218, ptr %NEXT_PC, align 8
  %219 = load i64, ptr %RAX, align 8
  %220 = load i64, ptr %RCX, align 8
  %221 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 %220, %219
  store i64 %add.i.i30, ptr %RAX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %219
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, %220
  %222 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %222, i64 noundef %219, i64 noundef %220, i64 noundef %add.i.i30) #17
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %223 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %224 = and i8 %223, 1
  %conv.i.i.i37 = xor i8 %224, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, %220
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %219
  %225 = trunc i64 %xor1.i.i.i.i40 to i8
  %226 = lshr i8 %225, 4
  %conv2.i.i.i41 = and i8 %226, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %219, i64 noundef %220, i64 noundef %add.i.i30) #17
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %219, i64 noundef %220, i64 noundef %add.i.i30) #17
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %219
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %219, i64 noundef %220, i64 noundef %add.i.i30) #17
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %221, ptr %MEMORY, align 8
  br label %227

227:                                              ; preds = %216
  %228 = load i64, ptr %NEXT_PC, align 8
  store i64 %228, ptr %PC, align 8
  %229 = add i64 %228, 7
  store i64 %229, ptr %NEXT_PC, align 8
  %230 = load i64, ptr %NEXT_PC, align 8
  %231 = add i64 %230, 7277
  %232 = load ptr, ptr %MEMORY, align 8
  store i64 %231, ptr %RCX, align 8
  store ptr %232, ptr %MEMORY, align 8
  br label %233

233:                                              ; preds = %227
  %234 = load i64, ptr %NEXT_PC, align 8
  store i64 %234, ptr %PC, align 8
  %235 = add i64 %234, 3
  store i64 %235, ptr %NEXT_PC, align 8
  %236 = load i64, ptr %RCX, align 8
  %237 = load ptr, ptr %MEMORY, align 8
  store i64 %236, ptr %RSI, align 8
  store ptr %237, ptr %MEMORY, align 8
  br label %238

238:                                              ; preds = %233
  %239 = load i64, ptr %NEXT_PC, align 8
  store i64 %239, ptr %PC, align 8
  %240 = add i64 %239, 3
  store i64 %240, ptr %NEXT_PC, align 8
  %241 = load i64, ptr %RAX, align 8
  %242 = load ptr, ptr %MEMORY, align 8
  store i64 %241, ptr %RDI, align 8
  store ptr %242, ptr %MEMORY, align 8
  br label %243

243:                                              ; preds = %238
  %244 = load i64, ptr %NEXT_PC, align 8
  store i64 %244, ptr %PC, align 8
  %245 = add i64 %244, 5
  store i64 %245, ptr %NEXT_PC, align 8
  %246 = load i64, ptr %NEXT_PC, align 8
  %247 = sub i64 %246, 734
  %248 = load i64, ptr %NEXT_PC, align 8
  %249 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %250 = load i64, ptr %rsp.i, align 8
  %sub.i.i141 = add i64 %250, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %249, i64 noundef %sub.i.i141, i64 noundef %248) #17
  store i64 %sub.i.i141, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %247, ptr %rip.i, align 8
  store i64 %247, ptr %NEXT_PC, align 8
  store i64 %248, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %251 = load ptr, ptr %MEMORY, align 8
  ret ptr %251
}

define ptr @BB_1306(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #17
  store i64 %call.i.i3, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = add i64 %10, 20
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #17
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = add i64 %16, 1
  %18 = load ptr, ptr %MEMORY, align 8
  %conv.i.i4 = and i64 %17, 4294967295
  store i64 %conv.i.i4, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 24
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #17
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RAX, align 8
  %29 = add i64 %28, 20
  %30 = load i32, ptr %EDX, align 4
  %31 = zext i32 %30 to i64
  %32 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %32, i64 noundef %29, i32 noundef %30) #17
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %25
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_12de(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 32, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_12e3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load i64, ptr %RAX, align 8
  %7 = load ptr, ptr %MEMORY, align 8
  %call.i.i27 = call ptr @__remill_write_memory_64(ptr noundef %7, i64 noundef %5, i64 noundef %6) #17
  store ptr %call.i.i27, ptr %MEMORY, align 8
  br label %8

8:                                                ; preds = %1
  %9 = load i64, ptr %NEXT_PC, align 8
  store i64 %9, ptr %PC, align 8
  %10 = add i64 %9, 4
  store i64 %10, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %RBP, align 8
  %12 = sub i64 %11, 24
  %13 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call i64 @__remill_read_memory_64(ptr noundef %13, i64 noundef %12) #17
  store i64 %call.i.i36, ptr %RAX, align 8
  store ptr %13, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %8
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 3
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RAX, align 8
  %18 = add i64 %17, 16
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call i32 @__remill_read_memory_32(ptr noundef %19, i64 noundef %18) #17
  %conv.i.i33 = zext i32 %call.i.i32 to i64
  store i64 %conv.i.i33, ptr %RDX, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %14
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 4
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call i32 @__remill_read_memory_32(ptr noundef %25, i64 noundef %24) #17
  %conv.i.i31 = zext i32 %call.i.i30 to i64
  store i64 %conv.i.i31, ptr %RAX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RDX, align 8
  %30 = load i32, ptr %EAX, align 4
  %31 = zext i32 %30 to i64
  %32 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %29 to i32
  %add.i.i = add i32 %30, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RDX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %30
  %33 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %33, i32 noundef %conv.i.i, i32 noundef %30, i32 noundef %add.i.i) #17
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %35 = and i8 %34, 1
  %conv.i.i.i = xor i8 %35, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %30
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %36 = trunc i32 %xor1.i.i.i.i to i8
  %37 = lshr i8 %36, 4
  %conv2.i.i.i = and i8 %37, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %30, i32 noundef %add.i.i) #17
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %30, i32 noundef %add.i.i) #17
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %30, i32 noundef %add.i.i) #17
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %32, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %26
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 4
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RBP, align 8
  %42 = sub i64 %41, 24
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %43, i64 noundef %42) #17
  store i64 %call.i.i35, ptr %RAX, align 8
  store ptr %43, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %38
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 3
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RAX, align 8
  %48 = add i64 %47, 16
  %49 = load i32, ptr %EDX, align 4
  %50 = zext i32 %49 to i64
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i26 = call ptr @__remill_write_memory_32(ptr noundef %51, i64 noundef %48, i32 noundef %49) #17
  store ptr %call.i.i26, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %44
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 4
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RBP, align 8
  %56 = sub i64 %55, 24
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i64 @__remill_read_memory_64(ptr noundef %57, i64 noundef %56) #17
  store i64 %call.i.i34, ptr %RAX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RAX, align 8
  %62 = add i64 %61, 16
  %63 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call i32 @__remill_read_memory_32(ptr noundef %63, i64 noundef %62) #17
  %conv.i.i29 = zext i32 %call.i.i28 to i64
  store i64 %conv.i.i29, ptr %RAX, align 8
  store ptr %63, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 3
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %RBP, align 8
  %68 = sub i64 %67, 4
  %69 = load i32, ptr %EAX, align 4
  %70 = zext i32 %69 to i64
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %71, i64 noundef %68) #17
  %sub.i.i = sub i32 %call.i.i, %69
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, %69
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef %69, i32 noundef %sub.i.i) #17
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %72 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %73 = and i8 %72, 1
  %conv.i.i.i5 = xor i8 %73, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, %69
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %74 = trunc i32 %xor1.i.i.i.i8 to i8
  %75 = lshr i8 %74, 4
  %conv2.i.i.i9 = and i8 %75, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, %69
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef %69, i32 noundef %sub.i.i) #17
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef %69, i32 noundef %sub.i.i) #17
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef %69, i32 noundef %sub.i.i) #17
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %71, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %64
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %NEXT_PC, align 8
  %80 = add i64 %79, 17
  %81 = load i64, ptr %NEXT_PC, align 8
  %82 = load ptr, ptr %MEMORY, align 8
  %cf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 1
  %83 = load i8, ptr %cf.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 2, i32 7
  %84 = load i8, ptr %zf.i, align 1
  %85 = or i8 %84, %83
  %86 = icmp ne i8 %85, 0
  %call11.i = call zeroext i1 @__remill_compare_ule(i1 noundef zeroext %86) #18
  %frombool.i = zext i1 %call11.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call11.i, i64 %80, i64 %81
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %82, ptr %MEMORY, align 8
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = load ptr, ptr %MEMORY, align 8
  ret ptr %88
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_memcpy(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_memcpy(ptr, i64, ptr) #2

define ptr @BB_139e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #17
  store i64 %call.i.i3, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 8
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = mul i64 %10, 4
  %12 = add i64 0, %11
  %13 = load ptr, ptr %MEMORY, align 8
  store i64 %12, ptr %RSI, align 8
  store ptr %13, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 24
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %19, i64 noundef %18) #17
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %14
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RAX, align 8
  %24 = add i64 %23, 28
  %25 = load ptr, ptr %MEMORY, align 8
  store i64 %24, ptr %RCX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 4
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RBP, align 8
  %30 = sub i64 %29, 24
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %31, i64 noundef %30) #17
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %26
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 3
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RAX, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  store i64 %35, ptr %RDX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %32
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RCX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  store i64 %40, ptr %RDI, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %37
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 5
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %NEXT_PC, align 8
  %46 = sub i64 %45, 801
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %49 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %49, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %sub.i.i, i64 noundef %47) #17
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %46, ptr %rip.i, align 8
  store i64 %46, ptr %NEXT_PC, align 8
  store i64 %47, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  ret ptr %50
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_md5_process_block(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_md5_process_block(ptr, i64, ptr) #4

define ptr @BB_13c1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #17
  store i64 %call.i.i2, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 24
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #17
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RDX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RSI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  store i64 %21, ptr %RDI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 5
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %NEXT_PC, align 8
  %27 = sub i64 %26, 740
  %28 = load i64, ptr %NEXT_PC, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %30 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %30, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %29, i64 noundef %sub.i.i, i64 noundef %28) #17
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %27, ptr %rip.i, align 8
  store i64 %27, ptr %NEXT_PC, align 8
  store i64 %28, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  ret ptr %31
}

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #5 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_md5_read_ctx(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_md5_read_ctx(ptr, i64, ptr) #5

define ptr @BB_13d4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.32041, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #17
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #17
  %rip.i = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #6 {
entry:
  %agg.tmp = alloca %struct.State.32041, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.32041) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #19
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #7

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.32041) align 16, i64 noundef, ptr noundef) local_unnamed_addr #8

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rax = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #9 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rax = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rip = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #10 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #11 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4787, label %bb_12B3
    i64 4823, label %bb_12D7
    i64 4830, label %bb_12DE
    i64 4835, label %bb_12E3
    i64 4870, label %bb_1306
    i64 4887, label %bb_1317
    i64 5022, label %bb_139E
    i64 5057, label %bb_13C1
    i64 5076, label %bb_13D4
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
  ]

dead_end:                                         ; preds = %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_13C1, %bb_139E, %bb_1317, %bb_1306, %bb_12E3, %bb_12DE, %bb_12D7, %bb_12B3, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_12B3:                                          ; preds = %entry
  %block_pc = add i64 4787, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4787, ptr %1)
  %4 = call ptr @BB_12b3(ptr %state, i64 %2, ptr %1) #20
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4823, label %bb_12D7
    i64 4830, label %bb_12DE
  ]

bb_12D7:                                          ; preds = %bb_12B3, %entry
  %block_pc1 = add i64 4823, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4823, ptr %6)
  %9 = call ptr @BB_12d7(ptr %state, i64 %7, ptr %6) #20
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4835, label %bb_12E3
  ]

bb_12DE:                                          ; preds = %bb_12B3, %entry
  %block_pc3 = add i64 4830, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4830, ptr %11)
  %14 = call ptr @BB_12de(ptr %state, i64 %12, ptr %11) #20
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4835, label %bb_12E3
  ]

bb_12E3:                                          ; preds = %bb_12DE, %bb_12D7, %entry
  %block_pc5 = add i64 4835, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4835, ptr %16)
  %19 = call ptr @BB_12e3(ptr %state, i64 %17, ptr %16) #20
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4870, label %bb_1306
    i64 4887, label %bb_1317
  ]

bb_1306:                                          ; preds = %bb_12E3, %entry
  %block_pc7 = add i64 4870, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4870, ptr %21)
  %24 = call ptr @BB_1306(ptr %state, i64 %22, ptr %21) #20
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4887, label %bb_1317
  ]

bb_1317:                                          ; preds = %bb_1306, %bb_12E3, %entry
  %block_pc9 = add i64 4887, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4887, ptr %26)
  %29 = call ptr @BB_1317(ptr %state, i64 %27, ptr %26) #20
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4288, label %bb_FFFF000000000000
  ]

bb_139E:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc11 = add i64 5022, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 5022, ptr %31)
  %34 = call ptr @BB_139e(ptr %state, i64 %32, ptr %31) #20
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4256, label %bb_FFFF000000000001
  ]

bb_13C1:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc13 = add i64 5057, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 5057, ptr %36)
  %39 = call ptr @BB_13c1(ptr %state, i64 %37, ptr %36) #20
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4336, label %bb_FFFF000000000002
  ]

bb_13D4:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc15 = add i64 5076, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 5076, ptr %41)
  %44 = call ptr @BB_13d4(ptr %state, i64 %42, ptr %41) #20
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  %46 = load ptr, ptr %mem_var, align 8
  ret ptr %46

bb_FFFF000000000000:                              ; preds = %bb_1317, %entry
  %47 = load ptr, ptr %mem_var, align 8
  %48 = load i64, ptr %pc_var, align 4
  %49 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %48, ptr %47) #20
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva17 = sub i64 %50, %base
  switch i64 %next_rva17, label %dead_end [
    i64 5022, label %bb_139E
  ]

bb_FFFF000000000001:                              ; preds = %bb_139E, %entry
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %52, ptr %51) #20
  store ptr %53, ptr %mem_var, align 8
  %54 = call i64 @__extract_rip(ptr %state)
  store i64 %54, ptr %pc_var, align 4
  %next_rva18 = sub i64 %54, %base
  switch i64 %next_rva18, label %dead_end [
    i64 5057, label %bb_13C1
  ]

bb_FFFF000000000002:                              ; preds = %bb_13C1, %entry
  %55 = load ptr, ptr %mem_var, align 8
  %56 = load i64, ptr %pc_var, align 4
  %57 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %56, ptr %55) #20
  store ptr %57, ptr %mem_var, align 8
  %58 = call i64 @__extract_rip(ptr %state)
  store i64 %58, ptr %pc_var, align 4
  %next_rva19 = sub i64 %58, %base
  switch i64 %next_rva19, label %dead_end [
    i64 5076, label %bb_13D4
  ]

return_bb:                                        ; No predecessors!
  %59 = load ptr, ptr %mem_var, align 8
  ret ptr %59
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #12 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4787, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #13 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #13 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #13 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #13 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #13 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #13 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #14 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #10 {
entry:
  %rip = getelementptr inbounds %struct.X86State.32040, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !32
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { "lifted.annotation_id"="5" "lifted.state_form"="folded" }
attributes #6 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #8 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #12 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #18 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #19 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #20 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33, !33, i64 0}
!33 = !{!"omnipotent char", !34, i64 0}
!34 = !{!"Simple C++ TBAA"}
