; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.21950 = type { %struct.X86State.21949 }
%struct.X86State.21949 = type { %struct.ArchState.21918, [32 x %union.VectorReg.21921], %struct.ArithFlags.21922, %union.anon.21917, %struct.Segments.21924, %struct.AddressSpace.21926, %struct.GPR.21927, %struct.X87Stack.21930, %struct.MMX.21934, %struct.FPUStatusFlags.21935, %union.anon.21917, %union.FPU.21944, %struct.SegmentCaches.21946, %struct.K_REG.21948 }
%struct.ArchState.21918 = type { i32, i32, %union.anon.21917 }
%union.VectorReg.21921 = type { %union.vec512_t.21920 }
%union.vec512_t.21920 = type { %struct.uint64v8_t.21919 }
%struct.uint64v8_t.21919 = type { [8 x i64] }
%struct.ArithFlags.21922 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.21924 = type { i16, %union.SegmentSelector.21923, i16, %union.SegmentSelector.21923, i16, %union.SegmentSelector.21923, i16, %union.SegmentSelector.21923, i16, %union.SegmentSelector.21923, i16, %union.SegmentSelector.21923 }
%union.SegmentSelector.21923 = type { i16 }
%struct.AddressSpace.21926 = type { i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925 }
%struct.Reg.21925 = type { %union.anon.21917 }
%struct.GPR.21927 = type { i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925, i64, %struct.Reg.21925 }
%struct.X87Stack.21930 = type { [8 x %struct.anon.3.21929] }
%struct.anon.3.21929 = type { [6 x i8], %struct.float80_t.21928 }
%struct.float80_t.21928 = type { [10 x i8] }
%struct.MMX.21934 = type { [8 x %struct.anon.4.21933] }
%struct.anon.4.21933 = type { i64, %union.vec64_t.21932 }
%union.vec64_t.21932 = type { %struct.uint64v1_t.21931 }
%struct.uint64v1_t.21931 = type { [1 x i64] }
%struct.FPUStatusFlags.21935 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.21917 = type { i64 }
%union.FPU.21944 = type { %struct.anon.13.21943 }
%struct.anon.13.21943 = type { %struct.FpuFXSAVE.21942, [96 x i8] }
%struct.FpuFXSAVE.21942 = type { %union.SegmentSelector.21923, %union.SegmentSelector.21923, %union.FPUAbridgedTagWord.21936, i8, i16, i32, %union.SegmentSelector.21923, i16, i32, %union.SegmentSelector.21923, i16, %union.FPUControlStatus.21937, %union.FPUControlStatus.21937, [8 x %struct.FPUStackElem.21939], [16 x %union.vec128_t.21941] }
%union.FPUAbridgedTagWord.21936 = type { i8 }
%union.FPUControlStatus.21937 = type { i32 }
%struct.FPUStackElem.21939 = type { %union.anon.11.21938, [6 x i8] }
%union.anon.11.21938 = type { %struct.float80_t.21928 }
%union.vec128_t.21941 = type { %struct.uint128v1_t.21940 }
%struct.uint128v1_t.21940 = type { [1 x i128] }
%struct.SegmentCaches.21946 = type { %struct.SegmentShadow.21945, %struct.SegmentShadow.21945, %struct.SegmentShadow.21945, %struct.SegmentShadow.21945, %struct.SegmentShadow.21945, %struct.SegmentShadow.21945 }
%struct.SegmentShadow.21945 = type { %union.anon.21917, i32, i32 }
%struct.K_REG.21948 = type { [8 x %struct.anon.18.21947] }
%struct.anon.18.21947 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1110(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %R10D = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 21, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %R10 = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 21, i32 0, i32 0
  %R9 = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i233 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i233, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 32
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i187 = icmp ult i64 %15, 32
  %call.i.i.i188 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i187, i64 noundef %15, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv.i.i189 = zext i1 %call.i.i.i188 to i8
  %cf.i.i190 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i189, ptr %cf.i.i190, align 1
  %conv.i.i.i.i191 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i191)
  %18 = and i8 %17, 1
  %conv.i.i.i192 = xor i8 %18, 1
  %pf.i.i.i193 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i192, ptr %pf.i.i.i193, align 1
  %xor.i.i.i.i194 = xor i64 32, %15
  %xor1.i.i.i.i195 = xor i64 %xor.i.i.i.i194, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i195 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i196 = and i8 %20, 1
  %af.i.i.i197 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i196, ptr %af.i.i.i197, align 1
  %cmp.i.i.i.i198 = icmp eq i64 %15, 32
  %call.i.i.i.i199 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i198, i64 noundef %15, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv5.i.i.i200 = zext i1 %call.i.i.i.i199 to i8
  %zf.i.i.i201 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i200, ptr %zf.i.i.i201, align 1
  %cmp.i27.i.i.i202 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i202, i64 noundef %15, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv8.i.i.i204 = zext i1 %call1.i.i.i.i203 to i8
  %sf.i.i.i205 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i204, ptr %sf.i.i.i205, align 1
  %xor.i28.i.i.i206 = lshr i64 %xor.i.i.i.i194, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i207 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i208 = add nuw nsw i64 %xor3.i.i.i.i207, %xor.i28.i.i.i206
  %cmp.i29.i.i.i209 = icmp eq i64 %add.i.i.i.i208, 2
  %call.i30.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i209, i64 noundef %15, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv11.i.i.i211 = zext i1 %call.i30.i.i.i210 to i8
  %of.i.i.i212 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i211, ptr %of.i.i.i212, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 4
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i216 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i216, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 4
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i231 = call i32 @__remill_read_memory_32(ptr noundef %34, i64 noundef %33) #15
  %conv.i.i232 = zext i32 %call.i.i231 to i64
  store i64 %conv.i.i232, ptr %RDI, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 4
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i229 = call i32 @__remill_read_memory_32(ptr noundef %40, i64 noundef %39) #15
  %conv.i.i230 = zext i32 %call.i.i229 to i64
  store i64 %conv.i.i230, ptr %RSI, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RSI, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  %conv.i.i156 = trunc i64 %44 to i32
  %add.i.i157 = add i32 1, %conv.i.i156
  %conv.i22.i158 = zext i32 %add.i.i157 to i64
  store i64 %conv.i22.i158, ptr %RSI, align 8
  %cmp.i.i.i159 = icmp ult i32 %add.i.i157, %conv.i.i156
  %cmp1.i.i.i160 = icmp ult i32 %add.i.i157, 1
  %46 = or i1 %cmp.i.i.i159, %cmp1.i.i.i160
  %call.i.i.i161 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %46, i32 noundef %conv.i.i156, i32 noundef 1, i32 noundef %add.i.i157) #15
  %conv.i23.i162 = zext i1 %call.i.i.i161 to i8
  %cf.i.i163 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i162, ptr %cf.i.i163, align 1
  %conv.i.i.i.i164 = trunc i32 %add.i.i157 to i8
  %47 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i164)
  %48 = and i8 %47, 1
  %conv.i.i.i165 = xor i8 %48, 1
  %pf.i.i.i166 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i165, ptr %pf.i.i.i166, align 1
  %xor.i.i.i.i167 = xor i32 %add.i.i157, 1
  %xor1.i.i.i.i168 = xor i32 %xor.i.i.i.i167, %conv.i.i156
  %49 = trunc i32 %xor1.i.i.i.i168 to i8
  %50 = lshr i8 %49, 4
  %conv2.i.i.i169 = and i8 %50, 1
  %af.i.i.i170 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i169, ptr %af.i.i.i170, align 1
  %cmp.i.i.i.i171 = icmp eq i32 %add.i.i157, 0
  %call.i.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i171, i32 noundef %conv.i.i156, i32 noundef 1, i32 noundef %add.i.i157) #15
  %conv5.i.i.i173 = zext i1 %call.i.i.i.i172 to i8
  %zf.i.i.i174 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i173, ptr %zf.i.i.i174, align 1
  %cmp.i27.i.i.i175 = icmp slt i32 %add.i.i157, 0
  %call1.i.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i175, i32 noundef %conv.i.i156, i32 noundef 1, i32 noundef %add.i.i157) #15
  %conv8.i.i.i177 = zext i1 %call1.i.i.i.i176 to i8
  %sf.i.i.i178 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i177, ptr %sf.i.i.i178, align 1
  %shr8.i.i.i.i179 = xor i32 %add.i.i157, %conv.i.i156
  %xor.i28.i.i.i180 = lshr i32 %shr8.i.i.i.i179, 31
  %xor3.i.i.i.i181 = lshr i32 %xor.i.i.i.i167, 31
  %add.i.i.i.i182 = add nuw nsw i32 %xor.i28.i.i.i180, %xor3.i.i.i.i181
  %cmp.i29.i.i.i183 = icmp eq i32 %add.i.i.i.i182, 2
  %call.i30.i.i.i184 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i183, i32 noundef %conv.i.i156, i32 noundef 1, i32 noundef %add.i.i157) #15
  %conv11.i.i.i185 = zext i1 %call.i30.i.i.i184 to i8
  %of.i.i.i186 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i185, ptr %of.i.i.i186, align 1
  store ptr %45, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %41
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 3
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RBP, align 8
  %55 = sub i64 %54, 4
  %56 = load ptr, ptr %MEMORY, align 8
  %call.i.i227 = call i32 @__remill_read_memory_32(ptr noundef %56, i64 noundef %55) #15
  %conv.i.i228 = zext i32 %call.i.i227 to i64
  store i64 %conv.i.i228, ptr %RDX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %51
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RDX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i125 = trunc i64 %60 to i32
  %add.i.i126 = add i32 2, %conv.i.i125
  %conv.i22.i127 = zext i32 %add.i.i126 to i64
  store i64 %conv.i22.i127, ptr %RDX, align 8
  %cmp.i.i.i128 = icmp ult i32 %add.i.i126, %conv.i.i125
  %cmp1.i.i.i129 = icmp ult i32 %add.i.i126, 2
  %62 = or i1 %cmp.i.i.i128, %cmp1.i.i.i129
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %62, i32 noundef %conv.i.i125, i32 noundef 2, i32 noundef %add.i.i126) #15
  %conv.i23.i131 = zext i1 %call.i.i.i130 to i8
  %cf.i.i132 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i131, ptr %cf.i.i132, align 1
  %conv.i.i.i.i133 = trunc i32 %add.i.i126 to i8
  %63 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i133)
  %64 = and i8 %63, 1
  %conv.i.i.i134 = xor i8 %64, 1
  %pf.i.i.i135 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i134, ptr %pf.i.i.i135, align 1
  %xor.i.i.i.i136 = xor i32 %add.i.i126, 2
  %xor1.i.i.i.i137 = xor i32 %xor.i.i.i.i136, %conv.i.i125
  %65 = trunc i32 %xor1.i.i.i.i137 to i8
  %66 = lshr i8 %65, 4
  %conv2.i.i.i138 = and i8 %66, 1
  %af.i.i.i139 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i138, ptr %af.i.i.i139, align 1
  %cmp.i.i.i.i140 = icmp eq i32 %add.i.i126, 0
  %call.i.i.i.i141 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i140, i32 noundef %conv.i.i125, i32 noundef 2, i32 noundef %add.i.i126) #15
  %conv5.i.i.i142 = zext i1 %call.i.i.i.i141 to i8
  %zf.i.i.i143 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i142, ptr %zf.i.i.i143, align 1
  %cmp.i27.i.i.i144 = icmp slt i32 %add.i.i126, 0
  %call1.i.i.i.i145 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i144, i32 noundef %conv.i.i125, i32 noundef 2, i32 noundef %add.i.i126) #15
  %conv8.i.i.i146 = zext i1 %call1.i.i.i.i145 to i8
  %sf.i.i.i147 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i146, ptr %sf.i.i.i147, align 1
  %shr8.i.i.i.i148 = xor i32 %add.i.i126, %conv.i.i125
  %xor.i28.i.i.i149 = lshr i32 %shr8.i.i.i.i148, 31
  %xor3.i.i.i.i150 = lshr i32 %xor.i.i.i.i136, 31
  %add.i.i.i.i151 = add nuw nsw i32 %xor.i28.i.i.i149, %xor3.i.i.i.i150
  %cmp.i29.i.i.i152 = icmp eq i32 %add.i.i.i.i151, 2
  %call.i30.i.i.i153 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i152, i32 noundef %conv.i.i125, i32 noundef 2, i32 noundef %add.i.i126) #15
  %conv11.i.i.i154 = zext i1 %call.i30.i.i.i153 to i8
  %of.i.i.i155 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i154, ptr %of.i.i.i155, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %57
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RBP, align 8
  %71 = sub i64 %70, 4
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i225 = call i32 @__remill_read_memory_32(ptr noundef %72, i64 noundef %71) #15
  %conv.i.i226 = zext i32 %call.i.i225 to i64
  store i64 %conv.i.i226, ptr %RCX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RCX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %76 to i32
  %add.i.i95 = add i32 3, %conv.i.i94
  %conv.i22.i96 = zext i32 %add.i.i95 to i64
  store i64 %conv.i22.i96, ptr %RCX, align 8
  %cmp.i.i.i97 = icmp ult i32 %add.i.i95, %conv.i.i94
  %cmp1.i.i.i98 = icmp ult i32 %add.i.i95, 3
  %78 = or i1 %cmp.i.i.i97, %cmp1.i.i.i98
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %78, i32 noundef %conv.i.i94, i32 noundef 3, i32 noundef %add.i.i95) #15
  %conv.i23.i100 = zext i1 %call.i.i.i99 to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i100, ptr %cf.i.i101, align 1
  %conv.i.i.i.i102 = trunc i32 %add.i.i95 to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i102)
  %80 = and i8 %79, 1
  %conv.i.i.i103 = xor i8 %80, 1
  %pf.i.i.i104 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i103, ptr %pf.i.i.i104, align 1
  %xor.i.i.i.i105 = xor i32 %add.i.i95, 3
  %xor1.i.i.i.i106 = xor i32 %xor.i.i.i.i105, %conv.i.i94
  %81 = trunc i32 %xor1.i.i.i.i106 to i8
  %82 = lshr i8 %81, 4
  %conv2.i.i.i107 = and i8 %82, 1
  %af.i.i.i108 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i107, ptr %af.i.i.i108, align 1
  %cmp.i.i.i.i109 = icmp eq i32 %add.i.i95, 0
  %call.i.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i109, i32 noundef %conv.i.i94, i32 noundef 3, i32 noundef %add.i.i95) #15
  %conv5.i.i.i111 = zext i1 %call.i.i.i.i110 to i8
  %zf.i.i.i112 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i111, ptr %zf.i.i.i112, align 1
  %cmp.i27.i.i.i113 = icmp slt i32 %add.i.i95, 0
  %call1.i.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i113, i32 noundef %conv.i.i94, i32 noundef 3, i32 noundef %add.i.i95) #15
  %conv8.i.i.i115 = zext i1 %call1.i.i.i.i114 to i8
  %sf.i.i.i116 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i115, ptr %sf.i.i.i116, align 1
  %shr8.i.i.i.i117 = xor i32 %add.i.i95, %conv.i.i94
  %xor.i28.i.i.i118 = lshr i32 %shr8.i.i.i.i117, 31
  %xor3.i.i.i.i119 = lshr i32 %xor.i.i.i.i105, 31
  %add.i.i.i.i120 = add nuw nsw i32 %xor.i28.i.i.i118, %xor3.i.i.i.i119
  %cmp.i29.i.i.i121 = icmp eq i32 %add.i.i.i.i120, 2
  %call.i30.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i121, i32 noundef %conv.i.i94, i32 noundef 3, i32 noundef %add.i.i95) #15
  %conv11.i.i.i123 = zext i1 %call.i30.i.i.i122 to i8
  %of.i.i.i124 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i123, ptr %of.i.i.i124, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %73
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 4
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i64, ptr %RBP, align 8
  %87 = sub i64 %86, 4
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i223 = call i32 @__remill_read_memory_32(ptr noundef %88, i64 noundef %87) #15
  %conv.i.i224 = zext i32 %call.i.i223 to i64
  store i64 %conv.i.i224, ptr %R8, align 8
  store ptr %88, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %83
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 4
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %R8, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %92 to i32
  %add.i.i64 = add i32 4, %conv.i.i63
  %conv.i22.i65 = zext i32 %add.i.i64 to i64
  store i64 %conv.i22.i65, ptr %R8, align 8
  %cmp.i.i.i66 = icmp ult i32 %add.i.i64, %conv.i.i63
  %cmp1.i.i.i67 = icmp ult i32 %add.i.i64, 4
  %94 = or i1 %cmp.i.i.i66, %cmp1.i.i.i67
  %call.i.i.i68 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %94, i32 noundef %conv.i.i63, i32 noundef 4, i32 noundef %add.i.i64) #15
  %conv.i23.i69 = zext i1 %call.i.i.i68 to i8
  %cf.i.i70 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i69, ptr %cf.i.i70, align 1
  %conv.i.i.i.i71 = trunc i32 %add.i.i64 to i8
  %95 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i71)
  %96 = and i8 %95, 1
  %conv.i.i.i72 = xor i8 %96, 1
  %pf.i.i.i73 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i72, ptr %pf.i.i.i73, align 1
  %xor.i.i.i.i74 = xor i32 %add.i.i64, 4
  %xor1.i.i.i.i75 = xor i32 %xor.i.i.i.i74, %conv.i.i63
  %97 = trunc i32 %xor1.i.i.i.i75 to i8
  %98 = lshr i8 %97, 4
  %conv2.i.i.i76 = and i8 %98, 1
  %af.i.i.i77 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i76, ptr %af.i.i.i77, align 1
  %cmp.i.i.i.i78 = icmp eq i32 %add.i.i64, 0
  %call.i.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i78, i32 noundef %conv.i.i63, i32 noundef 4, i32 noundef %add.i.i64) #15
  %conv5.i.i.i80 = zext i1 %call.i.i.i.i79 to i8
  %zf.i.i.i81 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i80, ptr %zf.i.i.i81, align 1
  %cmp.i27.i.i.i82 = icmp slt i32 %add.i.i64, 0
  %call1.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i82, i32 noundef %conv.i.i63, i32 noundef 4, i32 noundef %add.i.i64) #15
  %conv8.i.i.i84 = zext i1 %call1.i.i.i.i83 to i8
  %sf.i.i.i85 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i84, ptr %sf.i.i.i85, align 1
  %shr8.i.i.i.i86 = xor i32 %add.i.i64, %conv.i.i63
  %xor.i28.i.i.i87 = lshr i32 %shr8.i.i.i.i86, 31
  %xor3.i.i.i.i88 = lshr i32 %xor.i.i.i.i74, 31
  %add.i.i.i.i89 = add nuw nsw i32 %xor.i28.i.i.i87, %xor3.i.i.i.i88
  %cmp.i29.i.i.i90 = icmp eq i32 %add.i.i.i.i89, 2
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i90, i32 noundef %conv.i.i63, i32 noundef 4, i32 noundef %add.i.i64) #15
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %93, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %89
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 4
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RBP, align 8
  %103 = sub i64 %102, 4
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i221 = call i32 @__remill_read_memory_32(ptr noundef %104, i64 noundef %103) #15
  %conv.i.i222 = zext i32 %call.i.i221 to i64
  store i64 %conv.i.i222, ptr %R9, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %99
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 4
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %R9, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %108 to i32
  %add.i.i33 = add i32 5, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %R9, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, 5
  %110 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %110, i32 noundef %conv.i.i32, i32 noundef 5, i32 noundef %add.i.i33) #15
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %111 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %112 = and i8 %111, 1
  %conv.i.i.i41 = xor i8 %112, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, 5
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %113 = trunc i32 %xor1.i.i.i.i44 to i8
  %114 = lshr i8 %113, 4
  %conv2.i.i.i45 = and i8 %114, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef 5, i32 noundef %add.i.i33) #15
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef 5, i32 noundef %add.i.i33) #15
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef 5, i32 noundef %add.i.i33) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %115

115:                                              ; preds = %105
  %116 = load i64, ptr %NEXT_PC, align 8
  store i64 %116, ptr %PC, align 8
  %117 = add i64 %116, 4
  store i64 %117, ptr %NEXT_PC, align 8
  %118 = load i64, ptr %RBP, align 8
  %119 = sub i64 %118, 4
  %120 = load ptr, ptr %MEMORY, align 8
  %call.i.i219 = call i32 @__remill_read_memory_32(ptr noundef %120, i64 noundef %119) #15
  %conv.i.i220 = zext i32 %call.i.i219 to i64
  store i64 %conv.i.i220, ptr %R10, align 8
  store ptr %120, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %115
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 4
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load i64, ptr %R10, align 8
  %125 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %124 to i32
  %add.i.i2 = add i32 6, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %R10, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 6
  %126 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %126, i32 noundef %conv.i.i1, i32 noundef 6, i32 noundef %add.i.i2) #15
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %127 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %128 = and i8 %127, 1
  %conv.i.i.i10 = xor i8 %128, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 6
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %129 = trunc i32 %xor1.i.i.i.i13 to i8
  %130 = lshr i8 %129, 4
  %conv2.i.i.i14 = and i8 %130, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 6, i32 noundef %add.i.i2) #15
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 6, i32 noundef %add.i.i2) #15
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 6, i32 noundef %add.i.i2) #15
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %121
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 3
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i64, ptr %RBP, align 8
  %135 = sub i64 %134, 4
  %136 = load ptr, ptr %MEMORY, align 8
  %call.i.i217 = call i32 @__remill_read_memory_32(ptr noundef %136, i64 noundef %135) #15
  %conv.i.i218 = zext i32 %call.i.i217 to i64
  store i64 %conv.i.i218, ptr %RAX, align 8
  store ptr %136, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %131
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 3
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i64, ptr %RAX, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %140 to i32
  %add.i.i = add i32 7, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 7
  %142 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %142, i32 noundef %conv.i.i, i32 noundef 7, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %143 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %144 = and i8 %143, 1
  %conv.i.i.i = xor i8 %144, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 7
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %145 = trunc i32 %xor1.i.i.i.i to i8
  %146 = lshr i8 %145, 4
  %conv2.i.i.i = and i8 %146, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 7, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 7, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 7, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %141, ptr %MEMORY, align 8
  br label %147

147:                                              ; preds = %137
  %148 = load i64, ptr %NEXT_PC, align 8
  store i64 %148, ptr %PC, align 8
  %149 = add i64 %148, 4
  store i64 %149, ptr %NEXT_PC, align 8
  %150 = load i64, ptr %RSP, align 8
  %151 = load i32, ptr %R10D, align 4
  %152 = zext i32 %151 to i64
  %153 = load ptr, ptr %MEMORY, align 8
  %call.i.i215 = call ptr @__remill_write_memory_32(ptr noundef %153, i64 noundef %150, i32 noundef %151) #15
  store ptr %call.i.i215, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %147
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 4
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i64, ptr %RSP, align 8
  %158 = add i64 %157, 8
  %159 = load i32, ptr %EAX, align 4
  %160 = zext i32 %159 to i64
  %161 = load ptr, ptr %MEMORY, align 8
  %call.i.i214 = call ptr @__remill_write_memory_32(ptr noundef %161, i64 noundef %158, i32 noundef %159) #15
  store ptr %call.i.i214, ptr %MEMORY, align 8
  br label %162

162:                                              ; preds = %154
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = add i64 %163, 5
  store i64 %164, ptr %NEXT_PC, align 8
  %165 = load i64, ptr %NEXT_PC, align 8
  %166 = sub i64 %165, 299
  %167 = load i64, ptr %NEXT_PC, align 8
  %168 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  %169 = load i64, ptr %rsp.i, align 8
  %sub.i.i213 = add i64 %169, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %168, i64 noundef %sub.i.i213, i64 noundef %167) #15
  store i64 %sub.i.i213, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 33
  store i64 %166, ptr %rip.i, align 8
  store i64 %166, ptr %NEXT_PC, align 8
  store i64 %167, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %170 = load ptr, ptr %MEMORY, align 8
  ret ptr %170
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_anonymous(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_anonymous(ptr, i64, ptr) #2

define ptr @BB_115b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.21950, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i3 = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i3, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 32, %10
  store i64 %add.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %10
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 32
  %12 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef 32, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %14 = and i8 %13, 1
  %conv.i.i.i = xor i8 %14, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 32
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %10
  %15 = trunc i64 %xor1.i.i.i.i to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i = and i8 %16, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %10, i64 noundef 32, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %10, i64 noundef 32, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %10
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %10, i64 noundef 32, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i4 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i4, align 8
  %add.i.i5 = add i64 %21, 8
  store i64 %add.i.i5, ptr %rsp.i4, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #15
  store i64 %call.i.i6, ptr %RBP, align 8
  store ptr %20, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %17
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 1
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  %26 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %26) #15
  %rip.i = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %rsp.i, align 8
  %add.i.i1 = add i64 %27, 8
  store i64 %add.i.i1, ptr %rsp.i, align 8
  store ptr %25, ptr %MEMORY, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  ret ptr %28
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.21950, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.21950) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #16
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.21950) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4368, label %bb_1110
    i64 4443, label %bb_115B
    i64 -281474976710656, label %bb_FFFF000000000000
  ]

dead_end:                                         ; preds = %bb_FFFF000000000000, %bb_1110, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1110:                                          ; preds = %entry
  %block_pc = add i64 4368, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4368, ptr %1)
  %4 = call ptr @BB_1110(ptr %state, i64 %2, ptr %1) #17
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4144, label %bb_FFFF000000000000
  ]

bb_115B:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc1 = add i64 4443, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4443, ptr %6)
  %9 = call ptr @BB_115b(ptr %state, i64 %7, ptr %6) #17
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  %11 = load ptr, ptr %mem_var, align 8
  ret ptr %11

bb_FFFF000000000000:                              ; preds = %bb_1110, %entry
  %12 = load ptr, ptr %mem_var, align 8
  %13 = load i64, ptr %pc_var, align 4
  %14 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %13, ptr %12) #17
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva3 = sub i64 %15, %base
  switch i64 %next_rva3, label %dead_end [
    i64 4443, label %bb_115B
  ]

return_bb:                                        ; No predecessors!
  %16 = load ptr, ptr %mem_var, align 8
  ret ptr %16
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4368, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() local_unnamed_addr #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.21949, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !14
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #17 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15, !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C++ TBAA"}
