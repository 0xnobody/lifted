; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.14228 = type { %struct.X86State.14227 }
%struct.X86State.14227 = type { %struct.ArchState.14196, [32 x %union.VectorReg.14199], %struct.ArithFlags.14200, %union.anon.14195, %struct.Segments.14202, %struct.AddressSpace.14204, %struct.GPR.14205, %struct.X87Stack.14208, %struct.MMX.14212, %struct.FPUStatusFlags.14213, %union.anon.14195, %union.FPU.14222, %struct.SegmentCaches.14224, %struct.K_REG.14226 }
%struct.ArchState.14196 = type { i32, i32, %union.anon.14195 }
%union.VectorReg.14199 = type { %union.vec512_t.14198 }
%union.vec512_t.14198 = type { %struct.uint64v8_t.14197 }
%struct.uint64v8_t.14197 = type { [8 x i64] }
%struct.ArithFlags.14200 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.14202 = type { i16, %union.SegmentSelector.14201, i16, %union.SegmentSelector.14201, i16, %union.SegmentSelector.14201, i16, %union.SegmentSelector.14201, i16, %union.SegmentSelector.14201, i16, %union.SegmentSelector.14201 }
%union.SegmentSelector.14201 = type { i16 }
%struct.AddressSpace.14204 = type { i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203 }
%struct.Reg.14203 = type { %union.anon.14195 }
%struct.GPR.14205 = type { i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203, i64, %struct.Reg.14203 }
%struct.X87Stack.14208 = type { [8 x %struct.anon.3.14207] }
%struct.anon.3.14207 = type { [6 x i8], %struct.float80_t.14206 }
%struct.float80_t.14206 = type { [10 x i8] }
%struct.MMX.14212 = type { [8 x %struct.anon.4.14211] }
%struct.anon.4.14211 = type { i64, %union.vec64_t.14210 }
%union.vec64_t.14210 = type { %struct.uint64v1_t.14209 }
%struct.uint64v1_t.14209 = type { [1 x i64] }
%struct.FPUStatusFlags.14213 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.14195 = type { i64 }
%union.FPU.14222 = type { %struct.anon.13.14221 }
%struct.anon.13.14221 = type { %struct.FpuFXSAVE.14220, [96 x i8] }
%struct.FpuFXSAVE.14220 = type { %union.SegmentSelector.14201, %union.SegmentSelector.14201, %union.FPUAbridgedTagWord.14214, i8, i16, i32, %union.SegmentSelector.14201, i16, i32, %union.SegmentSelector.14201, i16, %union.FPUControlStatus.14215, %union.FPUControlStatus.14215, [8 x %struct.FPUStackElem.14217], [16 x %union.vec128_t.14219] }
%union.FPUAbridgedTagWord.14214 = type { i8 }
%union.FPUControlStatus.14215 = type { i32 }
%struct.FPUStackElem.14217 = type { %union.anon.11.14216, [6 x i8] }
%union.anon.11.14216 = type { %struct.float80_t.14206 }
%union.vec128_t.14219 = type { %struct.uint128v1_t.14218 }
%struct.uint128v1_t.14218 = type { [1 x i128] }
%struct.SegmentCaches.14224 = type { %struct.SegmentShadow.14223, %struct.SegmentShadow.14223, %struct.SegmentShadow.14223, %struct.SegmentShadow.14223, %struct.SegmentShadow.14223, %struct.SegmentShadow.14223 }
%struct.SegmentShadow.14223 = type { %union.anon.14195, i32, i32 }
%struct.K_REG.14226 = type { [8 x %struct.anon.18.14225] }
%struct.anon.18.14225 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1119(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i4 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i4, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 32
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 32
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 32, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 32
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 20
  %34 = load i32, ptr %EDI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #15
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 32
  %42 = load i64, ptr %RSI, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #15
  store ptr %call.i.i3, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 7
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 8
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %49, i64 noundef %48, i32 noundef 0) #15
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 7
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RBP, align 8
  %54 = sub i64 %53, 4
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %55, i64 noundef %54, i32 noundef 0) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = add i64 %59, 14
  %61 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  store i64 %60, ptr %rip.i, align 8
  store i64 %60, ptr %NEXT_PC, align 8
  store ptr %61, ptr %MEMORY, align 8
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  ret ptr %63
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_114a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i27 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i27, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 8, %10
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %10
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 8
  %12 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %14 = and i8 %13, 1
  %conv.i.i.i = xor i8 %14, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 8
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %10
  %15 = trunc i64 %xor1.i.i.i.i to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i = and i8 %16, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %10
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %10, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 3
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i64, ptr %RAX, align 8
  %21 = load ptr, ptr %MEMORY, align 8
  %call.i.i26 = call i64 @__remill_read_memory_64(ptr noundef %21, i64 noundef %20) #15
  store i64 %call.i.i26, ptr %RAX, align 8
  store ptr %21, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %17
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 3
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call zeroext i8 @__remill_read_memory_8(ptr noundef %26, i64 noundef %25) #15
  %conv.i.i29 = zext i8 %call.i.i28 to i64
  store i64 %conv.i.i29, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %22
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i8, ptr %AL, align 1
  %31 = zext i8 %30 to i64
  %32 = load ptr, ptr %MEMORY, align 8
  %conv.i.i30 = trunc i64 %31 to i32
  %sext.i = shl i32 %conv.i.i30, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RBP, align 8
  %37 = sub i64 %36, 4
  %38 = load i32, ptr %EAX, align 4
  %39 = zext i32 %38 to i64
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %40, i64 noundef %37) #15
  %sub.i.i = sub i32 %call.i.i, %38
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, %38
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef %38, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %41 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %42 = and i8 %41, 1
  %conv.i.i.i5 = xor i8 %42, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, %38
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %43 = trunc i32 %xor1.i.i.i.i8 to i8
  %44 = lshr i8 %43, 4
  %conv2.i.i.i9 = and i8 %44, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, %38
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef %38, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef %38, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef %38, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %40, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %33
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 2
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %NEXT_PC, align 8
  %49 = sub i64 %48, 36
  %50 = load i64, ptr %NEXT_PC, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 9
  %52 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %52, 0
  %of.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 13
  %53 = load i8, ptr %of.i, align 1
  %tobool9.i = icmp ne i8 %53, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool9.i
  %call11.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i) #16
  %frombool.i = zext i1 %call11.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call11.i, i64 %49, i64 %50
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %51, ptr %MEMORY, align 8
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = load ptr, ptr %MEMORY, align 8
  ret ptr %55
}

define ptr @BB_113c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i7 = zext i32 %call.i.i6 to i64
  store i64 %conv.i.i7, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load i64, ptr %RBP, align 8
  %12 = sub i64 %11, 4
  %13 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %13, i64 noundef %12) #15
  %sext.i = shl i64 %10, 32
  %conv.i24.i = ashr exact i64 %sext.i, 32
  %conv.i25.i = sext i32 %call.i.i1 to i64
  %mul.i.i = mul nsw i64 %conv.i24.i, %conv.i25.i
  %conv.i27.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i27.i, ptr %RAX, align 8
  %14 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i2 = icmp ult i64 %14, -4294967296
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %conv.i.i, i32 noundef %call.i.i1, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i4, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %13, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %7
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RBP, align 8
  %19 = sub i64 %18, 8
  %20 = load i32, ptr %EAX, align 4
  %21 = zext i32 %20 to i64
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call ptr @__remill_write_memory_32(ptr noundef %22, i64 noundef %19, i32 noundef %20) #15
  store ptr %call.i.i5, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %15
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 4
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RBP, align 8
  %27 = sub i64 %26, 4
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 4
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #15
  %add.i.i = add i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %30, i64 noundef %27, i32 noundef %add.i.i) #15
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %31 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %31, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %32 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %33 = and i8 %32, 1
  %conv.i.i.i = xor i8 %33, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %34 = trunc i32 %xor1.i.i.i.i to i8
  %35 = lshr i8 %34, 4
  %conv2.i.i.i = and i8 %35, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %23
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1160(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %11, 4294967295
  store i64 %conv.i11.i, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = add i64 %16, 3732
  %18 = load ptr, ptr %MEMORY, align 8
  store i64 %17, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  store i64 %22, ptr %RDI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 5
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %27, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %24
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 5
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %NEXT_PC, align 8
  %32 = sub i64 %31, 297
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  %35 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %35, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %sub.i.i, i64 noundef %33) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  store i64 %32, ptr %rip.i, align 8
  store i64 %32, ptr %NEXT_PC, align 8
  store i64 %33, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  ret ptr %36
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_1179(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.14228, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 1
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 15
  %9 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %8, i64 noundef %9) #15
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %9, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %10

10:                                               ; preds = %5
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = add i64 %11, 1
  store i64 %12, ptr %NEXT_PC, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %13, i64 noundef %14) #15
  %rip.i = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %15, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %13, ptr %MEMORY, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  ret ptr %16
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.14228, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.14228) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #17
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.14228) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4377, label %bb_1119
    i64 4412, label %bb_113C
    i64 4426, label %bb_114A
    i64 4448, label %bb_1160
    i64 4473, label %bb_1179
    i64 -281474976710656, label %bb_FFFF000000000000
  ]

dead_end:                                         ; preds = %bb_FFFF000000000000, %bb_1160, %bb_114A, %bb_113C, %bb_1119, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1119:                                          ; preds = %entry
  %block_pc = add i64 4377, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4377, ptr %1)
  %4 = call ptr @BB_1119(ptr %state, i64 %2, ptr %1) #18
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4426, label %bb_114A
  ]

bb_113C:                                          ; preds = %bb_114A, %entry
  %block_pc1 = add i64 4412, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4412, ptr %6)
  %9 = call ptr @BB_113c(ptr %state, i64 %7, ptr %6) #18
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4426, label %bb_114A
  ]

bb_114A:                                          ; preds = %bb_113C, %bb_1119, %entry
  %block_pc3 = add i64 4426, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4426, ptr %11)
  %14 = call ptr @BB_114a(ptr %state, i64 %12, ptr %11) #18
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4412, label %bb_113C
    i64 4448, label %bb_1160
  ]

bb_1160:                                          ; preds = %bb_114A, %entry
  %block_pc5 = add i64 4448, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4448, ptr %16)
  %19 = call ptr @BB_1160(ptr %state, i64 %17, ptr %16) #18
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4176, label %bb_FFFF000000000000
  ]

bb_1179:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc7 = add i64 4473, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4473, ptr %21)
  %24 = call ptr @BB_1179(ptr %state, i64 %22, ptr %21) #18
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  %26 = load ptr, ptr %mem_var, align 8
  ret ptr %26

bb_FFFF000000000000:                              ; preds = %bb_1160, %entry
  %27 = load ptr, ptr %mem_var, align 8
  %28 = load i64, ptr %pc_var, align 4
  %29 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %28, ptr %27) #18
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva9 = sub i64 %30, %base
  switch i64 %next_rva9, label %dead_end [
    i64 4473, label %bb_1179
  ]

return_bb:                                        ; No predecessors!
  %31 = load ptr, ptr %mem_var, align 8
  ret ptr %31
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4377, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.14227, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !14
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #18 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15, !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C++ TBAA"}
