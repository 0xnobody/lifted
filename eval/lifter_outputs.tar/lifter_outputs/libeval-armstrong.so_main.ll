; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.18548 = type { %struct.X86State.18547 }
%struct.X86State.18547 = type { %struct.ArchState.18516, [32 x %union.VectorReg.18519], %struct.ArithFlags.18520, %union.anon.18515, %struct.Segments.18522, %struct.AddressSpace.18524, %struct.GPR.18525, %struct.X87Stack.18528, %struct.MMX.18532, %struct.FPUStatusFlags.18533, %union.anon.18515, %union.FPU.18542, %struct.SegmentCaches.18544, %struct.K_REG.18546 }
%struct.ArchState.18516 = type { i32, i32, %union.anon.18515 }
%union.VectorReg.18519 = type { %union.vec512_t.18518 }
%union.vec512_t.18518 = type { %struct.uint64v8_t.18517 }
%struct.uint64v8_t.18517 = type { [8 x i64] }
%struct.ArithFlags.18520 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.18522 = type { i16, %union.SegmentSelector.18521, i16, %union.SegmentSelector.18521, i16, %union.SegmentSelector.18521, i16, %union.SegmentSelector.18521, i16, %union.SegmentSelector.18521, i16, %union.SegmentSelector.18521 }
%union.SegmentSelector.18521 = type { i16 }
%struct.AddressSpace.18524 = type { i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523 }
%struct.Reg.18523 = type { %union.anon.18515 }
%struct.GPR.18525 = type { i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523, i64, %struct.Reg.18523 }
%struct.X87Stack.18528 = type { [8 x %struct.anon.3.18527] }
%struct.anon.3.18527 = type { [6 x i8], %struct.float80_t.18526 }
%struct.float80_t.18526 = type { [10 x i8] }
%struct.MMX.18532 = type { [8 x %struct.anon.4.18531] }
%struct.anon.4.18531 = type { i64, %union.vec64_t.18530 }
%union.vec64_t.18530 = type { %struct.uint64v1_t.18529 }
%struct.uint64v1_t.18529 = type { [1 x i64] }
%struct.FPUStatusFlags.18533 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.18515 = type { i64 }
%union.FPU.18542 = type { %struct.anon.13.18541 }
%struct.anon.13.18541 = type { %struct.FpuFXSAVE.18540, [96 x i8] }
%struct.FpuFXSAVE.18540 = type { %union.SegmentSelector.18521, %union.SegmentSelector.18521, %union.FPUAbridgedTagWord.18534, i8, i16, i32, %union.SegmentSelector.18521, i16, i32, %union.SegmentSelector.18521, i16, %union.FPUControlStatus.18535, %union.FPUControlStatus.18535, [8 x %struct.FPUStackElem.18537], [16 x %union.vec128_t.18539] }
%union.FPUAbridgedTagWord.18534 = type { i8 }
%union.FPUControlStatus.18535 = type { i32 }
%struct.FPUStackElem.18537 = type { %union.anon.11.18536, [6 x i8] }
%union.anon.11.18536 = type { %struct.float80_t.18526 }
%union.vec128_t.18539 = type { %struct.uint128v1_t.18538 }
%struct.uint128v1_t.18538 = type { [1 x i128] }
%struct.SegmentCaches.18544 = type { %struct.SegmentShadow.18543, %struct.SegmentShadow.18543, %struct.SegmentShadow.18543, %struct.SegmentShadow.18543, %struct.SegmentShadow.18543, %struct.SegmentShadow.18543 }
%struct.SegmentShadow.18543 = type { %union.anon.18515, i32, i32 }
%struct.K_REG.18546 = type { [8 x %struct.anon.18.18545] }
%struct.anon.18.18545 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1119(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i30 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i30, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 32
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 32
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 32, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 32
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 32, i64 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 20
  %34 = load i32, ptr %EDI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #15
  store ptr %call.i.i28, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 32
  %42 = load i64, ptr %RSI, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #15
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 20
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %49, i64 noundef %48) #15
  %sub.i.i1 = sub i32 %call.i.i, 1
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, 1
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %51 = and i8 %50, 1
  %conv.i.i.i6 = xor i8 %51, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, 1
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %52 = trunc i32 %xor1.i.i.i.i9 to i8
  %53 = lshr i8 %52, 4
  %conv2.i.i.i10 = and i8 %53, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, 1
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i1) #15
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %44
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  %58 = add i64 %57, 10
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %61 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %61, 0
  %sf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool10.i = icmp eq i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool12.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool10.i, %tobool12.i
  %64 = and i1 %tobool.not.i, %cmp.i.i
  %call15.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %64) #16
  %frombool.i = zext i1 %call15.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call15.i, i64 %58, i64 %59
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %60, ptr %MEMORY, align 8
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  ret ptr %66
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_113c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %6, i64 noundef %5, i32 noundef 0) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i6, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 8, %16
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %16
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 8
  %18 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %18, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %19 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %20 = and i8 %19, 1
  %conv.i.i.i = xor i8 %20, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 8
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %16
  %21 = trunc i64 %xor1.i.i.i.i to i8
  %22 = lshr i8 %21, 4
  %conv2.i.i.i = and i8 %22, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %16
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %16, i64 noundef 8, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %13
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 3
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RAX, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %27, i64 noundef %26) #15
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %27, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %23
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RAX, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  %call.i.i7 = call zeroext i8 @__remill_read_memory_8(ptr noundef %32, i64 noundef %31) #15
  %conv.i.i8 = zext i8 %call.i.i7 to i64
  store i64 %conv.i.i8, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %28
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i8, ptr %AL, align 1
  %37 = zext i8 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i.i9 = trunc i64 %37 to i32
  %sext.i = shl i32 %conv.i.i9, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RBP, align 8
  %43 = sub i64 %42, 12
  %44 = load i32, ptr %EAX, align 4
  %45 = zext i32 %44 to i64
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_32(ptr noundef %46, i64 noundef %43, i32 noundef %44) #15
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %39
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RBP, align 8
  %51 = sub i64 %50, 12
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i32 @__remill_read_memory_32(ptr noundef %52, i64 noundef %51) #15
  %conv.i.i4 = zext i32 %call.i.i3 to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RBP, align 8
  %57 = sub i64 %56, 4
  %58 = load i32, ptr %EAX, align 4
  %59 = zext i32 %58 to i64
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %60, i64 noundef %57, i32 noundef %58) #15
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %53
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 2
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %NEXT_PC, align 8
  %65 = add i64 %64, 88
  %66 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %65, ptr %rip.i, align 8
  store i64 %65, ptr %NEXT_PC, align 8
  store ptr %66, ptr %MEMORY, align 8
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = load ptr, ptr %MEMORY, align 8
  ret ptr %68
}

define ptr @BB_1132(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 5
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 184
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_11b7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 94
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_11f4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #15
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #15
  %rip.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_115f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %ECX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i206 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i207 = zext i32 %call.i.i206 to i64
  store i64 %conv.i.i207, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EDX, align 4
  %11 = zext i32 %10 to i64
  %12 = load ptr, ptr %MEMORY, align 8
  %sext.i209 = shl i64 %11, 32
  %conv.i12.i210 = ashr exact i64 %sext.i209, 32
  store i64 %conv.i12.i210, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %18 = ashr i64 %16, 63
  %L.sroa.2.0.insert.ext.i.i152 = zext i64 %18 to i128
  %L.sroa.2.0.insert.shift.i.i153 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i152, 64
  %L.sroa.0.0.insert.ext.i.i154 = zext i64 %16 to i128
  %L.sroa.0.0.insert.insert.i.i155 = or i128 %L.sroa.2.0.insert.shift.i.i153, %L.sroa.0.0.insert.ext.i.i154
  %mul.i.i156 = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i155
  %retval.sroa.0.0.extract.trunc.i.i157 = trunc i128 %mul.i.i156 to i64
  %retval.sroa.2.0.extract.shift.i.i158 = lshr i128 %mul.i.i156, 64
  %retval.sroa.2.0.extract.trunc.i.i159 = trunc i128 %retval.sroa.2.0.extract.shift.i.i158 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i157, ptr %RAX, align 8
  %conv2.i.i.i160 = sext i64 %retval.sroa.0.0.extract.trunc.i.i157 to i128
  %cmp.i.i.i161 = icmp ne i128 %mul.i.i156, %conv2.i.i.i160
  %call.i.i.i162 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i161, i64 noundef %16, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i157, i64 noundef %retval.sroa.2.0.extract.trunc.i.i159) #15
  %frombool.i.i163 = zext i1 %call.i.i.i162 to i8
  %cf.i.i164 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i163, ptr %cf.i.i164, align 1
  %call2.i.i165 = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i166 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i165, ptr %pf.i.i166, align 1
  %af.i.i167 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i165, ptr %af.i.i167, align 1
  %zf.i.i168 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i165, ptr %zf.i.i168, align 1
  %sf.i.i169 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i165, ptr %sf.i.i169, align 1
  %of.i.i170 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i163, ptr %of.i.i170, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i212 = lshr i64 %22, 31
  %call34.i213 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i214 = icmp ne i8 %call34.i213, 0
  %new_val.0.i215 = lshr i64 %shr.i136.i212, 1
  store i64 %new_val.0.i215, ptr %RAX, align 8
  %cf.i216 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %24 = trunc i64 %shr.i136.i212 to i8
  %conv.i217 = and i8 %24, 1
  store i8 %conv.i217, ptr %cf.i216, align 1
  %pf.i218 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i219 = trunc i64 %new_val.0.i215 to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i219)
  %26 = and i8 %25, 1
  %conv67.i220 = xor i8 %26, 1
  store i8 %conv67.i220, ptr %pf.i218, align 1
  %af.i221 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i213, ptr %af.i221, align 1
  %zf.i222 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i223 = icmp ult i64 %shr.i136.i212, 2
  %conv80.i224 = zext i1 %cmp.i140.i223 to i8
  store i8 %conv80.i224, ptr %zf.i222, align 1
  %sf.i225 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i225, align 1
  %of.i226 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  %conv92.i227 = zext i1 %tobool.i214 to i8
  store i8 %conv92.i227, ptr %of.i226, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %19
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %sext167.i279 = shl i64 %30, 32
  %conv.i155.i280 = ashr exact i64 %sext167.i279, 32
  %shr.i156.i281 = ashr i64 %conv.i155.i280, 1
  %call36.i282 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i283 = icmp ne i8 %call36.i282, 0
  %shr.i160.i284 = ashr i64 %shr.i156.i281, 1
  %32 = zext i1 %tobool.i283 to i8
  %new_val.0.i285 = trunc i64 %shr.i160.i284 to i32
  %conv.i163.i286 = and i64 %shr.i160.i284, 4294967295
  store i64 %conv.i163.i286, ptr %RAX, align 8
  %cf.i287 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %33 = trunc i64 %shr.i156.i281 to i8
  %conv.i288 = and i8 %33, 1
  store i8 %conv.i288, ptr %cf.i287, align 1
  %pf.i289 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i290 = trunc i64 %shr.i160.i284 to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i290)
  %35 = and i8 %34, 1
  %conv75.i291 = xor i8 %35, 1
  store i8 %conv75.i291, ptr %pf.i289, align 1
  %af.i292 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i282, ptr %af.i292, align 1
  %zf.i293 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i294 = icmp eq i32 %new_val.0.i285, 0
  %conv88.i295 = zext i1 %cmp.i165.i294 to i8
  store i8 %conv88.i295, ptr %zf.i293, align 1
  %sf.i296 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i297 = lshr i32 %new_val.0.i285, 31
  %conv95.i298 = trunc i32 %new_val.0.lobit.i297 to i8
  store i8 %conv95.i298, ptr %sf.i296, align 1
  %of.i299 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %32, ptr %of.i299, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %27
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 2
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i32, ptr %EDX, align 4
  %40 = zext i32 %39 to i64
  %41 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i201 = and i64 %40, 4294967295
  store i64 %conv.i11.i201, ptr %RSI, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RSI, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %sext167.i258 = shl i64 %45, 32
  %conv.i155.i259 = ashr exact i64 %sext167.i258, 32
  %shr.i156.i260 = ashr i64 %conv.i155.i259, 30
  %call36.i261 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i262 = icmp ne i8 %call36.i261, 0
  %shr.i160.i263 = ashr i64 %shr.i156.i260, 1
  %47 = zext i1 %tobool.i262 to i8
  %new_val.0.i264 = trunc i64 %shr.i160.i263 to i32
  %conv.i163.i265 = and i64 %shr.i160.i263, 4294967295
  store i64 %conv.i163.i265, ptr %RSI, align 8
  %cf.i266 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %48 = trunc i64 %shr.i156.i260 to i8
  %conv.i267 = and i8 %48, 1
  store i8 %conv.i267, ptr %cf.i266, align 1
  %pf.i268 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i269 = trunc i64 %shr.i160.i263 to i8
  %49 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i269)
  %50 = and i8 %49, 1
  %conv75.i270 = xor i8 %50, 1
  store i8 %conv75.i270, ptr %pf.i268, align 1
  %af.i271 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i261, ptr %af.i271, align 1
  %zf.i272 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i273 = icmp eq i32 %new_val.0.i264, 0
  %conv88.i274 = zext i1 %cmp.i165.i273 to i8
  store i8 %conv88.i274, ptr %zf.i272, align 1
  %sf.i275 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i276 = lshr i32 %new_val.0.i264, 31
  %conv95.i277 = trunc i32 %new_val.0.lobit.i276 to i8
  store i8 %conv95.i277, ptr %sf.i275, align 1
  %of.i278 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %47, ptr %of.i278, align 1
  store ptr %46, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %42
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 2
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RAX, align 8
  %55 = load i32, ptr %ESI, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i118 = trunc i64 %54 to i32
  %sub.i.i119 = sub i32 %conv.i.i118, %55
  %conv.i22.i120 = zext i32 %sub.i.i119 to i64
  store i64 %conv.i22.i120, ptr %RAX, align 8
  %cmp.i.i.i121 = icmp ult i32 %conv.i.i118, %55
  %call.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i121, i32 noundef %conv.i.i118, i32 noundef %55, i32 noundef %sub.i.i119) #15
  %conv.i23.i123 = zext i1 %call.i.i.i122 to i8
  %cf.i.i124 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i123, ptr %cf.i.i124, align 1
  %conv.i.i.i.i125 = trunc i32 %sub.i.i119 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i125)
  %59 = and i8 %58, 1
  %conv.i.i.i126 = xor i8 %59, 1
  %pf.i.i.i127 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i126, ptr %pf.i.i.i127, align 1
  %xor.i.i.i.i128 = xor i32 %55, %conv.i.i118
  %xor1.i.i.i.i129 = xor i32 %xor.i.i.i.i128, %sub.i.i119
  %60 = trunc i32 %xor1.i.i.i.i129 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i130 = and i8 %61, 1
  %af.i.i.i131 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i130, ptr %af.i.i.i131, align 1
  %cmp.i.i.i.i132 = icmp eq i32 %conv.i.i118, %55
  %call.i.i.i.i133 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i132, i32 noundef %conv.i.i118, i32 noundef %55, i32 noundef %sub.i.i119) #15
  %conv5.i.i.i134 = zext i1 %call.i.i.i.i133 to i8
  %zf.i.i.i135 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i134, ptr %zf.i.i.i135, align 1
  %cmp.i27.i.i.i136 = icmp slt i32 %sub.i.i119, 0
  %call1.i.i.i.i137 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i136, i32 noundef %conv.i.i118, i32 noundef %55, i32 noundef %sub.i.i119) #15
  %conv8.i.i.i138 = zext i1 %call1.i.i.i.i137 to i8
  %sf.i.i.i139 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i138, ptr %sf.i.i.i139, align 1
  %xor.i28.i.i.i140 = lshr i32 %xor.i.i.i.i128, 31
  %shr9.i.i.i.i141 = xor i32 %sub.i.i119, %conv.i.i118
  %xor3.i.i.i.i142 = lshr i32 %shr9.i.i.i.i141, 31
  %add.i.i.i.i143 = add nuw nsw i32 %xor3.i.i.i.i142, %xor.i28.i.i.i140
  %cmp.i29.i.i.i144 = icmp eq i32 %add.i.i.i.i143, 2
  %call.i30.i.i.i145 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i144, i32 noundef %conv.i.i118, i32 noundef %55, i32 noundef %sub.i.i119) #15
  %conv11.i.i.i146 = zext i1 %call.i30.i.i.i145 to i8
  %of.i.i.i147 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i146, ptr %of.i.i.i147, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %51
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 2
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i32, ptr %EAX, align 4
  %66 = zext i32 %65 to i64
  %67 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i200 = and i64 %66, 4294967295
  store i64 %conv.i11.i200, ptr %RCX, align 8
  store ptr %67, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %ECX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i199 = and i64 %72, 4294967295
  store i64 %conv.i11.i199, ptr %RAX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RAX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %shl.i149.i = shl i64 %77, 1
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  %conv.i155.i301 = zext i32 %conv2.i154.i to i64
  store i64 %conv.i155.i301, ptr %RAX, align 8
  %cf.i302 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv2.i150.i, 31
  %conv.i303 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i303, ptr %cf.i302, align 1
  %pf.i304 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i154.i to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %80 = and i8 %79, 1
  %conv72.i = xor i8 %80, 1
  store i8 %conv72.i, ptr %pf.i304, align 1
  %af.i305 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i305, align 1
  %zf.i306 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i154.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i306, align 1
  %sf.i307 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i308 = lshr i32 %conv2.i154.i, 31
  %conv92.i309 = trunc i32 %new_val.0.lobit.i308 to i8
  store i8 %conv92.i309, ptr %sf.i307, align 1
  %of.i310 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i310, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %74
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RAX, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %conv.i.i29 = trunc i64 %84 to i32
  %add.i.i30 = add i32 %85, %conv.i.i29
  %conv.i22.i31 = zext i32 %add.i.i30 to i64
  store i64 %conv.i22.i31, ptr %RAX, align 8
  %cmp.i.i.i32 = icmp ult i32 %add.i.i30, %conv.i.i29
  %cmp1.i.i.i33 = icmp ult i32 %add.i.i30, %85
  %88 = or i1 %cmp.i.i.i32, %cmp1.i.i.i33
  %call.i.i.i34 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %88, i32 noundef %conv.i.i29, i32 noundef %85, i32 noundef %add.i.i30) #15
  %conv.i23.i35 = zext i1 %call.i.i.i34 to i8
  %cf.i.i36 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i35, ptr %cf.i.i36, align 1
  %conv.i.i.i.i37 = trunc i32 %add.i.i30 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i37)
  %90 = and i8 %89, 1
  %conv.i.i.i38 = xor i8 %90, 1
  %pf.i.i.i39 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i38, ptr %pf.i.i.i39, align 1
  %xor.i.i.i.i40 = xor i32 %add.i.i30, %85
  %xor1.i.i.i.i41 = xor i32 %xor.i.i.i.i40, %conv.i.i29
  %91 = trunc i32 %xor1.i.i.i.i41 to i8
  %92 = lshr i8 %91, 4
  %conv2.i.i.i42 = and i8 %92, 1
  %af.i.i.i43 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i42, ptr %af.i.i.i43, align 1
  %cmp.i.i.i.i44 = icmp eq i32 %add.i.i30, 0
  %call.i.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i44, i32 noundef %conv.i.i29, i32 noundef %85, i32 noundef %add.i.i30) #15
  %conv5.i.i.i46 = zext i1 %call.i.i.i.i45 to i8
  %zf.i.i.i47 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i46, ptr %zf.i.i.i47, align 1
  %cmp.i27.i.i.i48 = icmp slt i32 %add.i.i30, 0
  %call1.i.i.i.i49 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i48, i32 noundef %conv.i.i29, i32 noundef %85, i32 noundef %add.i.i30) #15
  %conv8.i.i.i50 = zext i1 %call1.i.i.i.i49 to i8
  %sf.i.i.i51 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i50, ptr %sf.i.i.i51, align 1
  %shr8.i.i.i.i52 = xor i32 %add.i.i30, %conv.i.i29
  %xor.i28.i.i.i53 = lshr i32 %shr8.i.i.i.i52, 31
  %xor3.i.i.i.i54 = lshr i32 %xor.i.i.i.i40, 31
  %add.i.i.i.i55 = add nuw nsw i32 %xor.i28.i.i.i53, %xor3.i.i.i.i54
  %cmp.i29.i.i.i56 = icmp eq i32 %add.i.i.i.i55, 2
  %call.i30.i.i.i57 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i56, i32 noundef %conv.i.i29, i32 noundef %85, i32 noundef %add.i.i30) #15
  %conv11.i.i.i58 = zext i1 %call.i30.i.i.i57 to i8
  %of.i.i.i59 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i58, ptr %of.i.i.i59, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %81
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 2
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load i32, ptr %EAX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %96 to i32
  %add.i.i1 = add i32 %97, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i1 to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i32 %add.i.i1, %conv.i.i
  %cmp1.i.i.i3 = icmp ult i32 %add.i.i1, %97
  %100 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %100, i32 noundef %conv.i.i, i32 noundef %97, i32 noundef %add.i.i1) #15
  %conv.i23.i = zext i1 %call.i.i.i4 to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i5, align 1
  %conv.i.i.i.i6 = trunc i32 %add.i.i1 to i8
  %101 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i6)
  %102 = and i8 %101, 1
  %conv.i.i.i7 = xor i8 %102, 1
  %pf.i.i.i8 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i7, ptr %pf.i.i.i8, align 1
  %xor.i.i.i.i9 = xor i32 %add.i.i1, %97
  %xor1.i.i.i.i10 = xor i32 %xor.i.i.i.i9, %conv.i.i
  %103 = trunc i32 %xor1.i.i.i.i10 to i8
  %104 = lshr i8 %103, 4
  %conv2.i.i.i11 = and i8 %104, 1
  %af.i.i.i12 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i11, ptr %af.i.i.i12, align 1
  %cmp.i.i.i.i13 = icmp eq i32 %add.i.i1, 0
  %call.i.i.i.i14 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i13, i32 noundef %conv.i.i, i32 noundef %97, i32 noundef %add.i.i1) #15
  %conv5.i.i.i15 = zext i1 %call.i.i.i.i14 to i8
  %zf.i.i.i16 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i15, ptr %zf.i.i.i16, align 1
  %cmp.i27.i.i.i17 = icmp slt i32 %add.i.i1, 0
  %call1.i.i.i.i18 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i17, i32 noundef %conv.i.i, i32 noundef %97, i32 noundef %add.i.i1) #15
  %conv8.i.i.i19 = zext i1 %call1.i.i.i.i18 to i8
  %sf.i.i.i20 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i19, ptr %sf.i.i.i20, align 1
  %shr8.i.i.i.i21 = xor i32 %add.i.i1, %conv.i.i
  %xor.i28.i.i.i22 = lshr i32 %shr8.i.i.i.i21, 31
  %xor3.i.i.i.i23 = lshr i32 %xor.i.i.i.i9, 31
  %add.i.i.i.i24 = add nuw nsw i32 %xor.i28.i.i.i22, %xor3.i.i.i.i23
  %cmp.i29.i.i.i25 = icmp eq i32 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i32 noundef %conv.i.i, i32 noundef %97, i32 noundef %add.i.i1) #15
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %93
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 2
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RDX, align 8
  %109 = load i32, ptr %EAX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %conv.i.i88 = trunc i64 %108 to i32
  %sub.i.i89 = sub i32 %conv.i.i88, %109
  %conv.i22.i90 = zext i32 %sub.i.i89 to i64
  store i64 %conv.i22.i90, ptr %RDX, align 8
  %cmp.i.i.i91 = icmp ult i32 %conv.i.i88, %109
  %call.i.i.i92 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i91, i32 noundef %conv.i.i88, i32 noundef %109, i32 noundef %sub.i.i89) #15
  %conv.i23.i93 = zext i1 %call.i.i.i92 to i8
  %cf.i.i94 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i93, ptr %cf.i.i94, align 1
  %conv.i.i.i.i95 = trunc i32 %sub.i.i89 to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i95)
  %113 = and i8 %112, 1
  %conv.i.i.i96 = xor i8 %113, 1
  %pf.i.i.i97 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i96, ptr %pf.i.i.i97, align 1
  %xor.i.i.i.i98 = xor i32 %109, %conv.i.i88
  %xor1.i.i.i.i99 = xor i32 %xor.i.i.i.i98, %sub.i.i89
  %114 = trunc i32 %xor1.i.i.i.i99 to i8
  %115 = lshr i8 %114, 4
  %conv2.i.i.i100 = and i8 %115, 1
  %af.i.i.i101 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i100, ptr %af.i.i.i101, align 1
  %cmp.i.i.i.i102 = icmp eq i32 %conv.i.i88, %109
  %call.i.i.i.i103 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i102, i32 noundef %conv.i.i88, i32 noundef %109, i32 noundef %sub.i.i89) #15
  %conv5.i.i.i104 = zext i1 %call.i.i.i.i103 to i8
  %zf.i.i.i105 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i104, ptr %zf.i.i.i105, align 1
  %cmp.i27.i.i.i106 = icmp slt i32 %sub.i.i89, 0
  %call1.i.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i106, i32 noundef %conv.i.i88, i32 noundef %109, i32 noundef %sub.i.i89) #15
  %conv8.i.i.i108 = zext i1 %call1.i.i.i.i107 to i8
  %sf.i.i.i109 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i108, ptr %sf.i.i.i109, align 1
  %xor.i28.i.i.i110 = lshr i32 %xor.i.i.i.i98, 31
  %shr9.i.i.i.i111 = xor i32 %sub.i.i89, %conv.i.i88
  %xor3.i.i.i.i112 = lshr i32 %shr9.i.i.i.i111, 31
  %add.i.i.i.i113 = add nuw nsw i32 %xor3.i.i.i.i112, %xor.i28.i.i.i110
  %cmp.i29.i.i.i114 = icmp eq i32 %add.i.i.i.i113, 2
  %call.i30.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i114, i32 noundef %conv.i.i88, i32 noundef %109, i32 noundef %sub.i.i89) #15
  %conv11.i.i.i116 = zext i1 %call.i30.i.i.i115 to i8
  %of.i.i.i117 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i116, ptr %of.i.i.i117, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %105
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 3
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %RBP, align 8
  %120 = sub i64 %119, 16
  %121 = load i32, ptr %EDX, align 4
  %122 = zext i32 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %call.i.i197 = call ptr @__remill_write_memory_32(ptr noundef %123, i64 noundef %120, i32 noundef %121) #15
  store ptr %call.i.i197, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %116
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 3
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RBP, align 8
  %128 = sub i64 %127, 16
  %129 = load ptr, ptr %MEMORY, align 8
  %call.i.i204 = call i32 @__remill_read_memory_32(ptr noundef %129, i64 noundef %128) #15
  %conv.i.i205 = zext i32 %call.i.i204 to i64
  store i64 %conv.i.i205, ptr %RAX, align 8
  store ptr %129, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %124
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 3
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load i64, ptr %RAX, align 8
  %134 = load i32, ptr %EAX, align 4
  %135 = zext i32 %134 to i64
  %136 = load ptr, ptr %MEMORY, align 8
  %conv.i.i183 = trunc i64 %133 to i32
  %sext.i184 = shl i64 %133, 32
  %conv.i28.i = ashr exact i64 %sext.i184, 32
  %sext32.i = shl i64 %135, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i185 = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i185, 4294967295
  store i64 %conv.i31.i, ptr %RAX, align 8
  %137 = add nsw i64 %mul.i.i185, -2147483648
  %cmp.i.i.i186 = icmp ult i64 %137, -4294967296
  %call.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i186, i32 noundef %conv.i.i183, i32 noundef %134, i64 noundef %mul.i.i185) #15
  %frombool.i.i188 = zext i1 %call.i.i.i187 to i8
  %cf.i.i189 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i188, ptr %cf.i.i189, align 1
  %call1.i.i190 = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i191 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i190, ptr %pf.i.i191, align 1
  %af.i.i192 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i190, ptr %af.i.i192, align 1
  %zf.i.i193 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i190, ptr %zf.i.i193, align 1
  %sf.i.i194 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i190, ptr %sf.i.i194, align 1
  %of.i.i195 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i188, ptr %of.i.i195, align 1
  store ptr %136, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %130
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 4
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i64, ptr %RAX, align 8
  %142 = load i64, ptr %RBP, align 8
  %143 = sub i64 %142, 16
  %144 = load ptr, ptr %MEMORY, align 8
  %conv.i.i171 = trunc i64 %141 to i32
  %call.i.i172 = call i32 @__remill_read_memory_32(ptr noundef %144, i64 noundef %143) #15
  %sext.i = shl i64 %141, 32
  %conv.i24.i = ashr exact i64 %sext.i, 32
  %conv.i25.i = sext i32 %call.i.i172 to i64
  %mul.i.i173 = mul nsw i64 %conv.i24.i, %conv.i25.i
  %conv.i27.i = and i64 %mul.i.i173, 4294967295
  store i64 %conv.i27.i, ptr %RAX, align 8
  %145 = add nsw i64 %mul.i.i173, -2147483648
  %cmp.i.i.i174 = icmp ult i64 %145, -4294967296
  %call.i.i.i175 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i174, i32 noundef %conv.i.i171, i32 noundef %call.i.i172, i64 noundef %mul.i.i173) #15
  %frombool.i.i176 = zext i1 %call.i.i.i175 to i8
  %cf.i.i177 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i176, ptr %cf.i.i177, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i178 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i178, align 1
  %af.i.i179 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i179, align 1
  %zf.i.i180 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i180, align 1
  %sf.i.i181 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i181, align 1
  %of.i.i182 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i176, ptr %of.i.i182, align 1
  store ptr %144, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %138
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 3
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %RBP, align 8
  %150 = sub i64 %149, 8
  %151 = load i64, ptr %RBP, align 8
  %152 = sub i64 %151, 8
  %153 = load i32, ptr %EAX, align 4
  %154 = zext i32 %153 to i64
  %155 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %155, i64 noundef %152) #15
  %add.i.i = add i32 %call.i.i, %153
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %155, i64 noundef %150, i32 noundef %add.i.i) #15
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %153
  %156 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %156, i32 noundef %call.i.i, i32 noundef %153, i32 noundef %add.i.i) #15
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %157 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %158 = and i8 %157, 1
  %conv.i.i.i = xor i8 %158, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %153
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %159 = trunc i32 %xor1.i.i.i.i to i8
  %160 = lshr i8 %159, 4
  %conv2.i.i.i = and i8 %160, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef %153, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef %153, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef %153, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %146
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 3
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i64, ptr %RBP, align 8
  %165 = sub i64 %164, 4
  %166 = load ptr, ptr %MEMORY, align 8
  %call.i.i202 = call i32 @__remill_read_memory_32(ptr noundef %166, i64 noundef %165) #15
  %conv.i.i203 = zext i32 %call.i.i202 to i64
  store i64 %conv.i.i203, ptr %RAX, align 8
  store ptr %166, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %161
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 3
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i32, ptr %EAX, align 4
  %171 = zext i32 %170 to i64
  %172 = load ptr, ptr %MEMORY, align 8
  %sext.i208 = shl i64 %171, 32
  %conv.i12.i = ashr exact i64 %sext.i208, 32
  store i64 %conv.i12.i, ptr %RDX, align 8
  store ptr %172, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %167
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 7
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i64, ptr %RDX, align 8
  %177 = load ptr, ptr %MEMORY, align 8
  %178 = ashr i64 %176, 63
  %L.sroa.2.0.insert.ext.i.i = zext i64 %178 to i128
  %L.sroa.2.0.insert.shift.i.i = shl nuw i128 %L.sroa.2.0.insert.ext.i.i, 64
  %L.sroa.0.0.insert.ext.i.i = zext i64 %176 to i128
  %L.sroa.0.0.insert.insert.i.i = or i128 %L.sroa.2.0.insert.shift.i.i, %L.sroa.0.0.insert.ext.i.i
  %mul.i.i = mul nsw i128 1717986919, %L.sroa.0.0.insert.insert.i.i
  %retval.sroa.0.0.extract.trunc.i.i = trunc i128 %mul.i.i to i64
  %retval.sroa.2.0.extract.shift.i.i = lshr i128 %mul.i.i, 64
  %retval.sroa.2.0.extract.trunc.i.i = trunc i128 %retval.sroa.2.0.extract.shift.i.i to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i, ptr %RDX, align 8
  %conv2.i.i.i148 = sext i64 %retval.sroa.0.0.extract.trunc.i.i to i128
  %cmp.i.i.i149 = icmp ne i128 %mul.i.i, %conv2.i.i.i148
  %call.i.i.i150 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i149, i64 noundef %176, i64 noundef 1717986919, i64 noundef %retval.sroa.0.0.extract.trunc.i.i, i64 noundef %retval.sroa.2.0.extract.trunc.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i150 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i151, align 1
  %call2.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %177, ptr %MEMORY, align 8
  br label %179

179:                                              ; preds = %173
  %180 = load i64, ptr %NEXT_PC, align 8
  store i64 %180, ptr %PC, align 8
  %181 = add i64 %180, 4
  store i64 %181, ptr %NEXT_PC, align 8
  %182 = load i64, ptr %RDX, align 8
  %183 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i = lshr i64 %182, 31
  %call34.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i64 %shr.i136.i, 1
  store i64 %new_val.0.i, ptr %RDX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %184 = trunc i64 %shr.i136.i to i8
  %conv.i = and i8 %184, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i211 = trunc i64 %new_val.0.i to i8
  %185 = call i8 @llvm.ctpop.i8(i8 %conv.i.i211)
  %186 = and i8 %185, 1
  %conv67.i = xor i8 %186, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i = icmp ult i64 %shr.i136.i, 2
  %conv80.i = zext i1 %cmp.i140.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %183, ptr %MEMORY, align 8
  br label %187

187:                                              ; preds = %179
  %188 = load i64, ptr %NEXT_PC, align 8
  store i64 %188, ptr %PC, align 8
  %189 = add i64 %188, 3
  store i64 %189, ptr %NEXT_PC, align 8
  %190 = load i64, ptr %RDX, align 8
  %191 = load ptr, ptr %MEMORY, align 8
  %sext167.i237 = shl i64 %190, 32
  %conv.i155.i238 = ashr exact i64 %sext167.i237, 32
  %shr.i156.i239 = ashr i64 %conv.i155.i238, 1
  %call36.i240 = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i241 = icmp ne i8 %call36.i240, 0
  %shr.i160.i242 = ashr i64 %shr.i156.i239, 1
  %192 = zext i1 %tobool.i241 to i8
  %new_val.0.i243 = trunc i64 %shr.i160.i242 to i32
  %conv.i163.i244 = and i64 %shr.i160.i242, 4294967295
  store i64 %conv.i163.i244, ptr %RDX, align 8
  %cf.i245 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %193 = trunc i64 %shr.i156.i239 to i8
  %conv.i246 = and i8 %193, 1
  store i8 %conv.i246, ptr %cf.i245, align 1
  %pf.i247 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i248 = trunc i64 %shr.i160.i242 to i8
  %194 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i248)
  %195 = and i8 %194, 1
  %conv75.i249 = xor i8 %195, 1
  store i8 %conv75.i249, ptr %pf.i247, align 1
  %af.i250 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i240, ptr %af.i250, align 1
  %zf.i251 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i252 = icmp eq i32 %new_val.0.i243, 0
  %conv88.i253 = zext i1 %cmp.i165.i252 to i8
  store i8 %conv88.i253, ptr %zf.i251, align 1
  %sf.i254 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i255 = lshr i32 %new_val.0.i243, 31
  %conv95.i256 = trunc i32 %new_val.0.lobit.i255 to i8
  store i8 %conv95.i256, ptr %sf.i254, align 1
  %of.i257 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %192, ptr %of.i257, align 1
  store ptr %191, ptr %MEMORY, align 8
  br label %196

196:                                              ; preds = %187
  %197 = load i64, ptr %NEXT_PC, align 8
  store i64 %197, ptr %PC, align 8
  %198 = add i64 %197, 3
  store i64 %198, ptr %NEXT_PC, align 8
  %199 = load i64, ptr %RAX, align 8
  %200 = load ptr, ptr %MEMORY, align 8
  %sext167.i = shl i64 %199, 32
  %conv.i155.i = ashr exact i64 %sext167.i, 32
  %shr.i156.i = ashr i64 %conv.i155.i, 30
  %call36.i = call zeroext i8 @__remill_undefined_8() #16
  %tobool.i228 = icmp ne i8 %call36.i, 0
  %shr.i160.i = ashr i64 %shr.i156.i, 1
  %201 = zext i1 %tobool.i228 to i8
  %new_val.0.i229 = trunc i64 %shr.i160.i to i32
  %conv.i163.i = and i64 %shr.i160.i, 4294967295
  store i64 %conv.i163.i, ptr %RAX, align 8
  %cf.i230 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  %202 = trunc i64 %shr.i156.i to i8
  %conv.i231 = and i8 %202, 1
  store i8 %conv.i231, ptr %cf.i230, align 1
  %pf.i232 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  %conv.i164.i = trunc i64 %shr.i160.i to i8
  %203 = call i8 @llvm.ctpop.i8(i8 %conv.i164.i)
  %204 = and i8 %203, 1
  %conv75.i = xor i8 %204, 1
  store i8 %conv75.i, ptr %pf.i232, align 1
  %af.i233 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i, ptr %af.i233, align 1
  %zf.i234 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %cmp.i165.i = icmp eq i32 %new_val.0.i229, 0
  %conv88.i = zext i1 %cmp.i165.i to i8
  store i8 %conv88.i, ptr %zf.i234, align 1
  %sf.i235 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %new_val.0.i229, 31
  %conv95.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv95.i, ptr %sf.i235, align 1
  %of.i236 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %201, ptr %of.i236, align 1
  store ptr %200, ptr %MEMORY, align 8
  br label %205

205:                                              ; preds = %196
  %206 = load i64, ptr %NEXT_PC, align 8
  store i64 %206, ptr %PC, align 8
  %207 = add i64 %206, 2
  store i64 %207, ptr %NEXT_PC, align 8
  %208 = load i32, ptr %EAX, align 4
  %209 = zext i32 %208 to i64
  %210 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i198 = and i64 %209, 4294967295
  store i64 %conv.i11.i198, ptr %RCX, align 8
  store ptr %210, ptr %MEMORY, align 8
  br label %211

211:                                              ; preds = %205
  %212 = load i64, ptr %NEXT_PC, align 8
  store i64 %212, ptr %PC, align 8
  %213 = add i64 %212, 2
  store i64 %213, ptr %NEXT_PC, align 8
  %214 = load i32, ptr %EDX, align 4
  %215 = zext i32 %214 to i64
  %216 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %215, 4294967295
  store i64 %conv.i11.i, ptr %RAX, align 8
  store ptr %216, ptr %MEMORY, align 8
  br label %217

217:                                              ; preds = %211
  %218 = load i64, ptr %NEXT_PC, align 8
  store i64 %218, ptr %PC, align 8
  %219 = add i64 %218, 2
  store i64 %219, ptr %NEXT_PC, align 8
  %220 = load i64, ptr %RAX, align 8
  %221 = load i32, ptr %ECX, align 4
  %222 = zext i32 %221 to i64
  %223 = load ptr, ptr %MEMORY, align 8
  %conv.i.i60 = trunc i64 %220 to i32
  %sub.i.i = sub i32 %conv.i.i60, %221
  %conv.i22.i61 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i61, ptr %RAX, align 8
  %cmp.i.i.i62 = icmp ult i32 %conv.i.i60, %221
  %call.i.i.i63 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i62, i32 noundef %conv.i.i60, i32 noundef %221, i32 noundef %sub.i.i) #15
  %conv.i23.i64 = zext i1 %call.i.i.i63 to i8
  %cf.i.i65 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i64, ptr %cf.i.i65, align 1
  %conv.i.i.i.i66 = trunc i32 %sub.i.i to i8
  %224 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i66)
  %225 = and i8 %224, 1
  %conv.i.i.i67 = xor i8 %225, 1
  %pf.i.i.i68 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i67, ptr %pf.i.i.i68, align 1
  %xor.i.i.i.i69 = xor i32 %221, %conv.i.i60
  %xor1.i.i.i.i70 = xor i32 %xor.i.i.i.i69, %sub.i.i
  %226 = trunc i32 %xor1.i.i.i.i70 to i8
  %227 = lshr i8 %226, 4
  %conv2.i.i.i71 = and i8 %227, 1
  %af.i.i.i72 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i71, ptr %af.i.i.i72, align 1
  %cmp.i.i.i.i73 = icmp eq i32 %conv.i.i60, %221
  %call.i.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i73, i32 noundef %conv.i.i60, i32 noundef %221, i32 noundef %sub.i.i) #15
  %conv5.i.i.i75 = zext i1 %call.i.i.i.i74 to i8
  %zf.i.i.i76 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i75, ptr %zf.i.i.i76, align 1
  %cmp.i27.i.i.i77 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i78 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i77, i32 noundef %conv.i.i60, i32 noundef %221, i32 noundef %sub.i.i) #15
  %conv8.i.i.i79 = zext i1 %call1.i.i.i.i78 to i8
  %sf.i.i.i80 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i79, ptr %sf.i.i.i80, align 1
  %xor.i28.i.i.i81 = lshr i32 %xor.i.i.i.i69, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i60
  %xor3.i.i.i.i82 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i83 = add nuw nsw i32 %xor3.i.i.i.i82, %xor.i28.i.i.i81
  %cmp.i29.i.i.i84 = icmp eq i32 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i32 noundef %conv.i.i60, i32 noundef %221, i32 noundef %sub.i.i) #15
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %223, ptr %MEMORY, align 8
  br label %228

228:                                              ; preds = %217
  %229 = load i64, ptr %NEXT_PC, align 8
  store i64 %229, ptr %PC, align 8
  %230 = add i64 %229, 3
  store i64 %230, ptr %NEXT_PC, align 8
  %231 = load i64, ptr %RBP, align 8
  %232 = sub i64 %231, 4
  %233 = load i32, ptr %EAX, align 4
  %234 = zext i32 %233 to i64
  %235 = load ptr, ptr %MEMORY, align 8
  %call.i.i196 = call ptr @__remill_write_memory_32(ptr noundef %235, i64 noundef %232, i32 noundef %233) #15
  store ptr %call.i.i196, ptr %MEMORY, align 8
  br label %236

236:                                              ; preds = %228
  %237 = load i64, ptr %NEXT_PC, align 8
  store i64 %237, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_11bd(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 12
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #15
  %sub.i.i = sub i32 %10, %call.i.i
  %cmp.i.i.i = icmp ugt i32 %call.i.i, %10
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %15 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %16 = and i8 %15, 1
  %conv.i.i.i = xor i8 %16, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, %10
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %17 = trunc i32 %xor1.i.i.i.i to i8
  %18 = lshr i8 %17, 4
  %conv2.i.i.i = and i8 %18, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, %10
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %10
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %7
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = add i64 %22, 22
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 2, i32 7
  %26 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %26, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %23, i64 %24
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %25, ptr %MEMORY, align 8
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  ret ptr %28
}

define ptr @BB_11db(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3638
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RDI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %12
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %NEXT_PC, align 8
  %20 = sub i64 %19, 415
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %23 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %23, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %22, i64 noundef %sub.i.i, i64 noundef %21) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %20, ptr %rip.i, align 8
  store i64 %20, ptr %NEXT_PC, align 8
  store i64 %21, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  ret ptr %24
}

define ptr @BB_11c5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3636
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RDI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %12
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %NEXT_PC, align 8
  %20 = sub i64 %19, 393
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %23 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %23, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %22, i64 noundef %sub.i.i, i64 noundef %21) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %20, ptr %rip.i, align 8
  store i64 %20, ptr %NEXT_PC, align 8
  store i64 %21, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  ret ptr %24
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_11ef(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_11d9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18548, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store ptr %6, ptr %MEMORY, align 8
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  ret ptr %8
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.18548, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.18548) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #17
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.18548) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4377, label %bb_1119
    i64 4402, label %bb_1132
    i64 4412, label %bb_113C
    i64 4447, label %bb_115F
    i64 4535, label %bb_11B7
    i64 4541, label %bb_11BD
    i64 4549, label %bb_11C5
    i64 4569, label %bb_11D9
    i64 4571, label %bb_11DB
    i64 4591, label %bb_11EF
    i64 4596, label %bb_11F4
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
  ]

dead_end:                                         ; preds = %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_11EF, %bb_11DB, %bb_11D9, %bb_11C5, %bb_11BD, %bb_11B7, %bb_115F, %bb_113C, %bb_1132, %bb_1119, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1119:                                          ; preds = %entry
  %block_pc = add i64 4377, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4377, ptr %1)
  %4 = call ptr @BB_1119(ptr %state, i64 %2, ptr %1) #18
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4402, label %bb_1132
    i64 4412, label %bb_113C
  ]

bb_1132:                                          ; preds = %bb_1119, %entry
  %block_pc1 = add i64 4402, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4402, ptr %6)
  %9 = call ptr @BB_1132(ptr %state, i64 %7, ptr %6) #18
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4596, label %bb_11F4
  ]

bb_113C:                                          ; preds = %bb_1119, %entry
  %block_pc3 = add i64 4412, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4412, ptr %11)
  %14 = call ptr @BB_113c(ptr %state, i64 %12, ptr %11) #18
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4535, label %bb_11B7
  ]

bb_115F:                                          ; preds = %bb_11B7, %entry
  %block_pc5 = add i64 4447, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4447, ptr %16)
  %19 = call ptr @BB_115f(ptr %state, i64 %17, ptr %16) #18
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4535, label %bb_11B7
  ]

bb_11B7:                                          ; preds = %bb_115F, %bb_113C, %entry
  %block_pc7 = add i64 4535, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4535, ptr %21)
  %24 = call ptr @BB_11b7(ptr %state, i64 %22, ptr %21) #18
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4447, label %bb_115F
    i64 4541, label %bb_11BD
  ]

bb_11BD:                                          ; preds = %bb_11B7, %entry
  %block_pc9 = add i64 4541, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4541, ptr %26)
  %29 = call ptr @BB_11bd(ptr %state, i64 %27, ptr %26) #18
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4549, label %bb_11C5
    i64 4571, label %bb_11DB
  ]

bb_11C5:                                          ; preds = %bb_11BD, %entry
  %block_pc11 = add i64 4549, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4549, ptr %31)
  %34 = call ptr @BB_11c5(ptr %state, i64 %32, ptr %31) #18
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4176, label %bb_FFFF000000000001
  ]

bb_11D9:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc13 = add i64 4569, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4569, ptr %36)
  %39 = call ptr @BB_11d9(ptr %state, i64 %37, ptr %36) #18
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4591, label %bb_11EF
  ]

bb_11DB:                                          ; preds = %bb_11BD, %entry
  %block_pc15 = add i64 4571, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4571, ptr %41)
  %44 = call ptr @BB_11db(ptr %state, i64 %42, ptr %41) #18
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4176, label %bb_FFFF000000000000
  ]

bb_11EF:                                          ; preds = %bb_FFFF000000000000, %bb_11D9, %entry
  %block_pc17 = add i64 4591, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4591, ptr %46)
  %49 = call ptr @BB_11ef(ptr %state, i64 %47, ptr %46) #18
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4596, label %bb_11F4
  ]

bb_11F4:                                          ; preds = %bb_11EF, %bb_1132, %entry
  %block_pc19 = add i64 4596, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4596, ptr %51)
  %54 = call ptr @BB_11f4(ptr %state, i64 %52, ptr %51) #18
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  %56 = load ptr, ptr %mem_var, align 8
  ret ptr %56

bb_FFFF000000000000:                              ; preds = %bb_11DB, %entry
  %57 = load ptr, ptr %mem_var, align 8
  %58 = load i64, ptr %pc_var, align 4
  %59 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %58, ptr %57) #18
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva21 = sub i64 %60, %base
  switch i64 %next_rva21, label %dead_end [
    i64 4591, label %bb_11EF
  ]

bb_FFFF000000000001:                              ; preds = %bb_11C5, %entry
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %62, ptr %61) #18
  store ptr %63, ptr %mem_var, align 8
  %64 = call i64 @__extract_rip(ptr %state)
  store i64 %64, ptr %pc_var, align 4
  %next_rva22 = sub i64 %64, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4569, label %bb_11D9
  ]

return_bb:                                        ; No predecessors!
  %65 = load ptr, ptr %mem_var, align 8
  ret ptr %65
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4377, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18547, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !23
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #18 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24, !24, i64 0}
!24 = !{!"omnipotent char", !25, i64 0}
!25 = !{!"Simple C++ TBAA"}
