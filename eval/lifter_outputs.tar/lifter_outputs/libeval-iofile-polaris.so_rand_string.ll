; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.291467 = type { %struct.X86State.291466 }
%struct.X86State.291466 = type { %struct.ArchState.291435, [32 x %union.VectorReg.291438], %struct.ArithFlags.291439, %union.anon.291434, %struct.Segments.291441, %struct.AddressSpace.291443, %struct.GPR.291444, %struct.X87Stack.291447, %struct.MMX.291451, %struct.FPUStatusFlags.291452, %union.anon.291434, %union.FPU.291461, %struct.SegmentCaches.291463, %struct.K_REG.291465 }
%struct.ArchState.291435 = type { i32, i32, %union.anon.291434 }
%union.VectorReg.291438 = type { %union.vec512_t.291437 }
%union.vec512_t.291437 = type { %struct.uint64v8_t.291436 }
%struct.uint64v8_t.291436 = type { [8 x i64] }
%struct.ArithFlags.291439 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.291441 = type { i16, %union.SegmentSelector.291440, i16, %union.SegmentSelector.291440, i16, %union.SegmentSelector.291440, i16, %union.SegmentSelector.291440, i16, %union.SegmentSelector.291440, i16, %union.SegmentSelector.291440 }
%union.SegmentSelector.291440 = type { i16 }
%struct.AddressSpace.291443 = type { i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442 }
%struct.Reg.291442 = type { %union.anon.291434 }
%struct.GPR.291444 = type { i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442, i64, %struct.Reg.291442 }
%struct.X87Stack.291447 = type { [8 x %struct.anon.3.291446] }
%struct.anon.3.291446 = type { [6 x i8], %struct.float80_t.291445 }
%struct.float80_t.291445 = type { [10 x i8] }
%struct.MMX.291451 = type { [8 x %struct.anon.4.291450] }
%struct.anon.4.291450 = type { i64, %union.vec64_t.291449 }
%union.vec64_t.291449 = type { %struct.uint64v1_t.291448 }
%struct.uint64v1_t.291448 = type { [1 x i64] }
%struct.FPUStatusFlags.291452 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.291434 = type { i64 }
%union.FPU.291461 = type { %struct.anon.13.291460 }
%struct.anon.13.291460 = type { %struct.FpuFXSAVE.291459, [96 x i8] }
%struct.FpuFXSAVE.291459 = type { %union.SegmentSelector.291440, %union.SegmentSelector.291440, %union.FPUAbridgedTagWord.291453, i8, i16, i32, %union.SegmentSelector.291440, i16, i32, %union.SegmentSelector.291440, i16, %union.FPUControlStatus.291454, %union.FPUControlStatus.291454, [8 x %struct.FPUStackElem.291456], [16 x %union.vec128_t.291458] }
%union.FPUAbridgedTagWord.291453 = type { i8 }
%union.FPUControlStatus.291454 = type { i32 }
%struct.FPUStackElem.291456 = type { %union.anon.11.291455, [6 x i8] }
%union.anon.11.291455 = type { %struct.float80_t.291445 }
%union.vec128_t.291458 = type { %struct.uint128v1_t.291457 }
%struct.uint128v1_t.291457 = type { [1 x i128] }
%struct.SegmentCaches.291463 = type { %struct.SegmentShadow.291462, %struct.SegmentShadow.291462, %struct.SegmentShadow.291462, %struct.SegmentShadow.291462, %struct.SegmentShadow.291462, %struct.SegmentShadow.291462 }
%struct.SegmentShadow.291462 = type { %union.anon.291434, i32, i32 }
%struct.K_REG.291465 = type { [8 x %struct.anon.18.291464] }
%struct.anon.18.291464 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_2860(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %XMM0 = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 1, i32 0, i32 0, i32 0, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i42 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #16
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i42, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 128
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %15, 128
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %15, i64 noundef 128, i64 noundef %sub.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %18 = and i8 %17, 1
  %conv.i.i.i = xor i8 %18, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 128, %15
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i = and i8 %20, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %15, 128
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %15, i64 noundef 128, i64 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %15, i64 noundef 128, i64 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %15, i64 noundef 128, i64 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 4
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 8
  %26 = load i64, ptr %RDI, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_64(ptr noundef %27, i64 noundef %25, i64 noundef %26) #16
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %21
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 4
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 16
  %33 = load i64, ptr %RSI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %32, i64 noundef %33) #16
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 10
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load ptr, ptr %MEMORY, align 8
  store i64 13573712489362740, ptr %RAX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %35
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 4
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RBP, align 8
  %43 = sub i64 %42, 35
  %44 = load i64, ptr %RAX, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %45, i64 noundef %43, i64 noundef %44) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %39
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 7
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %NEXT_PC, align 8
  %50 = add i64 %49, 1960
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call float @__remill_read_memory_f32(ptr noundef %51, i64 noundef %50) #16
  %add.1.i.i7 = add i64 %50, 4
  %call.1.i.i8 = call float @__remill_read_memory_f32(ptr noundef %51, i64 noundef %add.1.i.i7) #16
  %add.2.i.i9 = add i64 %50, 8
  %call.2.i.i10 = call float @__remill_read_memory_f32(ptr noundef %51, i64 noundef %add.2.i.i9) #16
  %add.3.i.i11 = add i64 %50, 12
  %call.3.i.i12 = call float @__remill_read_memory_f32(ptr noundef %51, i64 noundef %add.3.i.i11) #16
  store float %call.i.i6, ptr %XMM0, align 1
  %arrayidx2.1.i.i13 = getelementptr inbounds [4 x float], ptr %XMM0, i64 0, i64 1
  store float %call.1.i.i8, ptr %arrayidx2.1.i.i13, align 1
  %arrayidx2.2.i.i14 = getelementptr inbounds [4 x float], ptr %XMM0, i64 0, i64 2
  store float %call.2.i.i10, ptr %arrayidx2.2.i.i14, align 1
  %arrayidx2.3.i.i15 = getelementptr inbounds [4 x float], ptr %XMM0, i64 0, i64 3
  store float %call.3.i.i12, ptr %arrayidx2.3.i.i15, align 1
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 4
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RBP, align 8
  %56 = sub i64 %55, 48
  %57 = load ptr, ptr %MEMORY, align 8
  %src.coerce.val.i23 = load <2 x float>, ptr %XMM0, align 1
  %58 = getelementptr i8, ptr %XMM0, i64 8
  %src.coerce.val9.i24 = load <2 x float>, ptr %58, align 1
  %ref.tmp.sroa.0.0.vec.extract.i25 = extractelement <2 x float> %src.coerce.val.i23, i64 0
  %call.i.i26 = call ptr @__remill_write_memory_f32(ptr noundef %57, i64 noundef %56, float noundef %ref.tmp.sroa.0.0.vec.extract.i25) #16
  %add.1.i.i27 = add i64 %56, 4
  %ref.tmp.sroa.0.4.vec.extract.i28 = extractelement <2 x float> %src.coerce.val.i23, i64 1
  %call.1.i.i29 = call ptr @__remill_write_memory_f32(ptr noundef %call.i.i26, i64 noundef %add.1.i.i27, float noundef %ref.tmp.sroa.0.4.vec.extract.i28) #16
  %add.2.i.i30 = add i64 %56, 8
  %ref.tmp.sroa.5.8.vec.extract.i31 = extractelement <2 x float> %src.coerce.val9.i24, i64 0
  %call.2.i.i32 = call ptr @__remill_write_memory_f32(ptr noundef %call.1.i.i29, i64 noundef %add.2.i.i30, float noundef %ref.tmp.sroa.5.8.vec.extract.i31) #16
  %add.3.i.i33 = add i64 %56, 12
  %ref.tmp.sroa.5.12.vec.extract.i34 = extractelement <2 x float> %src.coerce.val9.i24, i64 1
  %call.3.i.i35 = call ptr @__remill_write_memory_f32(ptr noundef %call.2.i.i32, i64 noundef %add.3.i.i33, float noundef %ref.tmp.sroa.5.12.vec.extract.i34) #16
  store ptr %call.3.i.i35, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %52
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 7
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %NEXT_PC, align 8
  %63 = add i64 %62, 1933
  %64 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call float @__remill_read_memory_f32(ptr noundef %64, i64 noundef %63) #16
  %add.1.i.i = add i64 %63, 4
  %call.1.i.i = call float @__remill_read_memory_f32(ptr noundef %64, i64 noundef %add.1.i.i) #16
  %add.2.i.i = add i64 %63, 8
  %call.2.i.i = call float @__remill_read_memory_f32(ptr noundef %64, i64 noundef %add.2.i.i) #16
  %add.3.i.i = add i64 %63, 12
  %call.3.i.i = call float @__remill_read_memory_f32(ptr noundef %64, i64 noundef %add.3.i.i) #16
  store float %call.i.i5, ptr %XMM0, align 1
  %arrayidx2.1.i.i = getelementptr inbounds [4 x float], ptr %XMM0, i64 0, i64 1
  store float %call.1.i.i, ptr %arrayidx2.1.i.i, align 1
  %arrayidx2.2.i.i = getelementptr inbounds [4 x float], ptr %XMM0, i64 0, i64 2
  store float %call.2.i.i, ptr %arrayidx2.2.i.i, align 1
  %arrayidx2.3.i.i = getelementptr inbounds [4 x float], ptr %XMM0, i64 0, i64 3
  store float %call.3.i.i, ptr %arrayidx2.3.i.i, align 1
  store ptr %64, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %59
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 4
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RBP, align 8
  %69 = sub i64 %68, 64
  %70 = load ptr, ptr %MEMORY, align 8
  %src.coerce.val.i = load <2 x float>, ptr %XMM0, align 1
  %71 = getelementptr i8, ptr %XMM0, i64 8
  %src.coerce.val9.i = load <2 x float>, ptr %71, align 1
  %ref.tmp.sroa.0.0.vec.extract.i = extractelement <2 x float> %src.coerce.val.i, i64 0
  %call.i.i16 = call ptr @__remill_write_memory_f32(ptr noundef %70, i64 noundef %69, float noundef %ref.tmp.sroa.0.0.vec.extract.i) #16
  %add.1.i.i17 = add i64 %69, 4
  %ref.tmp.sroa.0.4.vec.extract.i = extractelement <2 x float> %src.coerce.val.i, i64 1
  %call.1.i.i18 = call ptr @__remill_write_memory_f32(ptr noundef %call.i.i16, i64 noundef %add.1.i.i17, float noundef %ref.tmp.sroa.0.4.vec.extract.i) #16
  %add.2.i.i19 = add i64 %69, 8
  %ref.tmp.sroa.5.8.vec.extract.i = extractelement <2 x float> %src.coerce.val9.i, i64 0
  %call.2.i.i20 = call ptr @__remill_write_memory_f32(ptr noundef %call.1.i.i18, i64 noundef %add.2.i.i19, float noundef %ref.tmp.sroa.5.8.vec.extract.i) #16
  %add.3.i.i21 = add i64 %69, 12
  %ref.tmp.sroa.5.12.vec.extract.i = extractelement <2 x float> %src.coerce.val9.i, i64 1
  %call.3.i.i22 = call ptr @__remill_write_memory_f32(ptr noundef %call.2.i.i20, i64 noundef %add.3.i.i21, float noundef %ref.tmp.sroa.5.12.vec.extract.i) #16
  store ptr %call.3.i.i22, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %65
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RBP, align 8
  %76 = sub i64 %75, 16
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %77, i64 noundef %76) #16
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %72
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 3
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RAX, align 8
  %82 = load i64, ptr %RAX, align 8
  %83 = load ptr, ptr %MEMORY, align 8
  %and.i.i = and i64 %82, %81
  %cf.i.i37 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i37, align 1
  %conv.i.i.i38 = trunc i64 %and.i.i to i8
  %84 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i38)
  %85 = and i8 %84, 1
  %conv.i.i39 = xor i8 %85, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i39, ptr %pf.i.i, align 1
  %cmp.i.i.i40 = icmp eq i64 %and.i.i, 0
  %call.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i40, i64 noundef %81, i64 noundef %82, i64 noundef %and.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i41 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i64 %and.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i64 noundef %81, i64 noundef %82, i64 noundef %and.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %86

86:                                               ; preds = %78
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = add i64 %87, 3
  store i64 %88, ptr %NEXT_PC, align 8
  %89 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %90 = load i8, ptr %zf.i, align 1
  store i8 %90, ptr %AL, align 1
  store ptr %89, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %86
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i8, ptr %AL, align 1
  %95 = zext i8 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i36 = and i64 %95, 255
  store i64 %conv.i11.i36, ptr %RAX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %91
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 2
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i32, ptr %EAX, align 4
  %101 = zext i32 %100 to i64
  %102 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %101, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %97
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 7
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  %107 = add i64 %106, 10259
  %108 = load ptr, ptr %MEMORY, align 8
  store i64 %107, ptr %RAX, align 8
  store ptr %108, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %103
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 4
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RAX, align 8
  %113 = load i64, ptr %RCX, align 8
  %114 = mul i64 %113, 8
  %115 = add i64 %112, %114
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %116, i64 noundef %115) #16
  store i64 %call.i.i3, ptr %RAX, align 8
  store ptr %116, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %109
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 2
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %RAX, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %120, ptr %rip.i, align 8
  store i64 %120, ptr %NEXT_PC, align 8
  store ptr %121, ptr %MEMORY, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  ret ptr %122
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

; Function Attrs: mustprogress noduplicate nofree noinline nosync nounwind optnone willreturn memory(none)
declare float @__remill_read_memory_f32(ptr noundef readnone, i64 noundef) #2

; Function Attrs: mustprogress noduplicate nofree noinline nosync nounwind optnone willreturn memory(none)
declare ptr @__remill_write_memory_f32(ptr noundef, i64 noundef, float noundef) #2

define ptr @BB_2b28(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9249
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9392
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_28b3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9758
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9845
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2b5e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 120
  %12 = load i64, ptr %RAX, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %11, i64 noundef %12) #16
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 7
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  %18 = add i64 %17, 9195
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i53 = call i64 @__remill_read_memory_64(ptr noundef %19, i64 noundef %18) #16
  store i64 %call.i.i53, ptr %RAX, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %14
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 2
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RAX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %24, i64 noundef %23) #16
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %20
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 7
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %NEXT_PC, align 8
  %29 = add i64 %28, 9306
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %30, i64 noundef %29) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %25
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 3
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %RAX, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %35, i64 noundef %34) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %36 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %37 = and i8 %36, 1
  %conv.i.i.i5 = xor i8 %37, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %38 = trunc i32 %xor1.i.i.i.i8 to i8
  %39 = lshr i8 %38, 4
  %conv2.i.i.i9 = and i8 %39, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %35, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %31
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %44 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %44, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %45 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %45, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %40
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 2
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i32, ptr %EDX, align 4
  %50 = zext i32 %49 to i64
  %51 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %50, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RCX, align 8
  %56 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %55 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %57 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %57, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %59 = and i8 %58, 1
  %conv.i.i.i = xor i8 %59, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %60 = trunc i32 %xor1.i.i.i.i to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i = and i8 %61, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %56, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %52
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RCX, align 8
  %66 = load i32, ptr %EDX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %65 to i32
  %sext.i = shl i64 %65, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %67, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %69 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %69, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %66, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %62
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RCX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i55 = trunc i64 %73 to i32
  %and3.i.i = and i32 1, %conv.i.i55
  %conv.i22.i56 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i56, ptr %RCX, align 8
  %cf.i.i57 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i57, align 1
  %conv.i.i.i58 = trunc i32 %and3.i.i to i8
  %75 = and i8 %conv.i.i.i58, 1
  %conv.i23.i59 = xor i8 %75, 1
  %pf.i.i60 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i59, ptr %pf.i.i60, align 1
  %cmp.i.i.i61 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i61, i32 noundef %conv.i.i55, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i62 to i8
  %zf.i.i63 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i63, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i55, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i64 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i64, align 1
  %of.i.i65 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i65, align 1
  %af.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i66, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %70
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i32, ptr %ECX, align 4
  %80 = zext i32 %79 to i64
  %81 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %79, i32 noundef 0, i32 noundef %79) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %79 to i8
  %82 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %83 = and i8 %82, 1
  %conv.i.i.i29 = xor i8 %83, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %79, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %79, i32 noundef 0, i32 noundef %79) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %79, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %79, i32 noundef 0, i32 noundef %79) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %79, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %79, i32 noundef 0, i32 noundef %79) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %76
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 3
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %88 = load i8, ptr %zf.i, align 1
  store i8 %88, ptr %CL, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %84
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load i8, ptr %CL, align 1
  %95 = zext i8 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %95, %93
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i67 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i67, align 1
  %97 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %98 = and i8 %97, 1
  %conv.i27.i = xor i8 %98, 1
  %pf.i.i68 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i68, align 1
  %99 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i69 = and i32 %99, 255
  %cmp.i.i.i70 = icmp eq i8 %or3.i.i, 0
  %100 = trunc i64 %93 to i32
  %conv1.i.i.i = and i32 %100, 255
  %101 = trunc i64 %95 to i32
  %conv2.i.i.i71 = and i32 %101, 255
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i70, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i71, i32 noundef %conv.i.i.i69) #16
  %conv3.i.i73 = zext i1 %call.i.i.i72 to i8
  %zf.i.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i73, ptr %zf.i.i74, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i71, i32 noundef %conv.i.i.i69) #16
  %conv6.i.i75 = zext i1 %call4.i.i.i to i8
  %sf.i.i76 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i75, ptr %sf.i.i76, align 1
  %of.i.i77 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i77, align 1
  %af.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i78, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %89
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 2
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load i8, ptr %AL, align 1
  %106 = zext i8 %105 to i64
  %107 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %106
  %and3.i.i79 = trunc i64 %and3.i15.i to i8
  %cf.i.i80 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i80, align 1
  %108 = and i8 %and3.i.i79, 1
  %conv.i14.i = xor i8 %108, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i81, align 1
  %109 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i82 = and i32 %109, 255
  %cmp.i.i.i83 = icmp eq i8 %and3.i.i79, 0
  %110 = trunc i64 %106 to i32
  %conv1.i.i.i84 = and i32 %110, 255
  %call.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i83, i32 noundef %conv1.i.i.i84, i32 noundef 1, i32 noundef %conv.i.i.i82) #16
  %conv3.i.i86 = zext i1 %call.i.i.i85 to i8
  %zf.i.i87 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i86, ptr %zf.i.i87, align 1
  %call4.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i84, i32 noundef 1, i32 noundef %conv.i.i.i82) #16
  %conv6.i.i89 = zext i1 %call4.i.i.i88 to i8
  %sf.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i89, ptr %sf.i.i90, align 1
  %of.i.i91 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i91, align 1
  %af.i.i92 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i92, align 1
  store ptr %107, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %102
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 6
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i64, ptr %NEXT_PC, align 8
  %115 = add i64 %114, 5
  %116 = load i64, ptr %NEXT_PC, align 8
  %117 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %118 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %118, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %115, i64 %116
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %117, ptr %MEMORY, align 8
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = load ptr, ptr %MEMORY, align 8
  ret ptr %120
}

define ptr @BB_28e9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -1, %10
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %10
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -1
  %12 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef -1, i64 noundef %add.i.i1) #16
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %14 = and i8 %13, 1
  %conv.i.i.i8 = xor i8 %14, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -1
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %10
  %15 = trunc i64 %xor1.i.i.i.i11 to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i12 = and i8 %16, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %10, i64 noundef -1, i64 noundef %add.i.i1) #16
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %10, i64 noundef -1, i64 noundef %add.i.i1) #16
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %10
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %10, i64 noundef -1, i64 noundef %add.i.i1) #16
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 4
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i64, ptr %RBP, align 8
  %21 = sub i64 %20, 16
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_64(ptr noundef %23, i64 noundef %21, i64 noundef %22) #16
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %17
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 8
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RBP, align 8
  %28 = sub i64 %27, 72
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i97 = call ptr @__remill_write_memory_64(ptr noundef %29, i64 noundef %28, i64 noundef 0) #16
  store ptr %call.i.i97, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %24
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 7
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = add i64 %33, 10188
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call i64 @__remill_read_memory_64(ptr noundef %35, i64 noundef %34) #16
  store i64 %call.i.i104, ptr %RAX, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %30
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 4
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RAX, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  store i64 %39, ptr %RAX, align 8
  %call.i.i.i30 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %39, i64 noundef 0, i64 noundef %39) #16
  %conv.i.i31 = zext i1 %call.i.i.i30 to i8
  %cf.i.i32 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i31, ptr %cf.i.i32, align 1
  %conv.i.i.i.i33 = trunc i64 %39 to i8
  %41 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i33)
  %42 = and i8 %41, 1
  %conv.i.i.i34 = xor i8 %42, 1
  %pf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i34, ptr %pf.i.i.i35, align 1
  %af.i.i.i36 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i36, align 1
  %cmp.i.i.i.i37 = icmp eq i64 %39, 0
  %call.i.i.i.i38 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i37, i64 noundef %39, i64 noundef 0, i64 noundef %39) #16
  %conv5.i.i.i39 = zext i1 %call.i.i.i.i38 to i8
  %zf.i.i.i40 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i39, ptr %zf.i.i.i40, align 1
  %cmp.i27.i.i.i41 = icmp slt i64 %39, 0
  %call1.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i41, i64 noundef %39, i64 noundef 0, i64 noundef %39) #16
  %conv8.i.i.i43 = zext i1 %call1.i.i.i.i42 to i8
  %sf.i.i.i44 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i43, ptr %sf.i.i.i44, align 1
  %xor.i28.i.i.i45 = lshr i64 %39, 63
  %call.i30.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %39, i64 noundef 0, i64 noundef %39) #16
  %conv11.i.i.i47 = zext i1 %call.i30.i.i.i46 to i8
  %of.i.i.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i47, ptr %of.i.i.i48, align 1
  store ptr %40, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %36
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RBP, align 8
  %47 = sub i64 %46, 88
  %48 = load i64, ptr %RAX, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_64(ptr noundef %49, i64 noundef %47, i64 noundef %48) #16
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %43
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 7
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = add i64 %53, 9533
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i64 @__remill_read_memory_64(ptr noundef %55, i64 noundef %54) #16
  store i64 %call.i.i103, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call i32 @__remill_read_memory_32(ptr noundef %60, i64 noundef %59) #16
  %conv.i.i101 = zext i32 %call.i.i100 to i64
  store i64 %conv.i.i101, ptr %RDX, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %56
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 7
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %NEXT_PC, align 8
  %65 = add i64 %64, 9748
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i102 = call i64 @__remill_read_memory_64(ptr noundef %66, i64 noundef %65) #16
  store i64 %call.i.i102, ptr %RAX, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %61
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RAX, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %71, i64 noundef %70) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i49 = icmp ult i32 %call.i.i, 10
  %call.i.i.i50 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i49, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i50 to i8
  %cf.i.i51 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i51, align 1
  %conv.i.i.i.i52 = trunc i32 %sub.i.i to i8
  %72 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i52)
  %73 = and i8 %72, 1
  %conv.i.i.i53 = xor i8 %73, 1
  %pf.i.i.i54 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i53, ptr %pf.i.i.i54, align 1
  %xor.i.i.i.i55 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i56 = xor i32 %xor.i.i.i.i55, %sub.i.i
  %74 = trunc i32 %xor1.i.i.i.i56 to i8
  %75 = lshr i8 %74, 4
  %conv2.i.i.i57 = and i8 %75, 1
  %af.i.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i57, ptr %af.i.i.i58, align 1
  %cmp.i.i.i.i59 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i59, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i61 = zext i1 %call.i.i.i.i60 to i8
  %zf.i.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i61, ptr %zf.i.i.i62, align 1
  %cmp.i27.i.i.i63 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i63, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i65 = zext i1 %call1.i.i.i.i64 to i8
  %sf.i.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i65, ptr %sf.i.i.i66, align 1
  %xor.i28.i.i.i67 = lshr i32 %xor.i.i.i.i55, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i68 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i69 = add nuw nsw i32 %xor3.i.i.i.i68, %xor.i28.i.i.i67
  %cmp.i29.i.i.i70 = icmp eq i32 %add.i.i.i.i69, 2
  %call.i30.i.i.i71 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i70, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i72 = zext i1 %call.i30.i.i.i71 to i8
  %of.i.i.i73 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i72, ptr %of.i.i.i73, align 1
  store ptr %71, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %67
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %80 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %80, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %81 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %81, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %79, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 2
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %EDX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %86, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %87, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %82
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %91 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %93 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %93, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %94 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %95 = and i8 %94, 1
  %conv.i.i.i = xor i8 %95, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %96 = trunc i32 %xor1.i.i.i.i to i8
  %97 = lshr i8 %96, 4
  %conv2.i.i.i = and i8 %97, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %88
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RCX, align 8
  %102 = load i32, ptr %EDX, align 4
  %103 = zext i32 %102 to i64
  %104 = load ptr, ptr %MEMORY, align 8
  %conv.i.i92 = trunc i64 %101 to i32
  %sext.i = shl i64 %101, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %103, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %105 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i93 = icmp ult i64 %105, -4294967296
  %call.i.i.i94 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i93, i32 noundef %conv.i.i92, i32 noundef %102, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i94 to i8
  %cf.i.i95 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i95, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %98
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RCX, align 8
  %110 = load ptr, ptr %MEMORY, align 8
  %conv.i.i106 = trunc i64 %109 to i32
  %and3.i.i = and i32 1, %conv.i.i106
  %conv.i22.i107 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i107, ptr %RCX, align 8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i108, align 1
  %conv.i.i.i109 = trunc i32 %and3.i.i to i8
  %111 = and i8 %conv.i.i.i109, 1
  %conv.i23.i110 = xor i8 %111, 1
  %pf.i.i111 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i110, ptr %pf.i.i111, align 1
  %cmp.i.i.i112 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i112, i32 noundef %conv.i.i106, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i113 to i8
  %zf.i.i114 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i114, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i106, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i115 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i115, align 1
  %of.i.i116 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i116, align 1
  %af.i.i117 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i117, align 1
  store ptr %110, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %106
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i32, ptr %ECX, align 4
  %116 = zext i32 %115 to i64
  %117 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %115, i32 noundef 0, i32 noundef %115) #16
  %conv.i12.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i75, align 1
  %conv.i.i.i.i76 = trunc i32 %115 to i8
  %118 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i76)
  %119 = and i8 %118, 1
  %conv.i.i.i77 = xor i8 %119, 1
  %pf.i.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i77, ptr %pf.i.i.i78, align 1
  %af.i.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i79, align 1
  %cmp.i.i.i.i80 = icmp eq i32 %115, 0
  %call.i.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i80, i32 noundef %115, i32 noundef 0, i32 noundef %115) #16
  %conv5.i.i.i82 = zext i1 %call.i.i.i.i81 to i8
  %zf.i.i.i83 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i82, ptr %zf.i.i.i83, align 1
  %cmp.i27.i.i.i84 = icmp slt i32 %115, 0
  %call1.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i84, i32 noundef %115, i32 noundef 0, i32 noundef %115) #16
  %conv8.i.i.i86 = zext i1 %call1.i.i.i.i85 to i8
  %sf.i.i.i87 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i86, ptr %sf.i.i.i87, align 1
  %xor.i28.i.i.i88 = lshr i32 %115, 31
  %call.i30.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %115, i32 noundef 0, i32 noundef %115) #16
  %conv11.i.i.i90 = zext i1 %call.i30.i.i.i89 to i8
  %of.i.i.i91 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i90, ptr %of.i.i.i91, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %112
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 3
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i, align 1
  store i8 %124, ptr %CL, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %120
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 2
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i8, ptr %AL, align 1
  %129 = zext i8 %128 to i64
  %130 = load i8, ptr %CL, align 1
  %131 = zext i8 %130 to i64
  %132 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %131, %129
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i118 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i118, align 1
  %133 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %134 = and i8 %133, 1
  %conv.i27.i = xor i8 %134, 1
  %pf.i.i119 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i119, align 1
  %135 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i120 = and i32 %135, 255
  %cmp.i.i.i121 = icmp eq i8 %or3.i.i, 0
  %136 = trunc i64 %129 to i32
  %conv1.i.i.i = and i32 %136, 255
  %137 = trunc i64 %131 to i32
  %conv2.i.i.i122 = and i32 %137, 255
  %call.i.i.i123 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i121, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i122, i32 noundef %conv.i.i.i120) #16
  %conv3.i.i124 = zext i1 %call.i.i.i123 to i8
  %zf.i.i125 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i124, ptr %zf.i.i125, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i122, i32 noundef %conv.i.i.i120) #16
  %conv6.i.i126 = zext i1 %call4.i.i.i to i8
  %sf.i.i127 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i126, ptr %sf.i.i127, align 1
  %of.i.i128 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i128, align 1
  %af.i.i129 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i129, align 1
  store ptr %132, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %125
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 2
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i8, ptr %AL, align 1
  %142 = zext i8 %141 to i64
  %143 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %142
  %and3.i.i130 = trunc i64 %and3.i15.i to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i131, align 1
  %144 = and i8 %and3.i.i130, 1
  %conv.i14.i = xor i8 %144, 1
  %pf.i.i132 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i132, align 1
  %145 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i133 = and i32 %145, 255
  %cmp.i.i.i134 = icmp eq i8 %and3.i.i130, 0
  %146 = trunc i64 %142 to i32
  %conv1.i.i.i135 = and i32 %146, 255
  %call.i.i.i136 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i134, i32 noundef %conv1.i.i.i135, i32 noundef 1, i32 noundef %conv.i.i.i133) #16
  %conv3.i.i137 = zext i1 %call.i.i.i136 to i8
  %zf.i.i138 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i137, ptr %zf.i.i138, align 1
  %call4.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i135, i32 noundef 1, i32 noundef %conv.i.i.i133) #16
  %conv6.i.i140 = zext i1 %call4.i.i.i139 to i8
  %sf.i.i141 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i140, ptr %sf.i.i141, align 1
  %of.i.i142 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i142, align 1
  %af.i.i143 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i143, align 1
  store ptr %143, ptr %MEMORY, align 8
  br label %147

147:                                              ; preds = %138
  %148 = load i64, ptr %NEXT_PC, align 8
  store i64 %148, ptr %PC, align 8
  %149 = add i64 %148, 6
  store i64 %149, ptr %NEXT_PC, align 8
  %150 = load i64, ptr %NEXT_PC, align 8
  %151 = add i64 %150, 5
  %152 = load i64, ptr %NEXT_PC, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  %zf.i96 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %154 = load i8, ptr %zf.i96, align 1
  %tobool.not.i = icmp eq i8 %154, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %151, i64 %152
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %153, ptr %MEMORY, align 8
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = load ptr, ptr %MEMORY, align 8
  ret ptr %156
}

define ptr @BB_2b9c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 120
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 7
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 128, %10
  store i64 %add.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %10
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 128
  %12 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef 128, i64 noundef %add.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %14 = and i8 %13, 1
  %conv.i.i.i = xor i8 %14, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 128
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %10
  %15 = trunc i64 %xor1.i.i.i.i to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i = and i8 %16, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %10, i64 noundef 128, i64 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %10, i64 noundef 128, i64 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %10
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %10, i64 noundef 128, i64 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i3, align 8
  %add.i.i4 = add i64 %21, 8
  store i64 %add.i.i4, ptr %rsp.i3, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #16
  store i64 %call.i.i5, ptr %RBP, align 8
  store ptr %20, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %17
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 1
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  %26 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %26) #16
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %rsp.i, align 8
  %add.i.i1 = add i64 %27, 8
  store i64 %add.i.i1, ptr %rsp.i, align 8
  store ptr %25, ptr %MEMORY, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  ret ptr %28
}

define ptr @BB_2942(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 88
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2948(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 16
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i4, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RCX, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %16, %17
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %16, %17
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %sub.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %19 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %20 = and i8 %19, 1
  %conv.i.i.i = xor i8 %20, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %17, %16
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %21 = trunc i64 %xor1.i.i.i.i to i8
  %22 = lshr i8 %21, 4
  %conv2.i.i.i = and i8 %22, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %16, %17
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %16
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %16, i64 noundef %17, i64 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %18, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %13
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 5
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  store i64 4, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %23
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %30 to i32
  %cf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  %32 = load i8, ptr %cf.i, align 1
  %conv.i42.i = zext i8 %32 to i32
  %sub.i43.i = sub i32 %conv.i.i1, %conv.i42.i
  %conv.i44.i = zext i32 %sub.i43.i to i64
  store i64 %conv.i44.i, ptr %RAX, align 8
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %conv.i.i1) #16
  br i1 %call.i.i.i2, label %_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit, label %lor.rhs.i.i

lor.rhs.i.i:                                      ; preds = %27
  %cmp.i3.i.i = icmp ult i32 %conv.i.i1, %conv.i42.i
  %call.i4.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i3.i.i, i32 noundef %conv.i.i1, i32 noundef %conv.i42.i, i32 noundef %sub.i43.i) #16
  %33 = zext i1 %call.i4.i.i to i8
  br label %_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit

_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit: ; preds = %lor.rhs.i.i, %27
  %conv.i = phi i8 [ 1, %27 ], [ %33, %lor.rhs.i.i ]
  store i8 %conv.i, ptr %cf.i, align 1
  %conv.i.i.i3 = trunc i32 %sub.i43.i to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i3)
  %35 = and i8 %34, 1
  %conv.i45.i = xor i8 %35, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i45.i, ptr %pf.i.i, align 1
  %xor1.i.i.i = xor i32 %sub.i43.i, %conv.i.i1
  %36 = trunc i32 %xor1.i.i.i to i8
  %37 = lshr i8 %36, 4
  %conv2.i.i = and i8 %37, 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i, ptr %af.i.i, align 1
  %cmp.i.i46.i = icmp eq i32 %conv.i.i1, %conv.i42.i
  %call.i.i47.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i46.i, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %sub.i43.i) #16
  %conv5.i.i = zext i1 %call.i.i47.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i, ptr %zf.i.i, align 1
  %cmp.i27.i.i = icmp slt i32 %sub.i43.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %sub.i43.i) #16
  %conv8.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i, ptr %sf.i.i, align 1
  %xor.i28.i.i = lshr i32 %conv.i.i1, 31
  %shr9.i.i.i = xor i32 %sub.i43.i, %conv.i.i1
  %xor3.i.i.i = lshr i32 %shr9.i.i.i, 31
  %add.i.i.i = add nuw nsw i32 %xor3.i.i.i, %xor.i28.i.i
  %cmp.i29.i.i = icmp eq i32 %add.i.i.i, 2
  %call.i30.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %sub.i43.i) #16
  %conv11.i.i = zext i1 %call.i30.i.i to i8
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i, ptr %of.i.i, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 2
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i32, ptr %EAX, align 4
  %42 = zext i32 %41 to i64
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %42, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %43, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %38
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 7
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = add i64 %47, 10076
  %49 = load ptr, ptr %MEMORY, align 8
  store i64 %48, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 4
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RAX, align 8
  %54 = load i64, ptr %RCX, align 8
  %55 = mul i64 %54, 8
  %56 = add i64 %53, %55
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %57, i64 noundef %56) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %50
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 2
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RAX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %61, ptr %rip.i, align 8
  store i64 %61, ptr %NEXT_PC, align 8
  store ptr %62, ptr %MEMORY, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  ret ptr %63
}

define ptr @BB_2a9b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9414
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9517
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_296a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9431
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9678
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2ad1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i76 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i76, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 16
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i75 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #16
  store i64 %call.i.i75, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RCX, align 8
  %18 = mul i64 %17, 1
  %19 = add i64 %16, %18
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_8(ptr noundef %20, i64 noundef %19, i8 noundef zeroext 0) #16
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 9700
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #16
  store i64 %call.i.i74, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 4
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  store i64 %30, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %30, i64 noundef 0, i64 noundef %30) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %30 to i8
  %32 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %33 = and i8 %32, 1
  %conv.i.i.i5 = xor i8 %33, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %30, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %30, i64 noundef 0, i64 noundef %30) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %30, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %30, i64 noundef 0, i64 noundef %30) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %30, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %30, i64 noundef 0, i64 noundef %30) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %27
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 4
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RBP, align 8
  %38 = sub i64 %37, 112
  %39 = load i64, ptr %RAX, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_64(ptr noundef %40, i64 noundef %38, i64 noundef %39) #16
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %34
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 7
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %NEXT_PC, align 8
  %45 = add i64 %44, 9325
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %46, i64 noundef %45) #16
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %51, i64 noundef %50) #16
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RDX, align 8
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %47
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 7
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %NEXT_PC, align 8
  %56 = add i64 %55, 9460
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %57, i64 noundef %56) #16
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RAX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %62, i64 noundef %61) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %63 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %64 = and i8 %63, 1
  %conv.i.i.i24 = xor i8 %64, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %65 = trunc i32 %xor1.i.i.i.i27 to i8
  %66 = lshr i8 %65, 4
  %conv2.i.i.i28 = and i8 %66, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %58
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %71 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %71, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %72 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %72, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 2
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i32, ptr %EDX, align 4
  %77 = zext i32 %76 to i64
  %78 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %77, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %78, ptr %MEMORY, align 8
  br label %79

79:                                               ; preds = %73
  %80 = load i64, ptr %NEXT_PC, align 8
  store i64 %80, ptr %PC, align 8
  %81 = add i64 %80, 3
  store i64 %81, ptr %NEXT_PC, align 8
  %82 = load i64, ptr %RCX, align 8
  %83 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %82 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %84 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %84, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %85 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %86 = and i8 %85, 1
  %conv.i.i.i = xor i8 %86, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %87 = trunc i32 %xor1.i.i.i.i to i8
  %88 = lshr i8 %87, 4
  %conv2.i.i.i = and i8 %88, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %79
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 3
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RCX, align 8
  %93 = load i32, ptr %EDX, align 4
  %94 = zext i32 %93 to i64
  %95 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %92 to i32
  %sext.i = shl i64 %92, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %94, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %96 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %96, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %93, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %95, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %89
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load ptr, ptr %MEMORY, align 8
  %conv.i.i77 = trunc i64 %100 to i32
  %and3.i.i = and i32 1, %conv.i.i77
  %conv.i22.i78 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i78, ptr %RCX, align 8
  %cf.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i79, align 1
  %conv.i.i.i80 = trunc i32 %and3.i.i to i8
  %102 = and i8 %conv.i.i.i80, 1
  %conv.i23.i81 = xor i8 %102, 1
  %pf.i.i82 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i81, ptr %pf.i.i82, align 1
  %cmp.i.i.i83 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i83, i32 noundef %conv.i.i77, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i84 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i85, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i77, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i86 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i86, align 1
  %of.i.i87 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i87, align 1
  %af.i.i88 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i88, align 1
  store ptr %101, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %97
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 3
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i32, ptr %ECX, align 4
  %107 = zext i32 %106 to i64
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %106, i32 noundef 0, i32 noundef %106) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %106 to i8
  %109 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %110 = and i8 %109, 1
  %conv.i.i.i48 = xor i8 %110, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %106, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %106, i32 noundef 0, i32 noundef %106) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %106, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %106, i32 noundef 0, i32 noundef %106) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %106, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %106, i32 noundef 0, i32 noundef %106) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %108, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %103
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %115 = load i8, ptr %zf.i, align 1
  store i8 %115, ptr %CL, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %111
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 2
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i8, ptr %AL, align 1
  %120 = zext i8 %119 to i64
  %121 = load i8, ptr %CL, align 1
  %122 = zext i8 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %122, %120
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i89 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i89, align 1
  %124 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %125 = and i8 %124, 1
  %conv.i27.i = xor i8 %125, 1
  %pf.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i90, align 1
  %126 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i91 = and i32 %126, 255
  %cmp.i.i.i92 = icmp eq i8 %or3.i.i, 0
  %127 = trunc i64 %120 to i32
  %conv1.i.i.i = and i32 %127, 255
  %128 = trunc i64 %122 to i32
  %conv2.i.i.i93 = and i32 %128, 255
  %call.i.i.i94 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i92, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i93, i32 noundef %conv.i.i.i91) #16
  %conv3.i.i95 = zext i1 %call.i.i.i94 to i8
  %zf.i.i96 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i95, ptr %zf.i.i96, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i93, i32 noundef %conv.i.i.i91) #16
  %conv6.i.i97 = zext i1 %call4.i.i.i to i8
  %sf.i.i98 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i97, ptr %sf.i.i98, align 1
  %of.i.i99 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i99, align 1
  %af.i.i100 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i100, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %116
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 2
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i8, ptr %AL, align 1
  %133 = zext i8 %132 to i64
  %134 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %133
  %and3.i.i101 = trunc i64 %and3.i15.i to i8
  %cf.i.i102 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i102, align 1
  %135 = and i8 %and3.i.i101, 1
  %conv.i14.i = xor i8 %135, 1
  %pf.i.i103 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i103, align 1
  %136 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i104 = and i32 %136, 255
  %cmp.i.i.i105 = icmp eq i8 %and3.i.i101, 0
  %137 = trunc i64 %133 to i32
  %conv1.i.i.i106 = and i32 %137, 255
  %call.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i105, i32 noundef %conv1.i.i.i106, i32 noundef 1, i32 noundef %conv.i.i.i104) #16
  %conv3.i.i108 = zext i1 %call.i.i.i107 to i8
  %zf.i.i109 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i108, ptr %zf.i.i109, align 1
  %call4.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i106, i32 noundef 1, i32 noundef %conv.i.i.i104) #16
  %conv6.i.i111 = zext i1 %call4.i.i.i110 to i8
  %sf.i.i112 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i111, ptr %sf.i.i112, align 1
  %of.i.i113 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i113, align 1
  %af.i.i114 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i114, align 1
  store ptr %134, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %129
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 6
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i64, ptr %NEXT_PC, align 8
  %142 = add i64 %141, 5
  %143 = load i64, ptr %NEXT_PC, align 8
  %144 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %145 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %145, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %142, i64 %143
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %144, ptr %MEMORY, align 8
  %146 = load i64, ptr %NEXT_PC, align 8
  store i64 %146, ptr %PC, align 8
  %147 = load ptr, ptr %MEMORY, align 8
  ret ptr %147
}

define ptr @BB_29a0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = sub i64 %4, 2293
  %6 = load i64, ptr %NEXT_PC, align 8
  %7 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  %8 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %8, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %7, i64 noundef %sub.i.i, i64 noundef %6) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store i64 %6, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  ret ptr %9
}

define ptr @BB_2b22(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 112
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #3 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_rand(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #4

declare ptr @__lifted_ext_call_rand(ptr, i64, ptr) #3

define ptr @BB_29a5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %DL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 36, ptr %RCX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 1
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  %rdx.i73 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 7
  %rax.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 1
  %9 = load i32, ptr %rax.i74, align 8
  %10 = ashr i32 %9, 31
  %conv.i13.i = zext i32 %10 to i64
  store i64 %conv.i13.i, ptr %rdx.i73, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %5
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 2
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load i32, ptr %ECX, align 4
  %15 = zext i32 %14 to i64
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 1
  %18 = load i32, ptr %rax.i, align 8
  %rdx.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 7
  %19 = load i32, ptr %rdx.i, align 8
  %sext.i67 = shl i64 %15, 32
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %16, ptr %rip.i, align 8
  %tobool.not.i.not.i = icmp eq i64 %sext.i67, 0
  br i1 %tobool.not.i.not.i, label %if.then.i, label %if.else.i

if.then.i:                                        ; preds = %11
  %call29.i = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %16, ptr noundef %17) #18
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

if.else.i:                                        ; preds = %11
  %conv.i118.i = ashr exact i64 %sext.i67, 32
  %conv.i.i68 = zext i32 %18 to i64
  %conv.i116.i = zext i32 %19 to i64
  %shl.i.i = shl nuw i64 %conv.i116.i, 32
  %or.i.i = or i64 %shl.i.i, %conv.i.i68
  %div.i.i = sdiv i64 %or.i.i, %conv.i118.i
  %rem.i.i = srem i64 %or.i.i, %conv.i118.i
  %20 = add i64 %div.i.i, 2147483648
  %cmp.not.i = icmp ult i64 %20, 4294967296
  br i1 %cmp.not.i, label %do.body42.i, label %if.then35.i

if.then35.i:                                      ; preds = %if.else.i
  %call39.i = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %16, ptr noundef %17) #18
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

do.body42.i:                                      ; preds = %if.else.i
  %conv.i123.i = and i64 %div.i.i, 4294967295
  store i64 %conv.i123.i, ptr %rax.i, align 8
  %conv.i124.i = and i64 %rem.i.i, 4294967295
  store i64 %conv.i124.i, ptr %rdx.i, align 8
  %call64.i = call zeroext i8 @__remill_undefined_8() #17
  %cf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i, ptr %of.i, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit: ; preds = %do.body42.i, %if.then35.i, %if.then.i
  %retval.1.i = phi ptr [ %call29.i, %if.then.i ], [ %call39.i, %if.then35.i ], [ %17, %do.body42.i ]
  store ptr %retval.1.i, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 76
  %26 = load i32, ptr %EDX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i76 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #16
  store ptr %call.i.i76, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 76
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i86 = call i32 @__remill_read_memory_32(ptr noundef %34, i64 noundef %33) #16
  %conv.i.i87 = sext i32 %call.i.i86 to i64
  store i64 %conv.i.i87, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = load i64, ptr %RAX, align 8
  %40 = mul i64 %39, 1
  %41 = add i64 %38, %40
  %42 = sub i64 %41, 64
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call zeroext i8 @__remill_read_memory_8(ptr noundef %43, i64 noundef %42) #16
  store i8 %call.i.i78, ptr %DL, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %35
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 8
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i85 = call i64 @__remill_read_memory_64(ptr noundef %49, i64 noundef %48) #16
  store i64 %call.i.i85, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 4
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RBP, align 8
  %54 = sub i64 %53, 72
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i84 = call i64 @__remill_read_memory_64(ptr noundef %55, i64 noundef %54) #16
  store i64 %call.i.i84, ptr %RCX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 3
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = mul i64 %60, 1
  %62 = add i64 %59, %61
  %63 = load i8, ptr %DL, align 1
  %64 = zext i8 %63 to i64
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i75 = call ptr @__remill_write_memory_8(ptr noundef %65, i64 noundef %62, i8 noundef zeroext %63) #16
  store ptr %call.i.i75, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %56
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 7
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %NEXT_PC, align 8
  %70 = add i64 %69, 10014
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i83 = call i64 @__remill_read_memory_64(ptr noundef %71, i64 noundef %70) #16
  store i64 %call.i.i83, ptr %RAX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %66
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RAX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  store i64 %75, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %75, i64 noundef 0, i64 noundef %75) #16
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %75 to i8
  %77 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %78 = and i8 %77, 1
  %conv.i.i.i5 = xor i8 %78, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %75, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %75, i64 noundef 0, i64 noundef %75) #16
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %75, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %75, i64 noundef 0, i64 noundef %75) #16
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %75, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %75, i64 noundef 0, i64 noundef %75) #16
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %79

79:                                               ; preds = %72
  %80 = load i64, ptr %NEXT_PC, align 8
  store i64 %80, ptr %PC, align 8
  %81 = add i64 %80, 4
  store i64 %81, ptr %NEXT_PC, align 8
  %82 = load i64, ptr %RBP, align 8
  %83 = sub i64 %82, 96
  %84 = load i64, ptr %RAX, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_64(ptr noundef %85, i64 noundef %83, i64 noundef %84) #16
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %86

86:                                               ; preds = %79
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = add i64 %87, 7
  store i64 %88, ptr %NEXT_PC, align 8
  %89 = load i64, ptr %NEXT_PC, align 8
  %90 = add i64 %89, 9351
  %91 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %91, i64 noundef %90) #16
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %91, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %86
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 2
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RAX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call i32 @__remill_read_memory_32(ptr noundef %96, i64 noundef %95) #16
  %conv.i.i80 = zext i32 %call.i.i79 to i64
  store i64 %conv.i.i80, ptr %RDX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %92
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 7
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %NEXT_PC, align 8
  %101 = add i64 %100, 9566
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %102, i64 noundef %101) #16
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %97
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 3
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RAX, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %107, i64 noundef %106) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %108 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %109 = and i8 %108, 1
  %conv.i.i.i24 = xor i8 %109, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %110 = trunc i32 %xor1.i.i.i.i27 to i8
  %111 = lshr i8 %110, 4
  %conv2.i.i.i28 = and i8 %111, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %107, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %103
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %sf.i69 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %116 = load i8, ptr %sf.i69, align 1
  %tobool.i = icmp ne i8 %116, 0
  %of.i70 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %117 = load i8, ptr %of.i70, align 1
  %tobool2.i = icmp ne i8 %117, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %115, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %112
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 2
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i32, ptr %EDX, align 4
  %122 = zext i32 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %122, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %123, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %118
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 3
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RCX, align 8
  %128 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %127 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %129 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %129, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %130 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %131 = and i8 %130, 1
  %conv.i.i.i = xor i8 %131, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %132 = trunc i32 %xor1.i.i.i.i to i8
  %133 = lshr i8 %132, 4
  %conv2.i.i.i = and i8 %133, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %128, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %124
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 3
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RCX, align 8
  %138 = load i32, ptr %EDX, align 4
  %139 = zext i32 %138 to i64
  %140 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %137 to i32
  %sext.i = shl i64 %137, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %139, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %141 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %141, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %138, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %134
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RCX, align 8
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i88 = trunc i64 %145 to i32
  %and3.i.i = and i32 1, %conv.i.i88
  %conv.i22.i89 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i89, ptr %RCX, align 8
  %cf.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i90, align 1
  %conv.i.i.i91 = trunc i32 %and3.i.i to i8
  %147 = and i8 %conv.i.i.i91, 1
  %conv.i23.i92 = xor i8 %147, 1
  %pf.i.i93 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i92, ptr %pf.i.i93, align 1
  %cmp.i.i.i94 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i88, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i95 to i8
  %zf.i.i96 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i96, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i88, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i97 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i97, align 1
  %of.i.i98 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i98, align 1
  %af.i.i99 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i99, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i32, ptr %ECX, align 4
  %152 = zext i32 %151 to i64
  %153 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %151, i32 noundef 0, i32 noundef %151) #16
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %151 to i8
  %154 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %155 = and i8 %154, 1
  %conv.i.i.i48 = xor i8 %155, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %151, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %151, i32 noundef 0, i32 noundef %151) #16
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %151, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %151, i32 noundef 0, i32 noundef %151) #16
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %151, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %151, i32 noundef 0, i32 noundef %151) #16
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %153, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %148
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 3
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load ptr, ptr %MEMORY, align 8
  %zf.i71 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %160 = load i8, ptr %zf.i71, align 1
  store i8 %160, ptr %CL, align 1
  store ptr %159, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %156
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 2
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i8, ptr %AL, align 1
  %165 = zext i8 %164 to i64
  %166 = load i8, ptr %CL, align 1
  %167 = zext i8 %166 to i64
  %168 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %167, %165
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i100 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i100, align 1
  %169 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %170 = and i8 %169, 1
  %conv.i27.i = xor i8 %170, 1
  %pf.i.i101 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i101, align 1
  %171 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i102 = and i32 %171, 255
  %cmp.i.i.i103 = icmp eq i8 %or3.i.i, 0
  %172 = trunc i64 %165 to i32
  %conv1.i.i.i = and i32 %172, 255
  %173 = trunc i64 %167 to i32
  %conv2.i.i.i104 = and i32 %173, 255
  %call.i.i.i105 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i103, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i104, i32 noundef %conv.i.i.i102) #16
  %conv3.i.i106 = zext i1 %call.i.i.i105 to i8
  %zf.i.i107 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i106, ptr %zf.i.i107, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i104, i32 noundef %conv.i.i.i102) #16
  %conv6.i.i108 = zext i1 %call4.i.i.i to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i111, align 1
  store ptr %168, ptr %MEMORY, align 8
  br label %174

174:                                              ; preds = %161
  %175 = load i64, ptr %NEXT_PC, align 8
  store i64 %175, ptr %PC, align 8
  %176 = add i64 %175, 2
  store i64 %176, ptr %NEXT_PC, align 8
  %177 = load i8, ptr %AL, align 1
  %178 = zext i8 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %178
  %and3.i.i112 = trunc i64 %and3.i15.i to i8
  %cf.i.i113 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i113, align 1
  %180 = and i8 %and3.i.i112, 1
  %conv.i14.i = xor i8 %180, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i114, align 1
  %181 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i115 = and i32 %181, 255
  %cmp.i.i.i116 = icmp eq i8 %and3.i.i112, 0
  %182 = trunc i64 %178 to i32
  %conv1.i.i.i117 = and i32 %182, 255
  %call.i.i.i118 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i116, i32 noundef %conv1.i.i.i117, i32 noundef 1, i32 noundef %conv.i.i.i115) #16
  %conv3.i.i119 = zext i1 %call.i.i.i118 to i8
  %zf.i.i120 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i119, ptr %zf.i.i120, align 1
  %call4.i.i.i121 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i117, i32 noundef 1, i32 noundef %conv.i.i.i115) #16
  %conv6.i.i122 = zext i1 %call4.i.i.i121 to i8
  %sf.i.i123 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i122, ptr %sf.i.i123, align 1
  %of.i.i124 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i124, align 1
  %af.i.i125 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i125, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %174
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 6
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i64, ptr %NEXT_PC, align 8
  %187 = add i64 %186, 5
  %188 = load i64, ptr %NEXT_PC, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %zf.i72 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %190 = load i8, ptr %zf.i72, align 1
  %tobool.not.i = icmp eq i8 %190, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %187, i64 %188
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %189, ptr %MEMORY, align 8
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = load ptr, ptr %MEMORY, align 8
  ret ptr %192
}

define ptr @BB_2a08(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 96
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2a0e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9283
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #16
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9482
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #16
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #16
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #16
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #16
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2a44(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i104, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 1, %10
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %10
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, 1
  %12 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %12, i64 noundef %10, i64 noundef 1, i64 noundef %add.i.i1) #16
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %13 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %14 = and i8 %13, 1
  %conv.i.i.i8 = xor i8 %14, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, 1
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %10
  %15 = trunc i64 %xor1.i.i.i.i11 to i8
  %16 = lshr i8 %15, 4
  %conv2.i.i.i12 = and i8 %16, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %10, i64 noundef 1, i64 noundef %add.i.i1) #16
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %10, i64 noundef 1, i64 noundef %add.i.i1) #16
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %10
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %10, i64 noundef 1, i64 noundef %add.i.i1) #16
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %7
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 4
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i64, ptr %RBP, align 8
  %21 = sub i64 %20, 72
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_64(ptr noundef %23, i64 noundef %21, i64 noundef %22) #16
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %17
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 7
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %NEXT_PC, align 8
  %28 = add i64 %27, 9849
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i64 @__remill_read_memory_64(ptr noundef %29, i64 noundef %28) #16
  store i64 %call.i.i103, ptr %RAX, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %24
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 4
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  store i64 %33, ptr %RAX, align 8
  %call.i.i.i30 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %33, i64 noundef 0, i64 noundef %33) #16
  %conv.i.i31 = zext i1 %call.i.i.i30 to i8
  %cf.i.i32 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i31, ptr %cf.i.i32, align 1
  %conv.i.i.i.i33 = trunc i64 %33 to i8
  %35 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i33)
  %36 = and i8 %35, 1
  %conv.i.i.i34 = xor i8 %36, 1
  %pf.i.i.i35 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i34, ptr %pf.i.i.i35, align 1
  %af.i.i.i36 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i36, align 1
  %cmp.i.i.i.i37 = icmp eq i64 %33, 0
  %call.i.i.i.i38 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i37, i64 noundef %33, i64 noundef 0, i64 noundef %33) #16
  %conv5.i.i.i39 = zext i1 %call.i.i.i.i38 to i8
  %zf.i.i.i40 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i39, ptr %zf.i.i.i40, align 1
  %cmp.i27.i.i.i41 = icmp slt i64 %33, 0
  %call1.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i41, i64 noundef %33, i64 noundef 0, i64 noundef %33) #16
  %conv8.i.i.i43 = zext i1 %call1.i.i.i.i42 to i8
  %sf.i.i.i44 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i43, ptr %sf.i.i.i44, align 1
  %xor.i28.i.i.i45 = lshr i64 %33, 63
  %call.i30.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %33, i64 noundef 0, i64 noundef %33) #16
  %conv11.i.i.i47 = zext i1 %call.i30.i.i.i46 to i8
  %of.i.i.i48 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i47, ptr %of.i.i.i48, align 1
  store ptr %34, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %30
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 104
  %42 = load i64, ptr %RAX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i97 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #16
  store ptr %call.i.i97, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 7
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = add i64 %47, 9178
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i102 = call i64 @__remill_read_memory_64(ptr noundef %49, i64 noundef %48) #16
  store i64 %call.i.i102, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 2
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RAX, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call i32 @__remill_read_memory_32(ptr noundef %54, i64 noundef %53) #16
  %conv.i.i100 = zext i32 %call.i.i99 to i64
  store i64 %conv.i.i100, ptr %RDX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %50
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 7
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %NEXT_PC, align 8
  %59 = add i64 %58, 9585
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i64 @__remill_read_memory_64(ptr noundef %60, i64 noundef %59) #16
  store i64 %call.i.i101, ptr %RAX, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %55
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 3
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %RAX, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %65, i64 noundef %64) #16
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i49 = icmp ult i32 %call.i.i, 10
  %call.i.i.i50 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i49, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i50 to i8
  %cf.i.i51 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i51, align 1
  %conv.i.i.i.i52 = trunc i32 %sub.i.i to i8
  %66 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i52)
  %67 = and i8 %66, 1
  %conv.i.i.i53 = xor i8 %67, 1
  %pf.i.i.i54 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i53, ptr %pf.i.i.i54, align 1
  %xor.i.i.i.i55 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i56 = xor i32 %xor.i.i.i.i55, %sub.i.i
  %68 = trunc i32 %xor1.i.i.i.i56 to i8
  %69 = lshr i8 %68, 4
  %conv2.i.i.i57 = and i8 %69, 1
  %af.i.i.i58 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i57, ptr %af.i.i.i58, align 1
  %cmp.i.i.i.i59 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i59, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv5.i.i.i61 = zext i1 %call.i.i.i.i60 to i8
  %zf.i.i.i62 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i61, ptr %zf.i.i.i62, align 1
  %cmp.i27.i.i.i63 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i63, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv8.i.i.i65 = zext i1 %call1.i.i.i.i64 to i8
  %sf.i.i.i66 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i65, ptr %sf.i.i.i66, align 1
  %xor.i28.i.i.i67 = lshr i32 %xor.i.i.i.i55, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i68 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i69 = add nuw nsw i32 %xor3.i.i.i.i68, %xor.i28.i.i.i67
  %cmp.i29.i.i.i70 = icmp eq i32 %add.i.i.i.i69, 2
  %call.i30.i.i.i71 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i70, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #16
  %conv11.i.i.i72 = zext i1 %call.i30.i.i.i71 to i8
  %of.i.i.i73 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i72, ptr %of.i.i.i73, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %61
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  %74 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %74, 0
  %of.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  %75 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %75, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %73, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %70
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i32, ptr %EDX, align 4
  %80 = zext i32 %79 to i64
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %80, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %81, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RCX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %85 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %87 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %87, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %89 = and i8 %88, 1
  %conv.i.i.i = xor i8 %89, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %90 = trunc i32 %xor1.i.i.i.i to i8
  %91 = lshr i8 %90, 4
  %conv2.i.i.i = and i8 %91, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %82
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load i32, ptr %EDX, align 4
  %97 = zext i32 %96 to i64
  %98 = load ptr, ptr %MEMORY, align 8
  %conv.i.i92 = trunc i64 %95 to i32
  %sext.i = shl i64 %95, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %97, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %99 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i93 = icmp ult i64 %99, -4294967296
  %call.i.i.i94 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i93, i32 noundef %conv.i.i92, i32 noundef %96, i64 noundef %mul.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i94 to i8
  %cf.i.i95 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i95, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %98, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %92
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 3
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %RCX, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %conv.i.i105 = trunc i64 %103 to i32
  %and3.i.i = and i32 1, %conv.i.i105
  %conv.i22.i106 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i106, ptr %RCX, align 8
  %cf.i.i107 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i107, align 1
  %conv.i.i.i108 = trunc i32 %and3.i.i to i8
  %105 = and i8 %conv.i.i.i108, 1
  %conv.i23.i109 = xor i8 %105, 1
  %pf.i.i110 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i109, ptr %pf.i.i110, align 1
  %cmp.i.i.i111 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv.i.i105, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i112 to i8
  %zf.i.i113 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i113, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i105, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i114 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i114, align 1
  %of.i.i115 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i115, align 1
  %af.i.i116 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i116, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %100
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i32, ptr %ECX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv.i12.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i75, align 1
  %conv.i.i.i.i76 = trunc i32 %109 to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i76)
  %113 = and i8 %112, 1
  %conv.i.i.i77 = xor i8 %113, 1
  %pf.i.i.i78 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i77, ptr %pf.i.i.i78, align 1
  %af.i.i.i79 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i79, align 1
  %cmp.i.i.i.i80 = icmp eq i32 %109, 0
  %call.i.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i80, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv5.i.i.i82 = zext i1 %call.i.i.i.i81 to i8
  %zf.i.i.i83 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i82, ptr %zf.i.i.i83, align 1
  %cmp.i27.i.i.i84 = icmp slt i32 %109, 0
  %call1.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i84, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv8.i.i.i86 = zext i1 %call1.i.i.i.i85 to i8
  %sf.i.i.i87 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i86, ptr %sf.i.i.i87, align 1
  %xor.i28.i.i.i88 = lshr i32 %109, 31
  %call.i30.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %109, i32 noundef 0, i32 noundef %109) #16
  %conv11.i.i.i90 = zext i1 %call.i30.i.i.i89 to i8
  %of.i.i.i91 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i90, ptr %of.i.i.i91, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %106
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %118 = load i8, ptr %zf.i, align 1
  store i8 %118, ptr %CL, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %114
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 2
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i8, ptr %AL, align 1
  %123 = zext i8 %122 to i64
  %124 = load i8, ptr %CL, align 1
  %125 = zext i8 %124 to i64
  %126 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %125, %123
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i117 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i117, align 1
  %127 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %128 = and i8 %127, 1
  %conv.i27.i = xor i8 %128, 1
  %pf.i.i118 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i118, align 1
  %129 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i119 = and i32 %129, 255
  %cmp.i.i.i120 = icmp eq i8 %or3.i.i, 0
  %130 = trunc i64 %123 to i32
  %conv1.i.i.i = and i32 %130, 255
  %131 = trunc i64 %125 to i32
  %conv2.i.i.i121 = and i32 %131, 255
  %call.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i120, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i121, i32 noundef %conv.i.i.i119) #16
  %conv3.i.i123 = zext i1 %call.i.i.i122 to i8
  %zf.i.i124 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i123, ptr %zf.i.i124, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i121, i32 noundef %conv.i.i.i119) #16
  %conv6.i.i125 = zext i1 %call4.i.i.i to i8
  %sf.i.i126 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i125, ptr %sf.i.i126, align 1
  %of.i.i127 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i127, align 1
  %af.i.i128 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call16.i, ptr %af.i.i128, align 1
  store ptr %126, ptr %MEMORY, align 8
  br label %132

132:                                              ; preds = %119
  %133 = load i64, ptr %NEXT_PC, align 8
  store i64 %133, ptr %PC, align 8
  %134 = add i64 %133, 2
  store i64 %134, ptr %NEXT_PC, align 8
  %135 = load i8, ptr %AL, align 1
  %136 = zext i8 %135 to i64
  %137 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %136
  %and3.i.i129 = trunc i64 %and3.i15.i to i8
  %cf.i.i130 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i130, align 1
  %138 = and i8 %and3.i.i129, 1
  %conv.i14.i = xor i8 %138, 1
  %pf.i.i131 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i131, align 1
  %139 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i132 = and i32 %139, 255
  %cmp.i.i.i133 = icmp eq i8 %and3.i.i129, 0
  %140 = trunc i64 %136 to i32
  %conv1.i.i.i134 = and i32 %140, 255
  %call.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i133, i32 noundef %conv1.i.i.i134, i32 noundef 1, i32 noundef %conv.i.i.i132) #16
  %conv3.i.i136 = zext i1 %call.i.i.i135 to i8
  %zf.i.i137 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i136, ptr %zf.i.i137, align 1
  %call4.i.i.i138 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i134, i32 noundef 1, i32 noundef %conv.i.i.i132) #16
  %conv6.i.i139 = zext i1 %call4.i.i.i138 to i8
  %sf.i.i140 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i139, ptr %sf.i.i140, align 1
  %of.i.i141 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i141, align 1
  %af.i.i142 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #17
  store i8 %call7.i, ptr %af.i.i142, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %141

141:                                              ; preds = %132
  %142 = load i64, ptr %NEXT_PC, align 8
  store i64 %142, ptr %PC, align 8
  %143 = add i64 %142, 6
  store i64 %143, ptr %NEXT_PC, align 8
  %144 = load i64, ptr %NEXT_PC, align 8
  %145 = add i64 %144, 5
  %146 = load i64, ptr %NEXT_PC, align 8
  %147 = load ptr, ptr %MEMORY, align 8
  %zf.i96 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 2, i32 7
  %148 = load i8, ptr %zf.i96, align 1
  %tobool.not.i = icmp eq i8 %148, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %145, i64 %146
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %147, ptr %MEMORY, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = load ptr, ptr %MEMORY, align 8
  ret ptr %150
}

define ptr @BB_2a95(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.291467, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 104
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #5 {
entry:
  %agg.tmp = alloca %struct.State.291467, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.291467) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #19
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.291467) align 16, i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rax = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #10 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 10336, label %bb_2860
    i64 10419, label %bb_28B3
    i64 10473, label %bb_28E9
    i64 10562, label %bb_2942
    i64 10568, label %bb_2948
    i64 10602, label %bb_296A
    i64 10656, label %bb_29A0
    i64 10661, label %bb_29A5
    i64 10760, label %bb_2A08
    i64 10766, label %bb_2A0E
    i64 10820, label %bb_2A44
    i64 10901, label %bb_2A95
    i64 10907, label %bb_2A9B
    i64 10961, label %bb_2AD1
    i64 11042, label %bb_2B22
    i64 11048, label %bb_2B28
    i64 11102, label %bb_2B5E
    i64 11164, label %bb_2B9C
    i64 -281474976710656, label %bb_FFFF000000000000
  ]

dead_end:                                         ; preds = %bb_FFFF000000000000, %bb_2B5E, %bb_2B28, %bb_2B22, %bb_2AD1, %bb_2A9B, %bb_2A95, %bb_2A44, %bb_2A0E, %bb_2A08, %bb_29A5, %bb_29A0, %bb_296A, %bb_2948, %bb_2942, %bb_28E9, %bb_28B3, %bb_2860, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_2860:                                          ; preds = %entry
  %block_pc = add i64 10336, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 10336, ptr %1)
  %4 = call ptr @BB_2860(ptr %state, i64 %2, ptr %1) #20
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 10419, label %bb_28B3
    i64 11048, label %bb_2B28
  ]

bb_28B3:                                          ; preds = %bb_2860, %entry
  %block_pc1 = add i64 10419, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 10419, ptr %6)
  %9 = call ptr @BB_28b3(ptr %state, i64 %7, ptr %6) #20
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 10473, label %bb_28E9
  ]

bb_28E9:                                          ; preds = %bb_28B3, %entry
  %block_pc3 = add i64 10473, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 10473, ptr %11)
  %14 = call ptr @BB_28e9(ptr %state, i64 %12, ptr %11) #20
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 10562, label %bb_2942
  ]

bb_2942:                                          ; preds = %bb_28E9, %entry
  %block_pc5 = add i64 10562, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 10562, ptr %16)
  %19 = call ptr @BB_2942(ptr %state, i64 %17, ptr %16) #20
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 10568, label %bb_2948
  ]

bb_2948:                                          ; preds = %bb_2A95, %bb_2942, %entry
  %block_pc7 = add i64 10568, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 10568, ptr %21)
  %24 = call ptr @BB_2948(ptr %state, i64 %22, ptr %21) #20
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 10602, label %bb_296A
    i64 10907, label %bb_2A9B
  ]

bb_296A:                                          ; preds = %bb_2948, %entry
  %block_pc9 = add i64 10602, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 10602, ptr %26)
  %29 = call ptr @BB_296a(ptr %state, i64 %27, ptr %26) #20
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 10656, label %bb_29A0
  ]

bb_29A0:                                          ; preds = %bb_296A, %entry
  %block_pc11 = add i64 10656, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 10656, ptr %31)
  %34 = call ptr @BB_29a0(ptr %state, i64 %32, ptr %31) #20
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 8368, label %bb_FFFF000000000000
  ]

bb_29A5:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc13 = add i64 10661, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 10661, ptr %36)
  %39 = call ptr @BB_29a5(ptr %state, i64 %37, ptr %36) #20
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 10760, label %bb_2A08
  ]

bb_2A08:                                          ; preds = %bb_29A5, %entry
  %block_pc15 = add i64 10760, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 10760, ptr %41)
  %44 = call ptr @BB_2a08(ptr %state, i64 %42, ptr %41) #20
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 10766, label %bb_2A0E
  ]

bb_2A0E:                                          ; preds = %bb_2A08, %entry
  %block_pc17 = add i64 10766, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 10766, ptr %46)
  %49 = call ptr @BB_2a0e(ptr %state, i64 %47, ptr %46) #20
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 10820, label %bb_2A44
  ]

bb_2A44:                                          ; preds = %bb_2A0E, %entry
  %block_pc19 = add i64 10820, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 10820, ptr %51)
  %54 = call ptr @BB_2a44(ptr %state, i64 %52, ptr %51) #20
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 10901, label %bb_2A95
  ]

bb_2A95:                                          ; preds = %bb_2A44, %entry
  %block_pc21 = add i64 10901, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 10901, ptr %56)
  %59 = call ptr @BB_2a95(ptr %state, i64 %57, ptr %56) #20
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 10568, label %bb_2948
  ]

bb_2A9B:                                          ; preds = %bb_2948, %entry
  %block_pc23 = add i64 10907, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 10907, ptr %61)
  %64 = call ptr @BB_2a9b(ptr %state, i64 %62, ptr %61) #20
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 10961, label %bb_2AD1
  ]

bb_2AD1:                                          ; preds = %bb_2A9B, %entry
  %block_pc25 = add i64 10961, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 10961, ptr %66)
  %69 = call ptr @BB_2ad1(ptr %state, i64 %67, ptr %66) #20
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 11042, label %bb_2B22
  ]

bb_2B22:                                          ; preds = %bb_2AD1, %entry
  %block_pc27 = add i64 11042, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 11042, ptr %71)
  %74 = call ptr @BB_2b22(ptr %state, i64 %72, ptr %71) #20
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 11048, label %bb_2B28
  ]

bb_2B28:                                          ; preds = %bb_2B22, %bb_2860, %entry
  %block_pc29 = add i64 11048, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 11048, ptr %76)
  %79 = call ptr @BB_2b28(ptr %state, i64 %77, ptr %76) #20
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 11102, label %bb_2B5E
  ]

bb_2B5E:                                          ; preds = %bb_2B28, %entry
  %block_pc31 = add i64 11102, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 11102, ptr %81)
  %84 = call ptr @BB_2b5e(ptr %state, i64 %82, ptr %81) #20
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 11164, label %bb_2B9C
  ]

bb_2B9C:                                          ; preds = %bb_2B5E, %entry
  %block_pc33 = add i64 11164, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 11164, ptr %86)
  %89 = call ptr @BB_2b9c(ptr %state, i64 %87, ptr %86) #20
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  %91 = load ptr, ptr %mem_var, align 8
  ret ptr %91

bb_FFFF000000000000:                              ; preds = %bb_29A0, %entry
  %92 = load ptr, ptr %mem_var, align 8
  %93 = load i64, ptr %pc_var, align 4
  %94 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %93, ptr %92) #20
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva35 = sub i64 %95, %base
  switch i64 %next_rva35, label %dead_end [
    i64 10661, label %bb_29A5
  ]

return_bb:                                        ; No predecessors!
  %96 = load ptr, ptr %mem_var, align 8
  ret ptr %96
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #11 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 10336, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #12 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #12 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #12 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #12 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #12 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) #13 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.291466, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !14
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { mustprogress noduplicate nofree noinline nosync nounwind optnone willreturn memory(none) "no-builtins" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "tune-cpu"="generic" }
attributes #3 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #4 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #5 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #18 = { alwaysinline nobuiltin nounwind "no-builtins" }
attributes #19 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #20 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15, !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C++ TBAA"}
