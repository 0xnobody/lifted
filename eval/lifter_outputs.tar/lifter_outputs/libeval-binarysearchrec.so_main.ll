; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.20060 = type { %struct.X86State.20059 }
%struct.X86State.20059 = type { %struct.ArchState.20028, [32 x %union.VectorReg.20031], %struct.ArithFlags.20032, %union.anon.20027, %struct.Segments.20034, %struct.AddressSpace.20036, %struct.GPR.20037, %struct.X87Stack.20040, %struct.MMX.20044, %struct.FPUStatusFlags.20045, %union.anon.20027, %union.FPU.20054, %struct.SegmentCaches.20056, %struct.K_REG.20058 }
%struct.ArchState.20028 = type { i32, i32, %union.anon.20027 }
%union.VectorReg.20031 = type { %union.vec512_t.20030 }
%union.vec512_t.20030 = type { %struct.uint64v8_t.20029 }
%struct.uint64v8_t.20029 = type { [8 x i64] }
%struct.ArithFlags.20032 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.20034 = type { i16, %union.SegmentSelector.20033, i16, %union.SegmentSelector.20033, i16, %union.SegmentSelector.20033, i16, %union.SegmentSelector.20033, i16, %union.SegmentSelector.20033, i16, %union.SegmentSelector.20033 }
%union.SegmentSelector.20033 = type { i16 }
%struct.AddressSpace.20036 = type { i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035 }
%struct.Reg.20035 = type { %union.anon.20027 }
%struct.GPR.20037 = type { i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035, i64, %struct.Reg.20035 }
%struct.X87Stack.20040 = type { [8 x %struct.anon.3.20039] }
%struct.anon.3.20039 = type { [6 x i8], %struct.float80_t.20038 }
%struct.float80_t.20038 = type { [10 x i8] }
%struct.MMX.20044 = type { [8 x %struct.anon.4.20043] }
%struct.anon.4.20043 = type { i64, %union.vec64_t.20042 }
%union.vec64_t.20042 = type { %struct.uint64v1_t.20041 }
%struct.uint64v1_t.20041 = type { [1 x i64] }
%struct.FPUStatusFlags.20045 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.20027 = type { i64 }
%union.FPU.20054 = type { %struct.anon.13.20053 }
%struct.anon.13.20053 = type { %struct.FpuFXSAVE.20052, [96 x i8] }
%struct.FpuFXSAVE.20052 = type { %union.SegmentSelector.20033, %union.SegmentSelector.20033, %union.FPUAbridgedTagWord.20046, i8, i16, i32, %union.SegmentSelector.20033, i16, i32, %union.SegmentSelector.20033, i16, %union.FPUControlStatus.20047, %union.FPUControlStatus.20047, [8 x %struct.FPUStackElem.20049], [16 x %union.vec128_t.20051] }
%union.FPUAbridgedTagWord.20046 = type { i8 }
%union.FPUControlStatus.20047 = type { i32 }
%struct.FPUStackElem.20049 = type { %union.anon.11.20048, [6 x i8] }
%union.anon.11.20048 = type { %struct.float80_t.20038 }
%union.vec128_t.20051 = type { %struct.uint128v1_t.20050 }
%struct.uint128v1_t.20050 = type { [1 x i128] }
%struct.SegmentCaches.20056 = type { %struct.SegmentShadow.20055, %struct.SegmentShadow.20055, %struct.SegmentShadow.20055, %struct.SegmentShadow.20055, %struct.SegmentShadow.20055, %struct.SegmentShadow.20055 }
%struct.SegmentShadow.20055 = type { %union.anon.20027, i32, i32 }
%struct.K_REG.20058 = type { [8 x %struct.anon.18.20057] }
%struct.anon.18.20057 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1139(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i30 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #16
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i30, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %23, 80
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %23, 80
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %26 = and i8 %25, 1
  %conv.i.i.i = xor i8 %26, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 80, %23
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %27 = trunc i64 %xor1.i.i.i.i to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i = and i8 %28, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %23, 80
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %23
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef 80, i64 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %20
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 68
  %34 = load i32, ptr %EDI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #16
  store ptr %call.i.i28, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 4
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RBP, align 8
  %41 = sub i64 %40, 80
  %42 = load i64, ptr %RSI, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %41, i64 noundef %42) #16
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 4
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 68
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %49, i64 noundef %48) #16
  %sub.i.i1 = sub i32 %call.i.i, 11
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, 11
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef 11, i32 noundef %sub.i.i1) #16
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %51 = and i8 %50, 1
  %conv.i.i.i6 = xor i8 %51, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, 11
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %52 = trunc i32 %xor1.i.i.i.i9 to i8
  %53 = lshr i8 %52, 4
  %conv2.i.i.i10 = and i8 %53, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, 11
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef 11, i32 noundef %sub.i.i1) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef 11, i32 noundef %sub.i.i1) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef 11, i32 noundef %sub.i.i1) #16
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %44
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %NEXT_PC, align 8
  %58 = add i64 %57, 10
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  %61 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %61, 0
  %sf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool10.i = icmp eq i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool12.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool10.i, %tobool12.i
  %64 = and i1 %tobool.not.i, %cmp.i.i
  %call15.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %64) #17
  %frombool.i = zext i1 %call15.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call15.i, i64 %58, i64 %59
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %60, ptr %MEMORY, align 8
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  ret ptr %66
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_115c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %6, i64 noundef %5, i32 noundef 1) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = add i64 %10, 46
  %12 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store ptr %12, ptr %MEMORY, align 8
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  ret ptr %14
}

define ptr @BB_1152(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 5
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 195
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1193(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 68
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %conv.i.i29 = zext i32 %call.i.i28 to i64
  store i64 %conv.i.i29, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %sub.i.i = sub i32 %conv.i.i, 1
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %conv.i.i, 1
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %13 = and i8 %12, 1
  %conv.i.i.i = xor i8 %13, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 1, %conv.i.i
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %14 = trunc i32 %xor1.i.i.i.i to i8
  %15 = lshr i8 %14, 4
  %conv2.i.i.i = and i8 %15, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %conv.i.i, 1
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %7
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 3
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %RBP, align 8
  %20 = sub i64 %19, 4
  %21 = load i32, ptr %EAX, align 4
  %22 = zext i32 %21 to i64
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %23, i64 noundef %20) #16
  %sub.i.i1 = sub i32 %call.i.i, %21
  %cmp.i.i.i2 = icmp ult i32 %call.i.i, %21
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %call.i.i, i32 noundef %21, i32 noundef %sub.i.i1) #16
  %conv.i9.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i1 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %25 = and i8 %24, 1
  %conv.i.i.i6 = xor i8 %25, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 %call.i.i, %21
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i1
  %26 = trunc i32 %xor1.i.i.i.i9 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i10 = and i8 %27, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %call.i.i, %21
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %call.i.i, i32 noundef %21, i32 noundef %sub.i.i1) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i1, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %call.i.i, i32 noundef %21, i32 noundef %sub.i.i1) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i21 = xor i32 %sub.i.i1, %call.i.i
  %xor3.i.i.i.i22 = lshr i32 %shr9.i.i.i.i21, 31
  %add.i.i.i.i23 = add nuw nsw i32 %xor3.i.i.i.i22, %xor.i28.i.i.i20
  %cmp.i29.i.i.i24 = icmp eq i32 %add.i.i.i.i23, 2
  %call.i30.i.i.i25 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i24, i32 noundef %call.i.i, i32 noundef %21, i32 noundef %sub.i.i1) #16
  %conv11.i.i.i26 = zext i1 %call.i30.i.i.i25 to i8
  %of.i.i.i27 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i26, ptr %of.i.i.i27, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %16
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 2
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %NEXT_PC, align 8
  %32 = sub i64 %31, 57
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  %35 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %35, 0
  %of.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  %36 = load i8, ptr %of.i, align 1
  %tobool9.i = icmp ne i8 %36, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool9.i
  %call11.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i) #17
  %frombool.i = zext i1 %call11.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call11.i, i64 %32, i64 %33
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %34, ptr %MEMORY, align 8
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = load ptr, ptr %MEMORY, align 8
  ret ptr %38
}

define ptr @BB_121f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #16
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #16
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1165(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %conv.i.i34 = zext i32 %call.i.i33 to i64
  store i64 %conv.i.i34, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 1
  %11 = load i32, ptr %rax.i, align 8
  %conv.i.i29 = sext i32 %11 to i64
  store i64 %conv.i.i29, ptr %rax.i, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 8
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RAX, align 8
  %16 = mul i64 %15, 8
  %17 = add i64 0, %16
  %18 = load ptr, ptr %MEMORY, align 8
  store i64 %17, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %12
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 80
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #16
  store i64 %call.i.i36, ptr %RAX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RAX, align 8
  %29 = load i64, ptr %RDX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 %29, %28
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %28
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, %29
  %31 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %31, i64 noundef %28, i64 noundef %29, i64 noundef %add.i.i1) #16
  %conv.i.i = zext i1 %call.i.i.i4 to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i5, align 1
  %conv.i.i.i.i6 = trunc i64 %add.i.i1 to i8
  %32 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i6)
  %33 = and i8 %32, 1
  %conv.i.i.i7 = xor i8 %33, 1
  %pf.i.i.i8 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i7, ptr %pf.i.i.i8, align 1
  %xor.i.i.i.i9 = xor i64 %add.i.i1, %29
  %xor1.i.i.i.i10 = xor i64 %xor.i.i.i.i9, %28
  %34 = trunc i64 %xor1.i.i.i.i10 to i8
  %35 = lshr i8 %34, 4
  %conv2.i.i.i11 = and i8 %35, 1
  %af.i.i.i12 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i11, ptr %af.i.i.i12, align 1
  %cmp.i.i.i.i13 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i14 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i13, i64 noundef %28, i64 noundef %29, i64 noundef %add.i.i1) #16
  %conv5.i.i.i15 = zext i1 %call.i.i.i.i14 to i8
  %zf.i.i.i16 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i15, ptr %zf.i.i.i16, align 1
  %cmp.i27.i.i.i17 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i18 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i17, i64 noundef %28, i64 noundef %29, i64 noundef %add.i.i1) #16
  %conv8.i.i.i19 = zext i1 %call1.i.i.i.i18 to i8
  %sf.i.i.i20 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i19, ptr %sf.i.i.i20, align 1
  %shr8.i.i.i.i21 = xor i64 %add.i.i1, %28
  %xor.i28.i.i.i22 = lshr i64 %shr8.i.i.i.i21, 63
  %xor3.i.i.i.i23 = lshr i64 %xor.i.i.i.i9, 63
  %add.i.i.i.i24 = add nuw nsw i64 %xor.i28.i.i.i22, %xor3.i.i.i.i23
  %cmp.i29.i.i.i25 = icmp eq i64 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i64 noundef %28, i64 noundef %29, i64 noundef %add.i.i1) #16
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %25
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RAX, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %40, i64 noundef %39) #16
  store i64 %call.i.i35, ptr %RAX, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %36
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RAX, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  %call.i.i37 = call zeroext i8 @__remill_read_memory_8(ptr noundef %45, i64 noundef %44) #16
  %conv.i.i38 = zext i8 %call.i.i37 to i64
  store i64 %conv.i.i38, ptr %RAX, align 8
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %41
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %RBP, align 8
  %50 = sub i64 %49, 4
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call i32 @__remill_read_memory_32(ptr noundef %51, i64 noundef %50) #16
  %conv.i.i32 = zext i32 %call.i.i31 to i64
  store i64 %conv.i.i32, ptr %RDX, align 8
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RDX, align 8
  %56 = sub i64 %55, 1
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i42 = and i64 %56, 4294967295
  store i64 %conv.i.i42, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i8, ptr %AL, align 1
  %62 = zext i8 %61 to i64
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i39 = trunc i64 %62 to i32
  %sext.i = shl i32 %conv.i.i39, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RDX, align 8
  store ptr %63, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 3
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %ECX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %sext.i40 = shl i64 %68, 32
  %conv.i12.i41 = ashr exact i64 %sext.i40, 32
  store i64 %conv.i12.i41, ptr %RAX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 4
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RBP, align 8
  %74 = load i64, ptr %RAX, align 8
  %75 = mul i64 %74, 4
  %76 = add i64 %73, %75
  %77 = sub i64 %76, 64
  %78 = load i32, ptr %EDX, align 4
  %79 = zext i32 %78 to i64
  %80 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_32(ptr noundef %80, i64 noundef %77, i32 noundef %78) #16
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %70
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 4
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RBP, align 8
  %85 = sub i64 %84, 4
  %86 = load i64, ptr %RBP, align 8
  %87 = sub i64 %86, 4
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %88, i64 noundef %87) #16
  %add.i.i = add i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %88, i64 noundef %85, i32 noundef %add.i.i) #16
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %89 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %89, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %90 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %91 = and i8 %90, 1
  %conv.i.i.i = xor i8 %91, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %92 = trunc i32 %xor1.i.i.i.i to i8
  %93 = lshr i8 %92, 4
  %conv2.i.i.i = and i8 %93, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %81
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_119e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 68
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i42 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %conv.i.i43 = zext i32 %call.i.i42 to i64
  store i64 %conv.i.i43, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 1
  %11 = load i32, ptr %rax.i, align 8
  %conv.i.i28 = sext i32 %11 to i64
  store i64 %conv.i.i28, ptr %rax.i, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RAX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %shl.i145.i = shl i64 %15, 2
  %call42.i = call zeroext i8 @__remill_undefined_8() #17
  %tobool43.i = icmp ne i8 %call42.i, 0
  %shl.i147.i = shl i64 %shl.i145.i, 1
  store i64 %shl.i147.i, ptr %RAX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i64 %shl.i145.i, 63
  %conv.i = trunc i64 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i50 = trunc i64 %shl.i147.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i50)
  %18 = and i8 %17, 1
  %conv72.i = xor i8 %18, 1
  store i8 %conv72.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  %cmp.i148.i = icmp eq i64 %shl.i147.i, 0
  %conv85.i = zext i1 %cmp.i148.i to i8
  store i8 %conv85.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i64 %shl.i147.i, 63
  %conv92.i = trunc i64 %new_val.0.lobit.i to i8
  store i8 %conv92.i, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %12
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = sub i64 %22, 8
  %24 = load ptr, ptr %MEMORY, align 8
  store i64 %23, ptr %RDX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 4
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 80
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i45 = call i64 @__remill_read_memory_64(ptr noundef %30, i64 noundef %29) #16
  store i64 %call.i.i45, ptr %RAX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %25
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 3
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %RAX, align 8
  %35 = load i64, ptr %RDX, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %35, %34
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %34
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %35
  %37 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %37, i64 noundef %34, i64 noundef %35, i64 noundef %add.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %38 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %39 = and i8 %38, 1
  %conv.i.i.i = xor i8 %39, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %35
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %34
  %40 = trunc i64 %xor1.i.i.i.i to i8
  %41 = lshr i8 %40, 4
  %conv2.i.i.i = and i8 %41, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %34, i64 noundef %35, i64 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %34, i64 noundef %35, i64 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %34
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %34, i64 noundef %35, i64 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %36, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %31
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i44 = call i64 @__remill_read_memory_64(ptr noundef %46, i64 noundef %45) #16
  store i64 %call.i.i44, ptr %RAX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i46 = call zeroext i8 @__remill_read_memory_8(ptr noundef %51, i64 noundef %50) #16
  %conv.i.i47 = zext i8 %call.i.i46 to i64
  store i64 %conv.i.i47, ptr %RAX, align 8
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %47
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i8, ptr %AL, align 1
  %56 = zext i8 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i48 = trunc i64 %56 to i32
  %sext.i = shl i32 %conv.i.i48, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RBP, align 8
  %62 = sub i64 %61, 8
  %63 = load i32, ptr %EAX, align 4
  %64 = zext i32 %63 to i64
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call ptr @__remill_write_memory_32(ptr noundef %65, i64 noundef %62, i32 noundef %63) #16
  store ptr %call.i.i31, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %58
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 7
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RBP, align 8
  %70 = sub i64 %69, 12
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_32(ptr noundef %71, i64 noundef %70, i32 noundef 0) #16
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %66
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 3
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RBP, align 8
  %76 = sub i64 %75, 68
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i40 = call i32 @__remill_read_memory_32(ptr noundef %77, i64 noundef %76) #16
  %conv.i.i41 = zext i32 %call.i.i40 to i64
  store i64 %conv.i.i41, ptr %RAX, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %72
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 3
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RAX, align 8
  %82 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %81 to i32
  %sub.i.i = sub i32 %conv.i.i1, 2
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i32 %conv.i.i1, 2
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv.i23.i = zext i1 %call.i.i.i3 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i32 %sub.i.i to i8
  %83 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %84 = and i8 %83, 1
  %conv.i.i.i6 = xor i8 %84, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i32 2, %conv.i.i1
  %xor1.i.i.i.i9 = xor i32 %xor.i.i.i.i8, %sub.i.i
  %85 = trunc i32 %xor1.i.i.i.i9 to i8
  %86 = lshr i8 %85, 4
  %conv2.i.i.i10 = and i8 %86, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i32 %conv.i.i1, 2
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i32 %xor.i.i.i.i8, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i1
  %xor3.i.i.i.i21 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i22 = add nuw nsw i32 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i32 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %82, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %78
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RBP, align 8
  %91 = sub i64 %90, 16
  %92 = load i32, ptr %EAX, align 4
  %93 = zext i32 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_32(ptr noundef %94, i64 noundef %91, i32 noundef %92) #16
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %87
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 3
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %RBP, align 8
  %99 = sub i64 %98, 68
  %100 = load ptr, ptr %MEMORY, align 8
  %call.i.i38 = call i32 @__remill_read_memory_32(ptr noundef %100, i64 noundef %99) #16
  %conv.i.i39 = zext i32 %call.i.i38 to i64
  store i64 %conv.i.i39, ptr %RAX, align 8
  store ptr %100, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %95
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 3
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RAX, align 8
  %105 = sub i64 %104, 1
  %106 = load ptr, ptr %MEMORY, align 8
  %conv.i.i49 = and i64 %105, 4294967295
  store i64 %conv.i.i49, ptr %RSI, align 8
  store ptr %106, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %101
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 3
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i64, ptr %RBP, align 8
  %111 = sub i64 %110, 16
  %112 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call i32 @__remill_read_memory_32(ptr noundef %112, i64 noundef %111) #16
  %conv.i.i37 = zext i32 %call.i.i36 to i64
  store i64 %conv.i.i37, ptr %RDI, align 8
  store ptr %112, ptr %MEMORY, align 8
  br label %113

113:                                              ; preds = %107
  %114 = load i64, ptr %NEXT_PC, align 8
  store i64 %114, ptr %PC, align 8
  %115 = add i64 %114, 3
  store i64 %115, ptr %NEXT_PC, align 8
  %116 = load i64, ptr %RBP, align 8
  %117 = sub i64 %116, 12
  %118 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i32 @__remill_read_memory_32(ptr noundef %118, i64 noundef %117) #16
  %conv.i.i35 = zext i32 %call.i.i34 to i64
  store i64 %conv.i.i35, ptr %RCX, align 8
  store ptr %118, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %113
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RBP, align 8
  %123 = sub i64 %122, 8
  %124 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call i32 @__remill_read_memory_32(ptr noundef %124, i64 noundef %123) #16
  %conv.i.i33 = zext i32 %call.i.i32 to i64
  store i64 %conv.i.i33, ptr %RDX, align 8
  store ptr %124, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %119
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 4
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i64, ptr %RBP, align 8
  %129 = sub i64 %128, 64
  %130 = load ptr, ptr %MEMORY, align 8
  store i64 %129, ptr %RAX, align 8
  store ptr %130, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %125
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 3
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i32, ptr %EDI, align 4
  %135 = zext i32 %134 to i64
  %136 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %135, 4294967295
  store i64 %conv.i11.i, ptr %R8, align 8
  store ptr %136, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %131
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 3
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i64, ptr %RAX, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  store i64 %140, ptr %RDI, align 8
  store ptr %141, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %137
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 5
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %145, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %142
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 5
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = sub i64 %149, 385
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %153 = load i64, ptr %rsp.i, align 8
  %sub.i.i27 = add i64 %153, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %152, i64 noundef %sub.i.i27, i64 noundef %151) #16
  store i64 %sub.i.i27, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %150, ptr %rip.i, align 8
  store i64 %150, ptr %NEXT_PC, align 8
  store i64 %151, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %154 = load ptr, ptr %MEMORY, align 8
  ret ptr %154
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_binary(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_binary(ptr, i64, ptr) #2

define ptr @BB_11f1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load i32, ptr %EAX, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %8, i64 noundef %5, i32 noundef %6) #16
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 4
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 20
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #16
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %15 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %16 = and i8 %15, 1
  %conv.i.i.i = xor i8 %16, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %9
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 2
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i64, ptr %NEXT_PC, align 8
  %21 = add i64 %20, 17
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 2, i32 7
  %24 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %24, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %21, i64 %22
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %23, ptr %MEMORY, align 8
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  ret ptr %26
}

define ptr @BB_120b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3587
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RDI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = sub i64 %15, 442
  %17 = load i64, ptr %NEXT_PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %19 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %19, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %18, i64 noundef %sub.i.i, i64 noundef %17) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %16, ptr %rip.i, align 8
  store i64 %16, ptr %NEXT_PC, align 8
  store i64 %17, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  ret ptr %20
}

define ptr @BB_11fa(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3583
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RDI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = sub i64 %15, 425
  %17 = load i64, ptr %NEXT_PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %19 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %19, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %18, i64 noundef %sub.i.i, i64 noundef %17) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %16, ptr %rip.i, align 8
  store i64 %16, ptr %NEXT_PC, align 8
  store i64 %17, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  ret ptr %20
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_puts(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_puts(ptr, i64, ptr) #4

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_puts(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_121a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_1209(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.20060, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 15
  %6 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store ptr %6, ptr %MEMORY, align 8
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  ret ptr %8
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #5 {
entry:
  %agg.tmp = alloca %struct.State.20060, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.20060) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #18
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.20060) align 16, i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rax = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #10 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4409, label %bb_1139
    i64 4434, label %bb_1152
    i64 4444, label %bb_115C
    i64 4453, label %bb_1165
    i64 4499, label %bb_1193
    i64 4510, label %bb_119E
    i64 4593, label %bb_11F1
    i64 4602, label %bb_11FA
    i64 4617, label %bb_1209
    i64 4619, label %bb_120B
    i64 4634, label %bb_121A
    i64 4639, label %bb_121F
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
  ]

dead_end:                                         ; preds = %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_121A, %bb_120B, %bb_1209, %bb_11FA, %bb_11F1, %bb_119E, %bb_1193, %bb_1165, %bb_115C, %bb_1152, %bb_1139, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1139:                                          ; preds = %entry
  %block_pc = add i64 4409, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4409, ptr %1)
  %4 = call ptr @BB_1139(ptr %state, i64 %2, ptr %1) #19
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4434, label %bb_1152
    i64 4444, label %bb_115C
  ]

bb_1152:                                          ; preds = %bb_1139, %entry
  %block_pc1 = add i64 4434, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4434, ptr %6)
  %9 = call ptr @BB_1152(ptr %state, i64 %7, ptr %6) #19
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4639, label %bb_121F
  ]

bb_115C:                                          ; preds = %bb_1139, %entry
  %block_pc3 = add i64 4444, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4444, ptr %11)
  %14 = call ptr @BB_115c(ptr %state, i64 %12, ptr %11) #19
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4499, label %bb_1193
  ]

bb_1165:                                          ; preds = %bb_1193, %entry
  %block_pc5 = add i64 4453, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4453, ptr %16)
  %19 = call ptr @BB_1165(ptr %state, i64 %17, ptr %16) #19
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4499, label %bb_1193
  ]

bb_1193:                                          ; preds = %bb_1165, %bb_115C, %entry
  %block_pc7 = add i64 4499, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4499, ptr %21)
  %24 = call ptr @BB_1193(ptr %state, i64 %22, ptr %21) #19
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4453, label %bb_1165
    i64 4510, label %bb_119E
  ]

bb_119E:                                          ; preds = %bb_1193, %entry
  %block_pc9 = add i64 4510, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4510, ptr %26)
  %29 = call ptr @BB_119e(ptr %state, i64 %27, ptr %26) #19
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4208, label %bb_FFFF000000000000
  ]

bb_11F1:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc11 = add i64 4593, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4593, ptr %31)
  %34 = call ptr @BB_11f1(ptr %state, i64 %32, ptr %31) #19
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4602, label %bb_11FA
    i64 4619, label %bb_120B
  ]

bb_11FA:                                          ; preds = %bb_11F1, %entry
  %block_pc13 = add i64 4602, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4602, ptr %36)
  %39 = call ptr @BB_11fa(ptr %state, i64 %37, ptr %36) #19
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4192, label %bb_FFFF000000000002
  ]

bb_1209:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc15 = add i64 4617, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4617, ptr %41)
  %44 = call ptr @BB_1209(ptr %state, i64 %42, ptr %41) #19
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4634, label %bb_121A
  ]

bb_120B:                                          ; preds = %bb_11F1, %entry
  %block_pc17 = add i64 4619, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4619, ptr %46)
  %49 = call ptr @BB_120b(ptr %state, i64 %47, ptr %46) #19
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4192, label %bb_FFFF000000000001
  ]

bb_121A:                                          ; preds = %bb_FFFF000000000001, %bb_1209, %entry
  %block_pc19 = add i64 4634, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4634, ptr %51)
  %54 = call ptr @BB_121a(ptr %state, i64 %52, ptr %51) #19
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 4639, label %bb_121F
  ]

bb_121F:                                          ; preds = %bb_121A, %bb_1152, %entry
  %block_pc21 = add i64 4639, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 4639, ptr %56)
  %59 = call ptr @BB_121f(ptr %state, i64 %57, ptr %56) #19
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  %61 = load ptr, ptr %mem_var, align 8
  ret ptr %61

bb_FFFF000000000000:                              ; preds = %bb_119E, %entry
  %62 = load ptr, ptr %mem_var, align 8
  %63 = load i64, ptr %pc_var, align 4
  %64 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %63, ptr %62) #19
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva23 = sub i64 %65, %base
  switch i64 %next_rva23, label %dead_end [
    i64 4593, label %bb_11F1
  ]

bb_FFFF000000000001:                              ; preds = %bb_120B, %entry
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %67, ptr %66) #19
  store ptr %68, ptr %mem_var, align 8
  %69 = call i64 @__extract_rip(ptr %state)
  store i64 %69, ptr %pc_var, align 4
  %next_rva24 = sub i64 %69, %base
  switch i64 %next_rva24, label %dead_end [
    i64 4634, label %bb_121A
  ]

bb_FFFF000000000002:                              ; preds = %bb_11FA, %entry
  %70 = load ptr, ptr %mem_var, align 8
  %71 = load i64, ptr %pc_var, align 4
  %72 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %71, ptr %70) #19
  store ptr %72, ptr %mem_var, align 8
  %73 = call i64 @__extract_rip(ptr %state)
  store i64 %73, ptr %pc_var, align 4
  %next_rva25 = sub i64 %73, %base
  switch i64 %next_rva25, label %dead_end [
    i64 4617, label %bb_1209
  ]

return_bb:                                        ; No predecessors!
  %74 = load ptr, ptr %mem_var, align 8
  ret ptr %74
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #11 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4409, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #12 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #12 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #12 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #12 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #12 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #13 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.20059, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !32
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #18 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #19 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33, !33, i64 0}
!33 = !{!"omnipotent char", !34, i64 0}
!34 = !{!"Simple C++ TBAA"}
