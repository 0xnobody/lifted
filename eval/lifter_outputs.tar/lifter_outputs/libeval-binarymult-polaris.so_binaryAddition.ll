; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.177478 = type { %struct.X86State.177477 }
%struct.X86State.177477 = type { %struct.ArchState.177446, [32 x %union.VectorReg.177449], %struct.ArithFlags.177450, %union.anon.177445, %struct.Segments.177452, %struct.AddressSpace.177454, %struct.GPR.177455, %struct.X87Stack.177458, %struct.MMX.177462, %struct.FPUStatusFlags.177463, %union.anon.177445, %union.FPU.177472, %struct.SegmentCaches.177474, %struct.K_REG.177476 }
%struct.ArchState.177446 = type { i32, i32, %union.anon.177445 }
%union.VectorReg.177449 = type { %union.vec512_t.177448 }
%union.vec512_t.177448 = type { %struct.uint64v8_t.177447 }
%struct.uint64v8_t.177447 = type { [8 x i64] }
%struct.ArithFlags.177450 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.177452 = type { i16, %union.SegmentSelector.177451, i16, %union.SegmentSelector.177451, i16, %union.SegmentSelector.177451, i16, %union.SegmentSelector.177451, i16, %union.SegmentSelector.177451, i16, %union.SegmentSelector.177451 }
%union.SegmentSelector.177451 = type { i16 }
%struct.AddressSpace.177454 = type { i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453 }
%struct.Reg.177453 = type { %union.anon.177445 }
%struct.GPR.177455 = type { i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453, i64, %struct.Reg.177453 }
%struct.X87Stack.177458 = type { [8 x %struct.anon.3.177457] }
%struct.anon.3.177457 = type { [6 x i8], %struct.float80_t.177456 }
%struct.float80_t.177456 = type { [10 x i8] }
%struct.MMX.177462 = type { [8 x %struct.anon.4.177461] }
%struct.anon.4.177461 = type { i64, %union.vec64_t.177460 }
%union.vec64_t.177460 = type { %struct.uint64v1_t.177459 }
%struct.uint64v1_t.177459 = type { [1 x i64] }
%struct.FPUStatusFlags.177463 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.177445 = type { i64 }
%union.FPU.177472 = type { %struct.anon.13.177471 }
%struct.anon.13.177471 = type { %struct.FpuFXSAVE.177470, [96 x i8] }
%struct.FpuFXSAVE.177470 = type { %union.SegmentSelector.177451, %union.SegmentSelector.177451, %union.FPUAbridgedTagWord.177464, i8, i16, i32, %union.SegmentSelector.177451, i16, i32, %union.SegmentSelector.177451, i16, %union.FPUControlStatus.177465, %union.FPUControlStatus.177465, [8 x %struct.FPUStackElem.177467], [16 x %union.vec128_t.177469] }
%union.FPUAbridgedTagWord.177464 = type { i8 }
%union.FPUControlStatus.177465 = type { i32 }
%struct.FPUStackElem.177467 = type { %union.anon.11.177466, [6 x i8] }
%union.anon.11.177466 = type { %struct.float80_t.177456 }
%union.vec128_t.177469 = type { %struct.uint128v1_t.177468 }
%struct.uint128v1_t.177468 = type { [1 x i128] }
%struct.SegmentCaches.177474 = type { %struct.SegmentShadow.177473, %struct.SegmentShadow.177473, %struct.SegmentShadow.177473, %struct.SegmentShadow.177473, %struct.SegmentShadow.177473, %struct.SegmentShadow.177473 }
%struct.SegmentShadow.177473 = type { %union.anon.177445, i32, i32 }
%struct.K_REG.177476 = type { [8 x %struct.anon.18.177475] }
%struct.anon.18.177475 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_2970(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i121 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i121, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 160
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 160
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 160, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 160, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 160
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 160, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 160, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 160, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 8
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #13
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 4
  %34 = load i32, ptr %ESI, align 4
  %35 = zext i32 %34 to i64
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %36, i64 noundef %33, i32 noundef %34) #13
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 7
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %NEXT_PC, align 8
  %41 = add i64 %40, 13288
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %42, i64 noundef %41) #13
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %37
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 2
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RAX, align 8
  %47 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call i32 @__remill_read_memory_32(ptr noundef %47, i64 noundef %46) #13
  %conv.i.i80 = zext i32 %call.i.i79 to i64
  store i64 %conv.i.i80, ptr %RDX, align 8
  store ptr %47, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %43
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 7
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %NEXT_PC, align 8
  %52 = add i64 %51, 13615
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %53, i64 noundef %52) #13
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %53, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %48
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 3
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %RAX, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %58, i64 noundef %57) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %59 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %60 = and i8 %59, 1
  %conv.i.i.i32 = xor i8 %60, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %61 = trunc i32 %xor1.i.i.i.i35 to i8
  %62 = lshr i8 %61, 4
  %conv2.i.i.i36 = and i8 %62, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %58, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %54
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %67 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %67, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %68 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %68, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %66, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %63
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 2
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i32, ptr %EDX, align 4
  %73 = zext i32 %72 to i64
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %73, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %74, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %69
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RCX, align 8
  %79 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %78 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %80 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %80, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %81 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %82 = and i8 %81, 1
  %conv.i.i.i = xor i8 %82, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %83 = trunc i32 %xor1.i.i.i.i to i8
  %84 = lshr i8 %83, 4
  %conv2.i.i.i = and i8 %84, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %79, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %75
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RCX, align 8
  %89 = load i32, ptr %EDX, align 4
  %90 = zext i32 %89 to i64
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %88 to i32
  %sext.i = shl i64 %88, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %90, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %92 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %92, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %89, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %85
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 3
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RCX, align 8
  %97 = load ptr, ptr %MEMORY, align 8
  %conv.i.i83 = trunc i64 %96 to i32
  %and3.i.i = and i32 1, %conv.i.i83
  %conv.i22.i84 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i84, ptr %RCX, align 8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i85, align 1
  %conv.i.i.i86 = trunc i32 %and3.i.i to i8
  %98 = and i8 %conv.i.i.i86, 1
  %conv.i23.i87 = xor i8 %98, 1
  %pf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i87, ptr %pf.i.i88, align 1
  %cmp.i.i.i89 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i90 to i8
  %zf.i.i91 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i91, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i94, align 1
  store ptr %97, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %93
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i32, ptr %ECX, align 4
  %103 = zext i32 %102 to i64
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %102, i32 noundef 0, i32 noundef %102) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %102 to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %106 = and i8 %105, 1
  %conv.i.i.i57 = xor i8 %106, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %102, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %102, i32 noundef 0, i32 noundef %102) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %102, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %102, i32 noundef 0, i32 noundef %102) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %102, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %102, i32 noundef 0, i32 noundef %102) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %99
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 3
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %111 = load i8, ptr %zf.i, align 1
  store i8 %111, ptr %CL, align 1
  store ptr %110, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %107
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 2
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i8, ptr %AL, align 1
  %116 = zext i8 %115 to i64
  %117 = load i8, ptr %CL, align 1
  %118 = zext i8 %117 to i64
  %119 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %118, %116
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i95 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %120 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %121 = and i8 %120, 1
  %conv.i27.i = xor i8 %121, 1
  %pf.i.i96 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i96, align 1
  %122 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i97 = and i32 %122, 255
  %cmp.i.i.i98 = icmp eq i8 %or3.i.i, 0
  %123 = trunc i64 %116 to i32
  %conv1.i.i.i = and i32 %123, 255
  %124 = trunc i64 %118 to i32
  %conv2.i.i.i99 = and i32 %124, 255
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i98, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #13
  %conv3.i.i101 = zext i1 %call.i.i.i100 to i8
  %zf.i.i102 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i101, ptr %zf.i.i102, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #13
  %conv6.i.i103 = zext i1 %call4.i.i.i to i8
  %sf.i.i104 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i103, ptr %sf.i.i104, align 1
  %of.i.i105 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i105, align 1
  %af.i.i106 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i106, align 1
  store ptr %119, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %112
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 2
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i8, ptr %AL, align 1
  %129 = zext i8 %128 to i64
  %130 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %129
  %and3.i.i107 = trunc i64 %and3.i15.i to i8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i108, align 1
  %131 = and i8 %and3.i.i107, 1
  %conv.i14.i = xor i8 %131, 1
  %pf.i.i109 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i109, align 1
  %132 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i110 = and i32 %132, 255
  %cmp.i.i.i111 = icmp eq i8 %and3.i.i107, 0
  %133 = trunc i64 %129 to i32
  %conv1.i.i.i112 = and i32 %133, 255
  %call.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #13
  %conv3.i.i114 = zext i1 %call.i.i.i113 to i8
  %zf.i.i115 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i114, ptr %zf.i.i115, align 1
  %call4.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #13
  %conv6.i.i117 = zext i1 %call4.i.i.i116 to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i117, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i120, align 1
  store ptr %130, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %125
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 6
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %NEXT_PC, align 8
  %138 = add i64 %137, 5
  %139 = load i64, ptr %NEXT_PC, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %141 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %141, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %138, i64 %139
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %140, ptr %MEMORY, align 8
  %142 = load i64, ptr %NEXT_PC, align 8
  store i64 %142, ptr %PC, align 8
  %143 = load ptr, ptr %MEMORY, align 8
  ret ptr %143
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_29b7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %R9D = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %R9 = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i258 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i259 = zext i32 %call.i.i258 to i64
  store i64 %conv.i.i259, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 8
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i256 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i257 = zext i32 %call.i.i256 to i64
  store i64 %conv.i.i257, ptr %R9, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RSP, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %R8, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %R8, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 -16, %21
  store i64 %add.i.i146, ptr %R8, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %21
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, -16
  %23 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %23, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %25 = and i8 %24, 1
  %conv.i.i.i153 = xor i8 %25, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, -16
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %21
  %26 = trunc i64 %xor1.i.i.i.i156 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i157 = and i8 %27, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %21
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %18
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 4
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 64
  %33 = load i64, ptr %R8, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i253 = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %32, i64 noundef %33) #13
  store ptr %call.i.i253, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %R8, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RSP, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %RSP, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  store i64 %43, ptr %RSI, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %40
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 4
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RSI, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %48
  store i64 %add.i.i117, ptr %RSI, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %48
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %50 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %50, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %52 = and i8 %51, 1
  %conv.i.i.i124 = xor i8 %52, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %48
  %53 = trunc i64 %xor1.i.i.i.i127 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i128 = and i8 %54, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %48
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %45
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 4
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RBP, align 8
  %59 = sub i64 %58, 56
  %60 = load i64, ptr %RSI, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %call.i.i252 = call ptr @__remill_write_memory_64(ptr noundef %61, i64 noundef %59, i64 noundef %60) #13
  store ptr %call.i.i252, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %55
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RSI, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  store i64 %65, ptr %RSP, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %62
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RSP, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  store i64 %70, ptr %RDX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %67
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RDX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %75
  store i64 %add.i.i88, ptr %RDX, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %75
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %77 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %77, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %79 = and i8 %78, 1
  %conv.i.i.i95 = xor i8 %79, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %75
  %80 = trunc i64 %xor1.i.i.i.i98 to i8
  %81 = lshr i8 %80, 4
  %conv2.i.i.i99 = and i8 %81, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %75
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %72
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 4
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RBP, align 8
  %86 = sub i64 %85, 48
  %87 = load i64, ptr %RDX, align 8
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i251 = call ptr @__remill_write_memory_64(ptr noundef %88, i64 noundef %86, i64 noundef %87) #13
  store ptr %call.i.i251, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %82
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 3
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RDX, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  store i64 %92, ptr %RSP, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %89
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i64, ptr %RSP, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  store i64 %97, ptr %RCX, align 8
  store ptr %98, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %94
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 4
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RCX, align 8
  %103 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %102
  store i64 %add.i.i59, ptr %RCX, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %102
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %104 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %104, i64 noundef %102, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %106 = and i8 %105, 1
  %conv.i.i.i66 = xor i8 %106, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %102
  %107 = trunc i64 %xor1.i.i.i.i69 to i8
  %108 = lshr i8 %107, 4
  %conv2.i.i.i70 = and i8 %108, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %102, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %102, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %102
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %102, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %99
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 4
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RBP, align 8
  %113 = sub i64 %112, 40
  %114 = load i64, ptr %RCX, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %call.i.i250 = call ptr @__remill_write_memory_64(ptr noundef %115, i64 noundef %113, i64 noundef %114) #13
  store ptr %call.i.i250, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %109
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 3
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %RCX, align 8
  %120 = load ptr, ptr %MEMORY, align 8
  store i64 %119, ptr %RSP, align 8
  store ptr %120, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %116
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load i64, ptr %RSP, align 8
  %125 = load ptr, ptr %MEMORY, align 8
  store i64 %124, ptr %RAX, align 8
  store ptr %125, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %121
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 4
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RAX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -80, %129
  store i64 %add.i.i30, ptr %RAX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %129
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -80
  %131 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %131, i64 noundef %129, i64 noundef -80, i64 noundef %add.i.i30) #13
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %132 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %133 = and i8 %132, 1
  %conv.i.i.i37 = xor i8 %133, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -80
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %129
  %134 = trunc i64 %xor1.i.i.i.i40 to i8
  %135 = lshr i8 %134, 4
  %conv2.i.i.i41 = and i8 %135, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %129, i64 noundef -80, i64 noundef %add.i.i30) #13
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %129, i64 noundef -80, i64 noundef %add.i.i30) #13
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %129
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %129, i64 noundef -80, i64 noundef %add.i.i30) #13
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %130, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %126
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 4
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %RBP, align 8
  %140 = sub i64 %139, 32
  %141 = load i64, ptr %RAX, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  %call.i.i249 = call ptr @__remill_write_memory_64(ptr noundef %142, i64 noundef %140, i64 noundef %141) #13
  store ptr %call.i.i249, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %136
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 3
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %RAX, align 8
  %147 = load ptr, ptr %MEMORY, align 8
  store i64 %146, ptr %RSP, align 8
  store ptr %147, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %143
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RSP, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  store i64 %151, ptr %RAX, align 8
  store ptr %152, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %148
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 4
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %RAX, align 8
  %157 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %156
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %156
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %158 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %158, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %159 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %160 = and i8 %159, 1
  %conv.i.i.i8 = xor i8 %160, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %156
  %161 = trunc i64 %xor1.i.i.i.i11 to i8
  %162 = lshr i8 %161, 4
  %conv2.i.i.i12 = and i8 %162, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %156
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %157, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %153
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 4
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %RBP, align 8
  %167 = sub i64 %166, 24
  %168 = load i64, ptr %RAX, align 8
  %169 = load ptr, ptr %MEMORY, align 8
  %call.i.i248 = call ptr @__remill_write_memory_64(ptr noundef %169, i64 noundef %167, i64 noundef %168) #13
  store ptr %call.i.i248, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %163
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 3
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i64, ptr %RAX, align 8
  %174 = load ptr, ptr %MEMORY, align 8
  store i64 %173, ptr %RSP, align 8
  store ptr %174, ptr %MEMORY, align 8
  br label %175

175:                                              ; preds = %170
  %176 = load i64, ptr %NEXT_PC, align 8
  store i64 %176, ptr %PC, align 8
  %177 = add i64 %176, 3
  store i64 %177, ptr %NEXT_PC, align 8
  %178 = load i64, ptr %R8, align 8
  %179 = load i32, ptr %R9D, align 4
  %180 = zext i32 %179 to i64
  %181 = load ptr, ptr %MEMORY, align 8
  %call.i.i246 = call ptr @__remill_write_memory_32(ptr noundef %181, i64 noundef %178, i32 noundef %179) #13
  store ptr %call.i.i246, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %175
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 2
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load i64, ptr %RSI, align 8
  %186 = load i32, ptr %EDI, align 4
  %187 = zext i32 %186 to i64
  %188 = load ptr, ptr %MEMORY, align 8
  %call.i.i245 = call ptr @__remill_write_memory_32(ptr noundef %188, i64 noundef %185, i32 noundef %186) #13
  store ptr %call.i.i245, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %182
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 6
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i64, ptr %RDX, align 8
  %193 = load ptr, ptr %MEMORY, align 8
  %call.i.i244 = call ptr @__remill_write_memory_32(ptr noundef %193, i64 noundef %192, i32 noundef 0) #13
  store ptr %call.i.i244, ptr %MEMORY, align 8
  br label %194

194:                                              ; preds = %189
  %195 = load i64, ptr %NEXT_PC, align 8
  store i64 %195, ptr %PC, align 8
  %196 = add i64 %195, 6
  store i64 %196, ptr %NEXT_PC, align 8
  %197 = load i64, ptr %RCX, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  %call.i.i243 = call ptr @__remill_write_memory_32(ptr noundef %198, i64 noundef %197, i32 noundef 0) #13
  store ptr %call.i.i243, ptr %MEMORY, align 8
  br label %199

199:                                              ; preds = %194
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = add i64 %200, 6
  store i64 %201, ptr %NEXT_PC, align 8
  %202 = load i64, ptr %RAX, align 8
  %203 = load ptr, ptr %MEMORY, align 8
  %call.i.i242 = call ptr @__remill_write_memory_32(ptr noundef %203, i64 noundef %202, i32 noundef 0) #13
  store ptr %call.i.i242, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %199
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 7
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i64, ptr %NEXT_PC, align 8
  %208 = add i64 %207, 13920
  %209 = load ptr, ptr %MEMORY, align 8
  %call.i.i262 = call i64 @__remill_read_memory_64(ptr noundef %209, i64 noundef %208) #13
  store i64 %call.i.i262, ptr %RAX, align 8
  store ptr %209, ptr %MEMORY, align 8
  br label %210

210:                                              ; preds = %204
  %211 = load i64, ptr %NEXT_PC, align 8
  store i64 %211, ptr %PC, align 8
  %212 = add i64 %211, 4
  store i64 %212, ptr %NEXT_PC, align 8
  %213 = load i64, ptr %RAX, align 8
  %214 = load ptr, ptr %MEMORY, align 8
  store i64 %213, ptr %RAX, align 8
  %call.i.i.i175 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %213, i64 noundef 0, i64 noundef %213) #13
  %conv.i.i176 = zext i1 %call.i.i.i175 to i8
  %cf.i.i177 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i176, ptr %cf.i.i177, align 1
  %conv.i.i.i.i178 = trunc i64 %213 to i8
  %215 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i178)
  %216 = and i8 %215, 1
  %conv.i.i.i179 = xor i8 %216, 1
  %pf.i.i.i180 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i179, ptr %pf.i.i.i180, align 1
  %af.i.i.i181 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i181, align 1
  %cmp.i.i.i.i182 = icmp eq i64 %213, 0
  %call.i.i.i.i183 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i182, i64 noundef %213, i64 noundef 0, i64 noundef %213) #13
  %conv5.i.i.i184 = zext i1 %call.i.i.i.i183 to i8
  %zf.i.i.i185 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i184, ptr %zf.i.i.i185, align 1
  %cmp.i27.i.i.i186 = icmp slt i64 %213, 0
  %call1.i.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i186, i64 noundef %213, i64 noundef 0, i64 noundef %213) #13
  %conv8.i.i.i188 = zext i1 %call1.i.i.i.i187 to i8
  %sf.i.i.i189 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i188, ptr %sf.i.i.i189, align 1
  %xor.i28.i.i.i190 = lshr i64 %213, 63
  %call.i30.i.i.i191 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %213, i64 noundef 0, i64 noundef %213) #13
  %conv11.i.i.i192 = zext i1 %call.i30.i.i.i191 to i8
  %of.i.i.i193 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i192, ptr %of.i.i.i193, align 1
  store ptr %214, ptr %MEMORY, align 8
  br label %217

217:                                              ; preds = %210
  %218 = load i64, ptr %NEXT_PC, align 8
  store i64 %218, ptr %PC, align 8
  %219 = add i64 %218, 4
  store i64 %219, ptr %NEXT_PC, align 8
  %220 = load i64, ptr %RBP, align 8
  %221 = sub i64 %220, 16
  %222 = load i64, ptr %RAX, align 8
  %223 = load ptr, ptr %MEMORY, align 8
  %call.i.i247 = call ptr @__remill_write_memory_64(ptr noundef %223, i64 noundef %221, i64 noundef %222) #13
  store ptr %call.i.i247, ptr %MEMORY, align 8
  br label %224

224:                                              ; preds = %217
  %225 = load i64, ptr %NEXT_PC, align 8
  store i64 %225, ptr %PC, align 8
  %226 = add i64 %225, 7
  store i64 %226, ptr %NEXT_PC, align 8
  %227 = load i64, ptr %NEXT_PC, align 8
  %228 = add i64 %227, 13097
  %229 = load ptr, ptr %MEMORY, align 8
  %call.i.i261 = call i64 @__remill_read_memory_64(ptr noundef %229, i64 noundef %228) #13
  store i64 %call.i.i261, ptr %RAX, align 8
  store ptr %229, ptr %MEMORY, align 8
  br label %230

230:                                              ; preds = %224
  %231 = load i64, ptr %NEXT_PC, align 8
  store i64 %231, ptr %PC, align 8
  %232 = add i64 %231, 2
  store i64 %232, ptr %NEXT_PC, align 8
  %233 = load i64, ptr %RAX, align 8
  %234 = load ptr, ptr %MEMORY, align 8
  %call.i.i254 = call i32 @__remill_read_memory_32(ptr noundef %234, i64 noundef %233) #13
  %conv.i.i255 = zext i32 %call.i.i254 to i64
  store i64 %conv.i.i255, ptr %RDX, align 8
  store ptr %234, ptr %MEMORY, align 8
  br label %235

235:                                              ; preds = %230
  %236 = load i64, ptr %NEXT_PC, align 8
  store i64 %236, ptr %PC, align 8
  %237 = add i64 %236, 7
  store i64 %237, ptr %NEXT_PC, align 8
  %238 = load i64, ptr %NEXT_PC, align 8
  %239 = add i64 %238, 13456
  %240 = load ptr, ptr %MEMORY, align 8
  %call.i.i260 = call i64 @__remill_read_memory_64(ptr noundef %240, i64 noundef %239) #13
  store i64 %call.i.i260, ptr %RAX, align 8
  store ptr %240, ptr %MEMORY, align 8
  br label %241

241:                                              ; preds = %235
  %242 = load i64, ptr %NEXT_PC, align 8
  store i64 %242, ptr %PC, align 8
  %243 = add i64 %242, 3
  store i64 %243, ptr %NEXT_PC, align 8
  %244 = load i64, ptr %RAX, align 8
  %245 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %245, i64 noundef %244) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i194 = icmp ult i32 %call.i.i, 10
  %call.i.i.i195 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i194, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i195 to i8
  %cf.i.i196 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i196, align 1
  %conv.i.i.i.i197 = trunc i32 %sub.i.i to i8
  %246 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i197)
  %247 = and i8 %246, 1
  %conv.i.i.i198 = xor i8 %247, 1
  %pf.i.i.i199 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i198, ptr %pf.i.i.i199, align 1
  %xor.i.i.i.i200 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i201 = xor i32 %xor.i.i.i.i200, %sub.i.i
  %248 = trunc i32 %xor1.i.i.i.i201 to i8
  %249 = lshr i8 %248, 4
  %conv2.i.i.i202 = and i8 %249, 1
  %af.i.i.i203 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i202, ptr %af.i.i.i203, align 1
  %cmp.i.i.i.i204 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i204, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i206 = zext i1 %call.i.i.i.i205 to i8
  %zf.i.i.i207 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i206, ptr %zf.i.i.i207, align 1
  %cmp.i27.i.i.i208 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i209 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i208, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i210 = zext i1 %call1.i.i.i.i209 to i8
  %sf.i.i.i211 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i210, ptr %sf.i.i.i211, align 1
  %xor.i28.i.i.i212 = lshr i32 %xor.i.i.i.i200, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i213 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i214 = add nuw nsw i32 %xor3.i.i.i.i213, %xor.i28.i.i.i212
  %cmp.i29.i.i.i215 = icmp eq i32 %add.i.i.i.i214, 2
  %call.i30.i.i.i216 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i215, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i217 = zext i1 %call.i30.i.i.i216 to i8
  %of.i.i.i218 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i217, ptr %of.i.i.i218, align 1
  store ptr %245, ptr %MEMORY, align 8
  br label %250

250:                                              ; preds = %241
  %251 = load i64, ptr %NEXT_PC, align 8
  store i64 %251, ptr %PC, align 8
  %252 = add i64 %251, 3
  store i64 %252, ptr %NEXT_PC, align 8
  %253 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %254 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %254, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %255 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %255, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %253, ptr %MEMORY, align 8
  br label %256

256:                                              ; preds = %250
  %257 = load i64, ptr %NEXT_PC, align 8
  store i64 %257, ptr %PC, align 8
  %258 = add i64 %257, 2
  store i64 %258, ptr %NEXT_PC, align 8
  %259 = load i32, ptr %EDX, align 4
  %260 = zext i32 %259 to i64
  %261 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %260, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %261, ptr %MEMORY, align 8
  br label %262

262:                                              ; preds = %256
  %263 = load i64, ptr %NEXT_PC, align 8
  store i64 %263, ptr %PC, align 8
  %264 = add i64 %263, 3
  store i64 %264, ptr %NEXT_PC, align 8
  %265 = load i64, ptr %RCX, align 8
  %266 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %265 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %267 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %267, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %268 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %269 = and i8 %268, 1
  %conv.i.i.i = xor i8 %269, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %270 = trunc i32 %xor1.i.i.i.i to i8
  %271 = lshr i8 %270, 4
  %conv2.i.i.i = and i8 %271, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %266, ptr %MEMORY, align 8
  br label %272

272:                                              ; preds = %262
  %273 = load i64, ptr %NEXT_PC, align 8
  store i64 %273, ptr %PC, align 8
  %274 = add i64 %273, 3
  store i64 %274, ptr %NEXT_PC, align 8
  %275 = load i64, ptr %RCX, align 8
  %276 = load i32, ptr %EDX, align 4
  %277 = zext i32 %276 to i64
  %278 = load ptr, ptr %MEMORY, align 8
  %conv.i.i237 = trunc i64 %275 to i32
  %sext.i = shl i64 %275, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %277, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %279 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i238 = icmp ult i64 %279, -4294967296
  %call.i.i.i239 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i238, i32 noundef %conv.i.i237, i32 noundef %276, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i239 to i8
  %cf.i.i240 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i240, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %278, ptr %MEMORY, align 8
  br label %280

280:                                              ; preds = %272
  %281 = load i64, ptr %NEXT_PC, align 8
  store i64 %281, ptr %PC, align 8
  %282 = add i64 %281, 3
  store i64 %282, ptr %NEXT_PC, align 8
  %283 = load i64, ptr %RCX, align 8
  %284 = load ptr, ptr %MEMORY, align 8
  %conv.i.i263 = trunc i64 %283 to i32
  %and3.i.i = and i32 1, %conv.i.i263
  %conv.i22.i264 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i264, ptr %RCX, align 8
  %cf.i.i265 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i265, align 1
  %conv.i.i.i266 = trunc i32 %and3.i.i to i8
  %285 = and i8 %conv.i.i.i266, 1
  %conv.i23.i267 = xor i8 %285, 1
  %pf.i.i268 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i267, ptr %pf.i.i268, align 1
  %cmp.i.i.i269 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i270 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i269, i32 noundef %conv.i.i263, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i270 to i8
  %zf.i.i271 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i271, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i263, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i272 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i272, align 1
  %of.i.i273 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i273, align 1
  %af.i.i274 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i274, align 1
  store ptr %284, ptr %MEMORY, align 8
  br label %286

286:                                              ; preds = %280
  %287 = load i64, ptr %NEXT_PC, align 8
  store i64 %287, ptr %PC, align 8
  %288 = add i64 %287, 3
  store i64 %288, ptr %NEXT_PC, align 8
  %289 = load i32, ptr %ECX, align 4
  %290 = zext i32 %289 to i64
  %291 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i219 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %289, i32 noundef 0, i32 noundef %289) #13
  %conv.i12.i = zext i1 %call.i.i.i219 to i8
  %cf.i.i220 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i220, align 1
  %conv.i.i.i.i221 = trunc i32 %289 to i8
  %292 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i221)
  %293 = and i8 %292, 1
  %conv.i.i.i222 = xor i8 %293, 1
  %pf.i.i.i223 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i222, ptr %pf.i.i.i223, align 1
  %af.i.i.i224 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i224, align 1
  %cmp.i.i.i.i225 = icmp eq i32 %289, 0
  %call.i.i.i.i226 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i225, i32 noundef %289, i32 noundef 0, i32 noundef %289) #13
  %conv5.i.i.i227 = zext i1 %call.i.i.i.i226 to i8
  %zf.i.i.i228 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i227, ptr %zf.i.i.i228, align 1
  %cmp.i27.i.i.i229 = icmp slt i32 %289, 0
  %call1.i.i.i.i230 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i229, i32 noundef %289, i32 noundef 0, i32 noundef %289) #13
  %conv8.i.i.i231 = zext i1 %call1.i.i.i.i230 to i8
  %sf.i.i.i232 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i231, ptr %sf.i.i.i232, align 1
  %xor.i28.i.i.i233 = lshr i32 %289, 31
  %call.i30.i.i.i234 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %289, i32 noundef 0, i32 noundef %289) #13
  %conv11.i.i.i235 = zext i1 %call.i30.i.i.i234 to i8
  %of.i.i.i236 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i235, ptr %of.i.i.i236, align 1
  store ptr %291, ptr %MEMORY, align 8
  br label %294

294:                                              ; preds = %286
  %295 = load i64, ptr %NEXT_PC, align 8
  store i64 %295, ptr %PC, align 8
  %296 = add i64 %295, 3
  store i64 %296, ptr %NEXT_PC, align 8
  %297 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %298 = load i8, ptr %zf.i, align 1
  store i8 %298, ptr %CL, align 1
  store ptr %297, ptr %MEMORY, align 8
  br label %299

299:                                              ; preds = %294
  %300 = load i64, ptr %NEXT_PC, align 8
  store i64 %300, ptr %PC, align 8
  %301 = add i64 %300, 2
  store i64 %301, ptr %NEXT_PC, align 8
  %302 = load i8, ptr %AL, align 1
  %303 = zext i8 %302 to i64
  %304 = load i8, ptr %CL, align 1
  %305 = zext i8 %304 to i64
  %306 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %305, %303
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i275 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i275, align 1
  %307 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %308 = and i8 %307, 1
  %conv.i27.i = xor i8 %308, 1
  %pf.i.i276 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i276, align 1
  %309 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i277 = and i32 %309, 255
  %cmp.i.i.i278 = icmp eq i8 %or3.i.i, 0
  %310 = trunc i64 %303 to i32
  %conv1.i.i.i = and i32 %310, 255
  %311 = trunc i64 %305 to i32
  %conv2.i.i.i279 = and i32 %311, 255
  %call.i.i.i280 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i278, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i279, i32 noundef %conv.i.i.i277) #13
  %conv3.i.i281 = zext i1 %call.i.i.i280 to i8
  %zf.i.i282 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i281, ptr %zf.i.i282, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i279, i32 noundef %conv.i.i.i277) #13
  %conv6.i.i283 = zext i1 %call4.i.i.i to i8
  %sf.i.i284 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i283, ptr %sf.i.i284, align 1
  %of.i.i285 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i285, align 1
  %af.i.i286 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i286, align 1
  store ptr %306, ptr %MEMORY, align 8
  br label %312

312:                                              ; preds = %299
  %313 = load i64, ptr %NEXT_PC, align 8
  store i64 %313, ptr %PC, align 8
  %314 = add i64 %313, 2
  store i64 %314, ptr %NEXT_PC, align 8
  %315 = load i8, ptr %AL, align 1
  %316 = zext i8 %315 to i64
  %317 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %316
  %and3.i.i287 = trunc i64 %and3.i15.i to i8
  %cf.i.i288 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i288, align 1
  %318 = and i8 %and3.i.i287, 1
  %conv.i14.i = xor i8 %318, 1
  %pf.i.i289 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i289, align 1
  %319 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i290 = and i32 %319, 255
  %cmp.i.i.i291 = icmp eq i8 %and3.i.i287, 0
  %320 = trunc i64 %316 to i32
  %conv1.i.i.i292 = and i32 %320, 255
  %call.i.i.i293 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i291, i32 noundef %conv1.i.i.i292, i32 noundef 1, i32 noundef %conv.i.i.i290) #13
  %conv3.i.i294 = zext i1 %call.i.i.i293 to i8
  %zf.i.i295 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i294, ptr %zf.i.i295, align 1
  %call4.i.i.i296 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i292, i32 noundef 1, i32 noundef %conv.i.i.i290) #13
  %conv6.i.i297 = zext i1 %call4.i.i.i296 to i8
  %sf.i.i298 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i297, ptr %sf.i.i298, align 1
  %of.i.i299 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i299, align 1
  %af.i.i300 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i300, align 1
  store ptr %317, ptr %MEMORY, align 8
  br label %321

321:                                              ; preds = %312
  %322 = load i64, ptr %NEXT_PC, align 8
  store i64 %322, ptr %PC, align 8
  %323 = add i64 %322, 6
  store i64 %323, ptr %NEXT_PC, align 8
  %324 = load i64, ptr %NEXT_PC, align 8
  %325 = add i64 %324, 5
  %326 = load i64, ptr %NEXT_PC, align 8
  %327 = load ptr, ptr %MEMORY, align 8
  %zf.i241 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %328 = load i8, ptr %zf.i241, align 1
  %tobool.not.i = icmp eq i8 %328, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %325, i64 %326
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %327, ptr %MEMORY, align 8
  %329 = load i64, ptr %NEXT_PC, align 8
  store i64 %329, ptr %PC, align 8
  %330 = load ptr, ptr %MEMORY, align 8
  ret ptr %330
}

define ptr @BB_2a6e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2a74(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 13061
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 13388
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2aaa(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i130 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i130, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i125 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i126 = zext i32 %call.i.i125 to i64
  store i64 %conv.i.i126, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RCX, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %12
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %16
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i32, ptr %EDX, align 4
  %24 = zext i32 %23 to i64
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv.i12.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i32 %23 to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %27 = and i8 %26, 1
  %conv.i.i.i95 = xor i8 %27, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %af.i.i.i97 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i97, align 1
  %cmp.i.i.i.i98 = icmp eq i32 %23, 0
  %call.i.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i98, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv5.i.i.i100 = zext i1 %call.i.i.i.i99 to i8
  %zf.i.i.i101 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i100, ptr %zf.i.i.i101, align 1
  %cmp.i27.i.i.i102 = icmp slt i32 %23, 0
  %call1.i.i.i.i103 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i102, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv8.i.i.i104 = zext i1 %call1.i.i.i.i103 to i8
  %sf.i.i.i105 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i104, ptr %sf.i.i.i105, align 1
  %xor.i28.i.i.i106 = lshr i32 %23, 31
  %call.i30.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv11.i.i.i108 = zext i1 %call.i30.i.i.i107 to i8
  %of.i.i.i109 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i108, ptr %of.i.i.i109, align 1
  store ptr %25, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i32, ptr %EAX, align 4
  %32 = zext i32 %31 to i64
  %33 = load ptr, ptr %MEMORY, align 8
  %zf.i114 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %34 = load i8, ptr %zf.i114, align 1
  %tobool.not.i = icmp eq i8 %34, 0
  %call3.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call3.i, i64 %32, i64 %dst.coerce.val.i
  %conv.i20.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i20.i, ptr %RCX, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 7
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %NEXT_PC, align 8
  %39 = add i64 %38, 13769
  %40 = load ptr, ptr %MEMORY, align 8
  store i64 %39, ptr %RAX, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i32, ptr %ECX, align 4
  %45 = zext i32 %44 to i64
  %46 = load ptr, ptr %MEMORY, align 8
  %sext.i131 = shl i64 %45, 32
  %conv.i12.i132 = ashr exact i64 %sext.i131, 32
  store i64 %conv.i12.i132, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 4
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load i64, ptr %RCX, align 8
  %52 = mul i64 %51, 8
  %53 = add i64 %50, %52
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i129 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #13
  store i64 %call.i.i129, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %47
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RCX, align 8
  %59 = load i32, ptr %ECX, align 4
  %60 = zext i32 %59 to i64
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i157 = trunc i64 %58 to i32
  %xor3.i.i = xor i32 %59, %conv.i.i157
  %conv.i27.i158 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i158, ptr %RCX, align 8
  %cf.i.i159 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i159, align 1
  %conv.i.i.i160 = trunc i32 %xor3.i.i to i8
  %62 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i160)
  %63 = and i8 %62, 1
  %conv.i28.i161 = xor i8 %63, 1
  %pf.i.i162 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i161, ptr %pf.i.i162, align 1
  %cmp.i.i.i163 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i163, i32 noundef %conv.i.i157, i32 noundef %59, i32 noundef %xor3.i.i) #13
  %conv3.i.i165 = zext i1 %call.i.i.i164 to i8
  %zf.i.i166 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i165, ptr %zf.i.i166, align 1
  %cmp.i19.i.i167 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i168 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i167, i32 noundef %conv.i.i157, i32 noundef %59, i32 noundef %xor3.i.i) #13
  %conv6.i.i169 = zext i1 %call1.i.i.i168 to i8
  %sf.i.i170 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i169, ptr %sf.i.i170, align 1
  %of.i.i171 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i171, align 1
  %af.i.i172 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i173 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i173, ptr %af.i.i172, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %55
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 3
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv.i12.i73 = zext i1 %call.i.i.i72 to i8
  %cf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i73, ptr %cf.i.i74, align 1
  %conv.i.i.i.i75 = trunc i32 %67 to i8
  %70 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i75)
  %71 = and i8 %70, 1
  %conv.i.i.i76 = xor i8 %71, 1
  %pf.i.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i76, ptr %pf.i.i.i77, align 1
  %af.i.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i78, align 1
  %cmp.i.i.i.i79 = icmp eq i32 %67, 0
  %call.i.i.i.i80 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i79, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv5.i.i.i81 = zext i1 %call.i.i.i.i80 to i8
  %zf.i.i.i82 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i81, ptr %zf.i.i.i82, align 1
  %cmp.i27.i.i.i83 = icmp slt i32 %67, 0
  %call1.i.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i83, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv8.i.i.i85 = zext i1 %call1.i.i.i.i84 to i8
  %sf.i.i.i86 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i85, ptr %sf.i.i.i86, align 1
  %xor.i28.i.i.i87 = lshr i32 %67, 31
  %call.i30.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv11.i.i.i89 = zext i1 %call.i30.i.i.i88 to i8
  %of.i.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i89, ptr %of.i.i.i90, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %64
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RCX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  %zf.i115 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %77 = load i8, ptr %zf.i115, align 1
  %tobool.not.i116 = icmp eq i8 %77, 0
  %call3.i117 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i116) #14
  %dst.coerce.val.i118 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call3.i117, i64 %75, i64 %dst.coerce.val.i118
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %76, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %72
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 3
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RAX, align 8
  %82 = load i64, ptr %RCX, align 8
  %83 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %81, %82
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %81, %82
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %84 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %85 = and i8 %84, 1
  %conv.i.i.i6 = xor i8 %85, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %82, %81
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %86 = trunc i64 %xor1.i.i.i.i9 to i8
  %87 = lshr i8 %86, 4
  %conv2.i.i.i10 = and i8 %87, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %81, %82
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %81
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %78
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 4
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RBP, align 8
  %92 = sub i64 %91, 72
  %93 = load i64, ptr %RAX, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i122 = call ptr @__remill_write_memory_64(ptr noundef %94, i64 noundef %92, i64 noundef %93) #13
  store ptr %call.i.i122, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %88
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 7
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %NEXT_PC, align 8
  %99 = add i64 %98, 12947
  %100 = load ptr, ptr %MEMORY, align 8
  %call.i.i128 = call i64 @__remill_read_memory_64(ptr noundef %100, i64 noundef %99) #13
  store i64 %call.i.i128, ptr %RAX, align 8
  store ptr %100, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %95
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 2
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RAX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %call.i.i123 = call i32 @__remill_read_memory_32(ptr noundef %105, i64 noundef %104) #13
  %conv.i.i124 = zext i32 %call.i.i123 to i64
  store i64 %conv.i.i124, ptr %RDX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %101
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 7
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %NEXT_PC, align 8
  %110 = add i64 %109, 13258
  %111 = load ptr, ptr %MEMORY, align 8
  %call.i.i127 = call i64 @__remill_read_memory_64(ptr noundef %111, i64 noundef %110) #13
  store i64 %call.i.i127, ptr %RAX, align 8
  store ptr %111, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %106
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %RAX, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %116, i64 noundef %115) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %118 = and i8 %117, 1
  %conv.i.i.i32 = xor i8 %118, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %119 = trunc i32 %xor1.i.i.i.i35 to i8
  %120 = lshr i8 %119, 4
  %conv2.i.i.i36 = and i8 %120, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %112
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %125 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %125, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %126 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %126, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %124, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %121
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 2
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i32, ptr %EDX, align 4
  %131 = zext i32 %130 to i64
  %132 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %131, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %132, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %127
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 3
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %RCX, align 8
  %137 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %136 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %138 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %138, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %139 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %140 = and i8 %139, 1
  %conv.i.i.i = xor i8 %140, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %141 = trunc i32 %xor1.i.i.i.i to i8
  %142 = lshr i8 %141, 4
  %conv2.i.i.i = and i8 %142, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %133
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 3
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %RCX, align 8
  %147 = load i32, ptr %EDX, align 4
  %148 = zext i32 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %conv.i.i110 = trunc i64 %146 to i32
  %sext.i = shl i64 %146, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %148, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %150 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i111 = icmp ult i64 %150, -4294967296
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv.i.i110, i32 noundef %147, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i112 to i8
  %cf.i.i113 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i113, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %151

151:                                              ; preds = %143
  %152 = load i64, ptr %NEXT_PC, align 8
  store i64 %152, ptr %PC, align 8
  %153 = add i64 %152, 3
  store i64 %153, ptr %NEXT_PC, align 8
  %154 = load i64, ptr %RCX, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  %conv.i.i133 = trunc i64 %154 to i32
  %and3.i.i = and i32 1, %conv.i.i133
  %conv.i22.i134 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i134, ptr %RCX, align 8
  %cf.i.i135 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i135, align 1
  %conv.i.i.i136 = trunc i32 %and3.i.i to i8
  %156 = and i8 %conv.i.i.i136, 1
  %conv.i23.i137 = xor i8 %156, 1
  %pf.i.i138 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i137, ptr %pf.i.i138, align 1
  %cmp.i.i.i139 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i140 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i139, i32 noundef %conv.i.i133, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i140 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i141, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i133, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i142 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i142, align 1
  %of.i.i143 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i143, align 1
  %af.i.i144 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i144, align 1
  store ptr %155, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %151
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 3
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load i32, ptr %ECX, align 4
  %161 = zext i32 %160 to i64
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %160 to i8
  %163 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %164 = and i8 %163, 1
  %conv.i.i.i57 = xor i8 %164, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %160, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %160, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %160, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %162, ptr %MEMORY, align 8
  br label %165

165:                                              ; preds = %157
  %166 = load i64, ptr %NEXT_PC, align 8
  store i64 %166, ptr %PC, align 8
  %167 = add i64 %166, 3
  store i64 %167, ptr %NEXT_PC, align 8
  %168 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %169 = load i8, ptr %zf.i, align 1
  store i8 %169, ptr %CL, align 1
  store ptr %168, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %165
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 2
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i8, ptr %AL, align 1
  %174 = zext i8 %173 to i64
  %175 = load i8, ptr %CL, align 1
  %176 = zext i8 %175 to i64
  %177 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %176, %174
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i145 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i145, align 1
  %178 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %179 = and i8 %178, 1
  %conv.i27.i = xor i8 %179, 1
  %pf.i.i146 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i146, align 1
  %180 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i147 = and i32 %180, 255
  %cmp.i.i.i148 = icmp eq i8 %or3.i.i, 0
  %181 = trunc i64 %174 to i32
  %conv1.i.i.i = and i32 %181, 255
  %182 = trunc i64 %176 to i32
  %conv2.i.i.i149 = and i32 %182, 255
  %call.i.i.i150 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i148, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i149, i32 noundef %conv.i.i.i147) #13
  %conv3.i.i151 = zext i1 %call.i.i.i150 to i8
  %zf.i.i152 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i151, ptr %zf.i.i152, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i149, i32 noundef %conv.i.i.i147) #13
  %conv6.i.i153 = zext i1 %call4.i.i.i to i8
  %sf.i.i154 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i153, ptr %sf.i.i154, align 1
  %of.i.i155 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i155, align 1
  %af.i.i156 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i156, align 1
  store ptr %177, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %170
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 2
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i8, ptr %AL, align 1
  %187 = zext i8 %186 to i64
  %188 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %187
  %and3.i.i174 = trunc i64 %and3.i15.i to i8
  %cf.i.i175 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i175, align 1
  %189 = and i8 %and3.i.i174, 1
  %conv.i14.i = xor i8 %189, 1
  %pf.i.i176 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i176, align 1
  %190 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i177 = and i32 %190, 255
  %cmp.i.i.i178 = icmp eq i8 %and3.i.i174, 0
  %191 = trunc i64 %187 to i32
  %conv1.i.i.i179 = and i32 %191, 255
  %call.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i178, i32 noundef %conv1.i.i.i179, i32 noundef 1, i32 noundef %conv.i.i.i177) #13
  %conv3.i.i181 = zext i1 %call.i.i.i180 to i8
  %zf.i.i182 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i181, ptr %zf.i.i182, align 1
  %call4.i.i.i183 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i179, i32 noundef 1, i32 noundef %conv.i.i.i177) #13
  %conv6.i.i184 = zext i1 %call4.i.i.i183 to i8
  %sf.i.i185 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i184, ptr %sf.i.i185, align 1
  %of.i.i186 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i186, align 1
  %af.i.i187 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i187, align 1
  store ptr %188, ptr %MEMORY, align 8
  br label %192

192:                                              ; preds = %183
  %193 = load i64, ptr %NEXT_PC, align 8
  store i64 %193, ptr %PC, align 8
  %194 = add i64 %193, 6
  store i64 %194, ptr %NEXT_PC, align 8
  %195 = load i64, ptr %NEXT_PC, align 8
  %196 = add i64 %195, 5
  %197 = load i64, ptr %NEXT_PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  %zf.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %199 = load i8, ptr %zf.i119, align 1
  %tobool.not.i120 = icmp eq i8 %199, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i120) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i121 = select i1 %call9.i, i64 %196, i64 %197
  store i64 %cond1.i.i121, ptr %NEXT_PC, align 8
  store ptr %198, ptr %MEMORY, align 8
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = load ptr, ptr %MEMORY, align 8
  ret ptr %201
}

define ptr @BB_2b14(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i8 1, ptr %CL, align 1
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 3
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load i64, ptr %RBP, align 8
  %15 = sub i64 %14, 73
  %16 = load i8, ptr %CL, align 1
  %17 = zext i8 %16 to i64
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_8(ptr noundef %18, i64 noundef %15, i8 noundef zeroext %16) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %11
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %22, ptr %rip.i, align 8
  store i64 %22, ptr %NEXT_PC, align 8
  store ptr %23, ptr %MEMORY, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  ret ptr %24
}

define ptr @BB_2b1f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i3, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 2
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i32, ptr %EAX, align 4
  %16 = zext i32 %15 to i64
  %17 = load i32, ptr %EAX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %and3.i.i = and i32 %17, %15
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %and3.i.i to i8
  %20 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %21 = and i8 %20, 1
  %conv.i14.i = xor i8 %21, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %and3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %15, i32 noundef %17, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %and3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %15, i32 noundef %17, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i, align 1
  store ptr %19, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 3
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %26 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %26, 0
  %conv.i = zext i1 %tobool.not.i to i8
  store i8 %conv.i, ptr %CL, align 1
  store ptr %25, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %22
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 7
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %NEXT_PC, align 8
  %31 = add i64 %30, 13671
  %32 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %32, i64 noundef %31) #13
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RBP, align 8
  %37 = sub i64 %36, 73
  %38 = load i8, ptr %CL, align 1
  %39 = zext i8 %38 to i64
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_8(ptr noundef %40, i64 noundef %37, i8 noundef zeroext %38) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %33
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 2
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RAX, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %44, ptr %rip.i, align 8
  store i64 %44, ptr %NEXT_PC, align 8
  store ptr %45, ptr %MEMORY, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  ret ptr %46
}

define ptr @BB_2b36(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 73
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call zeroext i8 @__remill_read_memory_8(ptr noundef %6, i64 noundef %5) #13
  store i8 %call.i.i50, ptr %AL, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 74
  %12 = load i8, ptr %AL, align 1
  %13 = zext i8 %12 to i64
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_8(ptr noundef %14, i64 noundef %11, i8 noundef zeroext %12) #13
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %7
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 7
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %NEXT_PC, align 8
  %19 = add i64 %18, 12829
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %19) #13
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %20, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %15
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RAX, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i32 @__remill_read_memory_32(ptr noundef %25, i64 noundef %24) #13
  %conv.i.i52 = zext i32 %call.i.i51 to i64
  store i64 %conv.i.i52, ptr %RDX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %21
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 7
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %NEXT_PC, align 8
  %30 = add i64 %29, 13460
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i53 = call i64 @__remill_read_memory_64(ptr noundef %31, i64 noundef %30) #13
  store i64 %call.i.i53, ptr %RAX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %26
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 3
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RAX, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %36, i64 noundef %35) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %37 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %38 = and i8 %37, 1
  %conv.i.i.i5 = xor i8 %38, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %39 = trunc i32 %xor1.i.i.i.i8 to i8
  %40 = lshr i8 %39, 4
  %conv2.i.i.i9 = and i8 %40, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %36, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %32
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %45 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %45, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %46 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %46, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %44, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i32, ptr %EDX, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %51, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RCX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %56 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %58 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %58, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %59 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %60 = and i8 %59, 1
  %conv.i.i.i = xor i8 %60, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %61 = trunc i32 %xor1.i.i.i.i to i8
  %62 = lshr i8 %61, 4
  %conv2.i.i.i = and i8 %62, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %53
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %RCX, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %66 to i32
  %sext.i = shl i64 %66, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %68, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %70 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %70, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %67, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load i64, ptr %RCX, align 8
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i55 = trunc i64 %74 to i32
  %and3.i.i = and i32 1, %conv.i.i55
  %conv.i22.i56 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i56, ptr %RCX, align 8
  %cf.i.i57 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i57, align 1
  %conv.i.i.i58 = trunc i32 %and3.i.i to i8
  %76 = and i8 %conv.i.i.i58, 1
  %conv.i23.i59 = xor i8 %76, 1
  %pf.i.i60 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i59, ptr %pf.i.i60, align 1
  %cmp.i.i.i61 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i61, i32 noundef %conv.i.i55, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i62 to i8
  %zf.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i63, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i55, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i64, align 1
  %of.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i65, align 1
  %af.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i66, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %71
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i32, ptr %ECX, align 4
  %81 = zext i32 %80 to i64
  %82 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %80, i32 noundef 0, i32 noundef %80) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %80 to i8
  %83 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %84 = and i8 %83, 1
  %conv.i.i.i29 = xor i8 %84, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %80, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %80, i32 noundef 0, i32 noundef %80) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %80, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %80, i32 noundef 0, i32 noundef %80) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %80, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %80, i32 noundef 0, i32 noundef %80) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %82, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %77
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %89 = load i8, ptr %zf.i, align 1
  store i8 %89, ptr %CL, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %85
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 2
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load i8, ptr %AL, align 1
  %94 = zext i8 %93 to i64
  %95 = load i8, ptr %CL, align 1
  %96 = zext i8 %95 to i64
  %97 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %96, %94
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i67, align 1
  %98 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %99 = and i8 %98, 1
  %conv.i27.i = xor i8 %99, 1
  %pf.i.i68 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i68, align 1
  %100 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i69 = and i32 %100, 255
  %cmp.i.i.i70 = icmp eq i8 %or3.i.i, 0
  %101 = trunc i64 %94 to i32
  %conv1.i.i.i = and i32 %101, 255
  %102 = trunc i64 %96 to i32
  %conv2.i.i.i71 = and i32 %102, 255
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i70, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i71, i32 noundef %conv.i.i.i69) #13
  %conv3.i.i73 = zext i1 %call.i.i.i72 to i8
  %zf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i73, ptr %zf.i.i74, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i71, i32 noundef %conv.i.i.i69) #13
  %conv6.i.i75 = zext i1 %call4.i.i.i to i8
  %sf.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i75, ptr %sf.i.i76, align 1
  %of.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i77, align 1
  %af.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i78, align 1
  store ptr %97, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %90
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 2
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i8, ptr %AL, align 1
  %107 = zext i8 %106 to i64
  %108 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %107
  %and3.i.i79 = trunc i64 %and3.i15.i to i8
  %cf.i.i80 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i80, align 1
  %109 = and i8 %and3.i.i79, 1
  %conv.i14.i = xor i8 %109, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i81, align 1
  %110 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i82 = and i32 %110, 255
  %cmp.i.i.i83 = icmp eq i8 %and3.i.i79, 0
  %111 = trunc i64 %107 to i32
  %conv1.i.i.i84 = and i32 %111, 255
  %call.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i83, i32 noundef %conv1.i.i.i84, i32 noundef 1, i32 noundef %conv.i.i.i82) #13
  %conv3.i.i86 = zext i1 %call.i.i.i85 to i8
  %zf.i.i87 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i86, ptr %zf.i.i87, align 1
  %call4.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i84, i32 noundef 1, i32 noundef %conv.i.i.i82) #13
  %conv6.i.i89 = zext i1 %call4.i.i.i88 to i8
  %sf.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i89, ptr %sf.i.i90, align 1
  %of.i.i91 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i91, align 1
  %af.i.i92 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i92, align 1
  store ptr %108, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %103
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 6
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %NEXT_PC, align 8
  %116 = add i64 %115, 5
  %117 = load i64, ptr %NEXT_PC, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %119 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %119, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %116, i64 %117
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %118, ptr %MEMORY, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  ret ptr %121
}

define ptr @BB_2b72(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %DL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 74
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i85 = call zeroext i8 @__remill_read_memory_8(ptr noundef %6, i64 noundef %5) #13
  store i8 %call.i.i85, ptr %DL, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i64 4, ptr %RCX, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 5
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  store i64 3, ptr %RAX, align 8
  store ptr %14, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %11
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i8, ptr %DL, align 1
  %19 = zext i8 %18 to i64
  %20 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i165 = and i64 1, %19
  %and3.i.i166 = trunc i64 %and3.i15.i165 to i8
  %cf.i.i167 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i167, align 1
  %21 = and i8 %and3.i.i166, 1
  %conv.i14.i168 = xor i8 %21, 1
  %pf.i.i169 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i168, ptr %pf.i.i169, align 1
  %22 = trunc i64 %and3.i15.i165 to i32
  %conv.i.i.i170 = and i32 %22, 255
  %cmp.i.i.i171 = icmp eq i8 %and3.i.i166, 0
  %23 = trunc i64 %19 to i32
  %conv1.i.i.i172 = and i32 %23, 255
  %call.i.i.i173 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i171, i32 noundef %conv1.i.i.i172, i32 noundef 1, i32 noundef %conv.i.i.i170) #13
  %conv3.i.i174 = zext i1 %call.i.i.i173 to i8
  %zf.i.i175 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i174, ptr %zf.i.i175, align 1
  %call4.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i172, i32 noundef 1, i32 noundef %conv.i.i.i170) #13
  %conv6.i.i177 = zext i1 %call4.i.i.i176 to i8
  %sf.i.i178 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i177, ptr %sf.i.i178, align 1
  %of.i.i179 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i179, align 1
  %af.i.i180 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i181 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i181, ptr %af.i.i180, align 1
  store ptr %20, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %15
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i32, ptr %EAX, align 4
  %28 = zext i32 %27 to i64
  %29 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %30 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %30, 0
  %call3.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call3.i, i64 %28, i64 %dst.coerce.val.i
  %conv.i20.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i20.i, ptr %RCX, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %24
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 13572
  %36 = load ptr, ptr %MEMORY, align 8
  store i64 %35, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i32, ptr %ECX, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %sext.i91 = shl i64 %41, 32
  %conv.i12.i92 = ashr exact i64 %sext.i91, 32
  store i64 %conv.i12.i92, ptr %RCX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %37
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RAX, align 8
  %47 = load i64, ptr %RCX, align 8
  %48 = mul i64 %47, 8
  %49 = add i64 %46, %48
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i90 = call i64 @__remill_read_memory_64(ptr noundef %50, i64 noundef %49) #13
  store i64 %call.i.i90, ptr %RAX, align 8
  store ptr %50, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %43
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 2
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RCX, align 8
  %55 = load i32, ptr %ECX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i.i117 = trunc i64 %54 to i32
  %xor3.i.i = xor i32 %55, %conv.i.i117
  %conv.i27.i118 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i118, ptr %RCX, align 8
  %cf.i.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i119, align 1
  %conv.i.i.i120 = trunc i32 %xor3.i.i to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i120)
  %59 = and i8 %58, 1
  %conv.i28.i121 = xor i8 %59, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i121, ptr %pf.i.i122, align 1
  %cmp.i.i.i123 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i124 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i123, i32 noundef %conv.i.i117, i32 noundef %55, i32 noundef %xor3.i.i) #13
  %conv3.i.i125 = zext i1 %call.i.i.i124 to i8
  %zf.i.i126 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i125, ptr %zf.i.i126, align 1
  %cmp.i19.i.i127 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i128 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i127, i32 noundef %conv.i.i117, i32 noundef %55, i32 noundef %xor3.i.i) #13
  %conv6.i.i129 = zext i1 %call1.i.i.i128 to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i133 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i133, ptr %af.i.i132, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %51
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 3
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i8, ptr %DL, align 1
  %64 = zext i8 %63 to i64
  %65 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i148 = and i64 1, %64
  %and3.i.i149 = trunc i64 %and3.i15.i148 to i8
  %cf.i.i150 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i150, align 1
  %66 = and i8 %and3.i.i149, 1
  %conv.i14.i151 = xor i8 %66, 1
  %pf.i.i152 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i151, ptr %pf.i.i152, align 1
  %67 = trunc i64 %and3.i15.i148 to i32
  %conv.i.i.i153 = and i32 %67, 255
  %cmp.i.i.i154 = icmp eq i8 %and3.i.i149, 0
  %68 = trunc i64 %64 to i32
  %conv1.i.i.i155 = and i32 %68, 255
  %call.i.i.i156 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i154, i32 noundef %conv1.i.i.i155, i32 noundef 1, i32 noundef %conv.i.i.i153) #13
  %conv3.i.i157 = zext i1 %call.i.i.i156 to i8
  %zf.i.i158 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i157, ptr %zf.i.i158, align 1
  %call4.i.i.i159 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i155, i32 noundef 1, i32 noundef %conv.i.i.i153) #13
  %conv6.i.i160 = zext i1 %call4.i.i.i159 to i8
  %sf.i.i161 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i160, ptr %sf.i.i161, align 1
  %of.i.i162 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i162, align 1
  %af.i.i163 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i164 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i164, ptr %af.i.i163, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %60
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 4
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %zf.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %74 = load i8, ptr %zf.i77, align 1
  %tobool.not.i78 = icmp eq i8 %74, 0
  %call3.i79 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i78) #14
  %dst.coerce.val.i80 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call3.i79, i64 %72, i64 %dst.coerce.val.i80
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %69
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RAX, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %78, %79
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %78, %79
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %81 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %82 = and i8 %81, 1
  %conv.i.i.i6 = xor i8 %82, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %79, %78
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %83 = trunc i64 %xor1.i.i.i.i9 to i8
  %84 = lshr i8 %83, 4
  %conv2.i.i.i10 = and i8 %84, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %78, %79
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %78
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %78, i64 noundef %79, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %75
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 4
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RBP, align 8
  %89 = sub i64 %88, 88
  %90 = load i64, ptr %RAX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %call.i.i84 = call ptr @__remill_write_memory_64(ptr noundef %91, i64 noundef %89, i64 noundef %90) #13
  store ptr %call.i.i84, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %85
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 7
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %NEXT_PC, align 8
  %96 = add i64 %95, 13134
  %97 = load ptr, ptr %MEMORY, align 8
  %call.i.i89 = call i64 @__remill_read_memory_64(ptr noundef %97, i64 noundef %96) #13
  store i64 %call.i.i89, ptr %RAX, align 8
  store ptr %97, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 2
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RAX, align 8
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i86 = call i32 @__remill_read_memory_32(ptr noundef %102, i64 noundef %101) #13
  %conv.i.i87 = zext i32 %call.i.i86 to i64
  store i64 %conv.i.i87, ptr %RDX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %98
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 7
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  %107 = add i64 %106, 13349
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i88 = call i64 @__remill_read_memory_64(ptr noundef %108, i64 noundef %107) #13
  store i64 %call.i.i88, ptr %RAX, align 8
  store ptr %108, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %103
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 3
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RAX, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %113, i64 noundef %112) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %114 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %115 = and i8 %114, 1
  %conv.i.i.i32 = xor i8 %115, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %116 = trunc i32 %xor1.i.i.i.i35 to i8
  %117 = lshr i8 %116, 4
  %conv2.i.i.i36 = and i8 %117, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 3
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %122 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %122, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %123 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %123, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %121, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %118
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i32, ptr %EDX, align 4
  %128 = zext i32 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %128, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %129, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %124
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 3
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load i64, ptr %RCX, align 8
  %134 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %133 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %135 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %135, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %136 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %137 = and i8 %136, 1
  %conv.i.i.i = xor i8 %137, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %138 = trunc i32 %xor1.i.i.i.i to i8
  %139 = lshr i8 %138, 4
  %conv2.i.i.i = and i8 %139, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %134, ptr %MEMORY, align 8
  br label %140

140:                                              ; preds = %130
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = add i64 %141, 3
  store i64 %142, ptr %NEXT_PC, align 8
  %143 = load i64, ptr %RCX, align 8
  %144 = load i32, ptr %EDX, align 4
  %145 = zext i32 %144 to i64
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %143 to i32
  %sext.i = shl i64 %143, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %145, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %147 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %147, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %144, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %140
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RCX, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %151 to i32
  %and3.i.i = and i32 1, %conv.i.i93
  %conv.i22.i94 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i94, ptr %RCX, align 8
  %cf.i.i95 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %conv.i.i.i96 = trunc i32 %and3.i.i to i8
  %153 = and i8 %conv.i.i.i96, 1
  %conv.i23.i97 = xor i8 %153, 1
  %pf.i.i98 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i97, ptr %pf.i.i98, align 1
  %cmp.i.i.i99 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i99, i32 noundef %conv.i.i93, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i100 to i8
  %zf.i.i101 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i101, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i93, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i102 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i102, align 1
  %of.i.i103 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i103, align 1
  %af.i.i104 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i104, align 1
  store ptr %152, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %148
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i32, ptr %ECX, align 4
  %158 = zext i32 %157 to i64
  %159 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %157, i32 noundef 0, i32 noundef %157) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %157 to i8
  %160 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %161 = and i8 %160, 1
  %conv.i.i.i57 = xor i8 %161, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %157, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %157, i32 noundef 0, i32 noundef %157) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %157, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %157, i32 noundef 0, i32 noundef %157) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %157, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %157, i32 noundef 0, i32 noundef %157) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %159, ptr %MEMORY, align 8
  br label %162

162:                                              ; preds = %154
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = add i64 %163, 3
  store i64 %164, ptr %NEXT_PC, align 8
  %165 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %166 = load i8, ptr %zf.i, align 1
  store i8 %166, ptr %CL, align 1
  store ptr %165, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %162
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 2
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i8, ptr %AL, align 1
  %171 = zext i8 %170 to i64
  %172 = load i8, ptr %CL, align 1
  %173 = zext i8 %172 to i64
  %174 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %173, %171
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i105 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i105, align 1
  %175 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %176 = and i8 %175, 1
  %conv.i27.i = xor i8 %176, 1
  %pf.i.i106 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i106, align 1
  %177 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i107 = and i32 %177, 255
  %cmp.i.i.i108 = icmp eq i8 %or3.i.i, 0
  %178 = trunc i64 %171 to i32
  %conv1.i.i.i = and i32 %178, 255
  %179 = trunc i64 %173 to i32
  %conv2.i.i.i109 = and i32 %179, 255
  %call.i.i.i110 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i108, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i109, i32 noundef %conv.i.i.i107) #13
  %conv3.i.i111 = zext i1 %call.i.i.i110 to i8
  %zf.i.i112 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i111, ptr %zf.i.i112, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i109, i32 noundef %conv.i.i.i107) #13
  %conv6.i.i113 = zext i1 %call4.i.i.i to i8
  %sf.i.i114 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i113, ptr %sf.i.i114, align 1
  %of.i.i115 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i115, align 1
  %af.i.i116 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i116, align 1
  store ptr %174, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %167
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 2
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i8, ptr %AL, align 1
  %184 = zext i8 %183 to i64
  %185 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %184
  %and3.i.i134 = trunc i64 %and3.i15.i to i8
  %cf.i.i135 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i135, align 1
  %186 = and i8 %and3.i.i134, 1
  %conv.i14.i = xor i8 %186, 1
  %pf.i.i136 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i136, align 1
  %187 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i137 = and i32 %187, 255
  %cmp.i.i.i138 = icmp eq i8 %and3.i.i134, 0
  %188 = trunc i64 %184 to i32
  %conv1.i.i.i139 = and i32 %188, 255
  %call.i.i.i140 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i138, i32 noundef %conv1.i.i.i139, i32 noundef 1, i32 noundef %conv.i.i.i137) #13
  %conv3.i.i141 = zext i1 %call.i.i.i140 to i8
  %zf.i.i142 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i141, ptr %zf.i.i142, align 1
  %call4.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i139, i32 noundef 1, i32 noundef %conv.i.i.i137) #13
  %conv6.i.i144 = zext i1 %call4.i.i.i143 to i8
  %sf.i.i145 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i144, ptr %sf.i.i145, align 1
  %of.i.i146 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i146, align 1
  %af.i.i147 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i147, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %180
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 6
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i64, ptr %NEXT_PC, align 8
  %193 = add i64 %192, 5
  %194 = load i64, ptr %NEXT_PC, align 8
  %195 = load ptr, ptr %MEMORY, align 8
  %zf.i81 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %196 = load i8, ptr %zf.i81, align 1
  %tobool.not.i82 = icmp eq i8 %196, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i82) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i83 = select i1 %call9.i, i64 %193, i64 %194
  store i64 %cond1.i.i83, ptr %NEXT_PC, align 8
  store ptr %195, ptr %MEMORY, align 8
  %197 = load i64, ptr %NEXT_PC, align 8
  store i64 %197, ptr %PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  ret ptr %198
}

define ptr @BB_2bd9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 88
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2bdf(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 13066
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 13313
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2d0c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12757
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12956
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2c15(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i508 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i508, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i507 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #13
  store i64 %call.i.i507, ptr %RDI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i494 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #13
  %conv.i.i495 = zext i32 %call.i.i494 to i64
  store i64 %conv.i.i495, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 5
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RSI, align 8
  store ptr %21, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %18
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 1
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %rdx.i458 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i459 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %26 = load i32, ptr %rax.i459, align 8
  %27 = ashr i32 %26, 31
  %conv.i13.i460 = zext i32 %27 to i64
  store i64 %conv.i13.i460, ptr %rdx.i458, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %22
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 2
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i32, ptr %ESI, align 4
  %32 = zext i32 %31 to i64
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %rax.i404 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %35 = load i32, ptr %rax.i404, align 8
  %rdx.i405 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %36 = load i32, ptr %rdx.i405, align 8
  %sext.i406 = shl i64 %32, 32
  %rip.i407 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %33, ptr %rip.i407, align 8
  %tobool.not.i.not.i408 = icmp eq i64 %sext.i406, 0
  br i1 %tobool.not.i.not.i408, label %if.then.i410, label %if.else.i419

if.then.i410:                                     ; preds = %28
  %call29.i409 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %33, ptr noundef %34) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit433

if.else.i419:                                     ; preds = %28
  %conv.i118.i411 = ashr exact i64 %sext.i406, 32
  %conv.i.i412 = zext i32 %35 to i64
  %conv.i116.i413 = zext i32 %36 to i64
  %shl.i.i414 = shl nuw i64 %conv.i116.i413, 32
  %or.i.i415 = or i64 %shl.i.i414, %conv.i.i412
  %div.i.i416 = sdiv i64 %or.i.i415, %conv.i118.i411
  %rem.i.i417 = srem i64 %or.i.i415, %conv.i118.i411
  %37 = add i64 %div.i.i416, 2147483648
  %cmp.not.i418 = icmp ult i64 %37, 4294967296
  br i1 %cmp.not.i418, label %do.body42.i431, label %if.then35.i421

if.then35.i421:                                   ; preds = %if.else.i419
  %call39.i420 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %33, ptr noundef %34) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit433

do.body42.i431:                                   ; preds = %if.else.i419
  %conv.i123.i422 = and i64 %div.i.i416, 4294967295
  store i64 %conv.i123.i422, ptr %rax.i404, align 8
  %conv.i124.i423 = and i64 %rem.i.i417, 4294967295
  store i64 %conv.i124.i423, ptr %rdx.i405, align 8
  %call64.i424 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i425 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i424, ptr %cf.i425, align 1
  %pf.i426 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i424, ptr %pf.i426, align 1
  %af.i427 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i424, ptr %af.i427, align 1
  %zf.i428 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i424, ptr %zf.i428, align 1
  %sf.i429 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i424, ptr %sf.i429, align 1
  %of.i430 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i424, ptr %of.i430, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit433

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit433: ; preds = %do.body42.i431, %if.then35.i421, %if.then.i410
  %retval.1.i432 = phi ptr [ %call29.i409, %if.then.i410 ], [ %call39.i420, %if.then35.i421 ], [ %34, %do.body42.i431 ]
  store ptr %retval.1.i432, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit433
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 4
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RBP, align 8
  %42 = sub i64 %41, 56
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i506 = call i64 @__remill_read_memory_64(ptr noundef %43, i64 noundef %42) #13
  store i64 %call.i.i506, ptr %RAX, align 8
  store ptr %43, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %38
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 3
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RBP, align 8
  %48 = sub i64 %47, 104
  %49 = load i32, ptr %EDX, align 4
  %50 = zext i32 %49 to i64
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i467 = call ptr @__remill_write_memory_32(ptr noundef %51, i64 noundef %48, i32 noundef %49) #13
  store ptr %call.i.i467, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %44
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RAX, align 8
  %56 = load ptr, ptr %MEMORY, align 8
  %call.i.i492 = call i32 @__remill_read_memory_32(ptr noundef %56, i64 noundef %55) #13
  %conv.i.i493 = zext i32 %call.i.i492 to i64
  store i64 %conv.i.i493, ptr %RAX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %52
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 5
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RSI, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %57
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 1
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  %rdx.i455 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i456 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %65 = load i32, ptr %rax.i456, align 8
  %66 = ashr i32 %65, 31
  %conv.i13.i457 = zext i32 %66 to i64
  store i64 %conv.i13.i457, ptr %rdx.i455, align 8
  store ptr %64, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %61
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 2
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i32, ptr %ESI, align 4
  %71 = zext i32 %70 to i64
  %72 = load i64, ptr %NEXT_PC, align 8
  %73 = load ptr, ptr %MEMORY, align 8
  %rax.i374 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %74 = load i32, ptr %rax.i374, align 8
  %rdx.i375 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %75 = load i32, ptr %rdx.i375, align 8
  %sext.i376 = shl i64 %71, 32
  %rip.i377 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %72, ptr %rip.i377, align 8
  %tobool.not.i.not.i378 = icmp eq i64 %sext.i376, 0
  br i1 %tobool.not.i.not.i378, label %if.then.i380, label %if.else.i389

if.then.i380:                                     ; preds = %67
  %call29.i379 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %72, ptr noundef %73) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit403

if.else.i389:                                     ; preds = %67
  %conv.i118.i381 = ashr exact i64 %sext.i376, 32
  %conv.i.i382 = zext i32 %74 to i64
  %conv.i116.i383 = zext i32 %75 to i64
  %shl.i.i384 = shl nuw i64 %conv.i116.i383, 32
  %or.i.i385 = or i64 %shl.i.i384, %conv.i.i382
  %div.i.i386 = sdiv i64 %or.i.i385, %conv.i118.i381
  %rem.i.i387 = srem i64 %or.i.i385, %conv.i118.i381
  %76 = add i64 %div.i.i386, 2147483648
  %cmp.not.i388 = icmp ult i64 %76, 4294967296
  br i1 %cmp.not.i388, label %do.body42.i401, label %if.then35.i391

if.then35.i391:                                   ; preds = %if.else.i389
  %call39.i390 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %72, ptr noundef %73) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit403

do.body42.i401:                                   ; preds = %if.else.i389
  %conv.i123.i392 = and i64 %div.i.i386, 4294967295
  store i64 %conv.i123.i392, ptr %rax.i374, align 8
  %conv.i124.i393 = and i64 %rem.i.i387, 4294967295
  store i64 %conv.i124.i393, ptr %rdx.i375, align 8
  %call64.i394 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i395 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i394, ptr %cf.i395, align 1
  %pf.i396 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i394, ptr %pf.i396, align 1
  %af.i397 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i394, ptr %af.i397, align 1
  %zf.i398 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i394, ptr %zf.i398, align 1
  %sf.i399 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i394, ptr %sf.i399, align 1
  %of.i400 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i394, ptr %of.i400, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit403

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit403: ; preds = %do.body42.i401, %if.then35.i391, %if.then.i380
  %retval.1.i402 = phi ptr [ %call29.i379, %if.then.i380 ], [ %call39.i390, %if.then35.i391 ], [ %73, %do.body42.i401 ]
  store ptr %retval.1.i402, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit403
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RBP, align 8
  %81 = sub i64 %80, 104
  %82 = load ptr, ptr %MEMORY, align 8
  %call.i.i490 = call i32 @__remill_read_memory_32(ptr noundef %82, i64 noundef %81) #13
  %conv.i.i491 = zext i32 %call.i.i490 to i64
  store i64 %conv.i.i491, ptr %RAX, align 8
  store ptr %82, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 2
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %EDX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i475 = and i64 %87, 4294967295
  store i64 %conv.i11.i475, ptr %RSI, align 8
  store ptr %88, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %83
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 4
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RBP, align 8
  %93 = sub i64 %92, 40
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i505 = call i64 @__remill_read_memory_64(ptr noundef %94, i64 noundef %93) #13
  store i64 %call.i.i505, ptr %RDX, align 8
  store ptr %94, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %89
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %RAX, align 8
  %99 = load i32, ptr %ESI, align 4
  %100 = zext i32 %99 to i64
  %101 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %98 to i32
  %add.i.i64 = add i32 %99, %conv.i.i63
  %conv.i22.i65 = zext i32 %add.i.i64 to i64
  store i64 %conv.i22.i65, ptr %RAX, align 8
  %cmp.i.i.i66 = icmp ult i32 %add.i.i64, %conv.i.i63
  %cmp1.i.i.i67 = icmp ult i32 %add.i.i64, %99
  %102 = or i1 %cmp.i.i.i66, %cmp1.i.i.i67
  %call.i.i.i68 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %102, i32 noundef %conv.i.i63, i32 noundef %99, i32 noundef %add.i.i64) #13
  %conv.i23.i69 = zext i1 %call.i.i.i68 to i8
  %cf.i.i70 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i69, ptr %cf.i.i70, align 1
  %conv.i.i.i.i71 = trunc i32 %add.i.i64 to i8
  %103 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i71)
  %104 = and i8 %103, 1
  %conv.i.i.i72 = xor i8 %104, 1
  %pf.i.i.i73 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i72, ptr %pf.i.i.i73, align 1
  %xor.i.i.i.i74 = xor i32 %add.i.i64, %99
  %xor1.i.i.i.i75 = xor i32 %xor.i.i.i.i74, %conv.i.i63
  %105 = trunc i32 %xor1.i.i.i.i75 to i8
  %106 = lshr i8 %105, 4
  %conv2.i.i.i76 = and i8 %106, 1
  %af.i.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i76, ptr %af.i.i.i77, align 1
  %cmp.i.i.i.i78 = icmp eq i32 %add.i.i64, 0
  %call.i.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i78, i32 noundef %conv.i.i63, i32 noundef %99, i32 noundef %add.i.i64) #13
  %conv5.i.i.i80 = zext i1 %call.i.i.i.i79 to i8
  %zf.i.i.i81 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i80, ptr %zf.i.i.i81, align 1
  %cmp.i27.i.i.i82 = icmp slt i32 %add.i.i64, 0
  %call1.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i82, i32 noundef %conv.i.i63, i32 noundef %99, i32 noundef %add.i.i64) #13
  %conv8.i.i.i84 = zext i1 %call1.i.i.i.i83 to i8
  %sf.i.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i84, ptr %sf.i.i.i85, align 1
  %shr8.i.i.i.i86 = xor i32 %add.i.i64, %conv.i.i63
  %xor.i28.i.i.i87 = lshr i32 %shr8.i.i.i.i86, 31
  %xor3.i.i.i.i88 = lshr i32 %xor.i.i.i.i74, 31
  %add.i.i.i.i89 = add nuw nsw i32 %xor.i28.i.i.i87, %xor3.i.i.i.i88
  %cmp.i29.i.i.i90 = icmp eq i32 %add.i.i.i.i89, 2
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i90, i32 noundef %conv.i.i63, i32 noundef %99, i32 noundef %add.i.i64) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %101, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %95
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 2
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i64, ptr %RAX, align 8
  %111 = load i64, ptr %RDX, align 8
  %112 = load ptr, ptr %MEMORY, align 8
  %conv.i.i123 = trunc i64 %110 to i32
  %call.i.i124 = call i32 @__remill_read_memory_32(ptr noundef %112, i64 noundef %111) #13
  %add.i.i125 = add i32 %call.i.i124, %conv.i.i123
  %conv.i18.i126 = zext i32 %add.i.i125 to i64
  store i64 %conv.i18.i126, ptr %RAX, align 8
  %cmp.i.i.i127 = icmp ult i32 %add.i.i125, %conv.i.i123
  %cmp1.i.i.i128 = icmp ult i32 %add.i.i125, %call.i.i124
  %113 = or i1 %cmp.i.i.i127, %cmp1.i.i.i128
  %call.i.i.i129 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %113, i32 noundef %conv.i.i123, i32 noundef %call.i.i124, i32 noundef %add.i.i125) #13
  %conv.i19.i130 = zext i1 %call.i.i.i129 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i130, ptr %cf.i.i131, align 1
  %conv.i.i.i.i132 = trunc i32 %add.i.i125 to i8
  %114 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i132)
  %115 = and i8 %114, 1
  %conv.i.i.i133 = xor i8 %115, 1
  %pf.i.i.i134 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i133, ptr %pf.i.i.i134, align 1
  %xor.i.i.i.i135 = xor i32 %add.i.i125, %call.i.i124
  %xor1.i.i.i.i136 = xor i32 %xor.i.i.i.i135, %conv.i.i123
  %116 = trunc i32 %xor1.i.i.i.i136 to i8
  %117 = lshr i8 %116, 4
  %conv2.i.i.i137 = and i8 %117, 1
  %af.i.i.i138 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i137, ptr %af.i.i.i138, align 1
  %cmp.i.i.i.i139 = icmp eq i32 %add.i.i125, 0
  %call.i.i.i.i140 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i139, i32 noundef %conv.i.i123, i32 noundef %call.i.i124, i32 noundef %add.i.i125) #13
  %conv5.i.i.i141 = zext i1 %call.i.i.i.i140 to i8
  %zf.i.i.i142 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i141, ptr %zf.i.i.i142, align 1
  %cmp.i27.i.i.i143 = icmp slt i32 %add.i.i125, 0
  %call1.i.i.i.i144 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i143, i32 noundef %conv.i.i123, i32 noundef %call.i.i124, i32 noundef %add.i.i125) #13
  %conv8.i.i.i145 = zext i1 %call1.i.i.i.i144 to i8
  %sf.i.i.i146 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i145, ptr %sf.i.i.i146, align 1
  %shr8.i.i.i.i147 = xor i32 %add.i.i125, %conv.i.i123
  %xor.i28.i.i.i148 = lshr i32 %shr8.i.i.i.i147, 31
  %xor3.i.i.i.i149 = lshr i32 %xor.i.i.i.i135, 31
  %add.i.i.i.i150 = add nuw nsw i32 %xor.i28.i.i.i148, %xor3.i.i.i.i149
  %cmp.i29.i.i.i151 = icmp eq i32 %add.i.i.i.i150, 2
  %call.i30.i.i.i152 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i151, i32 noundef %conv.i.i123, i32 noundef %call.i.i124, i32 noundef %add.i.i125) #13
  %conv11.i.i.i153 = zext i1 %call.i30.i.i.i152 to i8
  %of.i.i.i154 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i153, ptr %of.i.i.i154, align 1
  store ptr %112, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %107
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 5
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RSI, align 8
  store ptr %121, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %118
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 1
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load ptr, ptr %MEMORY, align 8
  %rdx.i452 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i453 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %126 = load i32, ptr %rax.i453, align 8
  %127 = ashr i32 %126, 31
  %conv.i13.i454 = zext i32 %127 to i64
  store i64 %conv.i13.i454, ptr %rdx.i452, align 8
  store ptr %125, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %122
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 2
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load i32, ptr %ESI, align 4
  %132 = zext i32 %131 to i64
  %133 = load i64, ptr %NEXT_PC, align 8
  %134 = load ptr, ptr %MEMORY, align 8
  %rax.i344 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %135 = load i32, ptr %rax.i344, align 8
  %rdx.i345 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %136 = load i32, ptr %rdx.i345, align 8
  %sext.i346 = shl i64 %132, 32
  %rip.i347 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %133, ptr %rip.i347, align 8
  %tobool.not.i.not.i348 = icmp eq i64 %sext.i346, 0
  br i1 %tobool.not.i.not.i348, label %if.then.i350, label %if.else.i359

if.then.i350:                                     ; preds = %128
  %call29.i349 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %133, ptr noundef %134) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit373

if.else.i359:                                     ; preds = %128
  %conv.i118.i351 = ashr exact i64 %sext.i346, 32
  %conv.i.i352 = zext i32 %135 to i64
  %conv.i116.i353 = zext i32 %136 to i64
  %shl.i.i354 = shl nuw i64 %conv.i116.i353, 32
  %or.i.i355 = or i64 %shl.i.i354, %conv.i.i352
  %div.i.i356 = sdiv i64 %or.i.i355, %conv.i118.i351
  %rem.i.i357 = srem i64 %or.i.i355, %conv.i118.i351
  %137 = add i64 %div.i.i356, 2147483648
  %cmp.not.i358 = icmp ult i64 %137, 4294967296
  br i1 %cmp.not.i358, label %do.body42.i371, label %if.then35.i361

if.then35.i361:                                   ; preds = %if.else.i359
  %call39.i360 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %133, ptr noundef %134) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit373

do.body42.i371:                                   ; preds = %if.else.i359
  %conv.i123.i362 = and i64 %div.i.i356, 4294967295
  store i64 %conv.i123.i362, ptr %rax.i344, align 8
  %conv.i124.i363 = and i64 %rem.i.i357, 4294967295
  store i64 %conv.i124.i363, ptr %rdx.i345, align 8
  %call64.i364 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i365 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i364, ptr %cf.i365, align 1
  %pf.i366 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i364, ptr %pf.i366, align 1
  %af.i367 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i364, ptr %af.i367, align 1
  %zf.i368 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i364, ptr %zf.i368, align 1
  %sf.i369 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i364, ptr %sf.i369, align 1
  %of.i370 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i364, ptr %of.i370, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit373

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit373: ; preds = %do.body42.i371, %if.then35.i361, %if.then.i350
  %retval.1.i372 = phi ptr [ %call29.i349, %if.then.i350 ], [ %call39.i360, %if.then35.i361 ], [ %134, %do.body42.i371 ]
  store ptr %retval.1.i372, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit373
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 4
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i64, ptr %RBP, align 8
  %142 = sub i64 %141, 32
  %143 = load ptr, ptr %MEMORY, align 8
  %call.i.i504 = call i64 @__remill_read_memory_64(ptr noundef %143, i64 noundef %142) #13
  store i64 %call.i.i504, ptr %RAX, align 8
  store ptr %143, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %138
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 2
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i32, ptr %EDX, align 4
  %148 = zext i32 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i474 = and i64 %148, 4294967295
  store i64 %conv.i11.i474, ptr %RSI, align 8
  store ptr %149, ptr %MEMORY, align 8
  br label %150

150:                                              ; preds = %144
  %151 = load i64, ptr %NEXT_PC, align 8
  store i64 %151, ptr %PC, align 8
  %152 = add i64 %151, 2
  store i64 %152, ptr %NEXT_PC, align 8
  %153 = load i64, ptr %RDI, align 8
  %154 = load ptr, ptr %MEMORY, align 8
  %call.i.i488 = call i32 @__remill_read_memory_32(ptr noundef %154, i64 noundef %153) #13
  %conv.i.i489 = zext i32 %call.i.i488 to i64
  store i64 %conv.i.i489, ptr %RDX, align 8
  store ptr %154, ptr %MEMORY, align 8
  br label %155

155:                                              ; preds = %150
  %156 = load i64, ptr %NEXT_PC, align 8
  store i64 %156, ptr %PC, align 8
  %157 = add i64 %156, 3
  store i64 %157, ptr %NEXT_PC, align 8
  %158 = load i32, ptr %EDX, align 4
  %159 = zext i32 %158 to i64
  %160 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i473 = and i64 %159, 4294967295
  store i64 %conv.i11.i473, ptr %R8, align 8
  store ptr %160, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %155
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 4
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i64, ptr %R8, align 8
  %165 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %164 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %R8, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %166 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %166, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %167 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %168 = and i8 %167, 1
  %conv.i.i.i10 = xor i8 %168, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %169 = trunc i32 %xor1.i.i.i.i13 to i8
  %170 = lshr i8 %169, 4
  %conv2.i.i.i14 = and i8 %170, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %165, ptr %MEMORY, align 8
  br label %171

171:                                              ; preds = %161
  %172 = load i64, ptr %NEXT_PC, align 8
  store i64 %172, ptr %PC, align 8
  %173 = add i64 %172, 3
  store i64 %173, ptr %NEXT_PC, align 8
  %174 = load i64, ptr %RDI, align 8
  %175 = load i32, ptr %R8D, align 4
  %176 = zext i32 %175 to i64
  %177 = load ptr, ptr %MEMORY, align 8
  %call.i.i466 = call ptr @__remill_write_memory_32(ptr noundef %177, i64 noundef %174, i32 noundef %175) #13
  store ptr %call.i.i466, ptr %MEMORY, align 8
  br label %178

178:                                              ; preds = %171
  %179 = load i64, ptr %NEXT_PC, align 8
  store i64 %179, ptr %PC, align 8
  %180 = add i64 %179, 3
  store i64 %180, ptr %NEXT_PC, align 8
  %181 = load i32, ptr %EDX, align 4
  %182 = zext i32 %181 to i64
  %183 = load ptr, ptr %MEMORY, align 8
  %sext.i509 = shl i64 %182, 32
  %conv.i12.i510 = ashr exact i64 %sext.i509, 32
  store i64 %conv.i12.i510, ptr %RDX, align 8
  store ptr %183, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %178
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 3
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i64, ptr %RAX, align 8
  %188 = load i64, ptr %RDX, align 8
  %189 = mul i64 %188, 4
  %190 = add i64 %187, %189
  %191 = load i32, ptr %ESI, align 4
  %192 = zext i32 %191 to i64
  %193 = load ptr, ptr %MEMORY, align 8
  %call.i.i465 = call ptr @__remill_write_memory_32(ptr noundef %193, i64 noundef %190, i32 noundef %191) #13
  store ptr %call.i.i465, ptr %MEMORY, align 8
  br label %194

194:                                              ; preds = %184
  %195 = load i64, ptr %NEXT_PC, align 8
  store i64 %195, ptr %PC, align 8
  %196 = add i64 %195, 2
  store i64 %196, ptr %NEXT_PC, align 8
  %197 = load i64, ptr %RCX, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  %call.i.i486 = call i32 @__remill_read_memory_32(ptr noundef %198, i64 noundef %197) #13
  %conv.i.i487 = zext i32 %call.i.i486 to i64
  store i64 %conv.i.i487, ptr %RAX, align 8
  store ptr %198, ptr %MEMORY, align 8
  br label %199

199:                                              ; preds = %194
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = add i64 %200, 5
  store i64 %201, ptr %NEXT_PC, align 8
  %202 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RSI, align 8
  store ptr %202, ptr %MEMORY, align 8
  br label %203

203:                                              ; preds = %199
  %204 = load i64, ptr %NEXT_PC, align 8
  store i64 %204, ptr %PC, align 8
  %205 = add i64 %204, 1
  store i64 %205, ptr %NEXT_PC, align 8
  %206 = load ptr, ptr %MEMORY, align 8
  %rdx.i449 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i450 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %207 = load i32, ptr %rax.i450, align 8
  %208 = ashr i32 %207, 31
  %conv.i13.i451 = zext i32 %208 to i64
  store i64 %conv.i13.i451, ptr %rdx.i449, align 8
  store ptr %206, ptr %MEMORY, align 8
  br label %209

209:                                              ; preds = %203
  %210 = load i64, ptr %NEXT_PC, align 8
  store i64 %210, ptr %PC, align 8
  %211 = add i64 %210, 2
  store i64 %211, ptr %NEXT_PC, align 8
  %212 = load i32, ptr %ESI, align 4
  %213 = zext i32 %212 to i64
  %214 = load i64, ptr %NEXT_PC, align 8
  %215 = load ptr, ptr %MEMORY, align 8
  %rax.i314 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %216 = load i32, ptr %rax.i314, align 8
  %rdx.i315 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %217 = load i32, ptr %rdx.i315, align 8
  %sext.i316 = shl i64 %213, 32
  %rip.i317 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %214, ptr %rip.i317, align 8
  %tobool.not.i.not.i318 = icmp eq i64 %sext.i316, 0
  br i1 %tobool.not.i.not.i318, label %if.then.i320, label %if.else.i329

if.then.i320:                                     ; preds = %209
  %call29.i319 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %214, ptr noundef %215) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit343

if.else.i329:                                     ; preds = %209
  %conv.i118.i321 = ashr exact i64 %sext.i316, 32
  %conv.i.i322 = zext i32 %216 to i64
  %conv.i116.i323 = zext i32 %217 to i64
  %shl.i.i324 = shl nuw i64 %conv.i116.i323, 32
  %or.i.i325 = or i64 %shl.i.i324, %conv.i.i322
  %div.i.i326 = sdiv i64 %or.i.i325, %conv.i118.i321
  %rem.i.i327 = srem i64 %or.i.i325, %conv.i118.i321
  %218 = add i64 %div.i.i326, 2147483648
  %cmp.not.i328 = icmp ult i64 %218, 4294967296
  br i1 %cmp.not.i328, label %do.body42.i341, label %if.then35.i331

if.then35.i331:                                   ; preds = %if.else.i329
  %call39.i330 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %214, ptr noundef %215) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit343

do.body42.i341:                                   ; preds = %if.else.i329
  %conv.i123.i332 = and i64 %div.i.i326, 4294967295
  store i64 %conv.i123.i332, ptr %rax.i314, align 8
  %conv.i124.i333 = and i64 %rem.i.i327, 4294967295
  store i64 %conv.i124.i333, ptr %rdx.i315, align 8
  %call64.i334 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i335 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i334, ptr %cf.i335, align 1
  %pf.i336 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i334, ptr %pf.i336, align 1
  %af.i337 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i334, ptr %af.i337, align 1
  %zf.i338 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i334, ptr %zf.i338, align 1
  %sf.i339 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i334, ptr %sf.i339, align 1
  %of.i340 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i334, ptr %of.i340, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit343

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit343: ; preds = %do.body42.i341, %if.then35.i331, %if.then.i320
  %retval.1.i342 = phi ptr [ %call29.i319, %if.then.i320 ], [ %call39.i330, %if.then35.i331 ], [ %215, %do.body42.i341 ]
  store ptr %retval.1.i342, ptr %MEMORY, align 8
  br label %219

219:                                              ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit343
  %220 = load i64, ptr %NEXT_PC, align 8
  store i64 %220, ptr %PC, align 8
  %221 = add i64 %220, 4
  store i64 %221, ptr %NEXT_PC, align 8
  %222 = load i64, ptr %RBP, align 8
  %223 = sub i64 %222, 56
  %224 = load ptr, ptr %MEMORY, align 8
  %call.i.i503 = call i64 @__remill_read_memory_64(ptr noundef %224, i64 noundef %223) #13
  store i64 %call.i.i503, ptr %RAX, align 8
  store ptr %224, ptr %MEMORY, align 8
  br label %225

225:                                              ; preds = %219
  %226 = load i64, ptr %NEXT_PC, align 8
  store i64 %226, ptr %PC, align 8
  %227 = add i64 %226, 3
  store i64 %227, ptr %NEXT_PC, align 8
  %228 = load i64, ptr %RBP, align 8
  %229 = sub i64 %228, 100
  %230 = load i32, ptr %EDX, align 4
  %231 = zext i32 %230 to i64
  %232 = load ptr, ptr %MEMORY, align 8
  %call.i.i464 = call ptr @__remill_write_memory_32(ptr noundef %232, i64 noundef %229, i32 noundef %230) #13
  store ptr %call.i.i464, ptr %MEMORY, align 8
  br label %233

233:                                              ; preds = %225
  %234 = load i64, ptr %NEXT_PC, align 8
  store i64 %234, ptr %PC, align 8
  %235 = add i64 %234, 2
  store i64 %235, ptr %NEXT_PC, align 8
  %236 = load i64, ptr %RAX, align 8
  %237 = load ptr, ptr %MEMORY, align 8
  %call.i.i484 = call i32 @__remill_read_memory_32(ptr noundef %237, i64 noundef %236) #13
  %conv.i.i485 = zext i32 %call.i.i484 to i64
  store i64 %conv.i.i485, ptr %RAX, align 8
  store ptr %237, ptr %MEMORY, align 8
  br label %238

238:                                              ; preds = %233
  %239 = load i64, ptr %NEXT_PC, align 8
  store i64 %239, ptr %PC, align 8
  %240 = add i64 %239, 5
  store i64 %240, ptr %NEXT_PC, align 8
  %241 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RSI, align 8
  store ptr %241, ptr %MEMORY, align 8
  br label %242

242:                                              ; preds = %238
  %243 = load i64, ptr %NEXT_PC, align 8
  store i64 %243, ptr %PC, align 8
  %244 = add i64 %243, 1
  store i64 %244, ptr %NEXT_PC, align 8
  %245 = load ptr, ptr %MEMORY, align 8
  %rdx.i446 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i447 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %246 = load i32, ptr %rax.i447, align 8
  %247 = ashr i32 %246, 31
  %conv.i13.i448 = zext i32 %247 to i64
  store i64 %conv.i13.i448, ptr %rdx.i446, align 8
  store ptr %245, ptr %MEMORY, align 8
  br label %248

248:                                              ; preds = %242
  %249 = load i64, ptr %NEXT_PC, align 8
  store i64 %249, ptr %PC, align 8
  %250 = add i64 %249, 2
  store i64 %250, ptr %NEXT_PC, align 8
  %251 = load i32, ptr %ESI, align 4
  %252 = zext i32 %251 to i64
  %253 = load i64, ptr %NEXT_PC, align 8
  %254 = load ptr, ptr %MEMORY, align 8
  %rax.i284 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %255 = load i32, ptr %rax.i284, align 8
  %rdx.i285 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %256 = load i32, ptr %rdx.i285, align 8
  %sext.i286 = shl i64 %252, 32
  %rip.i287 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %253, ptr %rip.i287, align 8
  %tobool.not.i.not.i288 = icmp eq i64 %sext.i286, 0
  br i1 %tobool.not.i.not.i288, label %if.then.i290, label %if.else.i299

if.then.i290:                                     ; preds = %248
  %call29.i289 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %253, ptr noundef %254) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit313

if.else.i299:                                     ; preds = %248
  %conv.i118.i291 = ashr exact i64 %sext.i286, 32
  %conv.i.i292 = zext i32 %255 to i64
  %conv.i116.i293 = zext i32 %256 to i64
  %shl.i.i294 = shl nuw i64 %conv.i116.i293, 32
  %or.i.i295 = or i64 %shl.i.i294, %conv.i.i292
  %div.i.i296 = sdiv i64 %or.i.i295, %conv.i118.i291
  %rem.i.i297 = srem i64 %or.i.i295, %conv.i118.i291
  %257 = add i64 %div.i.i296, 2147483648
  %cmp.not.i298 = icmp ult i64 %257, 4294967296
  br i1 %cmp.not.i298, label %do.body42.i311, label %if.then35.i301

if.then35.i301:                                   ; preds = %if.else.i299
  %call39.i300 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %253, ptr noundef %254) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit313

do.body42.i311:                                   ; preds = %if.else.i299
  %conv.i123.i302 = and i64 %div.i.i296, 4294967295
  store i64 %conv.i123.i302, ptr %rax.i284, align 8
  %conv.i124.i303 = and i64 %rem.i.i297, 4294967295
  store i64 %conv.i124.i303, ptr %rdx.i285, align 8
  %call64.i304 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i305 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i304, ptr %cf.i305, align 1
  %pf.i306 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i304, ptr %pf.i306, align 1
  %af.i307 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i304, ptr %af.i307, align 1
  %zf.i308 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i304, ptr %zf.i308, align 1
  %sf.i309 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i304, ptr %sf.i309, align 1
  %of.i310 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i304, ptr %of.i310, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit313

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit313: ; preds = %do.body42.i311, %if.then35.i301, %if.then.i290
  %retval.1.i312 = phi ptr [ %call29.i289, %if.then.i290 ], [ %call39.i300, %if.then35.i301 ], [ %254, %do.body42.i311 ]
  store ptr %retval.1.i312, ptr %MEMORY, align 8
  br label %258

258:                                              ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit313
  %259 = load i64, ptr %NEXT_PC, align 8
  store i64 %259, ptr %PC, align 8
  %260 = add i64 %259, 3
  store i64 %260, ptr %NEXT_PC, align 8
  %261 = load i64, ptr %RBP, align 8
  %262 = sub i64 %261, 100
  %263 = load ptr, ptr %MEMORY, align 8
  %call.i.i482 = call i32 @__remill_read_memory_32(ptr noundef %263, i64 noundef %262) #13
  %conv.i.i483 = zext i32 %call.i.i482 to i64
  store i64 %conv.i.i483, ptr %RAX, align 8
  store ptr %263, ptr %MEMORY, align 8
  br label %264

264:                                              ; preds = %258
  %265 = load i64, ptr %NEXT_PC, align 8
  store i64 %265, ptr %PC, align 8
  %266 = add i64 %265, 2
  store i64 %266, ptr %NEXT_PC, align 8
  %267 = load i32, ptr %EDX, align 4
  %268 = zext i32 %267 to i64
  %269 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i472 = and i64 %268, 4294967295
  store i64 %conv.i11.i472, ptr %RSI, align 8
  store ptr %269, ptr %MEMORY, align 8
  br label %270

270:                                              ; preds = %264
  %271 = load i64, ptr %NEXT_PC, align 8
  store i64 %271, ptr %PC, align 8
  %272 = add i64 %271, 4
  store i64 %272, ptr %NEXT_PC, align 8
  %273 = load i64, ptr %RBP, align 8
  %274 = sub i64 %273, 40
  %275 = load ptr, ptr %MEMORY, align 8
  %call.i.i502 = call i64 @__remill_read_memory_64(ptr noundef %275, i64 noundef %274) #13
  store i64 %call.i.i502, ptr %RDX, align 8
  store ptr %275, ptr %MEMORY, align 8
  br label %276

276:                                              ; preds = %270
  %277 = load i64, ptr %NEXT_PC, align 8
  store i64 %277, ptr %PC, align 8
  %278 = add i64 %277, 2
  store i64 %278, ptr %NEXT_PC, align 8
  %279 = load i64, ptr %RAX, align 8
  %280 = load i32, ptr %ESI, align 4
  %281 = zext i32 %280 to i64
  %282 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %279 to i32
  %add.i.i33 = add i32 %280, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RAX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, %280
  %283 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %283, i32 noundef %conv.i.i32, i32 noundef %280, i32 noundef %add.i.i33) #13
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %284 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %285 = and i8 %284, 1
  %conv.i.i.i41 = xor i8 %285, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, %280
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %286 = trunc i32 %xor1.i.i.i.i44 to i8
  %287 = lshr i8 %286, 4
  %conv2.i.i.i45 = and i8 %287, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %280, i32 noundef %add.i.i33) #13
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef %280, i32 noundef %add.i.i33) #13
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef %280, i32 noundef %add.i.i33) #13
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %282, ptr %MEMORY, align 8
  br label %288

288:                                              ; preds = %276
  %289 = load i64, ptr %NEXT_PC, align 8
  store i64 %289, ptr %PC, align 8
  %290 = add i64 %289, 2
  store i64 %290, ptr %NEXT_PC, align 8
  %291 = load i64, ptr %RAX, align 8
  %292 = load i64, ptr %RDX, align 8
  %293 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %291 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %293, i64 noundef %292) #13
  %add.i.i95 = add i32 %call.i.i, %conv.i.i94
  %conv.i18.i = zext i32 %add.i.i95 to i64
  store i64 %conv.i18.i, ptr %RAX, align 8
  %cmp.i.i.i96 = icmp ult i32 %add.i.i95, %conv.i.i94
  %cmp1.i.i.i97 = icmp ult i32 %add.i.i95, %call.i.i
  %294 = or i1 %cmp.i.i.i96, %cmp1.i.i.i97
  %call.i.i.i98 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %294, i32 noundef %conv.i.i94, i32 noundef %call.i.i, i32 noundef %add.i.i95) #13
  %conv.i19.i = zext i1 %call.i.i.i98 to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i99, align 1
  %conv.i.i.i.i100 = trunc i32 %add.i.i95 to i8
  %295 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i100)
  %296 = and i8 %295, 1
  %conv.i.i.i101 = xor i8 %296, 1
  %pf.i.i.i102 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i101, ptr %pf.i.i.i102, align 1
  %xor.i.i.i.i103 = xor i32 %add.i.i95, %call.i.i
  %xor1.i.i.i.i104 = xor i32 %xor.i.i.i.i103, %conv.i.i94
  %297 = trunc i32 %xor1.i.i.i.i104 to i8
  %298 = lshr i8 %297, 4
  %conv2.i.i.i105 = and i8 %298, 1
  %af.i.i.i106 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i105, ptr %af.i.i.i106, align 1
  %cmp.i.i.i.i107 = icmp eq i32 %add.i.i95, 0
  %call.i.i.i.i108 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i107, i32 noundef %conv.i.i94, i32 noundef %call.i.i, i32 noundef %add.i.i95) #13
  %conv5.i.i.i109 = zext i1 %call.i.i.i.i108 to i8
  %zf.i.i.i110 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i109, ptr %zf.i.i.i110, align 1
  %cmp.i27.i.i.i111 = icmp slt i32 %add.i.i95, 0
  %call1.i.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i111, i32 noundef %conv.i.i94, i32 noundef %call.i.i, i32 noundef %add.i.i95) #13
  %conv8.i.i.i113 = zext i1 %call1.i.i.i.i112 to i8
  %sf.i.i.i114 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i113, ptr %sf.i.i.i114, align 1
  %shr8.i.i.i.i115 = xor i32 %add.i.i95, %conv.i.i94
  %xor.i28.i.i.i116 = lshr i32 %shr8.i.i.i.i115, 31
  %xor3.i.i.i.i117 = lshr i32 %xor.i.i.i.i103, 31
  %add.i.i.i.i118 = add nuw nsw i32 %xor.i28.i.i.i116, %xor3.i.i.i.i117
  %cmp.i29.i.i.i119 = icmp eq i32 %add.i.i.i.i118, 2
  %call.i30.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i119, i32 noundef %conv.i.i94, i32 noundef %call.i.i, i32 noundef %add.i.i95) #13
  %conv11.i.i.i121 = zext i1 %call.i30.i.i.i120 to i8
  %of.i.i.i122 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i121, ptr %of.i.i.i122, align 1
  store ptr %293, ptr %MEMORY, align 8
  br label %299

299:                                              ; preds = %288
  %300 = load i64, ptr %NEXT_PC, align 8
  store i64 %300, ptr %PC, align 8
  %301 = add i64 %300, 5
  store i64 %301, ptr %NEXT_PC, align 8
  %302 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RSI, align 8
  store ptr %302, ptr %MEMORY, align 8
  br label %303

303:                                              ; preds = %299
  %304 = load i64, ptr %NEXT_PC, align 8
  store i64 %304, ptr %PC, align 8
  %305 = add i64 %304, 1
  store i64 %305, ptr %NEXT_PC, align 8
  %306 = load ptr, ptr %MEMORY, align 8
  %rdx.i443 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i444 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %307 = load i32, ptr %rax.i444, align 8
  %308 = ashr i32 %307, 31
  %conv.i13.i445 = zext i32 %308 to i64
  store i64 %conv.i13.i445, ptr %rdx.i443, align 8
  store ptr %306, ptr %MEMORY, align 8
  br label %309

309:                                              ; preds = %303
  %310 = load i64, ptr %NEXT_PC, align 8
  store i64 %310, ptr %PC, align 8
  %311 = add i64 %310, 2
  store i64 %311, ptr %NEXT_PC, align 8
  %312 = load i32, ptr %ESI, align 4
  %313 = zext i32 %312 to i64
  %314 = load i64, ptr %NEXT_PC, align 8
  %315 = load ptr, ptr %MEMORY, align 8
  %rax.i254 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %316 = load i32, ptr %rax.i254, align 8
  %rdx.i255 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %317 = load i32, ptr %rdx.i255, align 8
  %sext.i256 = shl i64 %313, 32
  %rip.i257 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %314, ptr %rip.i257, align 8
  %tobool.not.i.not.i258 = icmp eq i64 %sext.i256, 0
  br i1 %tobool.not.i.not.i258, label %if.then.i260, label %if.else.i269

if.then.i260:                                     ; preds = %309
  %call29.i259 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %314, ptr noundef %315) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit283

if.else.i269:                                     ; preds = %309
  %conv.i118.i261 = ashr exact i64 %sext.i256, 32
  %conv.i.i262 = zext i32 %316 to i64
  %conv.i116.i263 = zext i32 %317 to i64
  %shl.i.i264 = shl nuw i64 %conv.i116.i263, 32
  %or.i.i265 = or i64 %shl.i.i264, %conv.i.i262
  %div.i.i266 = sdiv i64 %or.i.i265, %conv.i118.i261
  %rem.i.i267 = srem i64 %or.i.i265, %conv.i118.i261
  %318 = add i64 %div.i.i266, 2147483648
  %cmp.not.i268 = icmp ult i64 %318, 4294967296
  br i1 %cmp.not.i268, label %do.body42.i281, label %if.then35.i271

if.then35.i271:                                   ; preds = %if.else.i269
  %call39.i270 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %314, ptr noundef %315) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit283

do.body42.i281:                                   ; preds = %if.else.i269
  %conv.i123.i272 = and i64 %div.i.i266, 4294967295
  store i64 %conv.i123.i272, ptr %rax.i254, align 8
  %conv.i124.i273 = and i64 %rem.i.i267, 4294967295
  store i64 %conv.i124.i273, ptr %rdx.i255, align 8
  %call64.i274 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i275 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i274, ptr %cf.i275, align 1
  %pf.i276 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i274, ptr %pf.i276, align 1
  %af.i277 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i274, ptr %af.i277, align 1
  %zf.i278 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i274, ptr %zf.i278, align 1
  %sf.i279 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i274, ptr %sf.i279, align 1
  %of.i280 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i274, ptr %of.i280, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit283

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit283: ; preds = %do.body42.i281, %if.then35.i271, %if.then.i260
  %retval.1.i282 = phi ptr [ %call29.i259, %if.then.i260 ], [ %call39.i270, %if.then35.i271 ], [ %315, %do.body42.i281 ]
  store ptr %retval.1.i282, ptr %MEMORY, align 8
  br label %319

319:                                              ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit283
  %320 = load i64, ptr %NEXT_PC, align 8
  store i64 %320, ptr %PC, align 8
  %321 = add i64 %320, 2
  store i64 %321, ptr %NEXT_PC, align 8
  %322 = load i32, ptr %EAX, align 4
  %323 = zext i32 %322 to i64
  %324 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i471 = and i64 %323, 4294967295
  store i64 %conv.i11.i471, ptr %RDX, align 8
  store ptr %324, ptr %MEMORY, align 8
  br label %325

325:                                              ; preds = %319
  %326 = load i64, ptr %NEXT_PC, align 8
  store i64 %326, ptr %PC, align 8
  %327 = add i64 %326, 4
  store i64 %327, ptr %NEXT_PC, align 8
  %328 = load i64, ptr %RBP, align 8
  %329 = sub i64 %328, 40
  %330 = load ptr, ptr %MEMORY, align 8
  %call.i.i501 = call i64 @__remill_read_memory_64(ptr noundef %330, i64 noundef %329) #13
  store i64 %call.i.i501, ptr %RAX, align 8
  store ptr %330, ptr %MEMORY, align 8
  br label %331

331:                                              ; preds = %325
  %332 = load i64, ptr %NEXT_PC, align 8
  store i64 %332, ptr %PC, align 8
  %333 = add i64 %332, 2
  store i64 %333, ptr %NEXT_PC, align 8
  %334 = load i64, ptr %RAX, align 8
  %335 = load i32, ptr %EDX, align 4
  %336 = zext i32 %335 to i64
  %337 = load ptr, ptr %MEMORY, align 8
  %call.i.i463 = call ptr @__remill_write_memory_32(ptr noundef %337, i64 noundef %334, i32 noundef %335) #13
  store ptr %call.i.i463, ptr %MEMORY, align 8
  br label %338

338:                                              ; preds = %331
  %339 = load i64, ptr %NEXT_PC, align 8
  store i64 %339, ptr %PC, align 8
  %340 = add i64 %339, 2
  store i64 %340, ptr %NEXT_PC, align 8
  %341 = load i64, ptr %RCX, align 8
  %342 = load ptr, ptr %MEMORY, align 8
  %call.i.i480 = call i32 @__remill_read_memory_32(ptr noundef %342, i64 noundef %341) #13
  %conv.i.i481 = zext i32 %call.i.i480 to i64
  store i64 %conv.i.i481, ptr %RAX, align 8
  store ptr %342, ptr %MEMORY, align 8
  br label %343

343:                                              ; preds = %338
  %344 = load i64, ptr %NEXT_PC, align 8
  store i64 %344, ptr %PC, align 8
  %345 = add i64 %344, 5
  store i64 %345, ptr %NEXT_PC, align 8
  %346 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RSI, align 8
  store ptr %346, ptr %MEMORY, align 8
  br label %347

347:                                              ; preds = %343
  %348 = load i64, ptr %NEXT_PC, align 8
  store i64 %348, ptr %PC, align 8
  %349 = add i64 %348, 1
  store i64 %349, ptr %NEXT_PC, align 8
  %350 = load ptr, ptr %MEMORY, align 8
  %rdx.i440 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i441 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %351 = load i32, ptr %rax.i441, align 8
  %352 = ashr i32 %351, 31
  %conv.i13.i442 = zext i32 %352 to i64
  store i64 %conv.i13.i442, ptr %rdx.i440, align 8
  store ptr %350, ptr %MEMORY, align 8
  br label %353

353:                                              ; preds = %347
  %354 = load i64, ptr %NEXT_PC, align 8
  store i64 %354, ptr %PC, align 8
  %355 = add i64 %354, 2
  store i64 %355, ptr %NEXT_PC, align 8
  %356 = load i32, ptr %ESI, align 4
  %357 = zext i32 %356 to i64
  %358 = load i64, ptr %NEXT_PC, align 8
  %359 = load ptr, ptr %MEMORY, align 8
  %rax.i224 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %360 = load i32, ptr %rax.i224, align 8
  %rdx.i225 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %361 = load i32, ptr %rdx.i225, align 8
  %sext.i226 = shl i64 %357, 32
  %rip.i227 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %358, ptr %rip.i227, align 8
  %tobool.not.i.not.i228 = icmp eq i64 %sext.i226, 0
  br i1 %tobool.not.i.not.i228, label %if.then.i230, label %if.else.i239

if.then.i230:                                     ; preds = %353
  %call29.i229 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %358, ptr noundef %359) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit253

if.else.i239:                                     ; preds = %353
  %conv.i118.i231 = ashr exact i64 %sext.i226, 32
  %conv.i.i232 = zext i32 %360 to i64
  %conv.i116.i233 = zext i32 %361 to i64
  %shl.i.i234 = shl nuw i64 %conv.i116.i233, 32
  %or.i.i235 = or i64 %shl.i.i234, %conv.i.i232
  %div.i.i236 = sdiv i64 %or.i.i235, %conv.i118.i231
  %rem.i.i237 = srem i64 %or.i.i235, %conv.i118.i231
  %362 = add i64 %div.i.i236, 2147483648
  %cmp.not.i238 = icmp ult i64 %362, 4294967296
  br i1 %cmp.not.i238, label %do.body42.i251, label %if.then35.i241

if.then35.i241:                                   ; preds = %if.else.i239
  %call39.i240 = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %358, ptr noundef %359) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit253

do.body42.i251:                                   ; preds = %if.else.i239
  %conv.i123.i242 = and i64 %div.i.i236, 4294967295
  store i64 %conv.i123.i242, ptr %rax.i224, align 8
  %conv.i124.i243 = and i64 %rem.i.i237, 4294967295
  store i64 %conv.i124.i243, ptr %rdx.i225, align 8
  %call64.i244 = call zeroext i8 @__remill_undefined_8() #14
  %cf.i245 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i244, ptr %cf.i245, align 1
  %pf.i246 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i244, ptr %pf.i246, align 1
  %af.i247 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i244, ptr %af.i247, align 1
  %zf.i248 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i244, ptr %zf.i248, align 1
  %sf.i249 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i244, ptr %sf.i249, align 1
  %of.i250 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i244, ptr %of.i250, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit253

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit253: ; preds = %do.body42.i251, %if.then35.i241, %if.then.i230
  %retval.1.i252 = phi ptr [ %call29.i229, %if.then.i230 ], [ %call39.i240, %if.then35.i241 ], [ %359, %do.body42.i251 ]
  store ptr %retval.1.i252, ptr %MEMORY, align 8
  br label %363

363:                                              ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit253
  %364 = load i64, ptr %NEXT_PC, align 8
  store i64 %364, ptr %PC, align 8
  %365 = add i64 %364, 2
  store i64 %365, ptr %NEXT_PC, align 8
  %366 = load i32, ptr %EAX, align 4
  %367 = zext i32 %366 to i64
  %368 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i470 = and i64 %367, 4294967295
  store i64 %conv.i11.i470, ptr %RDX, align 8
  store ptr %368, ptr %MEMORY, align 8
  br label %369

369:                                              ; preds = %363
  %370 = load i64, ptr %NEXT_PC, align 8
  store i64 %370, ptr %PC, align 8
  %371 = add i64 %370, 4
  store i64 %371, ptr %NEXT_PC, align 8
  %372 = load i64, ptr %RBP, align 8
  %373 = sub i64 %372, 56
  %374 = load ptr, ptr %MEMORY, align 8
  %call.i.i500 = call i64 @__remill_read_memory_64(ptr noundef %374, i64 noundef %373) #13
  store i64 %call.i.i500, ptr %RAX, align 8
  store ptr %374, ptr %MEMORY, align 8
  br label %375

375:                                              ; preds = %369
  %376 = load i64, ptr %NEXT_PC, align 8
  store i64 %376, ptr %PC, align 8
  %377 = add i64 %376, 2
  store i64 %377, ptr %NEXT_PC, align 8
  %378 = load i64, ptr %RCX, align 8
  %379 = load i32, ptr %EDX, align 4
  %380 = zext i32 %379 to i64
  %381 = load ptr, ptr %MEMORY, align 8
  %call.i.i462 = call ptr @__remill_write_memory_32(ptr noundef %381, i64 noundef %378, i32 noundef %379) #13
  store ptr %call.i.i462, ptr %MEMORY, align 8
  br label %382

382:                                              ; preds = %375
  %383 = load i64, ptr %NEXT_PC, align 8
  store i64 %383, ptr %PC, align 8
  %384 = add i64 %383, 2
  store i64 %384, ptr %NEXT_PC, align 8
  %385 = load i64, ptr %RAX, align 8
  %386 = load ptr, ptr %MEMORY, align 8
  %call.i.i478 = call i32 @__remill_read_memory_32(ptr noundef %386, i64 noundef %385) #13
  %conv.i.i479 = zext i32 %call.i.i478 to i64
  store i64 %conv.i.i479, ptr %RAX, align 8
  store ptr %386, ptr %MEMORY, align 8
  br label %387

387:                                              ; preds = %382
  %388 = load i64, ptr %NEXT_PC, align 8
  store i64 %388, ptr %PC, align 8
  %389 = add i64 %388, 5
  store i64 %389, ptr %NEXT_PC, align 8
  %390 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RCX, align 8
  store ptr %390, ptr %MEMORY, align 8
  br label %391

391:                                              ; preds = %387
  %392 = load i64, ptr %NEXT_PC, align 8
  store i64 %392, ptr %PC, align 8
  %393 = add i64 %392, 1
  store i64 %393, ptr %NEXT_PC, align 8
  %394 = load ptr, ptr %MEMORY, align 8
  %rdx.i438 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %rax.i439 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %395 = load i32, ptr %rax.i439, align 8
  %396 = ashr i32 %395, 31
  %conv.i13.i = zext i32 %396 to i64
  store i64 %conv.i13.i, ptr %rdx.i438, align 8
  store ptr %394, ptr %MEMORY, align 8
  br label %397

397:                                              ; preds = %391
  %398 = load i64, ptr %NEXT_PC, align 8
  store i64 %398, ptr %PC, align 8
  %399 = add i64 %398, 2
  store i64 %399, ptr %NEXT_PC, align 8
  %400 = load i32, ptr %ECX, align 4
  %401 = zext i32 %400 to i64
  %402 = load i64, ptr %NEXT_PC, align 8
  %403 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %404 = load i32, ptr %rax.i, align 8
  %rdx.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %405 = load i32, ptr %rdx.i, align 8
  %sext.i222 = shl i64 %401, 32
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %402, ptr %rip.i, align 8
  %tobool.not.i.not.i = icmp eq i64 %sext.i222, 0
  br i1 %tobool.not.i.not.i, label %if.then.i, label %if.else.i

if.then.i:                                        ; preds = %397
  %call29.i = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %402, ptr noundef %403) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

if.else.i:                                        ; preds = %397
  %conv.i118.i = ashr exact i64 %sext.i222, 32
  %conv.i.i223 = zext i32 %404 to i64
  %conv.i116.i = zext i32 %405 to i64
  %shl.i.i = shl nuw i64 %conv.i116.i, 32
  %or.i.i = or i64 %shl.i.i, %conv.i.i223
  %div.i.i = sdiv i64 %or.i.i, %conv.i118.i
  %rem.i.i = srem i64 %or.i.i, %conv.i118.i
  %406 = add i64 %div.i.i, 2147483648
  %cmp.not.i = icmp ult i64 %406, 4294967296
  br i1 %cmp.not.i, label %do.body42.i, label %if.then35.i

if.then35.i:                                      ; preds = %if.else.i
  %call39.i = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %402, ptr noundef %403) #15
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

do.body42.i:                                      ; preds = %if.else.i
  %conv.i123.i = and i64 %div.i.i, 4294967295
  store i64 %conv.i123.i, ptr %rax.i, align 8
  %conv.i124.i = and i64 %rem.i.i, 4294967295
  store i64 %conv.i124.i, ptr %rdx.i, align 8
  %call64.i = call zeroext i8 @__remill_undefined_8() #14
  %cf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i, ptr %of.i, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit: ; preds = %do.body42.i, %if.then35.i, %if.then.i
  %retval.1.i = phi ptr [ %call29.i, %if.then.i ], [ %call39.i, %if.then35.i ], [ %403, %do.body42.i ]
  store ptr %retval.1.i, ptr %MEMORY, align 8
  br label %407

407:                                              ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit
  %408 = load i64, ptr %NEXT_PC, align 8
  store i64 %408, ptr %PC, align 8
  %409 = add i64 %408, 2
  store i64 %409, ptr %NEXT_PC, align 8
  %410 = load i32, ptr %EAX, align 4
  %411 = zext i32 %410 to i64
  %412 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i469 = and i64 %411, 4294967295
  store i64 %conv.i11.i469, ptr %RCX, align 8
  store ptr %412, ptr %MEMORY, align 8
  br label %413

413:                                              ; preds = %407
  %414 = load i64, ptr %NEXT_PC, align 8
  store i64 %414, ptr %PC, align 8
  %415 = add i64 %414, 4
  store i64 %415, ptr %NEXT_PC, align 8
  %416 = load i64, ptr %RBP, align 8
  %417 = sub i64 %416, 56
  %418 = load ptr, ptr %MEMORY, align 8
  %call.i.i499 = call i64 @__remill_read_memory_64(ptr noundef %418, i64 noundef %417) #13
  store i64 %call.i.i499, ptr %RAX, align 8
  store ptr %418, ptr %MEMORY, align 8
  br label %419

419:                                              ; preds = %413
  %420 = load i64, ptr %NEXT_PC, align 8
  store i64 %420, ptr %PC, align 8
  %421 = add i64 %420, 2
  store i64 %421, ptr %NEXT_PC, align 8
  %422 = load i64, ptr %RAX, align 8
  %423 = load i32, ptr %ECX, align 4
  %424 = zext i32 %423 to i64
  %425 = load ptr, ptr %MEMORY, align 8
  %call.i.i461 = call ptr @__remill_write_memory_32(ptr noundef %425, i64 noundef %422, i32 noundef %423) #13
  store ptr %call.i.i461, ptr %MEMORY, align 8
  br label %426

426:                                              ; preds = %419
  %427 = load i64, ptr %NEXT_PC, align 8
  store i64 %427, ptr %PC, align 8
  %428 = add i64 %427, 7
  store i64 %428, ptr %NEXT_PC, align 8
  %429 = load i64, ptr %NEXT_PC, align 8
  %430 = add i64 %429, 13256
  %431 = load ptr, ptr %MEMORY, align 8
  %call.i.i498 = call i64 @__remill_read_memory_64(ptr noundef %431, i64 noundef %430) #13
  store i64 %call.i.i498, ptr %RAX, align 8
  store ptr %431, ptr %MEMORY, align 8
  br label %432

432:                                              ; preds = %426
  %433 = load i64, ptr %NEXT_PC, align 8
  store i64 %433, ptr %PC, align 8
  %434 = add i64 %433, 4
  store i64 %434, ptr %NEXT_PC, align 8
  %435 = load i64, ptr %RAX, align 8
  %436 = load ptr, ptr %MEMORY, align 8
  store i64 %435, ptr %RAX, align 8
  %call.i.i.i155 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %435, i64 noundef 0, i64 noundef %435) #13
  %conv.i.i156 = zext i1 %call.i.i.i155 to i8
  %cf.i.i157 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i156, ptr %cf.i.i157, align 1
  %conv.i.i.i.i158 = trunc i64 %435 to i8
  %437 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i158)
  %438 = and i8 %437, 1
  %conv.i.i.i159 = xor i8 %438, 1
  %pf.i.i.i160 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i159, ptr %pf.i.i.i160, align 1
  %af.i.i.i161 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i161, align 1
  %cmp.i.i.i.i162 = icmp eq i64 %435, 0
  %call.i.i.i.i163 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i162, i64 noundef %435, i64 noundef 0, i64 noundef %435) #13
  %conv5.i.i.i164 = zext i1 %call.i.i.i.i163 to i8
  %zf.i.i.i165 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i164, ptr %zf.i.i.i165, align 1
  %cmp.i27.i.i.i166 = icmp slt i64 %435, 0
  %call1.i.i.i.i167 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i166, i64 noundef %435, i64 noundef 0, i64 noundef %435) #13
  %conv8.i.i.i168 = zext i1 %call1.i.i.i.i167 to i8
  %sf.i.i.i169 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i168, ptr %sf.i.i.i169, align 1
  %xor.i28.i.i.i170 = lshr i64 %435, 63
  %call.i30.i.i.i171 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %435, i64 noundef 0, i64 noundef %435) #13
  %conv11.i.i.i172 = zext i1 %call.i30.i.i.i171 to i8
  %of.i.i.i173 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i172, ptr %of.i.i.i173, align 1
  store ptr %436, ptr %MEMORY, align 8
  br label %439

439:                                              ; preds = %432
  %440 = load i64, ptr %NEXT_PC, align 8
  store i64 %440, ptr %PC, align 8
  %441 = add i64 %440, 4
  store i64 %441, ptr %NEXT_PC, align 8
  %442 = load i64, ptr %RBP, align 8
  %443 = sub i64 %442, 96
  %444 = load i64, ptr %RAX, align 8
  %445 = load ptr, ptr %MEMORY, align 8
  %call.i.i468 = call ptr @__remill_write_memory_64(ptr noundef %445, i64 noundef %443, i64 noundef %444) #13
  store ptr %call.i.i468, ptr %MEMORY, align 8
  br label %446

446:                                              ; preds = %439
  %447 = load i64, ptr %NEXT_PC, align 8
  store i64 %447, ptr %PC, align 8
  %448 = add i64 %447, 7
  store i64 %448, ptr %NEXT_PC, align 8
  %449 = load i64, ptr %NEXT_PC, align 8
  %450 = add i64 %449, 12809
  %451 = load ptr, ptr %MEMORY, align 8
  %call.i.i497 = call i64 @__remill_read_memory_64(ptr noundef %451, i64 noundef %450) #13
  store i64 %call.i.i497, ptr %RAX, align 8
  store ptr %451, ptr %MEMORY, align 8
  br label %452

452:                                              ; preds = %446
  %453 = load i64, ptr %NEXT_PC, align 8
  store i64 %453, ptr %PC, align 8
  %454 = add i64 %453, 2
  store i64 %454, ptr %NEXT_PC, align 8
  %455 = load i64, ptr %RAX, align 8
  %456 = load ptr, ptr %MEMORY, align 8
  %call.i.i476 = call i32 @__remill_read_memory_32(ptr noundef %456, i64 noundef %455) #13
  %conv.i.i477 = zext i32 %call.i.i476 to i64
  store i64 %conv.i.i477, ptr %RDX, align 8
  store ptr %456, ptr %MEMORY, align 8
  br label %457

457:                                              ; preds = %452
  %458 = load i64, ptr %NEXT_PC, align 8
  store i64 %458, ptr %PC, align 8
  %459 = add i64 %458, 7
  store i64 %459, ptr %NEXT_PC, align 8
  %460 = load i64, ptr %NEXT_PC, align 8
  %461 = add i64 %460, 13064
  %462 = load ptr, ptr %MEMORY, align 8
  %call.i.i496 = call i64 @__remill_read_memory_64(ptr noundef %462, i64 noundef %461) #13
  store i64 %call.i.i496, ptr %RAX, align 8
  store ptr %462, ptr %MEMORY, align 8
  br label %463

463:                                              ; preds = %457
  %464 = load i64, ptr %NEXT_PC, align 8
  store i64 %464, ptr %PC, align 8
  %465 = add i64 %464, 3
  store i64 %465, ptr %NEXT_PC, align 8
  %466 = load i64, ptr %RAX, align 8
  %467 = load ptr, ptr %MEMORY, align 8
  %call.i.i174 = call i32 @__remill_read_memory_32(ptr noundef %467, i64 noundef %466) #13
  %sub.i.i = sub i32 %call.i.i174, 10
  %cmp.i.i.i175 = icmp ult i32 %call.i.i174, 10
  %call.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i175, i32 noundef %call.i.i174, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i176 to i8
  %cf.i.i177 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i177, align 1
  %conv.i.i.i.i178 = trunc i32 %sub.i.i to i8
  %468 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i178)
  %469 = and i8 %468, 1
  %conv.i.i.i179 = xor i8 %469, 1
  %pf.i.i.i180 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i179, ptr %pf.i.i.i180, align 1
  %xor.i.i.i.i181 = xor i32 %call.i.i174, 10
  %xor1.i.i.i.i182 = xor i32 %xor.i.i.i.i181, %sub.i.i
  %470 = trunc i32 %xor1.i.i.i.i182 to i8
  %471 = lshr i8 %470, 4
  %conv2.i.i.i183 = and i8 %471, 1
  %af.i.i.i184 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i183, ptr %af.i.i.i184, align 1
  %cmp.i.i.i.i185 = icmp eq i32 %call.i.i174, 10
  %call.i.i.i.i186 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i185, i32 noundef %call.i.i174, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i187 = zext i1 %call.i.i.i.i186 to i8
  %zf.i.i.i188 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i187, ptr %zf.i.i.i188, align 1
  %cmp.i27.i.i.i189 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i190 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i189, i32 noundef %call.i.i174, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i191 = zext i1 %call1.i.i.i.i190 to i8
  %sf.i.i.i192 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i191, ptr %sf.i.i.i192, align 1
  %xor.i28.i.i.i193 = lshr i32 %xor.i.i.i.i181, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i174
  %xor3.i.i.i.i194 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i195 = add nuw nsw i32 %xor3.i.i.i.i194, %xor.i28.i.i.i193
  %cmp.i29.i.i.i196 = icmp eq i32 %add.i.i.i.i195, 2
  %call.i30.i.i.i197 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i196, i32 noundef %call.i.i174, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i198 = zext i1 %call.i30.i.i.i197 to i8
  %of.i.i.i199 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i198, ptr %of.i.i.i199, align 1
  store ptr %467, ptr %MEMORY, align 8
  br label %472

472:                                              ; preds = %463
  %473 = load i64, ptr %NEXT_PC, align 8
  store i64 %473, ptr %PC, align 8
  %474 = add i64 %473, 3
  store i64 %474, ptr %NEXT_PC, align 8
  %475 = load ptr, ptr %MEMORY, align 8
  %sf.i434 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %476 = load i8, ptr %sf.i434, align 1
  %tobool.i = icmp ne i8 %476, 0
  %of.i435 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %477 = load i8, ptr %of.i435, align 1
  %tobool2.i = icmp ne i8 %477, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %475, ptr %MEMORY, align 8
  br label %478

478:                                              ; preds = %472
  %479 = load i64, ptr %NEXT_PC, align 8
  store i64 %479, ptr %PC, align 8
  %480 = add i64 %479, 2
  store i64 %480, ptr %NEXT_PC, align 8
  %481 = load i32, ptr %EDX, align 4
  %482 = zext i32 %481 to i64
  %483 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %482, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %483, ptr %MEMORY, align 8
  br label %484

484:                                              ; preds = %478
  %485 = load i64, ptr %NEXT_PC, align 8
  store i64 %485, ptr %PC, align 8
  %486 = add i64 %485, 3
  store i64 %486, ptr %NEXT_PC, align 8
  %487 = load i64, ptr %RCX, align 8
  %488 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %487 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %489 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %489, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %490 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %491 = and i8 %490, 1
  %conv.i.i.i = xor i8 %491, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %492 = trunc i32 %xor1.i.i.i.i to i8
  %493 = lshr i8 %492, 4
  %conv2.i.i.i = and i8 %493, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %488, ptr %MEMORY, align 8
  br label %494

494:                                              ; preds = %484
  %495 = load i64, ptr %NEXT_PC, align 8
  store i64 %495, ptr %PC, align 8
  %496 = add i64 %495, 3
  store i64 %496, ptr %NEXT_PC, align 8
  %497 = load i64, ptr %RCX, align 8
  %498 = load i32, ptr %EDX, align 4
  %499 = zext i32 %498 to i64
  %500 = load ptr, ptr %MEMORY, align 8
  %conv.i.i218 = trunc i64 %497 to i32
  %sext.i = shl i64 %497, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %499, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %501 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i219 = icmp ult i64 %501, -4294967296
  %call.i.i.i220 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i219, i32 noundef %conv.i.i218, i32 noundef %498, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i220 to i8
  %cf.i.i221 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i221, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %500, ptr %MEMORY, align 8
  br label %502

502:                                              ; preds = %494
  %503 = load i64, ptr %NEXT_PC, align 8
  store i64 %503, ptr %PC, align 8
  %504 = add i64 %503, 3
  store i64 %504, ptr %NEXT_PC, align 8
  %505 = load i64, ptr %RCX, align 8
  %506 = load ptr, ptr %MEMORY, align 8
  %conv.i.i511 = trunc i64 %505 to i32
  %and3.i.i = and i32 1, %conv.i.i511
  %conv.i22.i512 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i512, ptr %RCX, align 8
  %cf.i.i513 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i513, align 1
  %conv.i.i.i514 = trunc i32 %and3.i.i to i8
  %507 = and i8 %conv.i.i.i514, 1
  %conv.i23.i515 = xor i8 %507, 1
  %pf.i.i516 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i515, ptr %pf.i.i516, align 1
  %cmp.i.i.i517 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i518 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i517, i32 noundef %conv.i.i511, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i518 to i8
  %zf.i.i519 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i519, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i511, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i520 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i520, align 1
  %of.i.i521 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i521, align 1
  %af.i.i522 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i522, align 1
  store ptr %506, ptr %MEMORY, align 8
  br label %508

508:                                              ; preds = %502
  %509 = load i64, ptr %NEXT_PC, align 8
  store i64 %509, ptr %PC, align 8
  %510 = add i64 %509, 3
  store i64 %510, ptr %NEXT_PC, align 8
  %511 = load i32, ptr %ECX, align 4
  %512 = zext i32 %511 to i64
  %513 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i200 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %511, i32 noundef 0, i32 noundef %511) #13
  %conv.i12.i = zext i1 %call.i.i.i200 to i8
  %cf.i.i201 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i201, align 1
  %conv.i.i.i.i202 = trunc i32 %511 to i8
  %514 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i202)
  %515 = and i8 %514, 1
  %conv.i.i.i203 = xor i8 %515, 1
  %pf.i.i.i204 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i203, ptr %pf.i.i.i204, align 1
  %af.i.i.i205 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i205, align 1
  %cmp.i.i.i.i206 = icmp eq i32 %511, 0
  %call.i.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i206, i32 noundef %511, i32 noundef 0, i32 noundef %511) #13
  %conv5.i.i.i208 = zext i1 %call.i.i.i.i207 to i8
  %zf.i.i.i209 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i208, ptr %zf.i.i.i209, align 1
  %cmp.i27.i.i.i210 = icmp slt i32 %511, 0
  %call1.i.i.i.i211 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i210, i32 noundef %511, i32 noundef 0, i32 noundef %511) #13
  %conv8.i.i.i212 = zext i1 %call1.i.i.i.i211 to i8
  %sf.i.i.i213 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i212, ptr %sf.i.i.i213, align 1
  %xor.i28.i.i.i214 = lshr i32 %511, 31
  %call.i30.i.i.i215 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %511, i32 noundef 0, i32 noundef %511) #13
  %conv11.i.i.i216 = zext i1 %call.i30.i.i.i215 to i8
  %of.i.i.i217 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i216, ptr %of.i.i.i217, align 1
  store ptr %513, ptr %MEMORY, align 8
  br label %516

516:                                              ; preds = %508
  %517 = load i64, ptr %NEXT_PC, align 8
  store i64 %517, ptr %PC, align 8
  %518 = add i64 %517, 3
  store i64 %518, ptr %NEXT_PC, align 8
  %519 = load ptr, ptr %MEMORY, align 8
  %zf.i436 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %520 = load i8, ptr %zf.i436, align 1
  store i8 %520, ptr %CL, align 1
  store ptr %519, ptr %MEMORY, align 8
  br label %521

521:                                              ; preds = %516
  %522 = load i64, ptr %NEXT_PC, align 8
  store i64 %522, ptr %PC, align 8
  %523 = add i64 %522, 2
  store i64 %523, ptr %NEXT_PC, align 8
  %524 = load i8, ptr %AL, align 1
  %525 = zext i8 %524 to i64
  %526 = load i8, ptr %CL, align 1
  %527 = zext i8 %526 to i64
  %528 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %527, %525
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i523 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i523, align 1
  %529 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %530 = and i8 %529, 1
  %conv.i27.i = xor i8 %530, 1
  %pf.i.i524 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i524, align 1
  %531 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i525 = and i32 %531, 255
  %cmp.i.i.i526 = icmp eq i8 %or3.i.i, 0
  %532 = trunc i64 %525 to i32
  %conv1.i.i.i = and i32 %532, 255
  %533 = trunc i64 %527 to i32
  %conv2.i.i.i527 = and i32 %533, 255
  %call.i.i.i528 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i526, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i527, i32 noundef %conv.i.i.i525) #13
  %conv3.i.i529 = zext i1 %call.i.i.i528 to i8
  %zf.i.i530 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i529, ptr %zf.i.i530, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i527, i32 noundef %conv.i.i.i525) #13
  %conv6.i.i531 = zext i1 %call4.i.i.i to i8
  %sf.i.i532 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i531, ptr %sf.i.i532, align 1
  %of.i.i533 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i533, align 1
  %af.i.i534 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i534, align 1
  store ptr %528, ptr %MEMORY, align 8
  br label %534

534:                                              ; preds = %521
  %535 = load i64, ptr %NEXT_PC, align 8
  store i64 %535, ptr %PC, align 8
  %536 = add i64 %535, 2
  store i64 %536, ptr %NEXT_PC, align 8
  %537 = load i8, ptr %AL, align 1
  %538 = zext i8 %537 to i64
  %539 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %538
  %and3.i.i535 = trunc i64 %and3.i15.i to i8
  %cf.i.i536 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i536, align 1
  %540 = and i8 %and3.i.i535, 1
  %conv.i14.i = xor i8 %540, 1
  %pf.i.i537 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i537, align 1
  %541 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i538 = and i32 %541, 255
  %cmp.i.i.i539 = icmp eq i8 %and3.i.i535, 0
  %542 = trunc i64 %538 to i32
  %conv1.i.i.i540 = and i32 %542, 255
  %call.i.i.i541 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i539, i32 noundef %conv1.i.i.i540, i32 noundef 1, i32 noundef %conv.i.i.i538) #13
  %conv3.i.i542 = zext i1 %call.i.i.i541 to i8
  %zf.i.i543 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i542, ptr %zf.i.i543, align 1
  %call4.i.i.i544 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i540, i32 noundef 1, i32 noundef %conv.i.i.i538) #13
  %conv6.i.i545 = zext i1 %call4.i.i.i544 to i8
  %sf.i.i546 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i545, ptr %sf.i.i546, align 1
  %of.i.i547 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i547, align 1
  %af.i.i548 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i548, align 1
  store ptr %539, ptr %MEMORY, align 8
  br label %543

543:                                              ; preds = %534
  %544 = load i64, ptr %NEXT_PC, align 8
  store i64 %544, ptr %PC, align 8
  %545 = add i64 %544, 6
  store i64 %545, ptr %NEXT_PC, align 8
  %546 = load i64, ptr %NEXT_PC, align 8
  %547 = add i64 %546, 5
  %548 = load i64, ptr %NEXT_PC, align 8
  %549 = load ptr, ptr %MEMORY, align 8
  %zf.i437 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %550 = load i8, ptr %zf.i437, align 1
  %tobool.not.i = icmp eq i8 %550, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %547, i64 %548
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %549, ptr %MEMORY, align 8
  %551 = load i64, ptr %NEXT_PC, align 8
  store i64 %551, ptr %PC, align 8
  %552 = load ptr, ptr %MEMORY, align 8
  ret ptr %552
}

define ptr @BB_2d42(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i130 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i130, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i125 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i126 = zext i32 %call.i.i125 to i64
  store i64 %conv.i.i126, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  store i64 6, ptr %RCX, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %12
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 5, ptr %RAX, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %16
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i32, ptr %EDX, align 4
  %24 = zext i32 %23 to i64
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv.i12.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i32 %23 to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %27 = and i8 %26, 1
  %conv.i.i.i95 = xor i8 %27, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %af.i.i.i97 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i97, align 1
  %cmp.i.i.i.i98 = icmp eq i32 %23, 0
  %call.i.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i98, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv5.i.i.i100 = zext i1 %call.i.i.i.i99 to i8
  %zf.i.i.i101 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i100, ptr %zf.i.i.i101, align 1
  %cmp.i27.i.i.i102 = icmp slt i32 %23, 0
  %call1.i.i.i.i103 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i102, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv8.i.i.i104 = zext i1 %call1.i.i.i.i103 to i8
  %sf.i.i.i105 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i104, ptr %sf.i.i.i105, align 1
  %xor.i28.i.i.i106 = lshr i32 %23, 31
  %call.i30.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv11.i.i.i108 = zext i1 %call.i30.i.i.i107 to i8
  %of.i.i.i109 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i108, ptr %of.i.i.i109, align 1
  store ptr %25, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i32, ptr %EAX, align 4
  %32 = zext i32 %31 to i64
  %33 = load ptr, ptr %MEMORY, align 8
  %zf.i114 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %34 = load i8, ptr %zf.i114, align 1
  %tobool.not.i = icmp eq i8 %34, 0
  %call3.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call3.i, i64 %32, i64 %dst.coerce.val.i
  %conv.i20.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i20.i, ptr %RCX, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 7
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %NEXT_PC, align 8
  %39 = add i64 %38, 13105
  %40 = load ptr, ptr %MEMORY, align 8
  store i64 %39, ptr %RAX, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i32, ptr %ECX, align 4
  %45 = zext i32 %44 to i64
  %46 = load ptr, ptr %MEMORY, align 8
  %sext.i131 = shl i64 %45, 32
  %conv.i12.i132 = ashr exact i64 %sext.i131, 32
  store i64 %conv.i12.i132, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 4
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load i64, ptr %RCX, align 8
  %52 = mul i64 %51, 8
  %53 = add i64 %50, %52
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i129 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #13
  store i64 %call.i.i129, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %47
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RCX, align 8
  %59 = load i32, ptr %ECX, align 4
  %60 = zext i32 %59 to i64
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i157 = trunc i64 %58 to i32
  %xor3.i.i = xor i32 %59, %conv.i.i157
  %conv.i27.i158 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i158, ptr %RCX, align 8
  %cf.i.i159 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i159, align 1
  %conv.i.i.i160 = trunc i32 %xor3.i.i to i8
  %62 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i160)
  %63 = and i8 %62, 1
  %conv.i28.i161 = xor i8 %63, 1
  %pf.i.i162 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i161, ptr %pf.i.i162, align 1
  %cmp.i.i.i163 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i163, i32 noundef %conv.i.i157, i32 noundef %59, i32 noundef %xor3.i.i) #13
  %conv3.i.i165 = zext i1 %call.i.i.i164 to i8
  %zf.i.i166 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i165, ptr %zf.i.i166, align 1
  %cmp.i19.i.i167 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i168 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i167, i32 noundef %conv.i.i157, i32 noundef %59, i32 noundef %xor3.i.i) #13
  %conv6.i.i169 = zext i1 %call1.i.i.i168 to i8
  %sf.i.i170 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i169, ptr %sf.i.i170, align 1
  %of.i.i171 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i171, align 1
  %af.i.i172 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i173 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i173, ptr %af.i.i172, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %55
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 3
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv.i12.i73 = zext i1 %call.i.i.i72 to i8
  %cf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i73, ptr %cf.i.i74, align 1
  %conv.i.i.i.i75 = trunc i32 %67 to i8
  %70 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i75)
  %71 = and i8 %70, 1
  %conv.i.i.i76 = xor i8 %71, 1
  %pf.i.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i76, ptr %pf.i.i.i77, align 1
  %af.i.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i78, align 1
  %cmp.i.i.i.i79 = icmp eq i32 %67, 0
  %call.i.i.i.i80 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i79, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv5.i.i.i81 = zext i1 %call.i.i.i.i80 to i8
  %zf.i.i.i82 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i81, ptr %zf.i.i.i82, align 1
  %cmp.i27.i.i.i83 = icmp slt i32 %67, 0
  %call1.i.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i83, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv8.i.i.i85 = zext i1 %call1.i.i.i.i84 to i8
  %sf.i.i.i86 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i85, ptr %sf.i.i.i86, align 1
  %xor.i28.i.i.i87 = lshr i32 %67, 31
  %call.i30.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %67, i32 noundef 0, i32 noundef %67) #13
  %conv11.i.i.i89 = zext i1 %call.i30.i.i.i88 to i8
  %of.i.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i89, ptr %of.i.i.i90, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %64
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RCX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  %zf.i115 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %77 = load i8, ptr %zf.i115, align 1
  %tobool.not.i116 = icmp eq i8 %77, 0
  %call3.i117 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i116) #14
  %dst.coerce.val.i118 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call3.i117, i64 %75, i64 %dst.coerce.val.i118
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %76, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %72
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 3
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RAX, align 8
  %82 = load i64, ptr %RCX, align 8
  %83 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %81, %82
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %81, %82
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %84 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %85 = and i8 %84, 1
  %conv.i.i.i6 = xor i8 %85, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %82, %81
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %86 = trunc i64 %xor1.i.i.i.i9 to i8
  %87 = lshr i8 %86, 4
  %conv2.i.i.i10 = and i8 %87, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %81, %82
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %81
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %81, i64 noundef %82, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %78
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 4
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RBP, align 8
  %92 = sub i64 %91, 112
  %93 = load i64, ptr %RAX, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i122 = call ptr @__remill_write_memory_64(ptr noundef %94, i64 noundef %92, i64 noundef %93) #13
  store ptr %call.i.i122, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %88
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 7
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %NEXT_PC, align 8
  %99 = add i64 %98, 12723
  %100 = load ptr, ptr %MEMORY, align 8
  %call.i.i128 = call i64 @__remill_read_memory_64(ptr noundef %100, i64 noundef %99) #13
  store i64 %call.i.i128, ptr %RAX, align 8
  store ptr %100, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %95
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 2
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RAX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %call.i.i123 = call i32 @__remill_read_memory_32(ptr noundef %105, i64 noundef %104) #13
  %conv.i.i124 = zext i32 %call.i.i123 to i64
  store i64 %conv.i.i124, ptr %RDX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %101
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 7
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %NEXT_PC, align 8
  %110 = add i64 %109, 12778
  %111 = load ptr, ptr %MEMORY, align 8
  %call.i.i127 = call i64 @__remill_read_memory_64(ptr noundef %111, i64 noundef %110) #13
  store i64 %call.i.i127, ptr %RAX, align 8
  store ptr %111, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %106
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %RAX, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %116, i64 noundef %115) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %118 = and i8 %117, 1
  %conv.i.i.i32 = xor i8 %118, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %119 = trunc i32 %xor1.i.i.i.i35 to i8
  %120 = lshr i8 %119, 4
  %conv2.i.i.i36 = and i8 %120, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %112
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %125 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %125, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %126 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %126, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %124, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %121
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 2
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i32, ptr %EDX, align 4
  %131 = zext i32 %130 to i64
  %132 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %131, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %132, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %127
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 3
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %RCX, align 8
  %137 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %136 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %138 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %138, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %139 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %140 = and i8 %139, 1
  %conv.i.i.i = xor i8 %140, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %141 = trunc i32 %xor1.i.i.i.i to i8
  %142 = lshr i8 %141, 4
  %conv2.i.i.i = and i8 %142, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %133
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 3
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %RCX, align 8
  %147 = load i32, ptr %EDX, align 4
  %148 = zext i32 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %conv.i.i110 = trunc i64 %146 to i32
  %sext.i = shl i64 %146, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %148, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %150 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i111 = icmp ult i64 %150, -4294967296
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv.i.i110, i32 noundef %147, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i112 to i8
  %cf.i.i113 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i113, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %151

151:                                              ; preds = %143
  %152 = load i64, ptr %NEXT_PC, align 8
  store i64 %152, ptr %PC, align 8
  %153 = add i64 %152, 3
  store i64 %153, ptr %NEXT_PC, align 8
  %154 = load i64, ptr %RCX, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  %conv.i.i133 = trunc i64 %154 to i32
  %and3.i.i = and i32 1, %conv.i.i133
  %conv.i22.i134 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i134, ptr %RCX, align 8
  %cf.i.i135 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i135, align 1
  %conv.i.i.i136 = trunc i32 %and3.i.i to i8
  %156 = and i8 %conv.i.i.i136, 1
  %conv.i23.i137 = xor i8 %156, 1
  %pf.i.i138 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i137, ptr %pf.i.i138, align 1
  %cmp.i.i.i139 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i140 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i139, i32 noundef %conv.i.i133, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i140 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i141, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i133, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i142 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i142, align 1
  %of.i.i143 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i143, align 1
  %af.i.i144 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i144, align 1
  store ptr %155, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %151
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 3
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load i32, ptr %ECX, align 4
  %161 = zext i32 %160 to i64
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %160 to i8
  %163 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %164 = and i8 %163, 1
  %conv.i.i.i57 = xor i8 %164, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %160, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %160, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %160, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %160, i32 noundef 0, i32 noundef %160) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %162, ptr %MEMORY, align 8
  br label %165

165:                                              ; preds = %157
  %166 = load i64, ptr %NEXT_PC, align 8
  store i64 %166, ptr %PC, align 8
  %167 = add i64 %166, 3
  store i64 %167, ptr %NEXT_PC, align 8
  %168 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %169 = load i8, ptr %zf.i, align 1
  store i8 %169, ptr %CL, align 1
  store ptr %168, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %165
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 2
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i8, ptr %AL, align 1
  %174 = zext i8 %173 to i64
  %175 = load i8, ptr %CL, align 1
  %176 = zext i8 %175 to i64
  %177 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %176, %174
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i145 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i145, align 1
  %178 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %179 = and i8 %178, 1
  %conv.i27.i = xor i8 %179, 1
  %pf.i.i146 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i146, align 1
  %180 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i147 = and i32 %180, 255
  %cmp.i.i.i148 = icmp eq i8 %or3.i.i, 0
  %181 = trunc i64 %174 to i32
  %conv1.i.i.i = and i32 %181, 255
  %182 = trunc i64 %176 to i32
  %conv2.i.i.i149 = and i32 %182, 255
  %call.i.i.i150 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i148, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i149, i32 noundef %conv.i.i.i147) #13
  %conv3.i.i151 = zext i1 %call.i.i.i150 to i8
  %zf.i.i152 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i151, ptr %zf.i.i152, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i149, i32 noundef %conv.i.i.i147) #13
  %conv6.i.i153 = zext i1 %call4.i.i.i to i8
  %sf.i.i154 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i153, ptr %sf.i.i154, align 1
  %of.i.i155 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i155, align 1
  %af.i.i156 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i156, align 1
  store ptr %177, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %170
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 2
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i8, ptr %AL, align 1
  %187 = zext i8 %186 to i64
  %188 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %187
  %and3.i.i174 = trunc i64 %and3.i15.i to i8
  %cf.i.i175 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i175, align 1
  %189 = and i8 %and3.i.i174, 1
  %conv.i14.i = xor i8 %189, 1
  %pf.i.i176 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i176, align 1
  %190 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i177 = and i32 %190, 255
  %cmp.i.i.i178 = icmp eq i8 %and3.i.i174, 0
  %191 = trunc i64 %187 to i32
  %conv1.i.i.i179 = and i32 %191, 255
  %call.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i178, i32 noundef %conv1.i.i.i179, i32 noundef 1, i32 noundef %conv.i.i.i177) #13
  %conv3.i.i181 = zext i1 %call.i.i.i180 to i8
  %zf.i.i182 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i181, ptr %zf.i.i182, align 1
  %call4.i.i.i183 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i179, i32 noundef 1, i32 noundef %conv.i.i.i177) #13
  %conv6.i.i184 = zext i1 %call4.i.i.i183 to i8
  %sf.i.i185 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i184, ptr %sf.i.i185, align 1
  %of.i.i186 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i186, align 1
  %af.i.i187 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i187, align 1
  store ptr %188, ptr %MEMORY, align 8
  br label %192

192:                                              ; preds = %183
  %193 = load i64, ptr %NEXT_PC, align 8
  store i64 %193, ptr %PC, align 8
  %194 = add i64 %193, 6
  store i64 %194, ptr %NEXT_PC, align 8
  %195 = load i64, ptr %NEXT_PC, align 8
  %196 = add i64 %195, 5
  %197 = load i64, ptr %NEXT_PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  %zf.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %199 = load i8, ptr %zf.i119, align 1
  %tobool.not.i120 = icmp eq i8 %199, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i120) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i121 = select i1 %call9.i, i64 %196, i64 %197
  store i64 %cond1.i.i121, ptr %NEXT_PC, align 8
  store ptr %198, ptr %MEMORY, align 8
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = load ptr, ptr %MEMORY, align 8
  ret ptr %201
}

define ptr @BB_2d06(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 96
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2dac(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 112
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2e50(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12209
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12544
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2db2(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12359
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12734
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2e86(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 -1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, -1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, -1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #13
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 12848
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #13
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 128
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #13
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 12105
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #13
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #13
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 12472
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #13
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #13
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #13
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #13
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #13
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_2de8(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i114 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i114, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i113 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #13
  store i64 %call.i.i113, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 40
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i112 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i112, ptr %RCX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RCX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i32 @__remill_read_memory_32(ptr noundef %23, i64 noundef %22) #13
  %conv.i.i108 = zext i32 %call.i.i107 to i64
  store i64 %conv.i.i108, ptr %RDX, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 2
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RSI, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i32 @__remill_read_memory_32(ptr noundef %28, i64 noundef %27) #13
  %conv.i.i106 = zext i32 %call.i.i105 to i64
  store i64 %conv.i.i106, ptr %RCX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i32, ptr %ECX, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i102 = and i64 %33, 4294967295
  store i64 %conv.i11.i102, ptr %RDI, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RDI, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %38 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RDI, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %40 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %40, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %41 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %42 = and i8 %41, 1
  %conv.i.i.i10 = xor i8 %42, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %43 = trunc i32 %xor1.i.i.i.i13 to i8
  %44 = lshr i8 %43, 4
  %conv2.i.i.i14 = and i8 %44, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %35
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 2
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RSI, align 8
  %49 = load i32, ptr %EDI, align 4
  %50 = zext i32 %49 to i64
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_32(ptr noundef %51, i64 noundef %48, i32 noundef %49) #13
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %45
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %ECX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %sext.i115 = shl i64 %56, 32
  %conv.i12.i116 = ashr exact i64 %sext.i115, 32
  store i64 %conv.i12.i116, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RAX, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = mul i64 %62, 4
  %64 = add i64 %61, %63
  %65 = load i32, ptr %EDX, align 4
  %66 = zext i32 %65 to i64
  %67 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %67, i64 noundef %64, i32 noundef %65) #13
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 7
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %NEXT_PC, align 8
  %72 = add i64 %71, 12980
  %73 = load ptr, ptr %MEMORY, align 8
  %call.i.i111 = call i64 @__remill_read_memory_64(ptr noundef %73, i64 noundef %72) #13
  store i64 %call.i.i111, ptr %RAX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 4
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RAX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  store i64 %77, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %77, i64 noundef 0, i64 noundef %77) #13
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %77 to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %80 = and i8 %79, 1
  %conv.i.i.i36 = xor i8 %80, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %77, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %77, i64 noundef 0, i64 noundef %77) #13
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %77, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %77, i64 noundef 0, i64 noundef %77) #13
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %77, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %77, i64 noundef 0, i64 noundef %77) #13
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %74
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 4
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RBP, align 8
  %85 = sub i64 %84, 120
  %86 = load i64, ptr %RAX, align 8
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call ptr @__remill_write_memory_64(ptr noundef %87, i64 noundef %85, i64 noundef %86) #13
  store ptr %call.i.i101, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %81
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 7
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %NEXT_PC, align 8
  %92 = add i64 %91, 12277
  %93 = load ptr, ptr %MEMORY, align 8
  %call.i.i110 = call i64 @__remill_read_memory_64(ptr noundef %93, i64 noundef %92) #13
  store i64 %call.i.i110, ptr %RAX, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 2
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i64, ptr %RAX, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %98, i64 noundef %97) #13
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RDX, align 8
  store ptr %98, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %94
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 7
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %NEXT_PC, align 8
  %103 = add i64 %102, 12628
  %104 = load ptr, ptr %MEMORY, align 8
  %call.i.i109 = call i64 @__remill_read_memory_64(ptr noundef %104, i64 noundef %103) #13
  store i64 %call.i.i109, ptr %RAX, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %99
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RAX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %109, i64 noundef %108) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %110 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %111 = and i8 %110, 1
  %conv.i.i.i55 = xor i8 %111, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %112 = trunc i32 %xor1.i.i.i.i58 to i8
  %113 = lshr i8 %112, 4
  %conv2.i.i.i59 = and i8 %113, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %105
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %118 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %118, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %119 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %119, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %114
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 2
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i32, ptr %EDX, align 4
  %124 = zext i32 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %124, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %125, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %120
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 3
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RCX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %129 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %131 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %131, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %132 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %133 = and i8 %132, 1
  %conv.i.i.i = xor i8 %133, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %134 = trunc i32 %xor1.i.i.i.i to i8
  %135 = lshr i8 %134, 4
  %conv2.i.i.i = and i8 %135, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %130, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %126
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 3
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %RCX, align 8
  %140 = load i32, ptr %EDX, align 4
  %141 = zext i32 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %139 to i32
  %sext.i = shl i64 %139, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %141, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %143 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %143, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %140, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %136
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 3
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i64, ptr %RCX, align 8
  %148 = load ptr, ptr %MEMORY, align 8
  %conv.i.i117 = trunc i64 %147 to i32
  %and3.i.i = and i32 1, %conv.i.i117
  %conv.i22.i118 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i118, ptr %RCX, align 8
  %cf.i.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i119, align 1
  %conv.i.i.i120 = trunc i32 %and3.i.i to i8
  %149 = and i8 %conv.i.i.i120, 1
  %conv.i23.i121 = xor i8 %149, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i121, ptr %pf.i.i122, align 1
  %cmp.i.i.i123 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i124 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i123, i32 noundef %conv.i.i117, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i124 to i8
  %zf.i.i125 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i125, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i117, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i126 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i126, align 1
  %of.i.i127 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i127, align 1
  %af.i.i128 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i128, align 1
  store ptr %148, ptr %MEMORY, align 8
  br label %150

150:                                              ; preds = %144
  %151 = load i64, ptr %NEXT_PC, align 8
  store i64 %151, ptr %PC, align 8
  %152 = add i64 %151, 3
  store i64 %152, ptr %NEXT_PC, align 8
  %153 = load i32, ptr %ECX, align 4
  %154 = zext i32 %153 to i64
  %155 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %153, i32 noundef 0, i32 noundef %153) #13
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %153 to i8
  %156 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %157 = and i8 %156, 1
  %conv.i.i.i79 = xor i8 %157, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %153, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %153, i32 noundef 0, i32 noundef %153) #13
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %153, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %153, i32 noundef 0, i32 noundef %153) #13
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %153, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %153, i32 noundef 0, i32 noundef %153) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %155, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %150
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 3
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %162 = load i8, ptr %zf.i, align 1
  store i8 %162, ptr %CL, align 1
  store ptr %161, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %158
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 2
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i8, ptr %AL, align 1
  %167 = zext i8 %166 to i64
  %168 = load i8, ptr %CL, align 1
  %169 = zext i8 %168 to i64
  %170 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %169, %167
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i129 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i129, align 1
  %171 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %172 = and i8 %171, 1
  %conv.i27.i = xor i8 %172, 1
  %pf.i.i130 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i130, align 1
  %173 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i131 = and i32 %173, 255
  %cmp.i.i.i132 = icmp eq i8 %or3.i.i, 0
  %174 = trunc i64 %167 to i32
  %conv1.i.i.i = and i32 %174, 255
  %175 = trunc i64 %169 to i32
  %conv2.i.i.i133 = and i32 %175, 255
  %call.i.i.i134 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i132, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i133, i32 noundef %conv.i.i.i131) #13
  %conv3.i.i135 = zext i1 %call.i.i.i134 to i8
  %zf.i.i136 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i135, ptr %zf.i.i136, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i133, i32 noundef %conv.i.i.i131) #13
  %conv6.i.i137 = zext i1 %call4.i.i.i to i8
  %sf.i.i138 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i137, ptr %sf.i.i138, align 1
  %of.i.i139 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i139, align 1
  %af.i.i140 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i140, align 1
  store ptr %170, ptr %MEMORY, align 8
  br label %176

176:                                              ; preds = %163
  %177 = load i64, ptr %NEXT_PC, align 8
  store i64 %177, ptr %PC, align 8
  %178 = add i64 %177, 2
  store i64 %178, ptr %NEXT_PC, align 8
  %179 = load i8, ptr %AL, align 1
  %180 = zext i8 %179 to i64
  %181 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %180
  %and3.i.i141 = trunc i64 %and3.i15.i to i8
  %cf.i.i142 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i142, align 1
  %182 = and i8 %and3.i.i141, 1
  %conv.i14.i = xor i8 %182, 1
  %pf.i.i143 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i143, align 1
  %183 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i144 = and i32 %183, 255
  %cmp.i.i.i145 = icmp eq i8 %and3.i.i141, 0
  %184 = trunc i64 %180 to i32
  %conv1.i.i.i146 = and i32 %184, 255
  %call.i.i.i147 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i145, i32 noundef %conv1.i.i.i146, i32 noundef 1, i32 noundef %conv.i.i.i144) #13
  %conv3.i.i148 = zext i1 %call.i.i.i147 to i8
  %zf.i.i149 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i148, ptr %zf.i.i149, align 1
  %call4.i.i.i150 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i146, i32 noundef 1, i32 noundef %conv.i.i.i144) #13
  %conv6.i.i151 = zext i1 %call4.i.i.i150 to i8
  %sf.i.i152 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i151, ptr %sf.i.i152, align 1
  %of.i.i153 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i153, align 1
  %af.i.i154 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i154, align 1
  store ptr %181, ptr %MEMORY, align 8
  br label %185

185:                                              ; preds = %176
  %186 = load i64, ptr %NEXT_PC, align 8
  store i64 %186, ptr %PC, align 8
  %187 = add i64 %186, 6
  store i64 %187, ptr %NEXT_PC, align 8
  %188 = load i64, ptr %NEXT_PC, align 8
  %189 = add i64 %188, 5
  %190 = load i64, ptr %NEXT_PC, align 8
  %191 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %192 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %192, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %189, i64 %190
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %191, ptr %MEMORY, align 8
  %193 = load i64, ptr %NEXT_PC, align 8
  store i64 %193, ptr %PC, align 8
  %194 = load ptr, ptr %MEMORY, align 8
  ret ptr %194
}

define ptr @BB_2ed6(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 128
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2e4a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 120
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2edc(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12053
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 12004
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2f12(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i136 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i136, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i131 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i132 = zext i32 %call.i.i131 to i64
  store i64 %conv.i.i132, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 5
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  store i64 9, ptr %RCX, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %12
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 8, ptr %RAX, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %16
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 3
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i32, ptr %EDX, align 4
  %24 = zext i32 %23 to i64
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv.i12.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i32 %23 to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %27 = and i8 %26, 1
  %conv.i.i.i95 = xor i8 %27, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %af.i.i.i97 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i97, align 1
  %cmp.i.i.i.i98 = icmp eq i32 %23, 0
  %call.i.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i98, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv5.i.i.i100 = zext i1 %call.i.i.i.i99 to i8
  %zf.i.i.i101 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i100, ptr %zf.i.i.i101, align 1
  %cmp.i27.i.i.i102 = icmp slt i32 %23, 0
  %call1.i.i.i.i103 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i102, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv8.i.i.i104 = zext i1 %call1.i.i.i.i103 to i8
  %sf.i.i.i105 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i104, ptr %sf.i.i.i105, align 1
  %xor.i28.i.i.i106 = lshr i32 %23, 31
  %call.i30.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %23, i32 noundef 0, i32 noundef %23) #13
  %conv11.i.i.i108 = zext i1 %call.i30.i.i.i107 to i8
  %of.i.i.i109 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i108, ptr %of.i.i.i109, align 1
  store ptr %25, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %20
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i32, ptr %EAX, align 4
  %32 = zext i32 %31 to i64
  %33 = load ptr, ptr %MEMORY, align 8
  %sf.i114 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %34 = load i8, ptr %sf.i114, align 1
  %tobool.i115 = icmp eq i8 %34, 0
  %of.i116 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %35 = load i8, ptr %of.i116, align 1
  %tobool4.i = icmp ne i8 %35, 0
  %cmp.i.i117 = xor i1 %tobool.i115, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_sge(i1 noundef zeroext %cmp.i.i117) #14
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %32, i64 %dst.coerce.val.i
  %conv.i23.i118 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i118, ptr %RCX, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %28
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 12641
  %41 = load ptr, ptr %MEMORY, align 8
  store i64 %40, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i32, ptr %ECX, align 4
  %46 = zext i32 %45 to i64
  %47 = load ptr, ptr %MEMORY, align 8
  %sext.i137 = shl i64 %46, 32
  %conv.i12.i138 = ashr exact i64 %sext.i137, 32
  store i64 %conv.i12.i138, ptr %RCX, align 8
  store ptr %47, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %42
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 4
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RAX, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = mul i64 %52, 8
  %54 = add i64 %51, %53
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i135 = call i64 @__remill_read_memory_64(ptr noundef %55, i64 noundef %54) #13
  store i64 %call.i.i135, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %48
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RCX, align 8
  %60 = load i32, ptr %ECX, align 4
  %61 = zext i32 %60 to i64
  %62 = load ptr, ptr %MEMORY, align 8
  %conv.i.i163 = trunc i64 %59 to i32
  %xor3.i.i = xor i32 %60, %conv.i.i163
  %conv.i27.i164 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i164, ptr %RCX, align 8
  %cf.i.i165 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i165, align 1
  %conv.i.i.i166 = trunc i32 %xor3.i.i to i8
  %63 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i166)
  %64 = and i8 %63, 1
  %conv.i28.i167 = xor i8 %64, 1
  %pf.i.i168 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i167, ptr %pf.i.i168, align 1
  %cmp.i.i.i169 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i170 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i169, i32 noundef %conv.i.i163, i32 noundef %60, i32 noundef %xor3.i.i) #13
  %conv3.i.i171 = zext i1 %call.i.i.i170 to i8
  %zf.i.i172 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i171, ptr %zf.i.i172, align 1
  %cmp.i19.i.i173 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i174 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i173, i32 noundef %conv.i.i163, i32 noundef %60, i32 noundef %xor3.i.i) #13
  %conv6.i.i175 = zext i1 %call1.i.i.i174 to i8
  %sf.i.i176 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i175, ptr %sf.i.i176, align 1
  %of.i.i177 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i177, align 1
  %af.i.i178 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i179 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i179, ptr %af.i.i178, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %56
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 3
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i32, ptr %EDX, align 4
  %69 = zext i32 %68 to i64
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %68, i32 noundef 0, i32 noundef %68) #13
  %conv.i12.i73 = zext i1 %call.i.i.i72 to i8
  %cf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i73, ptr %cf.i.i74, align 1
  %conv.i.i.i.i75 = trunc i32 %68 to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i75)
  %72 = and i8 %71, 1
  %conv.i.i.i76 = xor i8 %72, 1
  %pf.i.i.i77 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i76, ptr %pf.i.i.i77, align 1
  %af.i.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i78, align 1
  %cmp.i.i.i.i79 = icmp eq i32 %68, 0
  %call.i.i.i.i80 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i79, i32 noundef %68, i32 noundef 0, i32 noundef %68) #13
  %conv5.i.i.i81 = zext i1 %call.i.i.i.i80 to i8
  %zf.i.i.i82 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i81, ptr %zf.i.i.i82, align 1
  %cmp.i27.i.i.i83 = icmp slt i32 %68, 0
  %call1.i.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i83, i32 noundef %68, i32 noundef 0, i32 noundef %68) #13
  %conv8.i.i.i85 = zext i1 %call1.i.i.i.i84 to i8
  %sf.i.i.i86 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i85, ptr %sf.i.i.i86, align 1
  %xor.i28.i.i.i87 = lshr i32 %68, 31
  %call.i30.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %68, i32 noundef 0, i32 noundef %68) #13
  %conv11.i.i.i89 = zext i1 %call.i30.i.i.i88 to i8
  %of.i.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i89, ptr %of.i.i.i90, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %65
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 4
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RCX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %sf.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %78 = load i8, ptr %sf.i119, align 1
  %tobool.i120 = icmp eq i8 %78, 0
  %of.i121 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %79 = load i8, ptr %of.i121, align 1
  %tobool4.i122 = icmp ne i8 %79, 0
  %cmp.i.i123 = xor i1 %tobool.i120, %tobool4.i122
  %call5.i124 = call zeroext i1 @__remill_compare_sge(i1 noundef zeroext %cmp.i.i123) #14
  %dst.coerce.val.i125 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i124, i64 %76, i64 %dst.coerce.val.i125
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %73
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RAX, align 8
  %84 = load i64, ptr %RCX, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %83, %84
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %83, %84
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %83, i64 noundef %84, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %86 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %87 = and i8 %86, 1
  %conv.i.i.i6 = xor i8 %87, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %84, %83
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %88 = trunc i64 %xor1.i.i.i.i9 to i8
  %89 = lshr i8 %88, 4
  %conv2.i.i.i10 = and i8 %89, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %83, %84
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %83, i64 noundef %84, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %83, i64 noundef %84, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %83
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %83, i64 noundef %84, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %85, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %80
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 7
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load i64, ptr %RBP, align 8
  %94 = sub i64 %93, 136
  %95 = load i64, ptr %RAX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i128 = call ptr @__remill_write_memory_64(ptr noundef %96, i64 noundef %94, i64 noundef %95) #13
  store ptr %call.i.i128, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %90
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 7
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %NEXT_PC, align 8
  %101 = add i64 %100, 12376
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i134 = call i64 @__remill_read_memory_64(ptr noundef %102, i64 noundef %101) #13
  store i64 %call.i.i134, ptr %RAX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %97
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 2
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RAX, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  %call.i.i129 = call i32 @__remill_read_memory_32(ptr noundef %107, i64 noundef %106) #13
  %conv.i.i130 = zext i32 %call.i.i129 to i64
  store i64 %conv.i.i130, ptr %RDX, align 8
  store ptr %107, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %103
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 7
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i64, ptr %NEXT_PC, align 8
  %112 = add i64 %111, 11919
  %113 = load ptr, ptr %MEMORY, align 8
  %call.i.i133 = call i64 @__remill_read_memory_64(ptr noundef %113, i64 noundef %112) #13
  store i64 %call.i.i133, ptr %RAX, align 8
  store ptr %113, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %108
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RAX, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %118, i64 noundef %117) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %119 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %120 = and i8 %119, 1
  %conv.i.i.i32 = xor i8 %120, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %121 = trunc i32 %xor1.i.i.i.i35 to i8
  %122 = lshr i8 %121, 4
  %conv2.i.i.i36 = and i8 %122, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %118, ptr %MEMORY, align 8
  br label %123

123:                                              ; preds = %114
  %124 = load i64, ptr %NEXT_PC, align 8
  store i64 %124, ptr %PC, align 8
  %125 = add i64 %124, 3
  store i64 %125, ptr %NEXT_PC, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %127 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %127, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %128 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %128, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %126, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %123
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 2
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i32, ptr %EDX, align 4
  %133 = zext i32 %132 to i64
  %134 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %133, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %134, ptr %MEMORY, align 8
  br label %135

135:                                              ; preds = %129
  %136 = load i64, ptr %NEXT_PC, align 8
  store i64 %136, ptr %PC, align 8
  %137 = add i64 %136, 3
  store i64 %137, ptr %NEXT_PC, align 8
  %138 = load i64, ptr %RCX, align 8
  %139 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %138 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %140 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %140, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %141 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %142 = and i8 %141, 1
  %conv.i.i.i = xor i8 %142, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %143 = trunc i32 %xor1.i.i.i.i to i8
  %144 = lshr i8 %143, 4
  %conv2.i.i.i = and i8 %144, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %139, ptr %MEMORY, align 8
  br label %145

145:                                              ; preds = %135
  %146 = load i64, ptr %NEXT_PC, align 8
  store i64 %146, ptr %PC, align 8
  %147 = add i64 %146, 3
  store i64 %147, ptr %NEXT_PC, align 8
  %148 = load i64, ptr %RCX, align 8
  %149 = load i32, ptr %EDX, align 4
  %150 = zext i32 %149 to i64
  %151 = load ptr, ptr %MEMORY, align 8
  %conv.i.i110 = trunc i64 %148 to i32
  %sext.i = shl i64 %148, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %150, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %152 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i111 = icmp ult i64 %152, -4294967296
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv.i.i110, i32 noundef %149, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i112 to i8
  %cf.i.i113 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i113, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %151, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %145
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 3
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %RCX, align 8
  %157 = load ptr, ptr %MEMORY, align 8
  %conv.i.i139 = trunc i64 %156 to i32
  %and3.i.i = and i32 1, %conv.i.i139
  %conv.i22.i140 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i140, ptr %RCX, align 8
  %cf.i.i141 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i141, align 1
  %conv.i.i.i142 = trunc i32 %and3.i.i to i8
  %158 = and i8 %conv.i.i.i142, 1
  %conv.i23.i143 = xor i8 %158, 1
  %pf.i.i144 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i143, ptr %pf.i.i144, align 1
  %cmp.i.i.i145 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i146 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i145, i32 noundef %conv.i.i139, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i146 to i8
  %zf.i.i147 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i147, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i139, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i148 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i148, align 1
  %of.i.i149 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i149, align 1
  %af.i.i150 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i150, align 1
  store ptr %157, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %153
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 3
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i32, ptr %ECX, align 4
  %163 = zext i32 %162 to i64
  %164 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %162, i32 noundef 0, i32 noundef %162) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %162 to i8
  %165 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %166 = and i8 %165, 1
  %conv.i.i.i57 = xor i8 %166, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %162, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %162, i32 noundef 0, i32 noundef %162) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %162, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %162, i32 noundef 0, i32 noundef %162) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %162, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %162, i32 noundef 0, i32 noundef %162) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %164, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %159
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 3
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %171 = load i8, ptr %zf.i, align 1
  store i8 %171, ptr %CL, align 1
  store ptr %170, ptr %MEMORY, align 8
  br label %172

172:                                              ; preds = %167
  %173 = load i64, ptr %NEXT_PC, align 8
  store i64 %173, ptr %PC, align 8
  %174 = add i64 %173, 2
  store i64 %174, ptr %NEXT_PC, align 8
  %175 = load i8, ptr %AL, align 1
  %176 = zext i8 %175 to i64
  %177 = load i8, ptr %CL, align 1
  %178 = zext i8 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %178, %176
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i151 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i151, align 1
  %180 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %181 = and i8 %180, 1
  %conv.i27.i = xor i8 %181, 1
  %pf.i.i152 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i152, align 1
  %182 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i153 = and i32 %182, 255
  %cmp.i.i.i154 = icmp eq i8 %or3.i.i, 0
  %183 = trunc i64 %176 to i32
  %conv1.i.i.i = and i32 %183, 255
  %184 = trunc i64 %178 to i32
  %conv2.i.i.i155 = and i32 %184, 255
  %call.i.i.i156 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i154, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i155, i32 noundef %conv.i.i.i153) #13
  %conv3.i.i157 = zext i1 %call.i.i.i156 to i8
  %zf.i.i158 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i157, ptr %zf.i.i158, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i155, i32 noundef %conv.i.i.i153) #13
  %conv6.i.i159 = zext i1 %call4.i.i.i to i8
  %sf.i.i160 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i159, ptr %sf.i.i160, align 1
  %of.i.i161 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i161, align 1
  %af.i.i162 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i162, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %185

185:                                              ; preds = %172
  %186 = load i64, ptr %NEXT_PC, align 8
  store i64 %186, ptr %PC, align 8
  %187 = add i64 %186, 2
  store i64 %187, ptr %NEXT_PC, align 8
  %188 = load i8, ptr %AL, align 1
  %189 = zext i8 %188 to i64
  %190 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %189
  %and3.i.i180 = trunc i64 %and3.i15.i to i8
  %cf.i.i181 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i181, align 1
  %191 = and i8 %and3.i.i180, 1
  %conv.i14.i = xor i8 %191, 1
  %pf.i.i182 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i182, align 1
  %192 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i183 = and i32 %192, 255
  %cmp.i.i.i184 = icmp eq i8 %and3.i.i180, 0
  %193 = trunc i64 %189 to i32
  %conv1.i.i.i185 = and i32 %193, 255
  %call.i.i.i186 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i184, i32 noundef %conv1.i.i.i185, i32 noundef 1, i32 noundef %conv.i.i.i183) #13
  %conv3.i.i187 = zext i1 %call.i.i.i186 to i8
  %zf.i.i188 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i187, ptr %zf.i.i188, align 1
  %call4.i.i.i189 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i185, i32 noundef 1, i32 noundef %conv.i.i.i183) #13
  %conv6.i.i190 = zext i1 %call4.i.i.i189 to i8
  %sf.i.i191 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i190, ptr %sf.i.i191, align 1
  %of.i.i192 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i192, align 1
  %af.i.i193 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i193, align 1
  store ptr %190, ptr %MEMORY, align 8
  br label %194

194:                                              ; preds = %185
  %195 = load i64, ptr %NEXT_PC, align 8
  store i64 %195, ptr %PC, align 8
  %196 = add i64 %195, 6
  store i64 %196, ptr %NEXT_PC, align 8
  %197 = load i64, ptr %NEXT_PC, align 8
  %198 = add i64 %197, 5
  %199 = load i64, ptr %NEXT_PC, align 8
  %200 = load ptr, ptr %MEMORY, align 8
  %zf.i126 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %201 = load i8, ptr %zf.i126, align 1
  %tobool.not.i = icmp eq i8 %201, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i127 = select i1 %call9.i, i64 %198, i64 %199
  store i64 %cond1.i.i127, ptr %NEXT_PC, align 8
  store ptr %200, ptr %MEMORY, align 8
  %202 = load i64, ptr %NEXT_PC, align 8
  store i64 %202, ptr %PC, align 8
  %203 = load ptr, ptr %MEMORY, align 8
  ret ptr %203
}

define ptr @BB_2f7f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 136
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2f88(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12337
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11848
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_3032(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 12175
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11646
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2fbe(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i154 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i154, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #13
  store i64 %call.i.i153, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 48
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i152 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i152, ptr %RDI, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i124 = call i32 @__remill_read_memory_32(ptr noundef %23, i64 noundef %22) #13
  %conv.i24.i = sext i32 %call.i.i124 to i64
  %mul.i.i = mul nsw i64 10, %conv.i24.i
  %conv.i27.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i27.i, ptr %RCX, align 8
  %24 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i125 = icmp ult i64 %24, -4294967296
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i125, i32 noundef %call.i.i124, i32 noundef 10, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i126 to i8
  %cf.i.i127 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i127, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 2
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RDI, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i147 = call i32 @__remill_read_memory_32(ptr noundef %29, i64 noundef %28) #13
  %conv.i.i148 = zext i32 %call.i.i147 to i64
  store i64 %conv.i.i148, ptr %RSI, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %25
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i32, ptr %ESI, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i144 = and i64 %34, 4294967295
  store i64 %conv.i11.i144, ptr %R8, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %30
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 4
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %R8, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %39 to i32
  %add.i.i2 = add i32 -1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %R8, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, -1
  %41 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %41, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %43 = and i8 %42, 1
  %conv.i.i.i10 = xor i8 %43, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, -1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %44 = trunc i32 %xor1.i.i.i.i13 to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i14 = and i8 %45, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef -1, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %40, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %36
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %RDI, align 8
  %50 = load i32, ptr %R8D, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i142 = call ptr @__remill_write_memory_32(ptr noundef %52, i64 noundef %49, i32 noundef %50) #13
  store ptr %call.i.i142, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %46
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %ESI, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %sext.i155 = shl i64 %57, 32
  %conv.i12.i156 = ashr exact i64 %sext.i155, 32
  store i64 %conv.i12.i156, ptr %RSI, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load i64, ptr %RDX, align 8
  %64 = load i64, ptr %RSI, align 8
  %65 = mul i64 %64, 4
  %66 = add i64 %63, %65
  %67 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %62 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %67, i64 noundef %66) #13
  %add.i.i33 = add i32 %call.i.i, %conv.i.i32
  %conv.i18.i = zext i32 %add.i.i33 to i64
  store i64 %conv.i18.i, ptr %RCX, align 8
  %cmp.i.i.i34 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i35 = icmp ult i32 %add.i.i33, %call.i.i
  %68 = or i1 %cmp.i.i.i34, %cmp1.i.i.i35
  %call.i.i.i36 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %68, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %add.i.i33) #13
  %conv.i19.i = zext i1 %call.i.i.i36 to i8
  %cf.i.i37 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i37, align 1
  %conv.i.i.i.i38 = trunc i32 %add.i.i33 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i38)
  %70 = and i8 %69, 1
  %conv.i.i.i39 = xor i8 %70, 1
  %pf.i.i.i40 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i39, ptr %pf.i.i.i40, align 1
  %xor.i.i.i.i41 = xor i32 %add.i.i33, %call.i.i
  %xor1.i.i.i.i42 = xor i32 %xor.i.i.i.i41, %conv.i.i32
  %71 = trunc i32 %xor1.i.i.i.i42 to i8
  %72 = lshr i8 %71, 4
  %conv2.i.i.i43 = and i8 %72, 1
  %af.i.i.i44 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i43, ptr %af.i.i.i44, align 1
  %cmp.i.i.i.i45 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i45, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %add.i.i33) #13
  %conv5.i.i.i47 = zext i1 %call.i.i.i.i46 to i8
  %zf.i.i.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i47, ptr %zf.i.i.i48, align 1
  %cmp.i27.i.i.i49 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i50 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i49, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %add.i.i33) #13
  %conv8.i.i.i51 = zext i1 %call1.i.i.i.i50 to i8
  %sf.i.i.i52 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i51, ptr %sf.i.i.i52, align 1
  %shr8.i.i.i.i53 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i54 = lshr i32 %shr8.i.i.i.i53, 31
  %xor3.i.i.i.i55 = lshr i32 %xor.i.i.i.i41, 31
  %add.i.i.i.i56 = add nuw nsw i32 %xor.i28.i.i.i54, %xor3.i.i.i.i55
  %cmp.i29.i.i.i57 = icmp eq i32 %add.i.i.i.i56, 2
  %call.i30.i.i.i58 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i57, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %add.i.i33) #13
  %conv11.i.i.i59 = zext i1 %call.i30.i.i.i58 to i8
  %of.i.i.i60 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i59, ptr %of.i.i.i60, align 1
  store ptr %67, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %59
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 2
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load i32, ptr %ECX, align 4
  %78 = zext i32 %77 to i64
  %79 = load ptr, ptr %MEMORY, align 8
  %call.i.i141 = call ptr @__remill_write_memory_32(ptr noundef %79, i64 noundef %76, i32 noundef %77) #13
  store ptr %call.i.i141, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %73
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 7
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %NEXT_PC, align 8
  %84 = add i64 %83, 12512
  %85 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i64 @__remill_read_memory_64(ptr noundef %85, i64 noundef %84) #13
  store i64 %call.i.i151, ptr %RAX, align 8
  store ptr %85, ptr %MEMORY, align 8
  br label %86

86:                                               ; preds = %80
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = add i64 %87, 4
  store i64 %88, ptr %NEXT_PC, align 8
  %89 = load i64, ptr %RAX, align 8
  %90 = load ptr, ptr %MEMORY, align 8
  store i64 %89, ptr %RAX, align 8
  %call.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %89, i64 noundef 0, i64 noundef %89) #13
  %conv.i.i62 = zext i1 %call.i.i.i61 to i8
  %cf.i.i63 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i62, ptr %cf.i.i63, align 1
  %conv.i.i.i.i64 = trunc i64 %89 to i8
  %91 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i64)
  %92 = and i8 %91, 1
  %conv.i.i.i65 = xor i8 %92, 1
  %pf.i.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i65, ptr %pf.i.i.i66, align 1
  %af.i.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i67, align 1
  %cmp.i.i.i.i68 = icmp eq i64 %89, 0
  %call.i.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i68, i64 noundef %89, i64 noundef 0, i64 noundef %89) #13
  %conv5.i.i.i70 = zext i1 %call.i.i.i.i69 to i8
  %zf.i.i.i71 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i70, ptr %zf.i.i.i71, align 1
  %cmp.i27.i.i.i72 = icmp slt i64 %89, 0
  %call1.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i72, i64 noundef %89, i64 noundef 0, i64 noundef %89) #13
  %conv8.i.i.i74 = zext i1 %call1.i.i.i.i73 to i8
  %sf.i.i.i75 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i74, ptr %sf.i.i.i75, align 1
  %xor.i28.i.i.i76 = lshr i64 %89, 63
  %call.i30.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %89, i64 noundef 0, i64 noundef %89) #13
  %conv11.i.i.i78 = zext i1 %call.i30.i.i.i77 to i8
  %of.i.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i78, ptr %of.i.i.i79, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %86
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 7
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RBP, align 8
  %97 = sub i64 %96, 144
  %98 = load i64, ptr %RAX, align 8
  %99 = load ptr, ptr %MEMORY, align 8
  %call.i.i143 = call ptr @__remill_write_memory_64(ptr noundef %99, i64 noundef %97, i64 noundef %98) #13
  store ptr %call.i.i143, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %93
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 7
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = add i64 %103, 12214
  %105 = load ptr, ptr %MEMORY, align 8
  %call.i.i150 = call i64 @__remill_read_memory_64(ptr noundef %105, i64 noundef %104) #13
  store i64 %call.i.i150, ptr %RAX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %100
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 2
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RAX, align 8
  %110 = load ptr, ptr %MEMORY, align 8
  %call.i.i145 = call i32 @__remill_read_memory_32(ptr noundef %110, i64 noundef %109) #13
  %conv.i.i146 = zext i32 %call.i.i145 to i64
  store i64 %conv.i.i146, ptr %RDX, align 8
  store ptr %110, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %106
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 7
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i64, ptr %NEXT_PC, align 8
  %115 = add i64 %114, 11701
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i64 @__remill_read_memory_64(ptr noundef %116, i64 noundef %115) #13
  store i64 %call.i.i149, ptr %RAX, align 8
  store ptr %116, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %111
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 3
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %RAX, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call i32 @__remill_read_memory_32(ptr noundef %121, i64 noundef %120) #13
  %sub.i.i = sub i32 %call.i.i80, 10
  %cmp.i.i.i81 = icmp ult i32 %call.i.i80, 10
  %call.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %call.i.i80, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i82 to i8
  %cf.i.i83 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i83, align 1
  %conv.i.i.i.i84 = trunc i32 %sub.i.i to i8
  %122 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i84)
  %123 = and i8 %122, 1
  %conv.i.i.i85 = xor i8 %123, 1
  %pf.i.i.i86 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i85, ptr %pf.i.i.i86, align 1
  %xor.i.i.i.i87 = xor i32 %call.i.i80, 10
  %xor1.i.i.i.i88 = xor i32 %xor.i.i.i.i87, %sub.i.i
  %124 = trunc i32 %xor1.i.i.i.i88 to i8
  %125 = lshr i8 %124, 4
  %conv2.i.i.i89 = and i8 %125, 1
  %af.i.i.i90 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i89, ptr %af.i.i.i90, align 1
  %cmp.i.i.i.i91 = icmp eq i32 %call.i.i80, 10
  %call.i.i.i.i92 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i91, i32 noundef %call.i.i80, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i93 = zext i1 %call.i.i.i.i92 to i8
  %zf.i.i.i94 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i93, ptr %zf.i.i.i94, align 1
  %cmp.i27.i.i.i95 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i95, i32 noundef %call.i.i80, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i97 = zext i1 %call1.i.i.i.i96 to i8
  %sf.i.i.i98 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i97, ptr %sf.i.i.i98, align 1
  %xor.i28.i.i.i99 = lshr i32 %xor.i.i.i.i87, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i80
  %xor3.i.i.i.i100 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i101 = add nuw nsw i32 %xor3.i.i.i.i100, %xor.i28.i.i.i99
  %cmp.i29.i.i.i102 = icmp eq i32 %add.i.i.i.i101, 2
  %call.i30.i.i.i103 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i102, i32 noundef %call.i.i80, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i104 = zext i1 %call.i30.i.i.i103 to i8
  %of.i.i.i105 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i104, ptr %of.i.i.i105, align 1
  store ptr %121, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %117
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 3
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %130 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %130, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %131 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %131, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %132

132:                                              ; preds = %126
  %133 = load i64, ptr %NEXT_PC, align 8
  store i64 %133, ptr %PC, align 8
  %134 = add i64 %133, 2
  store i64 %134, ptr %NEXT_PC, align 8
  %135 = load i32, ptr %EDX, align 4
  %136 = zext i32 %135 to i64
  %137 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %136, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %137, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %132
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 3
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i64, ptr %RCX, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %141 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %143 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %143, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %144 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %145 = and i8 %144, 1
  %conv.i.i.i = xor i8 %145, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %146 = trunc i32 %xor1.i.i.i.i to i8
  %147 = lshr i8 %146, 4
  %conv2.i.i.i = and i8 %147, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %138
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RCX, align 8
  %152 = load i32, ptr %EDX, align 4
  %153 = zext i32 %152 to i64
  %154 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %151 to i32
  %sext.i = shl i64 %151, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %153, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i129 = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i129, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %155 = add nsw i64 %mul.i.i129, -2147483648
  %cmp.i.i.i130 = icmp ult i64 %155, -4294967296
  %call.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i130, i32 noundef %conv.i.i128, i32 noundef %152, i64 noundef %mul.i.i129) #13
  %frombool.i.i132 = zext i1 %call.i.i.i131 to i8
  %cf.i.i133 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i132, ptr %cf.i.i133, align 1
  %call1.i.i134 = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i135 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i134, ptr %pf.i.i135, align 1
  %af.i.i136 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i134, ptr %af.i.i136, align 1
  %zf.i.i137 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i134, ptr %zf.i.i137, align 1
  %sf.i.i138 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i134, ptr %sf.i.i138, align 1
  %of.i.i139 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i132, ptr %of.i.i139, align 1
  store ptr %154, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %148
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 3
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load i64, ptr %RCX, align 8
  %160 = load ptr, ptr %MEMORY, align 8
  %conv.i.i157 = trunc i64 %159 to i32
  %and3.i.i = and i32 1, %conv.i.i157
  %conv.i22.i158 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i158, ptr %RCX, align 8
  %cf.i.i159 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i159, align 1
  %conv.i.i.i160 = trunc i32 %and3.i.i to i8
  %161 = and i8 %conv.i.i.i160, 1
  %conv.i23.i161 = xor i8 %161, 1
  %pf.i.i162 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i161, ptr %pf.i.i162, align 1
  %cmp.i.i.i163 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i163, i32 noundef %conv.i.i157, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i164 to i8
  %zf.i.i165 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i165, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i157, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i166 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i166, align 1
  %of.i.i167 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i167, align 1
  %af.i.i168 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i168, align 1
  store ptr %160, ptr %MEMORY, align 8
  br label %162

162:                                              ; preds = %156
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = add i64 %163, 3
  store i64 %164, ptr %NEXT_PC, align 8
  %165 = load i32, ptr %ECX, align 4
  %166 = zext i32 %165 to i64
  %167 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %165, i32 noundef 0, i32 noundef %165) #13
  %conv.i12.i = zext i1 %call.i.i.i106 to i8
  %cf.i.i107 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i107, align 1
  %conv.i.i.i.i108 = trunc i32 %165 to i8
  %168 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i108)
  %169 = and i8 %168, 1
  %conv.i.i.i109 = xor i8 %169, 1
  %pf.i.i.i110 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i109, ptr %pf.i.i.i110, align 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %165, 0
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %165, i32 noundef 0, i32 noundef %165) #13
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %165, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %165, i32 noundef 0, i32 noundef %165) #13
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %165, 31
  %call.i30.i.i.i121 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %165, i32 noundef 0, i32 noundef %165) #13
  %conv11.i.i.i122 = zext i1 %call.i30.i.i.i121 to i8
  %of.i.i.i123 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i122, ptr %of.i.i.i123, align 1
  store ptr %167, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %162
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 3
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %174 = load i8, ptr %zf.i, align 1
  store i8 %174, ptr %CL, align 1
  store ptr %173, ptr %MEMORY, align 8
  br label %175

175:                                              ; preds = %170
  %176 = load i64, ptr %NEXT_PC, align 8
  store i64 %176, ptr %PC, align 8
  %177 = add i64 %176, 2
  store i64 %177, ptr %NEXT_PC, align 8
  %178 = load i8, ptr %AL, align 1
  %179 = zext i8 %178 to i64
  %180 = load i8, ptr %CL, align 1
  %181 = zext i8 %180 to i64
  %182 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %181, %179
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i169 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i169, align 1
  %183 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %184 = and i8 %183, 1
  %conv.i27.i170 = xor i8 %184, 1
  %pf.i.i171 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i170, ptr %pf.i.i171, align 1
  %185 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i172 = and i32 %185, 255
  %cmp.i.i.i173 = icmp eq i8 %or3.i.i, 0
  %186 = trunc i64 %179 to i32
  %conv1.i.i.i = and i32 %186, 255
  %187 = trunc i64 %181 to i32
  %conv2.i.i.i174 = and i32 %187, 255
  %call.i.i.i175 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i173, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i174, i32 noundef %conv.i.i.i172) #13
  %conv3.i.i176 = zext i1 %call.i.i.i175 to i8
  %zf.i.i177 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i176, ptr %zf.i.i177, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i174, i32 noundef %conv.i.i.i172) #13
  %conv6.i.i178 = zext i1 %call4.i.i.i to i8
  %sf.i.i179 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i178, ptr %sf.i.i179, align 1
  %of.i.i180 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i180, align 1
  %af.i.i181 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i181, align 1
  store ptr %182, ptr %MEMORY, align 8
  br label %188

188:                                              ; preds = %175
  %189 = load i64, ptr %NEXT_PC, align 8
  store i64 %189, ptr %PC, align 8
  %190 = add i64 %189, 2
  store i64 %190, ptr %NEXT_PC, align 8
  %191 = load i8, ptr %AL, align 1
  %192 = zext i8 %191 to i64
  %193 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %192
  %and3.i.i182 = trunc i64 %and3.i15.i to i8
  %cf.i.i183 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i183, align 1
  %194 = and i8 %and3.i.i182, 1
  %conv.i14.i = xor i8 %194, 1
  %pf.i.i184 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i184, align 1
  %195 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i185 = and i32 %195, 255
  %cmp.i.i.i186 = icmp eq i8 %and3.i.i182, 0
  %196 = trunc i64 %192 to i32
  %conv1.i.i.i187 = and i32 %196, 255
  %call.i.i.i188 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i186, i32 noundef %conv1.i.i.i187, i32 noundef 1, i32 noundef %conv.i.i.i185) #13
  %conv3.i.i189 = zext i1 %call.i.i.i188 to i8
  %zf.i.i190 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i189, ptr %zf.i.i190, align 1
  %call4.i.i.i191 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i187, i32 noundef 1, i32 noundef %conv.i.i.i185) #13
  %conv6.i.i192 = zext i1 %call4.i.i.i191 to i8
  %sf.i.i193 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i192, ptr %sf.i.i193, align 1
  %of.i.i194 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i194, align 1
  %af.i.i195 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i195, align 1
  store ptr %193, ptr %MEMORY, align 8
  br label %197

197:                                              ; preds = %188
  %198 = load i64, ptr %NEXT_PC, align 8
  store i64 %198, ptr %PC, align 8
  %199 = add i64 %198, 6
  store i64 %199, ptr %NEXT_PC, align 8
  %200 = load i64, ptr %NEXT_PC, align 8
  %201 = add i64 %200, 5
  %202 = load i64, ptr %NEXT_PC, align 8
  %203 = load ptr, ptr %MEMORY, align 8
  %zf.i140 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %204 = load i8, ptr %zf.i140, align 1
  %tobool.not.i = icmp eq i8 %204, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %201, i64 %202
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %203, ptr %MEMORY, align 8
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = load ptr, ptr %MEMORY, align 8
  ret ptr %206
}

define ptr @BB_3068(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i56 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i56, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i53 = zext i32 %call.i.i52 to i64
  store i64 %conv.i.i53, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 6
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 148
  %17 = load i32, ptr %EAX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_32(ptr noundef %19, i64 noundef %16, i32 noundef %17) #13
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %12
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 7
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = add i64 %23, 12117
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i55 = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %24) #13
  store i64 %call.i.i55, ptr %RAX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RAX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #13
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 11532
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %36, i64 noundef %35) #13
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %41, i64 noundef %40) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %43 = and i8 %42, 1
  %conv.i.i.i5 = xor i8 %43, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %44 = trunc i32 %xor1.i.i.i.i8 to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i9 = and i8 %45, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %41, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %37
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  %50 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %50, 0
  %of.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  %51 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %51, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EDX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %56, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RCX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %61 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %63 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %63, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %64 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %65 = and i8 %64, 1
  %conv.i.i.i = xor i8 %65, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %66 = trunc i32 %xor1.i.i.i.i to i8
  %67 = lshr i8 %66, 4
  %conv2.i.i.i = and i8 %67, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RCX, align 8
  %72 = load i32, ptr %EDX, align 4
  %73 = zext i32 %72 to i64
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %71 to i32
  %sext.i = shl i64 %71, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %73, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %75 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %75, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %72, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %68
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %conv.i.i57 = trunc i64 %79 to i32
  %and3.i.i = and i32 1, %conv.i.i57
  %conv.i22.i58 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i58, ptr %RCX, align 8
  %cf.i.i59 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i59, align 1
  %conv.i.i.i60 = trunc i32 %and3.i.i to i8
  %81 = and i8 %conv.i.i.i60, 1
  %conv.i23.i61 = xor i8 %81, 1
  %pf.i.i62 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i61, ptr %pf.i.i62, align 1
  %cmp.i.i.i63 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i63, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i64 to i8
  %zf.i.i65 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i65, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i66 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i66, align 1
  %of.i.i67 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i67, align 1
  %af.i.i68 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i68, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %85 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %89 = and i8 %88, 1
  %conv.i.i.i29 = xor i8 %89, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %85, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %85, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %85, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %82
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 3
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %94 = load i8, ptr %zf.i, align 1
  store i8 %94, ptr %CL, align 1
  store ptr %93, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %90
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i8, ptr %AL, align 1
  %99 = zext i8 %98 to i64
  %100 = load i8, ptr %CL, align 1
  %101 = zext i8 %100 to i64
  %102 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %101, %99
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i69 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i69, align 1
  %103 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %104 = and i8 %103, 1
  %conv.i27.i = xor i8 %104, 1
  %pf.i.i70 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i70, align 1
  %105 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i71 = and i32 %105, 255
  %cmp.i.i.i72 = icmp eq i8 %or3.i.i, 0
  %106 = trunc i64 %99 to i32
  %conv1.i.i.i = and i32 %106, 255
  %107 = trunc i64 %101 to i32
  %conv2.i.i.i73 = and i32 %107, 255
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i72, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #13
  %conv3.i.i75 = zext i1 %call.i.i.i74 to i8
  %zf.i.i76 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i75, ptr %zf.i.i76, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #13
  %conv6.i.i77 = zext i1 %call4.i.i.i to i8
  %sf.i.i78 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i77, ptr %sf.i.i78, align 1
  %of.i.i79 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i79, align 1
  %af.i.i80 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i80, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %95
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 2
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i8, ptr %AL, align 1
  %112 = zext i8 %111 to i64
  %113 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %112
  %and3.i.i81 = trunc i64 %and3.i15.i to i8
  %cf.i.i82 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i82, align 1
  %114 = and i8 %and3.i.i81, 1
  %conv.i14.i = xor i8 %114, 1
  %pf.i.i83 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i83, align 1
  %115 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i84 = and i32 %115, 255
  %cmp.i.i.i85 = icmp eq i8 %and3.i.i81, 0
  %116 = trunc i64 %112 to i32
  %conv1.i.i.i86 = and i32 %116, 255
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i85, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #13
  %conv3.i.i88 = zext i1 %call.i.i.i87 to i8
  %zf.i.i89 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i88, ptr %zf.i.i89, align 1
  %call4.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #13
  %conv6.i.i91 = zext i1 %call4.i.i.i90 to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i91, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i94, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %108
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 6
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  %121 = add i64 %120, 5
  %122 = load i64, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %124, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %121, i64 %122
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %123, ptr %MEMORY, align 8
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  ret ptr %126
}

define ptr @BB_3029(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 144
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_30aa(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.177478, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 6
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 148
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %16, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %12
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #13
  %rip.i = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %22, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %20, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.177478, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.177478) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #16
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.177478) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 10608, label %bb_2970
    i64 10679, label %bb_29B7
    i64 10862, label %bb_2A6E
    i64 10868, label %bb_2A74
    i64 10922, label %bb_2AAA
    i64 11028, label %bb_2B14
    i64 11039, label %bb_2B1F
    i64 11062, label %bb_2B36
    i64 11122, label %bb_2B72
    i64 11225, label %bb_2BD9
    i64 11231, label %bb_2BDF
    i64 11285, label %bb_2C15
    i64 11526, label %bb_2D06
    i64 11532, label %bb_2D0C
    i64 11586, label %bb_2D42
    i64 11692, label %bb_2DAC
    i64 11698, label %bb_2DB2
    i64 11752, label %bb_2DE8
    i64 11850, label %bb_2E4A
    i64 11856, label %bb_2E50
    i64 11910, label %bb_2E86
    i64 11990, label %bb_2ED6
    i64 11996, label %bb_2EDC
    i64 12050, label %bb_2F12
    i64 12159, label %bb_2F7F
    i64 12168, label %bb_2F88
    i64 12222, label %bb_2FBE
    i64 12329, label %bb_3029
    i64 12338, label %bb_3032
    i64 12392, label %bb_3068
    i64 12458, label %bb_30AA
  ]

dead_end:                                         ; preds = %bb_3068, %bb_3032, %bb_3029, %bb_2FBE, %bb_2F88, %bb_2F7F, %bb_2F12, %bb_2EDC, %bb_2ED6, %bb_2E86, %bb_2E50, %bb_2E4A, %bb_2DE8, %bb_2DB2, %bb_2DAC, %bb_2D42, %bb_2D0C, %bb_2D06, %bb_2C15, %bb_2BDF, %bb_2BD9, %bb_2B72, %bb_2B36, %bb_2B1F, %bb_2B14, %bb_2AAA, %bb_2A74, %bb_2A6E, %bb_29B7, %bb_2970, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_2970:                                          ; preds = %entry
  %block_pc = add i64 10608, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 10608, ptr %1)
  %4 = call ptr @BB_2970(ptr %state, i64 %2, ptr %1) #17
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 10679, label %bb_29B7
  ]

bb_29B7:                                          ; preds = %bb_2970, %entry
  %block_pc1 = add i64 10679, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 10679, ptr %6)
  %9 = call ptr @BB_29b7(ptr %state, i64 %7, ptr %6) #17
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 10862, label %bb_2A6E
  ]

bb_2A6E:                                          ; preds = %bb_29B7, %entry
  %block_pc3 = add i64 10862, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 10862, ptr %11)
  %14 = call ptr @BB_2a6e(ptr %state, i64 %12, ptr %11) #17
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 10868, label %bb_2A74
  ]

bb_2A74:                                          ; preds = %bb_2D06, %bb_2A6E, %entry
  %block_pc5 = add i64 10868, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 10868, ptr %16)
  %19 = call ptr @BB_2a74(ptr %state, i64 %17, ptr %16) #17
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 10922, label %bb_2AAA
  ]

bb_2AAA:                                          ; preds = %bb_2A74, %entry
  %block_pc7 = add i64 10922, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 10922, ptr %21)
  %24 = call ptr @BB_2aaa(ptr %state, i64 %22, ptr %21) #17
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 11028, label %bb_2B14
  ]

bb_2B14:                                          ; preds = %bb_2AAA, %entry
  %block_pc9 = add i64 11028, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 11028, ptr %26)
  %29 = call ptr @BB_2b14(ptr %state, i64 %27, ptr %26) #17
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 11039, label %bb_2B1F
    i64 11062, label %bb_2B36
  ]

bb_2B1F:                                          ; preds = %bb_2B14, %entry
  %block_pc11 = add i64 11039, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 11039, ptr %31)
  %34 = call ptr @BB_2b1f(ptr %state, i64 %32, ptr %31) #17
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 11062, label %bb_2B36
  ]

bb_2B36:                                          ; preds = %bb_2B1F, %bb_2B14, %entry
  %block_pc13 = add i64 11062, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 11062, ptr %36)
  %39 = call ptr @BB_2b36(ptr %state, i64 %37, ptr %36) #17
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 11122, label %bb_2B72
  ]

bb_2B72:                                          ; preds = %bb_2B36, %entry
  %block_pc15 = add i64 11122, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 11122, ptr %41)
  %44 = call ptr @BB_2b72(ptr %state, i64 %42, ptr %41) #17
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 11225, label %bb_2BD9
  ]

bb_2BD9:                                          ; preds = %bb_2B72, %entry
  %block_pc17 = add i64 11225, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 11225, ptr %46)
  %49 = call ptr @BB_2bd9(ptr %state, i64 %47, ptr %46) #17
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 11231, label %bb_2BDF
    i64 11532, label %bb_2D0C
  ]

bb_2BDF:                                          ; preds = %bb_2BD9, %entry
  %block_pc19 = add i64 11231, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 11231, ptr %51)
  %54 = call ptr @BB_2bdf(ptr %state, i64 %52, ptr %51) #17
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 11285, label %bb_2C15
  ]

bb_2C15:                                          ; preds = %bb_2BDF, %entry
  %block_pc21 = add i64 11285, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 11285, ptr %56)
  %59 = call ptr @BB_2c15(ptr %state, i64 %57, ptr %56) #17
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 11526, label %bb_2D06
  ]

bb_2D06:                                          ; preds = %bb_2C15, %entry
  %block_pc23 = add i64 11526, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 11526, ptr %61)
  %64 = call ptr @BB_2d06(ptr %state, i64 %62, ptr %61) #17
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 10868, label %bb_2A74
  ]

bb_2D0C:                                          ; preds = %bb_2BD9, %entry
  %block_pc25 = add i64 11532, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 11532, ptr %66)
  %69 = call ptr @BB_2d0c(ptr %state, i64 %67, ptr %66) #17
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 11586, label %bb_2D42
  ]

bb_2D42:                                          ; preds = %bb_2D0C, %entry
  %block_pc27 = add i64 11586, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 11586, ptr %71)
  %74 = call ptr @BB_2d42(ptr %state, i64 %72, ptr %71) #17
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 11692, label %bb_2DAC
  ]

bb_2DAC:                                          ; preds = %bb_2D42, %entry
  %block_pc29 = add i64 11692, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 11692, ptr %76)
  %79 = call ptr @BB_2dac(ptr %state, i64 %77, ptr %76) #17
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 11698, label %bb_2DB2
    i64 11856, label %bb_2E50
  ]

bb_2DB2:                                          ; preds = %bb_2DAC, %entry
  %block_pc31 = add i64 11698, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 11698, ptr %81)
  %84 = call ptr @BB_2db2(ptr %state, i64 %82, ptr %81) #17
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 11752, label %bb_2DE8
  ]

bb_2DE8:                                          ; preds = %bb_2DB2, %entry
  %block_pc33 = add i64 11752, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 11752, ptr %86)
  %89 = call ptr @BB_2de8(ptr %state, i64 %87, ptr %86) #17
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  switch i64 %next_rva34, label %dead_end [
    i64 11850, label %bb_2E4A
  ]

bb_2E4A:                                          ; preds = %bb_2DE8, %entry
  %block_pc35 = add i64 11850, %base
  store i64 %block_pc35, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc35)
  %91 = load ptr, ptr %mem_var, align 8
  %92 = load i64, ptr %pc_var, align 4
  %93 = call ptr @__lifted_bb_entered(ptr %state, i64 11850, ptr %91)
  %94 = call ptr @BB_2e4a(ptr %state, i64 %92, ptr %91) #17
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva36 = sub i64 %95, %base
  switch i64 %next_rva36, label %dead_end [
    i64 11856, label %bb_2E50
  ]

bb_2E50:                                          ; preds = %bb_2E4A, %bb_2DAC, %entry
  %block_pc37 = add i64 11856, %base
  store i64 %block_pc37, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc37)
  %96 = load ptr, ptr %mem_var, align 8
  %97 = load i64, ptr %pc_var, align 4
  %98 = call ptr @__lifted_bb_entered(ptr %state, i64 11856, ptr %96)
  %99 = call ptr @BB_2e50(ptr %state, i64 %97, ptr %96) #17
  store ptr %99, ptr %mem_var, align 8
  %100 = call i64 @__extract_rip(ptr %state)
  store i64 %100, ptr %pc_var, align 4
  %next_rva38 = sub i64 %100, %base
  switch i64 %next_rva38, label %dead_end [
    i64 11910, label %bb_2E86
  ]

bb_2E86:                                          ; preds = %bb_2E50, %entry
  %block_pc39 = add i64 11910, %base
  store i64 %block_pc39, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc39)
  %101 = load ptr, ptr %mem_var, align 8
  %102 = load i64, ptr %pc_var, align 4
  %103 = call ptr @__lifted_bb_entered(ptr %state, i64 11910, ptr %101)
  %104 = call ptr @BB_2e86(ptr %state, i64 %102, ptr %101) #17
  store ptr %104, ptr %mem_var, align 8
  %105 = call i64 @__extract_rip(ptr %state)
  store i64 %105, ptr %pc_var, align 4
  %next_rva40 = sub i64 %105, %base
  switch i64 %next_rva40, label %dead_end [
    i64 11990, label %bb_2ED6
  ]

bb_2ED6:                                          ; preds = %bb_2E86, %entry
  %block_pc41 = add i64 11990, %base
  store i64 %block_pc41, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc41)
  %106 = load ptr, ptr %mem_var, align 8
  %107 = load i64, ptr %pc_var, align 4
  %108 = call ptr @__lifted_bb_entered(ptr %state, i64 11990, ptr %106)
  %109 = call ptr @BB_2ed6(ptr %state, i64 %107, ptr %106) #17
  store ptr %109, ptr %mem_var, align 8
  %110 = call i64 @__extract_rip(ptr %state)
  store i64 %110, ptr %pc_var, align 4
  %next_rva42 = sub i64 %110, %base
  switch i64 %next_rva42, label %dead_end [
    i64 11996, label %bb_2EDC
  ]

bb_2EDC:                                          ; preds = %bb_3029, %bb_2ED6, %entry
  %block_pc43 = add i64 11996, %base
  store i64 %block_pc43, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc43)
  %111 = load ptr, ptr %mem_var, align 8
  %112 = load i64, ptr %pc_var, align 4
  %113 = call ptr @__lifted_bb_entered(ptr %state, i64 11996, ptr %111)
  %114 = call ptr @BB_2edc(ptr %state, i64 %112, ptr %111) #17
  store ptr %114, ptr %mem_var, align 8
  %115 = call i64 @__extract_rip(ptr %state)
  store i64 %115, ptr %pc_var, align 4
  %next_rva44 = sub i64 %115, %base
  switch i64 %next_rva44, label %dead_end [
    i64 12050, label %bb_2F12
  ]

bb_2F12:                                          ; preds = %bb_2EDC, %entry
  %block_pc45 = add i64 12050, %base
  store i64 %block_pc45, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc45)
  %116 = load ptr, ptr %mem_var, align 8
  %117 = load i64, ptr %pc_var, align 4
  %118 = call ptr @__lifted_bb_entered(ptr %state, i64 12050, ptr %116)
  %119 = call ptr @BB_2f12(ptr %state, i64 %117, ptr %116) #17
  store ptr %119, ptr %mem_var, align 8
  %120 = call i64 @__extract_rip(ptr %state)
  store i64 %120, ptr %pc_var, align 4
  %next_rva46 = sub i64 %120, %base
  switch i64 %next_rva46, label %dead_end [
    i64 12159, label %bb_2F7F
  ]

bb_2F7F:                                          ; preds = %bb_2F12, %entry
  %block_pc47 = add i64 12159, %base
  store i64 %block_pc47, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc47)
  %121 = load ptr, ptr %mem_var, align 8
  %122 = load i64, ptr %pc_var, align 4
  %123 = call ptr @__lifted_bb_entered(ptr %state, i64 12159, ptr %121)
  %124 = call ptr @BB_2f7f(ptr %state, i64 %122, ptr %121) #17
  store ptr %124, ptr %mem_var, align 8
  %125 = call i64 @__extract_rip(ptr %state)
  store i64 %125, ptr %pc_var, align 4
  %next_rva48 = sub i64 %125, %base
  switch i64 %next_rva48, label %dead_end [
    i64 12168, label %bb_2F88
    i64 12338, label %bb_3032
  ]

bb_2F88:                                          ; preds = %bb_2F7F, %entry
  %block_pc49 = add i64 12168, %base
  store i64 %block_pc49, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc49)
  %126 = load ptr, ptr %mem_var, align 8
  %127 = load i64, ptr %pc_var, align 4
  %128 = call ptr @__lifted_bb_entered(ptr %state, i64 12168, ptr %126)
  %129 = call ptr @BB_2f88(ptr %state, i64 %127, ptr %126) #17
  store ptr %129, ptr %mem_var, align 8
  %130 = call i64 @__extract_rip(ptr %state)
  store i64 %130, ptr %pc_var, align 4
  %next_rva50 = sub i64 %130, %base
  switch i64 %next_rva50, label %dead_end [
    i64 12222, label %bb_2FBE
  ]

bb_2FBE:                                          ; preds = %bb_2F88, %entry
  %block_pc51 = add i64 12222, %base
  store i64 %block_pc51, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc51)
  %131 = load ptr, ptr %mem_var, align 8
  %132 = load i64, ptr %pc_var, align 4
  %133 = call ptr @__lifted_bb_entered(ptr %state, i64 12222, ptr %131)
  %134 = call ptr @BB_2fbe(ptr %state, i64 %132, ptr %131) #17
  store ptr %134, ptr %mem_var, align 8
  %135 = call i64 @__extract_rip(ptr %state)
  store i64 %135, ptr %pc_var, align 4
  %next_rva52 = sub i64 %135, %base
  switch i64 %next_rva52, label %dead_end [
    i64 12329, label %bb_3029
  ]

bb_3029:                                          ; preds = %bb_2FBE, %entry
  %block_pc53 = add i64 12329, %base
  store i64 %block_pc53, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc53)
  %136 = load ptr, ptr %mem_var, align 8
  %137 = load i64, ptr %pc_var, align 4
  %138 = call ptr @__lifted_bb_entered(ptr %state, i64 12329, ptr %136)
  %139 = call ptr @BB_3029(ptr %state, i64 %137, ptr %136) #17
  store ptr %139, ptr %mem_var, align 8
  %140 = call i64 @__extract_rip(ptr %state)
  store i64 %140, ptr %pc_var, align 4
  %next_rva54 = sub i64 %140, %base
  switch i64 %next_rva54, label %dead_end [
    i64 11996, label %bb_2EDC
  ]

bb_3032:                                          ; preds = %bb_2F7F, %entry
  %block_pc55 = add i64 12338, %base
  store i64 %block_pc55, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc55)
  %141 = load ptr, ptr %mem_var, align 8
  %142 = load i64, ptr %pc_var, align 4
  %143 = call ptr @__lifted_bb_entered(ptr %state, i64 12338, ptr %141)
  %144 = call ptr @BB_3032(ptr %state, i64 %142, ptr %141) #17
  store ptr %144, ptr %mem_var, align 8
  %145 = call i64 @__extract_rip(ptr %state)
  store i64 %145, ptr %pc_var, align 4
  %next_rva56 = sub i64 %145, %base
  switch i64 %next_rva56, label %dead_end [
    i64 12392, label %bb_3068
  ]

bb_3068:                                          ; preds = %bb_3032, %entry
  %block_pc57 = add i64 12392, %base
  store i64 %block_pc57, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc57)
  %146 = load ptr, ptr %mem_var, align 8
  %147 = load i64, ptr %pc_var, align 4
  %148 = call ptr @__lifted_bb_entered(ptr %state, i64 12392, ptr %146)
  %149 = call ptr @BB_3068(ptr %state, i64 %147, ptr %146) #17
  store ptr %149, ptr %mem_var, align 8
  %150 = call i64 @__extract_rip(ptr %state)
  store i64 %150, ptr %pc_var, align 4
  %next_rva58 = sub i64 %150, %base
  switch i64 %next_rva58, label %dead_end [
    i64 12458, label %bb_30AA
  ]

bb_30AA:                                          ; preds = %bb_3068, %entry
  %block_pc59 = add i64 12458, %base
  store i64 %block_pc59, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc59)
  %151 = load ptr, ptr %mem_var, align 8
  %152 = load i64, ptr %pc_var, align 4
  %153 = call ptr @__lifted_bb_entered(ptr %state, i64 12458, ptr %151)
  %154 = call ptr @BB_30aa(ptr %state, i64 %152, ptr %151) #17
  store ptr %154, ptr %mem_var, align 8
  %155 = call i64 @__extract_rip(ptr %state)
  store i64 %155, ptr %pc_var, align 4
  %next_rva60 = sub i64 %155, %base
  %156 = load ptr, ptr %mem_var, align 8
  ret ptr %156

return_bb:                                        ; No predecessors!
  %157 = load ptr, ptr %mem_var, align 8
  ret ptr %157
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 10608, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.177477, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { alwaysinline nobuiltin nounwind "no-builtins" }
attributes #16 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #17 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
