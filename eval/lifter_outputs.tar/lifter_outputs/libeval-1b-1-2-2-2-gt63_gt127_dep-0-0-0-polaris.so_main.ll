; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.116567 = type { %struct.X86State.116566 }
%struct.X86State.116566 = type { %struct.ArchState.116535, [32 x %union.VectorReg.116538], %struct.ArithFlags.116539, %union.anon.116534, %struct.Segments.116541, %struct.AddressSpace.116543, %struct.GPR.116544, %struct.X87Stack.116547, %struct.MMX.116551, %struct.FPUStatusFlags.116552, %union.anon.116534, %union.FPU.116561, %struct.SegmentCaches.116563, %struct.K_REG.116565 }
%struct.ArchState.116535 = type { i32, i32, %union.anon.116534 }
%union.VectorReg.116538 = type { %union.vec512_t.116537 }
%union.vec512_t.116537 = type { %struct.uint64v8_t.116536 }
%struct.uint64v8_t.116536 = type { [8 x i64] }
%struct.ArithFlags.116539 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.116541 = type { i16, %union.SegmentSelector.116540, i16, %union.SegmentSelector.116540, i16, %union.SegmentSelector.116540, i16, %union.SegmentSelector.116540, i16, %union.SegmentSelector.116540, i16, %union.SegmentSelector.116540 }
%union.SegmentSelector.116540 = type { i16 }
%struct.AddressSpace.116543 = type { i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542 }
%struct.Reg.116542 = type { %union.anon.116534 }
%struct.GPR.116544 = type { i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542, i64, %struct.Reg.116542 }
%struct.X87Stack.116547 = type { [8 x %struct.anon.3.116546] }
%struct.anon.3.116546 = type { [6 x i8], %struct.float80_t.116545 }
%struct.float80_t.116545 = type { [10 x i8] }
%struct.MMX.116551 = type { [8 x %struct.anon.4.116550] }
%struct.anon.4.116550 = type { i64, %union.vec64_t.116549 }
%union.vec64_t.116549 = type { %struct.uint64v1_t.116548 }
%struct.uint64v1_t.116548 = type { [1 x i64] }
%struct.FPUStatusFlags.116552 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.116534 = type { i64 }
%union.FPU.116561 = type { %struct.anon.13.116560 }
%struct.anon.13.116560 = type { %struct.FpuFXSAVE.116559, [96 x i8] }
%struct.FpuFXSAVE.116559 = type { %union.SegmentSelector.116540, %union.SegmentSelector.116540, %union.FPUAbridgedTagWord.116553, i8, i16, i32, %union.SegmentSelector.116540, i16, i32, %union.SegmentSelector.116540, i16, %union.FPUControlStatus.116554, %union.FPUControlStatus.116554, [8 x %struct.FPUStackElem.116556], [16 x %union.vec128_t.116558] }
%union.FPUAbridgedTagWord.116553 = type { i8 }
%union.FPUControlStatus.116554 = type { i32 }
%struct.FPUStackElem.116556 = type { %union.anon.11.116555, [6 x i8] }
%union.anon.11.116555 = type { %struct.float80_t.116545 }
%union.vec128_t.116558 = type { %struct.uint128v1_t.116557 }
%struct.uint128v1_t.116557 = type { [1 x i128] }
%struct.SegmentCaches.116563 = type { %struct.SegmentShadow.116562, %struct.SegmentShadow.116562, %struct.SegmentShadow.116562, %struct.SegmentShadow.116562, %struct.SegmentShadow.116562, %struct.SegmentShadow.116562 }
%struct.SegmentShadow.116562 = type { %union.anon.116534, i32, i32 }
%struct.K_REG.116565 = type { [8 x %struct.anon.18.116564] }
%struct.anon.18.116564 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1110(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i39 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i39, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i1 = sub i64 %15, 48
  store i64 %sub.i.i1, ptr %RSP, align 8
  %cmp.i.i.i2 = icmp ult i64 %15, 48
  %call.i.i.i3 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i2, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #15
  %conv.i.i4 = zext i1 %call.i.i.i3 to i8
  %cf.i.i5 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i4, ptr %cf.i.i5, align 1
  %conv.i.i.i.i6 = trunc i64 %sub.i.i1 to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i6)
  %18 = and i8 %17, 1
  %conv.i.i.i7 = xor i8 %18, 1
  %pf.i.i.i8 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i7, ptr %pf.i.i.i8, align 1
  %xor.i.i.i.i9 = xor i64 48, %15
  %xor1.i.i.i.i10 = xor i64 %xor.i.i.i.i9, %sub.i.i1
  %19 = trunc i64 %xor1.i.i.i.i10 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i11 = and i8 %20, 1
  %af.i.i.i12 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i11, ptr %af.i.i.i12, align 1
  %cmp.i.i.i.i13 = icmp eq i64 %15, 48
  %call.i.i.i.i14 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i13, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #15
  %conv5.i.i.i15 = zext i1 %call.i.i.i.i14 to i8
  %zf.i.i.i16 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i15, ptr %zf.i.i.i16, align 1
  %cmp.i27.i.i.i17 = icmp slt i64 %sub.i.i1, 0
  %call1.i.i.i.i18 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i17, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #15
  %conv8.i.i.i19 = zext i1 %call1.i.i.i.i18 to i8
  %sf.i.i.i20 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i19, ptr %sf.i.i.i20, align 1
  %xor.i28.i.i.i21 = lshr i64 %xor.i.i.i.i9, 63
  %shr9.i.i.i.i22 = xor i64 %sub.i.i1, %15
  %xor3.i.i.i.i23 = lshr i64 %shr9.i.i.i.i22, 63
  %add.i.i.i.i24 = add nuw nsw i64 %xor3.i.i.i.i23, %xor.i28.i.i.i21
  %cmp.i29.i.i.i25 = icmp eq i64 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i64 noundef %15, i64 noundef 48, i64 noundef %sub.i.i1) #15
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 4
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %26, i64 noundef %25, i32 noundef 0) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RBP, align 8
  %31 = sub i64 %30, 8
  %32 = load i32, ptr %EDI, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_32(ptr noundef %34, i64 noundef %31, i32 noundef %32) #15
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %27
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 16
  %40 = load i64, ptr %RSI, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call ptr @__remill_write_memory_64(ptr noundef %41, i64 noundef %39, i64 noundef %40) #15
  store ptr %call.i.i31, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 16
  %47 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %47, i64 noundef %46) #15
  store i64 %call.i.i35, ptr %RAX, align 8
  store ptr %47, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %42
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 4
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RAX, align 8
  %52 = add i64 %51, 8
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i64 @__remill_read_memory_64(ptr noundef %53, i64 noundef %52) #15
  store i64 %call.i.i34, ptr %RAX, align 8
  store ptr %53, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %48
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %RAX, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call zeroext i8 @__remill_read_memory_8(ptr noundef %58, i64 noundef %57) #15
  store i8 %call.i.i32, ptr %AL, align 1
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %54
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RBP, align 8
  %63 = sub i64 %62, 17
  %64 = load i8, ptr %AL, align 1
  %65 = zext i8 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i29 = call ptr @__remill_write_memory_8(ptr noundef %66, i64 noundef %63, i8 noundef zeroext %64) #15
  store ptr %call.i.i29, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %59
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 4
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RBP, align 8
  %71 = sub i64 %70, 17
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call zeroext i8 @__remill_read_memory_8(ptr noundef %72, i64 noundef %71) #15
  %conv.i.i37 = zext i8 %call.i.i36 to i64
  store i64 %conv.i.i37, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %76 to i32
  %sub.i.i = sub i32 %conv.i.i, 64
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %conv.i.i, 64
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 64, i32 noundef %sub.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %79 = and i8 %78, 1
  %conv.i.i.i = xor i8 %79, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 64, %conv.i.i
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %80 = trunc i32 %xor1.i.i.i.i to i8
  %81 = lshr i8 %80, 4
  %conv2.i.i.i = and i8 %81, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %conv.i.i, 64
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 64, i32 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 64, i32 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 64, i32 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %73
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %86 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %86, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %87 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %87, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %85, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %82
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i8, ptr %AL, align 1
  %92 = zext i8 %91 to i64
  %93 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i38 = and i64 %92, 255
  store i64 %conv.i11.i38, ptr %RAX, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 2
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i32, ptr %EAX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %98, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %99, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %94
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 7
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = add i64 %103, 12007
  %105 = load ptr, ptr %MEMORY, align 8
  store i64 %104, ptr %RAX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %100
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 4
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RAX, align 8
  %110 = load i64, ptr %RCX, align 8
  %111 = mul i64 %110, 8
  %112 = add i64 %109, %111
  %113 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i64 @__remill_read_memory_64(ptr noundef %113, i64 noundef %112) #15
  store i64 %call.i.i33, ptr %RAX, align 8
  store ptr %113, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %106
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 2
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RAX, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %117, ptr %rip.i, align 8
  store i64 %117, ptr %NEXT_PC, align 8
  store ptr %118, ptr %MEMORY, align 8
  %119 = load ptr, ptr %MEMORY, align 8
  ret ptr %119
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_133a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3294
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load i32, ptr %EAX, align 4
  %12 = zext i32 %11 to i64
  %13 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %xor3.i.i = xor i32 %11, %conv.i.i
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RAX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %xor3.i.i to i8
  %14 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %15 = and i8 %14, 1
  %conv.i28.i = xor i8 %15, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %13, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %7
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %NEXT_PC, align 8
  %20 = sub i64 %19, 792
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %23 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %23, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %22, i64 noundef %sub.i.i, i64 noundef %21) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %20, ptr %rip.i, align 8
  store i64 %20, ptr %NEXT_PC, align 8
  store i64 %21, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  ret ptr %24
}

define ptr @BB_114f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11794
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11849
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_1185(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3700
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 5
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = sub i64 %14, 355
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %18 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %18, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %17, i64 noundef %sub.i.i, i64 noundef %16) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %15, ptr %rip.i, align 8
  store i64 %15, ptr %NEXT_PC, align 8
  store i64 %16, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  ret ptr %19
}

define ptr @BB_1348(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11529
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_1351(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11336
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11399
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1193(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 17
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i166 = call zeroext i8 @__remill_read_memory_8(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i167 = zext i8 %call.i.i166 to i64
  store i64 %conv.i.i167, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i64 3, ptr %RCX, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 1
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  %rdx.i155 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 7
  %rax.i156 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 1
  %15 = load i32, ptr %rax.i156, align 8
  %16 = ashr i32 %15, 31
  %conv.i13.i = zext i32 %16 to i64
  store i64 %conv.i13.i, ptr %rdx.i155, align 8
  store ptr %14, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %11
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 2
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load i32, ptr %ECX, align 4
  %21 = zext i32 %20 to i64
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 1
  %24 = load i32, ptr %rax.i, align 8
  %rdx.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 7
  %25 = load i32, ptr %rdx.i, align 8
  %sext.i132 = shl i64 %21, 32
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %22, ptr %rip.i, align 8
  %tobool.not.i.not.i = icmp eq i64 %sext.i132, 0
  br i1 %tobool.not.i.not.i, label %if.then.i, label %if.else.i

if.then.i:                                        ; preds = %17
  %call29.i = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %22, ptr noundef %23) #17
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

if.else.i:                                        ; preds = %17
  %conv.i118.i = ashr exact i64 %sext.i132, 32
  %conv.i.i133 = zext i32 %24 to i64
  %conv.i116.i = zext i32 %25 to i64
  %shl.i.i = shl nuw i64 %conv.i116.i, 32
  %or.i.i = or i64 %shl.i.i, %conv.i.i133
  %div.i.i = sdiv i64 %or.i.i, %conv.i118.i
  %rem.i.i = srem i64 %or.i.i, %conv.i118.i
  %26 = add i64 %div.i.i, 2147483648
  %cmp.not.i = icmp ult i64 %26, 4294967296
  br i1 %cmp.not.i, label %do.body42.i, label %if.then35.i

if.then35.i:                                      ; preds = %if.else.i
  %call39.i = call ptr @__remill_error(ptr noundef nonnull align 16 dereferenceable(3504) %state, i64 noundef %22, ptr noundef %23) #17
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

do.body42.i:                                      ; preds = %if.else.i
  %conv.i123.i = and i64 %div.i.i, 4294967295
  store i64 %conv.i123.i, ptr %rax.i, align 8
  %conv.i124.i = and i64 %rem.i.i, 4294967295
  store i64 %conv.i124.i, ptr %rdx.i, align 8
  %call64.i = call zeroext i8 @__remill_undefined_8() #16
  %cf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %call64.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call64.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call64.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call64.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call64.i, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %call64.i, ptr %of.i, align 1
  br label %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit

_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit: ; preds = %do.body42.i, %if.then35.i, %if.then.i
  %retval.1.i = phi ptr [ %call29.i, %if.then.i ], [ %call39.i, %if.then35.i ], [ %23, %do.body42.i ]
  store ptr %retval.1.i, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %_ZN12_GLOBAL__N_110IDIVedxeaxI2RnIjLb1EEEEP6MemoryS4_R5StateT_2InImE.exit
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %conv.i.i225 = trunc i64 %30 to i32
  %conv2.i.i = shl i32 %conv.i.i225, 1
  %32 = xor i32 %conv2.i.i, %conv.i.i225
  %cmp.i146.i = icmp slt i32 %32, 0
  %.pre.i = call zeroext i8 @__remill_undefined_8() #16
  %conv.i155.i = zext i32 %conv2.i.i to i64
  store i64 %conv.i155.i, ptr %RAX, align 8
  %cf.i226 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %conv.i.i225, 31
  %conv.i227 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i227, ptr %cf.i226, align 1
  %pf.i228 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %conv2.i.i to i8
  %33 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %34 = and i8 %33, 1
  %conv72.i = xor i8 %34, 1
  store i8 %conv72.i, ptr %pf.i228, align 1
  %af.i229 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %.pre.i, ptr %af.i229, align 1
  %zf.i230 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %conv2.i.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i230, align 1
  %sf.i231 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %conv2.i.i, 31
  %conv92.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv92.i, ptr %sf.i231, align 1
  %of.i232 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %cmp.i146.i to i8
  store i8 %conv99.i, ptr %of.i232, align 1
  store ptr %31, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %27
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 18
  %40 = load i8, ptr %AL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call ptr @__remill_write_memory_8(ptr noundef %42, i64 noundef %39, i8 noundef zeroext %40) #15
  store ptr %call.i.i157, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %35
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RBP, align 8
  %47 = sub i64 %46, 17
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i164 = call zeroext i8 @__remill_read_memory_8(ptr noundef %48, i64 noundef %47) #15
  %conv.i.i165 = zext i8 %call.i.i164 to i64
  store i64 %conv.i.i165, ptr %RDX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 5
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load ptr, ptr %MEMORY, align 8
  store i64 3, ptr %RCX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %49
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 5
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RAX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %53
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i32, ptr %EDX, align 4
  %61 = zext i32 %60 to i64
  %62 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %60, 127
  %cmp.i.i.i101 = icmp ult i32 %60, 127
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %60, i32 noundef 127, i32 noundef %sub.i.i100) #15
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %63 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %64 = and i8 %63, 1
  %conv.i.i.i106 = xor i8 %64, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 127, %60
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %65 = trunc i32 %xor1.i.i.i.i109 to i8
  %66 = lshr i8 %65, 4
  %conv2.i.i.i110 = and i8 %66, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %60, 127
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %60, i32 noundef 127, i32 noundef %sub.i.i100) #15
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %60, i32 noundef 127, i32 noundef %sub.i.i100) #15
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %60
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %60, i32 noundef 127, i32 noundef %sub.i.i100) #15
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %57
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i32, ptr %EAX, align 4
  %71 = zext i32 %70 to i64
  %72 = load ptr, ptr %MEMORY, align 8
  %zf.i137 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %73 = load i8, ptr %zf.i137, align 1
  %tobool.not.i = icmp eq i8 %73, 0
  %sf.i138 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %74 = load i8, ptr %sf.i138, align 1
  %tobool4.i = icmp eq i8 %74, 0
  %of.i139 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %75 = load i8, ptr %of.i139, align 1
  %tobool6.i = icmp ne i8 %75, 0
  %cmp.i.i140 = xor i1 %tobool4.i, %tobool6.i
  %76 = and i1 %tobool.not.i, %cmp.i.i140
  %call9.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %76) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call9.i, i64 %71, i64 %dst.coerce.val.i
  %conv.i28.i141 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i28.i141, ptr %RCX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %67
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 7
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %NEXT_PC, align 8
  %81 = add i64 %80, 11888
  %82 = load ptr, ptr %MEMORY, align 8
  store i64 %81, ptr %RAX, align 8
  store ptr %82, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %sext.i168 = shl i64 %87, 32
  %conv.i12.i169 = ashr exact i64 %sext.i168, 32
  store i64 %conv.i12.i169, ptr %RCX, align 8
  store ptr %88, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %83
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 4
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RAX, align 8
  %93 = load i64, ptr %RCX, align 8
  %94 = mul i64 %93, 8
  %95 = add i64 %92, %94
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i163 = call i64 @__remill_read_memory_64(ptr noundef %96, i64 noundef %95) #15
  store i64 %call.i.i163, ptr %RAX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %89
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 2
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %ECX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i194 = trunc i64 %100 to i32
  %xor3.i.i = xor i32 %101, %conv.i.i194
  %conv.i27.i195 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i195, ptr %RCX, align 8
  %cf.i.i196 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i196, align 1
  %conv.i.i.i197 = trunc i32 %xor3.i.i to i8
  %104 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i197)
  %105 = and i8 %104, 1
  %conv.i28.i198 = xor i8 %105, 1
  %pf.i.i199 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i198, ptr %pf.i.i199, align 1
  %cmp.i.i.i200 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i200, i32 noundef %conv.i.i194, i32 noundef %101, i32 noundef %xor3.i.i) #15
  %conv3.i.i202 = zext i1 %call.i.i.i201 to i8
  %zf.i.i203 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i202, ptr %zf.i.i203, align 1
  %cmp.i19.i.i204 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i204, i32 noundef %conv.i.i194, i32 noundef %101, i32 noundef %xor3.i.i) #15
  %conv6.i.i206 = zext i1 %call1.i.i.i205 to i8
  %sf.i.i207 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i206, ptr %sf.i.i207, align 1
  %of.i.i208 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i208, align 1
  %af.i.i209 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i210 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i210, ptr %af.i.i209, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %97
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i32, ptr %EDX, align 4
  %110 = zext i32 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %109, 127
  %cmp.i.i.i73 = icmp ult i32 %109, 127
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %109, i32 noundef 127, i32 noundef %sub.i.i72) #15
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %113 = and i8 %112, 1
  %conv.i.i.i78 = xor i8 %113, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 127, %109
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %114 = trunc i32 %xor1.i.i.i.i81 to i8
  %115 = lshr i8 %114, 4
  %conv2.i.i.i82 = and i8 %115, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %109, 127
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %109, i32 noundef 127, i32 noundef %sub.i.i72) #15
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %109, i32 noundef 127, i32 noundef %sub.i.i72) #15
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %109
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %109, i32 noundef 127, i32 noundef %sub.i.i72) #15
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %106
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 4
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %RCX, align 8
  %120 = load ptr, ptr %MEMORY, align 8
  %zf.i142 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %121 = load i8, ptr %zf.i142, align 1
  %tobool.not.i143 = icmp eq i8 %121, 0
  %sf.i144 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %122 = load i8, ptr %sf.i144, align 1
  %tobool4.i145 = icmp eq i8 %122, 0
  %of.i146 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %123 = load i8, ptr %of.i146, align 1
  %tobool6.i147 = icmp ne i8 %123, 0
  %cmp.i.i148 = xor i1 %tobool4.i145, %tobool6.i147
  %124 = and i1 %tobool.not.i143, %cmp.i.i148
  %call9.i149 = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %124) #16
  %dst.coerce.val.i150 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call9.i149, i64 %119, i64 %dst.coerce.val.i150
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %120, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %116
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 3
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i64, ptr %RAX, align 8
  %129 = load i64, ptr %RCX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %128, %129
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %128, %129
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %128, i64 noundef %129, i64 noundef %sub.i.i) #15
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %131 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %132 = and i8 %131, 1
  %conv.i.i.i6 = xor i8 %132, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %129, %128
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %133 = trunc i64 %xor1.i.i.i.i9 to i8
  %134 = lshr i8 %133, 4
  %conv2.i.i.i10 = and i8 %134, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %128, %129
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %128, i64 noundef %129, i64 noundef %sub.i.i) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %128, i64 noundef %129, i64 noundef %sub.i.i) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %128
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %128, i64 noundef %129, i64 noundef %sub.i.i) #15
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %130, ptr %MEMORY, align 8
  br label %135

135:                                              ; preds = %125
  %136 = load i64, ptr %NEXT_PC, align 8
  store i64 %136, ptr %PC, align 8
  %137 = add i64 %136, 4
  store i64 %137, ptr %NEXT_PC, align 8
  %138 = load i64, ptr %RBP, align 8
  %139 = sub i64 %138, 32
  %140 = load i64, ptr %RAX, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  %call.i.i158 = call ptr @__remill_write_memory_64(ptr noundef %141, i64 noundef %139, i64 noundef %140) #15
  store ptr %call.i.i158, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %135
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 7
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %NEXT_PC, align 8
  %146 = add i64 %145, 11738
  %147 = load ptr, ptr %MEMORY, align 8
  %call.i.i162 = call i64 @__remill_read_memory_64(ptr noundef %147, i64 noundef %146) #15
  store i64 %call.i.i162, ptr %RAX, align 8
  store ptr %147, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 2
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RAX, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %call.i.i159 = call i32 @__remill_read_memory_32(ptr noundef %152, i64 noundef %151) #15
  %conv.i.i160 = zext i32 %call.i.i159 to i64
  store i64 %conv.i.i160, ptr %RDX, align 8
  store ptr %152, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %148
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 7
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %NEXT_PC, align 8
  %157 = add i64 %156, 11657
  %158 = load ptr, ptr %MEMORY, align 8
  %call.i.i161 = call i64 @__remill_read_memory_64(ptr noundef %158, i64 noundef %157) #15
  store i64 %call.i.i161, ptr %RAX, align 8
  store ptr %158, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %153
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 3
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i64, ptr %RAX, align 8
  %163 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %163, i64 noundef %162) #15
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %164 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %165 = and i8 %164, 1
  %conv.i.i.i32 = xor i8 %165, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %166 = trunc i32 %xor1.i.i.i.i35 to i8
  %167 = lshr i8 %166, 4
  %conv2.i.i.i36 = and i8 %167, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %163, ptr %MEMORY, align 8
  br label %168

168:                                              ; preds = %159
  %169 = load i64, ptr %NEXT_PC, align 8
  store i64 %169, ptr %PC, align 8
  %170 = add i64 %169, 3
  store i64 %170, ptr %NEXT_PC, align 8
  %171 = load ptr, ptr %MEMORY, align 8
  %sf.i134 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %172 = load i8, ptr %sf.i134, align 1
  %tobool.i = icmp ne i8 %172, 0
  %of.i135 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %173 = load i8, ptr %of.i135, align 1
  %tobool2.i = icmp ne i8 %173, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %171, ptr %MEMORY, align 8
  br label %174

174:                                              ; preds = %168
  %175 = load i64, ptr %NEXT_PC, align 8
  store i64 %175, ptr %PC, align 8
  %176 = add i64 %175, 2
  store i64 %176, ptr %NEXT_PC, align 8
  %177 = load i32, ptr %EDX, align 4
  %178 = zext i32 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %178, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %179, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %174
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 3
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i64, ptr %RCX, align 8
  %184 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %183 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %185 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %185, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %186 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %187 = and i8 %186, 1
  %conv.i.i.i = xor i8 %187, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %188 = trunc i32 %xor1.i.i.i.i to i8
  %189 = lshr i8 %188, 4
  %conv2.i.i.i = and i8 %189, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %184, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %180
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 3
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %RCX, align 8
  %194 = load i32, ptr %EDX, align 4
  %195 = zext i32 %194 to i64
  %196 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %193 to i32
  %sext.i = shl i64 %193, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %195, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %197 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %197, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %194, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %196, ptr %MEMORY, align 8
  br label %198

198:                                              ; preds = %190
  %199 = load i64, ptr %NEXT_PC, align 8
  store i64 %199, ptr %PC, align 8
  %200 = add i64 %199, 3
  store i64 %200, ptr %NEXT_PC, align 8
  %201 = load i64, ptr %RCX, align 8
  %202 = load ptr, ptr %MEMORY, align 8
  %conv.i.i170 = trunc i64 %201 to i32
  %and3.i.i = and i32 1, %conv.i.i170
  %conv.i22.i171 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i171, ptr %RCX, align 8
  %cf.i.i172 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i172, align 1
  %conv.i.i.i173 = trunc i32 %and3.i.i to i8
  %203 = and i8 %conv.i.i.i173, 1
  %conv.i23.i174 = xor i8 %203, 1
  %pf.i.i175 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i174, ptr %pf.i.i175, align 1
  %cmp.i.i.i176 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i177 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i176, i32 noundef %conv.i.i170, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i177 to i8
  %zf.i.i178 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i178, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i170, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i179 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i179, align 1
  %of.i.i180 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i180, align 1
  %af.i.i181 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i181, align 1
  store ptr %202, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %198
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 3
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i32, ptr %ECX, align 4
  %208 = zext i32 %207 to i64
  %209 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %207, i32 noundef 0, i32 noundef %207) #15
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %207 to i8
  %210 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %211 = and i8 %210, 1
  %conv.i.i.i57 = xor i8 %211, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %207, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %207, i32 noundef 0, i32 noundef %207) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %207, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %207, i32 noundef 0, i32 noundef %207) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %207, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %207, i32 noundef 0, i32 noundef %207) #15
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %209, ptr %MEMORY, align 8
  br label %212

212:                                              ; preds = %204
  %213 = load i64, ptr %NEXT_PC, align 8
  store i64 %213, ptr %PC, align 8
  %214 = add i64 %213, 3
  store i64 %214, ptr %NEXT_PC, align 8
  %215 = load ptr, ptr %MEMORY, align 8
  %zf.i136 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %216 = load i8, ptr %zf.i136, align 1
  store i8 %216, ptr %CL, align 1
  store ptr %215, ptr %MEMORY, align 8
  br label %217

217:                                              ; preds = %212
  %218 = load i64, ptr %NEXT_PC, align 8
  store i64 %218, ptr %PC, align 8
  %219 = add i64 %218, 2
  store i64 %219, ptr %NEXT_PC, align 8
  %220 = load i8, ptr %AL, align 1
  %221 = zext i8 %220 to i64
  %222 = load i8, ptr %CL, align 1
  %223 = zext i8 %222 to i64
  %224 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %223, %221
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i182 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i182, align 1
  %225 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %226 = and i8 %225, 1
  %conv.i27.i = xor i8 %226, 1
  %pf.i.i183 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i183, align 1
  %227 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i184 = and i32 %227, 255
  %cmp.i.i.i185 = icmp eq i8 %or3.i.i, 0
  %228 = trunc i64 %221 to i32
  %conv1.i.i.i = and i32 %228, 255
  %229 = trunc i64 %223 to i32
  %conv2.i.i.i186 = and i32 %229, 255
  %call.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i185, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i186, i32 noundef %conv.i.i.i184) #15
  %conv3.i.i188 = zext i1 %call.i.i.i187 to i8
  %zf.i.i189 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i188, ptr %zf.i.i189, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i186, i32 noundef %conv.i.i.i184) #15
  %conv6.i.i190 = zext i1 %call4.i.i.i to i8
  %sf.i.i191 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i190, ptr %sf.i.i191, align 1
  %of.i.i192 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i192, align 1
  %af.i.i193 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i193, align 1
  store ptr %224, ptr %MEMORY, align 8
  br label %230

230:                                              ; preds = %217
  %231 = load i64, ptr %NEXT_PC, align 8
  store i64 %231, ptr %PC, align 8
  %232 = add i64 %231, 2
  store i64 %232, ptr %NEXT_PC, align 8
  %233 = load i8, ptr %AL, align 1
  %234 = zext i8 %233 to i64
  %235 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %234
  %and3.i.i211 = trunc i64 %and3.i15.i to i8
  %cf.i.i212 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i212, align 1
  %236 = and i8 %and3.i.i211, 1
  %conv.i14.i = xor i8 %236, 1
  %pf.i.i213 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i213, align 1
  %237 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i214 = and i32 %237, 255
  %cmp.i.i.i215 = icmp eq i8 %and3.i.i211, 0
  %238 = trunc i64 %234 to i32
  %conv1.i.i.i216 = and i32 %238, 255
  %call.i.i.i217 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i215, i32 noundef %conv1.i.i.i216, i32 noundef 1, i32 noundef %conv.i.i.i214) #15
  %conv3.i.i218 = zext i1 %call.i.i.i217 to i8
  %zf.i.i219 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i218, ptr %zf.i.i219, align 1
  %call4.i.i.i220 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i216, i32 noundef 1, i32 noundef %conv.i.i.i214) #15
  %conv6.i.i221 = zext i1 %call4.i.i.i220 to i8
  %sf.i.i222 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i221, ptr %sf.i.i222, align 1
  %of.i.i223 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i223, align 1
  %af.i.i224 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i224, align 1
  store ptr %235, ptr %MEMORY, align 8
  br label %239

239:                                              ; preds = %230
  %240 = load i64, ptr %NEXT_PC, align 8
  store i64 %240, ptr %PC, align 8
  %241 = add i64 %240, 6
  store i64 %241, ptr %NEXT_PC, align 8
  %242 = load i64, ptr %NEXT_PC, align 8
  %243 = add i64 %242, 5
  %244 = load i64, ptr %NEXT_PC, align 8
  %245 = load ptr, ptr %MEMORY, align 8
  %zf.i151 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %246 = load i8, ptr %zf.i151, align 1
  %tobool.not.i152 = icmp eq i8 %246, 0
  %call9.i153 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i152) #16
  %frombool.i = zext i1 %call9.i153 to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i154 = select i1 %call9.i153, i64 %243, i64 %244
  store i64 %cond1.i.i154, ptr %NEXT_PC, align 8
  store ptr %245, ptr %MEMORY, align 8
  %247 = load i64, ptr %NEXT_PC, align 8
  store i64 %247, ptr %PC, align 8
  %248 = load ptr, ptr %MEMORY, align 8
  ret ptr %248
}

define ptr @BB_1387(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11274
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11337
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_120d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_13bd(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RAX, align 8
  %5 = load i32, ptr %EAX, align 4
  %6 = zext i32 %5 to i64
  %7 = load ptr, ptr %MEMORY, align 8
  %conv.i.i2 = trunc i64 %4 to i32
  %xor3.i.i = xor i32 %5, %conv.i.i2
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RAX, align 8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i3, align 1
  %conv.i.i.i4 = trunc i32 %xor3.i.i to i8
  %8 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i4)
  %9 = and i8 %8, 1
  %conv.i28.i = xor i8 %9, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i5 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i5, i32 noundef %conv.i.i2, i32 noundef %5, i32 noundef %xor3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i6 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i2, i32 noundef %5, i32 noundef %xor3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %7, ptr %MEMORY, align 8
  br label %10

10:                                               ; preds = %1
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = add i64 %11, 4
  store i64 %12, ptr %NEXT_PC, align 8
  %13 = load i64, ptr %RSP, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 48, %13
  store i64 %add.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %13
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 48
  %15 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %15, i64 noundef %13, i64 noundef 48, i64 noundef %add.i.i) #15
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %16 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %17 = and i8 %16, 1
  %conv.i.i.i = xor i8 %17, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 48
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %13
  %18 = trunc i64 %xor1.i.i.i.i to i8
  %19 = lshr i8 %18, 4
  %conv2.i.i.i = and i8 %19, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %13, i64 noundef 48, i64 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %13, i64 noundef 48, i64 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %13
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %13, i64 noundef 48, i64 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %10
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 1
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %rsp.i7 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %24 = load i64, ptr %rsp.i7, align 8
  %add.i.i8 = add i64 %24, 8
  store i64 %add.i.i8, ptr %rsp.i7, align 8
  %call.i.i9 = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %24) #15
  store i64 %call.i.i9, ptr %RBP, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %20
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 1
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %29 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %28, i64 noundef %29) #15
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %rsp.i, align 8
  %add.i.i1 = add i64 %30, 8
  store i64 %add.i.i1, ptr %rsp.i, align 8
  store ptr %28, ptr %MEMORY, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  ret ptr %31
}

define ptr @BB_1213(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3568
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load i32, ptr %EAX, align 4
  %12 = zext i32 %11 to i64
  %13 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %xor3.i.i = xor i32 %11, %conv.i.i
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RAX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %xor3.i.i to i8
  %14 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %15 = and i8 %14, 1
  %conv.i28.i = xor i8 %15, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %13, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %7
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %NEXT_PC, align 8
  %20 = sub i64 %19, 497
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %23 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %23, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %22, i64 noundef %sub.i.i, i64 noundef %21) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %20, ptr %rip.i, align 8
  store i64 %20, ptr %NEXT_PC, align 8
  store i64 %21, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  ret ptr %24
}

define ptr @BB_122a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11663
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11582
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_1260(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 3501
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 5
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = sub i64 %14, 574
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %18 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %18, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %17, i64 noundef %sub.i.i, i64 noundef %16) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %15, ptr %rip.i, align 8
  store i64 %15, ptr %NEXT_PC, align 8
  store i64 %16, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  ret ptr %19
}

define ptr @BB_1221(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11816
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000003_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !32)
  %rsp.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !35)
  %rip.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !38)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_12b9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11472
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11535
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_126e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11739
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 40
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 11564
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #15
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 11627
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_12ef(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11618
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 48
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 11395
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #15
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 11458
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_12b3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1334(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.116567, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.116567, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.116567) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #18
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.116567) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !41
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !41
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4368, label %bb_1110
    i64 4431, label %bb_114F
    i64 4485, label %bb_1185
    i64 4499, label %bb_1193
    i64 4621, label %bb_120D
    i64 4627, label %bb_1213
    i64 4641, label %bb_1221
    i64 4650, label %bb_122A
    i64 4704, label %bb_1260
    i64 4718, label %bb_126E
    i64 4787, label %bb_12B3
    i64 4793, label %bb_12B9
    i64 4847, label %bb_12EF
    i64 4916, label %bb_1334
    i64 4922, label %bb_133A
    i64 4936, label %bb_1348
    i64 4945, label %bb_1351
    i64 4999, label %bb_1387
    i64 5053, label %bb_13BD
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
    i64 -281474976710653, label %bb_FFFF000000000003
  ]

dead_end:                                         ; preds = %bb_FFFF000000000003, %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_1387, %bb_1351, %bb_1348, %bb_133A, %bb_1334, %bb_12EF, %bb_12B9, %bb_12B3, %bb_126E, %bb_1260, %bb_122A, %bb_1221, %bb_1213, %bb_120D, %bb_1193, %bb_1185, %bb_114F, %bb_1110, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1110:                                          ; preds = %entry
  %block_pc = add i64 4368, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4368, ptr %1)
  %4 = call ptr @BB_1110(ptr %state, i64 %2, ptr %1) #19
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4431, label %bb_114F
    i64 4922, label %bb_133A
  ]

bb_114F:                                          ; preds = %bb_1110, %entry
  %block_pc1 = add i64 4431, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4431, ptr %6)
  %9 = call ptr @BB_114f(ptr %state, i64 %7, ptr %6) #19
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4485, label %bb_1185
  ]

bb_1185:                                          ; preds = %bb_114F, %entry
  %block_pc3 = add i64 4485, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4485, ptr %11)
  %14 = call ptr @BB_1185(ptr %state, i64 %12, ptr %11) #19
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4144, label %bb_FFFF000000000001
  ]

bb_1193:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc5 = add i64 4499, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4499, ptr %16)
  %19 = call ptr @BB_1193(ptr %state, i64 %17, ptr %16) #19
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4621, label %bb_120D
  ]

bb_120D:                                          ; preds = %bb_1193, %entry
  %block_pc7 = add i64 4621, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4621, ptr %21)
  %24 = call ptr @BB_120d(ptr %state, i64 %22, ptr %21) #19
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4627, label %bb_1213
    i64 4650, label %bb_122A
  ]

bb_1213:                                          ; preds = %bb_120D, %entry
  %block_pc9 = add i64 4627, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4627, ptr %26)
  %29 = call ptr @BB_1213(ptr %state, i64 %27, ptr %26) #19
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4144, label %bb_FFFF000000000002
  ]

bb_1221:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc11 = add i64 4641, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4641, ptr %31)
  %34 = call ptr @BB_1221(ptr %state, i64 %32, ptr %31) #19
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4793, label %bb_12B9
  ]

bb_122A:                                          ; preds = %bb_120D, %entry
  %block_pc13 = add i64 4650, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4650, ptr %36)
  %39 = call ptr @BB_122a(ptr %state, i64 %37, ptr %36) #19
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4704, label %bb_1260
  ]

bb_1260:                                          ; preds = %bb_122A, %entry
  %block_pc15 = add i64 4704, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4704, ptr %41)
  %44 = call ptr @BB_1260(ptr %state, i64 %42, ptr %41) #19
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4144, label %bb_FFFF000000000003
  ]

bb_126E:                                          ; preds = %bb_FFFF000000000003, %entry
  %block_pc17 = add i64 4718, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4718, ptr %46)
  %49 = call ptr @BB_126e(ptr %state, i64 %47, ptr %46) #19
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4787, label %bb_12B3
  ]

bb_12B3:                                          ; preds = %bb_126E, %entry
  %block_pc19 = add i64 4787, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4787, ptr %51)
  %54 = call ptr @BB_12b3(ptr %state, i64 %52, ptr %51) #19
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 4793, label %bb_12B9
  ]

bb_12B9:                                          ; preds = %bb_12B3, %bb_1221, %entry
  %block_pc21 = add i64 4793, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 4793, ptr %56)
  %59 = call ptr @BB_12b9(ptr %state, i64 %57, ptr %56) #19
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4847, label %bb_12EF
  ]

bb_12EF:                                          ; preds = %bb_12B9, %entry
  %block_pc23 = add i64 4847, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 4847, ptr %61)
  %64 = call ptr @BB_12ef(ptr %state, i64 %62, ptr %61) #19
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 4916, label %bb_1334
  ]

bb_1334:                                          ; preds = %bb_12EF, %entry
  %block_pc25 = add i64 4916, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 4916, ptr %66)
  %69 = call ptr @BB_1334(ptr %state, i64 %67, ptr %66) #19
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 4945, label %bb_1351
  ]

bb_133A:                                          ; preds = %bb_1110, %entry
  %block_pc27 = add i64 4922, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 4922, ptr %71)
  %74 = call ptr @BB_133a(ptr %state, i64 %72, ptr %71) #19
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 4144, label %bb_FFFF000000000000
  ]

bb_1348:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc29 = add i64 4936, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 4936, ptr %76)
  %79 = call ptr @BB_1348(ptr %state, i64 %77, ptr %76) #19
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 4945, label %bb_1351
  ]

bb_1351:                                          ; preds = %bb_1348, %bb_1334, %entry
  %block_pc31 = add i64 4945, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 4945, ptr %81)
  %84 = call ptr @BB_1351(ptr %state, i64 %82, ptr %81) #19
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 4999, label %bb_1387
  ]

bb_1387:                                          ; preds = %bb_1351, %entry
  %block_pc33 = add i64 4999, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 4999, ptr %86)
  %89 = call ptr @BB_1387(ptr %state, i64 %87, ptr %86) #19
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  switch i64 %next_rva34, label %dead_end [
    i64 5053, label %bb_13BD
  ]

bb_13BD:                                          ; preds = %bb_1387, %entry
  %block_pc35 = add i64 5053, %base
  store i64 %block_pc35, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc35)
  %91 = load ptr, ptr %mem_var, align 8
  %92 = load i64, ptr %pc_var, align 4
  %93 = call ptr @__lifted_bb_entered(ptr %state, i64 5053, ptr %91)
  %94 = call ptr @BB_13bd(ptr %state, i64 %92, ptr %91) #19
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva36 = sub i64 %95, %base
  %96 = load ptr, ptr %mem_var, align 8
  ret ptr %96

bb_FFFF000000000000:                              ; preds = %bb_133A, %entry
  %97 = load ptr, ptr %mem_var, align 8
  %98 = load i64, ptr %pc_var, align 4
  %99 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %98, ptr %97) #19
  store ptr %99, ptr %mem_var, align 8
  %100 = call i64 @__extract_rip(ptr %state)
  store i64 %100, ptr %pc_var, align 4
  %next_rva37 = sub i64 %100, %base
  switch i64 %next_rva37, label %dead_end [
    i64 4936, label %bb_1348
  ]

bb_FFFF000000000001:                              ; preds = %bb_1185, %entry
  %101 = load ptr, ptr %mem_var, align 8
  %102 = load i64, ptr %pc_var, align 4
  %103 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %102, ptr %101) #19
  store ptr %103, ptr %mem_var, align 8
  %104 = call i64 @__extract_rip(ptr %state)
  store i64 %104, ptr %pc_var, align 4
  %next_rva38 = sub i64 %104, %base
  switch i64 %next_rva38, label %dead_end [
    i64 4499, label %bb_1193
  ]

bb_FFFF000000000002:                              ; preds = %bb_1213, %entry
  %105 = load ptr, ptr %mem_var, align 8
  %106 = load i64, ptr %pc_var, align 4
  %107 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %106, ptr %105) #19
  store ptr %107, ptr %mem_var, align 8
  %108 = call i64 @__extract_rip(ptr %state)
  store i64 %108, ptr %pc_var, align 4
  %next_rva39 = sub i64 %108, %base
  switch i64 %next_rva39, label %dead_end [
    i64 4641, label %bb_1221
  ]

bb_FFFF000000000003:                              ; preds = %bb_1260, %entry
  %109 = load ptr, ptr %mem_var, align 8
  %110 = load i64, ptr %pc_var, align 4
  %111 = call ptr @BB_ffff000000000003_ext(ptr %state, i64 %110, ptr %109) #19
  store ptr %111, ptr %mem_var, align 8
  %112 = call i64 @__extract_rip(ptr %state)
  store i64 %112, ptr %pc_var, align 4
  %next_rva40 = sub i64 %112, %base
  switch i64 %next_rva40, label %dead_end [
    i64 4718, label %bb_126E
  ]

return_bb:                                        ; No predecessors!
  %113 = load ptr, ptr %mem_var, align 8
  ret ptr %113
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4368, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.116566, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !41
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { alwaysinline nobuiltin nounwind "no-builtins" }
attributes #18 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #19 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33}
!33 = distinct !{!33, !34, !"__extract_rsp: %state"}
!34 = distinct !{!34, !"__extract_rsp"}
!35 = !{!36}
!36 = distinct !{!36, !37, !"__store_rip: %state"}
!37 = distinct !{!37, !"__store_rip"}
!38 = !{!39}
!39 = distinct !{!39, !40, !"__store_rsp: %state"}
!40 = distinct !{!40, !"__store_rsp"}
!41 = !{!42, !42, i64 0}
!42 = !{!"omnipotent char", !43, i64 0}
!43 = !{!"Simple C++ TBAA"}
