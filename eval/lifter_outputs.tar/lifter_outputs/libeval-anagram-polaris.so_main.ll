; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.161565 = type { %struct.X86State.161564 }
%struct.X86State.161564 = type { %struct.ArchState.161533, [32 x %union.VectorReg.161536], %struct.ArithFlags.161537, %union.anon.161532, %struct.Segments.161539, %struct.AddressSpace.161541, %struct.GPR.161542, %struct.X87Stack.161545, %struct.MMX.161549, %struct.FPUStatusFlags.161550, %union.anon.161532, %union.FPU.161559, %struct.SegmentCaches.161561, %struct.K_REG.161563 }
%struct.ArchState.161533 = type { i32, i32, %union.anon.161532 }
%union.VectorReg.161536 = type { %union.vec512_t.161535 }
%union.vec512_t.161535 = type { %struct.uint64v8_t.161534 }
%struct.uint64v8_t.161534 = type { [8 x i64] }
%struct.ArithFlags.161537 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.161539 = type { i16, %union.SegmentSelector.161538, i16, %union.SegmentSelector.161538, i16, %union.SegmentSelector.161538, i16, %union.SegmentSelector.161538, i16, %union.SegmentSelector.161538, i16, %union.SegmentSelector.161538 }
%union.SegmentSelector.161538 = type { i16 }
%struct.AddressSpace.161541 = type { i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540 }
%struct.Reg.161540 = type { %union.anon.161532 }
%struct.GPR.161542 = type { i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540, i64, %struct.Reg.161540 }
%struct.X87Stack.161545 = type { [8 x %struct.anon.3.161544] }
%struct.anon.3.161544 = type { [6 x i8], %struct.float80_t.161543 }
%struct.float80_t.161543 = type { [10 x i8] }
%struct.MMX.161549 = type { [8 x %struct.anon.4.161548] }
%struct.anon.4.161548 = type { i64, %union.vec64_t.161547 }
%union.vec64_t.161547 = type { %struct.uint64v1_t.161546 }
%struct.uint64v1_t.161546 = type { [1 x i64] }
%struct.FPUStatusFlags.161550 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.161532 = type { i64 }
%union.FPU.161559 = type { %struct.anon.13.161558 }
%struct.anon.13.161558 = type { %struct.FpuFXSAVE.161557, [96 x i8] }
%struct.FpuFXSAVE.161557 = type { %union.SegmentSelector.161538, %union.SegmentSelector.161538, %union.FPUAbridgedTagWord.161551, i8, i16, i32, %union.SegmentSelector.161538, i16, i32, %union.SegmentSelector.161538, i16, %union.FPUControlStatus.161552, %union.FPUControlStatus.161552, [8 x %struct.FPUStackElem.161554], [16 x %union.vec128_t.161556] }
%union.FPUAbridgedTagWord.161551 = type { i8 }
%union.FPUControlStatus.161552 = type { i32 }
%struct.FPUStackElem.161554 = type { %union.anon.11.161553, [6 x i8] }
%union.anon.11.161553 = type { %struct.float80_t.161543 }
%union.vec128_t.161556 = type { %struct.uint128v1_t.161555 }
%struct.uint128v1_t.161555 = type { [1 x i128] }
%struct.SegmentCaches.161561 = type { %struct.SegmentShadow.161560, %struct.SegmentShadow.161560, %struct.SegmentShadow.161560, %struct.SegmentShadow.161560, %struct.SegmentShadow.161560, %struct.SegmentShadow.161560 }
%struct.SegmentShadow.161560 = type { %union.anon.161532, i32, i32 }
%struct.K_REG.161563 = type { [8 x %struct.anon.18.161562] }
%struct.anon.18.161562 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_2160(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i121 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #18
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i121, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 112
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 112
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #18
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 112, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 112
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #18
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #18
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #18
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 12
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #18
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 8
  %34 = load i64, ptr %RSI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_64(ptr noundef %35, i64 noundef %33, i64 noundef %34) #18
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 15514
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #18
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #18
  %conv.i.i80 = zext i32 %call.i.i79 to i64
  store i64 %conv.i.i80, ptr %RDX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 7
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %NEXT_PC, align 8
  %51 = add i64 %50, 15769
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %52, i64 noundef %51) #18
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %57, i64 noundef %56) #18
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %59 = and i8 %58, 1
  %conv.i.i.i32 = xor i8 %59, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %60 = trunc i32 %xor1.i.i.i.i35 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i36 = and i8 %61, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %53
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %66 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %66, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %67 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %67, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %EDX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %72, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RCX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %77 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %79 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %79, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %80 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %81 = and i8 %80, 1
  %conv.i.i.i = xor i8 %81, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %82 = trunc i32 %xor1.i.i.i.i to i8
  %83 = lshr i8 %82, 4
  %conv2.i.i.i = and i8 %83, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %74
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 3
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RCX, align 8
  %88 = load i32, ptr %EDX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %87 to i32
  %sext.i = shl i64 %87, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %89, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %91 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %91, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %88, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %84
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %conv.i.i83 = trunc i64 %95 to i32
  %and3.i.i = and i32 1, %conv.i.i83
  %conv.i22.i84 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i84, ptr %RCX, align 8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i85, align 1
  %conv.i.i.i86 = trunc i32 %and3.i.i to i8
  %97 = and i8 %conv.i.i.i86, 1
  %conv.i23.i87 = xor i8 %97, 1
  %pf.i.i88 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i87, ptr %pf.i.i88, align 1
  %cmp.i.i.i89 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i90 to i8
  %zf.i.i91 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i91, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i94, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i32, ptr %ECX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %101 to i8
  %104 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %105 = and i8 %104, 1
  %conv.i.i.i57 = xor i8 %105, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %101, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %101, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %101, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #18
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %98
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %110 = load i8, ptr %zf.i, align 1
  store i8 %110, ptr %CL, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %106
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 2
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i8, ptr %AL, align 1
  %115 = zext i8 %114 to i64
  %116 = load i8, ptr %CL, align 1
  %117 = zext i8 %116 to i64
  %118 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %117, %115
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i95 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %119 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %120 = and i8 %119, 1
  %conv.i27.i = xor i8 %120, 1
  %pf.i.i96 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i96, align 1
  %121 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i97 = and i32 %121, 255
  %cmp.i.i.i98 = icmp eq i8 %or3.i.i, 0
  %122 = trunc i64 %115 to i32
  %conv1.i.i.i = and i32 %122, 255
  %123 = trunc i64 %117 to i32
  %conv2.i.i.i99 = and i32 %123, 255
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i98, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #18
  %conv3.i.i101 = zext i1 %call.i.i.i100 to i8
  %zf.i.i102 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i101, ptr %zf.i.i102, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #18
  %conv6.i.i103 = zext i1 %call4.i.i.i to i8
  %sf.i.i104 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i103, ptr %sf.i.i104, align 1
  %of.i.i105 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i105, align 1
  %af.i.i106 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i106, align 1
  store ptr %118, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %111
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %128
  %and3.i.i107 = trunc i64 %and3.i15.i to i8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i108, align 1
  %130 = and i8 %and3.i.i107, 1
  %conv.i14.i = xor i8 %130, 1
  %pf.i.i109 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i109, align 1
  %131 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i110 = and i32 %131, 255
  %cmp.i.i.i111 = icmp eq i8 %and3.i.i107, 0
  %132 = trunc i64 %128 to i32
  %conv1.i.i.i112 = and i32 %132, 255
  %call.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #18
  %conv3.i.i114 = zext i1 %call.i.i.i113 to i8
  %zf.i.i115 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i114, ptr %zf.i.i115, align 1
  %call4.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #18
  %conv6.i.i117 = zext i1 %call4.i.i.i116 to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i117, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i120, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %124
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 6
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %NEXT_PC, align 8
  %137 = add i64 %136, 5
  %138 = load i64, ptr %NEXT_PC, align 8
  %139 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %140 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %140, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %137, i64 %138
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %139, ptr %MEMORY, align 8
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  ret ptr %142
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_21a5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i368 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i368, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 12
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i363 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #18
  %conv.i.i364 = zext i32 %call.i.i363 to i64
  store i64 %conv.i.i364, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RSP, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RDI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RDI, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %add.i.i175 = add i64 -16, %21
  store i64 %add.i.i175, ptr %RDI, align 8
  %cmp.i.i.i176 = icmp ult i64 %add.i.i175, %21
  %cmp1.i.i.i177 = icmp ult i64 %add.i.i175, -16
  %23 = or i1 %cmp.i.i.i176, %cmp1.i.i.i177
  %call.i.i.i178 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %23, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #18
  %conv.i.i179 = zext i1 %call.i.i.i178 to i8
  %cf.i.i180 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i179, ptr %cf.i.i180, align 1
  %conv.i.i.i.i181 = trunc i64 %add.i.i175 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i181)
  %25 = and i8 %24, 1
  %conv.i.i.i182 = xor i8 %25, 1
  %pf.i.i.i183 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i182, ptr %pf.i.i.i183, align 1
  %xor.i.i.i.i184 = xor i64 %add.i.i175, -16
  %xor1.i.i.i.i185 = xor i64 %xor.i.i.i.i184, %21
  %26 = trunc i64 %xor1.i.i.i.i185 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i186 = and i8 %27, 1
  %af.i.i.i187 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i186, ptr %af.i.i.i187, align 1
  %cmp.i.i.i.i188 = icmp eq i64 %add.i.i175, 0
  %call.i.i.i.i189 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i188, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #18
  %conv5.i.i.i190 = zext i1 %call.i.i.i.i189 to i8
  %zf.i.i.i191 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i190, ptr %zf.i.i.i191, align 1
  %cmp.i27.i.i.i192 = icmp slt i64 %add.i.i175, 0
  %call1.i.i.i.i193 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i192, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #18
  %conv8.i.i.i194 = zext i1 %call1.i.i.i.i193 to i8
  %sf.i.i.i195 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i194, ptr %sf.i.i.i195, align 1
  %shr8.i.i.i.i196 = xor i64 %add.i.i175, %21
  %xor.i28.i.i.i197 = lshr i64 %shr8.i.i.i.i196, 63
  %xor3.i.i.i.i198 = lshr i64 %xor.i.i.i.i184, 63
  %add.i.i.i.i199 = add nuw nsw i64 %xor.i28.i.i.i197, %xor3.i.i.i.i198
  %cmp.i29.i.i.i200 = icmp eq i64 %add.i.i.i.i199, 2
  %call.i30.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i200, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #18
  %conv11.i.i.i202 = zext i1 %call.i30.i.i.i201 to i8
  %of.i.i.i203 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i202, ptr %of.i.i.i203, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %18
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 4
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 72
  %33 = load i64, ptr %RDI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i358 = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %32, i64 noundef %33) #18
  store ptr %call.i.i358, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RDI, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RSP, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %RSP, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  store i64 %43, ptr %RAX, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %40
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 4
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RAX, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 -16, %48
  store i64 %add.i.i146, ptr %RAX, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %48
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, -16
  %50 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %50, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %52 = and i8 %51, 1
  %conv.i.i.i153 = xor i8 %52, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, -16
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %48
  %53 = trunc i64 %xor1.i.i.i.i156 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i157 = and i8 %54, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %48
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #18
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %45
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  store i64 %58, ptr %RSP, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 3
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RSP, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  store i64 %63, ptr %RCX, align 8
  store ptr %64, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %60
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 4
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RCX, align 8
  %69 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %68
  store i64 %add.i.i117, ptr %RCX, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %68
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %70 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %70, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %72 = and i8 %71, 1
  %conv.i.i.i124 = xor i8 %72, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %68
  %73 = trunc i64 %xor1.i.i.i.i127 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i128 = and i8 %74, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %68
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i117) #18
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %65
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 4
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RBP, align 8
  %79 = sub i64 %78, 64
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %call.i.i357 = call ptr @__remill_write_memory_64(ptr noundef %81, i64 noundef %79, i64 noundef %80) #18
  store ptr %call.i.i357, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %75
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RCX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  store i64 %85, ptr %RSP, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %82
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RSP, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  store i64 %90, ptr %R8, align 8
  store ptr %91, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %87
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 4
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %R8, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %95
  store i64 %add.i.i88, ptr %R8, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %95
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %97 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %97, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %98 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %99 = and i8 %98, 1
  %conv.i.i.i95 = xor i8 %99, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %95
  %100 = trunc i64 %xor1.i.i.i.i98 to i8
  %101 = lshr i8 %100, 4
  %conv2.i.i.i99 = and i8 %101, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %95
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i88) #18
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %92
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 4
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load i64, ptr %RBP, align 8
  %106 = sub i64 %105, 56
  %107 = load i64, ptr %R8, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i356 = call ptr @__remill_write_memory_64(ptr noundef %108, i64 noundef %106, i64 noundef %107) #18
  store ptr %call.i.i356, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %102
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 3
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %R8, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  store i64 %112, ptr %RSP, align 8
  store ptr %113, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %109
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RSP, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  store i64 %117, ptr %R8, align 8
  store ptr %118, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %114
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 4
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %R8, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %122
  store i64 %add.i.i59, ptr %R8, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %122
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %124 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %124, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %125 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %126 = and i8 %125, 1
  %conv.i.i.i66 = xor i8 %126, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %122
  %127 = trunc i64 %xor1.i.i.i.i69 to i8
  %128 = lshr i8 %127, 4
  %conv2.i.i.i70 = and i8 %128, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %122
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i59) #18
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %119
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 4
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %RBP, align 8
  %133 = sub i64 %132, 48
  %134 = load i64, ptr %R8, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %call.i.i355 = call ptr @__remill_write_memory_64(ptr noundef %135, i64 noundef %133, i64 noundef %134) #18
  store ptr %call.i.i355, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %129
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 3
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %R8, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  store i64 %139, ptr %RSP, align 8
  store ptr %140, ptr %MEMORY, align 8
  br label %141

141:                                              ; preds = %136
  %142 = load i64, ptr %NEXT_PC, align 8
  store i64 %142, ptr %PC, align 8
  %143 = add i64 %142, 3
  store i64 %143, ptr %NEXT_PC, align 8
  %144 = load i64, ptr %RSP, align 8
  %145 = load ptr, ptr %MEMORY, align 8
  store i64 %144, ptr %R8, align 8
  store ptr %145, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %141
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 4
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %R8, align 8
  %150 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %149
  store i64 %add.i.i30, ptr %R8, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %149
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %151 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %151, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %152 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %153 = and i8 %152, 1
  %conv.i.i.i37 = xor i8 %153, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %149
  %154 = trunc i64 %xor1.i.i.i.i40 to i8
  %155 = lshr i8 %154, 4
  %conv2.i.i.i41 = and i8 %155, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %149
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %149, i64 noundef -16, i64 noundef %add.i.i30) #18
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %150, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %146
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 4
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load i64, ptr %RBP, align 8
  %160 = sub i64 %159, 40
  %161 = load i64, ptr %R8, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i354 = call ptr @__remill_write_memory_64(ptr noundef %162, i64 noundef %160, i64 noundef %161) #18
  store ptr %call.i.i354, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %156
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 3
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %R8, align 8
  %167 = load ptr, ptr %MEMORY, align 8
  store i64 %166, ptr %RSP, align 8
  store ptr %167, ptr %MEMORY, align 8
  br label %168

168:                                              ; preds = %163
  %169 = load i64, ptr %NEXT_PC, align 8
  store i64 %169, ptr %PC, align 8
  %170 = add i64 %169, 3
  store i64 %170, ptr %NEXT_PC, align 8
  %171 = load i64, ptr %RSP, align 8
  %172 = load ptr, ptr %MEMORY, align 8
  store i64 %171, ptr %R8, align 8
  store ptr %172, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %168
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 4
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i64, ptr %R8, align 8
  %177 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %176
  store i64 %add.i.i1, ptr %R8, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %176
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %178 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %178, i64 noundef %176, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %179 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %180 = and i8 %179, 1
  %conv.i.i.i8 = xor i8 %180, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %176
  %181 = trunc i64 %xor1.i.i.i.i11 to i8
  %182 = lshr i8 %181, 4
  %conv2.i.i.i12 = and i8 %182, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %176, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %176, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %176
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %176, i64 noundef -16, i64 noundef %add.i.i1) #18
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %177, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %173
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 4
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i64, ptr %RBP, align 8
  %187 = sub i64 %186, 32
  %188 = load i64, ptr %R8, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %call.i.i353 = call ptr @__remill_write_memory_64(ptr noundef %189, i64 noundef %187, i64 noundef %188) #18
  store ptr %call.i.i353, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %183
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 3
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %R8, align 8
  %194 = load ptr, ptr %MEMORY, align 8
  store i64 %193, ptr %RSP, align 8
  store ptr %194, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %190
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 6
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i64, ptr %RDI, align 8
  %199 = load ptr, ptr %MEMORY, align 8
  %call.i.i349 = call ptr @__remill_write_memory_32(ptr noundef %199, i64 noundef %198, i32 noundef 0) #18
  store ptr %call.i.i349, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %195
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 2
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i64, ptr %RAX, align 8
  %204 = load i32, ptr %ESI, align 4
  %205 = zext i32 %204 to i64
  %206 = load ptr, ptr %MEMORY, align 8
  %call.i.i350 = call ptr @__remill_write_memory_32(ptr noundef %206, i64 noundef %203, i32 noundef %204) #18
  store ptr %call.i.i350, ptr %MEMORY, align 8
  br label %207

207:                                              ; preds = %200
  %208 = load i64, ptr %NEXT_PC, align 8
  store i64 %208, ptr %PC, align 8
  %209 = add i64 %208, 3
  store i64 %209, ptr %NEXT_PC, align 8
  %210 = load i64, ptr %RCX, align 8
  %211 = load i64, ptr %RDX, align 8
  %212 = load ptr, ptr %MEMORY, align 8
  %call.i.i352 = call ptr @__remill_write_memory_64(ptr noundef %212, i64 noundef %210, i64 noundef %211) #18
  store ptr %call.i.i352, ptr %MEMORY, align 8
  br label %213

213:                                              ; preds = %207
  %214 = load i64, ptr %NEXT_PC, align 8
  store i64 %214, ptr %PC, align 8
  %215 = add i64 %214, 2
  store i64 %215, ptr %NEXT_PC, align 8
  %216 = load i64, ptr %RAX, align 8
  %217 = load ptr, ptr %MEMORY, align 8
  %call.i.i361 = call i32 @__remill_read_memory_32(ptr noundef %217, i64 noundef %216) #18
  %conv.i.i362 = zext i32 %call.i.i361 to i64
  store i64 %conv.i.i362, ptr %RDX, align 8
  store ptr %217, ptr %MEMORY, align 8
  br label %218

218:                                              ; preds = %213
  %219 = load i64, ptr %NEXT_PC, align 8
  store i64 %219, ptr %PC, align 8
  %220 = add i64 %219, 5
  store i64 %220, ptr %NEXT_PC, align 8
  %221 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RCX, align 8
  store ptr %221, ptr %MEMORY, align 8
  br label %222

222:                                              ; preds = %218
  %223 = load i64, ptr %NEXT_PC, align 8
  store i64 %223, ptr %PC, align 8
  %224 = add i64 %223, 2
  store i64 %224, ptr %NEXT_PC, align 8
  %225 = load i64, ptr %RAX, align 8
  %226 = load i32, ptr %EAX, align 4
  %227 = zext i32 %226 to i64
  %228 = load ptr, ptr %MEMORY, align 8
  %conv.i.i412 = trunc i64 %225 to i32
  %xor3.i.i413 = xor i32 %226, %conv.i.i412
  %conv.i27.i414 = zext i32 %xor3.i.i413 to i64
  store i64 %conv.i27.i414, ptr %RAX, align 8
  %cf.i.i415 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i415, align 1
  %conv.i.i.i416 = trunc i32 %xor3.i.i413 to i8
  %229 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i416)
  %230 = and i8 %229, 1
  %conv.i28.i417 = xor i8 %230, 1
  %pf.i.i418 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i417, ptr %pf.i.i418, align 1
  %cmp.i.i.i419 = icmp eq i32 %xor3.i.i413, 0
  %call.i.i.i420 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i419, i32 noundef %conv.i.i412, i32 noundef %226, i32 noundef %xor3.i.i413) #18
  %conv3.i.i421 = zext i1 %call.i.i.i420 to i8
  %zf.i.i422 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i421, ptr %zf.i.i422, align 1
  %cmp.i19.i.i423 = icmp slt i32 %xor3.i.i413, 0
  %call1.i.i.i424 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i423, i32 noundef %conv.i.i412, i32 noundef %226, i32 noundef %xor3.i.i413) #18
  %conv6.i.i425 = zext i1 %call1.i.i.i424 to i8
  %sf.i.i426 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i425, ptr %sf.i.i426, align 1
  %of.i.i427 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i427, align 1
  %af.i.i428 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i429 = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i429, ptr %af.i.i428, align 1
  store ptr %228, ptr %MEMORY, align 8
  br label %231

231:                                              ; preds = %222
  %232 = load i64, ptr %NEXT_PC, align 8
  store i64 %232, ptr %PC, align 8
  %233 = add i64 %232, 3
  store i64 %233, ptr %NEXT_PC, align 8
  %234 = load i32, ptr %EDX, align 4
  %235 = zext i32 %234 to i64
  %236 = load ptr, ptr %MEMORY, align 8
  %sub.i.i303 = sub i32 %234, 3
  %cmp.i.i.i304 = icmp ult i32 %234, 3
  %call.i.i.i305 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i304, i32 noundef %234, i32 noundef 3, i32 noundef %sub.i.i303) #18
  %conv.i12.i306 = zext i1 %call.i.i.i305 to i8
  %cf.i.i307 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i306, ptr %cf.i.i307, align 1
  %conv.i.i.i.i308 = trunc i32 %sub.i.i303 to i8
  %237 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i308)
  %238 = and i8 %237, 1
  %conv.i.i.i309 = xor i8 %238, 1
  %pf.i.i.i310 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i309, ptr %pf.i.i.i310, align 1
  %xor.i.i.i.i311 = xor i32 3, %234
  %xor1.i.i.i.i312 = xor i32 %xor.i.i.i.i311, %sub.i.i303
  %239 = trunc i32 %xor1.i.i.i.i312 to i8
  %240 = lshr i8 %239, 4
  %conv2.i.i.i313 = and i8 %240, 1
  %af.i.i.i314 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i313, ptr %af.i.i.i314, align 1
  %cmp.i.i.i.i315 = icmp eq i32 %234, 3
  %call.i.i.i.i316 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i315, i32 noundef %234, i32 noundef 3, i32 noundef %sub.i.i303) #18
  %conv5.i.i.i317 = zext i1 %call.i.i.i.i316 to i8
  %zf.i.i.i318 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i317, ptr %zf.i.i.i318, align 1
  %cmp.i27.i.i.i319 = icmp slt i32 %sub.i.i303, 0
  %call1.i.i.i.i320 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i319, i32 noundef %234, i32 noundef 3, i32 noundef %sub.i.i303) #18
  %conv8.i.i.i321 = zext i1 %call1.i.i.i.i320 to i8
  %sf.i.i.i322 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i321, ptr %sf.i.i.i322, align 1
  %xor.i28.i.i.i323 = lshr i32 %xor.i.i.i.i311, 31
  %shr9.i.i.i.i324 = xor i32 %sub.i.i303, %234
  %xor3.i.i.i.i325 = lshr i32 %shr9.i.i.i.i324, 31
  %add.i.i.i.i326 = add nuw nsw i32 %xor3.i.i.i.i325, %xor.i28.i.i.i323
  %cmp.i29.i.i.i327 = icmp eq i32 %add.i.i.i.i326, 2
  %call.i30.i.i.i328 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i327, i32 noundef %234, i32 noundef 3, i32 noundef %sub.i.i303) #18
  %conv11.i.i.i329 = zext i1 %call.i30.i.i.i328 to i8
  %of.i.i.i330 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i329, ptr %of.i.i.i330, align 1
  store ptr %236, ptr %MEMORY, align 8
  br label %241

241:                                              ; preds = %231
  %242 = load i64, ptr %NEXT_PC, align 8
  store i64 %242, ptr %PC, align 8
  %243 = add i64 %242, 3
  store i64 %243, ptr %NEXT_PC, align 8
  %244 = load i32, ptr %EAX, align 4
  %245 = zext i32 %244 to i64
  %246 = load ptr, ptr %MEMORY, align 8
  %sf.i335 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %247 = load i8, ptr %sf.i335, align 1
  %tobool.i336 = icmp ne i8 %247, 0
  %of.i337 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %248 = load i8, ptr %of.i337, align 1
  %tobool4.i = icmp ne i8 %248, 0
  %cmp.i.i338 = xor i1 %tobool.i336, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i338) #19
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %245, i64 %dst.coerce.val.i
  %conv.i23.i339 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i339, ptr %RCX, align 8
  store ptr %246, ptr %MEMORY, align 8
  br label %249

249:                                              ; preds = %241
  %250 = load i64, ptr %NEXT_PC, align 8
  store i64 %250, ptr %PC, align 8
  %251 = add i64 %250, 7
  store i64 %251, ptr %NEXT_PC, align 8
  %252 = load i64, ptr %NEXT_PC, align 8
  %253 = add i64 %252, 15941
  %254 = load ptr, ptr %MEMORY, align 8
  store i64 %253, ptr %RAX, align 8
  store ptr %254, ptr %MEMORY, align 8
  br label %255

255:                                              ; preds = %249
  %256 = load i64, ptr %NEXT_PC, align 8
  store i64 %256, ptr %PC, align 8
  %257 = add i64 %256, 3
  store i64 %257, ptr %NEXT_PC, align 8
  %258 = load i32, ptr %ECX, align 4
  %259 = zext i32 %258 to i64
  %260 = load ptr, ptr %MEMORY, align 8
  %sext.i369 = shl i64 %259, 32
  %conv.i12.i370 = ashr exact i64 %sext.i369, 32
  store i64 %conv.i12.i370, ptr %RCX, align 8
  store ptr %260, ptr %MEMORY, align 8
  br label %261

261:                                              ; preds = %255
  %262 = load i64, ptr %NEXT_PC, align 8
  store i64 %262, ptr %PC, align 8
  %263 = add i64 %262, 4
  store i64 %263, ptr %NEXT_PC, align 8
  %264 = load i64, ptr %RAX, align 8
  %265 = load i64, ptr %RCX, align 8
  %266 = mul i64 %265, 8
  %267 = add i64 %264, %266
  %268 = load ptr, ptr %MEMORY, align 8
  %call.i.i367 = call i64 @__remill_read_memory_64(ptr noundef %268, i64 noundef %267) #18
  store i64 %call.i.i367, ptr %RAX, align 8
  store ptr %268, ptr %MEMORY, align 8
  br label %269

269:                                              ; preds = %261
  %270 = load i64, ptr %NEXT_PC, align 8
  store i64 %270, ptr %PC, align 8
  %271 = add i64 %270, 2
  store i64 %271, ptr %NEXT_PC, align 8
  %272 = load i64, ptr %RCX, align 8
  %273 = load i32, ptr %ECX, align 4
  %274 = zext i32 %273 to i64
  %275 = load ptr, ptr %MEMORY, align 8
  %conv.i.i395 = trunc i64 %272 to i32
  %xor3.i.i = xor i32 %273, %conv.i.i395
  %conv.i27.i396 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i396, ptr %RCX, align 8
  %cf.i.i397 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i397, align 1
  %conv.i.i.i398 = trunc i32 %xor3.i.i to i8
  %276 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i398)
  %277 = and i8 %276, 1
  %conv.i28.i399 = xor i8 %277, 1
  %pf.i.i400 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i399, ptr %pf.i.i400, align 1
  %cmp.i.i.i401 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i402 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i401, i32 noundef %conv.i.i395, i32 noundef %273, i32 noundef %xor3.i.i) #18
  %conv3.i.i403 = zext i1 %call.i.i.i402 to i8
  %zf.i.i404 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i403, ptr %zf.i.i404, align 1
  %cmp.i19.i.i405 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i406 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i405, i32 noundef %conv.i.i395, i32 noundef %273, i32 noundef %xor3.i.i) #18
  %conv6.i.i407 = zext i1 %call1.i.i.i406 to i8
  %sf.i.i408 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i407, ptr %sf.i.i408, align 1
  %of.i.i409 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i409, align 1
  %af.i.i410 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i411 = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i411, ptr %af.i.i410, align 1
  store ptr %275, ptr %MEMORY, align 8
  br label %278

278:                                              ; preds = %269
  %279 = load i64, ptr %NEXT_PC, align 8
  store i64 %279, ptr %PC, align 8
  %280 = add i64 %279, 3
  store i64 %280, ptr %NEXT_PC, align 8
  %281 = load i32, ptr %EDX, align 4
  %282 = zext i32 %281 to i64
  %283 = load ptr, ptr %MEMORY, align 8
  %sub.i.i275 = sub i32 %281, 3
  %cmp.i.i.i276 = icmp ult i32 %281, 3
  %call.i.i.i277 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i276, i32 noundef %281, i32 noundef 3, i32 noundef %sub.i.i275) #18
  %conv.i12.i278 = zext i1 %call.i.i.i277 to i8
  %cf.i.i279 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i278, ptr %cf.i.i279, align 1
  %conv.i.i.i.i280 = trunc i32 %sub.i.i275 to i8
  %284 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i280)
  %285 = and i8 %284, 1
  %conv.i.i.i281 = xor i8 %285, 1
  %pf.i.i.i282 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i281, ptr %pf.i.i.i282, align 1
  %xor.i.i.i.i283 = xor i32 3, %281
  %xor1.i.i.i.i284 = xor i32 %xor.i.i.i.i283, %sub.i.i275
  %286 = trunc i32 %xor1.i.i.i.i284 to i8
  %287 = lshr i8 %286, 4
  %conv2.i.i.i285 = and i8 %287, 1
  %af.i.i.i286 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i285, ptr %af.i.i.i286, align 1
  %cmp.i.i.i.i287 = icmp eq i32 %281, 3
  %call.i.i.i.i288 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i287, i32 noundef %281, i32 noundef 3, i32 noundef %sub.i.i275) #18
  %conv5.i.i.i289 = zext i1 %call.i.i.i.i288 to i8
  %zf.i.i.i290 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i289, ptr %zf.i.i.i290, align 1
  %cmp.i27.i.i.i291 = icmp slt i32 %sub.i.i275, 0
  %call1.i.i.i.i292 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i291, i32 noundef %281, i32 noundef 3, i32 noundef %sub.i.i275) #18
  %conv8.i.i.i293 = zext i1 %call1.i.i.i.i292 to i8
  %sf.i.i.i294 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i293, ptr %sf.i.i.i294, align 1
  %xor.i28.i.i.i295 = lshr i32 %xor.i.i.i.i283, 31
  %shr9.i.i.i.i296 = xor i32 %sub.i.i275, %281
  %xor3.i.i.i.i297 = lshr i32 %shr9.i.i.i.i296, 31
  %add.i.i.i.i298 = add nuw nsw i32 %xor3.i.i.i.i297, %xor.i28.i.i.i295
  %cmp.i29.i.i.i299 = icmp eq i32 %add.i.i.i.i298, 2
  %call.i30.i.i.i300 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i299, i32 noundef %281, i32 noundef 3, i32 noundef %sub.i.i275) #18
  %conv11.i.i.i301 = zext i1 %call.i30.i.i.i300 to i8
  %of.i.i.i302 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i301, ptr %of.i.i.i302, align 1
  store ptr %283, ptr %MEMORY, align 8
  br label %288

288:                                              ; preds = %278
  %289 = load i64, ptr %NEXT_PC, align 8
  store i64 %289, ptr %PC, align 8
  %290 = add i64 %289, 4
  store i64 %290, ptr %NEXT_PC, align 8
  %291 = load i64, ptr %RCX, align 8
  %292 = load ptr, ptr %MEMORY, align 8
  %sf.i340 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %293 = load i8, ptr %sf.i340, align 1
  %tobool.i341 = icmp ne i8 %293, 0
  %of.i342 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %294 = load i8, ptr %of.i342, align 1
  %tobool4.i343 = icmp ne i8 %294, 0
  %cmp.i.i344 = xor i1 %tobool.i341, %tobool4.i343
  %call5.i345 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i344) #19
  %dst.coerce.val.i346 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i345, i64 %291, i64 %dst.coerce.val.i346
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %292, ptr %MEMORY, align 8
  br label %295

295:                                              ; preds = %288
  %296 = load i64, ptr %NEXT_PC, align 8
  store i64 %296, ptr %PC, align 8
  %297 = add i64 %296, 3
  store i64 %297, ptr %NEXT_PC, align 8
  %298 = load i64, ptr %RAX, align 8
  %299 = load i64, ptr %RCX, align 8
  %300 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %298, %299
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i204 = icmp ult i64 %298, %299
  %call.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i204, i64 noundef %298, i64 noundef %299, i64 noundef %sub.i.i) #18
  %conv.i.i206 = zext i1 %call.i.i.i205 to i8
  %cf.i.i207 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i206, ptr %cf.i.i207, align 1
  %conv.i.i.i.i208 = trunc i64 %sub.i.i to i8
  %301 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i208)
  %302 = and i8 %301, 1
  %conv.i.i.i209 = xor i8 %302, 1
  %pf.i.i.i210 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i209, ptr %pf.i.i.i210, align 1
  %xor.i.i.i.i211 = xor i64 %299, %298
  %xor1.i.i.i.i212 = xor i64 %xor.i.i.i.i211, %sub.i.i
  %303 = trunc i64 %xor1.i.i.i.i212 to i8
  %304 = lshr i8 %303, 4
  %conv2.i.i.i213 = and i8 %304, 1
  %af.i.i.i214 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i213, ptr %af.i.i.i214, align 1
  %cmp.i.i.i.i215 = icmp eq i64 %298, %299
  %call.i.i.i.i216 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i215, i64 noundef %298, i64 noundef %299, i64 noundef %sub.i.i) #18
  %conv5.i.i.i217 = zext i1 %call.i.i.i.i216 to i8
  %zf.i.i.i218 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i217, ptr %zf.i.i.i218, align 1
  %cmp.i27.i.i.i219 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i220 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i219, i64 noundef %298, i64 noundef %299, i64 noundef %sub.i.i) #18
  %conv8.i.i.i221 = zext i1 %call1.i.i.i.i220 to i8
  %sf.i.i.i222 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i221, ptr %sf.i.i.i222, align 1
  %xor.i28.i.i.i223 = lshr i64 %xor.i.i.i.i211, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %298
  %xor3.i.i.i.i224 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i225 = add nuw nsw i64 %xor3.i.i.i.i224, %xor.i28.i.i.i223
  %cmp.i29.i.i.i226 = icmp eq i64 %add.i.i.i.i225, 2
  %call.i30.i.i.i227 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i226, i64 noundef %298, i64 noundef %299, i64 noundef %sub.i.i) #18
  %conv11.i.i.i228 = zext i1 %call.i30.i.i.i227 to i8
  %of.i.i.i229 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i228, ptr %of.i.i.i229, align 1
  store ptr %300, ptr %MEMORY, align 8
  br label %305

305:                                              ; preds = %295
  %306 = load i64, ptr %NEXT_PC, align 8
  store i64 %306, ptr %PC, align 8
  %307 = add i64 %306, 4
  store i64 %307, ptr %NEXT_PC, align 8
  %308 = load i64, ptr %RBP, align 8
  %309 = sub i64 %308, 24
  %310 = load i64, ptr %RAX, align 8
  %311 = load ptr, ptr %MEMORY, align 8
  %call.i.i351 = call ptr @__remill_write_memory_64(ptr noundef %311, i64 noundef %309, i64 noundef %310) #18
  store ptr %call.i.i351, ptr %MEMORY, align 8
  br label %312

312:                                              ; preds = %305
  %313 = load i64, ptr %NEXT_PC, align 8
  store i64 %313, ptr %PC, align 8
  %314 = add i64 %313, 7
  store i64 %314, ptr %NEXT_PC, align 8
  %315 = load i64, ptr %NEXT_PC, align 8
  %316 = add i64 %315, 15695
  %317 = load ptr, ptr %MEMORY, align 8
  %call.i.i366 = call i64 @__remill_read_memory_64(ptr noundef %317, i64 noundef %316) #18
  store i64 %call.i.i366, ptr %RAX, align 8
  store ptr %317, ptr %MEMORY, align 8
  br label %318

318:                                              ; preds = %312
  %319 = load i64, ptr %NEXT_PC, align 8
  store i64 %319, ptr %PC, align 8
  %320 = add i64 %319, 2
  store i64 %320, ptr %NEXT_PC, align 8
  %321 = load i64, ptr %RAX, align 8
  %322 = load ptr, ptr %MEMORY, align 8
  %call.i.i359 = call i32 @__remill_read_memory_32(ptr noundef %322, i64 noundef %321) #18
  %conv.i.i360 = zext i32 %call.i.i359 to i64
  store i64 %conv.i.i360, ptr %RDX, align 8
  store ptr %322, ptr %MEMORY, align 8
  br label %323

323:                                              ; preds = %318
  %324 = load i64, ptr %NEXT_PC, align 8
  store i64 %324, ptr %PC, align 8
  %325 = add i64 %324, 7
  store i64 %325, ptr %NEXT_PC, align 8
  %326 = load i64, ptr %NEXT_PC, align 8
  %327 = add i64 %326, 15406
  %328 = load ptr, ptr %MEMORY, align 8
  %call.i.i365 = call i64 @__remill_read_memory_64(ptr noundef %328, i64 noundef %327) #18
  store i64 %call.i.i365, ptr %RAX, align 8
  store ptr %328, ptr %MEMORY, align 8
  br label %329

329:                                              ; preds = %323
  %330 = load i64, ptr %NEXT_PC, align 8
  store i64 %330, ptr %PC, align 8
  %331 = add i64 %330, 3
  store i64 %331, ptr %NEXT_PC, align 8
  %332 = load i64, ptr %RAX, align 8
  %333 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %333, i64 noundef %332) #18
  %sub.i.i230 = sub i32 %call.i.i, 10
  %cmp.i.i.i231 = icmp ult i32 %call.i.i, 10
  %call.i.i.i232 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i231, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #18
  %conv.i9.i = zext i1 %call.i.i.i232 to i8
  %cf.i.i233 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i233, align 1
  %conv.i.i.i.i234 = trunc i32 %sub.i.i230 to i8
  %334 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i234)
  %335 = and i8 %334, 1
  %conv.i.i.i235 = xor i8 %335, 1
  %pf.i.i.i236 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i235, ptr %pf.i.i.i236, align 1
  %xor.i.i.i.i237 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i238 = xor i32 %xor.i.i.i.i237, %sub.i.i230
  %336 = trunc i32 %xor1.i.i.i.i238 to i8
  %337 = lshr i8 %336, 4
  %conv2.i.i.i239 = and i8 %337, 1
  %af.i.i.i240 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i239, ptr %af.i.i.i240, align 1
  %cmp.i.i.i.i241 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i242 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i241, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #18
  %conv5.i.i.i243 = zext i1 %call.i.i.i.i242 to i8
  %zf.i.i.i244 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i243, ptr %zf.i.i.i244, align 1
  %cmp.i27.i.i.i245 = icmp slt i32 %sub.i.i230, 0
  %call1.i.i.i.i246 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i245, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #18
  %conv8.i.i.i247 = zext i1 %call1.i.i.i.i246 to i8
  %sf.i.i.i248 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i247, ptr %sf.i.i.i248, align 1
  %xor.i28.i.i.i249 = lshr i32 %xor.i.i.i.i237, 31
  %shr9.i.i.i.i250 = xor i32 %sub.i.i230, %call.i.i
  %xor3.i.i.i.i251 = lshr i32 %shr9.i.i.i.i250, 31
  %add.i.i.i.i252 = add nuw nsw i32 %xor3.i.i.i.i251, %xor.i28.i.i.i249
  %cmp.i29.i.i.i253 = icmp eq i32 %add.i.i.i.i252, 2
  %call.i30.i.i.i254 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i253, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #18
  %conv11.i.i.i255 = zext i1 %call.i30.i.i.i254 to i8
  %of.i.i.i256 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i255, ptr %of.i.i.i256, align 1
  store ptr %333, ptr %MEMORY, align 8
  br label %338

338:                                              ; preds = %329
  %339 = load i64, ptr %NEXT_PC, align 8
  store i64 %339, ptr %PC, align 8
  %340 = add i64 %339, 3
  store i64 %340, ptr %NEXT_PC, align 8
  %341 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %342 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %342, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %343 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %343, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %341, ptr %MEMORY, align 8
  br label %344

344:                                              ; preds = %338
  %345 = load i64, ptr %NEXT_PC, align 8
  store i64 %345, ptr %PC, align 8
  %346 = add i64 %345, 2
  store i64 %346, ptr %NEXT_PC, align 8
  %347 = load i32, ptr %EDX, align 4
  %348 = zext i32 %347 to i64
  %349 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %348, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %349, ptr %MEMORY, align 8
  br label %350

350:                                              ; preds = %344
  %351 = load i64, ptr %NEXT_PC, align 8
  store i64 %351, ptr %PC, align 8
  %352 = add i64 %351, 3
  store i64 %352, ptr %NEXT_PC, align 8
  %353 = load i64, ptr %RCX, align 8
  %354 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %353 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %355 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %355, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %356 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %357 = and i8 %356, 1
  %conv.i.i.i = xor i8 %357, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %358 = trunc i32 %xor1.i.i.i.i to i8
  %359 = lshr i8 %358, 4
  %conv2.i.i.i = and i8 %359, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %354, ptr %MEMORY, align 8
  br label %360

360:                                              ; preds = %350
  %361 = load i64, ptr %NEXT_PC, align 8
  store i64 %361, ptr %PC, align 8
  %362 = add i64 %361, 3
  store i64 %362, ptr %NEXT_PC, align 8
  %363 = load i64, ptr %RCX, align 8
  %364 = load i32, ptr %EDX, align 4
  %365 = zext i32 %364 to i64
  %366 = load ptr, ptr %MEMORY, align 8
  %conv.i.i331 = trunc i64 %363 to i32
  %sext.i = shl i64 %363, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %365, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %367 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i332 = icmp ult i64 %367, -4294967296
  %call.i.i.i333 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i332, i32 noundef %conv.i.i331, i32 noundef %364, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i333 to i8
  %cf.i.i334 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i334, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %366, ptr %MEMORY, align 8
  br label %368

368:                                              ; preds = %360
  %369 = load i64, ptr %NEXT_PC, align 8
  store i64 %369, ptr %PC, align 8
  %370 = add i64 %369, 3
  store i64 %370, ptr %NEXT_PC, align 8
  %371 = load i64, ptr %RCX, align 8
  %372 = load ptr, ptr %MEMORY, align 8
  %conv.i.i371 = trunc i64 %371 to i32
  %and3.i.i = and i32 1, %conv.i.i371
  %conv.i22.i372 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i372, ptr %RCX, align 8
  %cf.i.i373 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i373, align 1
  %conv.i.i.i374 = trunc i32 %and3.i.i to i8
  %373 = and i8 %conv.i.i.i374, 1
  %conv.i23.i375 = xor i8 %373, 1
  %pf.i.i376 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i375, ptr %pf.i.i376, align 1
  %cmp.i.i.i377 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i378 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i377, i32 noundef %conv.i.i371, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i378 to i8
  %zf.i.i379 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i379, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i371, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i380 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i380, align 1
  %of.i.i381 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i381, align 1
  %af.i.i382 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i382, align 1
  store ptr %372, ptr %MEMORY, align 8
  br label %374

374:                                              ; preds = %368
  %375 = load i64, ptr %NEXT_PC, align 8
  store i64 %375, ptr %PC, align 8
  %376 = add i64 %375, 3
  store i64 %376, ptr %NEXT_PC, align 8
  %377 = load i32, ptr %ECX, align 4
  %378 = zext i32 %377 to i64
  %379 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i257 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %377, i32 noundef 0, i32 noundef %377) #18
  %conv.i12.i = zext i1 %call.i.i.i257 to i8
  %cf.i.i258 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i258, align 1
  %conv.i.i.i.i259 = trunc i32 %377 to i8
  %380 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i259)
  %381 = and i8 %380, 1
  %conv.i.i.i260 = xor i8 %381, 1
  %pf.i.i.i261 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i260, ptr %pf.i.i.i261, align 1
  %af.i.i.i262 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i262, align 1
  %cmp.i.i.i.i263 = icmp eq i32 %377, 0
  %call.i.i.i.i264 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i263, i32 noundef %377, i32 noundef 0, i32 noundef %377) #18
  %conv5.i.i.i265 = zext i1 %call.i.i.i.i264 to i8
  %zf.i.i.i266 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i265, ptr %zf.i.i.i266, align 1
  %cmp.i27.i.i.i267 = icmp slt i32 %377, 0
  %call1.i.i.i.i268 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i267, i32 noundef %377, i32 noundef 0, i32 noundef %377) #18
  %conv8.i.i.i269 = zext i1 %call1.i.i.i.i268 to i8
  %sf.i.i.i270 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i269, ptr %sf.i.i.i270, align 1
  %xor.i28.i.i.i271 = lshr i32 %377, 31
  %call.i30.i.i.i272 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %377, i32 noundef 0, i32 noundef %377) #18
  %conv11.i.i.i273 = zext i1 %call.i30.i.i.i272 to i8
  %of.i.i.i274 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i273, ptr %of.i.i.i274, align 1
  store ptr %379, ptr %MEMORY, align 8
  br label %382

382:                                              ; preds = %374
  %383 = load i64, ptr %NEXT_PC, align 8
  store i64 %383, ptr %PC, align 8
  %384 = add i64 %383, 3
  store i64 %384, ptr %NEXT_PC, align 8
  %385 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %386 = load i8, ptr %zf.i, align 1
  store i8 %386, ptr %CL, align 1
  store ptr %385, ptr %MEMORY, align 8
  br label %387

387:                                              ; preds = %382
  %388 = load i64, ptr %NEXT_PC, align 8
  store i64 %388, ptr %PC, align 8
  %389 = add i64 %388, 2
  store i64 %389, ptr %NEXT_PC, align 8
  %390 = load i8, ptr %AL, align 1
  %391 = zext i8 %390 to i64
  %392 = load i8, ptr %CL, align 1
  %393 = zext i8 %392 to i64
  %394 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %393, %391
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i383 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i383, align 1
  %395 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %396 = and i8 %395, 1
  %conv.i27.i = xor i8 %396, 1
  %pf.i.i384 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i384, align 1
  %397 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i385 = and i32 %397, 255
  %cmp.i.i.i386 = icmp eq i8 %or3.i.i, 0
  %398 = trunc i64 %391 to i32
  %conv1.i.i.i = and i32 %398, 255
  %399 = trunc i64 %393 to i32
  %conv2.i.i.i387 = and i32 %399, 255
  %call.i.i.i388 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i386, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i387, i32 noundef %conv.i.i.i385) #18
  %conv3.i.i389 = zext i1 %call.i.i.i388 to i8
  %zf.i.i390 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i389, ptr %zf.i.i390, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i387, i32 noundef %conv.i.i.i385) #18
  %conv6.i.i391 = zext i1 %call4.i.i.i to i8
  %sf.i.i392 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i391, ptr %sf.i.i392, align 1
  %of.i.i393 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i393, align 1
  %af.i.i394 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i394, align 1
  store ptr %394, ptr %MEMORY, align 8
  br label %400

400:                                              ; preds = %387
  %401 = load i64, ptr %NEXT_PC, align 8
  store i64 %401, ptr %PC, align 8
  %402 = add i64 %401, 2
  store i64 %402, ptr %NEXT_PC, align 8
  %403 = load i8, ptr %AL, align 1
  %404 = zext i8 %403 to i64
  %405 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %404
  %and3.i.i430 = trunc i64 %and3.i15.i to i8
  %cf.i.i431 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i431, align 1
  %406 = and i8 %and3.i.i430, 1
  %conv.i14.i = xor i8 %406, 1
  %pf.i.i432 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i432, align 1
  %407 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i433 = and i32 %407, 255
  %cmp.i.i.i434 = icmp eq i8 %and3.i.i430, 0
  %408 = trunc i64 %404 to i32
  %conv1.i.i.i435 = and i32 %408, 255
  %call.i.i.i436 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i434, i32 noundef %conv1.i.i.i435, i32 noundef 1, i32 noundef %conv.i.i.i433) #18
  %conv3.i.i437 = zext i1 %call.i.i.i436 to i8
  %zf.i.i438 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i437, ptr %zf.i.i438, align 1
  %call4.i.i.i439 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i435, i32 noundef 1, i32 noundef %conv.i.i.i433) #18
  %conv6.i.i440 = zext i1 %call4.i.i.i439 to i8
  %sf.i.i441 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i440, ptr %sf.i.i441, align 1
  %of.i.i442 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i442, align 1
  %af.i.i443 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i443, align 1
  store ptr %405, ptr %MEMORY, align 8
  br label %409

409:                                              ; preds = %400
  %410 = load i64, ptr %NEXT_PC, align 8
  store i64 %410, ptr %PC, align 8
  %411 = add i64 %410, 6
  store i64 %411, ptr %NEXT_PC, align 8
  %412 = load i64, ptr %NEXT_PC, align 8
  %413 = add i64 %412, 5
  %414 = load i64, ptr %NEXT_PC, align 8
  %415 = load ptr, ptr %MEMORY, align 8
  %zf.i347 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %416 = load i8, ptr %zf.i347, align 1
  %tobool.not.i = icmp eq i8 %416, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i348 = select i1 %call9.i, i64 %413, i64 %414
  store i64 %cond1.i.i348, ptr %NEXT_PC, align 8
  store ptr %415, ptr %MEMORY, align 8
  %417 = load i64, ptr %NEXT_PC, align 8
  store i64 %417, ptr %PC, align 8
  %418 = load ptr, ptr %MEMORY, align 8
  ret ptr %418
}

define ptr @BB_2278(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_227e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 1) #18
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 15857
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %21, ptr %rip.i, align 8
  store i64 %21, ptr %NEXT_PC, align 8
  store ptr %22, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

define ptr @BB_2291(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 15592
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 15311
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_24d5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 14892
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 15099
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_22c7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i10 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i10, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 56
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i9 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #18
  store i64 %call.i.i9, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 32
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i8 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #18
  store i64 %call.i.i8, ptr %RDI, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 64
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i7 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #18
  store i64 %call.i.i7, ptr %RCX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RCX, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %29, i64 noundef %28) #18
  store i64 %call.i.i6, ptr %RSI, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %25
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 4
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RSI, align 8
  %34 = add i64 %33, 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %35, i64 noundef %34) #18
  store i64 %call.i.i5, ptr %RSI, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %30
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 3
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RDX, align 8
  %40 = load i64, ptr %RSI, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_64(ptr noundef %41, i64 noundef %39, i64 noundef %40) #18
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 3
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RCX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %46, i64 noundef %45) #18
  store i64 %call.i.i4, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 4
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RCX, align 8
  %51 = add i64 %50, 16
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %52, i64 noundef %51) #18
  store i64 %call.i.i3, ptr %RCX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load i64, ptr %RCX, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_64(ptr noundef %58, i64 noundef %56, i64 noundef %57) #18
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 5
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %NEXT_PC, align 8
  %63 = sub i64 %62, 640
  %64 = load i64, ptr %NEXT_PC, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %66 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %66, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %65, i64 noundef %sub.i.i, i64 noundef %64) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %63, ptr %rip.i, align 8
  store i64 %63, ptr %NEXT_PC, align 8
  store i64 %64, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %67 = load ptr, ptr %MEMORY, align 8
  ret ptr %67
}

define ptr @BB_250b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i56 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i56, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i53 = zext i32 %call.i.i52 to i64
  store i64 %conv.i.i53, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 100
  %17 = load i32, ptr %EAX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_32(ptr noundef %19, i64 noundef %16, i32 noundef %17) #18
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %12
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 7
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = add i64 %23, 14653
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i55 = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %24) #18
  store i64 %call.i.i55, ptr %RAX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RAX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #18
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 14956
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %36, i64 noundef %35) #18
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %41, i64 noundef %40) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %43 = and i8 %42, 1
  %conv.i.i.i5 = xor i8 %43, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %44 = trunc i32 %xor1.i.i.i.i8 to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i9 = and i8 %45, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %41, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %37
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %50 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %50, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %51 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %51, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EDX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %56, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RCX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %61 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %63 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %63, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %64 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %65 = and i8 %64, 1
  %conv.i.i.i = xor i8 %65, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %66 = trunc i32 %xor1.i.i.i.i to i8
  %67 = lshr i8 %66, 4
  %conv2.i.i.i = and i8 %67, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RCX, align 8
  %72 = load i32, ptr %EDX, align 4
  %73 = zext i32 %72 to i64
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %71 to i32
  %sext.i = shl i64 %71, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %73, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %75 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %75, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %72, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %68
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %conv.i.i57 = trunc i64 %79 to i32
  %and3.i.i = and i32 1, %conv.i.i57
  %conv.i22.i58 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i58, ptr %RCX, align 8
  %cf.i.i59 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i59, align 1
  %conv.i.i.i60 = trunc i32 %and3.i.i to i8
  %81 = and i8 %conv.i.i.i60, 1
  %conv.i23.i61 = xor i8 %81, 1
  %pf.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i61, ptr %pf.i.i62, align 1
  %cmp.i.i.i63 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i63, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i64 to i8
  %zf.i.i65 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i65, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i66, align 1
  %of.i.i67 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i67, align 1
  %af.i.i68 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i68, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %85 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %89 = and i8 %88, 1
  %conv.i.i.i29 = xor i8 %89, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %85, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %85, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %85, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %82
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 3
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %94 = load i8, ptr %zf.i, align 1
  store i8 %94, ptr %CL, align 1
  store ptr %93, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %90
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i8, ptr %AL, align 1
  %99 = zext i8 %98 to i64
  %100 = load i8, ptr %CL, align 1
  %101 = zext i8 %100 to i64
  %102 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %101, %99
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i69 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i69, align 1
  %103 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %104 = and i8 %103, 1
  %conv.i27.i = xor i8 %104, 1
  %pf.i.i70 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i70, align 1
  %105 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i71 = and i32 %105, 255
  %cmp.i.i.i72 = icmp eq i8 %or3.i.i, 0
  %106 = trunc i64 %99 to i32
  %conv1.i.i.i = and i32 %106, 255
  %107 = trunc i64 %101 to i32
  %conv2.i.i.i73 = and i32 %107, 255
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i72, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #18
  %conv3.i.i75 = zext i1 %call.i.i.i74 to i8
  %zf.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i75, ptr %zf.i.i76, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #18
  %conv6.i.i77 = zext i1 %call4.i.i.i to i8
  %sf.i.i78 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i77, ptr %sf.i.i78, align 1
  %of.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i79, align 1
  %af.i.i80 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i80, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %95
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 2
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i8, ptr %AL, align 1
  %112 = zext i8 %111 to i64
  %113 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %112
  %and3.i.i81 = trunc i64 %and3.i15.i to i8
  %cf.i.i82 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i82, align 1
  %114 = and i8 %and3.i.i81, 1
  %conv.i14.i = xor i8 %114, 1
  %pf.i.i83 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i83, align 1
  %115 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i84 = and i32 %115, 255
  %cmp.i.i.i85 = icmp eq i8 %and3.i.i81, 0
  %116 = trunc i64 %112 to i32
  %conv1.i.i.i86 = and i32 %116, 255
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i85, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #18
  %conv3.i.i88 = zext i1 %call.i.i.i87 to i8
  %zf.i.i89 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i88, ptr %zf.i.i89, align 1
  %call4.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #18
  %conv6.i.i91 = zext i1 %call4.i.i.i90 to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i91, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i94, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %108
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 6
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  %121 = add i64 %120, 5
  %122 = load i64, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %124, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %121, i64 %122
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %123, ptr %MEMORY, align 8
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  ret ptr %126
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_time(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_time(ptr, i64, ptr) #2

define ptr @BB_254a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 100
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #18
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %16, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #18
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %12
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #18
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %22, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %20, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

define ptr @BB_22f0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EAX, align 4
  %5 = zext i32 %4 to i64
  %6 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %5, 4294967295
  store i64 %conv.i11.i, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 5
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = sub i64 %10, 679
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %14, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i, i64 noundef %12) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %11, ptr %rip.i, align 8
  store i64 %11, ptr %NEXT_PC, align 8
  store i64 %12, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  ret ptr %15
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_srand(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_srand(ptr, i64, ptr) #4

define ptr @BB_22f7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i6, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #18
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i4, ptr %RDI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %22, i64 noundef %21) #18
  store i64 %call.i.i3, ptr %RSI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 7
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %NEXT_PC, align 8
  %27 = add i64 %26, 15700
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %28, i64 noundef %27) #18
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %23
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 6
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %32, 1026752269
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %32, 1026752269
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i64 noundef %32, i64 noundef 1026752269, i64 noundef %sub.i.i) #18
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %sub.i.i to i8
  %34 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %35 = and i8 %34, 1
  %conv.i.i.i = xor i8 %35, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 1026752269, %32
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %sub.i.i
  %36 = trunc i64 %xor1.i.i.i.i to i8
  %37 = lshr i8 %36, 4
  %conv2.i.i.i = and i8 %37, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %32, 1026752269
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %32, i64 noundef 1026752269, i64 noundef %sub.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %32, i64 noundef 1026752269, i64 noundef %sub.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %32
  %xor3.i.i.i.i = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %32, i64 noundef 1026752269, i64 noundef %sub.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %33, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %29
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 2
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load i64, ptr %NEXT_PC, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %44 = load i64, ptr %rsp.i, align 8
  %sub.i.i1 = add i64 %44, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %43, i64 noundef %sub.i.i1, i64 noundef %42) #18
  store i64 %sub.i.i1, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %41, ptr %rip.i, align 8
  store i64 %41, ptr %NEXT_PC, align 8
  store i64 %42, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %45 = load ptr, ptr %MEMORY, align 8
  ret ptr %45
}

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #5 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_check_anagram(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_check_anagram(ptr, i64, ptr) #5

define ptr @BB_2314(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EAX, align 4
  %5 = zext i32 %4 to i64
  %6 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i142 = and i64 %5, 4294967295
  store i64 %conv.i11.i142, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 40
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i150 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #18
  store i64 %call.i.i150, ptr %RAX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i32, ptr %ECX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i140 = call ptr @__remill_write_memory_32(ptr noundef %19, i64 noundef %16, i32 noundef %17) #18
  store ptr %call.i.i140, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %13
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 2
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RAX, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i145 = call i32 @__remill_read_memory_32(ptr noundef %24, i64 noundef %23) #18
  %conv.i.i146 = zext i32 %call.i.i145 to i64
  store i64 %conv.i.i146, ptr %RDX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %20
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 5
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  store i64 4, ptr %RCX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %25
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 5
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  store i64 3, ptr %RAX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %29
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %36, 1
  %cmp.i.i.i101 = icmp ult i32 %36, 1
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %36, i32 noundef 1, i32 noundef %sub.i.i100) #18
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %39 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %40 = and i8 %39, 1
  %conv.i.i.i106 = xor i8 %40, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 1, %36
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %41 = trunc i32 %xor1.i.i.i.i109 to i8
  %42 = lshr i8 %41, 4
  %conv2.i.i.i110 = and i8 %42, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %36, 1
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %36, i32 noundef 1, i32 noundef %sub.i.i100) #18
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %36, i32 noundef 1, i32 noundef %sub.i.i100) #18
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %36
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %36, i32 noundef 1, i32 noundef %sub.i.i100) #18
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %38, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %33
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 3
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i32, ptr %EAX, align 4
  %47 = zext i32 %46 to i64
  %48 = load ptr, ptr %MEMORY, align 8
  %zf.i132 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %49 = load i8, ptr %zf.i132, align 1
  %tobool.i133 = icmp ne i8 %49, 0
  %call.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i133) #19
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call.i, i64 %47, i64 %dst.coerce.val.i
  %conv.i19.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i19.i, ptr %RCX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %43
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 7
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = add i64 %53, 15675
  %55 = load ptr, ptr %MEMORY, align 8
  store i64 %54, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 3
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i32, ptr %ECX, align 4
  %60 = zext i32 %59 to i64
  %61 = load ptr, ptr %MEMORY, align 8
  %sext.i151 = shl i64 %60, 32
  %conv.i12.i152 = ashr exact i64 %sext.i151, 32
  store i64 %conv.i12.i152, ptr %RCX, align 8
  store ptr %61, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %56
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 4
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RAX, align 8
  %66 = load i64, ptr %RCX, align 8
  %67 = mul i64 %66, 8
  %68 = add i64 %65, %67
  %69 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i64 @__remill_read_memory_64(ptr noundef %69, i64 noundef %68) #18
  store i64 %call.i.i149, ptr %RAX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %62
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 2
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RCX, align 8
  %74 = load i32, ptr %ECX, align 4
  %75 = zext i32 %74 to i64
  %76 = load ptr, ptr %MEMORY, align 8
  %conv.i.i177 = trunc i64 %73 to i32
  %xor3.i.i = xor i32 %74, %conv.i.i177
  %conv.i27.i178 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i178, ptr %RCX, align 8
  %cf.i.i179 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i179, align 1
  %conv.i.i.i180 = trunc i32 %xor3.i.i to i8
  %77 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i180)
  %78 = and i8 %77, 1
  %conv.i28.i181 = xor i8 %78, 1
  %pf.i.i182 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i181, ptr %pf.i.i182, align 1
  %cmp.i.i.i183 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i184 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i183, i32 noundef %conv.i.i177, i32 noundef %74, i32 noundef %xor3.i.i) #18
  %conv3.i.i185 = zext i1 %call.i.i.i184 to i8
  %zf.i.i186 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i185, ptr %zf.i.i186, align 1
  %cmp.i19.i.i187 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i188 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i187, i32 noundef %conv.i.i177, i32 noundef %74, i32 noundef %xor3.i.i) #18
  %conv6.i.i189 = zext i1 %call1.i.i.i188 to i8
  %sf.i.i190 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i189, ptr %sf.i.i190, align 1
  %of.i.i191 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i191, align 1
  %af.i.i192 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i193 = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i193, ptr %af.i.i192, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %79

79:                                               ; preds = %70
  %80 = load i64, ptr %NEXT_PC, align 8
  store i64 %80, ptr %PC, align 8
  %81 = add i64 %80, 3
  store i64 %81, ptr %NEXT_PC, align 8
  %82 = load i32, ptr %EDX, align 4
  %83 = zext i32 %82 to i64
  %84 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %82, 1
  %cmp.i.i.i73 = icmp ult i32 %82, 1
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %82, i32 noundef 1, i32 noundef %sub.i.i72) #18
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %85 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %86 = and i8 %85, 1
  %conv.i.i.i78 = xor i8 %86, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 1, %82
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %87 = trunc i32 %xor1.i.i.i.i81 to i8
  %88 = lshr i8 %87, 4
  %conv2.i.i.i82 = and i8 %88, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %82, 1
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %82, i32 noundef 1, i32 noundef %sub.i.i72) #18
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %82, i32 noundef 1, i32 noundef %sub.i.i72) #18
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %82
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %82, i32 noundef 1, i32 noundef %sub.i.i72) #18
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %84, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %79
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 4
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RCX, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %zf.i134 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %94 = load i8, ptr %zf.i134, align 1
  %tobool.i135 = icmp ne i8 %94, 0
  %call.i136 = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i135) #19
  %dst.coerce.val.i137 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call.i136, i64 %92, i64 %dst.coerce.val.i137
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %89
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 3
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %RAX, align 8
  %99 = load i64, ptr %RCX, align 8
  %100 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %98, %99
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %98, %99
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %98, i64 noundef %99, i64 noundef %sub.i.i) #18
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %101 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %102 = and i8 %101, 1
  %conv.i.i.i6 = xor i8 %102, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %99, %98
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %103 = trunc i64 %xor1.i.i.i.i9 to i8
  %104 = lshr i8 %103, 4
  %conv2.i.i.i10 = and i8 %104, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %98, %99
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %98, i64 noundef %99, i64 noundef %sub.i.i) #18
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %98, i64 noundef %99, i64 noundef %sub.i.i) #18
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %98
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %98, i64 noundef %99, i64 noundef %sub.i.i) #18
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %100, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %95
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 4
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RBP, align 8
  %109 = sub i64 %108, 80
  %110 = load i64, ptr %RAX, align 8
  %111 = load ptr, ptr %MEMORY, align 8
  %call.i.i141 = call ptr @__remill_write_memory_64(ptr noundef %111, i64 noundef %109, i64 noundef %110) #18
  store ptr %call.i.i141, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %105
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 7
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %NEXT_PC, align 8
  %116 = add i64 %115, 15413
  %117 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call i64 @__remill_read_memory_64(ptr noundef %117, i64 noundef %116) #18
  store i64 %call.i.i148, ptr %RAX, align 8
  store ptr %117, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %112
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 2
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %RAX, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %call.i.i143 = call i32 @__remill_read_memory_32(ptr noundef %122, i64 noundef %121) #18
  %conv.i.i144 = zext i32 %call.i.i143 to i64
  store i64 %conv.i.i144, ptr %RDX, align 8
  store ptr %122, ptr %MEMORY, align 8
  br label %123

123:                                              ; preds = %118
  %124 = load i64, ptr %NEXT_PC, align 8
  store i64 %124, ptr %PC, align 8
  %125 = add i64 %124, 7
  store i64 %125, ptr %NEXT_PC, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  %127 = add i64 %126, 15132
  %128 = load ptr, ptr %MEMORY, align 8
  %call.i.i147 = call i64 @__remill_read_memory_64(ptr noundef %128, i64 noundef %127) #18
  store i64 %call.i.i147, ptr %RAX, align 8
  store ptr %128, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %123
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 3
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %RAX, align 8
  %133 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %133, i64 noundef %132) #18
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %134 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %135 = and i8 %134, 1
  %conv.i.i.i32 = xor i8 %135, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %136 = trunc i32 %xor1.i.i.i.i35 to i8
  %137 = lshr i8 %136, 4
  %conv2.i.i.i36 = and i8 %137, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #18
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %133, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %129
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 3
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %142 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %142, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %143 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %143, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %141, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %138
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 2
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i32, ptr %EDX, align 4
  %148 = zext i32 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %148, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %149, ptr %MEMORY, align 8
  br label %150

150:                                              ; preds = %144
  %151 = load i64, ptr %NEXT_PC, align 8
  store i64 %151, ptr %PC, align 8
  %152 = add i64 %151, 3
  store i64 %152, ptr %NEXT_PC, align 8
  %153 = load i64, ptr %RCX, align 8
  %154 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %153 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %155 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %155, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %156 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %157 = and i8 %156, 1
  %conv.i.i.i = xor i8 %157, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %158 = trunc i32 %xor1.i.i.i.i to i8
  %159 = lshr i8 %158, 4
  %conv2.i.i.i = and i8 %159, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %154, ptr %MEMORY, align 8
  br label %160

160:                                              ; preds = %150
  %161 = load i64, ptr %NEXT_PC, align 8
  store i64 %161, ptr %PC, align 8
  %162 = add i64 %161, 3
  store i64 %162, ptr %NEXT_PC, align 8
  %163 = load i64, ptr %RCX, align 8
  %164 = load i32, ptr %EDX, align 4
  %165 = zext i32 %164 to i64
  %166 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %163 to i32
  %sext.i = shl i64 %163, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %165, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %167 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %167, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %164, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %166, ptr %MEMORY, align 8
  br label %168

168:                                              ; preds = %160
  %169 = load i64, ptr %NEXT_PC, align 8
  store i64 %169, ptr %PC, align 8
  %170 = add i64 %169, 3
  store i64 %170, ptr %NEXT_PC, align 8
  %171 = load i64, ptr %RCX, align 8
  %172 = load ptr, ptr %MEMORY, align 8
  %conv.i.i153 = trunc i64 %171 to i32
  %and3.i.i = and i32 1, %conv.i.i153
  %conv.i22.i154 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i154, ptr %RCX, align 8
  %cf.i.i155 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i155, align 1
  %conv.i.i.i156 = trunc i32 %and3.i.i to i8
  %173 = and i8 %conv.i.i.i156, 1
  %conv.i23.i157 = xor i8 %173, 1
  %pf.i.i158 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i157, ptr %pf.i.i158, align 1
  %cmp.i.i.i159 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i159, i32 noundef %conv.i.i153, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i160 to i8
  %zf.i.i161 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i161, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i153, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i162 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i162, align 1
  %of.i.i163 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i163, align 1
  %af.i.i164 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i164, align 1
  store ptr %172, ptr %MEMORY, align 8
  br label %174

174:                                              ; preds = %168
  %175 = load i64, ptr %NEXT_PC, align 8
  store i64 %175, ptr %PC, align 8
  %176 = add i64 %175, 3
  store i64 %176, ptr %NEXT_PC, align 8
  %177 = load i32, ptr %ECX, align 4
  %178 = zext i32 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %177, i32 noundef 0, i32 noundef %177) #18
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %177 to i8
  %180 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %181 = and i8 %180, 1
  %conv.i.i.i57 = xor i8 %181, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %177, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %177, i32 noundef 0, i32 noundef %177) #18
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %177, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %177, i32 noundef 0, i32 noundef %177) #18
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %177, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %177, i32 noundef 0, i32 noundef %177) #18
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %174
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 3
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %186 = load i8, ptr %zf.i, align 1
  store i8 %186, ptr %CL, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %187

187:                                              ; preds = %182
  %188 = load i64, ptr %NEXT_PC, align 8
  store i64 %188, ptr %PC, align 8
  %189 = add i64 %188, 2
  store i64 %189, ptr %NEXT_PC, align 8
  %190 = load i8, ptr %AL, align 1
  %191 = zext i8 %190 to i64
  %192 = load i8, ptr %CL, align 1
  %193 = zext i8 %192 to i64
  %194 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %193, %191
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i165 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i165, align 1
  %195 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %196 = and i8 %195, 1
  %conv.i27.i = xor i8 %196, 1
  %pf.i.i166 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i166, align 1
  %197 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i167 = and i32 %197, 255
  %cmp.i.i.i168 = icmp eq i8 %or3.i.i, 0
  %198 = trunc i64 %191 to i32
  %conv1.i.i.i = and i32 %198, 255
  %199 = trunc i64 %193 to i32
  %conv2.i.i.i169 = and i32 %199, 255
  %call.i.i.i170 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i168, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i169, i32 noundef %conv.i.i.i167) #18
  %conv3.i.i171 = zext i1 %call.i.i.i170 to i8
  %zf.i.i172 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i171, ptr %zf.i.i172, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i169, i32 noundef %conv.i.i.i167) #18
  %conv6.i.i173 = zext i1 %call4.i.i.i to i8
  %sf.i.i174 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i173, ptr %sf.i.i174, align 1
  %of.i.i175 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i175, align 1
  %af.i.i176 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i176, align 1
  store ptr %194, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %187
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 2
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i8, ptr %AL, align 1
  %204 = zext i8 %203 to i64
  %205 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %204
  %and3.i.i194 = trunc i64 %and3.i15.i to i8
  %cf.i.i195 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i195, align 1
  %206 = and i8 %and3.i.i194, 1
  %conv.i14.i = xor i8 %206, 1
  %pf.i.i196 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i196, align 1
  %207 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i197 = and i32 %207, 255
  %cmp.i.i.i198 = icmp eq i8 %and3.i.i194, 0
  %208 = trunc i64 %204 to i32
  %conv1.i.i.i199 = and i32 %208, 255
  %call.i.i.i200 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i198, i32 noundef %conv1.i.i.i199, i32 noundef 1, i32 noundef %conv.i.i.i197) #18
  %conv3.i.i201 = zext i1 %call.i.i.i200 to i8
  %zf.i.i202 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i201, ptr %zf.i.i202, align 1
  %call4.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i199, i32 noundef 1, i32 noundef %conv.i.i.i197) #18
  %conv6.i.i204 = zext i1 %call4.i.i.i203 to i8
  %sf.i.i205 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i204, ptr %sf.i.i205, align 1
  %of.i.i206 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i206, align 1
  %af.i.i207 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i207, align 1
  store ptr %205, ptr %MEMORY, align 8
  br label %209

209:                                              ; preds = %200
  %210 = load i64, ptr %NEXT_PC, align 8
  store i64 %210, ptr %PC, align 8
  %211 = add i64 %210, 6
  store i64 %211, ptr %NEXT_PC, align 8
  %212 = load i64, ptr %NEXT_PC, align 8
  %213 = add i64 %212, 5
  %214 = load i64, ptr %NEXT_PC, align 8
  %215 = load ptr, ptr %MEMORY, align 8
  %zf.i138 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %216 = load i8, ptr %zf.i138, align 1
  %tobool.not.i = icmp eq i8 %216, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i139 = select i1 %call9.i, i64 %213, i64 %214
  store i64 %cond1.i.i139, ptr %NEXT_PC, align 8
  store ptr %215, ptr %MEMORY, align 8
  %217 = load i64, ptr %NEXT_PC, align 8
  store i64 %217, ptr %PC, align 8
  %218 = load ptr, ptr %MEMORY, align 8
  ret ptr %218
}

define ptr @BB_2382(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2388(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 15257
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 15456
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2425(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 15052
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #18
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 15259
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #18
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #18
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #18
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_23be(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 56
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #18
  store i64 %call.i.i3, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i2, ptr %RSI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %22, i64 noundef %21) #18
  store i64 %call.i.i1, ptr %RDX, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 7
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %NEXT_PC, align 8
  %27 = add i64 %26, 7213
  %28 = load ptr, ptr %MEMORY, align 8
  store i64 %27, ptr %RDI, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %23
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %29
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 5
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %NEXT_PC, align 8
  %37 = sub i64 %36, 938
  %38 = load i64, ptr %NEXT_PC, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %40 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %40, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %39, i64 noundef %sub.i.i, i64 noundef %38) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %37, ptr %rip.i, align 8
  store i64 %37, ptr %NEXT_PC, align 8
  store i64 %38, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  ret ptr %41
}

define ptr @BB_245b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 56
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #18
  store i64 %call.i.i3, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i2, ptr %RSI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %22, i64 noundef %21) #18
  store i64 %call.i.i1, ptr %RDX, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 7
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %NEXT_PC, align 8
  %27 = add i64 %26, 7085
  %28 = load ptr, ptr %MEMORY, align 8
  store i64 %27, ptr %RDI, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %23
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %29
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 5
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %NEXT_PC, align 8
  %37 = sub i64 %36, 1095
  %38 = load i64, ptr %NEXT_PC, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %40 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %40, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %39, i64 noundef %sub.i.i, i64 noundef %38) #18
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %37, ptr %rip.i, align 8
  store i64 %37, ptr %NEXT_PC, align 8
  store i64 %38, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  ret ptr %41
}

define ptr @BB_ffff000000000003_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #6 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !32)
  %rsp.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !35)
  %rip.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !38)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #6

define ptr @BB_ffff000000000004_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #6 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !41)
  %rsp.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !44)
  %rip.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !47)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_23da(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 15543
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 88
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #18
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 15120
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #18
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #18
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 15327
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #18
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #18
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #18
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #18
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #18
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_2477(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 15386
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #18
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 96
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #18
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 14979
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #18
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #18
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 15186
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #18
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #18
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #18
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #18
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #18
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #18
  %pf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #18
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #18
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #18
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #18
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #18
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #18
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #19
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #19
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_241f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 88
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_24bc(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 96
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_24c2(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.161565, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #18
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 0) #18
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 15277
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #18
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %21, ptr %rip.i, align 8
  store i64 %21, ptr %NEXT_PC, align 8
  store ptr %22, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #7 {
entry:
  %agg.tmp = alloca %struct.State.161565, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.161565) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #20
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #8

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.161565) align 16, i64 noundef, ptr noundef) local_unnamed_addr #9

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rip = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rax = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #10 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !50
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rax = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rip = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #11 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !50
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #12 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 8544, label %bb_2160
    i64 8613, label %bb_21A5
    i64 8824, label %bb_2278
    i64 8830, label %bb_227E
    i64 8849, label %bb_2291
    i64 8903, label %bb_22C7
    i64 8944, label %bb_22F0
    i64 8951, label %bb_22F7
    i64 8980, label %bb_2314
    i64 9090, label %bb_2382
    i64 9096, label %bb_2388
    i64 9150, label %bb_23BE
    i64 9178, label %bb_23DA
    i64 9247, label %bb_241F
    i64 9253, label %bb_2425
    i64 9307, label %bb_245B
    i64 9335, label %bb_2477
    i64 9404, label %bb_24BC
    i64 9410, label %bb_24C2
    i64 9429, label %bb_24D5
    i64 9483, label %bb_250B
    i64 9546, label %bb_254A
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
    i64 -281474976710653, label %bb_FFFF000000000003
    i64 -281474976710652, label %bb_FFFF000000000004
  ]

dead_end:                                         ; preds = %bb_FFFF000000000004, %bb_FFFF000000000003, %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_250B, %bb_24D5, %bb_24C2, %bb_24BC, %bb_2477, %bb_245B, %bb_2425, %bb_241F, %bb_23DA, %bb_23BE, %bb_2388, %bb_2382, %bb_2314, %bb_22F7, %bb_22F0, %bb_22C7, %bb_2291, %bb_227E, %bb_2278, %bb_21A5, %bb_2160, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_2160:                                          ; preds = %entry
  %block_pc = add i64 8544, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 8544, ptr %1)
  %4 = call ptr @BB_2160(ptr %state, i64 %2, ptr %1) #21
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 8613, label %bb_21A5
  ]

bb_21A5:                                          ; preds = %bb_2160, %entry
  %block_pc1 = add i64 8613, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 8613, ptr %6)
  %9 = call ptr @BB_21a5(ptr %state, i64 %7, ptr %6) #21
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 8824, label %bb_2278
  ]

bb_2278:                                          ; preds = %bb_21A5, %entry
  %block_pc3 = add i64 8824, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 8824, ptr %11)
  %14 = call ptr @BB_2278(ptr %state, i64 %12, ptr %11) #21
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 8830, label %bb_227E
    i64 8849, label %bb_2291
  ]

bb_227E:                                          ; preds = %bb_2278, %entry
  %block_pc5 = add i64 8830, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 8830, ptr %16)
  %19 = call ptr @BB_227e(ptr %state, i64 %17, ptr %16) #21
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 9429, label %bb_24D5
  ]

bb_2291:                                          ; preds = %bb_2278, %entry
  %block_pc7 = add i64 8849, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 8849, ptr %21)
  %24 = call ptr @BB_2291(ptr %state, i64 %22, ptr %21) #21
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 8903, label %bb_22C7
  ]

bb_22C7:                                          ; preds = %bb_2291, %entry
  %block_pc9 = add i64 8903, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 8903, ptr %26)
  %29 = call ptr @BB_22c7(ptr %state, i64 %27, ptr %26) #21
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 8304, label %bb_FFFF000000000000
  ]

bb_22F0:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc11 = add i64 8944, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 8944, ptr %31)
  %34 = call ptr @BB_22f0(ptr %state, i64 %32, ptr %31) #21
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 8272, label %bb_FFFF000000000001
  ]

bb_22F7:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc13 = add i64 8951, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 8951, ptr %36)
  %39 = call ptr @BB_22f7(ptr %state, i64 %37, ptr %36) #21
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 9776, label %bb_FFFF000000000002
  ]

bb_2314:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc15 = add i64 8980, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 8980, ptr %41)
  %44 = call ptr @BB_2314(ptr %state, i64 %42, ptr %41) #21
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 9090, label %bb_2382
  ]

bb_2382:                                          ; preds = %bb_2314, %entry
  %block_pc17 = add i64 9090, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 9090, ptr %46)
  %49 = call ptr @BB_2382(ptr %state, i64 %47, ptr %46) #21
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 9096, label %bb_2388
    i64 9253, label %bb_2425
  ]

bb_2388:                                          ; preds = %bb_2382, %entry
  %block_pc19 = add i64 9096, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 9096, ptr %51)
  %54 = call ptr @BB_2388(ptr %state, i64 %52, ptr %51) #21
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 9150, label %bb_23BE
  ]

bb_23BE:                                          ; preds = %bb_2388, %entry
  %block_pc21 = add i64 9150, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 9150, ptr %56)
  %59 = call ptr @BB_23be(ptr %state, i64 %57, ptr %56) #21
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 8240, label %bb_FFFF000000000003
  ]

bb_23DA:                                          ; preds = %bb_FFFF000000000003, %entry
  %block_pc23 = add i64 9178, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 9178, ptr %61)
  %64 = call ptr @BB_23da(ptr %state, i64 %62, ptr %61) #21
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 9247, label %bb_241F
  ]

bb_241F:                                          ; preds = %bb_23DA, %entry
  %block_pc25 = add i64 9247, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 9247, ptr %66)
  %69 = call ptr @BB_241f(ptr %state, i64 %67, ptr %66) #21
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 9410, label %bb_24C2
  ]

bb_2425:                                          ; preds = %bb_2382, %entry
  %block_pc27 = add i64 9253, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 9253, ptr %71)
  %74 = call ptr @BB_2425(ptr %state, i64 %72, ptr %71) #21
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 9307, label %bb_245B
  ]

bb_245B:                                          ; preds = %bb_2425, %entry
  %block_pc29 = add i64 9307, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 9307, ptr %76)
  %79 = call ptr @BB_245b(ptr %state, i64 %77, ptr %76) #21
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 8240, label %bb_FFFF000000000004
  ]

bb_2477:                                          ; preds = %bb_FFFF000000000004, %entry
  %block_pc31 = add i64 9335, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 9335, ptr %81)
  %84 = call ptr @BB_2477(ptr %state, i64 %82, ptr %81) #21
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 9404, label %bb_24BC
  ]

bb_24BC:                                          ; preds = %bb_2477, %entry
  %block_pc33 = add i64 9404, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 9404, ptr %86)
  %89 = call ptr @BB_24bc(ptr %state, i64 %87, ptr %86) #21
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  switch i64 %next_rva34, label %dead_end [
    i64 9410, label %bb_24C2
  ]

bb_24C2:                                          ; preds = %bb_24BC, %bb_241F, %entry
  %block_pc35 = add i64 9410, %base
  store i64 %block_pc35, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc35)
  %91 = load ptr, ptr %mem_var, align 8
  %92 = load i64, ptr %pc_var, align 4
  %93 = call ptr @__lifted_bb_entered(ptr %state, i64 9410, ptr %91)
  %94 = call ptr @BB_24c2(ptr %state, i64 %92, ptr %91) #21
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva36 = sub i64 %95, %base
  switch i64 %next_rva36, label %dead_end [
    i64 9429, label %bb_24D5
  ]

bb_24D5:                                          ; preds = %bb_24C2, %bb_227E, %entry
  %block_pc37 = add i64 9429, %base
  store i64 %block_pc37, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc37)
  %96 = load ptr, ptr %mem_var, align 8
  %97 = load i64, ptr %pc_var, align 4
  %98 = call ptr @__lifted_bb_entered(ptr %state, i64 9429, ptr %96)
  %99 = call ptr @BB_24d5(ptr %state, i64 %97, ptr %96) #21
  store ptr %99, ptr %mem_var, align 8
  %100 = call i64 @__extract_rip(ptr %state)
  store i64 %100, ptr %pc_var, align 4
  %next_rva38 = sub i64 %100, %base
  switch i64 %next_rva38, label %dead_end [
    i64 9483, label %bb_250B
  ]

bb_250B:                                          ; preds = %bb_24D5, %entry
  %block_pc39 = add i64 9483, %base
  store i64 %block_pc39, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc39)
  %101 = load ptr, ptr %mem_var, align 8
  %102 = load i64, ptr %pc_var, align 4
  %103 = call ptr @__lifted_bb_entered(ptr %state, i64 9483, ptr %101)
  %104 = call ptr @BB_250b(ptr %state, i64 %102, ptr %101) #21
  store ptr %104, ptr %mem_var, align 8
  %105 = call i64 @__extract_rip(ptr %state)
  store i64 %105, ptr %pc_var, align 4
  %next_rva40 = sub i64 %105, %base
  switch i64 %next_rva40, label %dead_end [
    i64 9546, label %bb_254A
  ]

bb_254A:                                          ; preds = %bb_250B, %entry
  %block_pc41 = add i64 9546, %base
  store i64 %block_pc41, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc41)
  %106 = load ptr, ptr %mem_var, align 8
  %107 = load i64, ptr %pc_var, align 4
  %108 = call ptr @__lifted_bb_entered(ptr %state, i64 9546, ptr %106)
  %109 = call ptr @BB_254a(ptr %state, i64 %107, ptr %106) #21
  store ptr %109, ptr %mem_var, align 8
  %110 = call i64 @__extract_rip(ptr %state)
  store i64 %110, ptr %pc_var, align 4
  %next_rva42 = sub i64 %110, %base
  %111 = load ptr, ptr %mem_var, align 8
  ret ptr %111

bb_FFFF000000000000:                              ; preds = %bb_22C7, %entry
  %112 = load ptr, ptr %mem_var, align 8
  %113 = load i64, ptr %pc_var, align 4
  %114 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %113, ptr %112) #21
  store ptr %114, ptr %mem_var, align 8
  %115 = call i64 @__extract_rip(ptr %state)
  store i64 %115, ptr %pc_var, align 4
  %next_rva43 = sub i64 %115, %base
  switch i64 %next_rva43, label %dead_end [
    i64 8944, label %bb_22F0
  ]

bb_FFFF000000000001:                              ; preds = %bb_22F0, %entry
  %116 = load ptr, ptr %mem_var, align 8
  %117 = load i64, ptr %pc_var, align 4
  %118 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %117, ptr %116) #21
  store ptr %118, ptr %mem_var, align 8
  %119 = call i64 @__extract_rip(ptr %state)
  store i64 %119, ptr %pc_var, align 4
  %next_rva44 = sub i64 %119, %base
  switch i64 %next_rva44, label %dead_end [
    i64 8951, label %bb_22F7
  ]

bb_FFFF000000000002:                              ; preds = %bb_22F7, %entry
  %120 = load ptr, ptr %mem_var, align 8
  %121 = load i64, ptr %pc_var, align 4
  %122 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %121, ptr %120) #21
  store ptr %122, ptr %mem_var, align 8
  %123 = call i64 @__extract_rip(ptr %state)
  store i64 %123, ptr %pc_var, align 4
  %next_rva45 = sub i64 %123, %base
  switch i64 %next_rva45, label %dead_end [
    i64 8980, label %bb_2314
  ]

bb_FFFF000000000003:                              ; preds = %bb_23BE, %entry
  %124 = load ptr, ptr %mem_var, align 8
  %125 = load i64, ptr %pc_var, align 4
  %126 = call ptr @BB_ffff000000000003_ext(ptr %state, i64 %125, ptr %124) #21
  store ptr %126, ptr %mem_var, align 8
  %127 = call i64 @__extract_rip(ptr %state)
  store i64 %127, ptr %pc_var, align 4
  %next_rva46 = sub i64 %127, %base
  switch i64 %next_rva46, label %dead_end [
    i64 9178, label %bb_23DA
  ]

bb_FFFF000000000004:                              ; preds = %bb_245B, %entry
  %128 = load ptr, ptr %mem_var, align 8
  %129 = load i64, ptr %pc_var, align 4
  %130 = call ptr @BB_ffff000000000004_ext(ptr %state, i64 %129, ptr %128) #21
  store ptr %130, ptr %mem_var, align 8
  %131 = call i64 @__extract_rip(ptr %state)
  store i64 %131, ptr %pc_var, align 4
  %next_rva47 = sub i64 %131, %base
  switch i64 %next_rva47, label %dead_end [
    i64 9335, label %bb_2477
  ]

return_bb:                                        ; No predecessors!
  %132 = load ptr, ptr %mem_var, align 8
  ret ptr %132
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #13 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 8544, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #14 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #14 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #14 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #14 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #14 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #14 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #15 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  %rip = getelementptr inbounds %struct.X86State.161564, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !50
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #16 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #17 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { "lifted.annotation_id"="5" "lifted.state_form"="folded" }
attributes #6 = { "lifted.annotation_id"="6" "lifted.state_form"="folded" }
attributes #7 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #9 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #13 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #17 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #18 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #19 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #20 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #21 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33}
!33 = distinct !{!33, !34, !"__extract_rsp: %state"}
!34 = distinct !{!34, !"__extract_rsp"}
!35 = !{!36}
!36 = distinct !{!36, !37, !"__store_rip: %state"}
!37 = distinct !{!37, !"__store_rip"}
!38 = !{!39}
!39 = distinct !{!39, !40, !"__store_rsp: %state"}
!40 = distinct !{!40, !"__store_rsp"}
!41 = !{!42}
!42 = distinct !{!42, !43, !"__extract_rsp: %state"}
!43 = distinct !{!43, !"__extract_rsp"}
!44 = !{!45}
!45 = distinct !{!45, !46, !"__store_rip: %state"}
!46 = distinct !{!46, !"__store_rip"}
!47 = !{!48}
!48 = distinct !{!48, !49, !"__store_rsp: %state"}
!49 = distinct !{!49, !"__store_rsp"}
!50 = !{!51, !51, i64 0}
!51 = !{!"omnipotent char", !52, i64 0}
!52 = !{!"Simple C++ TBAA"}
