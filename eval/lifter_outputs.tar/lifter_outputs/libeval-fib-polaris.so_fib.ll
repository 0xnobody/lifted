; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.251735 = type { %struct.X86State.251734 }
%struct.X86State.251734 = type { %struct.ArchState.251703, [32 x %union.VectorReg.251706], %struct.ArithFlags.251707, %union.anon.251702, %struct.Segments.251709, %struct.AddressSpace.251711, %struct.GPR.251712, %struct.X87Stack.251715, %struct.MMX.251719, %struct.FPUStatusFlags.251720, %union.anon.251702, %union.FPU.251729, %struct.SegmentCaches.251731, %struct.K_REG.251733 }
%struct.ArchState.251703 = type { i32, i32, %union.anon.251702 }
%union.VectorReg.251706 = type { %union.vec512_t.251705 }
%union.vec512_t.251705 = type { %struct.uint64v8_t.251704 }
%struct.uint64v8_t.251704 = type { [8 x i64] }
%struct.ArithFlags.251707 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.251709 = type { i16, %union.SegmentSelector.251708, i16, %union.SegmentSelector.251708, i16, %union.SegmentSelector.251708, i16, %union.SegmentSelector.251708, i16, %union.SegmentSelector.251708, i16, %union.SegmentSelector.251708 }
%union.SegmentSelector.251708 = type { i16 }
%struct.AddressSpace.251711 = type { i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710 }
%struct.Reg.251710 = type { %union.anon.251702 }
%struct.GPR.251712 = type { i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710, i64, %struct.Reg.251710 }
%struct.X87Stack.251715 = type { [8 x %struct.anon.3.251714] }
%struct.anon.3.251714 = type { [6 x i8], %struct.float80_t.251713 }
%struct.float80_t.251713 = type { [10 x i8] }
%struct.MMX.251719 = type { [8 x %struct.anon.4.251718] }
%struct.anon.4.251718 = type { i64, %union.vec64_t.251717 }
%union.vec64_t.251717 = type { %struct.uint64v1_t.251716 }
%struct.uint64v1_t.251716 = type { [1 x i64] }
%struct.FPUStatusFlags.251720 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.251702 = type { i64 }
%union.FPU.251729 = type { %struct.anon.13.251728 }
%struct.anon.13.251728 = type { %struct.FpuFXSAVE.251727, [96 x i8] }
%struct.FpuFXSAVE.251727 = type { %union.SegmentSelector.251708, %union.SegmentSelector.251708, %union.FPUAbridgedTagWord.251721, i8, i16, i32, %union.SegmentSelector.251708, i16, i32, %union.SegmentSelector.251708, i16, %union.FPUControlStatus.251722, %union.FPUControlStatus.251722, [8 x %struct.FPUStackElem.251724], [16 x %union.vec128_t.251726] }
%union.FPUAbridgedTagWord.251721 = type { i8 }
%union.FPUControlStatus.251722 = type { i32 }
%struct.FPUStackElem.251724 = type { %union.anon.11.251723, [6 x i8] }
%union.anon.11.251723 = type { %struct.float80_t.251713 }
%union.vec128_t.251726 = type { %struct.uint128v1_t.251725 }
%struct.uint128v1_t.251725 = type { [1 x i128] }
%struct.SegmentCaches.251731 = type { %struct.SegmentShadow.251730, %struct.SegmentShadow.251730, %struct.SegmentShadow.251730, %struct.SegmentShadow.251730, %struct.SegmentShadow.251730, %struct.SegmentShadow.251730 }
%struct.SegmentShadow.251730 = type { %union.anon.251702, i32, i32 }
%struct.K_REG.251733 = type { [8 x %struct.anon.18.251732] }
%struct.anon.18.251732 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1130(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i120 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i120, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 96
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 96
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 96, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 96
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 96, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 4
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #13
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 11694
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #13
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call i32 @__remill_read_memory_32(ptr noundef %39, i64 noundef %38) #13
  %conv.i.i79 = zext i32 %call.i.i78 to i64
  store i64 %conv.i.i79, ptr %RDX, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 7
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %NEXT_PC, align 8
  %44 = add i64 %43, 11837
  %45 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call i64 @__remill_read_memory_64(ptr noundef %45, i64 noundef %44) #13
  store i64 %call.i.i80, ptr %RAX, align 8
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %40
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %RAX, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %50, i64 noundef %49) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %52 = and i8 %51, 1
  %conv.i.i.i32 = xor i8 %52, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %53 = trunc i32 %xor1.i.i.i.i35 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i36 = and i8 %54, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %46
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %59 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %59, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %60 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %60, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %58, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %55
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 2
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i32, ptr %EDX, align 4
  %65 = zext i32 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %65, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %61
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RCX, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %70 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %72 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %72, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %73 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %74 = and i8 %73, 1
  %conv.i.i.i = xor i8 %74, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %75 = trunc i32 %xor1.i.i.i.i to i8
  %76 = lshr i8 %75, 4
  %conv2.i.i.i = and i8 %76, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %71, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %67
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load i32, ptr %EDX, align 4
  %82 = zext i32 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %80 to i32
  %sext.i = shl i64 %80, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %82, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %84 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %84, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %81, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %77
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RCX, align 8
  %89 = load ptr, ptr %MEMORY, align 8
  %conv.i.i82 = trunc i64 %88 to i32
  %and3.i.i = and i32 1, %conv.i.i82
  %conv.i22.i83 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i83, ptr %RCX, align 8
  %cf.i.i84 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i84, align 1
  %conv.i.i.i85 = trunc i32 %and3.i.i to i8
  %90 = and i8 %conv.i.i.i85, 1
  %conv.i23.i86 = xor i8 %90, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i86, ptr %pf.i.i87, align 1
  %cmp.i.i.i88 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i88, i32 noundef %conv.i.i82, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i89 to i8
  %zf.i.i90 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i90, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i82, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i91 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i91, align 1
  %of.i.i92 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i92, align 1
  %af.i.i93 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i93, align 1
  store ptr %89, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %85
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i32, ptr %ECX, align 4
  %95 = zext i32 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %94 to i8
  %97 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %98 = and i8 %97, 1
  %conv.i.i.i57 = xor i8 %98, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %94, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %94, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %94, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %94, i32 noundef 0, i32 noundef %94) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %91
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %103 = load i8, ptr %zf.i, align 1
  store i8 %103, ptr %CL, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %99
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 2
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i8, ptr %AL, align 1
  %108 = zext i8 %107 to i64
  %109 = load i8, ptr %CL, align 1
  %110 = zext i8 %109 to i64
  %111 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %110, %108
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i94 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i94, align 1
  %112 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %113 = and i8 %112, 1
  %conv.i27.i = xor i8 %113, 1
  %pf.i.i95 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i95, align 1
  %114 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i96 = and i32 %114, 255
  %cmp.i.i.i97 = icmp eq i8 %or3.i.i, 0
  %115 = trunc i64 %108 to i32
  %conv1.i.i.i = and i32 %115, 255
  %116 = trunc i64 %110 to i32
  %conv2.i.i.i98 = and i32 %116, 255
  %call.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i97, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i98, i32 noundef %conv.i.i.i96) #13
  %conv3.i.i100 = zext i1 %call.i.i.i99 to i8
  %zf.i.i101 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i100, ptr %zf.i.i101, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i98, i32 noundef %conv.i.i.i96) #13
  %conv6.i.i102 = zext i1 %call4.i.i.i to i8
  %sf.i.i103 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i102, ptr %sf.i.i103, align 1
  %of.i.i104 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i104, align 1
  %af.i.i105 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i105, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %104
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 2
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i8, ptr %AL, align 1
  %121 = zext i8 %120 to i64
  %122 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %121
  %and3.i.i106 = trunc i64 %and3.i15.i to i8
  %cf.i.i107 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i107, align 1
  %123 = and i8 %and3.i.i106, 1
  %conv.i14.i = xor i8 %123, 1
  %pf.i.i108 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i108, align 1
  %124 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i109 = and i32 %124, 255
  %cmp.i.i.i110 = icmp eq i8 %and3.i.i106, 0
  %125 = trunc i64 %121 to i32
  %conv1.i.i.i111 = and i32 %125, 255
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i110, i32 noundef %conv1.i.i.i111, i32 noundef 1, i32 noundef %conv.i.i.i109) #13
  %conv3.i.i113 = zext i1 %call.i.i.i112 to i8
  %zf.i.i114 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i113, ptr %zf.i.i114, align 1
  %call4.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i111, i32 noundef 1, i32 noundef %conv.i.i.i109) #13
  %conv6.i.i116 = zext i1 %call4.i.i.i115 to i8
  %sf.i.i117 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i116, ptr %sf.i.i117, align 1
  %of.i.i118 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i118, align 1
  %af.i.i119 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i119, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %117
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 6
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %NEXT_PC, align 8
  %130 = add i64 %129, 5
  %131 = load i64, ptr %NEXT_PC, align 8
  %132 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %133 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %133, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %130, i64 %131
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %132, ptr %MEMORY, align 8
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  ret ptr %135
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1171(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i225 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i226 = zext i32 %call.i.i225 to i64
  store i64 %conv.i.i226, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSI, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %15
  store i64 %add.i.i117, ptr %RSI, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %15
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %17 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %19 = and i8 %18, 1
  %conv.i.i.i124 = xor i8 %19, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %15
  %20 = trunc i64 %xor1.i.i.i.i127 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i128 = and i8 %21, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %15
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %15, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 4
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RBP, align 8
  %26 = sub i64 %25, 56
  %27 = load i64, ptr %RSI, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i222 = call ptr @__remill_write_memory_64(ptr noundef %28, i64 noundef %26, i64 noundef %27) #13
  store ptr %call.i.i222, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RSI, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  store i64 %32, ptr %RSP, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %29
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 3
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RSP, align 8
  %38 = load ptr, ptr %MEMORY, align 8
  store i64 %37, ptr %RDX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %34
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 4
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RDX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %42
  store i64 %add.i.i88, ptr %RDX, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %42
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %44 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i64 noundef %42, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %46 = and i8 %45, 1
  %conv.i.i.i95 = xor i8 %46, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %42
  %47 = trunc i64 %xor1.i.i.i.i98 to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i99 = and i8 %48, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %42, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %42, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %42
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %42, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 4
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RBP, align 8
  %53 = sub i64 %52, 48
  %54 = load i64, ptr %RDX, align 8
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i221 = call ptr @__remill_write_memory_64(ptr noundef %55, i64 noundef %53, i64 noundef %54) #13
  store ptr %call.i.i221, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %49
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 3
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RDX, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  store i64 %59, ptr %RSP, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %56
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 3
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %RSP, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  store i64 %64, ptr %RCX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %61
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 4
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RCX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %69
  store i64 %add.i.i59, ptr %RCX, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %69
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %71 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %71, i64 noundef %69, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %72 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %73 = and i8 %72, 1
  %conv.i.i.i66 = xor i8 %73, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %69
  %74 = trunc i64 %xor1.i.i.i.i69 to i8
  %75 = lshr i8 %74, 4
  %conv2.i.i.i70 = and i8 %75, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %69, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %69, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %69
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %69, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %66
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 4
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RBP, align 8
  %80 = sub i64 %79, 40
  %81 = load i64, ptr %RCX, align 8
  %82 = load ptr, ptr %MEMORY, align 8
  %call.i.i220 = call ptr @__remill_write_memory_64(ptr noundef %82, i64 noundef %80, i64 noundef %81) #13
  store ptr %call.i.i220, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %76
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i64, ptr %RCX, align 8
  %87 = load ptr, ptr %MEMORY, align 8
  store i64 %86, ptr %RSP, align 8
  store ptr %87, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %83
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RSP, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  store i64 %91, ptr %RAX, align 8
  store ptr %92, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %88
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 4
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RAX, align 8
  %97 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %96
  store i64 %add.i.i30, ptr %RAX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %96
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %98 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %98, i64 noundef %96, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %99 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %100 = and i8 %99, 1
  %conv.i.i.i37 = xor i8 %100, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %96
  %101 = trunc i64 %xor1.i.i.i.i40 to i8
  %102 = lshr i8 %101, 4
  %conv2.i.i.i41 = and i8 %102, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %96, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %96, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %96
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %96, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %97, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %93
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 4
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RBP, align 8
  %107 = sub i64 %106, 32
  %108 = load i64, ptr %RAX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %call.i.i219 = call ptr @__remill_write_memory_64(ptr noundef %109, i64 noundef %107, i64 noundef %108) #13
  store ptr %call.i.i219, ptr %MEMORY, align 8
  br label %110

110:                                              ; preds = %103
  %111 = load i64, ptr %NEXT_PC, align 8
  store i64 %111, ptr %PC, align 8
  %112 = add i64 %111, 3
  store i64 %112, ptr %NEXT_PC, align 8
  %113 = load i64, ptr %RAX, align 8
  %114 = load ptr, ptr %MEMORY, align 8
  store i64 %113, ptr %RSP, align 8
  store ptr %114, ptr %MEMORY, align 8
  br label %115

115:                                              ; preds = %110
  %116 = load i64, ptr %NEXT_PC, align 8
  store i64 %116, ptr %PC, align 8
  %117 = add i64 %116, 3
  store i64 %117, ptr %NEXT_PC, align 8
  %118 = load i64, ptr %RSP, align 8
  %119 = load ptr, ptr %MEMORY, align 8
  store i64 %118, ptr %R8, align 8
  store ptr %119, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %115
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 4
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i64, ptr %R8, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %123
  store i64 %add.i.i1, ptr %R8, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %123
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %125 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %125, i64 noundef %123, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %126 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %127 = and i8 %126, 1
  %conv.i.i.i8 = xor i8 %127, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %123
  %128 = trunc i64 %xor1.i.i.i.i11 to i8
  %129 = lshr i8 %128, 4
  %conv2.i.i.i12 = and i8 %129, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %123, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %123, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %123
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %123, i64 noundef -16, i64 noundef %add.i.i1) #13
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %124, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %120
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 4
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load i64, ptr %RBP, align 8
  %134 = sub i64 %133, 24
  %135 = load i64, ptr %R8, align 8
  %136 = load ptr, ptr %MEMORY, align 8
  %call.i.i218 = call ptr @__remill_write_memory_64(ptr noundef %136, i64 noundef %134, i64 noundef %135) #13
  store ptr %call.i.i218, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %130
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 3
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i64, ptr %R8, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  store i64 %140, ptr %RSP, align 8
  store ptr %141, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %137
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 2
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RSI, align 8
  %146 = load i32, ptr %EDI, align 4
  %147 = zext i32 %146 to i64
  %148 = load ptr, ptr %MEMORY, align 8
  %call.i.i216 = call ptr @__remill_write_memory_32(ptr noundef %148, i64 noundef %145, i32 noundef %146) #13
  store ptr %call.i.i216, ptr %MEMORY, align 8
  br label %149

149:                                              ; preds = %142
  %150 = load i64, ptr %NEXT_PC, align 8
  store i64 %150, ptr %PC, align 8
  %151 = add i64 %150, 6
  store i64 %151, ptr %NEXT_PC, align 8
  %152 = load i64, ptr %RDX, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  %call.i.i215 = call ptr @__remill_write_memory_32(ptr noundef %153, i64 noundef %152, i32 noundef 1) #13
  store ptr %call.i.i215, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %149
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 6
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i64, ptr %RCX, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  %call.i.i214 = call ptr @__remill_write_memory_32(ptr noundef %158, i64 noundef %157, i32 noundef 1) #13
  store ptr %call.i.i214, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %154
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 6
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i64, ptr %RAX, align 8
  %163 = load ptr, ptr %MEMORY, align 8
  %call.i.i213 = call ptr @__remill_write_memory_32(ptr noundef %163, i64 noundef %162, i32 noundef 3) #13
  store ptr %call.i.i213, ptr %MEMORY, align 8
  br label %164

164:                                              ; preds = %159
  %165 = load i64, ptr %NEXT_PC, align 8
  store i64 %165, ptr %PC, align 8
  %166 = add i64 %165, 7
  store i64 %166, ptr %NEXT_PC, align 8
  %167 = load i64, ptr %NEXT_PC, align 8
  %168 = add i64 %167, 11899
  %169 = load ptr, ptr %MEMORY, align 8
  %call.i.i229 = call i64 @__remill_read_memory_64(ptr noundef %169, i64 noundef %168) #13
  store i64 %call.i.i229, ptr %RAX, align 8
  store ptr %169, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %164
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 4
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i64, ptr %RAX, align 8
  %174 = load ptr, ptr %MEMORY, align 8
  store i64 %173, ptr %RAX, align 8
  %call.i.i.i146 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %173, i64 noundef 0, i64 noundef %173) #13
  %conv.i.i147 = zext i1 %call.i.i.i146 to i8
  %cf.i.i148 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i147, ptr %cf.i.i148, align 1
  %conv.i.i.i.i149 = trunc i64 %173 to i8
  %175 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i149)
  %176 = and i8 %175, 1
  %conv.i.i.i150 = xor i8 %176, 1
  %pf.i.i.i151 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i150, ptr %pf.i.i.i151, align 1
  %af.i.i.i152 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i152, align 1
  %cmp.i.i.i.i153 = icmp eq i64 %173, 0
  %call.i.i.i.i154 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i153, i64 noundef %173, i64 noundef 0, i64 noundef %173) #13
  %conv5.i.i.i155 = zext i1 %call.i.i.i.i154 to i8
  %zf.i.i.i156 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i155, ptr %zf.i.i.i156, align 1
  %cmp.i27.i.i.i157 = icmp slt i64 %173, 0
  %call1.i.i.i.i158 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i157, i64 noundef %173, i64 noundef 0, i64 noundef %173) #13
  %conv8.i.i.i159 = zext i1 %call1.i.i.i.i158 to i8
  %sf.i.i.i160 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i159, ptr %sf.i.i.i160, align 1
  %xor.i28.i.i.i161 = lshr i64 %173, 63
  %call.i30.i.i.i162 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %173, i64 noundef 0, i64 noundef %173) #13
  %conv11.i.i.i163 = zext i1 %call.i30.i.i.i162 to i8
  %of.i.i.i164 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i163, ptr %of.i.i.i164, align 1
  store ptr %174, ptr %MEMORY, align 8
  br label %177

177:                                              ; preds = %170
  %178 = load i64, ptr %NEXT_PC, align 8
  store i64 %178, ptr %PC, align 8
  %179 = add i64 %178, 4
  store i64 %179, ptr %NEXT_PC, align 8
  %180 = load i64, ptr %RBP, align 8
  %181 = sub i64 %180, 16
  %182 = load i64, ptr %RAX, align 8
  %183 = load ptr, ptr %MEMORY, align 8
  %call.i.i217 = call ptr @__remill_write_memory_64(ptr noundef %183, i64 noundef %181, i64 noundef %182) #13
  store ptr %call.i.i217, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %177
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 7
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i64, ptr %NEXT_PC, align 8
  %188 = add i64 %187, 11572
  %189 = load ptr, ptr %MEMORY, align 8
  %call.i.i228 = call i64 @__remill_read_memory_64(ptr noundef %189, i64 noundef %188) #13
  store i64 %call.i.i228, ptr %RAX, align 8
  store ptr %189, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %184
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 2
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %RAX, align 8
  %194 = load ptr, ptr %MEMORY, align 8
  %call.i.i223 = call i32 @__remill_read_memory_32(ptr noundef %194, i64 noundef %193) #13
  %conv.i.i224 = zext i32 %call.i.i223 to i64
  store i64 %conv.i.i224, ptr %RDX, align 8
  store ptr %194, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %190
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 7
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i64, ptr %NEXT_PC, align 8
  %199 = add i64 %198, 11755
  %200 = load ptr, ptr %MEMORY, align 8
  %call.i.i227 = call i64 @__remill_read_memory_64(ptr noundef %200, i64 noundef %199) #13
  store i64 %call.i.i227, ptr %RAX, align 8
  store ptr %200, ptr %MEMORY, align 8
  br label %201

201:                                              ; preds = %195
  %202 = load i64, ptr %NEXT_PC, align 8
  store i64 %202, ptr %PC, align 8
  %203 = add i64 %202, 3
  store i64 %203, ptr %NEXT_PC, align 8
  %204 = load i64, ptr %RAX, align 8
  %205 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %205, i64 noundef %204) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i165 = icmp ult i32 %call.i.i, 10
  %call.i.i.i166 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i165, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i166 to i8
  %cf.i.i167 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i167, align 1
  %conv.i.i.i.i168 = trunc i32 %sub.i.i to i8
  %206 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i168)
  %207 = and i8 %206, 1
  %conv.i.i.i169 = xor i8 %207, 1
  %pf.i.i.i170 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i169, ptr %pf.i.i.i170, align 1
  %xor.i.i.i.i171 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i172 = xor i32 %xor.i.i.i.i171, %sub.i.i
  %208 = trunc i32 %xor1.i.i.i.i172 to i8
  %209 = lshr i8 %208, 4
  %conv2.i.i.i173 = and i8 %209, 1
  %af.i.i.i174 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i173, ptr %af.i.i.i174, align 1
  %cmp.i.i.i.i175 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i175, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i177 = zext i1 %call.i.i.i.i176 to i8
  %zf.i.i.i178 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i177, ptr %zf.i.i.i178, align 1
  %cmp.i27.i.i.i179 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i179, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i181 = zext i1 %call1.i.i.i.i180 to i8
  %sf.i.i.i182 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i181, ptr %sf.i.i.i182, align 1
  %xor.i28.i.i.i183 = lshr i32 %xor.i.i.i.i171, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i184 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i185 = add nuw nsw i32 %xor3.i.i.i.i184, %xor.i28.i.i.i183
  %cmp.i29.i.i.i186 = icmp eq i32 %add.i.i.i.i185, 2
  %call.i30.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i186, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i188 = zext i1 %call.i30.i.i.i187 to i8
  %of.i.i.i189 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i188, ptr %of.i.i.i189, align 1
  store ptr %205, ptr %MEMORY, align 8
  br label %210

210:                                              ; preds = %201
  %211 = load i64, ptr %NEXT_PC, align 8
  store i64 %211, ptr %PC, align 8
  %212 = add i64 %211, 3
  store i64 %212, ptr %NEXT_PC, align 8
  %213 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %214 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %214, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %215 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %215, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %213, ptr %MEMORY, align 8
  br label %216

216:                                              ; preds = %210
  %217 = load i64, ptr %NEXT_PC, align 8
  store i64 %217, ptr %PC, align 8
  %218 = add i64 %217, 2
  store i64 %218, ptr %NEXT_PC, align 8
  %219 = load i32, ptr %EDX, align 4
  %220 = zext i32 %219 to i64
  %221 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %220, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %221, ptr %MEMORY, align 8
  br label %222

222:                                              ; preds = %216
  %223 = load i64, ptr %NEXT_PC, align 8
  store i64 %223, ptr %PC, align 8
  %224 = add i64 %223, 3
  store i64 %224, ptr %NEXT_PC, align 8
  %225 = load i64, ptr %RCX, align 8
  %226 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %225 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %227 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %227, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %228 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %229 = and i8 %228, 1
  %conv.i.i.i = xor i8 %229, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %230 = trunc i32 %xor1.i.i.i.i to i8
  %231 = lshr i8 %230, 4
  %conv2.i.i.i = and i8 %231, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %226, ptr %MEMORY, align 8
  br label %232

232:                                              ; preds = %222
  %233 = load i64, ptr %NEXT_PC, align 8
  store i64 %233, ptr %PC, align 8
  %234 = add i64 %233, 3
  store i64 %234, ptr %NEXT_PC, align 8
  %235 = load i64, ptr %RCX, align 8
  %236 = load i32, ptr %EDX, align 4
  %237 = zext i32 %236 to i64
  %238 = load ptr, ptr %MEMORY, align 8
  %conv.i.i208 = trunc i64 %235 to i32
  %sext.i = shl i64 %235, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %237, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %239 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i209 = icmp ult i64 %239, -4294967296
  %call.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i209, i32 noundef %conv.i.i208, i32 noundef %236, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i210 to i8
  %cf.i.i211 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i211, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %238, ptr %MEMORY, align 8
  br label %240

240:                                              ; preds = %232
  %241 = load i64, ptr %NEXT_PC, align 8
  store i64 %241, ptr %PC, align 8
  %242 = add i64 %241, 3
  store i64 %242, ptr %NEXT_PC, align 8
  %243 = load i64, ptr %RCX, align 8
  %244 = load ptr, ptr %MEMORY, align 8
  %conv.i.i230 = trunc i64 %243 to i32
  %and3.i.i = and i32 1, %conv.i.i230
  %conv.i22.i231 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i231, ptr %RCX, align 8
  %cf.i.i232 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i232, align 1
  %conv.i.i.i233 = trunc i32 %and3.i.i to i8
  %245 = and i8 %conv.i.i.i233, 1
  %conv.i23.i234 = xor i8 %245, 1
  %pf.i.i235 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i234, ptr %pf.i.i235, align 1
  %cmp.i.i.i236 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i237 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i236, i32 noundef %conv.i.i230, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i237 to i8
  %zf.i.i238 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i238, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i230, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i239 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i239, align 1
  %of.i.i240 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i240, align 1
  %af.i.i241 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i241, align 1
  store ptr %244, ptr %MEMORY, align 8
  br label %246

246:                                              ; preds = %240
  %247 = load i64, ptr %NEXT_PC, align 8
  store i64 %247, ptr %PC, align 8
  %248 = add i64 %247, 3
  store i64 %248, ptr %NEXT_PC, align 8
  %249 = load i32, ptr %ECX, align 4
  %250 = zext i32 %249 to i64
  %251 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i190 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %249, i32 noundef 0, i32 noundef %249) #13
  %conv.i12.i = zext i1 %call.i.i.i190 to i8
  %cf.i.i191 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i191, align 1
  %conv.i.i.i.i192 = trunc i32 %249 to i8
  %252 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i192)
  %253 = and i8 %252, 1
  %conv.i.i.i193 = xor i8 %253, 1
  %pf.i.i.i194 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i193, ptr %pf.i.i.i194, align 1
  %af.i.i.i195 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i195, align 1
  %cmp.i.i.i.i196 = icmp eq i32 %249, 0
  %call.i.i.i.i197 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i196, i32 noundef %249, i32 noundef 0, i32 noundef %249) #13
  %conv5.i.i.i198 = zext i1 %call.i.i.i.i197 to i8
  %zf.i.i.i199 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i198, ptr %zf.i.i.i199, align 1
  %cmp.i27.i.i.i200 = icmp slt i32 %249, 0
  %call1.i.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i200, i32 noundef %249, i32 noundef 0, i32 noundef %249) #13
  %conv8.i.i.i202 = zext i1 %call1.i.i.i.i201 to i8
  %sf.i.i.i203 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i202, ptr %sf.i.i.i203, align 1
  %xor.i28.i.i.i204 = lshr i32 %249, 31
  %call.i30.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %249, i32 noundef 0, i32 noundef %249) #13
  %conv11.i.i.i206 = zext i1 %call.i30.i.i.i205 to i8
  %of.i.i.i207 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i206, ptr %of.i.i.i207, align 1
  store ptr %251, ptr %MEMORY, align 8
  br label %254

254:                                              ; preds = %246
  %255 = load i64, ptr %NEXT_PC, align 8
  store i64 %255, ptr %PC, align 8
  %256 = add i64 %255, 3
  store i64 %256, ptr %NEXT_PC, align 8
  %257 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %258 = load i8, ptr %zf.i, align 1
  store i8 %258, ptr %CL, align 1
  store ptr %257, ptr %MEMORY, align 8
  br label %259

259:                                              ; preds = %254
  %260 = load i64, ptr %NEXT_PC, align 8
  store i64 %260, ptr %PC, align 8
  %261 = add i64 %260, 2
  store i64 %261, ptr %NEXT_PC, align 8
  %262 = load i8, ptr %AL, align 1
  %263 = zext i8 %262 to i64
  %264 = load i8, ptr %CL, align 1
  %265 = zext i8 %264 to i64
  %266 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %265, %263
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i242 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i242, align 1
  %267 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %268 = and i8 %267, 1
  %conv.i27.i = xor i8 %268, 1
  %pf.i.i243 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i243, align 1
  %269 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i244 = and i32 %269, 255
  %cmp.i.i.i245 = icmp eq i8 %or3.i.i, 0
  %270 = trunc i64 %263 to i32
  %conv1.i.i.i = and i32 %270, 255
  %271 = trunc i64 %265 to i32
  %conv2.i.i.i246 = and i32 %271, 255
  %call.i.i.i247 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i245, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i246, i32 noundef %conv.i.i.i244) #13
  %conv3.i.i248 = zext i1 %call.i.i.i247 to i8
  %zf.i.i249 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i248, ptr %zf.i.i249, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i246, i32 noundef %conv.i.i.i244) #13
  %conv6.i.i250 = zext i1 %call4.i.i.i to i8
  %sf.i.i251 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i250, ptr %sf.i.i251, align 1
  %of.i.i252 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i252, align 1
  %af.i.i253 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i253, align 1
  store ptr %266, ptr %MEMORY, align 8
  br label %272

272:                                              ; preds = %259
  %273 = load i64, ptr %NEXT_PC, align 8
  store i64 %273, ptr %PC, align 8
  %274 = add i64 %273, 2
  store i64 %274, ptr %NEXT_PC, align 8
  %275 = load i8, ptr %AL, align 1
  %276 = zext i8 %275 to i64
  %277 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %276
  %and3.i.i254 = trunc i64 %and3.i15.i to i8
  %cf.i.i255 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i255, align 1
  %278 = and i8 %and3.i.i254, 1
  %conv.i14.i = xor i8 %278, 1
  %pf.i.i256 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i256, align 1
  %279 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i257 = and i32 %279, 255
  %cmp.i.i.i258 = icmp eq i8 %and3.i.i254, 0
  %280 = trunc i64 %276 to i32
  %conv1.i.i.i259 = and i32 %280, 255
  %call.i.i.i260 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i258, i32 noundef %conv1.i.i.i259, i32 noundef 1, i32 noundef %conv.i.i.i257) #13
  %conv3.i.i261 = zext i1 %call.i.i.i260 to i8
  %zf.i.i262 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i261, ptr %zf.i.i262, align 1
  %call4.i.i.i263 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i259, i32 noundef 1, i32 noundef %conv.i.i.i257) #13
  %conv6.i.i264 = zext i1 %call4.i.i.i263 to i8
  %sf.i.i265 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i264, ptr %sf.i.i265, align 1
  %of.i.i266 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i266, align 1
  %af.i.i267 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i267, align 1
  store ptr %277, ptr %MEMORY, align 8
  br label %281

281:                                              ; preds = %272
  %282 = load i64, ptr %NEXT_PC, align 8
  store i64 %282, ptr %PC, align 8
  %283 = add i64 %282, 6
  store i64 %283, ptr %NEXT_PC, align 8
  %284 = load i64, ptr %NEXT_PC, align 8
  %285 = add i64 %284, 5
  %286 = load i64, ptr %NEXT_PC, align 8
  %287 = load ptr, ptr %MEMORY, align 8
  %zf.i212 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %288 = load i8, ptr %zf.i212, align 1
  %tobool.not.i = icmp eq i8 %288, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %285, i64 %286
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %287, ptr %MEMORY, align 8
  %289 = load i64, ptr %NEXT_PC, align 8
  store i64 %289, ptr %PC, align 8
  %290 = load ptr, ptr %MEMORY, align 8
  ret ptr %290
}

define ptr @BB_1213(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1219(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11520
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11703
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_124f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i159 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i159, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i158 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #13
  store i64 %call.i.i158, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #13
  %conv.i.i154 = zext i32 %call.i.i153 to i64
  store i64 %conv.i.i154, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %conv.i.i152 = zext i32 %call.i.i151 to i64
  store i64 %conv.i.i152, ptr %RSI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 5
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RCX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %23
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 5
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %27
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 2
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i32, ptr %EDX, align 4
  %35 = zext i32 %34 to i64
  %36 = load i32, ptr %ESI, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %34, %36
  %cmp.i.i.i101 = icmp ult i32 %34, %36
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #13
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %39 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %40 = and i8 %39, 1
  %conv.i.i.i106 = xor i8 %40, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %36, %34
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %41 = trunc i32 %xor1.i.i.i.i109 to i8
  %42 = lshr i8 %41, 4
  %conv2.i.i.i110 = and i8 %42, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %34, %36
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #13
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #13
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %34
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #13
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %38, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %31
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 3
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i32, ptr %EAX, align 4
  %47 = zext i32 %46 to i64
  %48 = load ptr, ptr %MEMORY, align 8
  %zf.i132 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %49 = load i8, ptr %zf.i132, align 1
  %tobool.i133 = icmp ne i8 %49, 0
  %sf.i134 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %50 = load i8, ptr %sf.i134, align 1
  %tobool4.i = icmp ne i8 %50, 0
  %of.i135 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %51 = load i8, ptr %of.i135, align 1
  %tobool6.i = icmp ne i8 %51, 0
  %cmp.i.i136 = xor i1 %tobool4.i, %tobool6.i
  %52 = or i1 %tobool.i133, %cmp.i.i136
  %call8.i = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %52) #14
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call8.i, i64 %47, i64 %dst.coerce.val.i
  %conv.i27.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i27.i, ptr %RCX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %43
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 7
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %NEXT_PC, align 8
  %57 = add i64 %56, 11743
  %58 = load ptr, ptr %MEMORY, align 8
  store i64 %57, ptr %RAX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i32, ptr %ECX, align 4
  %63 = zext i32 %62 to i64
  %64 = load ptr, ptr %MEMORY, align 8
  %sext.i160 = shl i64 %63, 32
  %conv.i12.i161 = ashr exact i64 %sext.i160, 32
  store i64 %conv.i12.i161, ptr %RCX, align 8
  store ptr %64, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %59
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 4
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RAX, align 8
  %69 = load i64, ptr %RCX, align 8
  %70 = mul i64 %69, 8
  %71 = add i64 %68, %70
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %72, i64 noundef %71) #13
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %65
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 2
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RCX, align 8
  %77 = load i32, ptr %ECX, align 4
  %78 = zext i32 %77 to i64
  %79 = load ptr, ptr %MEMORY, align 8
  %conv.i.i187 = trunc i64 %76 to i32
  %xor3.i.i = xor i32 %77, %conv.i.i187
  %conv.i27.i188 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i188, ptr %RCX, align 8
  %cf.i.i189 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i189, align 1
  %conv.i.i.i190 = trunc i32 %xor3.i.i to i8
  %80 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i190)
  %81 = and i8 %80, 1
  %conv.i28.i191 = xor i8 %81, 1
  %pf.i.i192 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i191, ptr %pf.i.i192, align 1
  %cmp.i.i.i193 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i194 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i193, i32 noundef %conv.i.i187, i32 noundef %77, i32 noundef %xor3.i.i) #13
  %conv3.i.i195 = zext i1 %call.i.i.i194 to i8
  %zf.i.i196 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i195, ptr %zf.i.i196, align 1
  %cmp.i19.i.i197 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i198 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i197, i32 noundef %conv.i.i187, i32 noundef %77, i32 noundef %xor3.i.i) #13
  %conv6.i.i199 = zext i1 %call1.i.i.i198 to i8
  %sf.i.i200 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i199, ptr %sf.i.i200, align 1
  %of.i.i201 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i201, align 1
  %af.i.i202 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i203 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i203, ptr %af.i.i202, align 1
  store ptr %79, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %73
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 2
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %EDX, align 4
  %86 = zext i32 %85 to i64
  %87 = load i32, ptr %ESI, align 4
  %88 = zext i32 %87 to i64
  %89 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %85, %87
  %cmp.i.i.i73 = icmp ult i32 %85, %87
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %85, i32 noundef %87, i32 noundef %sub.i.i72) #13
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %90 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %91 = and i8 %90, 1
  %conv.i.i.i78 = xor i8 %91, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %87, %85
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %92 = trunc i32 %xor1.i.i.i.i81 to i8
  %93 = lshr i8 %92, 4
  %conv2.i.i.i82 = and i8 %93, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %85, %87
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %85, i32 noundef %87, i32 noundef %sub.i.i72) #13
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %85, i32 noundef %87, i32 noundef %sub.i.i72) #13
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %85
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %85, i32 noundef %87, i32 noundef %sub.i.i72) #13
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %89, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %82
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 4
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i64, ptr %RCX, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  %zf.i137 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %99 = load i8, ptr %zf.i137, align 1
  %tobool.i138 = icmp ne i8 %99, 0
  %sf.i139 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %100 = load i8, ptr %sf.i139, align 1
  %tobool4.i140 = icmp ne i8 %100, 0
  %of.i141 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %101 = load i8, ptr %of.i141, align 1
  %tobool6.i142 = icmp ne i8 %101, 0
  %cmp.i.i143 = xor i1 %tobool4.i140, %tobool6.i142
  %102 = or i1 %tobool.i138, %cmp.i.i143
  %call8.i144 = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %102) #14
  %dst.coerce.val.i145 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call8.i144, i64 %97, i64 %dst.coerce.val.i145
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %98, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %94
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 3
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RAX, align 8
  %107 = load i64, ptr %RCX, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %106, %107
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %106, %107
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %106, i64 noundef %107, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %109 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %110 = and i8 %109, 1
  %conv.i.i.i6 = xor i8 %110, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %107, %106
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %111 = trunc i64 %xor1.i.i.i.i9 to i8
  %112 = lshr i8 %111, 4
  %conv2.i.i.i10 = and i8 %112, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %106, %107
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %106, i64 noundef %107, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %106, i64 noundef %107, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %106
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %106, i64 noundef %107, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %108, ptr %MEMORY, align 8
  br label %113

113:                                              ; preds = %103
  %114 = load i64, ptr %NEXT_PC, align 8
  store i64 %114, ptr %PC, align 8
  %115 = add i64 %114, 4
  store i64 %115, ptr %NEXT_PC, align 8
  %116 = load i64, ptr %RBP, align 8
  %117 = sub i64 %116, 64
  %118 = load i64, ptr %RAX, align 8
  %119 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call ptr @__remill_write_memory_64(ptr noundef %119, i64 noundef %117, i64 noundef %118) #13
  store ptr %call.i.i148, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %113
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 7
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = add i64 %123, 11418
  %125 = load ptr, ptr %MEMORY, align 8
  %call.i.i156 = call i64 @__remill_read_memory_64(ptr noundef %125, i64 noundef %124) #13
  store i64 %call.i.i156, ptr %RAX, align 8
  store ptr %125, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %120
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 2
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RAX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i32 @__remill_read_memory_32(ptr noundef %130, i64 noundef %129) #13
  %conv.i.i150 = zext i32 %call.i.i149 to i64
  store i64 %conv.i.i150, ptr %RDX, align 8
  store ptr %130, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %126
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 7
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i64, ptr %NEXT_PC, align 8
  %135 = add i64 %134, 11601
  %136 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i64 @__remill_read_memory_64(ptr noundef %136, i64 noundef %135) #13
  store i64 %call.i.i155, ptr %RAX, align 8
  store ptr %136, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %131
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 3
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i64, ptr %RAX, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %141, i64 noundef %140) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %142 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %143 = and i8 %142, 1
  %conv.i.i.i32 = xor i8 %143, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %144 = trunc i32 %xor1.i.i.i.i35 to i8
  %145 = lshr i8 %144, 4
  %conv2.i.i.i36 = and i8 %145, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %141, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 3
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %150 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %150, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %151 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %151, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %152

152:                                              ; preds = %146
  %153 = load i64, ptr %NEXT_PC, align 8
  store i64 %153, ptr %PC, align 8
  %154 = add i64 %153, 2
  store i64 %154, ptr %NEXT_PC, align 8
  %155 = load i32, ptr %EDX, align 4
  %156 = zext i32 %155 to i64
  %157 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %156, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %157, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %152
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 3
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RCX, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %161 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %163 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %163, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %164 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %165 = and i8 %164, 1
  %conv.i.i.i = xor i8 %165, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %166 = trunc i32 %xor1.i.i.i.i to i8
  %167 = lshr i8 %166, 4
  %conv2.i.i.i = and i8 %167, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %162, ptr %MEMORY, align 8
  br label %168

168:                                              ; preds = %158
  %169 = load i64, ptr %NEXT_PC, align 8
  store i64 %169, ptr %PC, align 8
  %170 = add i64 %169, 3
  store i64 %170, ptr %NEXT_PC, align 8
  %171 = load i64, ptr %RCX, align 8
  %172 = load i32, ptr %EDX, align 4
  %173 = zext i32 %172 to i64
  %174 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %171 to i32
  %sext.i = shl i64 %171, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %173, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %175 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %175, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %172, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %174, ptr %MEMORY, align 8
  br label %176

176:                                              ; preds = %168
  %177 = load i64, ptr %NEXT_PC, align 8
  store i64 %177, ptr %PC, align 8
  %178 = add i64 %177, 3
  store i64 %178, ptr %NEXT_PC, align 8
  %179 = load i64, ptr %RCX, align 8
  %180 = load ptr, ptr %MEMORY, align 8
  %conv.i.i162 = trunc i64 %179 to i32
  %and3.i.i = and i32 1, %conv.i.i162
  %conv.i22.i163 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i163, ptr %RCX, align 8
  %cf.i.i164 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i164, align 1
  %conv.i.i.i165 = trunc i32 %and3.i.i to i8
  %181 = and i8 %conv.i.i.i165, 1
  %conv.i23.i166 = xor i8 %181, 1
  %pf.i.i167 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i166, ptr %pf.i.i167, align 1
  %cmp.i.i.i168 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i169 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i168, i32 noundef %conv.i.i162, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i169 to i8
  %zf.i.i170 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i170, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i162, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i171 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i171, align 1
  %of.i.i172 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i172, align 1
  %af.i.i173 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i173, align 1
  store ptr %180, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %176
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 3
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load i32, ptr %ECX, align 4
  %186 = zext i32 %185 to i64
  %187 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %185, i32 noundef 0, i32 noundef %185) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %185 to i8
  %188 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %189 = and i8 %188, 1
  %conv.i.i.i57 = xor i8 %189, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %185, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %185, i32 noundef 0, i32 noundef %185) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %185, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %185, i32 noundef 0, i32 noundef %185) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %185, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %185, i32 noundef 0, i32 noundef %185) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %187, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %182
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 3
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %194 = load i8, ptr %zf.i, align 1
  store i8 %194, ptr %CL, align 1
  store ptr %193, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %190
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 2
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i8, ptr %AL, align 1
  %199 = zext i8 %198 to i64
  %200 = load i8, ptr %CL, align 1
  %201 = zext i8 %200 to i64
  %202 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %201, %199
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i174 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i174, align 1
  %203 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %204 = and i8 %203, 1
  %conv.i27.i175 = xor i8 %204, 1
  %pf.i.i176 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i175, ptr %pf.i.i176, align 1
  %205 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i177 = and i32 %205, 255
  %cmp.i.i.i178 = icmp eq i8 %or3.i.i, 0
  %206 = trunc i64 %199 to i32
  %conv1.i.i.i = and i32 %206, 255
  %207 = trunc i64 %201 to i32
  %conv2.i.i.i179 = and i32 %207, 255
  %call.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i178, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i179, i32 noundef %conv.i.i.i177) #13
  %conv3.i.i181 = zext i1 %call.i.i.i180 to i8
  %zf.i.i182 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i181, ptr %zf.i.i182, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i179, i32 noundef %conv.i.i.i177) #13
  %conv6.i.i183 = zext i1 %call4.i.i.i to i8
  %sf.i.i184 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i183, ptr %sf.i.i184, align 1
  %of.i.i185 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i185, align 1
  %af.i.i186 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i186, align 1
  store ptr %202, ptr %MEMORY, align 8
  br label %208

208:                                              ; preds = %195
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = add i64 %209, 2
  store i64 %210, ptr %NEXT_PC, align 8
  %211 = load i8, ptr %AL, align 1
  %212 = zext i8 %211 to i64
  %213 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %212
  %and3.i.i204 = trunc i64 %and3.i15.i to i8
  %cf.i.i205 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i205, align 1
  %214 = and i8 %and3.i.i204, 1
  %conv.i14.i = xor i8 %214, 1
  %pf.i.i206 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i206, align 1
  %215 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i207 = and i32 %215, 255
  %cmp.i.i.i208 = icmp eq i8 %and3.i.i204, 0
  %216 = trunc i64 %212 to i32
  %conv1.i.i.i209 = and i32 %216, 255
  %call.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i208, i32 noundef %conv1.i.i.i209, i32 noundef 1, i32 noundef %conv.i.i.i207) #13
  %conv3.i.i211 = zext i1 %call.i.i.i210 to i8
  %zf.i.i212 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i211, ptr %zf.i.i212, align 1
  %call4.i.i.i213 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i209, i32 noundef 1, i32 noundef %conv.i.i.i207) #13
  %conv6.i.i214 = zext i1 %call4.i.i.i213 to i8
  %sf.i.i215 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i214, ptr %sf.i.i215, align 1
  %of.i.i216 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i216, align 1
  %af.i.i217 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i217, align 1
  store ptr %213, ptr %MEMORY, align 8
  br label %217

217:                                              ; preds = %208
  %218 = load i64, ptr %NEXT_PC, align 8
  store i64 %218, ptr %PC, align 8
  %219 = add i64 %218, 6
  store i64 %219, ptr %NEXT_PC, align 8
  %220 = load i64, ptr %NEXT_PC, align 8
  %221 = add i64 %220, 5
  %222 = load i64, ptr %NEXT_PC, align 8
  %223 = load ptr, ptr %MEMORY, align 8
  %zf.i146 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %224 = load i8, ptr %zf.i146, align 1
  %tobool.not.i = icmp eq i8 %224, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i147 = select i1 %call9.i, i64 %221, i64 %222
  store i64 %cond1.i.i147, ptr %NEXT_PC, align 8
  store ptr %223, ptr %MEMORY, align 8
  %225 = load i64, ptr %NEXT_PC, align 8
  store i64 %225, ptr %PC, align 8
  %226 = load ptr, ptr %MEMORY, align 8
  ret ptr %226
}

define ptr @BB_12bd(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_12c3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11374
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11421
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_13ea(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10991
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11118
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_12f9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i115 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i115, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 24
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i114 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #13
  store i64 %call.i.i114, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 48
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i113 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #13
  store i64 %call.i.i113, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i32 @__remill_read_memory_32(ptr noundef %23, i64 noundef %22) #13
  %conv.i.i109 = zext i32 %call.i.i108 to i64
  store i64 %conv.i.i109, ptr %RSI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 2
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RSI, align 8
  %28 = load i64, ptr %RAX, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %27 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %29, i64 noundef %28) #13
  %add.i.i2 = add i32 %call.i.i, %conv.i.i1
  %conv.i18.i = zext i32 %add.i.i2 to i64
  store i64 %conv.i18.i, ptr %RSI, align 8
  %cmp.i.i.i3 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i4 = icmp ult i32 %add.i.i2, %call.i.i
  %30 = or i1 %cmp.i.i.i3, %cmp1.i.i.i4
  %call.i.i.i5 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %30, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #13
  %conv.i19.i = zext i1 %call.i.i.i5 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %add.i.i2 to i8
  %31 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %32 = and i8 %31, 1
  %conv.i.i.i8 = xor i8 %32, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 %add.i.i2, %call.i.i
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %conv.i.i1
  %33 = trunc i32 %xor1.i.i.i.i11 to i8
  %34 = lshr i8 %33, 4
  %conv2.i.i.i12 = and i8 %34, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #13
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #13
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i23 = lshr i32 %shr8.i.i.i.i22, 31
  %xor3.i.i.i.i24 = lshr i32 %xor.i.i.i.i10, 31
  %add.i.i.i.i25 = add nuw nsw i32 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i32 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #13
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %29, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %24
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RCX, align 8
  %39 = load i32, ptr %ESI, align 4
  %40 = zext i32 %39 to i64
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_32(ptr noundef %41, i64 noundef %38, i32 noundef %39) #13
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #13
  %conv.i.i107 = zext i32 %call.i.i106 to i64
  store i64 %conv.i.i107, ptr %RSI, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RDX, align 8
  %51 = load i32, ptr %ESI, align 4
  %52 = zext i32 %51 to i64
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %53, i64 noundef %50, i32 noundef %51) #13
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %47
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 2
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i64, ptr %RCX, align 8
  %58 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call i32 @__remill_read_memory_32(ptr noundef %58, i64 noundef %57) #13
  %conv.i.i105 = zext i32 %call.i.i104 to i64
  store i64 %conv.i.i105, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %54
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 2
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RAX, align 8
  %63 = load i32, ptr %ECX, align 4
  %64 = zext i32 %63 to i64
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_32(ptr noundef %65, i64 noundef %62, i32 noundef %63) #13
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %59
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 7
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %NEXT_PC, align 8
  %70 = add i64 %69, 11598
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i112 = call i64 @__remill_read_memory_64(ptr noundef %71, i64 noundef %70) #13
  store i64 %call.i.i112, ptr %RAX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %66
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RAX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  store i64 %75, ptr %RAX, align 8
  %call.i.i.i30 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %75, i64 noundef 0, i64 noundef %75) #13
  %conv.i.i31 = zext i1 %call.i.i.i30 to i8
  %cf.i.i32 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i31, ptr %cf.i.i32, align 1
  %conv.i.i.i.i33 = trunc i64 %75 to i8
  %77 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i33)
  %78 = and i8 %77, 1
  %conv.i.i.i34 = xor i8 %78, 1
  %pf.i.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i34, ptr %pf.i.i.i35, align 1
  %af.i.i.i36 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i36, align 1
  %cmp.i.i.i.i37 = icmp eq i64 %75, 0
  %call.i.i.i.i38 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i37, i64 noundef %75, i64 noundef 0, i64 noundef %75) #13
  %conv5.i.i.i39 = zext i1 %call.i.i.i.i38 to i8
  %zf.i.i.i40 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i39, ptr %zf.i.i.i40, align 1
  %cmp.i27.i.i.i41 = icmp slt i64 %75, 0
  %call1.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i41, i64 noundef %75, i64 noundef 0, i64 noundef %75) #13
  %conv8.i.i.i43 = zext i1 %call1.i.i.i.i42 to i8
  %sf.i.i.i44 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i43, ptr %sf.i.i.i44, align 1
  %xor.i28.i.i.i45 = lshr i64 %75, 63
  %call.i30.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %75, i64 noundef 0, i64 noundef %75) #13
  %conv11.i.i.i47 = zext i1 %call.i30.i.i.i46 to i8
  %of.i.i.i48 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i47, ptr %of.i.i.i48, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %79

79:                                               ; preds = %72
  %80 = load i64, ptr %NEXT_PC, align 8
  store i64 %80, ptr %PC, align 8
  %81 = add i64 %80, 4
  store i64 %81, ptr %NEXT_PC, align 8
  %82 = load i64, ptr %RBP, align 8
  %83 = sub i64 %82, 72
  %84 = load i64, ptr %RAX, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call ptr @__remill_write_memory_64(ptr noundef %85, i64 noundef %83, i64 noundef %84) #13
  store ptr %call.i.i101, ptr %MEMORY, align 8
  br label %86

86:                                               ; preds = %79
  %87 = load i64, ptr %NEXT_PC, align 8
  store i64 %87, ptr %PC, align 8
  %88 = add i64 %87, 7
  store i64 %88, ptr %NEXT_PC, align 8
  %89 = load i64, ptr %NEXT_PC, align 8
  %90 = add i64 %89, 11199
  %91 = load ptr, ptr %MEMORY, align 8
  %call.i.i111 = call i64 @__remill_read_memory_64(ptr noundef %91, i64 noundef %90) #13
  store i64 %call.i.i111, ptr %RAX, align 8
  store ptr %91, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %86
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 2
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RAX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i102 = call i32 @__remill_read_memory_32(ptr noundef %96, i64 noundef %95) #13
  %conv.i.i103 = zext i32 %call.i.i102 to i64
  store i64 %conv.i.i103, ptr %RDX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %92
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 7
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %NEXT_PC, align 8
  %101 = add i64 %100, 11342
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i110 = call i64 @__remill_read_memory_64(ptr noundef %102, i64 noundef %101) #13
  store i64 %call.i.i110, ptr %RAX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %97
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 3
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RAX, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %107, i64 noundef %106) #13
  %sub.i.i = sub i32 %call.i.i49, 10
  %cmp.i.i.i50 = icmp ult i32 %call.i.i49, 10
  %call.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i50, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i51 to i8
  %cf.i.i52 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i52, align 1
  %conv.i.i.i.i53 = trunc i32 %sub.i.i to i8
  %108 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i53)
  %109 = and i8 %108, 1
  %conv.i.i.i54 = xor i8 %109, 1
  %pf.i.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i54, ptr %pf.i.i.i55, align 1
  %xor.i.i.i.i56 = xor i32 %call.i.i49, 10
  %xor1.i.i.i.i57 = xor i32 %xor.i.i.i.i56, %sub.i.i
  %110 = trunc i32 %xor1.i.i.i.i57 to i8
  %111 = lshr i8 %110, 4
  %conv2.i.i.i58 = and i8 %111, 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i58, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %call.i.i49, 10
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %xor.i.i.i.i56, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i49
  %xor3.i.i.i.i69 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i70 = add nuw nsw i32 %xor3.i.i.i.i69, %xor.i28.i.i.i68
  %cmp.i29.i.i.i71 = icmp eq i32 %add.i.i.i.i70, 2
  %call.i30.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i71, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i73 = zext i1 %call.i30.i.i.i72 to i8
  %of.i.i.i74 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i73, ptr %of.i.i.i74, align 1
  store ptr %107, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %103
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %116 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %116, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %117 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %117, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %115, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %112
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 2
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i32, ptr %EDX, align 4
  %122 = zext i32 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %122, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %123, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %118
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 3
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RCX, align 8
  %128 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %127 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %129 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %129, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %130 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %131 = and i8 %130, 1
  %conv.i.i.i = xor i8 %131, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %132 = trunc i32 %xor1.i.i.i.i to i8
  %133 = lshr i8 %132, 4
  %conv2.i.i.i = and i8 %133, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %128, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %124
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 3
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RCX, align 8
  %138 = load i32, ptr %EDX, align 4
  %139 = zext i32 %138 to i64
  %140 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %137 to i32
  %sext.i = shl i64 %137, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %139, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %141 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i94 = icmp ult i64 %141, -4294967296
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i93, i32 noundef %138, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i95 to i8
  %cf.i.i96 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i96, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %134
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RCX, align 8
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i116 = trunc i64 %145 to i32
  %and3.i.i = and i32 1, %conv.i.i116
  %conv.i22.i117 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i117, ptr %RCX, align 8
  %cf.i.i118 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i118, align 1
  %conv.i.i.i119 = trunc i32 %and3.i.i to i8
  %147 = and i8 %conv.i.i.i119, 1
  %conv.i23.i120 = xor i8 %147, 1
  %pf.i.i121 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i120, ptr %pf.i.i121, align 1
  %cmp.i.i.i122 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i123 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i122, i32 noundef %conv.i.i116, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i123 to i8
  %zf.i.i124 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i124, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i116, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i125 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i125, align 1
  %of.i.i126 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i126, align 1
  %af.i.i127 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i127, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i32, ptr %ECX, align 4
  %152 = zext i32 %151 to i64
  %153 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv.i12.i = zext i1 %call.i.i.i75 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %151 to i8
  %154 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %155 = and i8 %154, 1
  %conv.i.i.i78 = xor i8 %155, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %af.i.i.i80 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i80, align 1
  %cmp.i.i.i.i81 = icmp eq i32 %151, 0
  %call.i.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i81, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv5.i.i.i83 = zext i1 %call.i.i.i.i82 to i8
  %zf.i.i.i84 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i83, ptr %zf.i.i.i84, align 1
  %cmp.i27.i.i.i85 = icmp slt i32 %151, 0
  %call1.i.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i85, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv8.i.i.i87 = zext i1 %call1.i.i.i.i86 to i8
  %sf.i.i.i88 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i87, ptr %sf.i.i.i88, align 1
  %xor.i28.i.i.i89 = lshr i32 %151, 31
  %call.i30.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %151, i32 noundef 0, i32 noundef %151) #13
  %conv11.i.i.i91 = zext i1 %call.i30.i.i.i90 to i8
  %of.i.i.i92 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i91, ptr %of.i.i.i92, align 1
  store ptr %153, ptr %MEMORY, align 8
  br label %156

156:                                              ; preds = %148
  %157 = load i64, ptr %NEXT_PC, align 8
  store i64 %157, ptr %PC, align 8
  %158 = add i64 %157, 3
  store i64 %158, ptr %NEXT_PC, align 8
  %159 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %160 = load i8, ptr %zf.i, align 1
  store i8 %160, ptr %CL, align 1
  store ptr %159, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %156
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 2
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i8, ptr %AL, align 1
  %165 = zext i8 %164 to i64
  %166 = load i8, ptr %CL, align 1
  %167 = zext i8 %166 to i64
  %168 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %167, %165
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i128 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i128, align 1
  %169 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %170 = and i8 %169, 1
  %conv.i27.i = xor i8 %170, 1
  %pf.i.i129 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i129, align 1
  %171 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i130 = and i32 %171, 255
  %cmp.i.i.i131 = icmp eq i8 %or3.i.i, 0
  %172 = trunc i64 %165 to i32
  %conv1.i.i.i = and i32 %172, 255
  %173 = trunc i64 %167 to i32
  %conv2.i.i.i132 = and i32 %173, 255
  %call.i.i.i133 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i131, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i132, i32 noundef %conv.i.i.i130) #13
  %conv3.i.i134 = zext i1 %call.i.i.i133 to i8
  %zf.i.i135 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i134, ptr %zf.i.i135, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i132, i32 noundef %conv.i.i.i130) #13
  %conv6.i.i136 = zext i1 %call4.i.i.i to i8
  %sf.i.i137 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i136, ptr %sf.i.i137, align 1
  %of.i.i138 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i138, align 1
  %af.i.i139 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i139, align 1
  store ptr %168, ptr %MEMORY, align 8
  br label %174

174:                                              ; preds = %161
  %175 = load i64, ptr %NEXT_PC, align 8
  store i64 %175, ptr %PC, align 8
  %176 = add i64 %175, 2
  store i64 %176, ptr %NEXT_PC, align 8
  %177 = load i8, ptr %AL, align 1
  %178 = zext i8 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %178
  %and3.i.i140 = trunc i64 %and3.i15.i to i8
  %cf.i.i141 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i141, align 1
  %180 = and i8 %and3.i.i140, 1
  %conv.i14.i = xor i8 %180, 1
  %pf.i.i142 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i142, align 1
  %181 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i143 = and i32 %181, 255
  %cmp.i.i.i144 = icmp eq i8 %and3.i.i140, 0
  %182 = trunc i64 %178 to i32
  %conv1.i.i.i145 = and i32 %182, 255
  %call.i.i.i146 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i144, i32 noundef %conv1.i.i.i145, i32 noundef 1, i32 noundef %conv.i.i.i143) #13
  %conv3.i.i147 = zext i1 %call.i.i.i146 to i8
  %zf.i.i148 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i147, ptr %zf.i.i148, align 1
  %call4.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i145, i32 noundef 1, i32 noundef %conv.i.i.i143) #13
  %conv6.i.i150 = zext i1 %call4.i.i.i149 to i8
  %sf.i.i151 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i150, ptr %sf.i.i151, align 1
  %of.i.i152 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i152, align 1
  %af.i.i153 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i153, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %174
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 6
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i64, ptr %NEXT_PC, align 8
  %187 = add i64 %186, 5
  %188 = load i64, ptr %NEXT_PC, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %zf.i97 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %190 = load i8, ptr %zf.i97, align 1
  %tobool.not.i = icmp eq i8 %190, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %187, i64 %188
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %189, ptr %MEMORY, align 8
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = load ptr, ptr %MEMORY, align 8
  ret ptr %192
}

define ptr @BB_1420(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i56 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i56, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i53 = zext i32 %call.i.i52 to i64
  store i64 %conv.i.i53, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 84
  %17 = load i32, ptr %EAX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_32(ptr noundef %19, i64 noundef %16, i32 noundef %17) #13
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %12
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 7
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = add i64 %23, 10920
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i55 = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %24) #13
  store i64 %call.i.i55, ptr %RAX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RAX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #13
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 10999
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %36, i64 noundef %35) #13
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %41, i64 noundef %40) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %43 = and i8 %42, 1
  %conv.i.i.i5 = xor i8 %43, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %44 = trunc i32 %xor1.i.i.i.i8 to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i9 = and i8 %45, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %41, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %37
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %50 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %50, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %51 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %51, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EDX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %56, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RCX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %61 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %63 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %63, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %64 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %65 = and i8 %64, 1
  %conv.i.i.i = xor i8 %65, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %66 = trunc i32 %xor1.i.i.i.i to i8
  %67 = lshr i8 %66, 4
  %conv2.i.i.i = and i8 %67, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RCX, align 8
  %72 = load i32, ptr %EDX, align 4
  %73 = zext i32 %72 to i64
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %71 to i32
  %sext.i = shl i64 %71, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %73, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %75 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %75, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %72, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %68
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %conv.i.i57 = trunc i64 %79 to i32
  %and3.i.i = and i32 1, %conv.i.i57
  %conv.i22.i58 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i58, ptr %RCX, align 8
  %cf.i.i59 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i59, align 1
  %conv.i.i.i60 = trunc i32 %and3.i.i to i8
  %81 = and i8 %conv.i.i.i60, 1
  %conv.i23.i61 = xor i8 %81, 1
  %pf.i.i62 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i61, ptr %pf.i.i62, align 1
  %cmp.i.i.i63 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i63, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i64 to i8
  %zf.i.i65 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i65, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i66 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i66, align 1
  %of.i.i67 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i67, align 1
  %af.i.i68 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i68, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %85 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %89 = and i8 %88, 1
  %conv.i.i.i29 = xor i8 %89, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %85, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %85, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %85, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %82
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 3
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %94 = load i8, ptr %zf.i, align 1
  store i8 %94, ptr %CL, align 1
  store ptr %93, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %90
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i8, ptr %AL, align 1
  %99 = zext i8 %98 to i64
  %100 = load i8, ptr %CL, align 1
  %101 = zext i8 %100 to i64
  %102 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %101, %99
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i69 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i69, align 1
  %103 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %104 = and i8 %103, 1
  %conv.i27.i = xor i8 %104, 1
  %pf.i.i70 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i70, align 1
  %105 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i71 = and i32 %105, 255
  %cmp.i.i.i72 = icmp eq i8 %or3.i.i, 0
  %106 = trunc i64 %99 to i32
  %conv1.i.i.i = and i32 %106, 255
  %107 = trunc i64 %101 to i32
  %conv2.i.i.i73 = and i32 %107, 255
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i72, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #13
  %conv3.i.i75 = zext i1 %call.i.i.i74 to i8
  %zf.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i75, ptr %zf.i.i76, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #13
  %conv6.i.i77 = zext i1 %call4.i.i.i to i8
  %sf.i.i78 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i77, ptr %sf.i.i78, align 1
  %of.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i79, align 1
  %af.i.i80 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i80, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %95
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 2
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i8, ptr %AL, align 1
  %112 = zext i8 %111 to i64
  %113 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %112
  %and3.i.i81 = trunc i64 %and3.i15.i to i8
  %cf.i.i82 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i82, align 1
  %114 = and i8 %and3.i.i81, 1
  %conv.i14.i = xor i8 %114, 1
  %pf.i.i83 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i83, align 1
  %115 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i84 = and i32 %115, 255
  %cmp.i.i.i85 = icmp eq i8 %and3.i.i81, 0
  %116 = trunc i64 %112 to i32
  %conv1.i.i.i86 = and i32 %116, 255
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i85, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #13
  %conv3.i.i88 = zext i1 %call.i.i.i87 to i8
  %zf.i.i89 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i88, ptr %zf.i.i89, align 1
  %call4.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #13
  %conv6.i.i91 = zext i1 %call4.i.i.i90 to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i91, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i94, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %108
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 6
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  %121 = add i64 %120, 5
  %122 = load i64, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %124, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %121, i64 %122
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %123, ptr %MEMORY, align 8
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  ret ptr %126
}

define ptr @BB_1358(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_145f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 84
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %16, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %12
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #13
  %rip.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %22, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %20, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

define ptr @BB_135e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11115
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11250
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1394(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #13
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 11434
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #13
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #13
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 80
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #13
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 11027
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #13
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #13
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 11162
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #13
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #13
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #13
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #13
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #13
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #13
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_13e4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.251735, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.251735, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.251735) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.251735) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4400, label %bb_1130
    i64 4465, label %bb_1171
    i64 4627, label %bb_1213
    i64 4633, label %bb_1219
    i64 4687, label %bb_124F
    i64 4797, label %bb_12BD
    i64 4803, label %bb_12C3
    i64 4857, label %bb_12F9
    i64 4952, label %bb_1358
    i64 4958, label %bb_135E
    i64 5012, label %bb_1394
    i64 5092, label %bb_13E4
    i64 5098, label %bb_13EA
    i64 5152, label %bb_1420
    i64 5215, label %bb_145F
  ]

dead_end:                                         ; preds = %bb_1420, %bb_13EA, %bb_13E4, %bb_1394, %bb_135E, %bb_1358, %bb_12F9, %bb_12C3, %bb_12BD, %bb_124F, %bb_1219, %bb_1213, %bb_1171, %bb_1130, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1130:                                          ; preds = %entry
  %block_pc = add i64 4400, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4400, ptr %1)
  %4 = call ptr @BB_1130(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4465, label %bb_1171
  ]

bb_1171:                                          ; preds = %bb_1130, %entry
  %block_pc1 = add i64 4465, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4465, ptr %6)
  %9 = call ptr @BB_1171(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4627, label %bb_1213
  ]

bb_1213:                                          ; preds = %bb_1171, %entry
  %block_pc3 = add i64 4627, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4627, ptr %11)
  %14 = call ptr @BB_1213(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4633, label %bb_1219
  ]

bb_1219:                                          ; preds = %bb_13E4, %bb_1213, %entry
  %block_pc5 = add i64 4633, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4633, ptr %16)
  %19 = call ptr @BB_1219(ptr %state, i64 %17, ptr %16) #16
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4687, label %bb_124F
  ]

bb_124F:                                          ; preds = %bb_1219, %entry
  %block_pc7 = add i64 4687, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4687, ptr %21)
  %24 = call ptr @BB_124f(ptr %state, i64 %22, ptr %21) #16
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4797, label %bb_12BD
  ]

bb_12BD:                                          ; preds = %bb_124F, %entry
  %block_pc9 = add i64 4797, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4797, ptr %26)
  %29 = call ptr @BB_12bd(ptr %state, i64 %27, ptr %26) #16
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4803, label %bb_12C3
    i64 5098, label %bb_13EA
  ]

bb_12C3:                                          ; preds = %bb_12BD, %entry
  %block_pc11 = add i64 4803, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4803, ptr %31)
  %34 = call ptr @BB_12c3(ptr %state, i64 %32, ptr %31) #16
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4857, label %bb_12F9
  ]

bb_12F9:                                          ; preds = %bb_12C3, %entry
  %block_pc13 = add i64 4857, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4857, ptr %36)
  %39 = call ptr @BB_12f9(ptr %state, i64 %37, ptr %36) #16
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4952, label %bb_1358
  ]

bb_1358:                                          ; preds = %bb_12F9, %entry
  %block_pc15 = add i64 4952, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4952, ptr %41)
  %44 = call ptr @BB_1358(ptr %state, i64 %42, ptr %41) #16
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4958, label %bb_135E
  ]

bb_135E:                                          ; preds = %bb_1358, %entry
  %block_pc17 = add i64 4958, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4958, ptr %46)
  %49 = call ptr @BB_135e(ptr %state, i64 %47, ptr %46) #16
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 5012, label %bb_1394
  ]

bb_1394:                                          ; preds = %bb_135E, %entry
  %block_pc19 = add i64 5012, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 5012, ptr %51)
  %54 = call ptr @BB_1394(ptr %state, i64 %52, ptr %51) #16
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 5092, label %bb_13E4
  ]

bb_13E4:                                          ; preds = %bb_1394, %entry
  %block_pc21 = add i64 5092, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 5092, ptr %56)
  %59 = call ptr @BB_13e4(ptr %state, i64 %57, ptr %56) #16
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4633, label %bb_1219
  ]

bb_13EA:                                          ; preds = %bb_12BD, %entry
  %block_pc23 = add i64 5098, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 5098, ptr %61)
  %64 = call ptr @BB_13ea(ptr %state, i64 %62, ptr %61) #16
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 5152, label %bb_1420
  ]

bb_1420:                                          ; preds = %bb_13EA, %entry
  %block_pc25 = add i64 5152, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 5152, ptr %66)
  %69 = call ptr @BB_1420(ptr %state, i64 %67, ptr %66) #16
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 5215, label %bb_145F
  ]

bb_145F:                                          ; preds = %bb_1420, %entry
  %block_pc27 = add i64 5215, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 5215, ptr %71)
  %74 = call ptr @BB_145f(ptr %state, i64 %72, ptr %71) #16
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  %76 = load ptr, ptr %mem_var, align 8
  ret ptr %76

return_bb:                                        ; No predecessors!
  %77 = load ptr, ptr %mem_var, align 8
  ret ptr %77
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4400, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.251734, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
