; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.224771 = type { %struct.X86State.224770 }
%struct.X86State.224770 = type { %struct.ArchState.224739, [32 x %union.VectorReg.224742], %struct.ArithFlags.224743, %union.anon.224738, %struct.Segments.224745, %struct.AddressSpace.224747, %struct.GPR.224748, %struct.X87Stack.224751, %struct.MMX.224755, %struct.FPUStatusFlags.224756, %union.anon.224738, %union.FPU.224765, %struct.SegmentCaches.224767, %struct.K_REG.224769 }
%struct.ArchState.224739 = type { i32, i32, %union.anon.224738 }
%union.VectorReg.224742 = type { %union.vec512_t.224741 }
%union.vec512_t.224741 = type { %struct.uint64v8_t.224740 }
%struct.uint64v8_t.224740 = type { [8 x i64] }
%struct.ArithFlags.224743 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.224745 = type { i16, %union.SegmentSelector.224744, i16, %union.SegmentSelector.224744, i16, %union.SegmentSelector.224744, i16, %union.SegmentSelector.224744, i16, %union.SegmentSelector.224744, i16, %union.SegmentSelector.224744 }
%union.SegmentSelector.224744 = type { i16 }
%struct.AddressSpace.224747 = type { i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746 }
%struct.Reg.224746 = type { %union.anon.224738 }
%struct.GPR.224748 = type { i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746, i64, %struct.Reg.224746 }
%struct.X87Stack.224751 = type { [8 x %struct.anon.3.224750] }
%struct.anon.3.224750 = type { [6 x i8], %struct.float80_t.224749 }
%struct.float80_t.224749 = type { [10 x i8] }
%struct.MMX.224755 = type { [8 x %struct.anon.4.224754] }
%struct.anon.4.224754 = type { i64, %union.vec64_t.224753 }
%union.vec64_t.224753 = type { %struct.uint64v1_t.224752 }
%struct.uint64v1_t.224752 = type { [1 x i64] }
%struct.FPUStatusFlags.224756 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.224738 = type { i64 }
%union.FPU.224765 = type { %struct.anon.13.224764 }
%struct.anon.13.224764 = type { %struct.FpuFXSAVE.224763, [96 x i8] }
%struct.FpuFXSAVE.224763 = type { %union.SegmentSelector.224744, %union.SegmentSelector.224744, %union.FPUAbridgedTagWord.224757, i8, i16, i32, %union.SegmentSelector.224744, i16, i32, %union.SegmentSelector.224744, i16, %union.FPUControlStatus.224758, %union.FPUControlStatus.224758, [8 x %struct.FPUStackElem.224760], [16 x %union.vec128_t.224762] }
%union.FPUAbridgedTagWord.224757 = type { i8 }
%union.FPUControlStatus.224758 = type { i32 }
%struct.FPUStackElem.224760 = type { %union.anon.11.224759, [6 x i8] }
%union.anon.11.224759 = type { %struct.float80_t.224749 }
%union.vec128_t.224762 = type { %struct.uint128v1_t.224761 }
%struct.uint128v1_t.224761 = type { [1 x i128] }
%struct.SegmentCaches.224767 = type { %struct.SegmentShadow.224766, %struct.SegmentShadow.224766, %struct.SegmentShadow.224766, %struct.SegmentShadow.224766, %struct.SegmentShadow.224766, %struct.SegmentShadow.224766 }
%struct.SegmentShadow.224766 = type { %union.anon.224738, i32, i32 }
%struct.K_REG.224769 = type { [8 x %struct.anon.18.224768] }
%struct.anon.18.224768 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_14a0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 8
  %17 = load i64, ptr %RDI, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call ptr @__remill_write_memory_64(ptr noundef %18, i64 noundef %16, i64 noundef %17) #13
  store ptr %call.i.i3, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %12
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 16
  %24 = load i64, ptr %RSI, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call ptr @__remill_write_memory_64(ptr noundef %25, i64 noundef %23, i64 noundef %24) #13
  store ptr %call.i.i2, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %19
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 7
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RBP, align 8
  %30 = sub i64 %29, 20
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %31, i64 noundef %30, i32 noundef 0) #13
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %26
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RBP, align 8
  %36 = sub i64 %35, 24
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %37, i64 noundef %36, i32 noundef 0) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 7
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %NEXT_PC, align 8
  %42 = add i64 %41, 11167
  %43 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %43, i64 noundef %42) #13
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %43, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %38
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 2
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %47, ptr %rip.i, align 8
  store i64 %47, ptr %NEXT_PC, align 8
  store ptr %48, ptr %MEMORY, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  ret ptr %49
}

define ptr @BB_14c3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10838
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10941
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_14f9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i128 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i128, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 20
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i131 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i132 = sext i32 %call.i.i131 to i64
  store i64 %conv.i.i132, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RCX, align 8
  %18 = mul i64 %17, 1
  %19 = add i64 %16, %18
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i129 = call zeroext i8 @__remill_read_memory_8(ptr noundef %20, i64 noundef %19) #13
  %conv.i.i130 = sext i8 %call.i.i129 to i64
  %conv.i10.i = and i64 %conv.i.i130, 4294967295
  store i64 %conv.i10.i, ptr %RDX, align 8
  store ptr %20, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 5
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RCX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %21
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 5
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %25
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i32, ptr %EDX, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %32, i32 noundef 0, i32 noundef %32) #13
  %conv.i12.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i32 %32 to i8
  %35 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %36 = and i8 %35, 1
  %conv.i.i.i95 = xor i8 %36, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %af.i.i.i97 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i97, align 1
  %cmp.i.i.i.i98 = icmp eq i32 %32, 0
  %call.i.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i98, i32 noundef %32, i32 noundef 0, i32 noundef %32) #13
  %conv5.i.i.i100 = zext i1 %call.i.i.i.i99 to i8
  %zf.i.i.i101 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i100, ptr %zf.i.i.i101, align 1
  %cmp.i27.i.i.i102 = icmp slt i32 %32, 0
  %call1.i.i.i.i103 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i102, i32 noundef %32, i32 noundef 0, i32 noundef %32) #13
  %conv8.i.i.i104 = zext i1 %call1.i.i.i.i103 to i8
  %sf.i.i.i105 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i104, ptr %sf.i.i.i105, align 1
  %xor.i28.i.i.i106 = lshr i32 %32, 31
  %call.i30.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %32, i32 noundef 0, i32 noundef %32) #13
  %conv11.i.i.i108 = zext i1 %call.i30.i.i.i107 to i8
  %of.i.i.i109 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i108, ptr %of.i.i.i109, align 1
  store ptr %34, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i32, ptr %EAX, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %zf.i114 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %43 = load i8, ptr %zf.i114, align 1
  %tobool.not.i = icmp eq i8 %43, 0
  %call3.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call3.i, i64 %41, i64 %dst.coerce.val.i
  %conv.i20.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i20.i, ptr %RCX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %37
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 7
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i64, ptr %NEXT_PC, align 8
  %48 = add i64 %47, 11076
  %49 = load ptr, ptr %MEMORY, align 8
  store i64 %48, ptr %RAX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 3
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i32, ptr %ECX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %sext.i133 = shl i64 %54, 32
  %conv.i12.i134 = ashr exact i64 %sext.i133, 32
  store i64 %conv.i12.i134, ptr %RCX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 4
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = mul i64 %60, 8
  %62 = add i64 %59, %61
  %63 = load ptr, ptr %MEMORY, align 8
  %call.i.i127 = call i64 @__remill_read_memory_64(ptr noundef %63, i64 noundef %62) #13
  store i64 %call.i.i127, ptr %RAX, align 8
  store ptr %63, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %56
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 2
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %RCX, align 8
  %68 = load i32, ptr %ECX, align 4
  %69 = zext i32 %68 to i64
  %70 = load ptr, ptr %MEMORY, align 8
  %conv.i.i159 = trunc i64 %67 to i32
  %xor3.i.i = xor i32 %68, %conv.i.i159
  %conv.i27.i160 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i160, ptr %RCX, align 8
  %cf.i.i161 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i161, align 1
  %conv.i.i.i162 = trunc i32 %xor3.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i162)
  %72 = and i8 %71, 1
  %conv.i28.i163 = xor i8 %72, 1
  %pf.i.i164 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i163, ptr %pf.i.i164, align 1
  %cmp.i.i.i165 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i166 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i165, i32 noundef %conv.i.i159, i32 noundef %68, i32 noundef %xor3.i.i) #13
  %conv3.i.i167 = zext i1 %call.i.i.i166 to i8
  %zf.i.i168 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i167, ptr %zf.i.i168, align 1
  %cmp.i19.i.i169 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i170 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i169, i32 noundef %conv.i.i159, i32 noundef %68, i32 noundef %xor3.i.i) #13
  %conv6.i.i171 = zext i1 %call1.i.i.i170 to i8
  %sf.i.i172 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i171, ptr %sf.i.i172, align 1
  %of.i.i173 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i173, align 1
  %af.i.i174 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i175 = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i175, ptr %af.i.i174, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %64
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i32, ptr %EDX, align 4
  %77 = zext i32 %76 to i64
  %78 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %76, i32 noundef 0, i32 noundef %76) #13
  %conv.i12.i73 = zext i1 %call.i.i.i72 to i8
  %cf.i.i74 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i73, ptr %cf.i.i74, align 1
  %conv.i.i.i.i75 = trunc i32 %76 to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i75)
  %80 = and i8 %79, 1
  %conv.i.i.i76 = xor i8 %80, 1
  %pf.i.i.i77 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i76, ptr %pf.i.i.i77, align 1
  %af.i.i.i78 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i78, align 1
  %cmp.i.i.i.i79 = icmp eq i32 %76, 0
  %call.i.i.i.i80 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i79, i32 noundef %76, i32 noundef 0, i32 noundef %76) #13
  %conv5.i.i.i81 = zext i1 %call.i.i.i.i80 to i8
  %zf.i.i.i82 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i81, ptr %zf.i.i.i82, align 1
  %cmp.i27.i.i.i83 = icmp slt i32 %76, 0
  %call1.i.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i83, i32 noundef %76, i32 noundef 0, i32 noundef %76) #13
  %conv8.i.i.i85 = zext i1 %call1.i.i.i.i84 to i8
  %sf.i.i.i86 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i85, ptr %sf.i.i.i86, align 1
  %xor.i28.i.i.i87 = lshr i32 %76, 31
  %call.i30.i.i.i88 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %76, i32 noundef 0, i32 noundef %76) #13
  %conv11.i.i.i89 = zext i1 %call.i30.i.i.i88 to i8
  %of.i.i.i90 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i89, ptr %of.i.i.i90, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %73
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 4
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RCX, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %zf.i115 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %86 = load i8, ptr %zf.i115, align 1
  %tobool.not.i116 = icmp eq i8 %86, 0
  %call3.i117 = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i116) #14
  %dst.coerce.val.i118 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call3.i117, i64 %84, i64 %dst.coerce.val.i118
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %85, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RAX, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %90, %91
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %90, %91
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %90, i64 noundef %91, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %94 = and i8 %93, 1
  %conv.i.i.i6 = xor i8 %94, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %91, %90
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %95 = trunc i64 %xor1.i.i.i.i9 to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i10 = and i8 %96, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %90, %91
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %90, i64 noundef %91, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %90, i64 noundef %91, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %90
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %90, i64 noundef %91, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 4
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RBP, align 8
  %101 = sub i64 %100, 32
  %102 = load i64, ptr %RAX, align 8
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i122 = call ptr @__remill_write_memory_64(ptr noundef %103, i64 noundef %101, i64 noundef %102) #13
  store ptr %call.i.i122, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %97
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 7
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i64, ptr %NEXT_PC, align 8
  %108 = add i64 %107, 10718
  %109 = load ptr, ptr %MEMORY, align 8
  %call.i.i126 = call i64 @__remill_read_memory_64(ptr noundef %109, i64 noundef %108) #13
  store i64 %call.i.i126, ptr %RAX, align 8
  store ptr %109, ptr %MEMORY, align 8
  br label %110

110:                                              ; preds = %104
  %111 = load i64, ptr %NEXT_PC, align 8
  store i64 %111, ptr %PC, align 8
  %112 = add i64 %111, 2
  store i64 %112, ptr %NEXT_PC, align 8
  %113 = load i64, ptr %RAX, align 8
  %114 = load ptr, ptr %MEMORY, align 8
  %call.i.i123 = call i32 @__remill_read_memory_32(ptr noundef %114, i64 noundef %113) #13
  %conv.i.i124 = zext i32 %call.i.i123 to i64
  store i64 %conv.i.i124, ptr %RDX, align 8
  store ptr %114, ptr %MEMORY, align 8
  br label %115

115:                                              ; preds = %110
  %116 = load i64, ptr %NEXT_PC, align 8
  store i64 %116, ptr %PC, align 8
  %117 = add i64 %116, 7
  store i64 %117, ptr %NEXT_PC, align 8
  %118 = load i64, ptr %NEXT_PC, align 8
  %119 = add i64 %118, 10797
  %120 = load ptr, ptr %MEMORY, align 8
  %call.i.i125 = call i64 @__remill_read_memory_64(ptr noundef %120, i64 noundef %119) #13
  store i64 %call.i.i125, ptr %RAX, align 8
  store ptr %120, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %115
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load i64, ptr %RAX, align 8
  %125 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %125, i64 noundef %124) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %126 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %127 = and i8 %126, 1
  %conv.i.i.i32 = xor i8 %127, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %128 = trunc i32 %xor1.i.i.i.i35 to i8
  %129 = lshr i8 %128, 4
  %conv2.i.i.i36 = and i8 %129, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %121
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 3
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  %134 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %134, 0
  %of.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  %135 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %135, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %133, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %130
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 2
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i32, ptr %EDX, align 4
  %140 = zext i32 %139 to i64
  %141 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %140, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %141, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %136
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RCX, align 8
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %145 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %147 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %147, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %148 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %149 = and i8 %148, 1
  %conv.i.i.i = xor i8 %149, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %150 = trunc i32 %xor1.i.i.i.i to i8
  %151 = lshr i8 %150, 4
  %conv2.i.i.i = and i8 %151, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %152

152:                                              ; preds = %142
  %153 = load i64, ptr %NEXT_PC, align 8
  store i64 %153, ptr %PC, align 8
  %154 = add i64 %153, 3
  store i64 %154, ptr %NEXT_PC, align 8
  %155 = load i64, ptr %RCX, align 8
  %156 = load i32, ptr %EDX, align 4
  %157 = zext i32 %156 to i64
  %158 = load ptr, ptr %MEMORY, align 8
  %conv.i.i110 = trunc i64 %155 to i32
  %sext.i = shl i64 %155, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %157, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %159 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i111 = icmp ult i64 %159, -4294967296
  %call.i.i.i112 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv.i.i110, i32 noundef %156, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i112 to i8
  %cf.i.i113 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i113, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %158, ptr %MEMORY, align 8
  br label %160

160:                                              ; preds = %152
  %161 = load i64, ptr %NEXT_PC, align 8
  store i64 %161, ptr %PC, align 8
  %162 = add i64 %161, 3
  store i64 %162, ptr %NEXT_PC, align 8
  %163 = load i64, ptr %RCX, align 8
  %164 = load ptr, ptr %MEMORY, align 8
  %conv.i.i135 = trunc i64 %163 to i32
  %and3.i.i = and i32 1, %conv.i.i135
  %conv.i22.i136 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i136, ptr %RCX, align 8
  %cf.i.i137 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i137, align 1
  %conv.i.i.i138 = trunc i32 %and3.i.i to i8
  %165 = and i8 %conv.i.i.i138, 1
  %conv.i23.i139 = xor i8 %165, 1
  %pf.i.i140 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i139, ptr %pf.i.i140, align 1
  %cmp.i.i.i141 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i141, i32 noundef %conv.i.i135, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i142 to i8
  %zf.i.i143 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i143, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i135, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i146, align 1
  store ptr %164, ptr %MEMORY, align 8
  br label %166

166:                                              ; preds = %160
  %167 = load i64, ptr %NEXT_PC, align 8
  store i64 %167, ptr %PC, align 8
  %168 = add i64 %167, 3
  store i64 %168, ptr %NEXT_PC, align 8
  %169 = load i32, ptr %ECX, align 4
  %170 = zext i32 %169 to i64
  %171 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %169, i32 noundef 0, i32 noundef %169) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %169 to i8
  %172 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %173 = and i8 %172, 1
  %conv.i.i.i57 = xor i8 %173, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %169, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %169, i32 noundef 0, i32 noundef %169) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %169, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %169, i32 noundef 0, i32 noundef %169) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %169, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %169, i32 noundef 0, i32 noundef %169) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %171, ptr %MEMORY, align 8
  br label %174

174:                                              ; preds = %166
  %175 = load i64, ptr %NEXT_PC, align 8
  store i64 %175, ptr %PC, align 8
  %176 = add i64 %175, 3
  store i64 %176, ptr %NEXT_PC, align 8
  %177 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %178 = load i8, ptr %zf.i, align 1
  store i8 %178, ptr %CL, align 1
  store ptr %177, ptr %MEMORY, align 8
  br label %179

179:                                              ; preds = %174
  %180 = load i64, ptr %NEXT_PC, align 8
  store i64 %180, ptr %PC, align 8
  %181 = add i64 %180, 2
  store i64 %181, ptr %NEXT_PC, align 8
  %182 = load i8, ptr %AL, align 1
  %183 = zext i8 %182 to i64
  %184 = load i8, ptr %CL, align 1
  %185 = zext i8 %184 to i64
  %186 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %185, %183
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i147 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i147, align 1
  %187 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %188 = and i8 %187, 1
  %conv.i27.i = xor i8 %188, 1
  %pf.i.i148 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i148, align 1
  %189 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i149 = and i32 %189, 255
  %cmp.i.i.i150 = icmp eq i8 %or3.i.i, 0
  %190 = trunc i64 %183 to i32
  %conv1.i.i.i = and i32 %190, 255
  %191 = trunc i64 %185 to i32
  %conv2.i.i.i151 = and i32 %191, 255
  %call.i.i.i152 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i150, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i151, i32 noundef %conv.i.i.i149) #13
  %conv3.i.i153 = zext i1 %call.i.i.i152 to i8
  %zf.i.i154 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i153, ptr %zf.i.i154, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i151, i32 noundef %conv.i.i.i149) #13
  %conv6.i.i155 = zext i1 %call4.i.i.i to i8
  %sf.i.i156 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i155, ptr %sf.i.i156, align 1
  %of.i.i157 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i157, align 1
  %af.i.i158 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i158, align 1
  store ptr %186, ptr %MEMORY, align 8
  br label %192

192:                                              ; preds = %179
  %193 = load i64, ptr %NEXT_PC, align 8
  store i64 %193, ptr %PC, align 8
  %194 = add i64 %193, 2
  store i64 %194, ptr %NEXT_PC, align 8
  %195 = load i8, ptr %AL, align 1
  %196 = zext i8 %195 to i64
  %197 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %196
  %and3.i.i176 = trunc i64 %and3.i15.i to i8
  %cf.i.i177 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i177, align 1
  %198 = and i8 %and3.i.i176, 1
  %conv.i14.i = xor i8 %198, 1
  %pf.i.i178 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i178, align 1
  %199 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i179 = and i32 %199, 255
  %cmp.i.i.i180 = icmp eq i8 %and3.i.i176, 0
  %200 = trunc i64 %196 to i32
  %conv1.i.i.i181 = and i32 %200, 255
  %call.i.i.i182 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i180, i32 noundef %conv1.i.i.i181, i32 noundef 1, i32 noundef %conv.i.i.i179) #13
  %conv3.i.i183 = zext i1 %call.i.i.i182 to i8
  %zf.i.i184 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i183, ptr %zf.i.i184, align 1
  %call4.i.i.i185 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i181, i32 noundef 1, i32 noundef %conv.i.i.i179) #13
  %conv6.i.i186 = zext i1 %call4.i.i.i185 to i8
  %sf.i.i187 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i186, ptr %sf.i.i187, align 1
  %of.i.i188 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i188, align 1
  %af.i.i189 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i189, align 1
  store ptr %197, ptr %MEMORY, align 8
  br label %201

201:                                              ; preds = %192
  %202 = load i64, ptr %NEXT_PC, align 8
  store i64 %202, ptr %PC, align 8
  %203 = add i64 %202, 6
  store i64 %203, ptr %NEXT_PC, align 8
  %204 = load i64, ptr %NEXT_PC, align 8
  %205 = add i64 %204, 5
  %206 = load i64, ptr %NEXT_PC, align 8
  %207 = load ptr, ptr %MEMORY, align 8
  %zf.i119 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %208 = load i8, ptr %zf.i119, align 1
  %tobool.not.i120 = icmp eq i8 %208, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i120) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i121 = select i1 %call9.i, i64 %205, i64 %206
  store i64 %cond1.i.i121, ptr %NEXT_PC, align 8
  store ptr %207, ptr %MEMORY, align 8
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = load ptr, ptr %MEMORY, align 8
  ret ptr %210
}

define ptr @BB_1569(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1580(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10993
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_156f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i2 = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %add.i.i = add i32 %conv.i.i, 1
  %conv.i16.i = zext i32 %add.i.i to i64
  store i64 %conv.i16.i, ptr %RAX, align 8
  %conv.i.i.i = trunc i32 %add.i.i to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %13 = and i8 %12, 1
  %conv.i17.i = xor i8 %13, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i17.i, ptr %pf.i.i, align 1
  %xor1.i.i.i = xor i32 %add.i.i, %conv.i.i
  %14 = trunc i32 %xor1.i.i.i to i8
  %15 = lshr i8 %14, 4
  %conv2.i.i = and i8 %15, 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i, ptr %af.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i, ptr %zf.i.i, align 1
  %cmp.i27.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i, ptr %sf.i.i, align 1
  %xor.i28.i.i = lshr i32 %xor1.i.i.i, 31
  %xor3.i.i.i = lshr i32 %add.i.i, 31
  %add.i.i.i = add nuw nsw i32 %xor.i28.i.i, %xor3.i.i.i
  %cmp.i29.i.i = icmp eq i32 %add.i.i.i, 2
  %call.i30.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i = zext i1 %call.i30.i.i to i8
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i, ptr %of.i.i, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %7
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 3
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %RBP, align 8
  %20 = sub i64 %19, 20
  %21 = load i32, ptr %EAX, align 4
  %22 = zext i32 %21 to i64
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %23, i64 noundef %20, i32 noundef %21) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %16
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 7
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %NEXT_PC, align 8
  %28 = add i64 %27, 10978
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %29, i64 noundef %28) #13
  store i64 %call.i.i3, ptr %RAX, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %24
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 2
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RAX, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %33, ptr %rip.i, align 8
  store i64 %33, ptr %NEXT_PC, align 8
  store ptr %34, ptr %MEMORY, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  ret ptr %35
}

define ptr @BB_1589(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 24
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i = sext i32 %call.i.i4 to i64
  store i64 %conv.i.i, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RCX, align 8
  %18 = mul i64 %17, 1
  %19 = add i64 %16, %18
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call zeroext i8 @__remill_read_memory_8(ptr noundef %20, i64 noundef %19) #13
  store i8 %call.i.i, ptr %AL, align 1
  store ptr %20, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i8, ptr %AL, align 1
  %25 = zext i8 %24 to i64
  %26 = load i8, ptr %AL, align 1
  %27 = zext i8 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 %27, %25
  %and3.i.i = trunc i64 %and3.i15.i to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i6, align 1
  %29 = call i8 @llvm.ctpop.i8(i8 %and3.i.i)
  %30 = and i8 %29, 1
  %conv.i14.i = xor i8 %30, 1
  %pf.i.i7 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i7, align 1
  %31 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i8 = and i32 %31, 255
  %cmp.i.i.i9 = icmp eq i8 %and3.i.i, 0
  %32 = trunc i64 %25 to i32
  %conv1.i.i.i = and i32 %32, 255
  %33 = trunc i64 %27 to i32
  %conv2.i.i.i = and i32 %33, 255
  %call.i.i.i10 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i9, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i, i32 noundef %conv.i.i.i8) #13
  %conv3.i.i11 = zext i1 %call.i.i.i10 to i8
  %zf.i.i12 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i11, ptr %zf.i.i12, align 1
  %cmp.i19.i.i13 = icmp slt i8 %and3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i13, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i, i32 noundef %conv.i.i.i8) #13
  %conv6.i.i14 = zext i1 %call4.i.i.i to i8
  %sf.i.i15 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i14, ptr %sf.i.i15, align 1
  %of.i.i16 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i16, align 1
  %af.i.i17 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i17, align 1
  store ptr %28, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %21
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 3
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %38 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %38, 0
  %conv.i = zext i1 %tobool.not.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %37, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %34
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i8, ptr %AL, align 1
  %43 = zext i8 %42 to i64
  %44 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i3 = and i64 %43, 255
  store i64 %conv.i11.i3, ptr %RAX, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %39
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 3
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RAX, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %conv.i.i5 = trunc i64 %48 to i32
  %xor3.i.i = xor i32 5, %conv.i.i5
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RAX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %xor3.i.i to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %51 = and i8 %50, 1
  %conv.i28.i = xor i8 %51, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i5, i32 noundef 5, i32 noundef %xor3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i5, i32 noundef 5, i32 noundef %xor3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %45
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EAX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %56, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 7
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %NEXT_PC, align 8
  %62 = add i64 %61, 10936
  %63 = load ptr, ptr %MEMORY, align 8
  store i64 %62, ptr %RAX, align 8
  store ptr %63, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 4
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %RAX, align 8
  %68 = load i64, ptr %RCX, align 8
  %69 = mul i64 %68, 8
  %70 = add i64 %67, %69
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %71, i64 noundef %70) #13
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %64
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 2
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RAX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %75, ptr %rip.i, align 8
  store i64 %75, ptr %NEXT_PC, align 8
  store ptr %76, ptr %MEMORY, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  ret ptr %77
}

define ptr @BB_1657(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10610
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10473
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_15ae(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10763
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #13
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10626
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #13
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #13
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #13
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_168d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 20
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i55 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i56 = sext i32 %call.i.i55 to i64
  store i64 %conv.i.i56, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RCX, align 8
  %18 = mul i64 %17, 1
  %19 = add i64 %16, %18
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_8(ptr noundef %20, i64 noundef %19, i8 noundef zeroext 0) #13
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 10536
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i53 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #13
  store i64 %call.i.i53, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #13
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 10399
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #13
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %44 = and i8 %43, 1
  %conv.i.i.i5 = xor i8 %44, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i8 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i9 = and i8 %46, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %76, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %73, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i57 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i57
  %conv.i22.i58 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i58, ptr %RCX, align 8
  %cf.i.i59 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i59, align 1
  %conv.i.i.i60 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i60, 1
  %conv.i23.i61 = xor i8 %82, 1
  %pf.i.i62 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i61, ptr %pf.i.i62, align 1
  %cmp.i.i.i63 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i63, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i64 to i8
  %zf.i.i65 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i65, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i66 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i66, align 1
  %of.i.i67 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i67, align 1
  %af.i.i68 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i68, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #13
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %90 = and i8 %89, 1
  %conv.i.i.i29 = xor i8 %90, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %86, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %86, i32 noundef 0, i32 noundef %86) #13
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %86, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %86, i32 noundef 0, i32 noundef %86) #13
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %86, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #13
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i69 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i69, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i70 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i70, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i71 = and i32 %106, 255
  %cmp.i.i.i72 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i73 = and i32 %108, 255
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i72, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #13
  %conv3.i.i75 = zext i1 %call.i.i.i74 to i8
  %zf.i.i76 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i75, ptr %zf.i.i76, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #13
  %conv6.i.i77 = zext i1 %call4.i.i.i to i8
  %sf.i.i78 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i77, ptr %sf.i.i78, align 1
  %of.i.i79 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i79, align 1
  %af.i.i80 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i80, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i81 = trunc i64 %and3.i15.i to i8
  %cf.i.i82 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i82, align 1
  %115 = and i8 %and3.i.i81, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i83 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i83, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i84 = and i32 %116, 255
  %cmp.i.i.i85 = icmp eq i8 %and3.i.i81, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i86 = and i32 %117, 255
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i85, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #13
  %conv3.i.i88 = zext i1 %call.i.i.i87 to i8
  %zf.i.i89 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i88, ptr %zf.i.i89, align 1
  %call4.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #13
  %conv6.i.i91 = zext i1 %call4.i.i.i90 to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i91, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i94, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_15e4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %DL = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i145 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i145, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 24
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i149 = sext i32 %call.i.i148 to i64
  store i64 %conv.i.i149, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load i64, ptr %RCX, align 8
  %18 = mul i64 %17, 1
  %19 = add i64 %16, %18
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i134 = call zeroext i8 @__remill_read_memory_8(ptr noundef %20, i64 noundef %19) #13
  store i8 %call.i.i134, ptr %DL, align 1
  store ptr %20, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 4
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 8
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i144 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #13
  store i64 %call.i.i144, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 4
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RBP, align 8
  %31 = sub i64 %30, 20
  %32 = load ptr, ptr %MEMORY, align 8
  %call.i.i146 = call i32 @__remill_read_memory_32(ptr noundef %32, i64 noundef %31) #13
  %conv.i.i147 = sext i32 %call.i.i146 to i64
  store i64 %conv.i.i147, ptr %RCX, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RAX, align 8
  %37 = load i64, ptr %RCX, align 8
  %38 = mul i64 %37, 1
  %39 = add i64 %36, %38
  %40 = load i8, ptr %DL, align 1
  %41 = zext i8 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i130 = call ptr @__remill_write_memory_8(ptr noundef %42, i64 noundef %39, i8 noundef zeroext %40) #13
  store ptr %call.i.i130, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %33
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 3
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RBP, align 8
  %47 = sub i64 %46, 20
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i139 = call i32 @__remill_read_memory_32(ptr noundef %48, i64 noundef %47) #13
  %conv.i.i140 = zext i32 %call.i.i139 to i64
  store i64 %conv.i.i140, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %52 to i32
  %add.i.i33 = add i32 1, %conv.i.i32
  %conv.i22.i34 = zext i32 %add.i.i33 to i64
  store i64 %conv.i22.i34, ptr %RAX, align 8
  %cmp.i.i.i35 = icmp ult i32 %add.i.i33, %conv.i.i32
  %cmp1.i.i.i36 = icmp ult i32 %add.i.i33, 1
  %54 = or i1 %cmp.i.i.i35, %cmp1.i.i.i36
  %call.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %54, i32 noundef %conv.i.i32, i32 noundef 1, i32 noundef %add.i.i33) #13
  %conv.i23.i38 = zext i1 %call.i.i.i37 to i8
  %cf.i.i39 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i38, ptr %cf.i.i39, align 1
  %conv.i.i.i.i40 = trunc i32 %add.i.i33 to i8
  %55 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i40)
  %56 = and i8 %55, 1
  %conv.i.i.i41 = xor i8 %56, 1
  %pf.i.i.i42 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i41, ptr %pf.i.i.i42, align 1
  %xor.i.i.i.i43 = xor i32 %add.i.i33, 1
  %xor1.i.i.i.i44 = xor i32 %xor.i.i.i.i43, %conv.i.i32
  %57 = trunc i32 %xor1.i.i.i.i44 to i8
  %58 = lshr i8 %57, 4
  %conv2.i.i.i45 = and i8 %58, 1
  %af.i.i.i46 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i45, ptr %af.i.i.i46, align 1
  %cmp.i.i.i.i47 = icmp eq i32 %add.i.i33, 0
  %call.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i47, i32 noundef %conv.i.i32, i32 noundef 1, i32 noundef %add.i.i33) #13
  %conv5.i.i.i49 = zext i1 %call.i.i.i.i48 to i8
  %zf.i.i.i50 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i49, ptr %zf.i.i.i50, align 1
  %cmp.i27.i.i.i51 = icmp slt i32 %add.i.i33, 0
  %call1.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i51, i32 noundef %conv.i.i32, i32 noundef 1, i32 noundef %add.i.i33) #13
  %conv8.i.i.i53 = zext i1 %call1.i.i.i.i52 to i8
  %sf.i.i.i54 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i53, ptr %sf.i.i.i54, align 1
  %shr8.i.i.i.i55 = xor i32 %add.i.i33, %conv.i.i32
  %xor.i28.i.i.i56 = lshr i32 %shr8.i.i.i.i55, 31
  %xor3.i.i.i.i57 = lshr i32 %xor.i.i.i.i43, 31
  %add.i.i.i.i58 = add nuw nsw i32 %xor.i28.i.i.i56, %xor3.i.i.i.i57
  %cmp.i29.i.i.i59 = icmp eq i32 %add.i.i.i.i58, 2
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i59, i32 noundef %conv.i.i32, i32 noundef 1, i32 noundef %add.i.i33) #13
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %53, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %49
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RBP, align 8
  %63 = sub i64 %62, 20
  %64 = load i32, ptr %EAX, align 4
  %65 = zext i32 %64 to i64
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i132 = call ptr @__remill_write_memory_32(ptr noundef %66, i64 noundef %63, i32 noundef %64) #13
  store ptr %call.i.i132, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %59
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RBP, align 8
  %71 = sub i64 %70, 24
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i137 = call i32 @__remill_read_memory_32(ptr noundef %72, i64 noundef %71) #13
  %conv.i.i138 = zext i32 %call.i.i137 to i64
  store i64 %conv.i.i138, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %76 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RAX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %78 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %78, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %80 = and i8 %79, 1
  %conv.i.i.i10 = xor i8 %80, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %81 = trunc i32 %xor1.i.i.i.i13 to i8
  %82 = lshr i8 %81, 4
  %conv2.i.i.i14 = and i8 %82, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %73
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i64, ptr %RBP, align 8
  %87 = sub i64 %86, 24
  %88 = load i32, ptr %EAX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %call.i.i131 = call ptr @__remill_write_memory_32(ptr noundef %90, i64 noundef %87, i32 noundef %88) #13
  store ptr %call.i.i131, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 7
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i64, ptr %NEXT_PC, align 8
  %95 = add i64 %94, 10853
  %96 = load ptr, ptr %MEMORY, align 8
  %call.i.i143 = call i64 @__remill_read_memory_64(ptr noundef %96, i64 noundef %95) #13
  store i64 %call.i.i143, ptr %RAX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %91
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 4
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RAX, align 8
  %101 = load ptr, ptr %MEMORY, align 8
  store i64 %100, ptr %RAX, align 8
  %call.i.i.i63 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %100, i64 noundef 0, i64 noundef %100) #13
  %conv.i.i64 = zext i1 %call.i.i.i63 to i8
  %cf.i.i65 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i64, ptr %cf.i.i65, align 1
  %conv.i.i.i.i66 = trunc i64 %100 to i8
  %102 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i66)
  %103 = and i8 %102, 1
  %conv.i.i.i67 = xor i8 %103, 1
  %pf.i.i.i68 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i67, ptr %pf.i.i.i68, align 1
  %af.i.i.i69 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i69, align 1
  %cmp.i.i.i.i70 = icmp eq i64 %100, 0
  %call.i.i.i.i71 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i70, i64 noundef %100, i64 noundef 0, i64 noundef %100) #13
  %conv5.i.i.i72 = zext i1 %call.i.i.i.i71 to i8
  %zf.i.i.i73 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i72, ptr %zf.i.i.i73, align 1
  %cmp.i27.i.i.i74 = icmp slt i64 %100, 0
  %call1.i.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i74, i64 noundef %100, i64 noundef 0, i64 noundef %100) #13
  %conv8.i.i.i76 = zext i1 %call1.i.i.i.i75 to i8
  %sf.i.i.i77 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i76, ptr %sf.i.i.i77, align 1
  %xor.i28.i.i.i78 = lshr i64 %100, 63
  %call.i30.i.i.i79 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %100, i64 noundef 0, i64 noundef %100) #13
  %conv11.i.i.i80 = zext i1 %call.i30.i.i.i79 to i8
  %of.i.i.i81 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i80, ptr %of.i.i.i81, align 1
  store ptr %101, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %97
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 4
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i64, ptr %RBP, align 8
  %108 = sub i64 %107, 40
  %109 = load i64, ptr %RAX, align 8
  %110 = load ptr, ptr %MEMORY, align 8
  %call.i.i133 = call ptr @__remill_write_memory_64(ptr noundef %110, i64 noundef %108, i64 noundef %109) #13
  store ptr %call.i.i133, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %104
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 7
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i64, ptr %NEXT_PC, align 8
  %115 = add i64 %114, 10646
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i142 = call i64 @__remill_read_memory_64(ptr noundef %116, i64 noundef %115) #13
  store i64 %call.i.i142, ptr %RAX, align 8
  store ptr %116, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %111
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 2
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %RAX, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %call.i.i135 = call i32 @__remill_read_memory_32(ptr noundef %121, i64 noundef %120) #13
  %conv.i.i136 = zext i32 %call.i.i135 to i64
  store i64 %conv.i.i136, ptr %RDX, align 8
  store ptr %121, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %117
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 7
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load i64, ptr %NEXT_PC, align 8
  %126 = add i64 %125, 10509
  %127 = load ptr, ptr %MEMORY, align 8
  %call.i.i141 = call i64 @__remill_read_memory_64(ptr noundef %127, i64 noundef %126) #13
  store i64 %call.i.i141, ptr %RAX, align 8
  store ptr %127, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %122
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 3
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load i64, ptr %RAX, align 8
  %132 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %132, i64 noundef %131) #13
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i82 = icmp ult i32 %call.i.i, 10
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i82, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i83 to i8
  %cf.i.i84 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i84, align 1
  %conv.i.i.i.i85 = trunc i32 %sub.i.i to i8
  %133 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i85)
  %134 = and i8 %133, 1
  %conv.i.i.i86 = xor i8 %134, 1
  %pf.i.i.i87 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i86, ptr %pf.i.i.i87, align 1
  %xor.i.i.i.i88 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i89 = xor i32 %xor.i.i.i.i88, %sub.i.i
  %135 = trunc i32 %xor1.i.i.i.i89 to i8
  %136 = lshr i8 %135, 4
  %conv2.i.i.i90 = and i8 %136, 1
  %af.i.i.i91 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i90, ptr %af.i.i.i91, align 1
  %cmp.i.i.i.i92 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i93 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i92, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i94 = zext i1 %call.i.i.i.i93 to i8
  %zf.i.i.i95 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i94, ptr %zf.i.i.i95, align 1
  %cmp.i27.i.i.i96 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i96, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i98 = zext i1 %call1.i.i.i.i97 to i8
  %sf.i.i.i99 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i98, ptr %sf.i.i.i99, align 1
  %xor.i28.i.i.i100 = lshr i32 %xor.i.i.i.i88, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i101 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i102 = add nuw nsw i32 %xor3.i.i.i.i101, %xor.i28.i.i.i100
  %cmp.i29.i.i.i103 = icmp eq i32 %add.i.i.i.i102, 2
  %call.i30.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i103, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i105 = zext i1 %call.i30.i.i.i104 to i8
  %of.i.i.i106 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i105, ptr %of.i.i.i106, align 1
  store ptr %132, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %128
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 3
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  %141 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %141, 0
  %of.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  %142 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %142, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %137
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 2
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i32, ptr %EDX, align 4
  %147 = zext i32 %146 to i64
  %148 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %147, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %148, ptr %MEMORY, align 8
  br label %149

149:                                              ; preds = %143
  %150 = load i64, ptr %NEXT_PC, align 8
  store i64 %150, ptr %PC, align 8
  %151 = add i64 %150, 3
  store i64 %151, ptr %NEXT_PC, align 8
  %152 = load i64, ptr %RCX, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %152 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %154 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %154, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %155 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %156 = and i8 %155, 1
  %conv.i.i.i = xor i8 %156, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %157 = trunc i32 %xor1.i.i.i.i to i8
  %158 = lshr i8 %157, 4
  %conv2.i.i.i = and i8 %158, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %153, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %149
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 3
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i64, ptr %RCX, align 8
  %163 = load i32, ptr %EDX, align 4
  %164 = zext i32 %163 to i64
  %165 = load ptr, ptr %MEMORY, align 8
  %conv.i.i125 = trunc i64 %162 to i32
  %sext.i = shl i64 %162, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %164, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %166 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i126 = icmp ult i64 %166, -4294967296
  %call.i.i.i127 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i126, i32 noundef %conv.i.i125, i32 noundef %163, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i127 to i8
  %cf.i.i128 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i128, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %165, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %159
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 3
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i64, ptr %RCX, align 8
  %171 = load ptr, ptr %MEMORY, align 8
  %conv.i.i150 = trunc i64 %170 to i32
  %and3.i.i = and i32 1, %conv.i.i150
  %conv.i22.i151 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i151, ptr %RCX, align 8
  %cf.i.i152 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i152, align 1
  %conv.i.i.i153 = trunc i32 %and3.i.i to i8
  %172 = and i8 %conv.i.i.i153, 1
  %conv.i23.i154 = xor i8 %172, 1
  %pf.i.i155 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i154, ptr %pf.i.i155, align 1
  %cmp.i.i.i156 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i157 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i156, i32 noundef %conv.i.i150, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i157 to i8
  %zf.i.i158 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i158, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i150, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i159 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i159, align 1
  %of.i.i160 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i160, align 1
  %af.i.i161 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i161, align 1
  store ptr %171, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %167
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 3
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i32, ptr %ECX, align 4
  %177 = zext i32 %176 to i64
  %178 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %176, i32 noundef 0, i32 noundef %176) #13
  %conv.i12.i = zext i1 %call.i.i.i107 to i8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i108, align 1
  %conv.i.i.i.i109 = trunc i32 %176 to i8
  %179 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i109)
  %180 = and i8 %179, 1
  %conv.i.i.i110 = xor i8 %180, 1
  %pf.i.i.i111 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i110, ptr %pf.i.i.i111, align 1
  %af.i.i.i112 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i112, align 1
  %cmp.i.i.i.i113 = icmp eq i32 %176, 0
  %call.i.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i113, i32 noundef %176, i32 noundef 0, i32 noundef %176) #13
  %conv5.i.i.i115 = zext i1 %call.i.i.i.i114 to i8
  %zf.i.i.i116 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i115, ptr %zf.i.i.i116, align 1
  %cmp.i27.i.i.i117 = icmp slt i32 %176, 0
  %call1.i.i.i.i118 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i117, i32 noundef %176, i32 noundef 0, i32 noundef %176) #13
  %conv8.i.i.i119 = zext i1 %call1.i.i.i.i118 to i8
  %sf.i.i.i120 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i119, ptr %sf.i.i.i120, align 1
  %xor.i28.i.i.i121 = lshr i32 %176, 31
  %call.i30.i.i.i122 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %176, i32 noundef 0, i32 noundef %176) #13
  %conv11.i.i.i123 = zext i1 %call.i30.i.i.i122 to i8
  %of.i.i.i124 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i123, ptr %of.i.i.i124, align 1
  store ptr %178, ptr %MEMORY, align 8
  br label %181

181:                                              ; preds = %173
  %182 = load i64, ptr %NEXT_PC, align 8
  store i64 %182, ptr %PC, align 8
  %183 = add i64 %182, 3
  store i64 %183, ptr %NEXT_PC, align 8
  %184 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %185 = load i8, ptr %zf.i, align 1
  store i8 %185, ptr %CL, align 1
  store ptr %184, ptr %MEMORY, align 8
  br label %186

186:                                              ; preds = %181
  %187 = load i64, ptr %NEXT_PC, align 8
  store i64 %187, ptr %PC, align 8
  %188 = add i64 %187, 2
  store i64 %188, ptr %NEXT_PC, align 8
  %189 = load i8, ptr %AL, align 1
  %190 = zext i8 %189 to i64
  %191 = load i8, ptr %CL, align 1
  %192 = zext i8 %191 to i64
  %193 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %192, %190
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i162 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i162, align 1
  %194 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %195 = and i8 %194, 1
  %conv.i27.i = xor i8 %195, 1
  %pf.i.i163 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i163, align 1
  %196 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i164 = and i32 %196, 255
  %cmp.i.i.i165 = icmp eq i8 %or3.i.i, 0
  %197 = trunc i64 %190 to i32
  %conv1.i.i.i = and i32 %197, 255
  %198 = trunc i64 %192 to i32
  %conv2.i.i.i166 = and i32 %198, 255
  %call.i.i.i167 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i165, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i166, i32 noundef %conv.i.i.i164) #13
  %conv3.i.i168 = zext i1 %call.i.i.i167 to i8
  %zf.i.i169 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i168, ptr %zf.i.i169, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i166, i32 noundef %conv.i.i.i164) #13
  %conv6.i.i170 = zext i1 %call4.i.i.i to i8
  %sf.i.i171 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i170, ptr %sf.i.i171, align 1
  %of.i.i172 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i172, align 1
  %af.i.i173 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i173, align 1
  store ptr %193, ptr %MEMORY, align 8
  br label %199

199:                                              ; preds = %186
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = add i64 %200, 2
  store i64 %201, ptr %NEXT_PC, align 8
  %202 = load i8, ptr %AL, align 1
  %203 = zext i8 %202 to i64
  %204 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %203
  %and3.i.i174 = trunc i64 %and3.i15.i to i8
  %cf.i.i175 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i175, align 1
  %205 = and i8 %and3.i.i174, 1
  %conv.i14.i = xor i8 %205, 1
  %pf.i.i176 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i176, align 1
  %206 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i177 = and i32 %206, 255
  %cmp.i.i.i178 = icmp eq i8 %and3.i.i174, 0
  %207 = trunc i64 %203 to i32
  %conv1.i.i.i179 = and i32 %207, 255
  %call.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i178, i32 noundef %conv1.i.i.i179, i32 noundef 1, i32 noundef %conv.i.i.i177) #13
  %conv3.i.i181 = zext i1 %call.i.i.i180 to i8
  %zf.i.i182 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i181, ptr %zf.i.i182, align 1
  %call4.i.i.i183 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i179, i32 noundef 1, i32 noundef %conv.i.i.i177) #13
  %conv6.i.i184 = zext i1 %call4.i.i.i183 to i8
  %sf.i.i185 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i184, ptr %sf.i.i185, align 1
  %of.i.i186 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i186, align 1
  %af.i.i187 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i187, align 1
  store ptr %204, ptr %MEMORY, align 8
  br label %208

208:                                              ; preds = %199
  %209 = load i64, ptr %NEXT_PC, align 8
  store i64 %209, ptr %PC, align 8
  %210 = add i64 %209, 6
  store i64 %210, ptr %NEXT_PC, align 8
  %211 = load i64, ptr %NEXT_PC, align 8
  %212 = add i64 %211, 5
  %213 = load i64, ptr %NEXT_PC, align 8
  %214 = load ptr, ptr %MEMORY, align 8
  %zf.i129 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 2, i32 7
  %215 = load i8, ptr %zf.i129, align 1
  %tobool.not.i = icmp eq i8 %215, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %212, i64 %213
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %214, ptr %MEMORY, align 8
  %216 = load i64, ptr %NEXT_PC, align 8
  store i64 %216, ptr %PC, align 8
  %217 = load ptr, ptr %MEMORY, align 8
  ret ptr %217
}

define ptr @BB_16cf(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rsp.i1 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 13
  %5 = load i64, ptr %rsp.i1, align 8
  %add.i.i2 = add i64 %5, 8
  store i64 %add.i.i2, ptr %rsp.i1, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #13
  store i64 %call.i.i3, ptr %RBP, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #13
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1651(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.224771, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.224771, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.224771) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.224771) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 5280, label %bb_14A0
    i64 5315, label %bb_14C3
    i64 5369, label %bb_14F9
    i64 5481, label %bb_1569
    i64 5487, label %bb_156F
    i64 5504, label %bb_1580
    i64 5513, label %bb_1589
    i64 5550, label %bb_15AE
    i64 5604, label %bb_15E4
    i64 5713, label %bb_1651
    i64 5719, label %bb_1657
    i64 5773, label %bb_168D
    i64 5839, label %bb_16CF
  ]

dead_end:                                         ; preds = %bb_168D, %bb_1657, %bb_1651, %bb_15E4, %bb_15AE, %bb_1589, %bb_1580, %bb_156F, %bb_1569, %bb_14F9, %bb_14C3, %bb_14A0, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_14A0:                                          ; preds = %entry
  %block_pc = add i64 5280, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 5280, ptr %1)
  %4 = call ptr @BB_14a0(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 5315, label %bb_14C3
  ]

bb_14C3:                                          ; preds = %bb_156F, %bb_14A0, %entry
  %block_pc1 = add i64 5315, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 5315, ptr %6)
  %9 = call ptr @BB_14c3(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 5369, label %bb_14F9
  ]

bb_14F9:                                          ; preds = %bb_14C3, %entry
  %block_pc3 = add i64 5369, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 5369, ptr %11)
  %14 = call ptr @BB_14f9(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 5481, label %bb_1569
  ]

bb_1569:                                          ; preds = %bb_14F9, %entry
  %block_pc5 = add i64 5481, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 5481, ptr %16)
  %19 = call ptr @BB_1569(ptr %state, i64 %17, ptr %16) #16
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 5487, label %bb_156F
    i64 5504, label %bb_1580
  ]

bb_156F:                                          ; preds = %bb_1569, %entry
  %block_pc7 = add i64 5487, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 5487, ptr %21)
  %24 = call ptr @BB_156f(ptr %state, i64 %22, ptr %21) #16
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 5315, label %bb_14C3
  ]

bb_1580:                                          ; preds = %bb_1569, %entry
  %block_pc9 = add i64 5504, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 5504, ptr %26)
  %29 = call ptr @BB_1580(ptr %state, i64 %27, ptr %26) #16
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 5513, label %bb_1589
  ]

bb_1589:                                          ; preds = %bb_1651, %bb_1580, %entry
  %block_pc11 = add i64 5513, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 5513, ptr %31)
  %34 = call ptr @BB_1589(ptr %state, i64 %32, ptr %31) #16
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 5550, label %bb_15AE
    i64 5719, label %bb_1657
  ]

bb_15AE:                                          ; preds = %bb_1589, %entry
  %block_pc13 = add i64 5550, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 5550, ptr %36)
  %39 = call ptr @BB_15ae(ptr %state, i64 %37, ptr %36) #16
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 5604, label %bb_15E4
  ]

bb_15E4:                                          ; preds = %bb_15AE, %entry
  %block_pc15 = add i64 5604, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 5604, ptr %41)
  %44 = call ptr @BB_15e4(ptr %state, i64 %42, ptr %41) #16
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 5713, label %bb_1651
  ]

bb_1651:                                          ; preds = %bb_15E4, %entry
  %block_pc17 = add i64 5713, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 5713, ptr %46)
  %49 = call ptr @BB_1651(ptr %state, i64 %47, ptr %46) #16
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 5513, label %bb_1589
  ]

bb_1657:                                          ; preds = %bb_1589, %entry
  %block_pc19 = add i64 5719, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 5719, ptr %51)
  %54 = call ptr @BB_1657(ptr %state, i64 %52, ptr %51) #16
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 5773, label %bb_168D
  ]

bb_168D:                                          ; preds = %bb_1657, %entry
  %block_pc21 = add i64 5773, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 5773, ptr %56)
  %59 = call ptr @BB_168d(ptr %state, i64 %57, ptr %56) #16
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 5839, label %bb_16CF
  ]

bb_16CF:                                          ; preds = %bb_168D, %entry
  %block_pc23 = add i64 5839, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 5839, ptr %61)
  %64 = call ptr @BB_16cf(ptr %state, i64 %62, ptr %61) #16
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  %66 = load ptr, ptr %mem_var, align 8
  ret ptr %66

return_bb:                                        ; No predecessors!
  %67 = load ptr, ptr %mem_var, align 8
  ret ptr %67
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 5280, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.224770, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
