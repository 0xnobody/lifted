; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.3226 = type { %struct.X86State.3225 }
%struct.X86State.3225 = type { %struct.ArchState.3194, [32 x %union.VectorReg.3197], %struct.ArithFlags.3198, %union.anon.3193, %struct.Segments.3200, %struct.AddressSpace.3202, %struct.GPR.3203, %struct.X87Stack.3206, %struct.MMX.3210, %struct.FPUStatusFlags.3211, %union.anon.3193, %union.FPU.3220, %struct.SegmentCaches.3222, %struct.K_REG.3224 }
%struct.ArchState.3194 = type { i32, i32, %union.anon.3193 }
%union.VectorReg.3197 = type { %union.vec512_t.3196 }
%union.vec512_t.3196 = type { %struct.uint64v8_t.3195 }
%struct.uint64v8_t.3195 = type { [8 x i64] }
%struct.ArithFlags.3198 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.3200 = type { i16, %union.SegmentSelector.3199, i16, %union.SegmentSelector.3199, i16, %union.SegmentSelector.3199, i16, %union.SegmentSelector.3199, i16, %union.SegmentSelector.3199, i16, %union.SegmentSelector.3199 }
%union.SegmentSelector.3199 = type { i16 }
%struct.AddressSpace.3202 = type { i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201 }
%struct.Reg.3201 = type { %union.anon.3193 }
%struct.GPR.3203 = type { i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201, i64, %struct.Reg.3201 }
%struct.X87Stack.3206 = type { [8 x %struct.anon.3.3205] }
%struct.anon.3.3205 = type { [6 x i8], %struct.float80_t.3204 }
%struct.float80_t.3204 = type { [10 x i8] }
%struct.MMX.3210 = type { [8 x %struct.anon.4.3209] }
%struct.anon.4.3209 = type { i64, %union.vec64_t.3208 }
%union.vec64_t.3208 = type { %struct.uint64v1_t.3207 }
%struct.uint64v1_t.3207 = type { [1 x i64] }
%struct.FPUStatusFlags.3211 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.3193 = type { i64 }
%union.FPU.3220 = type { %struct.anon.13.3219 }
%struct.anon.13.3219 = type { %struct.FpuFXSAVE.3218, [96 x i8] }
%struct.FpuFXSAVE.3218 = type { %union.SegmentSelector.3199, %union.SegmentSelector.3199, %union.FPUAbridgedTagWord.3212, i8, i16, i32, %union.SegmentSelector.3199, i16, i32, %union.SegmentSelector.3199, i16, %union.FPUControlStatus.3213, %union.FPUControlStatus.3213, [8 x %struct.FPUStackElem.3215], [16 x %union.vec128_t.3217] }
%union.FPUAbridgedTagWord.3212 = type { i8 }
%union.FPUControlStatus.3213 = type { i32 }
%struct.FPUStackElem.3215 = type { %union.anon.11.3214, [6 x i8] }
%union.anon.11.3214 = type { %struct.float80_t.3204 }
%union.vec128_t.3217 = type { %struct.uint128v1_t.3216 }
%struct.uint128v1_t.3216 = type { [1 x i128] }
%struct.SegmentCaches.3222 = type { %struct.SegmentShadow.3221, %struct.SegmentShadow.3221, %struct.SegmentShadow.3221, %struct.SegmentShadow.3221, %struct.SegmentShadow.3221, %struct.SegmentShadow.3221 }
%struct.SegmentShadow.3221 = type { %union.anon.3193, i32, i32 }
%struct.K_REG.3224 = type { [8 x %struct.anon.18.3223] }
%struct.anon.18.3223 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1159(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i76 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i76, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RBP, align 8
  %24 = sub i64 %23, 40
  %25 = load i64, ptr %RDI, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i67 = call ptr @__remill_write_memory_64(ptr noundef %26, i64 noundef %24, i64 noundef %25) #13
  store ptr %call.i.i67, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %20
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RBP, align 8
  %31 = sub i64 %30, 44
  %32 = load i32, ptr %ESI, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i66 = call ptr @__remill_write_memory_32(ptr noundef %34, i64 noundef %31, i32 noundef %32) #13
  store ptr %call.i.i66, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %27
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 7
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 12
  %40 = load ptr, ptr %MEMORY, align 8
  %call.i.i62 = call ptr @__remill_write_memory_32(ptr noundef %40, i64 noundef %39, i32 noundef 32) #13
  store ptr %call.i.i62, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 3
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %RBP, align 8
  %45 = sub i64 %44, 12
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #13
  %conv.i.i75 = zext i32 %call.i.i74 to i64
  store i64 %conv.i.i75, ptr %RDX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 2
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i32, ptr %EDX, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i69 = and i64 %51, 4294967295
  store i64 %conv.i11.i69, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load i32, ptr %EAX, align 4
  %58 = zext i32 %57 to i64
  %59 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %56 to i32
  %add.i.i2 = add i32 %57, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RAX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, %57
  %60 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %60, i32 noundef %conv.i.i1, i32 noundef %57, i32 noundef %add.i.i2) #13
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %61 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %62 = and i8 %61, 1
  %conv.i.i.i10 = xor i8 %62, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, %57
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %63 = trunc i32 %xor1.i.i.i.i13 to i8
  %64 = lshr i8 %63, 4
  %conv2.i.i.i14 = and i8 %64, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef %57, i32 noundef %add.i.i2) #13
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef %57, i32 noundef %add.i.i2) #13
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef %57, i32 noundef %add.i.i2) #13
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %59, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %53
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 2
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RAX, align 8
  %69 = load i32, ptr %EDX, align 4
  %70 = zext i32 %69 to i64
  %71 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %68 to i32
  %add.i.i = add i32 %69, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %69
  %72 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %72, i32 noundef %conv.i.i, i32 noundef %69, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %73 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %74 = and i8 %73, 1
  %conv.i.i.i = xor i8 %74, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %69
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %75 = trunc i32 %xor1.i.i.i.i to i8
  %76 = lshr i8 %75, 4
  %conv2.i.i.i = and i8 %76, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %69, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %69, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %69, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %71, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %65
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RAX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i139.i77 = and i64 %80, 4294967295
  %shr.i140.i78 = lshr i64 %conv.i139.i77, 1
  %conv2.i141.i79 = trunc i64 %shr.i140.i78 to i32
  %call34.i80 = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i81 = icmp ne i8 %call34.i80, 0
  %new_val.0.i82 = lshr i32 %conv2.i141.i79, 1
  %conv.i147.i83 = zext i32 %new_val.0.i82 to i64
  store i64 %conv.i147.i83, ptr %RAX, align 8
  %cf.i84 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  %82 = trunc i32 %conv2.i141.i79 to i8
  %conv.i85 = and i8 %82, 1
  store i8 %conv.i85, ptr %cf.i84, align 1
  %pf.i86 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  %conv.i148.i87 = trunc i32 %new_val.0.i82 to i8
  %83 = call i8 @llvm.ctpop.i8(i8 %conv.i148.i87)
  %84 = and i8 %83, 1
  %conv67.i88 = xor i8 %84, 1
  store i8 %conv67.i88, ptr %pf.i86, align 1
  %af.i89 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i80, ptr %af.i89, align 1
  %zf.i90 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  %cmp.i149.i91 = icmp ult i32 %conv2.i141.i79, 2
  %conv80.i92 = zext i1 %cmp.i149.i91 to i8
  store i8 %conv80.i92, ptr %zf.i90, align 1
  %sf.i93 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i93, align 1
  %of.i94 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  %conv92.i95 = zext i1 %tobool.i81 to i8
  store i8 %conv92.i95, ptr %of.i94, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %77
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RBP, align 8
  %89 = sub i64 %88, 16
  %90 = load i32, ptr %EAX, align 4
  %91 = zext i32 %90 to i64
  %92 = load ptr, ptr %MEMORY, align 8
  %call.i.i65 = call ptr @__remill_write_memory_32(ptr noundef %92, i64 noundef %89, i32 noundef %90) #13
  store ptr %call.i.i65, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %85
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 3
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i64, ptr %RBP, align 8
  %97 = sub i64 %96, 12
  %98 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i32 @__remill_read_memory_32(ptr noundef %98, i64 noundef %97) #13
  %conv.i.i73 = zext i32 %call.i.i72 to i64
  store i64 %conv.i.i73, ptr %RAX, align 8
  store ptr %98, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %93
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RAX, align 8
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i139.i = and i64 %102, 4294967295
  %shr.i140.i = lshr i64 %conv.i139.i, 2
  %conv2.i141.i = trunc i64 %shr.i140.i to i32
  %call34.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i32 %conv2.i141.i, 1
  %conv.i147.i = zext i32 %new_val.0.i to i64
  store i64 %conv.i147.i, ptr %RAX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  %104 = trunc i32 %conv2.i141.i to i8
  %conv.i = and i8 %104, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  %conv.i148.i = trunc i32 %new_val.0.i to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i148.i)
  %106 = and i8 %105, 1
  %conv67.i = xor i8 %106, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  %cmp.i149.i = icmp ult i32 %conv2.i141.i, 2
  %conv80.i = zext i1 %cmp.i149.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %99
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 3
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i64, ptr %RBP, align 8
  %111 = sub i64 %110, 20
  %112 = load i32, ptr %EAX, align 4
  %113 = zext i32 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %call.i.i64 = call ptr @__remill_write_memory_32(ptr noundef %114, i64 noundef %111, i32 noundef %112) #13
  store ptr %call.i.i64, ptr %MEMORY, align 8
  br label %115

115:                                              ; preds = %107
  %116 = load i64, ptr %NEXT_PC, align 8
  store i64 %116, ptr %PC, align 8
  %117 = add i64 %116, 3
  store i64 %117, ptr %NEXT_PC, align 8
  %118 = load i64, ptr %RBP, align 8
  %119 = sub i64 %118, 12
  %120 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %120, i64 noundef %119) #13
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RAX, align 8
  store ptr %120, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %115
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load i64, ptr %RAX, align 8
  %125 = load i64, ptr %RBP, align 8
  %126 = sub i64 %125, 20
  %127 = load ptr, ptr %MEMORY, align 8
  %conv.i.i32 = trunc i64 %124 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %127, i64 noundef %126) #13
  %sub.i.i = sub i32 %conv.i.i32, %call.i.i
  %conv.i18.i = zext i32 %sub.i.i to i64
  store i64 %conv.i18.i, ptr %RAX, align 8
  %cmp.i.i.i33 = icmp ugt i32 %call.i.i, %conv.i.i32
  %call.i.i.i34 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i33, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv.i19.i = zext i1 %call.i.i.i34 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i32 %sub.i.i to i8
  %128 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %129 = and i8 %128, 1
  %conv.i.i.i37 = xor i8 %129, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i32 %call.i.i, %conv.i.i32
  %xor1.i.i.i.i40 = xor i32 %xor.i.i.i.i39, %sub.i.i
  %130 = trunc i32 %xor1.i.i.i.i40 to i8
  %131 = lshr i8 %130, 4
  %conv2.i.i.i41 = and i8 %131, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i32 %call.i.i, %conv.i.i32
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %xor.i28.i.i.i51 = lshr i32 %xor.i.i.i.i39, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i32
  %xor3.i.i.i.i52 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i53 = add nuw nsw i32 %xor3.i.i.i.i52, %xor.i28.i.i.i51
  %cmp.i29.i.i.i54 = icmp eq i32 %add.i.i.i.i53, 2
  %call.i30.i.i.i55 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i54, i32 noundef %conv.i.i32, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv11.i.i.i56 = zext i1 %call.i30.i.i.i55 to i8
  %of.i.i.i57 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i56, ptr %of.i.i.i57, align 1
  store ptr %127, ptr %MEMORY, align 8
  br label %132

132:                                              ; preds = %121
  %133 = load i64, ptr %NEXT_PC, align 8
  store i64 %133, ptr %PC, align 8
  %134 = add i64 %133, 5
  store i64 %134, ptr %NEXT_PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  store i64 4294967295, ptr %RDX, align 8
  store ptr %135, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %132
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 2
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i32, ptr %EAX, align 4
  %140 = zext i32 %139 to i64
  %141 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i68 = and i64 %140, 4294967295
  store i64 %conv.i11.i68, ptr %RCX, align 8
  store ptr %141, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %136
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 2
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RDX, align 8
  %146 = load i8, ptr %CL, align 1
  %147 = zext i8 %146 to i64
  %148 = load ptr, ptr %MEMORY, align 8
  %conv.i140.i = trunc i64 %147 to i32
  %and3.i.i = and i32 %conv.i140.i, 31
  switch i32 %and3.i.i, label %if.then35.i [
    i32 0, label %do.body16.i
    i32 1, label %if.then24.i
  ]

do.body16.i:                                      ; preds = %142
  %conv.i141.i = and i64 %145, 4294967295
  store i64 %conv.i141.i, ptr %RDX, align 8
  br label %_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit

if.then24.i:                                      ; preds = %142
  %conv.i.i96 = trunc i64 %145 to i32
  %conv2.i.i = shl i32 %conv.i.i96, 1
  %149 = xor i32 %conv2.i.i, %conv.i.i96
  %cmp.i146.i = icmp slt i32 %149, 0
  %.pre.i = call zeroext i8 @__remill_undefined_8() #14
  br label %do.body55.i

if.then35.i:                                      ; preds = %142
  %sub.i.i97 = add nsw i32 %and3.i.i, -1
  %conv1.i.i = zext i32 %sub.i.i97 to i64
  %shl.i149.i = shl i64 %145, %conv1.i.i
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  br label %do.body55.i

do.body55.i:                                      ; preds = %if.then35.i, %if.then24.i
  %call78.pre-phi.i = phi i8 [ %call42.i, %if.then35.i ], [ %.pre.i, %if.then24.i ]
  %new_cf.0.shrunk.in.i = phi i32 [ %conv2.i150.i, %if.then35.i ], [ %conv.i.i96, %if.then24.i ]
  %new_of.0.in.i = phi i1 [ %tobool43.i, %if.then35.i ], [ %cmp.i146.i, %if.then24.i ]
  %new_val.0.i98 = phi i32 [ %conv2.i154.i, %if.then35.i ], [ %conv2.i.i, %if.then24.i ]
  %conv.i155.i = zext i32 %new_val.0.i98 to i64
  store i64 %conv.i155.i, ptr %RDX, align 8
  %cf.i99 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %new_cf.0.shrunk.in.i, 31
  %conv.i100 = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i100, ptr %cf.i99, align 1
  %pf.i101 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %new_val.0.i98 to i8
  %150 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %151 = and i8 %150, 1
  %conv72.i = xor i8 %151, 1
  store i8 %conv72.i, ptr %pf.i101, align 1
  %af.i102 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %call78.pre-phi.i, ptr %af.i102, align 1
  %zf.i103 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %new_val.0.i98, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i103, align 1
  %sf.i104 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %new_val.0.i98, 31
  %conv92.i105 = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv92.i105, ptr %sf.i104, align 1
  %of.i106 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %new_of.0.in.i to i8
  store i8 %conv99.i, ptr %of.i106, align 1
  br label %_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit

_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit: ; preds = %do.body55.i, %do.body16.i
  store ptr %148, ptr %MEMORY, align 8
  br label %152

152:                                              ; preds = %_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit
  %153 = load i64, ptr %NEXT_PC, align 8
  store i64 %153, ptr %PC, align 8
  %154 = add i64 %153, 2
  store i64 %154, ptr %NEXT_PC, align 8
  %155 = load i32, ptr %EDX, align 4
  %156 = zext i32 %155 to i64
  %157 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %156, 4294967295
  store i64 %conv.i11.i, ptr %RAX, align 8
  store ptr %157, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %152
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 3
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RBP, align 8
  %162 = sub i64 %161, 24
  %163 = load i32, ptr %EAX, align 4
  %164 = zext i32 %163 to i64
  %165 = load ptr, ptr %MEMORY, align 8
  %call.i.i63 = call ptr @__remill_write_memory_32(ptr noundef %165, i64 noundef %162, i32 noundef %163) #13
  store ptr %call.i.i63, ptr %MEMORY, align 8
  br label %166

166:                                              ; preds = %158
  %167 = load i64, ptr %NEXT_PC, align 8
  store i64 %167, ptr %PC, align 8
  %168 = add i64 %167, 7
  store i64 %168, ptr %NEXT_PC, align 8
  %169 = load i64, ptr %RBP, align 8
  %170 = sub i64 %169, 4
  %171 = load ptr, ptr %MEMORY, align 8
  %call.i.i61 = call ptr @__remill_write_memory_32(ptr noundef %171, i64 noundef %170, i32 noundef 0) #13
  store ptr %call.i.i61, ptr %MEMORY, align 8
  br label %172

172:                                              ; preds = %166
  %173 = load i64, ptr %NEXT_PC, align 8
  store i64 %173, ptr %PC, align 8
  %174 = add i64 %173, 7
  store i64 %174, ptr %NEXT_PC, align 8
  %175 = load i64, ptr %RBP, align 8
  %176 = sub i64 %175, 28
  %177 = load ptr, ptr %MEMORY, align 8
  %call.i.i60 = call ptr @__remill_write_memory_32(ptr noundef %177, i64 noundef %176, i32 noundef 0) #13
  store ptr %call.i.i60, ptr %MEMORY, align 8
  br label %178

178:                                              ; preds = %172
  %179 = load i64, ptr %NEXT_PC, align 8
  store i64 %179, ptr %PC, align 8
  %180 = add i64 %179, 7
  store i64 %180, ptr %NEXT_PC, align 8
  %181 = load i64, ptr %RBP, align 8
  %182 = sub i64 %181, 8
  %183 = load ptr, ptr %MEMORY, align 8
  %call.i.i59 = call ptr @__remill_write_memory_32(ptr noundef %183, i64 noundef %182, i32 noundef 0) #13
  store ptr %call.i.i59, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %178
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 7
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i64, ptr %RBP, align 8
  %188 = sub i64 %187, 8
  %189 = load ptr, ptr %MEMORY, align 8
  %call.i.i58 = call ptr @__remill_write_memory_32(ptr noundef %189, i64 noundef %188, i32 noundef 0) #13
  store ptr %call.i.i58, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %184
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 2
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %NEXT_PC, align 8
  %194 = add i64 %193, 76
  %195 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 33
  store i64 %194, ptr %rip.i, align 8
  store i64 %194, ptr %NEXT_PC, align 8
  store ptr %195, ptr %MEMORY, align 8
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = load ptr, ptr %MEMORY, align 8
  ret ptr %197
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1205(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i32, ptr %EAX, align 4
  %11 = zext i32 %10 to i64
  %12 = load i64, ptr %RBP, align 8
  %13 = sub i64 %12, 44
  %14 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %14, i64 noundef %13) #13
  %sub.i.i = sub i32 %10, %call.i.i
  %cmp.i.i.i = icmp ugt i32 %call.i.i, %10
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %15 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %16 = and i8 %15, 1
  %conv.i.i.i = xor i8 %16, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, %10
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %17 = trunc i32 %xor1.i.i.i.i to i8
  %18 = lshr i8 %17, 4
  %conv2.i.i.i = and i8 %18, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, %10
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %10
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %10, i32 noundef %call.i.i, i32 noundef %sub.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %14, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %7
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %NEXT_PC, align 8
  %23 = sub i64 %22, 84
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = load ptr, ptr %MEMORY, align 8
  %cf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  %26 = load i8, ptr %cf.i, align 1
  %tobool.i = icmp ne i8 %26, 0
  %call8.i = call zeroext i1 @__remill_compare_ult(i1 noundef zeroext %tobool.i) #14
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %23, i64 %24
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %25, ptr %MEMORY, align 8
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  ret ptr %28
}

define ptr @BB_11b9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %CL = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i25 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i26 = zext i32 %call.i.i25 to i64
  store i64 %conv.i.i26, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 4
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i23 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i24 = zext i32 %call.i.i23 to i64
  store i64 %conv.i.i24, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i32, ptr %EAX, align 4
  %17 = zext i32 %16 to i64
  %18 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %17, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load i8, ptr %CL, align 1
  %24 = zext i8 %23 to i64
  %25 = load ptr, ptr %MEMORY, align 8
  %conv.i140.i = trunc i64 %24 to i32
  %and3.i.i37 = and i32 %conv.i140.i, 31
  switch i32 %and3.i.i37, label %if.then35.i [
    i32 0, label %do.body16.i
    i32 1, label %if.then24.i
  ]

do.body16.i:                                      ; preds = %19
  %conv.i141.i = and i64 %22, 4294967295
  store i64 %conv.i141.i, ptr %RDX, align 8
  br label %_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit

if.then24.i:                                      ; preds = %19
  %conv.i.i38 = trunc i64 %22 to i32
  %conv2.i.i = shl i32 %conv.i.i38, 1
  %26 = xor i32 %conv2.i.i, %conv.i.i38
  %cmp.i146.i = icmp slt i32 %26, 0
  %.pre.i = call zeroext i8 @__remill_undefined_8() #14
  br label %do.body55.i

if.then35.i:                                      ; preds = %19
  %sub.i.i = add nsw i32 %and3.i.i37, -1
  %conv1.i.i = zext i32 %sub.i.i to i64
  %shl.i149.i = shl i64 %22, %conv1.i.i
  %conv2.i150.i = trunc i64 %shl.i149.i to i32
  %call42.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool43.i = icmp ne i8 %call42.i, 0
  %conv2.i154.i = shl i32 %conv2.i150.i, 1
  br label %do.body55.i

do.body55.i:                                      ; preds = %if.then35.i, %if.then24.i
  %call78.pre-phi.i = phi i8 [ %call42.i, %if.then35.i ], [ %.pre.i, %if.then24.i ]
  %new_cf.0.shrunk.in.i = phi i32 [ %conv2.i150.i, %if.then35.i ], [ %conv.i.i38, %if.then24.i ]
  %new_of.0.in.i = phi i1 [ %tobool43.i, %if.then35.i ], [ %cmp.i146.i, %if.then24.i ]
  %new_val.0.i = phi i32 [ %conv2.i154.i, %if.then35.i ], [ %conv2.i.i, %if.then24.i ]
  %conv.i155.i = zext i32 %new_val.0.i to i64
  store i64 %conv.i155.i, ptr %RDX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i32 %new_cf.0.shrunk.in.i, 31
  %conv.i = trunc i32 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  %conv.i156.i = trunc i32 %new_val.0.i to i8
  %27 = call i8 @llvm.ctpop.i8(i8 %conv.i156.i)
  %28 = and i8 %27, 1
  %conv72.i = xor i8 %28, 1
  store i8 %conv72.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %call78.pre-phi.i, ptr %af.i, align 1
  %zf.i39 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp eq i32 %new_val.0.i, 0
  %conv85.i = zext i1 %cmp.i157.i to i8
  store i8 %conv85.i, ptr %zf.i39, align 1
  %sf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i32 %new_val.0.i, 31
  %conv92.i = trunc i32 %new_val.0.lobit.i to i8
  store i8 %conv92.i, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %new_of.0.in.i to i8
  store i8 %conv99.i, ptr %of.i, align 1
  br label %_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit

_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit: ; preds = %do.body55.i, %do.body16.i
  store ptr %25, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %_ZN12_GLOBAL__N_13SHLI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 40
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i27 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #13
  store i64 %call.i.i27, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %call.i.i28 = call zeroext i8 @__remill_read_memory_8(ptr noundef %39, i64 noundef %38) #13
  %conv.i.i29 = zext i8 %call.i.i28 to i64
  store i64 %conv.i.i29, ptr %RAX, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i8, ptr %AL, align 1
  %44 = zext i8 %43 to i64
  %45 = load ptr, ptr %MEMORY, align 8
  %conv.i.i30 = trunc i64 %44 to i32
  %sext.i = shl i32 %conv.i.i30, 24
  %conv.i12.i = ashr exact i32 %sext.i, 24
  %conv.i13.i = zext i32 %conv.i12.i to i64
  store i64 %conv.i13.i, ptr %RAX, align 8
  store ptr %45, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %40
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 2
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load i64, ptr %RAX, align 8
  %50 = load i32, ptr %EDX, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %49 to i32
  %add.i.i = add i32 %50, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, %50
  %53 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %53, i32 noundef %conv.i.i, i32 noundef %50, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %54 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %55 = and i8 %54, 1
  %conv.i.i.i = xor i8 %55, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, %50
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %56 = trunc i32 %xor1.i.i.i.i to i8
  %57 = lshr i8 %56, 4
  %conv2.i.i.i = and i8 %57, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef %50, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef %50, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef %50, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %52, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %46
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RBP, align 8
  %62 = sub i64 %61, 4
  %63 = load i32, ptr %EAX, align 4
  %64 = zext i32 %63 to i64
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i20 = call ptr @__remill_write_memory_32(ptr noundef %65, i64 noundef %62, i32 noundef %63) #13
  store ptr %call.i.i20, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %58
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RBP, align 8
  %70 = sub i64 %69, 4
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i21 = call i32 @__remill_read_memory_32(ptr noundef %71, i64 noundef %70) #13
  %conv.i.i22 = zext i32 %call.i.i21 to i64
  store i64 %conv.i.i22, ptr %RAX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %66
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 3
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RAX, align 8
  %76 = load i64, ptr %RBP, align 8
  %77 = sub i64 %76, 24
  %78 = load ptr, ptr %MEMORY, align 8
  %conv.i.i31 = trunc i64 %75 to i32
  %call.i.i32 = call i32 @__remill_read_memory_32(ptr noundef %78, i64 noundef %77) #13
  %and3.i.i = and i32 %call.i.i32, %conv.i.i31
  %conv.i18.i = zext i32 %and3.i.i to i64
  store i64 %conv.i18.i, ptr %RAX, align 8
  %cf.i.i33 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i33, align 1
  %conv.i.i.i34 = trunc i32 %and3.i.i to i8
  %79 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i34)
  %80 = and i8 %79, 1
  %conv.i19.i = xor i8 %80, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i19.i, ptr %pf.i.i, align 1
  %cmp.i.i.i35 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i36 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i35, i32 noundef %conv.i.i31, i32 noundef %call.i.i32, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i36 to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %and3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i31, i32 noundef %call.i.i32, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %72
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 3
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RBP, align 8
  %85 = sub i64 %84, 28
  %86 = load i32, ptr %EAX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i19 = call ptr @__remill_write_memory_32(ptr noundef %88, i64 noundef %85, i32 noundef %86) #13
  store ptr %call.i.i19, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %81
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 4
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RBP, align 8
  %93 = sub i64 %92, 28
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %94, i64 noundef %93) #13
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i1 to i8
  %cf.i.i2 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i2, align 1
  %conv.i.i.i.i3 = trunc i32 %call.i.i to i8
  %95 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i3)
  %96 = and i8 %95, 1
  %conv.i.i.i4 = xor i8 %96, 1
  %pf.i.i.i5 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i4, ptr %pf.i.i.i5, align 1
  %af.i.i.i6 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i6, align 1
  %cmp.i.i.i.i7 = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i8 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i7, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv5.i.i.i9 = zext i1 %call.i.i.i.i8 to i8
  %zf.i.i.i10 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i9, ptr %zf.i.i.i10, align 1
  %cmp.i27.i.i.i11 = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i11, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv8.i.i.i13 = zext i1 %call1.i.i.i.i12 to i8
  %sf.i.i.i14 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i13, ptr %sf.i.i.i14, align 1
  %xor.i28.i.i.i15 = lshr i32 %call.i.i, 31
  %call.i30.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #13
  %conv11.i.i.i17 = zext i1 %call.i30.i.i.i16 to i8
  %of.i.i.i18 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i17, ptr %of.i.i.i18, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %89
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 2
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %NEXT_PC, align 8
  %101 = add i64 %100, 27
  %102 = load i64, ptr %NEXT_PC, align 8
  %103 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  %104 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %104, 0
  %call8.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i) #14
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %101, i64 %102
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %103, ptr %MEMORY, align 8
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = load ptr, ptr %MEMORY, align 8
  ret ptr %106
}

define ptr @BB_120d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 4
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 1
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 13
  %11 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %11, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %10, i64 noundef %11) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #13
  %rip.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %17, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %15, ptr %MEMORY, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_11fc(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load i64, ptr %RBP, align 8
  %7 = sub i64 %6, 40
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %8, i64 noundef %7) #13
  %add.i.i2 = add i64 %call.i.i1, 1
  %call.i18.i3 = call ptr @__remill_write_memory_64(ptr noundef %8, i64 noundef %5, i64 noundef %add.i.i2) #13
  %cmp.i.i.i4 = icmp ult i64 %add.i.i2, %call.i.i1
  %cmp1.i.i.i5 = icmp ult i64 %add.i.i2, 1
  %9 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %9, i64 noundef %call.i.i1, i64 noundef 1, i64 noundef %add.i.i2) #13
  %conv.i.i = zext i1 %call.i.i.i6 to i8
  %cf.i.i7 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i7, align 1
  %conv.i.i.i.i8 = trunc i64 %add.i.i2 to i8
  %10 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i8)
  %11 = and i8 %10, 1
  %conv.i.i.i9 = xor i8 %11, 1
  %pf.i.i.i10 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i9, ptr %pf.i.i.i10, align 1
  %xor.i.i.i.i11 = xor i64 %add.i.i2, 1
  %xor1.i.i.i.i12 = xor i64 %xor.i.i.i.i11, %call.i.i1
  %12 = trunc i64 %xor1.i.i.i.i12 to i8
  %13 = lshr i8 %12, 4
  %conv2.i.i.i13 = and i8 %13, 1
  %af.i.i.i14 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i13, ptr %af.i.i.i14, align 1
  %cmp.i.i.i.i15 = icmp eq i64 %add.i.i2, 0
  %call.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i15, i64 noundef %call.i.i1, i64 noundef 1, i64 noundef %add.i.i2) #13
  %conv5.i.i.i17 = zext i1 %call.i.i.i.i16 to i8
  %zf.i.i.i18 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i17, ptr %zf.i.i.i18, align 1
  %cmp.i27.i.i.i19 = icmp slt i64 %add.i.i2, 0
  %call1.i.i.i.i20 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i19, i64 noundef %call.i.i1, i64 noundef 1, i64 noundef %add.i.i2) #13
  %conv8.i.i.i21 = zext i1 %call1.i.i.i.i20 to i8
  %sf.i.i.i22 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i21, ptr %sf.i.i.i22, align 1
  %shr8.i.i.i.i23 = xor i64 %add.i.i2, %call.i.i1
  %xor.i28.i.i.i24 = lshr i64 %shr8.i.i.i.i23, 63
  %xor3.i.i.i.i25 = lshr i64 %xor.i.i.i.i11, 63
  %add.i.i.i.i26 = add nuw nsw i64 %xor.i28.i.i.i24, %xor3.i.i.i.i25
  %cmp.i29.i.i.i27 = icmp eq i64 %add.i.i.i.i26, 2
  %call.i30.i.i.i28 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i27, i64 noundef %call.i.i1, i64 noundef 1, i64 noundef %add.i.i2) #13
  %conv11.i.i.i29 = zext i1 %call.i30.i.i.i28 to i8
  %of.i.i.i30 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i29, ptr %of.i.i.i30, align 1
  store ptr %call.i18.i3, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %1
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 4
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 8
  %19 = load i64, ptr %RBP, align 8
  %20 = sub i64 %19, 8
  %21 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %21, i64 noundef %20) #13
  %add.i.i = add i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %21, i64 noundef %18, i32 noundef %add.i.i) #13
  %cmp.i.i.i = icmp ult i32 %add.i.i, %call.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %22 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %22, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %24 = and i8 %23, 1
  %conv.i.i.i = xor i8 %24, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %call.i.i
  %25 = trunc i32 %xor1.i.i.i.i to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i = and i8 %26, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %call.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %14
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_11e1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %CL = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.3226, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i7 = zext i32 %call.i.i6 to i64
  store i64 %conv.i.i7, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 28
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i5 = zext i32 %call.i.i4 to i64
  store i64 %conv.i.i5, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i32, ptr %EAX, align 4
  %17 = zext i32 %16 to i64
  %18 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i2 = and i64 %17, 4294967295
  store i64 %conv.i11.i2, ptr %RCX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 2
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load i8, ptr %CL, align 1
  %24 = zext i8 %23 to i64
  %25 = load ptr, ptr %MEMORY, align 8
  %conv.i131.i = trunc i64 %24 to i32
  %and3.i.i25 = and i32 %conv.i131.i, 31
  switch i32 %and3.i.i25, label %if.then31.i [
    i32 0, label %do.body16.i
    i32 1, label %if.then24.i
  ]

do.body16.i:                                      ; preds = %19
  %conv.i132.i = and i64 %22, 4294967295
  store i64 %conv.i132.i, ptr %RDX, align 8
  br label %_ZN12_GLOBAL__N_13SHRI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit

if.then24.i:                                      ; preds = %19
  %conv.i.i26 = trunc i64 %22 to i32
  %cmp.i134.i = icmp slt i32 %conv.i.i26, 0
  %.pre.i = call zeroext i8 @__remill_undefined_8() #14
  br label %do.body50.i

if.then31.i:                                      ; preds = %19
  %sub.i.i = add nsw i32 %and3.i.i25, -1
  %conv.i139.i = and i64 %22, 4294967295
  %conv1.i.i = zext i32 %sub.i.i to i64
  %shr.i140.i = lshr i64 %conv.i139.i, %conv1.i.i
  %conv2.i141.i = trunc i64 %shr.i140.i to i32
  %call34.i = call zeroext i8 @__remill_undefined_8() #14
  %tobool.i = icmp ne i8 %call34.i, 0
  br label %do.body50.i

do.body50.i:                                      ; preds = %if.then31.i, %if.then24.i
  %call73.pre-phi.i = phi i8 [ %call34.i, %if.then31.i ], [ %.pre.i, %if.then24.i ]
  %new_val.0.in.pre-phi.i = phi i32 [ %conv2.i141.i, %if.then31.i ], [ %conv.i.i26, %if.then24.i ]
  %new_of.0.i = phi i1 [ %tobool.i, %if.then31.i ], [ %cmp.i134.i, %if.then24.i ]
  %new_val.0.i = lshr i32 %new_val.0.in.pre-phi.i, 1
  %conv.i147.i = zext i32 %new_val.0.i to i64
  store i64 %conv.i147.i, ptr %RDX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  %26 = trunc i32 %new_val.0.in.pre-phi.i to i8
  %conv.i = and i8 %26, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  %conv.i148.i = trunc i32 %new_val.0.i to i8
  %27 = call i8 @llvm.ctpop.i8(i8 %conv.i148.i)
  %28 = and i8 %27, 1
  %conv67.i = xor i8 %28, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 %call73.pre-phi.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  %cmp.i149.i = icmp ult i32 %new_val.0.in.pre-phi.i, 2
  %conv80.i = zext i1 %cmp.i149.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %new_of.0.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  br label %_ZN12_GLOBAL__N_13SHRI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit

_ZN12_GLOBAL__N_13SHRI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit: ; preds = %do.body50.i, %do.body16.i
  store ptr %25, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %_ZN12_GLOBAL__N_13SHRI3RnWImE2RnIjLb1EES4_EEP6MemoryS6_R5StateT_T0_T1_.exit
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i32, ptr %EDX, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i1 = and i64 %33, 4294967295
  store i64 %conv.i11.i1, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load i64, ptr %RBP, align 8
  %40 = sub i64 %39, 4
  %41 = load ptr, ptr %MEMORY, align 8
  %conv.i.i9 = trunc i64 %38 to i32
  %call.i.i10 = call i32 @__remill_read_memory_32(ptr noundef %41, i64 noundef %40) #13
  %xor3.i.i = xor i32 %call.i.i10, %conv.i.i9
  %conv.i23.i11 = zext i32 %xor3.i.i to i64
  store i64 %conv.i23.i11, ptr %RAX, align 8
  %cf.i.i12 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i12, align 1
  %conv.i.i.i13 = trunc i32 %xor3.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i13)
  %43 = and i8 %42, 1
  %conv.i24.i = xor i8 %43, 1
  %pf.i.i14 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i24.i, ptr %pf.i.i14, align 1
  %cmp.i.i.i15 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i15, i32 noundef %conv.i.i9, i32 noundef %call.i.i10, i32 noundef %xor3.i.i) #13
  %conv3.i.i17 = zext i1 %call.i.i.i16 to i8
  %zf.i.i18 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i17, ptr %zf.i.i18, align 1
  %cmp.i19.i.i19 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i20 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i19, i32 noundef %conv.i.i9, i32 noundef %call.i.i10, i32 noundef %xor3.i.i) #13
  %conv6.i.i21 = zext i1 %call1.i.i.i20 to i8
  %sf.i.i22 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i21, ptr %sf.i.i22, align 1
  %of.i.i23 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i23, align 1
  %af.i.i24 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i24, align 1
  store ptr %41, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %35
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 2
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i32, ptr %EAX, align 4
  %48 = zext i32 %47 to i64
  %49 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %48, 4294967295
  store i64 %conv.i11.i, ptr %RDX, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 3
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RBP, align 8
  %54 = sub i64 %53, 24
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i32 @__remill_read_memory_32(ptr noundef %55, i64 noundef %54) #13
  %conv.i.i = zext i32 %call.i.i3 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %not.i.i = and i64 %59, 4294967295
  %conv.i12.i = xor i64 %not.i.i, 4294967295
  store i64 %conv.i12.i, ptr %RAX, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %56
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 2
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %RAX, align 8
  %65 = load i32, ptr %EDX, align 4
  %66 = zext i32 %65 to i64
  %67 = load ptr, ptr %MEMORY, align 8
  %conv.i.i8 = trunc i64 %64 to i32
  %and3.i.i = and i32 %65, %conv.i.i8
  %conv.i22.i = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %and3.i.i to i8
  %68 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %69 = and i8 %68, 1
  %conv.i23.i = xor i8 %69, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %and3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i8, i32 noundef %65, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %and3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i8, i32 noundef %65, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i, align 1
  store ptr %67, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %61
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RBP, align 8
  %74 = sub i64 %73, 4
  %75 = load i32, ptr %EAX, align 4
  %76 = zext i32 %75 to i64
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %77, i64 noundef %74, i32 noundef %75) #13
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %70
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  ret ptr %memory
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.3226, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.3226) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.3226) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4441, label %bb_1159
    i64 4537, label %bb_11B9
    i64 4577, label %bb_11E1
    i64 4604, label %bb_11FC
    i64 4613, label %bb_1205
    i64 4621, label %bb_120D
  ]

dead_end:                                         ; preds = %bb_1205, %bb_11FC, %bb_11E1, %bb_11B9, %bb_1159, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1159:                                          ; preds = %entry
  %block_pc = add i64 4441, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4441, ptr %1)
  %4 = call ptr @BB_1159(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4613, label %bb_1205
  ]

bb_11B9:                                          ; preds = %bb_1205, %entry
  %block_pc1 = add i64 4537, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4537, ptr %6)
  %9 = call ptr @BB_11b9(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4577, label %bb_11E1
    i64 4604, label %bb_11FC
  ]

bb_11E1:                                          ; preds = %bb_11B9, %entry
  %block_pc3 = add i64 4577, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4577, ptr %11)
  %14 = call ptr @BB_11e1(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4604, label %bb_11FC
  ]

bb_11FC:                                          ; preds = %bb_11E1, %bb_11B9, %entry
  %block_pc5 = add i64 4604, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4604, ptr %16)
  %19 = call ptr @BB_11fc(ptr %state, i64 %17, ptr %16) #16
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4613, label %bb_1205
  ]

bb_1205:                                          ; preds = %bb_11FC, %bb_1159, %entry
  %block_pc7 = add i64 4613, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4613, ptr %21)
  %24 = call ptr @BB_1205(ptr %state, i64 %22, ptr %21) #16
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4537, label %bb_11B9
    i64 4621, label %bb_120D
  ]

bb_120D:                                          ; preds = %bb_1205, %entry
  %block_pc9 = add i64 4621, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4621, ptr %26)
  %29 = call ptr @BB_120d(ptr %state, i64 %27, ptr %26) #16
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  %31 = load ptr, ptr %mem_var, align 8
  ret ptr %31

return_bb:                                        ; No predecessors!
  %32 = load ptr, ptr %mem_var, align 8
  ret ptr %32
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4441, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.3225, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
