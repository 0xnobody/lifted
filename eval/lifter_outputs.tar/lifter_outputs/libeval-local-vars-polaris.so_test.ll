; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.4685 = type { %struct.X86State.4684 }
%struct.X86State.4684 = type { %struct.ArchState.4653, [32 x %union.VectorReg.4656], %struct.ArithFlags.4657, %union.anon.4652, %struct.Segments.4659, %struct.AddressSpace.4661, %struct.GPR.4662, %struct.X87Stack.4665, %struct.MMX.4669, %struct.FPUStatusFlags.4670, %union.anon.4652, %union.FPU.4679, %struct.SegmentCaches.4681, %struct.K_REG.4683 }
%struct.ArchState.4653 = type { i32, i32, %union.anon.4652 }
%union.VectorReg.4656 = type { %union.vec512_t.4655 }
%union.vec512_t.4655 = type { %struct.uint64v8_t.4654 }
%struct.uint64v8_t.4654 = type { [8 x i64] }
%struct.ArithFlags.4657 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.4659 = type { i16, %union.SegmentSelector.4658, i16, %union.SegmentSelector.4658, i16, %union.SegmentSelector.4658, i16, %union.SegmentSelector.4658, i16, %union.SegmentSelector.4658, i16, %union.SegmentSelector.4658 }
%union.SegmentSelector.4658 = type { i16 }
%struct.AddressSpace.4661 = type { i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660 }
%struct.Reg.4660 = type { %union.anon.4652 }
%struct.GPR.4662 = type { i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660, i64, %struct.Reg.4660 }
%struct.X87Stack.4665 = type { [8 x %struct.anon.3.4664] }
%struct.anon.3.4664 = type { [6 x i8], %struct.float80_t.4663 }
%struct.float80_t.4663 = type { [10 x i8] }
%struct.MMX.4669 = type { [8 x %struct.anon.4.4668] }
%struct.anon.4.4668 = type { i64, %union.vec64_t.4667 }
%union.vec64_t.4667 = type { %struct.uint64v1_t.4666 }
%struct.uint64v1_t.4666 = type { [1 x i64] }
%struct.FPUStatusFlags.4670 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.4652 = type { i64 }
%union.FPU.4679 = type { %struct.anon.13.4678 }
%struct.anon.13.4678 = type { %struct.FpuFXSAVE.4677, [96 x i8] }
%struct.FpuFXSAVE.4677 = type { %union.SegmentSelector.4658, %union.SegmentSelector.4658, %union.FPUAbridgedTagWord.4671, i8, i16, i32, %union.SegmentSelector.4658, i16, i32, %union.SegmentSelector.4658, i16, %union.FPUControlStatus.4672, %union.FPUControlStatus.4672, [8 x %struct.FPUStackElem.4674], [16 x %union.vec128_t.4676] }
%union.FPUAbridgedTagWord.4671 = type { i8 }
%union.FPUControlStatus.4672 = type { i32 }
%struct.FPUStackElem.4674 = type { %union.anon.11.4673, [6 x i8] }
%union.anon.11.4673 = type { %struct.float80_t.4663 }
%union.vec128_t.4676 = type { %struct.uint128v1_t.4675 }
%struct.uint128v1_t.4675 = type { [1 x i128] }
%struct.SegmentCaches.4681 = type { %struct.SegmentShadow.4680, %struct.SegmentShadow.4680, %struct.SegmentShadow.4680, %struct.SegmentShadow.4680, %struct.SegmentShadow.4680, %struct.SegmentShadow.4680 }
%struct.SegmentShadow.4680 = type { %union.anon.4652, i32, i32 }
%struct.K_REG.4683 = type { [8 x %struct.anon.18.4682] }
%struct.anon.18.4682 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1100(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RBX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 3, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i124 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i124, align 8
  %sub.i.i.i125 = add i64 %6, -8
  %call.i.i.i126 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i125, i64 noundef %4) #13
  store i64 %sub.i.i.i125, ptr %rsp.i.i124, align 8
  store ptr %call.i.i.i126, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  %17 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %17, -8
  %call.i.i.i123 = call ptr @__remill_write_memory_64(ptr noundef %16, i64 noundef %sub.i.i.i, i64 noundef %15) #13
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i123, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RSP, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %21, 56
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %21, 56
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %21, i64 noundef 56, i64 noundef %sub.i.i) #13
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %24 = and i8 %23, 1
  %conv.i.i.i6 = xor i8 %24, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 56, %21
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %25 = trunc i64 %xor1.i.i.i.i9 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i10 = and i8 %26, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %21, 56
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %21, i64 noundef 56, i64 noundef %sub.i.i) #13
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %21, i64 noundef 56, i64 noundef %sub.i.i) #13
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %21
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %21, i64 noundef 56, i64 noundef %sub.i.i) #13
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RBP, align 8
  %31 = sub i64 %30, 28
  %32 = load i32, ptr %EDI, align 4
  %33 = zext i32 %32 to i64
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call ptr @__remill_write_memory_32(ptr noundef %34, i64 noundef %31, i32 noundef %32) #13
  store ptr %call.i.i79, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %27
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RBP, align 8
  %39 = sub i64 %38, 24
  %40 = load i32, ptr %ESI, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_32(ptr noundef %42, i64 noundef %39, i32 noundef %40) #13
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %35
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 3
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RBP, align 8
  %47 = sub i64 %46, 20
  %48 = load i32, ptr %EDX, align 4
  %49 = zext i32 %48 to i64
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %50, i64 noundef %47, i32 noundef %48) #13
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %43
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 4
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %RBP, align 8
  %55 = sub i64 %54, 16
  %56 = load i64, ptr %RCX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i80 = call ptr @__remill_write_memory_64(ptr noundef %57, i64 noundef %55, i64 noundef %56) #13
  store ptr %call.i.i80, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %51
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 7
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %NEXT_PC, align 8
  %62 = add i64 %61, 11947
  %63 = load ptr, ptr %MEMORY, align 8
  %call.i.i84 = call i64 @__remill_read_memory_64(ptr noundef %63, i64 noundef %62) #13
  store i64 %call.i.i84, ptr %RAX, align 8
  store ptr %63, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 2
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %RAX, align 8
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i32 @__remill_read_memory_32(ptr noundef %68, i64 noundef %67) #13
  %conv.i.i82 = zext i32 %call.i.i81 to i64
  store i64 %conv.i.i82, ptr %RDX, align 8
  store ptr %68, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %64
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 7
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %NEXT_PC, align 8
  %73 = add i64 %72, 11962
  %74 = load ptr, ptr %MEMORY, align 8
  %call.i.i83 = call i64 @__remill_read_memory_64(ptr noundef %74, i64 noundef %73) #13
  store i64 %call.i.i83, ptr %RAX, align 8
  store ptr %74, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %69
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RAX, align 8
  %79 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %79, i64 noundef %78) #13
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %80 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %81 = and i8 %80, 1
  %conv.i.i.i32 = xor i8 %81, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %82 = trunc i32 %xor1.i.i.i.i35 to i8
  %83 = lshr i8 %82, 4
  %conv2.i.i.i36 = and i8 %83, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #13
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %79, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %75
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 3
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  %88 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %88, 0
  %of.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  %89 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %89, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %84
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 2
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load i32, ptr %EDX, align 4
  %94 = zext i32 %93 to i64
  %95 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %94, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %95, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %90
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 3
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i64, ptr %RCX, align 8
  %100 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %99 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %101 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %101, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %102 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %103 = and i8 %102, 1
  %conv.i.i.i = xor i8 %103, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %104 = trunc i32 %xor1.i.i.i.i to i8
  %105 = lshr i8 %104, 4
  %conv2.i.i.i = and i8 %105, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %100, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %96
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RCX, align 8
  %110 = load i32, ptr %EDX, align 4
  %111 = zext i32 %110 to i64
  %112 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %109 to i32
  %sext.i = shl i64 %109, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %111, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %113 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %113, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %110, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %112, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %106
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RCX, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  %conv.i.i85 = trunc i64 %117 to i32
  %and3.i.i = and i32 1, %conv.i.i85
  %conv.i22.i86 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i86, ptr %RCX, align 8
  %cf.i.i87 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i87, align 1
  %conv.i.i.i88 = trunc i32 %and3.i.i to i8
  %119 = and i8 %conv.i.i.i88, 1
  %conv.i23.i89 = xor i8 %119, 1
  %pf.i.i90 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i89, ptr %pf.i.i90, align 1
  %cmp.i.i.i91 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i92 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i91, i32 noundef %conv.i.i85, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i92 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i93, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i85, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i94 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i94, align 1
  %of.i.i95 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i95, align 1
  %af.i.i96 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i96, align 1
  store ptr %118, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %114
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 3
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i32, ptr %ECX, align 4
  %124 = zext i32 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %123, i32 noundef 0, i32 noundef %123) #13
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %123 to i8
  %126 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %127 = and i8 %126, 1
  %conv.i.i.i57 = xor i8 %127, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %123, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %123, i32 noundef 0, i32 noundef %123) #13
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %123, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %123, i32 noundef 0, i32 noundef %123) #13
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %123, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %123, i32 noundef 0, i32 noundef %123) #13
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %120
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 3
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  %132 = load i8, ptr %zf.i, align 1
  store i8 %132, ptr %CL, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %128
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 2
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i8, ptr %AL, align 1
  %137 = zext i8 %136 to i64
  %138 = load i8, ptr %CL, align 1
  %139 = zext i8 %138 to i64
  %140 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %139, %137
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i97 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i97, align 1
  %141 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %142 = and i8 %141, 1
  %conv.i27.i = xor i8 %142, 1
  %pf.i.i98 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i98, align 1
  %143 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i99 = and i32 %143, 255
  %cmp.i.i.i100 = icmp eq i8 %or3.i.i, 0
  %144 = trunc i64 %137 to i32
  %conv1.i.i.i = and i32 %144, 255
  %145 = trunc i64 %139 to i32
  %conv2.i.i.i101 = and i32 %145, 255
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i100, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i101, i32 noundef %conv.i.i.i99) #13
  %conv3.i.i103 = zext i1 %call.i.i.i102 to i8
  %zf.i.i104 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i103, ptr %zf.i.i104, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i101, i32 noundef %conv.i.i.i99) #13
  %conv6.i.i105 = zext i1 %call4.i.i.i to i8
  %sf.i.i106 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i105, ptr %sf.i.i106, align 1
  %of.i.i107 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i107, align 1
  %af.i.i108 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i108, align 1
  store ptr %140, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %133
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 2
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i8, ptr %AL, align 1
  %150 = zext i8 %149 to i64
  %151 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %150
  %and3.i.i109 = trunc i64 %and3.i15.i to i8
  %cf.i.i110 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i110, align 1
  %152 = and i8 %and3.i.i109, 1
  %conv.i14.i = xor i8 %152, 1
  %pf.i.i111 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i111, align 1
  %153 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i112 = and i32 %153, 255
  %cmp.i.i.i113 = icmp eq i8 %and3.i.i109, 0
  %154 = trunc i64 %150 to i32
  %conv1.i.i.i114 = and i32 %154, 255
  %call.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i113, i32 noundef %conv1.i.i.i114, i32 noundef 1, i32 noundef %conv.i.i.i112) #13
  %conv3.i.i116 = zext i1 %call.i.i.i115 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i116, ptr %zf.i.i117, align 1
  %call4.i.i.i118 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i114, i32 noundef 1, i32 noundef %conv.i.i.i112) #13
  %conv6.i.i119 = zext i1 %call4.i.i.i118 to i8
  %sf.i.i120 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i119, ptr %sf.i.i120, align 1
  %of.i.i121 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i121, align 1
  %af.i.i122 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i122, align 1
  store ptr %151, ptr %MEMORY, align 8
  br label %155

155:                                              ; preds = %146
  %156 = load i64, ptr %NEXT_PC, align 8
  store i64 %156, ptr %PC, align 8
  %157 = add i64 %156, 6
  store i64 %157, ptr %NEXT_PC, align 8
  %158 = load i64, ptr %NEXT_PC, align 8
  %159 = add i64 %158, 5
  %160 = load i64, ptr %NEXT_PC, align 8
  %161 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  %162 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %162, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %159, i64 %160
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %161, ptr %MEMORY, align 8
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = load ptr, ptr %MEMORY, align 8
  ret ptr %164
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_114c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %R9D = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %R8B = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %R9B = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %R10D = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 21, i32 0, i32 0
  %R11D = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 23, i32 0, i32 0
  %EBX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 3, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RBX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 3, i32 0, i32 0
  %R11 = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 23, i32 0, i32 0
  %R10 = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 21, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %R9 = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i520 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #13
  store i64 %call.i.i520, ptr %R9, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 20
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i513 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #13
  %conv.i.i514 = zext i32 %call.i.i513 to i64
  store i64 %conv.i.i514, ptr %R10, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 24
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i511 = call i32 @__remill_read_memory_32(ptr noundef %18, i64 noundef %17) #13
  %conv.i.i512 = zext i32 %call.i.i511 to i64
  store i64 %conv.i.i512, ptr %R11, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 28
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i509 = call i32 @__remill_read_memory_32(ptr noundef %24, i64 noundef %23) #13
  %conv.i.i510 = zext i32 %call.i.i509 to i64
  store i64 %conv.i.i510, ptr %RBX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RSP, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  store i64 %28, ptr %RDI, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %25
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 4
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RDI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 -16, %33
  store i64 %add.i.i146, ptr %RDI, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %33
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, -16
  %35 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %35, i64 noundef %33, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %36 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %37 = and i8 %36, 1
  %conv.i.i.i153 = xor i8 %37, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, -16
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %33
  %38 = trunc i64 %xor1.i.i.i.i156 to i8
  %39 = lshr i8 %38, 4
  %conv2.i.i.i157 = and i8 %39, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %33, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %33, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %33
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %33, i64 noundef -16, i64 noundef %add.i.i146) #13
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %34, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %30
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %RDI, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  store i64 %43, ptr %RSP, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %40
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 3
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RSP, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  store i64 %48, ptr %RSI, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %45
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 4
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RSI, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %53
  store i64 %add.i.i117, ptr %RSI, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %53
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %55 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %55, i64 noundef %53, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %56 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %57 = and i8 %56, 1
  %conv.i.i.i124 = xor i8 %57, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %53
  %58 = trunc i64 %xor1.i.i.i.i127 to i8
  %59 = lshr i8 %58, 4
  %conv2.i.i.i128 = and i8 %59, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %53, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %53, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %53
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %53, i64 noundef -16, i64 noundef %add.i.i117) #13
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %54, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %50
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 3
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RSI, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  store i64 %63, ptr %RSP, align 8
  store ptr %64, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %60
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 3
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RSP, align 8
  %69 = load ptr, ptr %MEMORY, align 8
  store i64 %68, ptr %RDX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %65
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 4
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RDX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %73
  store i64 %add.i.i88, ptr %RDX, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %73
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %75 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %75, i64 noundef %73, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %76 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %77 = and i8 %76, 1
  %conv.i.i.i95 = xor i8 %77, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %73
  %78 = trunc i64 %xor1.i.i.i.i98 to i8
  %79 = lshr i8 %78, 4
  %conv2.i.i.i99 = and i8 %79, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %73, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %73, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %73
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %73, i64 noundef -16, i64 noundef %add.i.i88) #13
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %70
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RDX, align 8
  %84 = load ptr, ptr %MEMORY, align 8
  store i64 %83, ptr %RSP, align 8
  store ptr %84, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %80
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 3
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RSP, align 8
  %89 = load ptr, ptr %MEMORY, align 8
  store i64 %88, ptr %R8, align 8
  store ptr %89, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %85
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 4
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load i64, ptr %R8, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %93
  store i64 %add.i.i59, ptr %R8, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %93
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %95 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %95, i64 noundef %93, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %96 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %97 = and i8 %96, 1
  %conv.i.i.i66 = xor i8 %97, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %93
  %98 = trunc i64 %xor1.i.i.i.i69 to i8
  %99 = lshr i8 %98, 4
  %conv2.i.i.i70 = and i8 %99, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %93, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %93, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %93
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %93, i64 noundef -16, i64 noundef %add.i.i59) #13
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %100

100:                                              ; preds = %90
  %101 = load i64, ptr %NEXT_PC, align 8
  store i64 %101, ptr %PC, align 8
  %102 = add i64 %101, 3
  store i64 %102, ptr %NEXT_PC, align 8
  %103 = load i64, ptr %R8, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  store i64 %103, ptr %RSP, align 8
  store ptr %104, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %100
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RSP, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  store i64 %108, ptr %RAX, align 8
  store ptr %109, ptr %MEMORY, align 8
  br label %110

110:                                              ; preds = %105
  %111 = load i64, ptr %NEXT_PC, align 8
  store i64 %111, ptr %PC, align 8
  %112 = add i64 %111, 4
  store i64 %112, ptr %NEXT_PC, align 8
  %113 = load i64, ptr %RAX, align 8
  %114 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %113
  store i64 %add.i.i30, ptr %RAX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %113
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %115 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %115, i64 noundef %113, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %116 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %117 = and i8 %116, 1
  %conv.i.i.i37 = xor i8 %117, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %113
  %118 = trunc i64 %xor1.i.i.i.i40 to i8
  %119 = lshr i8 %118, 4
  %conv2.i.i.i41 = and i8 %119, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %113, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %113, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %113
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %113, i64 noundef -16, i64 noundef %add.i.i30) #13
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %110
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 4
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i64, ptr %RBP, align 8
  %124 = sub i64 %123, 48
  %125 = load i64, ptr %RAX, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  %call.i.i494 = call ptr @__remill_write_memory_64(ptr noundef %126, i64 noundef %124, i64 noundef %125) #13
  store ptr %call.i.i494, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %120
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 3
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i64, ptr %RAX, align 8
  %131 = load ptr, ptr %MEMORY, align 8
  store i64 %130, ptr %RSP, align 8
  store ptr %131, ptr %MEMORY, align 8
  br label %132

132:                                              ; preds = %127
  %133 = load i64, ptr %NEXT_PC, align 8
  store i64 %133, ptr %PC, align 8
  %134 = add i64 %133, 3
  store i64 %134, ptr %NEXT_PC, align 8
  %135 = load i64, ptr %RSP, align 8
  %136 = load ptr, ptr %MEMORY, align 8
  store i64 %135, ptr %RCX, align 8
  store ptr %136, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %132
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 4
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i64, ptr %RCX, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -32, %140
  store i64 %add.i.i1, ptr %RCX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %140
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -32
  %142 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %142, i64 noundef %140, i64 noundef -32, i64 noundef %add.i.i1) #13
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %143 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %144 = and i8 %143, 1
  %conv.i.i.i8 = xor i8 %144, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -32
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %140
  %145 = trunc i64 %xor1.i.i.i.i11 to i8
  %146 = lshr i8 %145, 4
  %conv2.i.i.i12 = and i8 %146, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %140, i64 noundef -32, i64 noundef %add.i.i1) #13
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %140, i64 noundef -32, i64 noundef %add.i.i1) #13
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %140
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %140, i64 noundef -32, i64 noundef %add.i.i1) #13
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %141, ptr %MEMORY, align 8
  br label %147

147:                                              ; preds = %137
  %148 = load i64, ptr %NEXT_PC, align 8
  store i64 %148, ptr %PC, align 8
  %149 = add i64 %148, 4
  store i64 %149, ptr %NEXT_PC, align 8
  %150 = load i64, ptr %RBP, align 8
  %151 = sub i64 %150, 40
  %152 = load i64, ptr %RCX, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  %call.i.i493 = call ptr @__remill_write_memory_64(ptr noundef %153, i64 noundef %151, i64 noundef %152) #13
  store ptr %call.i.i493, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %147
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i64, ptr %RCX, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  store i64 %157, ptr %RSP, align 8
  store ptr %158, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %154
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 2
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i64, ptr %RDI, align 8
  %163 = load i32, ptr %EBX, align 4
  %164 = zext i32 %163 to i64
  %165 = load ptr, ptr %MEMORY, align 8
  %call.i.i491 = call ptr @__remill_write_memory_32(ptr noundef %165, i64 noundef %162, i32 noundef %163) #13
  store ptr %call.i.i491, ptr %MEMORY, align 8
  br label %166

166:                                              ; preds = %159
  %167 = load i64, ptr %NEXT_PC, align 8
  store i64 %167, ptr %PC, align 8
  %168 = add i64 %167, 3
  store i64 %168, ptr %NEXT_PC, align 8
  %169 = load i64, ptr %RSI, align 8
  %170 = load i32, ptr %R11D, align 4
  %171 = zext i32 %170 to i64
  %172 = load ptr, ptr %MEMORY, align 8
  %call.i.i490 = call ptr @__remill_write_memory_32(ptr noundef %172, i64 noundef %169, i32 noundef %170) #13
  store ptr %call.i.i490, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %166
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 3
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i64, ptr %RDX, align 8
  %177 = load i32, ptr %R10D, align 4
  %178 = zext i32 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %call.i.i489 = call ptr @__remill_write_memory_32(ptr noundef %179, i64 noundef %176, i32 noundef %177) #13
  store ptr %call.i.i489, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %173
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 3
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i64, ptr %R8, align 8
  %184 = load i64, ptr %R9, align 8
  %185 = load ptr, ptr %MEMORY, align 8
  %call.i.i492 = call ptr @__remill_write_memory_64(ptr noundef %185, i64 noundef %183, i64 noundef %184) #13
  store ptr %call.i.i492, ptr %MEMORY, align 8
  br label %186

186:                                              ; preds = %180
  %187 = load i64, ptr %NEXT_PC, align 8
  store i64 %187, ptr %PC, align 8
  %188 = add i64 %187, 3
  store i64 %188, ptr %NEXT_PC, align 8
  %189 = load i64, ptr %R8, align 8
  %190 = load ptr, ptr %MEMORY, align 8
  %call.i.i519 = call i64 @__remill_read_memory_64(ptr noundef %190, i64 noundef %189) #13
  store i64 %call.i.i519, ptr %R9, align 8
  store ptr %190, ptr %MEMORY, align 8
  br label %191

191:                                              ; preds = %186
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = add i64 %192, 3
  store i64 %193, ptr %NEXT_PC, align 8
  %194 = load i64, ptr %RDI, align 8
  %195 = load ptr, ptr %MEMORY, align 8
  %call.i.i560 = call i32 @__remill_read_memory_32(ptr noundef %195, i64 noundef %194) #13
  %conv.i.i561 = sext i32 %call.i.i560 to i64
  store i64 %conv.i.i561, ptr %R10, align 8
  store ptr %195, ptr %MEMORY, align 8
  br label %196

196:                                              ; preds = %191
  %197 = load i64, ptr %NEXT_PC, align 8
  store i64 %197, ptr %PC, align 8
  %198 = add i64 %197, 4
  store i64 %198, ptr %NEXT_PC, align 8
  %199 = load i64, ptr %R9, align 8
  %200 = load i64, ptr %R10, align 8
  %201 = mul i64 %200, 4
  %202 = add i64 %199, %201
  %203 = load ptr, ptr %MEMORY, align 8
  %call.i.i507 = call i32 @__remill_read_memory_32(ptr noundef %203, i64 noundef %202) #13
  %conv.i.i508 = zext i32 %call.i.i507 to i64
  store i64 %conv.i.i508, ptr %R9, align 8
  store ptr %203, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %196
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 3
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i64, ptr %RAX, align 8
  %208 = load i8, ptr %R9B, align 1
  %209 = zext i8 %208 to i64
  %210 = load ptr, ptr %MEMORY, align 8
  %call.i.i479 = call ptr @__remill_write_memory_8(ptr noundef %210, i64 noundef %207, i8 noundef zeroext %208) #13
  store ptr %call.i.i479, ptr %MEMORY, align 8
  br label %211

211:                                              ; preds = %204
  %212 = load i64, ptr %NEXT_PC, align 8
  store i64 %212, ptr %PC, align 8
  %213 = add i64 %212, 3
  store i64 %213, ptr %NEXT_PC, align 8
  %214 = load i64, ptr %R8, align 8
  %215 = load ptr, ptr %MEMORY, align 8
  %call.i.i518 = call i64 @__remill_read_memory_64(ptr noundef %215, i64 noundef %214) #13
  store i64 %call.i.i518, ptr %R9, align 8
  store ptr %215, ptr %MEMORY, align 8
  br label %216

216:                                              ; preds = %211
  %217 = load i64, ptr %NEXT_PC, align 8
  store i64 %217, ptr %PC, align 8
  %218 = add i64 %217, 3
  store i64 %218, ptr %NEXT_PC, align 8
  %219 = load i64, ptr %RSI, align 8
  %220 = load ptr, ptr %MEMORY, align 8
  %call.i.i558 = call i32 @__remill_read_memory_32(ptr noundef %220, i64 noundef %219) #13
  %conv.i.i559 = sext i32 %call.i.i558 to i64
  store i64 %conv.i.i559, ptr %R10, align 8
  store ptr %220, ptr %MEMORY, align 8
  br label %221

221:                                              ; preds = %216
  %222 = load i64, ptr %NEXT_PC, align 8
  store i64 %222, ptr %PC, align 8
  %223 = add i64 %222, 4
  store i64 %223, ptr %NEXT_PC, align 8
  %224 = load i64, ptr %R9, align 8
  %225 = load i64, ptr %R10, align 8
  %226 = mul i64 %225, 4
  %227 = add i64 %224, %226
  %228 = load ptr, ptr %MEMORY, align 8
  %call.i.i505 = call i32 @__remill_read_memory_32(ptr noundef %228, i64 noundef %227) #13
  %conv.i.i506 = zext i32 %call.i.i505 to i64
  store i64 %conv.i.i506, ptr %R9, align 8
  store ptr %228, ptr %MEMORY, align 8
  br label %229

229:                                              ; preds = %221
  %230 = load i64, ptr %NEXT_PC, align 8
  store i64 %230, ptr %PC, align 8
  %231 = add i64 %230, 4
  store i64 %231, ptr %NEXT_PC, align 8
  %232 = load i64, ptr %RAX, align 8
  %233 = add i64 %232, 1
  %234 = load i8, ptr %R9B, align 1
  %235 = zext i8 %234 to i64
  %236 = load ptr, ptr %MEMORY, align 8
  %call.i.i478 = call ptr @__remill_write_memory_8(ptr noundef %236, i64 noundef %233, i8 noundef zeroext %234) #13
  store ptr %call.i.i478, ptr %MEMORY, align 8
  br label %237

237:                                              ; preds = %229
  %238 = load i64, ptr %NEXT_PC, align 8
  store i64 %238, ptr %PC, align 8
  %239 = add i64 %238, 3
  store i64 %239, ptr %NEXT_PC, align 8
  %240 = load i64, ptr %R8, align 8
  %241 = load ptr, ptr %MEMORY, align 8
  %call.i.i517 = call i64 @__remill_read_memory_64(ptr noundef %241, i64 noundef %240) #13
  store i64 %call.i.i517, ptr %R8, align 8
  store ptr %241, ptr %MEMORY, align 8
  br label %242

242:                                              ; preds = %237
  %243 = load i64, ptr %NEXT_PC, align 8
  store i64 %243, ptr %PC, align 8
  %244 = add i64 %243, 3
  store i64 %244, ptr %NEXT_PC, align 8
  %245 = load i64, ptr %RDX, align 8
  %246 = load ptr, ptr %MEMORY, align 8
  %call.i.i556 = call i32 @__remill_read_memory_32(ptr noundef %246, i64 noundef %245) #13
  %conv.i.i557 = sext i32 %call.i.i556 to i64
  store i64 %conv.i.i557, ptr %R9, align 8
  store ptr %246, ptr %MEMORY, align 8
  br label %247

247:                                              ; preds = %242
  %248 = load i64, ptr %NEXT_PC, align 8
  store i64 %248, ptr %PC, align 8
  %249 = add i64 %248, 4
  store i64 %249, ptr %NEXT_PC, align 8
  %250 = load i64, ptr %R8, align 8
  %251 = load i64, ptr %R9, align 8
  %252 = mul i64 %251, 4
  %253 = add i64 %250, %252
  %254 = load ptr, ptr %MEMORY, align 8
  %call.i.i503 = call i32 @__remill_read_memory_32(ptr noundef %254, i64 noundef %253) #13
  %conv.i.i504 = zext i32 %call.i.i503 to i64
  store i64 %conv.i.i504, ptr %R8, align 8
  store ptr %254, ptr %MEMORY, align 8
  br label %255

255:                                              ; preds = %247
  %256 = load i64, ptr %NEXT_PC, align 8
  store i64 %256, ptr %PC, align 8
  %257 = add i64 %256, 4
  store i64 %257, ptr %NEXT_PC, align 8
  %258 = load i64, ptr %RAX, align 8
  %259 = add i64 %258, 2
  %260 = load i8, ptr %R8B, align 1
  %261 = zext i8 %260 to i64
  %262 = load ptr, ptr %MEMORY, align 8
  %call.i.i477 = call ptr @__remill_write_memory_8(ptr noundef %262, i64 noundef %259, i8 noundef zeroext %260) #13
  store ptr %call.i.i477, ptr %MEMORY, align 8
  br label %263

263:                                              ; preds = %255
  %264 = load i64, ptr %NEXT_PC, align 8
  store i64 %264, ptr %PC, align 8
  %265 = add i64 %264, 4
  store i64 %265, ptr %NEXT_PC, align 8
  %266 = load i64, ptr %RAX, align 8
  %267 = load ptr, ptr %MEMORY, align 8
  %call.i.i547 = call zeroext i8 @__remill_read_memory_8(ptr noundef %267, i64 noundef %266) #13
  %conv.i.i548 = sext i8 %call.i.i547 to i64
  %conv.i10.i549 = and i64 %conv.i.i548, 4294967295
  store i64 %conv.i10.i549, ptr %R8, align 8
  store ptr %267, ptr %MEMORY, align 8
  br label %268

268:                                              ; preds = %263
  %269 = load i64, ptr %NEXT_PC, align 8
  store i64 %269, ptr %PC, align 8
  %270 = add i64 %269, 5
  store i64 %270, ptr %NEXT_PC, align 8
  %271 = load i64, ptr %RAX, align 8
  %272 = add i64 %271, 1
  %273 = load ptr, ptr %MEMORY, align 8
  %call.i.i544 = call zeroext i8 @__remill_read_memory_8(ptr noundef %273, i64 noundef %272) #13
  %conv.i.i545 = sext i8 %call.i.i544 to i64
  %conv.i10.i546 = and i64 %conv.i.i545, 4294967295
  store i64 %conv.i10.i546, ptr %R9, align 8
  store ptr %273, ptr %MEMORY, align 8
  br label %274

274:                                              ; preds = %268
  %275 = load i64, ptr %NEXT_PC, align 8
  store i64 %275, ptr %PC, align 8
  %276 = add i64 %275, 3
  store i64 %276, ptr %NEXT_PC, align 8
  %277 = load i64, ptr %R8, align 8
  %278 = load i32, ptr %R9D, align 4
  %279 = zext i32 %278 to i64
  %280 = load ptr, ptr %MEMORY, align 8
  %conv.i.i206 = trunc i64 %277 to i32
  %add.i.i207 = add i32 %278, %conv.i.i206
  %conv.i22.i208 = zext i32 %add.i.i207 to i64
  store i64 %conv.i22.i208, ptr %R8, align 8
  %cmp.i.i.i209 = icmp ult i32 %add.i.i207, %conv.i.i206
  %cmp1.i.i.i210 = icmp ult i32 %add.i.i207, %278
  %281 = or i1 %cmp.i.i.i209, %cmp1.i.i.i210
  %call.i.i.i211 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %281, i32 noundef %conv.i.i206, i32 noundef %278, i32 noundef %add.i.i207) #13
  %conv.i23.i212 = zext i1 %call.i.i.i211 to i8
  %cf.i.i213 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i212, ptr %cf.i.i213, align 1
  %conv.i.i.i.i214 = trunc i32 %add.i.i207 to i8
  %282 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i214)
  %283 = and i8 %282, 1
  %conv.i.i.i215 = xor i8 %283, 1
  %pf.i.i.i216 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i215, ptr %pf.i.i.i216, align 1
  %xor.i.i.i.i217 = xor i32 %add.i.i207, %278
  %xor1.i.i.i.i218 = xor i32 %xor.i.i.i.i217, %conv.i.i206
  %284 = trunc i32 %xor1.i.i.i.i218 to i8
  %285 = lshr i8 %284, 4
  %conv2.i.i.i219 = and i8 %285, 1
  %af.i.i.i220 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i219, ptr %af.i.i.i220, align 1
  %cmp.i.i.i.i221 = icmp eq i32 %add.i.i207, 0
  %call.i.i.i.i222 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i221, i32 noundef %conv.i.i206, i32 noundef %278, i32 noundef %add.i.i207) #13
  %conv5.i.i.i223 = zext i1 %call.i.i.i.i222 to i8
  %zf.i.i.i224 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i223, ptr %zf.i.i.i224, align 1
  %cmp.i27.i.i.i225 = icmp slt i32 %add.i.i207, 0
  %call1.i.i.i.i226 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i225, i32 noundef %conv.i.i206, i32 noundef %278, i32 noundef %add.i.i207) #13
  %conv8.i.i.i227 = zext i1 %call1.i.i.i.i226 to i8
  %sf.i.i.i228 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i227, ptr %sf.i.i.i228, align 1
  %shr8.i.i.i.i229 = xor i32 %add.i.i207, %conv.i.i206
  %xor.i28.i.i.i230 = lshr i32 %shr8.i.i.i.i229, 31
  %xor3.i.i.i.i231 = lshr i32 %xor.i.i.i.i217, 31
  %add.i.i.i.i232 = add nuw nsw i32 %xor.i28.i.i.i230, %xor3.i.i.i.i231
  %cmp.i29.i.i.i233 = icmp eq i32 %add.i.i.i.i232, 2
  %call.i30.i.i.i234 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i233, i32 noundef %conv.i.i206, i32 noundef %278, i32 noundef %add.i.i207) #13
  %conv11.i.i.i235 = zext i1 %call.i30.i.i.i234 to i8
  %of.i.i.i236 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i235, ptr %of.i.i.i236, align 1
  store ptr %280, ptr %MEMORY, align 8
  br label %286

286:                                              ; preds = %274
  %287 = load i64, ptr %NEXT_PC, align 8
  store i64 %287, ptr %PC, align 8
  %288 = add i64 %287, 4
  store i64 %288, ptr %NEXT_PC, align 8
  %289 = load i64, ptr %RAX, align 8
  %290 = add i64 %289, 3
  %291 = load i8, ptr %R8B, align 1
  %292 = zext i8 %291 to i64
  %293 = load ptr, ptr %MEMORY, align 8
  %call.i.i476 = call ptr @__remill_write_memory_8(ptr noundef %293, i64 noundef %290, i8 noundef zeroext %291) #13
  store ptr %call.i.i476, ptr %MEMORY, align 8
  br label %294

294:                                              ; preds = %286
  %295 = load i64, ptr %NEXT_PC, align 8
  store i64 %295, ptr %PC, align 8
  %296 = add i64 %295, 5
  store i64 %296, ptr %NEXT_PC, align 8
  %297 = load i64, ptr %RAX, align 8
  %298 = add i64 %297, 1
  %299 = load ptr, ptr %MEMORY, align 8
  %call.i.i541 = call zeroext i8 @__remill_read_memory_8(ptr noundef %299, i64 noundef %298) #13
  %conv.i.i542 = sext i8 %call.i.i541 to i64
  %conv.i10.i543 = and i64 %conv.i.i542, 4294967295
  store i64 %conv.i10.i543, ptr %R8, align 8
  store ptr %299, ptr %MEMORY, align 8
  br label %300

300:                                              ; preds = %294
  %301 = load i64, ptr %NEXT_PC, align 8
  store i64 %301, ptr %PC, align 8
  %302 = add i64 %301, 5
  store i64 %302, ptr %NEXT_PC, align 8
  %303 = load i64, ptr %RAX, align 8
  %304 = add i64 %303, 2
  %305 = load ptr, ptr %MEMORY, align 8
  %call.i.i538 = call zeroext i8 @__remill_read_memory_8(ptr noundef %305, i64 noundef %304) #13
  %conv.i.i539 = sext i8 %call.i.i538 to i64
  %conv.i10.i540 = and i64 %conv.i.i539, 4294967295
  store i64 %conv.i10.i540, ptr %R9, align 8
  store ptr %305, ptr %MEMORY, align 8
  br label %306

306:                                              ; preds = %300
  %307 = load i64, ptr %NEXT_PC, align 8
  store i64 %307, ptr %PC, align 8
  %308 = add i64 %307, 3
  store i64 %308, ptr %NEXT_PC, align 8
  %309 = load i64, ptr %R8, align 8
  %310 = load i32, ptr %R9D, align 4
  %311 = zext i32 %310 to i64
  %312 = load ptr, ptr %MEMORY, align 8
  %conv.i.i175 = trunc i64 %309 to i32
  %add.i.i176 = add i32 %310, %conv.i.i175
  %conv.i22.i177 = zext i32 %add.i.i176 to i64
  store i64 %conv.i22.i177, ptr %R8, align 8
  %cmp.i.i.i178 = icmp ult i32 %add.i.i176, %conv.i.i175
  %cmp1.i.i.i179 = icmp ult i32 %add.i.i176, %310
  %313 = or i1 %cmp.i.i.i178, %cmp1.i.i.i179
  %call.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %313, i32 noundef %conv.i.i175, i32 noundef %310, i32 noundef %add.i.i176) #13
  %conv.i23.i181 = zext i1 %call.i.i.i180 to i8
  %cf.i.i182 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i181, ptr %cf.i.i182, align 1
  %conv.i.i.i.i183 = trunc i32 %add.i.i176 to i8
  %314 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i183)
  %315 = and i8 %314, 1
  %conv.i.i.i184 = xor i8 %315, 1
  %pf.i.i.i185 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i184, ptr %pf.i.i.i185, align 1
  %xor.i.i.i.i186 = xor i32 %add.i.i176, %310
  %xor1.i.i.i.i187 = xor i32 %xor.i.i.i.i186, %conv.i.i175
  %316 = trunc i32 %xor1.i.i.i.i187 to i8
  %317 = lshr i8 %316, 4
  %conv2.i.i.i188 = and i8 %317, 1
  %af.i.i.i189 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i188, ptr %af.i.i.i189, align 1
  %cmp.i.i.i.i190 = icmp eq i32 %add.i.i176, 0
  %call.i.i.i.i191 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i190, i32 noundef %conv.i.i175, i32 noundef %310, i32 noundef %add.i.i176) #13
  %conv5.i.i.i192 = zext i1 %call.i.i.i.i191 to i8
  %zf.i.i.i193 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i192, ptr %zf.i.i.i193, align 1
  %cmp.i27.i.i.i194 = icmp slt i32 %add.i.i176, 0
  %call1.i.i.i.i195 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i194, i32 noundef %conv.i.i175, i32 noundef %310, i32 noundef %add.i.i176) #13
  %conv8.i.i.i196 = zext i1 %call1.i.i.i.i195 to i8
  %sf.i.i.i197 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i196, ptr %sf.i.i.i197, align 1
  %shr8.i.i.i.i198 = xor i32 %add.i.i176, %conv.i.i175
  %xor.i28.i.i.i199 = lshr i32 %shr8.i.i.i.i198, 31
  %xor3.i.i.i.i200 = lshr i32 %xor.i.i.i.i186, 31
  %add.i.i.i.i201 = add nuw nsw i32 %xor.i28.i.i.i199, %xor3.i.i.i.i200
  %cmp.i29.i.i.i202 = icmp eq i32 %add.i.i.i.i201, 2
  %call.i30.i.i.i203 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i202, i32 noundef %conv.i.i175, i32 noundef %310, i32 noundef %add.i.i176) #13
  %conv11.i.i.i204 = zext i1 %call.i30.i.i.i203 to i8
  %of.i.i.i205 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i204, ptr %of.i.i.i205, align 1
  store ptr %312, ptr %MEMORY, align 8
  br label %318

318:                                              ; preds = %306
  %319 = load i64, ptr %NEXT_PC, align 8
  store i64 %319, ptr %PC, align 8
  %320 = add i64 %319, 4
  store i64 %320, ptr %NEXT_PC, align 8
  %321 = load i64, ptr %RAX, align 8
  %322 = add i64 %321, 4
  %323 = load i8, ptr %R8B, align 1
  %324 = zext i8 %323 to i64
  %325 = load ptr, ptr %MEMORY, align 8
  %call.i.i475 = call ptr @__remill_write_memory_8(ptr noundef %325, i64 noundef %322, i8 noundef zeroext %323) #13
  store ptr %call.i.i475, ptr %MEMORY, align 8
  br label %326

326:                                              ; preds = %318
  %327 = load i64, ptr %NEXT_PC, align 8
  store i64 %327, ptr %PC, align 8
  %328 = add i64 %327, 4
  store i64 %328, ptr %NEXT_PC, align 8
  %329 = load i64, ptr %RAX, align 8
  %330 = load ptr, ptr %MEMORY, align 8
  %call.i.i535 = call zeroext i8 @__remill_read_memory_8(ptr noundef %330, i64 noundef %329) #13
  %conv.i.i536 = sext i8 %call.i.i535 to i64
  %conv.i10.i537 = and i64 %conv.i.i536, 4294967295
  store i64 %conv.i10.i537, ptr %R8, align 8
  store ptr %330, ptr %MEMORY, align 8
  br label %331

331:                                              ; preds = %326
  %332 = load i64, ptr %NEXT_PC, align 8
  store i64 %332, ptr %PC, align 8
  %333 = add i64 %332, 3
  store i64 %333, ptr %NEXT_PC, align 8
  %334 = load i64, ptr %RCX, align 8
  %335 = load i32, ptr %R8D, align 4
  %336 = zext i32 %335 to i64
  %337 = load ptr, ptr %MEMORY, align 8
  %call.i.i488 = call ptr @__remill_write_memory_32(ptr noundef %337, i64 noundef %334, i32 noundef %335) #13
  store ptr %call.i.i488, ptr %MEMORY, align 8
  br label %338

338:                                              ; preds = %331
  %339 = load i64, ptr %NEXT_PC, align 8
  store i64 %339, ptr %PC, align 8
  %340 = add i64 %339, 5
  store i64 %340, ptr %NEXT_PC, align 8
  %341 = load i64, ptr %RAX, align 8
  %342 = add i64 %341, 1
  %343 = load ptr, ptr %MEMORY, align 8
  %call.i.i532 = call zeroext i8 @__remill_read_memory_8(ptr noundef %343, i64 noundef %342) #13
  %conv.i.i533 = sext i8 %call.i.i532 to i64
  %conv.i10.i534 = and i64 %conv.i.i533, 4294967295
  store i64 %conv.i10.i534, ptr %R8, align 8
  store ptr %343, ptr %MEMORY, align 8
  br label %344

344:                                              ; preds = %338
  %345 = load i64, ptr %NEXT_PC, align 8
  store i64 %345, ptr %PC, align 8
  %346 = add i64 %345, 4
  store i64 %346, ptr %NEXT_PC, align 8
  %347 = load i64, ptr %RCX, align 8
  %348 = add i64 %347, 4
  %349 = load i32, ptr %R8D, align 4
  %350 = zext i32 %349 to i64
  %351 = load ptr, ptr %MEMORY, align 8
  %call.i.i487 = call ptr @__remill_write_memory_32(ptr noundef %351, i64 noundef %348, i32 noundef %349) #13
  store ptr %call.i.i487, ptr %MEMORY, align 8
  br label %352

352:                                              ; preds = %344
  %353 = load i64, ptr %NEXT_PC, align 8
  store i64 %353, ptr %PC, align 8
  %354 = add i64 %353, 5
  store i64 %354, ptr %NEXT_PC, align 8
  %355 = load i64, ptr %RAX, align 8
  %356 = add i64 %355, 2
  %357 = load ptr, ptr %MEMORY, align 8
  %call.i.i529 = call zeroext i8 @__remill_read_memory_8(ptr noundef %357, i64 noundef %356) #13
  %conv.i.i530 = sext i8 %call.i.i529 to i64
  %conv.i10.i531 = and i64 %conv.i.i530, 4294967295
  store i64 %conv.i10.i531, ptr %R8, align 8
  store ptr %357, ptr %MEMORY, align 8
  br label %358

358:                                              ; preds = %352
  %359 = load i64, ptr %NEXT_PC, align 8
  store i64 %359, ptr %PC, align 8
  %360 = add i64 %359, 4
  store i64 %360, ptr %NEXT_PC, align 8
  %361 = load i64, ptr %RCX, align 8
  %362 = add i64 %361, 8
  %363 = load i32, ptr %R8D, align 4
  %364 = zext i32 %363 to i64
  %365 = load ptr, ptr %MEMORY, align 8
  %call.i.i486 = call ptr @__remill_write_memory_32(ptr noundef %365, i64 noundef %362, i32 noundef %363) #13
  store ptr %call.i.i486, ptr %MEMORY, align 8
  br label %366

366:                                              ; preds = %358
  %367 = load i64, ptr %NEXT_PC, align 8
  store i64 %367, ptr %PC, align 8
  %368 = add i64 %367, 5
  store i64 %368, ptr %NEXT_PC, align 8
  %369 = load i64, ptr %RAX, align 8
  %370 = add i64 %369, 3
  %371 = load ptr, ptr %MEMORY, align 8
  %call.i.i526 = call zeroext i8 @__remill_read_memory_8(ptr noundef %371, i64 noundef %370) #13
  %conv.i.i527 = sext i8 %call.i.i526 to i64
  %conv.i10.i528 = and i64 %conv.i.i527, 4294967295
  store i64 %conv.i10.i528, ptr %R8, align 8
  store ptr %371, ptr %MEMORY, align 8
  br label %372

372:                                              ; preds = %366
  %373 = load i64, ptr %NEXT_PC, align 8
  store i64 %373, ptr %PC, align 8
  %374 = add i64 %373, 4
  store i64 %374, ptr %NEXT_PC, align 8
  %375 = load i64, ptr %RCX, align 8
  %376 = add i64 %375, 12
  %377 = load i32, ptr %R8D, align 4
  %378 = zext i32 %377 to i64
  %379 = load ptr, ptr %MEMORY, align 8
  %call.i.i485 = call ptr @__remill_write_memory_32(ptr noundef %379, i64 noundef %376, i32 noundef %377) #13
  store ptr %call.i.i485, ptr %MEMORY, align 8
  br label %380

380:                                              ; preds = %372
  %381 = load i64, ptr %NEXT_PC, align 8
  store i64 %381, ptr %PC, align 8
  %382 = add i64 %381, 5
  store i64 %382, ptr %NEXT_PC, align 8
  %383 = load i64, ptr %RAX, align 8
  %384 = add i64 %383, 4
  %385 = load ptr, ptr %MEMORY, align 8
  %call.i.i523 = call zeroext i8 @__remill_read_memory_8(ptr noundef %385, i64 noundef %384) #13
  %conv.i.i524 = sext i8 %call.i.i523 to i64
  %conv.i10.i525 = and i64 %conv.i.i524, 4294967295
  store i64 %conv.i10.i525, ptr %R8, align 8
  store ptr %385, ptr %MEMORY, align 8
  br label %386

386:                                              ; preds = %380
  %387 = load i64, ptr %NEXT_PC, align 8
  store i64 %387, ptr %PC, align 8
  %388 = add i64 %387, 4
  store i64 %388, ptr %NEXT_PC, align 8
  %389 = load i64, ptr %RCX, align 8
  %390 = add i64 %389, 16
  %391 = load i32, ptr %R8D, align 4
  %392 = zext i32 %391 to i64
  %393 = load ptr, ptr %MEMORY, align 8
  %call.i.i484 = call ptr @__remill_write_memory_32(ptr noundef %393, i64 noundef %390, i32 noundef %391) #13
  store ptr %call.i.i484, ptr %MEMORY, align 8
  br label %394

394:                                              ; preds = %386
  %395 = load i64, ptr %NEXT_PC, align 8
  store i64 %395, ptr %PC, align 8
  %396 = add i64 %395, 3
  store i64 %396, ptr %NEXT_PC, align 8
  %397 = load i64, ptr %RCX, align 8
  %398 = load ptr, ptr %MEMORY, align 8
  %call.i.i501 = call i32 @__remill_read_memory_32(ptr noundef %398, i64 noundef %397) #13
  %conv.i.i502 = zext i32 %call.i.i501 to i64
  store i64 %conv.i.i502, ptr %R8, align 8
  store ptr %398, ptr %MEMORY, align 8
  br label %399

399:                                              ; preds = %394
  %400 = load i64, ptr %NEXT_PC, align 8
  store i64 %400, ptr %PC, align 8
  %401 = add i64 %400, 4
  store i64 %401, ptr %NEXT_PC, align 8
  %402 = load i64, ptr %R8, align 8
  %403 = load i64, ptr %RCX, align 8
  %404 = add i64 %403, 4
  %405 = load ptr, ptr %MEMORY, align 8
  %conv.i.i394 = trunc i64 %402 to i32
  %call.i.i395 = call i32 @__remill_read_memory_32(ptr noundef %405, i64 noundef %404) #13
  %add.i.i396 = add i32 %call.i.i395, %conv.i.i394
  %conv.i18.i397 = zext i32 %add.i.i396 to i64
  store i64 %conv.i18.i397, ptr %R8, align 8
  %cmp.i.i.i398 = icmp ult i32 %add.i.i396, %conv.i.i394
  %cmp1.i.i.i399 = icmp ult i32 %add.i.i396, %call.i.i395
  %406 = or i1 %cmp.i.i.i398, %cmp1.i.i.i399
  %call.i.i.i400 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %406, i32 noundef %conv.i.i394, i32 noundef %call.i.i395, i32 noundef %add.i.i396) #13
  %conv.i19.i401 = zext i1 %call.i.i.i400 to i8
  %cf.i.i402 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i401, ptr %cf.i.i402, align 1
  %conv.i.i.i.i403 = trunc i32 %add.i.i396 to i8
  %407 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i403)
  %408 = and i8 %407, 1
  %conv.i.i.i404 = xor i8 %408, 1
  %pf.i.i.i405 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i404, ptr %pf.i.i.i405, align 1
  %xor.i.i.i.i406 = xor i32 %add.i.i396, %call.i.i395
  %xor1.i.i.i.i407 = xor i32 %xor.i.i.i.i406, %conv.i.i394
  %409 = trunc i32 %xor1.i.i.i.i407 to i8
  %410 = lshr i8 %409, 4
  %conv2.i.i.i408 = and i8 %410, 1
  %af.i.i.i409 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i408, ptr %af.i.i.i409, align 1
  %cmp.i.i.i.i410 = icmp eq i32 %add.i.i396, 0
  %call.i.i.i.i411 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i410, i32 noundef %conv.i.i394, i32 noundef %call.i.i395, i32 noundef %add.i.i396) #13
  %conv5.i.i.i412 = zext i1 %call.i.i.i.i411 to i8
  %zf.i.i.i413 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i412, ptr %zf.i.i.i413, align 1
  %cmp.i27.i.i.i414 = icmp slt i32 %add.i.i396, 0
  %call1.i.i.i.i415 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i414, i32 noundef %conv.i.i394, i32 noundef %call.i.i395, i32 noundef %add.i.i396) #13
  %conv8.i.i.i416 = zext i1 %call1.i.i.i.i415 to i8
  %sf.i.i.i417 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i416, ptr %sf.i.i.i417, align 1
  %shr8.i.i.i.i418 = xor i32 %add.i.i396, %conv.i.i394
  %xor.i28.i.i.i419 = lshr i32 %shr8.i.i.i.i418, 31
  %xor3.i.i.i.i420 = lshr i32 %xor.i.i.i.i406, 31
  %add.i.i.i.i421 = add nuw nsw i32 %xor.i28.i.i.i419, %xor3.i.i.i.i420
  %cmp.i29.i.i.i422 = icmp eq i32 %add.i.i.i.i421, 2
  %call.i30.i.i.i423 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i422, i32 noundef %conv.i.i394, i32 noundef %call.i.i395, i32 noundef %add.i.i396) #13
  %conv11.i.i.i424 = zext i1 %call.i30.i.i.i423 to i8
  %of.i.i.i425 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i424, ptr %of.i.i.i425, align 1
  store ptr %405, ptr %MEMORY, align 8
  br label %411

411:                                              ; preds = %399
  %412 = load i64, ptr %NEXT_PC, align 8
  store i64 %412, ptr %PC, align 8
  %413 = add i64 %412, 4
  store i64 %413, ptr %NEXT_PC, align 8
  %414 = load i64, ptr %RCX, align 8
  %415 = add i64 %414, 20
  %416 = load i32, ptr %R8D, align 4
  %417 = zext i32 %416 to i64
  %418 = load ptr, ptr %MEMORY, align 8
  %call.i.i483 = call ptr @__remill_write_memory_32(ptr noundef %418, i64 noundef %415, i32 noundef %416) #13
  store ptr %call.i.i483, ptr %MEMORY, align 8
  br label %419

419:                                              ; preds = %411
  %420 = load i64, ptr %NEXT_PC, align 8
  store i64 %420, ptr %PC, align 8
  %421 = add i64 %420, 4
  store i64 %421, ptr %NEXT_PC, align 8
  %422 = load i64, ptr %RCX, align 8
  %423 = add i64 %422, 8
  %424 = load ptr, ptr %MEMORY, align 8
  %call.i.i499 = call i32 @__remill_read_memory_32(ptr noundef %424, i64 noundef %423) #13
  %conv.i.i500 = zext i32 %call.i.i499 to i64
  store i64 %conv.i.i500, ptr %R8, align 8
  store ptr %424, ptr %MEMORY, align 8
  br label %425

425:                                              ; preds = %419
  %426 = load i64, ptr %NEXT_PC, align 8
  store i64 %426, ptr %PC, align 8
  %427 = add i64 %426, 4
  store i64 %427, ptr %NEXT_PC, align 8
  %428 = load i64, ptr %R8, align 8
  %429 = load i64, ptr %RCX, align 8
  %430 = add i64 %429, 12
  %431 = load ptr, ptr %MEMORY, align 8
  %conv.i.i362 = trunc i64 %428 to i32
  %call.i.i363 = call i32 @__remill_read_memory_32(ptr noundef %431, i64 noundef %430) #13
  %add.i.i364 = add i32 %call.i.i363, %conv.i.i362
  %conv.i18.i365 = zext i32 %add.i.i364 to i64
  store i64 %conv.i18.i365, ptr %R8, align 8
  %cmp.i.i.i366 = icmp ult i32 %add.i.i364, %conv.i.i362
  %cmp1.i.i.i367 = icmp ult i32 %add.i.i364, %call.i.i363
  %432 = or i1 %cmp.i.i.i366, %cmp1.i.i.i367
  %call.i.i.i368 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %432, i32 noundef %conv.i.i362, i32 noundef %call.i.i363, i32 noundef %add.i.i364) #13
  %conv.i19.i369 = zext i1 %call.i.i.i368 to i8
  %cf.i.i370 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i369, ptr %cf.i.i370, align 1
  %conv.i.i.i.i371 = trunc i32 %add.i.i364 to i8
  %433 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i371)
  %434 = and i8 %433, 1
  %conv.i.i.i372 = xor i8 %434, 1
  %pf.i.i.i373 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i372, ptr %pf.i.i.i373, align 1
  %xor.i.i.i.i374 = xor i32 %add.i.i364, %call.i.i363
  %xor1.i.i.i.i375 = xor i32 %xor.i.i.i.i374, %conv.i.i362
  %435 = trunc i32 %xor1.i.i.i.i375 to i8
  %436 = lshr i8 %435, 4
  %conv2.i.i.i376 = and i8 %436, 1
  %af.i.i.i377 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i376, ptr %af.i.i.i377, align 1
  %cmp.i.i.i.i378 = icmp eq i32 %add.i.i364, 0
  %call.i.i.i.i379 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i378, i32 noundef %conv.i.i362, i32 noundef %call.i.i363, i32 noundef %add.i.i364) #13
  %conv5.i.i.i380 = zext i1 %call.i.i.i.i379 to i8
  %zf.i.i.i381 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i380, ptr %zf.i.i.i381, align 1
  %cmp.i27.i.i.i382 = icmp slt i32 %add.i.i364, 0
  %call1.i.i.i.i383 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i382, i32 noundef %conv.i.i362, i32 noundef %call.i.i363, i32 noundef %add.i.i364) #13
  %conv8.i.i.i384 = zext i1 %call1.i.i.i.i383 to i8
  %sf.i.i.i385 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i384, ptr %sf.i.i.i385, align 1
  %shr8.i.i.i.i386 = xor i32 %add.i.i364, %conv.i.i362
  %xor.i28.i.i.i387 = lshr i32 %shr8.i.i.i.i386, 31
  %xor3.i.i.i.i388 = lshr i32 %xor.i.i.i.i374, 31
  %add.i.i.i.i389 = add nuw nsw i32 %xor.i28.i.i.i387, %xor3.i.i.i.i388
  %cmp.i29.i.i.i390 = icmp eq i32 %add.i.i.i.i389, 2
  %call.i30.i.i.i391 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i390, i32 noundef %conv.i.i362, i32 noundef %call.i.i363, i32 noundef %add.i.i364) #13
  %conv11.i.i.i392 = zext i1 %call.i30.i.i.i391 to i8
  %of.i.i.i393 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i392, ptr %of.i.i.i393, align 1
  store ptr %431, ptr %MEMORY, align 8
  br label %437

437:                                              ; preds = %425
  %438 = load i64, ptr %NEXT_PC, align 8
  store i64 %438, ptr %PC, align 8
  %439 = add i64 %438, 4
  store i64 %439, ptr %NEXT_PC, align 8
  %440 = load i64, ptr %RCX, align 8
  %441 = add i64 %440, 24
  %442 = load i32, ptr %R8D, align 4
  %443 = zext i32 %442 to i64
  %444 = load ptr, ptr %MEMORY, align 8
  %call.i.i482 = call ptr @__remill_write_memory_32(ptr noundef %444, i64 noundef %441, i32 noundef %442) #13
  store ptr %call.i.i482, ptr %MEMORY, align 8
  br label %445

445:                                              ; preds = %437
  %446 = load i64, ptr %NEXT_PC, align 8
  store i64 %446, ptr %PC, align 8
  %447 = add i64 %446, 4
  store i64 %447, ptr %NEXT_PC, align 8
  %448 = load i64, ptr %RCX, align 8
  %449 = add i64 %448, 16
  %450 = load ptr, ptr %MEMORY, align 8
  %call.i.i497 = call i32 @__remill_read_memory_32(ptr noundef %450, i64 noundef %449) #13
  %conv.i.i498 = zext i32 %call.i.i497 to i64
  store i64 %conv.i.i498, ptr %R8, align 8
  store ptr %450, ptr %MEMORY, align 8
  br label %451

451:                                              ; preds = %445
  %452 = load i64, ptr %NEXT_PC, align 8
  store i64 %452, ptr %PC, align 8
  %453 = add i64 %452, 4
  store i64 %453, ptr %NEXT_PC, align 8
  %454 = load i64, ptr %R8, align 8
  %455 = load i64, ptr %RCX, align 8
  %456 = add i64 %455, 20
  %457 = load ptr, ptr %MEMORY, align 8
  %conv.i.i330 = trunc i64 %454 to i32
  %call.i.i331 = call i32 @__remill_read_memory_32(ptr noundef %457, i64 noundef %456) #13
  %add.i.i332 = add i32 %call.i.i331, %conv.i.i330
  %conv.i18.i333 = zext i32 %add.i.i332 to i64
  store i64 %conv.i18.i333, ptr %R8, align 8
  %cmp.i.i.i334 = icmp ult i32 %add.i.i332, %conv.i.i330
  %cmp1.i.i.i335 = icmp ult i32 %add.i.i332, %call.i.i331
  %458 = or i1 %cmp.i.i.i334, %cmp1.i.i.i335
  %call.i.i.i336 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %458, i32 noundef %conv.i.i330, i32 noundef %call.i.i331, i32 noundef %add.i.i332) #13
  %conv.i19.i337 = zext i1 %call.i.i.i336 to i8
  %cf.i.i338 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i337, ptr %cf.i.i338, align 1
  %conv.i.i.i.i339 = trunc i32 %add.i.i332 to i8
  %459 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i339)
  %460 = and i8 %459, 1
  %conv.i.i.i340 = xor i8 %460, 1
  %pf.i.i.i341 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i340, ptr %pf.i.i.i341, align 1
  %xor.i.i.i.i342 = xor i32 %add.i.i332, %call.i.i331
  %xor1.i.i.i.i343 = xor i32 %xor.i.i.i.i342, %conv.i.i330
  %461 = trunc i32 %xor1.i.i.i.i343 to i8
  %462 = lshr i8 %461, 4
  %conv2.i.i.i344 = and i8 %462, 1
  %af.i.i.i345 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i344, ptr %af.i.i.i345, align 1
  %cmp.i.i.i.i346 = icmp eq i32 %add.i.i332, 0
  %call.i.i.i.i347 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i346, i32 noundef %conv.i.i330, i32 noundef %call.i.i331, i32 noundef %add.i.i332) #13
  %conv5.i.i.i348 = zext i1 %call.i.i.i.i347 to i8
  %zf.i.i.i349 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i348, ptr %zf.i.i.i349, align 1
  %cmp.i27.i.i.i350 = icmp slt i32 %add.i.i332, 0
  %call1.i.i.i.i351 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i350, i32 noundef %conv.i.i330, i32 noundef %call.i.i331, i32 noundef %add.i.i332) #13
  %conv8.i.i.i352 = zext i1 %call1.i.i.i.i351 to i8
  %sf.i.i.i353 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i352, ptr %sf.i.i.i353, align 1
  %shr8.i.i.i.i354 = xor i32 %add.i.i332, %conv.i.i330
  %xor.i28.i.i.i355 = lshr i32 %shr8.i.i.i.i354, 31
  %xor3.i.i.i.i356 = lshr i32 %xor.i.i.i.i342, 31
  %add.i.i.i.i357 = add nuw nsw i32 %xor.i28.i.i.i355, %xor3.i.i.i.i356
  %cmp.i29.i.i.i358 = icmp eq i32 %add.i.i.i.i357, 2
  %call.i30.i.i.i359 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i358, i32 noundef %conv.i.i330, i32 noundef %call.i.i331, i32 noundef %add.i.i332) #13
  %conv11.i.i.i360 = zext i1 %call.i30.i.i.i359 to i8
  %of.i.i.i361 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i360, ptr %of.i.i.i361, align 1
  store ptr %457, ptr %MEMORY, align 8
  br label %463

463:                                              ; preds = %451
  %464 = load i64, ptr %NEXT_PC, align 8
  store i64 %464, ptr %PC, align 8
  %465 = add i64 %464, 4
  store i64 %465, ptr %NEXT_PC, align 8
  %466 = load i64, ptr %R8, align 8
  %467 = load i64, ptr %RCX, align 8
  %468 = add i64 %467, 24
  %469 = load ptr, ptr %MEMORY, align 8
  %conv.i.i298 = trunc i64 %466 to i32
  %call.i.i299 = call i32 @__remill_read_memory_32(ptr noundef %469, i64 noundef %468) #13
  %add.i.i300 = add i32 %call.i.i299, %conv.i.i298
  %conv.i18.i301 = zext i32 %add.i.i300 to i64
  store i64 %conv.i18.i301, ptr %R8, align 8
  %cmp.i.i.i302 = icmp ult i32 %add.i.i300, %conv.i.i298
  %cmp1.i.i.i303 = icmp ult i32 %add.i.i300, %call.i.i299
  %470 = or i1 %cmp.i.i.i302, %cmp1.i.i.i303
  %call.i.i.i304 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %470, i32 noundef %conv.i.i298, i32 noundef %call.i.i299, i32 noundef %add.i.i300) #13
  %conv.i19.i305 = zext i1 %call.i.i.i304 to i8
  %cf.i.i306 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i305, ptr %cf.i.i306, align 1
  %conv.i.i.i.i307 = trunc i32 %add.i.i300 to i8
  %471 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i307)
  %472 = and i8 %471, 1
  %conv.i.i.i308 = xor i8 %472, 1
  %pf.i.i.i309 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i308, ptr %pf.i.i.i309, align 1
  %xor.i.i.i.i310 = xor i32 %add.i.i300, %call.i.i299
  %xor1.i.i.i.i311 = xor i32 %xor.i.i.i.i310, %conv.i.i298
  %473 = trunc i32 %xor1.i.i.i.i311 to i8
  %474 = lshr i8 %473, 4
  %conv2.i.i.i312 = and i8 %474, 1
  %af.i.i.i313 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i312, ptr %af.i.i.i313, align 1
  %cmp.i.i.i.i314 = icmp eq i32 %add.i.i300, 0
  %call.i.i.i.i315 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i314, i32 noundef %conv.i.i298, i32 noundef %call.i.i299, i32 noundef %add.i.i300) #13
  %conv5.i.i.i316 = zext i1 %call.i.i.i.i315 to i8
  %zf.i.i.i317 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i316, ptr %zf.i.i.i317, align 1
  %cmp.i27.i.i.i318 = icmp slt i32 %add.i.i300, 0
  %call1.i.i.i.i319 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i318, i32 noundef %conv.i.i298, i32 noundef %call.i.i299, i32 noundef %add.i.i300) #13
  %conv8.i.i.i320 = zext i1 %call1.i.i.i.i319 to i8
  %sf.i.i.i321 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i320, ptr %sf.i.i.i321, align 1
  %shr8.i.i.i.i322 = xor i32 %add.i.i300, %conv.i.i298
  %xor.i28.i.i.i323 = lshr i32 %shr8.i.i.i.i322, 31
  %xor3.i.i.i.i324 = lshr i32 %xor.i.i.i.i310, 31
  %add.i.i.i.i325 = add nuw nsw i32 %xor.i28.i.i.i323, %xor3.i.i.i.i324
  %cmp.i29.i.i.i326 = icmp eq i32 %add.i.i.i.i325, 2
  %call.i30.i.i.i327 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i326, i32 noundef %conv.i.i298, i32 noundef %call.i.i299, i32 noundef %add.i.i300) #13
  %conv11.i.i.i328 = zext i1 %call.i30.i.i.i327 to i8
  %of.i.i.i329 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i328, ptr %of.i.i.i329, align 1
  store ptr %469, ptr %MEMORY, align 8
  br label %475

475:                                              ; preds = %463
  %476 = load i64, ptr %NEXT_PC, align 8
  store i64 %476, ptr %PC, align 8
  %477 = add i64 %476, 4
  store i64 %477, ptr %NEXT_PC, align 8
  %478 = load i64, ptr %RCX, align 8
  %479 = add i64 %478, 28
  %480 = load i32, ptr %R8D, align 4
  %481 = zext i32 %480 to i64
  %482 = load ptr, ptr %MEMORY, align 8
  %call.i.i481 = call ptr @__remill_write_memory_32(ptr noundef %482, i64 noundef %479, i32 noundef %480) #13
  store ptr %call.i.i481, ptr %MEMORY, align 8
  br label %483

483:                                              ; preds = %475
  %484 = load i64, ptr %NEXT_PC, align 8
  store i64 %484, ptr %PC, align 8
  %485 = add i64 %484, 3
  store i64 %485, ptr %NEXT_PC, align 8
  %486 = load i64, ptr %RDI, align 8
  %487 = load ptr, ptr %MEMORY, align 8
  %call.i.i554 = call i32 @__remill_read_memory_32(ptr noundef %487, i64 noundef %486) #13
  %conv.i.i555 = sext i32 %call.i.i554 to i64
  store i64 %conv.i.i555, ptr %RDI, align 8
  store ptr %487, ptr %MEMORY, align 8
  br label %488

488:                                              ; preds = %483
  %489 = load i64, ptr %NEXT_PC, align 8
  store i64 %489, ptr %PC, align 8
  %490 = add i64 %489, 4
  store i64 %490, ptr %NEXT_PC, align 8
  %491 = load i64, ptr %RAX, align 8
  %492 = load i64, ptr %RDI, align 8
  %493 = mul i64 %492, 1
  %494 = add i64 %491, %493
  %495 = load ptr, ptr %MEMORY, align 8
  %call.i.i521 = call zeroext i8 @__remill_read_memory_8(ptr noundef %495, i64 noundef %494) #13
  %conv.i.i522 = sext i8 %call.i.i521 to i64
  %conv.i10.i = and i64 %conv.i.i522, 4294967295
  store i64 %conv.i10.i, ptr %RAX, align 8
  store ptr %495, ptr %MEMORY, align 8
  br label %496

496:                                              ; preds = %488
  %497 = load i64, ptr %NEXT_PC, align 8
  store i64 %497, ptr %PC, align 8
  %498 = add i64 %497, 3
  store i64 %498, ptr %NEXT_PC, align 8
  %499 = load i64, ptr %RSI, align 8
  %500 = load ptr, ptr %MEMORY, align 8
  %call.i.i552 = call i32 @__remill_read_memory_32(ptr noundef %500, i64 noundef %499) #13
  %conv.i.i553 = sext i32 %call.i.i552 to i64
  store i64 %conv.i.i553, ptr %RSI, align 8
  store ptr %500, ptr %MEMORY, align 8
  br label %501

501:                                              ; preds = %496
  %502 = load i64, ptr %NEXT_PC, align 8
  store i64 %502, ptr %PC, align 8
  %503 = add i64 %502, 3
  store i64 %503, ptr %NEXT_PC, align 8
  %504 = load i64, ptr %RAX, align 8
  %505 = load i64, ptr %RCX, align 8
  %506 = load i64, ptr %RSI, align 8
  %507 = mul i64 %506, 4
  %508 = add i64 %505, %507
  %509 = load ptr, ptr %MEMORY, align 8
  %conv.i.i266 = trunc i64 %504 to i32
  %call.i.i267 = call i32 @__remill_read_memory_32(ptr noundef %509, i64 noundef %508) #13
  %add.i.i268 = add i32 %call.i.i267, %conv.i.i266
  %conv.i18.i269 = zext i32 %add.i.i268 to i64
  store i64 %conv.i18.i269, ptr %RAX, align 8
  %cmp.i.i.i270 = icmp ult i32 %add.i.i268, %conv.i.i266
  %cmp1.i.i.i271 = icmp ult i32 %add.i.i268, %call.i.i267
  %510 = or i1 %cmp.i.i.i270, %cmp1.i.i.i271
  %call.i.i.i272 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %510, i32 noundef %conv.i.i266, i32 noundef %call.i.i267, i32 noundef %add.i.i268) #13
  %conv.i19.i273 = zext i1 %call.i.i.i272 to i8
  %cf.i.i274 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i273, ptr %cf.i.i274, align 1
  %conv.i.i.i.i275 = trunc i32 %add.i.i268 to i8
  %511 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i275)
  %512 = and i8 %511, 1
  %conv.i.i.i276 = xor i8 %512, 1
  %pf.i.i.i277 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i276, ptr %pf.i.i.i277, align 1
  %xor.i.i.i.i278 = xor i32 %add.i.i268, %call.i.i267
  %xor1.i.i.i.i279 = xor i32 %xor.i.i.i.i278, %conv.i.i266
  %513 = trunc i32 %xor1.i.i.i.i279 to i8
  %514 = lshr i8 %513, 4
  %conv2.i.i.i280 = and i8 %514, 1
  %af.i.i.i281 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i280, ptr %af.i.i.i281, align 1
  %cmp.i.i.i.i282 = icmp eq i32 %add.i.i268, 0
  %call.i.i.i.i283 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i282, i32 noundef %conv.i.i266, i32 noundef %call.i.i267, i32 noundef %add.i.i268) #13
  %conv5.i.i.i284 = zext i1 %call.i.i.i.i283 to i8
  %zf.i.i.i285 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i284, ptr %zf.i.i.i285, align 1
  %cmp.i27.i.i.i286 = icmp slt i32 %add.i.i268, 0
  %call1.i.i.i.i287 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i286, i32 noundef %conv.i.i266, i32 noundef %call.i.i267, i32 noundef %add.i.i268) #13
  %conv8.i.i.i288 = zext i1 %call1.i.i.i.i287 to i8
  %sf.i.i.i289 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i288, ptr %sf.i.i.i289, align 1
  %shr8.i.i.i.i290 = xor i32 %add.i.i268, %conv.i.i266
  %xor.i28.i.i.i291 = lshr i32 %shr8.i.i.i.i290, 31
  %xor3.i.i.i.i292 = lshr i32 %xor.i.i.i.i278, 31
  %add.i.i.i.i293 = add nuw nsw i32 %xor.i28.i.i.i291, %xor3.i.i.i.i292
  %cmp.i29.i.i.i294 = icmp eq i32 %add.i.i.i.i293, 2
  %call.i30.i.i.i295 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i294, i32 noundef %conv.i.i266, i32 noundef %call.i.i267, i32 noundef %add.i.i268) #13
  %conv11.i.i.i296 = zext i1 %call.i30.i.i.i295 to i8
  %of.i.i.i297 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i296, ptr %of.i.i.i297, align 1
  store ptr %509, ptr %MEMORY, align 8
  br label %515

515:                                              ; preds = %501
  %516 = load i64, ptr %NEXT_PC, align 8
  store i64 %516, ptr %PC, align 8
  %517 = add i64 %516, 3
  store i64 %517, ptr %NEXT_PC, align 8
  %518 = load i64, ptr %RDX, align 8
  %519 = load ptr, ptr %MEMORY, align 8
  %call.i.i550 = call i32 @__remill_read_memory_32(ptr noundef %519, i64 noundef %518) #13
  %conv.i.i551 = sext i32 %call.i.i550 to i64
  store i64 %conv.i.i551, ptr %RDX, align 8
  store ptr %519, ptr %MEMORY, align 8
  br label %520

520:                                              ; preds = %515
  %521 = load i64, ptr %NEXT_PC, align 8
  store i64 %521, ptr %PC, align 8
  %522 = add i64 %521, 3
  store i64 %522, ptr %NEXT_PC, align 8
  %523 = load i64, ptr %RAX, align 8
  %524 = load i64, ptr %RCX, align 8
  %525 = load i64, ptr %RDX, align 8
  %526 = mul i64 %525, 4
  %527 = add i64 %524, %526
  %528 = load ptr, ptr %MEMORY, align 8
  %conv.i.i237 = trunc i64 %523 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %528, i64 noundef %527) #13
  %add.i.i238 = add i32 %call.i.i, %conv.i.i237
  %conv.i18.i = zext i32 %add.i.i238 to i64
  store i64 %conv.i18.i, ptr %RAX, align 8
  %cmp.i.i.i239 = icmp ult i32 %add.i.i238, %conv.i.i237
  %cmp1.i.i.i240 = icmp ult i32 %add.i.i238, %call.i.i
  %529 = or i1 %cmp.i.i.i239, %cmp1.i.i.i240
  %call.i.i.i241 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %529, i32 noundef %conv.i.i237, i32 noundef %call.i.i, i32 noundef %add.i.i238) #13
  %conv.i19.i = zext i1 %call.i.i.i241 to i8
  %cf.i.i242 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i242, align 1
  %conv.i.i.i.i243 = trunc i32 %add.i.i238 to i8
  %530 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i243)
  %531 = and i8 %530, 1
  %conv.i.i.i244 = xor i8 %531, 1
  %pf.i.i.i245 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i244, ptr %pf.i.i.i245, align 1
  %xor.i.i.i.i246 = xor i32 %add.i.i238, %call.i.i
  %xor1.i.i.i.i247 = xor i32 %xor.i.i.i.i246, %conv.i.i237
  %532 = trunc i32 %xor1.i.i.i.i247 to i8
  %533 = lshr i8 %532, 4
  %conv2.i.i.i248 = and i8 %533, 1
  %af.i.i.i249 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i248, ptr %af.i.i.i249, align 1
  %cmp.i.i.i.i250 = icmp eq i32 %add.i.i238, 0
  %call.i.i.i.i251 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i250, i32 noundef %conv.i.i237, i32 noundef %call.i.i, i32 noundef %add.i.i238) #13
  %conv5.i.i.i252 = zext i1 %call.i.i.i.i251 to i8
  %zf.i.i.i253 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i252, ptr %zf.i.i.i253, align 1
  %cmp.i27.i.i.i254 = icmp slt i32 %add.i.i238, 0
  %call1.i.i.i.i255 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i254, i32 noundef %conv.i.i237, i32 noundef %call.i.i, i32 noundef %add.i.i238) #13
  %conv8.i.i.i256 = zext i1 %call1.i.i.i.i255 to i8
  %sf.i.i.i257 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i256, ptr %sf.i.i.i257, align 1
  %shr8.i.i.i.i258 = xor i32 %add.i.i238, %conv.i.i237
  %xor.i28.i.i.i259 = lshr i32 %shr8.i.i.i.i258, 31
  %xor3.i.i.i.i260 = lshr i32 %xor.i.i.i.i246, 31
  %add.i.i.i.i261 = add nuw nsw i32 %xor.i28.i.i.i259, %xor3.i.i.i.i260
  %cmp.i29.i.i.i262 = icmp eq i32 %add.i.i.i.i261, 2
  %call.i30.i.i.i263 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i262, i32 noundef %conv.i.i237, i32 noundef %call.i.i, i32 noundef %add.i.i238) #13
  %conv11.i.i.i264 = zext i1 %call.i30.i.i.i263 to i8
  %of.i.i.i265 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i264, ptr %of.i.i.i265, align 1
  store ptr %528, ptr %MEMORY, align 8
  br label %534

534:                                              ; preds = %520
  %535 = load i64, ptr %NEXT_PC, align 8
  store i64 %535, ptr %PC, align 8
  %536 = add i64 %535, 3
  store i64 %536, ptr %NEXT_PC, align 8
  %537 = load i64, ptr %RBP, align 8
  %538 = sub i64 %537, 32
  %539 = load i32, ptr %EAX, align 4
  %540 = zext i32 %539 to i64
  %541 = load ptr, ptr %MEMORY, align 8
  %call.i.i480 = call ptr @__remill_write_memory_32(ptr noundef %541, i64 noundef %538, i32 noundef %539) #13
  store ptr %call.i.i480, ptr %MEMORY, align 8
  br label %542

542:                                              ; preds = %534
  %543 = load i64, ptr %NEXT_PC, align 8
  store i64 %543, ptr %PC, align 8
  %544 = add i64 %543, 7
  store i64 %544, ptr %NEXT_PC, align 8
  %545 = load i64, ptr %NEXT_PC, align 8
  %546 = add i64 %545, 11653
  %547 = load ptr, ptr %MEMORY, align 8
  %call.i.i516 = call i64 @__remill_read_memory_64(ptr noundef %547, i64 noundef %546) #13
  store i64 %call.i.i516, ptr %RAX, align 8
  store ptr %547, ptr %MEMORY, align 8
  br label %548

548:                                              ; preds = %542
  %549 = load i64, ptr %NEXT_PC, align 8
  store i64 %549, ptr %PC, align 8
  %550 = add i64 %549, 2
  store i64 %550, ptr %NEXT_PC, align 8
  %551 = load i64, ptr %RAX, align 8
  %552 = load ptr, ptr %MEMORY, align 8
  %call.i.i495 = call i32 @__remill_read_memory_32(ptr noundef %552, i64 noundef %551) #13
  %conv.i.i496 = zext i32 %call.i.i495 to i64
  store i64 %conv.i.i496, ptr %RDX, align 8
  store ptr %552, ptr %MEMORY, align 8
  br label %553

553:                                              ; preds = %548
  %554 = load i64, ptr %NEXT_PC, align 8
  store i64 %554, ptr %PC, align 8
  %555 = add i64 %554, 7
  store i64 %555, ptr %NEXT_PC, align 8
  %556 = load i64, ptr %NEXT_PC, align 8
  %557 = add i64 %556, 11620
  %558 = load ptr, ptr %MEMORY, align 8
  %call.i.i515 = call i64 @__remill_read_memory_64(ptr noundef %558, i64 noundef %557) #13
  store i64 %call.i.i515, ptr %RAX, align 8
  store ptr %558, ptr %MEMORY, align 8
  br label %559

559:                                              ; preds = %553
  %560 = load i64, ptr %NEXT_PC, align 8
  store i64 %560, ptr %PC, align 8
  %561 = add i64 %560, 3
  store i64 %561, ptr %NEXT_PC, align 8
  %562 = load i64, ptr %RAX, align 8
  %563 = load ptr, ptr %MEMORY, align 8
  %call.i.i426 = call i32 @__remill_read_memory_32(ptr noundef %563, i64 noundef %562) #13
  %sub.i.i = sub i32 %call.i.i426, 10
  %cmp.i.i.i427 = icmp ult i32 %call.i.i426, 10
  %call.i.i.i428 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i427, i32 noundef %call.i.i426, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv.i9.i = zext i1 %call.i.i.i428 to i8
  %cf.i.i429 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i429, align 1
  %conv.i.i.i.i430 = trunc i32 %sub.i.i to i8
  %564 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i430)
  %565 = and i8 %564, 1
  %conv.i.i.i431 = xor i8 %565, 1
  %pf.i.i.i432 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i431, ptr %pf.i.i.i432, align 1
  %xor.i.i.i.i433 = xor i32 %call.i.i426, 10
  %xor1.i.i.i.i434 = xor i32 %xor.i.i.i.i433, %sub.i.i
  %566 = trunc i32 %xor1.i.i.i.i434 to i8
  %567 = lshr i8 %566, 4
  %conv2.i.i.i435 = and i8 %567, 1
  %af.i.i.i436 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i435, ptr %af.i.i.i436, align 1
  %cmp.i.i.i.i437 = icmp eq i32 %call.i.i426, 10
  %call.i.i.i.i438 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i437, i32 noundef %call.i.i426, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv5.i.i.i439 = zext i1 %call.i.i.i.i438 to i8
  %zf.i.i.i440 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i439, ptr %zf.i.i.i440, align 1
  %cmp.i27.i.i.i441 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i442 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i441, i32 noundef %call.i.i426, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv8.i.i.i443 = zext i1 %call1.i.i.i.i442 to i8
  %sf.i.i.i444 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i443, ptr %sf.i.i.i444, align 1
  %xor.i28.i.i.i445 = lshr i32 %xor.i.i.i.i433, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i426
  %xor3.i.i.i.i446 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i447 = add nuw nsw i32 %xor3.i.i.i.i446, %xor.i28.i.i.i445
  %cmp.i29.i.i.i448 = icmp eq i32 %add.i.i.i.i447, 2
  %call.i30.i.i.i449 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i448, i32 noundef %call.i.i426, i32 noundef 10, i32 noundef %sub.i.i) #13
  %conv11.i.i.i450 = zext i1 %call.i30.i.i.i449 to i8
  %of.i.i.i451 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i450, ptr %of.i.i.i451, align 1
  store ptr %563, ptr %MEMORY, align 8
  br label %568

568:                                              ; preds = %559
  %569 = load i64, ptr %NEXT_PC, align 8
  store i64 %569, ptr %PC, align 8
  %570 = add i64 %569, 3
  store i64 %570, ptr %NEXT_PC, align 8
  %571 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  %572 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %572, 0
  %of.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  %573 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %573, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %571, ptr %MEMORY, align 8
  br label %574

574:                                              ; preds = %568
  %575 = load i64, ptr %NEXT_PC, align 8
  store i64 %575, ptr %PC, align 8
  %576 = add i64 %575, 2
  store i64 %576, ptr %NEXT_PC, align 8
  %577 = load i32, ptr %EDX, align 4
  %578 = zext i32 %577 to i64
  %579 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %578, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %579, ptr %MEMORY, align 8
  br label %580

580:                                              ; preds = %574
  %581 = load i64, ptr %NEXT_PC, align 8
  store i64 %581, ptr %PC, align 8
  %582 = add i64 %581, 3
  store i64 %582, ptr %NEXT_PC, align 8
  %583 = load i64, ptr %RCX, align 8
  %584 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %583 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %585 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %585, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %586 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %587 = and i8 %586, 1
  %conv.i.i.i = xor i8 %587, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %588 = trunc i32 %xor1.i.i.i.i to i8
  %589 = lshr i8 %588, 4
  %conv2.i.i.i = and i8 %589, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #13
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %584, ptr %MEMORY, align 8
  br label %590

590:                                              ; preds = %580
  %591 = load i64, ptr %NEXT_PC, align 8
  store i64 %591, ptr %PC, align 8
  %592 = add i64 %591, 3
  store i64 %592, ptr %NEXT_PC, align 8
  %593 = load i64, ptr %RCX, align 8
  %594 = load i32, ptr %EDX, align 4
  %595 = zext i32 %594 to i64
  %596 = load ptr, ptr %MEMORY, align 8
  %conv.i.i470 = trunc i64 %593 to i32
  %sext.i = shl i64 %593, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %595, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %597 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i471 = icmp ult i64 %597, -4294967296
  %call.i.i.i472 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i471, i32 noundef %conv.i.i470, i32 noundef %594, i64 noundef %mul.i.i) #13
  %frombool.i.i = zext i1 %call.i.i.i472 to i8
  %cf.i.i473 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i473, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #13
  %pf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %596, ptr %MEMORY, align 8
  br label %598

598:                                              ; preds = %590
  %599 = load i64, ptr %NEXT_PC, align 8
  store i64 %599, ptr %PC, align 8
  %600 = add i64 %599, 3
  store i64 %600, ptr %NEXT_PC, align 8
  %601 = load i64, ptr %RCX, align 8
  %602 = load ptr, ptr %MEMORY, align 8
  %conv.i.i562 = trunc i64 %601 to i32
  %and3.i.i = and i32 1, %conv.i.i562
  %conv.i22.i563 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i563, ptr %RCX, align 8
  %cf.i.i564 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i564, align 1
  %conv.i.i.i565 = trunc i32 %and3.i.i to i8
  %603 = and i8 %conv.i.i.i565, 1
  %conv.i23.i566 = xor i8 %603, 1
  %pf.i.i567 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i566, ptr %pf.i.i567, align 1
  %cmp.i.i.i568 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i569 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i568, i32 noundef %conv.i.i562, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv3.i.i = zext i1 %call.i.i.i569 to i8
  %zf.i.i570 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i570, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i562, i32 noundef 1, i32 noundef %and3.i.i) #13
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i571 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i571, align 1
  %of.i.i572 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i572, align 1
  %af.i.i573 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i573, align 1
  store ptr %602, ptr %MEMORY, align 8
  br label %604

604:                                              ; preds = %598
  %605 = load i64, ptr %NEXT_PC, align 8
  store i64 %605, ptr %PC, align 8
  %606 = add i64 %605, 3
  store i64 %606, ptr %NEXT_PC, align 8
  %607 = load i32, ptr %ECX, align 4
  %608 = zext i32 %607 to i64
  %609 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i452 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %607, i32 noundef 0, i32 noundef %607) #13
  %conv.i12.i = zext i1 %call.i.i.i452 to i8
  %cf.i.i453 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i453, align 1
  %conv.i.i.i.i454 = trunc i32 %607 to i8
  %610 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i454)
  %611 = and i8 %610, 1
  %conv.i.i.i455 = xor i8 %611, 1
  %pf.i.i.i456 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i455, ptr %pf.i.i.i456, align 1
  %af.i.i.i457 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i457, align 1
  %cmp.i.i.i.i458 = icmp eq i32 %607, 0
  %call.i.i.i.i459 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i458, i32 noundef %607, i32 noundef 0, i32 noundef %607) #13
  %conv5.i.i.i460 = zext i1 %call.i.i.i.i459 to i8
  %zf.i.i.i461 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i460, ptr %zf.i.i.i461, align 1
  %cmp.i27.i.i.i462 = icmp slt i32 %607, 0
  %call1.i.i.i.i463 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i462, i32 noundef %607, i32 noundef 0, i32 noundef %607) #13
  %conv8.i.i.i464 = zext i1 %call1.i.i.i.i463 to i8
  %sf.i.i.i465 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i464, ptr %sf.i.i.i465, align 1
  %xor.i28.i.i.i466 = lshr i32 %607, 31
  %call.i30.i.i.i467 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %607, i32 noundef 0, i32 noundef %607) #13
  %conv11.i.i.i468 = zext i1 %call.i30.i.i.i467 to i8
  %of.i.i.i469 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i468, ptr %of.i.i.i469, align 1
  store ptr %609, ptr %MEMORY, align 8
  br label %612

612:                                              ; preds = %604
  %613 = load i64, ptr %NEXT_PC, align 8
  store i64 %613, ptr %PC, align 8
  %614 = add i64 %613, 3
  store i64 %614, ptr %NEXT_PC, align 8
  %615 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  %616 = load i8, ptr %zf.i, align 1
  store i8 %616, ptr %CL, align 1
  store ptr %615, ptr %MEMORY, align 8
  br label %617

617:                                              ; preds = %612
  %618 = load i64, ptr %NEXT_PC, align 8
  store i64 %618, ptr %PC, align 8
  %619 = add i64 %618, 2
  store i64 %619, ptr %NEXT_PC, align 8
  %620 = load i8, ptr %AL, align 1
  %621 = zext i8 %620 to i64
  %622 = load i8, ptr %CL, align 1
  %623 = zext i8 %622 to i64
  %624 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %623, %621
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i574 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i574, align 1
  %625 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %626 = and i8 %625, 1
  %conv.i27.i = xor i8 %626, 1
  %pf.i.i575 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i575, align 1
  %627 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i576 = and i32 %627, 255
  %cmp.i.i.i577 = icmp eq i8 %or3.i.i, 0
  %628 = trunc i64 %621 to i32
  %conv1.i.i.i = and i32 %628, 255
  %629 = trunc i64 %623 to i32
  %conv2.i.i.i578 = and i32 %629, 255
  %call.i.i.i579 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i577, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i578, i32 noundef %conv.i.i.i576) #13
  %conv3.i.i580 = zext i1 %call.i.i.i579 to i8
  %zf.i.i581 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i580, ptr %zf.i.i581, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i578, i32 noundef %conv.i.i.i576) #13
  %conv6.i.i582 = zext i1 %call4.i.i.i to i8
  %sf.i.i583 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i582, ptr %sf.i.i583, align 1
  %of.i.i584 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i584, align 1
  %af.i.i585 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call16.i, ptr %af.i.i585, align 1
  store ptr %624, ptr %MEMORY, align 8
  br label %630

630:                                              ; preds = %617
  %631 = load i64, ptr %NEXT_PC, align 8
  store i64 %631, ptr %PC, align 8
  %632 = add i64 %631, 2
  store i64 %632, ptr %NEXT_PC, align 8
  %633 = load i8, ptr %AL, align 1
  %634 = zext i8 %633 to i64
  %635 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %634
  %and3.i.i586 = trunc i64 %and3.i15.i to i8
  %cf.i.i587 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i587, align 1
  %636 = and i8 %and3.i.i586, 1
  %conv.i14.i = xor i8 %636, 1
  %pf.i.i588 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i588, align 1
  %637 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i589 = and i32 %637, 255
  %cmp.i.i.i590 = icmp eq i8 %and3.i.i586, 0
  %638 = trunc i64 %634 to i32
  %conv1.i.i.i591 = and i32 %638, 255
  %call.i.i.i592 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i590, i32 noundef %conv1.i.i.i591, i32 noundef 1, i32 noundef %conv.i.i.i589) #13
  %conv3.i.i593 = zext i1 %call.i.i.i592 to i8
  %zf.i.i594 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i593, ptr %zf.i.i594, align 1
  %call4.i.i.i595 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i591, i32 noundef 1, i32 noundef %conv.i.i.i589) #13
  %conv6.i.i596 = zext i1 %call4.i.i.i595 to i8
  %sf.i.i597 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i596, ptr %sf.i.i597, align 1
  %of.i.i598 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i598, align 1
  %af.i.i599 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #14
  store i8 %call7.i, ptr %af.i.i599, align 1
  store ptr %635, ptr %MEMORY, align 8
  br label %639

639:                                              ; preds = %630
  %640 = load i64, ptr %NEXT_PC, align 8
  store i64 %640, ptr %PC, align 8
  %641 = add i64 %640, 6
  store i64 %641, ptr %NEXT_PC, align 8
  %642 = load i64, ptr %NEXT_PC, align 8
  %643 = add i64 %642, 5
  %644 = load i64, ptr %NEXT_PC, align 8
  %645 = load ptr, ptr %MEMORY, align 8
  %zf.i474 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 2, i32 7
  %646 = load i8, ptr %zf.i474, align 1
  %tobool.not.i = icmp eq i8 %646, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #14
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %643, i64 %644
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %645, ptr %MEMORY, align 8
  %647 = load i64, ptr %NEXT_PC, align 8
  store i64 %647, ptr %PC, align 8
  %648 = load ptr, ptr %MEMORY, align 8
  ret ptr %648
}

define ptr @BB_1292(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 3, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.4685, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #13
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 8
  %12 = load ptr, ptr %MEMORY, align 8
  store i64 %11, ptr %RSP, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 1
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %rsp.i5 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  %17 = load i64, ptr %rsp.i5, align 8
  %add.i.i6 = add i64 %17, 8
  store i64 %add.i.i6, ptr %rsp.i5, align 8
  %call.i.i7 = call i64 @__remill_read_memory_64(ptr noundef %16, i64 noundef %17) #13
  store i64 %call.i.i7, ptr %RBX, align 8
  store ptr %16, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 1
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  %22 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %22, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %21, i64 noundef %22) #13
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %21, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 1
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  %27 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %27) #13
  %rip.i = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %28, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %26, ptr %MEMORY, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  ret ptr %29
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #2 {
entry:
  %agg.tmp = alloca %struct.State.4685, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.4685) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #15
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #3

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.4685) align 16, i64 noundef, ptr noundef) local_unnamed_addr #4

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rip = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rax = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #5 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !5
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rax = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #6 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !5
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #7 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4352, label %bb_1100
    i64 4428, label %bb_114C
    i64 4754, label %bb_1292
  ]

dead_end:                                         ; preds = %bb_114C, %bb_1100, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1100:                                          ; preds = %entry
  %block_pc = add i64 4352, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4352, ptr %1)
  %4 = call ptr @BB_1100(ptr %state, i64 %2, ptr %1) #16
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4428, label %bb_114C
  ]

bb_114C:                                          ; preds = %bb_1100, %entry
  %block_pc1 = add i64 4428, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4428, ptr %6)
  %9 = call ptr @BB_114c(ptr %state, i64 %7, ptr %6) #16
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4754, label %bb_1292
  ]

bb_1292:                                          ; preds = %bb_114C, %entry
  %block_pc3 = add i64 4754, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4754, ptr %11)
  %14 = call ptr @BB_1292(ptr %state, i64 %12, ptr %11) #16
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  %16 = load ptr, ptr %mem_var, align 8
  ret ptr %16

return_bb:                                        ; No predecessors!
  %17 = load ptr, ptr %mem_var, align 8
  ret ptr %17
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #8 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4352, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #9 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #9 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #9 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #9 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #9 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #10 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #6 {
entry:
  %rip = getelementptr inbounds %struct.X86State.4684, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !5
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #11 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #12 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #3 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #4 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #8 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #14 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #15 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #16 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6, !6, i64 0}
!6 = !{!"omnipotent char", !7, i64 0}
!7 = !{!"Simple C++ TBAA"}
