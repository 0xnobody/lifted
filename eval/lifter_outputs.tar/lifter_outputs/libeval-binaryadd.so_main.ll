; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.18764 = type { %struct.X86State.18763 }
%struct.X86State.18763 = type { %struct.ArchState.18732, [32 x %union.VectorReg.18735], %struct.ArithFlags.18736, %union.anon.18731, %struct.Segments.18738, %struct.AddressSpace.18740, %struct.GPR.18741, %struct.X87Stack.18744, %struct.MMX.18748, %struct.FPUStatusFlags.18749, %union.anon.18731, %union.FPU.18758, %struct.SegmentCaches.18760, %struct.K_REG.18762 }
%struct.ArchState.18732 = type { i32, i32, %union.anon.18731 }
%union.VectorReg.18735 = type { %union.vec512_t.18734 }
%union.vec512_t.18734 = type { %struct.uint64v8_t.18733 }
%struct.uint64v8_t.18733 = type { [8 x i64] }
%struct.ArithFlags.18736 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.18738 = type { i16, %union.SegmentSelector.18737, i16, %union.SegmentSelector.18737, i16, %union.SegmentSelector.18737, i16, %union.SegmentSelector.18737, i16, %union.SegmentSelector.18737, i16, %union.SegmentSelector.18737 }
%union.SegmentSelector.18737 = type { i16 }
%struct.AddressSpace.18740 = type { i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739 }
%struct.Reg.18739 = type { %union.anon.18731 }
%struct.GPR.18741 = type { i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739, i64, %struct.Reg.18739 }
%struct.X87Stack.18744 = type { [8 x %struct.anon.3.18743] }
%struct.anon.3.18743 = type { [6 x i8], %struct.float80_t.18742 }
%struct.float80_t.18742 = type { [10 x i8] }
%struct.MMX.18748 = type { [8 x %struct.anon.4.18747] }
%struct.anon.4.18747 = type { i64, %union.vec64_t.18746 }
%union.vec64_t.18746 = type { %struct.uint64v1_t.18745 }
%struct.uint64v1_t.18745 = type { [1 x i64] }
%struct.FPUStatusFlags.18749 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.18731 = type { i64 }
%union.FPU.18758 = type { %struct.anon.13.18757 }
%struct.anon.13.18757 = type { %struct.FpuFXSAVE.18756, [96 x i8] }
%struct.FpuFXSAVE.18756 = type { %union.SegmentSelector.18737, %union.SegmentSelector.18737, %union.FPUAbridgedTagWord.18750, i8, i16, i32, %union.SegmentSelector.18737, i16, i32, %union.SegmentSelector.18737, i16, %union.FPUControlStatus.18751, %union.FPUControlStatus.18751, [8 x %struct.FPUStackElem.18753], [16 x %union.vec128_t.18755] }
%union.FPUAbridgedTagWord.18750 = type { i8 }
%union.FPUControlStatus.18751 = type { i32 }
%struct.FPUStackElem.18753 = type { %union.anon.11.18752, [6 x i8] }
%union.anon.11.18752 = type { %struct.float80_t.18742 }
%union.vec128_t.18755 = type { %struct.uint128v1_t.18754 }
%struct.uint128v1_t.18754 = type { [1 x i128] }
%struct.SegmentCaches.18760 = type { %struct.SegmentShadow.18759, %struct.SegmentShadow.18759, %struct.SegmentShadow.18759, %struct.SegmentShadow.18759, %struct.SegmentShadow.18759, %struct.SegmentShadow.18759 }
%struct.SegmentShadow.18759 = type { %union.anon.18731, i32, i32 }
%struct.K_REG.18762 = type { [8 x %struct.anon.18.18761] }
%struct.anon.18.18761 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1139(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i32, ptr %EDX, align 4
  %5 = zext i32 %4 to i64
  %6 = load i32, ptr %EDI, align 4
  %7 = zext i32 %6 to i64
  %8 = load ptr, ptr %MEMORY, align 8
  store ptr %8, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 1
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %RBP, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %14 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %14, -8
  %call.i.i.i28 = call ptr @__remill_write_memory_64(ptr noundef %13, i64 noundef %sub.i.i.i, i64 noundef %12) #16
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i28, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %9
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 3
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load i64, ptr %RSP, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  store i64 %18, ptr %RBP, align 8
  store ptr %19, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 4
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %RSP, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 -128, %23
  store i64 %add.i.i, ptr %RSP, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %23
  %cmp1.i.i.i = icmp ult i64 %add.i.i, -128
  %25 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %25, i64 noundef %23, i64 noundef -128, i64 noundef %add.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %26 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %27 = and i8 %26, 1
  %conv.i.i.i = xor i8 %27, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, -128
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %23
  %28 = trunc i64 %xor1.i.i.i.i to i8
  %29 = lshr i8 %28, 4
  %conv2.i.i.i = and i8 %29, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %23, i64 noundef -128, i64 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %23, i64 noundef -128, i64 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %23
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %23, i64 noundef -128, i64 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %24, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %20
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 3
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RBP, align 8
  %34 = sub i64 %33, 116
  %35 = load i32, ptr %EDI, align 4
  %36 = zext i32 %35 to i64
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i26 = call ptr @__remill_write_memory_32(ptr noundef %37, i64 noundef %34, i32 noundef %35) #16
  store ptr %call.i.i26, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %30
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 4
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RBP, align 8
  %42 = sub i64 %41, 128
  %43 = load i64, ptr %RSI, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  %call.i.i27 = call ptr @__remill_write_memory_64(ptr noundef %44, i64 noundef %42, i64 noundef %43) #16
  store ptr %call.i.i27, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %38
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 4
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RBP, align 8
  %49 = sub i64 %48, 116
  %50 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %50, i64 noundef %49) #16
  %sub.i.i = sub i32 %call.i.i, 2
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 2
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %52 = and i8 %51, 1
  %conv.i.i.i5 = xor i8 %52, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 2
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %53 = trunc i32 %xor1.i.i.i.i8 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i9 = and i8 %54, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 2
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 2, i32 noundef %sub.i.i) #16
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %45
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %NEXT_PC, align 8
  %59 = add i64 %58, 10
  %60 = load i64, ptr %NEXT_PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %62 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %62, 0
  %sf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %63 = load i8, ptr %sf.i, align 1
  %tobool10.i = icmp eq i8 %63, 0
  %of.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %64 = load i8, ptr %of.i, align 1
  %tobool12.i = icmp ne i8 %64, 0
  %cmp.i.i = xor i1 %tobool10.i, %tobool12.i
  %65 = and i1 %tobool.not.i, %cmp.i.i
  %call15.i = call zeroext i1 @__remill_compare_sgt(i1 noundef zeroext %65) #17
  %frombool.i = zext i1 %call15.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call15.i, i64 %59, i64 %60
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %61, ptr %MEMORY, align 8
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = load ptr, ptr %MEMORY, align 8
  ret ptr %67
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_115c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i30 = call ptr @__remill_write_memory_32(ptr noundef %6, i64 noundef %5, i32 noundef 0) #16
  store ptr %call.i.i30, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 7
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 24
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %12, i64 noundef %11, i32 noundef 0) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 128
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i36 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #16
  store i64 %call.i.i36, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 8, %22
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %22
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, 8
  %24 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %24, i64 noundef %22, i64 noundef 8, i64 noundef %add.i.i1) #16
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %26 = and i8 %25, 1
  %conv.i.i.i8 = xor i8 %26, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, 8
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %22
  %27 = trunc i64 %xor1.i.i.i.i11 to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i12 = and i8 %28, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %22, i64 noundef 8, i64 noundef %add.i.i1) #16
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %22, i64 noundef 8, i64 noundef %add.i.i1) #16
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %22
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %22, i64 noundef 8, i64 noundef %add.i.i1) #16
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %19
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %call.i.i35 = call i64 @__remill_read_memory_64(ptr noundef %33, i64 noundef %32) #16
  store i64 %call.i.i35, ptr %RAX, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %29
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 3
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load i64, ptr %RAX, align 8
  %38 = load ptr, ptr %MEMORY, align 8
  %call.i.i39 = call zeroext i8 @__remill_read_memory_8(ptr noundef %38, i64 noundef %37) #16
  %conv.i.i40 = zext i8 %call.i.i39 to i64
  store i64 %conv.i.i40, ptr %RAX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %34
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 4
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i8, ptr %AL, align 1
  %43 = zext i8 %42 to i64
  %44 = load ptr, ptr %MEMORY, align 8
  %sext.i41 = shl i64 %43, 56
  %conv.i12.i42 = ashr exact i64 %sext.i41, 56
  store i64 %conv.i12.i42, ptr %RAX, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %39
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 4
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RBP, align 8
  %49 = sub i64 %48, 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %call.i.i32 = call ptr @__remill_write_memory_64(ptr noundef %51, i64 noundef %49, i64 noundef %50) #16
  store ptr %call.i.i32, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %45
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 4
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RBP, align 8
  %56 = sub i64 %55, 128
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i34 = call i64 @__remill_read_memory_64(ptr noundef %57, i64 noundef %56) #16
  store i64 %call.i.i34, ptr %RAX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 4
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RAX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 16, %61
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %61
  %cmp1.i.i.i = icmp ult i64 %add.i.i, 16
  %63 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %63, i64 noundef %61, i64 noundef 16, i64 noundef %add.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %64 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %65 = and i8 %64, 1
  %conv.i.i.i = xor i8 %65, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, 16
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %61
  %66 = trunc i64 %xor1.i.i.i.i to i8
  %67 = lshr i8 %66, 4
  %conv2.i.i.i = and i8 %67, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %61, i64 noundef 16, i64 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %61, i64 noundef 16, i64 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %61
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %61, i64 noundef 16, i64 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RAX, align 8
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i33 = call i64 @__remill_read_memory_64(ptr noundef %72, i64 noundef %71) #16
  store i64 %call.i.i33, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %68
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i37 = call zeroext i8 @__remill_read_memory_8(ptr noundef %77, i64 noundef %76) #16
  %conv.i.i38 = zext i8 %call.i.i37 to i64
  store i64 %conv.i.i38, ptr %RAX, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %73
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 4
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i8, ptr %AL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %sext.i = shl i64 %82, 56
  %conv.i12.i = ashr exact i64 %sext.i, 56
  store i64 %conv.i12.i, ptr %RAX, align 8
  store ptr %83, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %78
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 4
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RBP, align 8
  %88 = sub i64 %87, 16
  %89 = load i64, ptr %RAX, align 8
  %90 = load ptr, ptr %MEMORY, align 8
  %call.i.i31 = call ptr @__remill_write_memory_64(ptr noundef %90, i64 noundef %88, i64 noundef %89) #16
  store ptr %call.i.i31, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %84
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 5
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i64, ptr %NEXT_PC, align 8
  %95 = add i64 %94, 391
  %96 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %95, ptr %rip.i, align 8
  store i64 %95, ptr %NEXT_PC, align 8
  store ptr %96, ptr %MEMORY, align 8
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  ret ptr %98
}

define ptr @BB_1152(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 5
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = add i64 %8, 584
  %10 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store ptr %10, ptr %MEMORY, align 8
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1322(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %call.i.i, 63
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 6
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 402
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_13a4(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  %rbp.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 15
  %5 = load i64, ptr %rbp.i, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %4, i64 noundef %5) #16
  store i64 %call.i.i1, ptr %rbp.i, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %add.i.i3 = add i64 %5, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %6

6:                                                ; preds = %1
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = add i64 %7, 1
  store i64 %8, ptr %NEXT_PC, align 8
  %9 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %10 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %9, i64 noundef %10) #16
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %11 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %11, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %9, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_119b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i836 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  store i64 %call.i.i836, ptr %RCX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 10
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i64 7378697629483820647, ptr %RDX, align 8
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 3
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load i64, ptr %RCX, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  store i64 %14, ptr %RAX, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %11
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 3
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %RDX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rax.i788 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %21 = load i64, ptr %rax.i788, align 8
  %22 = ashr i64 %21, 63
  %23 = ashr i64 %19, 63
  %L.sroa.2.0.insert.ext.i.i789 = zext i64 %22 to i128
  %L.sroa.2.0.insert.shift.i.i790 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i789, 64
  %L.sroa.0.0.insert.ext.i.i791 = zext i64 %21 to i128
  %L.sroa.0.0.insert.insert.i.i792 = or i128 %L.sroa.2.0.insert.shift.i.i790, %L.sroa.0.0.insert.ext.i.i791
  %R.sroa.2.0.insert.ext.i.i793 = zext i64 %23 to i128
  %R.sroa.2.0.insert.shift.i.i794 = shl nuw i128 %R.sroa.2.0.insert.ext.i.i793, 64
  %R.sroa.0.0.insert.ext.i.i795 = zext i64 %19 to i128
  %R.sroa.0.0.insert.insert.i.i796 = or i128 %R.sroa.2.0.insert.shift.i.i794, %R.sroa.0.0.insert.ext.i.i795
  %mul.i.i797 = mul nsw i128 %L.sroa.0.0.insert.insert.i.i792, %R.sroa.0.0.insert.insert.i.i796
  %retval.sroa.0.0.extract.trunc.i.i798 = trunc i128 %mul.i.i797 to i64
  %retval.sroa.2.0.extract.shift.i.i799 = lshr i128 %mul.i.i797, 64
  %retval.sroa.2.0.extract.trunc.i.i800 = trunc i128 %retval.sroa.2.0.extract.shift.i.i799 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i798, ptr %rax.i788, align 8
  %rdx.i801 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %retval.sroa.2.0.extract.trunc.i.i800, ptr %rdx.i801, align 8
  %conv2.i.i.i802 = sext i64 %retval.sroa.0.0.extract.trunc.i.i798 to i128
  %cmp.i.i.i803 = icmp ne i128 %mul.i.i797, %conv2.i.i.i802
  %call.i.i.i804 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i803, i64 noundef %21, i64 noundef %19, i64 noundef %retval.sroa.0.0.extract.trunc.i.i798, i64 noundef %retval.sroa.2.0.extract.trunc.i.i800) #16
  %frombool.i.i805 = zext i1 %call.i.i.i804 to i8
  %cf.i.i806 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i805, ptr %cf.i.i806, align 1
  %call2.i.i807 = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i808 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i807, ptr %pf.i.i808, align 1
  %af.i.i809 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i807, ptr %af.i.i809, align 1
  %zf.i.i810 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i807, ptr %zf.i.i810, align 1
  %sf.i.i811 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i807, ptr %sf.i.i811, align 1
  %of.i.i812 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i805, ptr %of.i.i812, align 1
  store ptr %20, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %16
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RDX, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  store i64 %27, ptr %RAX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i1059 = ashr i64 %32, 1
  %call36.i1060 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i1061 = icmp ne i8 %call36.i1060, 0
  %34 = zext i1 %tobool.i1061 to i8
  %new_val.0.i1062 = ashr i64 %shr.i152.i1059, 1
  store i64 %new_val.0.i1062, ptr %RAX, align 8
  %cf.i1063 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %35 = trunc i64 %shr.i152.i1059 to i8
  %conv.i1064 = and i8 %35, 1
  store i8 %conv.i1064, ptr %cf.i1063, align 1
  %pf.i1065 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1066 = trunc i64 %new_val.0.i1062 to i8
  %36 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1066)
  %37 = and i8 %36, 1
  %conv75.i1067 = xor i8 %37, 1
  store i8 %conv75.i1067, ptr %pf.i1065, align 1
  %af.i1068 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1060, ptr %af.i1068, align 1
  %zf.i1069 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1070 = icmp ult i64 %shr.i152.i1059, 2
  %conv88.i1071 = zext i1 %cmp.i157.i1070 to i8
  store i8 %conv88.i1071, ptr %zf.i1069, align 1
  %sf.i1072 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i1073 = lshr i64 %shr.i152.i1059, 63
  %conv95.i1074 = trunc i64 %new_val.0.in.lobit.i1073 to i8
  store i8 %conv95.i1074, ptr %sf.i1072, align 1
  %of.i1075 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %34, ptr %of.i1075, align 1
  store ptr %33, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %29
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RCX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  store i64 %41, ptr %RDX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %38
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RDX, align 8
  %47 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i1042 = ashr i64 %46, 62
  %call36.i1043 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i1044 = icmp ne i8 %call36.i1043, 0
  %48 = zext i1 %tobool.i1044 to i8
  %new_val.0.i1045 = ashr i64 %shr.i152.i1042, 1
  store i64 %new_val.0.i1045, ptr %RDX, align 8
  %cf.i1046 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %49 = trunc i64 %shr.i152.i1042 to i8
  %conv.i1047 = and i8 %49, 1
  store i8 %conv.i1047, ptr %cf.i1046, align 1
  %pf.i1048 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1049 = trunc i64 %new_val.0.i1045 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1049)
  %51 = and i8 %50, 1
  %conv75.i1050 = xor i8 %51, 1
  store i8 %conv75.i1050, ptr %pf.i1048, align 1
  %af.i1051 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1043, ptr %af.i1051, align 1
  %zf.i1052 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1053 = icmp ult i64 %shr.i152.i1042, 2
  %conv88.i1054 = zext i1 %cmp.i157.i1053 to i8
  store i8 %conv88.i1054, ptr %zf.i1052, align 1
  %sf.i1055 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i1056 = lshr i64 %shr.i152.i1042, 63
  %conv95.i1057 = trunc i64 %new_val.0.in.lobit.i1056 to i8
  store i8 %conv95.i1057, ptr %sf.i1055, align 1
  %of.i1058 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %48, ptr %of.i1058, align 1
  store ptr %47, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %43
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i64, ptr %RAX, align 8
  %56 = load i64, ptr %RDX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %sub.i.i656 = sub i64 %55, %56
  store i64 %sub.i.i656, ptr %RAX, align 8
  %cmp.i.i.i657 = icmp ult i64 %55, %56
  %call.i.i.i658 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i657, i64 noundef %55, i64 noundef %56, i64 noundef %sub.i.i656) #16
  %conv.i.i659 = zext i1 %call.i.i.i658 to i8
  %cf.i.i660 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i659, ptr %cf.i.i660, align 1
  %conv.i.i.i.i661 = trunc i64 %sub.i.i656 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i661)
  %59 = and i8 %58, 1
  %conv.i.i.i662 = xor i8 %59, 1
  %pf.i.i.i663 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i662, ptr %pf.i.i.i663, align 1
  %xor.i.i.i.i664 = xor i64 %56, %55
  %xor1.i.i.i.i665 = xor i64 %xor.i.i.i.i664, %sub.i.i656
  %60 = trunc i64 %xor1.i.i.i.i665 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i666 = and i8 %61, 1
  %af.i.i.i667 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i666, ptr %af.i.i.i667, align 1
  %cmp.i.i.i.i668 = icmp eq i64 %55, %56
  %call.i.i.i.i669 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i668, i64 noundef %55, i64 noundef %56, i64 noundef %sub.i.i656) #16
  %conv5.i.i.i670 = zext i1 %call.i.i.i.i669 to i8
  %zf.i.i.i671 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i670, ptr %zf.i.i.i671, align 1
  %cmp.i27.i.i.i672 = icmp slt i64 %sub.i.i656, 0
  %call1.i.i.i.i673 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i672, i64 noundef %55, i64 noundef %56, i64 noundef %sub.i.i656) #16
  %conv8.i.i.i674 = zext i1 %call1.i.i.i.i673 to i8
  %sf.i.i.i675 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i674, ptr %sf.i.i.i675, align 1
  %xor.i28.i.i.i676 = lshr i64 %xor.i.i.i.i664, 63
  %shr9.i.i.i.i677 = xor i64 %sub.i.i656, %55
  %xor3.i.i.i.i678 = lshr i64 %shr9.i.i.i.i677, 63
  %add.i.i.i.i679 = add nuw nsw i64 %xor3.i.i.i.i678, %xor.i28.i.i.i676
  %cmp.i29.i.i.i680 = icmp eq i64 %add.i.i.i.i679, 2
  %call.i30.i.i.i681 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i680, i64 noundef %55, i64 noundef %56, i64 noundef %sub.i.i656) #16
  %conv11.i.i.i682 = zext i1 %call.i30.i.i.i681 to i8
  %of.i.i.i683 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i682, ptr %of.i.i.i683, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %52
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RAX, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  store i64 %65, ptr %RSI, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %62
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RSI, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  store i64 %70, ptr %RAX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %67
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RAX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  %shl.i145.i1126 = shl i64 %75, 1
  %call42.i1127 = call zeroext i8 @__remill_undefined_8() #17
  %tobool43.i1128 = icmp ne i8 %call42.i1127, 0
  %shl.i147.i1129 = shl i64 %shl.i145.i1126, 1
  store i64 %shl.i147.i1129, ptr %RAX, align 8
  %cf.i1131 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i1132 = lshr i64 %shl.i145.i1126, 63
  %conv.i1133 = trunc i64 %new_cf.0.shrunk.in.lobit.i1132 to i8
  store i8 %conv.i1133, ptr %cf.i1131, align 1
  %pf.i1134 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1135 = trunc i64 %shl.i147.i1129 to i8
  %77 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1135)
  %78 = and i8 %77, 1
  %conv72.i1136 = xor i8 %78, 1
  store i8 %conv72.i1136, ptr %pf.i1134, align 1
  %af.i1137 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i1127, ptr %af.i1137, align 1
  %zf.i1138 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i148.i1139 = icmp eq i64 %shl.i147.i1129, 0
  %conv85.i1140 = zext i1 %cmp.i148.i1139 to i8
  store i8 %conv85.i1140, ptr %zf.i1138, align 1
  %sf.i1141 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1142 = lshr i64 %shl.i147.i1129, 63
  %conv92.i1143 = trunc i64 %new_val.0.lobit.i1142 to i8
  store i8 %conv92.i1143, ptr %sf.i1141, align 1
  %of.i1144 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %conv99.i1145 = zext i1 %tobool43.i1128 to i8
  store i8 %conv99.i1145, ptr %of.i1144, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %79

79:                                               ; preds = %72
  %80 = load i64, ptr %NEXT_PC, align 8
  store i64 %80, ptr %PC, align 8
  %81 = add i64 %80, 3
  store i64 %81, ptr %NEXT_PC, align 8
  %82 = load i64, ptr %RAX, align 8
  %83 = load i64, ptr %RSI, align 8
  %84 = load ptr, ptr %MEMORY, align 8
  %add.i.i349 = add i64 %83, %82
  store i64 %add.i.i349, ptr %RAX, align 8
  %cmp.i.i.i350 = icmp ult i64 %add.i.i349, %82
  %cmp1.i.i.i351 = icmp ult i64 %add.i.i349, %83
  %85 = or i1 %cmp.i.i.i350, %cmp1.i.i.i351
  %call.i.i.i352 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %85, i64 noundef %82, i64 noundef %83, i64 noundef %add.i.i349) #16
  %conv.i.i353 = zext i1 %call.i.i.i352 to i8
  %cf.i.i354 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i353, ptr %cf.i.i354, align 1
  %conv.i.i.i.i355 = trunc i64 %add.i.i349 to i8
  %86 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i355)
  %87 = and i8 %86, 1
  %conv.i.i.i356 = xor i8 %87, 1
  %pf.i.i.i357 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i356, ptr %pf.i.i.i357, align 1
  %xor.i.i.i.i358 = xor i64 %add.i.i349, %83
  %xor1.i.i.i.i359 = xor i64 %xor.i.i.i.i358, %82
  %88 = trunc i64 %xor1.i.i.i.i359 to i8
  %89 = lshr i8 %88, 4
  %conv2.i.i.i360 = and i8 %89, 1
  %af.i.i.i361 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i360, ptr %af.i.i.i361, align 1
  %cmp.i.i.i.i362 = icmp eq i64 %add.i.i349, 0
  %call.i.i.i.i363 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i362, i64 noundef %82, i64 noundef %83, i64 noundef %add.i.i349) #16
  %conv5.i.i.i364 = zext i1 %call.i.i.i.i363 to i8
  %zf.i.i.i365 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i364, ptr %zf.i.i.i365, align 1
  %cmp.i27.i.i.i366 = icmp slt i64 %add.i.i349, 0
  %call1.i.i.i.i367 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i366, i64 noundef %82, i64 noundef %83, i64 noundef %add.i.i349) #16
  %conv8.i.i.i368 = zext i1 %call1.i.i.i.i367 to i8
  %sf.i.i.i369 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i368, ptr %sf.i.i.i369, align 1
  %shr8.i.i.i.i370 = xor i64 %add.i.i349, %82
  %xor.i28.i.i.i371 = lshr i64 %shr8.i.i.i.i370, 63
  %xor3.i.i.i.i372 = lshr i64 %xor.i.i.i.i358, 63
  %add.i.i.i.i373 = add nuw nsw i64 %xor.i28.i.i.i371, %xor3.i.i.i.i372
  %cmp.i29.i.i.i374 = icmp eq i64 %add.i.i.i.i373, 2
  %call.i30.i.i.i375 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i374, i64 noundef %82, i64 noundef %83, i64 noundef %add.i.i349) #16
  %conv11.i.i.i376 = zext i1 %call.i30.i.i.i375 to i8
  %of.i.i.i377 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i376, ptr %of.i.i.i377, align 1
  store ptr %84, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %79
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 3
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load i64, ptr %RAX, align 8
  %94 = load i64, ptr %RAX, align 8
  %95 = load ptr, ptr %MEMORY, align 8
  %add.i.i320 = add i64 %94, %93
  store i64 %add.i.i320, ptr %RAX, align 8
  %cmp.i.i.i321 = icmp ult i64 %add.i.i320, %93
  %cmp1.i.i.i322 = icmp ult i64 %add.i.i320, %94
  %96 = or i1 %cmp.i.i.i321, %cmp1.i.i.i322
  %call.i.i.i323 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %96, i64 noundef %93, i64 noundef %94, i64 noundef %add.i.i320) #16
  %conv.i.i324 = zext i1 %call.i.i.i323 to i8
  %cf.i.i325 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i324, ptr %cf.i.i325, align 1
  %conv.i.i.i.i326 = trunc i64 %add.i.i320 to i8
  %97 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i326)
  %98 = and i8 %97, 1
  %conv.i.i.i327 = xor i8 %98, 1
  %pf.i.i.i328 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i327, ptr %pf.i.i.i328, align 1
  %xor.i.i.i.i329 = xor i64 %add.i.i320, %94
  %xor1.i.i.i.i330 = xor i64 %xor.i.i.i.i329, %93
  %99 = trunc i64 %xor1.i.i.i.i330 to i8
  %100 = lshr i8 %99, 4
  %conv2.i.i.i331 = and i8 %100, 1
  %af.i.i.i332 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i331, ptr %af.i.i.i332, align 1
  %cmp.i.i.i.i333 = icmp eq i64 %add.i.i320, 0
  %call.i.i.i.i334 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i333, i64 noundef %93, i64 noundef %94, i64 noundef %add.i.i320) #16
  %conv5.i.i.i335 = zext i1 %call.i.i.i.i334 to i8
  %zf.i.i.i336 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i335, ptr %zf.i.i.i336, align 1
  %cmp.i27.i.i.i337 = icmp slt i64 %add.i.i320, 0
  %call1.i.i.i.i338 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i337, i64 noundef %93, i64 noundef %94, i64 noundef %add.i.i320) #16
  %conv8.i.i.i339 = zext i1 %call1.i.i.i.i338 to i8
  %sf.i.i.i340 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i339, ptr %sf.i.i.i340, align 1
  %shr8.i.i.i.i341 = xor i64 %add.i.i320, %93
  %xor.i28.i.i.i342 = lshr i64 %shr8.i.i.i.i341, 63
  %xor3.i.i.i.i343 = lshr i64 %xor.i.i.i.i329, 63
  %add.i.i.i.i344 = add nuw nsw i64 %xor.i28.i.i.i342, %xor3.i.i.i.i343
  %cmp.i29.i.i.i345 = icmp eq i64 %add.i.i.i.i344, 2
  %call.i30.i.i.i346 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i345, i64 noundef %93, i64 noundef %94, i64 noundef %add.i.i320) #16
  %conv11.i.i.i347 = zext i1 %call.i30.i.i.i346 to i8
  %of.i.i.i348 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i347, ptr %of.i.i.i348, align 1
  store ptr %95, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %90
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 3
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RCX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  store i64 %104, ptr %RSI, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %101
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RSI, align 8
  %110 = load i64, ptr %RAX, align 8
  %111 = load ptr, ptr %MEMORY, align 8
  %sub.i.i628 = sub i64 %109, %110
  store i64 %sub.i.i628, ptr %RSI, align 8
  %cmp.i.i.i629 = icmp ult i64 %109, %110
  %call.i.i.i630 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i629, i64 noundef %109, i64 noundef %110, i64 noundef %sub.i.i628) #16
  %conv.i.i631 = zext i1 %call.i.i.i630 to i8
  %cf.i.i632 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i631, ptr %cf.i.i632, align 1
  %conv.i.i.i.i633 = trunc i64 %sub.i.i628 to i8
  %112 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i633)
  %113 = and i8 %112, 1
  %conv.i.i.i634 = xor i8 %113, 1
  %pf.i.i.i635 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i634, ptr %pf.i.i.i635, align 1
  %xor.i.i.i.i636 = xor i64 %110, %109
  %xor1.i.i.i.i637 = xor i64 %xor.i.i.i.i636, %sub.i.i628
  %114 = trunc i64 %xor1.i.i.i.i637 to i8
  %115 = lshr i8 %114, 4
  %conv2.i.i.i638 = and i8 %115, 1
  %af.i.i.i639 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i638, ptr %af.i.i.i639, align 1
  %cmp.i.i.i.i640 = icmp eq i64 %109, %110
  %call.i.i.i.i641 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i640, i64 noundef %109, i64 noundef %110, i64 noundef %sub.i.i628) #16
  %conv5.i.i.i642 = zext i1 %call.i.i.i.i641 to i8
  %zf.i.i.i643 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i642, ptr %zf.i.i.i643, align 1
  %cmp.i27.i.i.i644 = icmp slt i64 %sub.i.i628, 0
  %call1.i.i.i.i645 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i644, i64 noundef %109, i64 noundef %110, i64 noundef %sub.i.i628) #16
  %conv8.i.i.i646 = zext i1 %call1.i.i.i.i645 to i8
  %sf.i.i.i647 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i646, ptr %sf.i.i.i647, align 1
  %xor.i28.i.i.i648 = lshr i64 %xor.i.i.i.i636, 63
  %shr9.i.i.i.i649 = xor i64 %sub.i.i628, %109
  %xor3.i.i.i.i650 = lshr i64 %shr9.i.i.i.i649, 63
  %add.i.i.i.i651 = add nuw nsw i64 %xor3.i.i.i.i650, %xor.i28.i.i.i648
  %cmp.i29.i.i.i652 = icmp eq i64 %add.i.i.i.i651, 2
  %call.i30.i.i.i653 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i652, i64 noundef %109, i64 noundef %110, i64 noundef %sub.i.i628) #16
  %conv11.i.i.i654 = zext i1 %call.i30.i.i.i653 to i8
  %of.i.i.i655 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i654, ptr %of.i.i.i655, align 1
  store ptr %111, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %106
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 4
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %RBP, align 8
  %120 = sub i64 %119, 16
  %121 = load ptr, ptr %MEMORY, align 8
  %call.i.i835 = call i64 @__remill_read_memory_64(ptr noundef %121, i64 noundef %120) #16
  store i64 %call.i.i835, ptr %RCX, align 8
  store ptr %121, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %116
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 10
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load ptr, ptr %MEMORY, align 8
  store i64 7378697629483820647, ptr %RDX, align 8
  store ptr %125, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %122
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 3
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %RCX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  store i64 %129, ptr %RAX, align 8
  store ptr %130, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %126
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 3
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i64, ptr %RDX, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %rax.i763 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %136 = load i64, ptr %rax.i763, align 8
  %137 = ashr i64 %136, 63
  %138 = ashr i64 %134, 63
  %L.sroa.2.0.insert.ext.i.i764 = zext i64 %137 to i128
  %L.sroa.2.0.insert.shift.i.i765 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i764, 64
  %L.sroa.0.0.insert.ext.i.i766 = zext i64 %136 to i128
  %L.sroa.0.0.insert.insert.i.i767 = or i128 %L.sroa.2.0.insert.shift.i.i765, %L.sroa.0.0.insert.ext.i.i766
  %R.sroa.2.0.insert.ext.i.i768 = zext i64 %138 to i128
  %R.sroa.2.0.insert.shift.i.i769 = shl nuw i128 %R.sroa.2.0.insert.ext.i.i768, 64
  %R.sroa.0.0.insert.ext.i.i770 = zext i64 %134 to i128
  %R.sroa.0.0.insert.insert.i.i771 = or i128 %R.sroa.2.0.insert.shift.i.i769, %R.sroa.0.0.insert.ext.i.i770
  %mul.i.i772 = mul nsw i128 %L.sroa.0.0.insert.insert.i.i767, %R.sroa.0.0.insert.insert.i.i771
  %retval.sroa.0.0.extract.trunc.i.i773 = trunc i128 %mul.i.i772 to i64
  %retval.sroa.2.0.extract.shift.i.i774 = lshr i128 %mul.i.i772, 64
  %retval.sroa.2.0.extract.trunc.i.i775 = trunc i128 %retval.sroa.2.0.extract.shift.i.i774 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i773, ptr %rax.i763, align 8
  %rdx.i776 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %retval.sroa.2.0.extract.trunc.i.i775, ptr %rdx.i776, align 8
  %conv2.i.i.i777 = sext i64 %retval.sroa.0.0.extract.trunc.i.i773 to i128
  %cmp.i.i.i778 = icmp ne i128 %mul.i.i772, %conv2.i.i.i777
  %call.i.i.i779 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i778, i64 noundef %136, i64 noundef %134, i64 noundef %retval.sroa.0.0.extract.trunc.i.i773, i64 noundef %retval.sroa.2.0.extract.trunc.i.i775) #16
  %frombool.i.i780 = zext i1 %call.i.i.i779 to i8
  %cf.i.i781 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i780, ptr %cf.i.i781, align 1
  %call2.i.i782 = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i783 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i782, ptr %pf.i.i783, align 1
  %af.i.i784 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i782, ptr %af.i.i784, align 1
  %zf.i.i785 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i782, ptr %zf.i.i785, align 1
  %sf.i.i786 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i782, ptr %sf.i.i786, align 1
  %of.i.i787 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i780, ptr %of.i.i787, align 1
  store ptr %135, ptr %MEMORY, align 8
  br label %139

139:                                              ; preds = %131
  %140 = load i64, ptr %NEXT_PC, align 8
  store i64 %140, ptr %PC, align 8
  %141 = add i64 %140, 3
  store i64 %141, ptr %NEXT_PC, align 8
  %142 = load i64, ptr %RDX, align 8
  %143 = load ptr, ptr %MEMORY, align 8
  store i64 %142, ptr %RAX, align 8
  store ptr %143, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %139
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 4
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i64, ptr %RAX, align 8
  %148 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i1025 = ashr i64 %147, 1
  %call36.i1026 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i1027 = icmp ne i8 %call36.i1026, 0
  %149 = zext i1 %tobool.i1027 to i8
  %new_val.0.i1028 = ashr i64 %shr.i152.i1025, 1
  store i64 %new_val.0.i1028, ptr %RAX, align 8
  %cf.i1029 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %150 = trunc i64 %shr.i152.i1025 to i8
  %conv.i1030 = and i8 %150, 1
  store i8 %conv.i1030, ptr %cf.i1029, align 1
  %pf.i1031 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1032 = trunc i64 %new_val.0.i1028 to i8
  %151 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1032)
  %152 = and i8 %151, 1
  %conv75.i1033 = xor i8 %152, 1
  store i8 %conv75.i1033, ptr %pf.i1031, align 1
  %af.i1034 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1026, ptr %af.i1034, align 1
  %zf.i1035 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1036 = icmp ult i64 %shr.i152.i1025, 2
  %conv88.i1037 = zext i1 %cmp.i157.i1036 to i8
  store i8 %conv88.i1037, ptr %zf.i1035, align 1
  %sf.i1038 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i1039 = lshr i64 %shr.i152.i1025, 63
  %conv95.i1040 = trunc i64 %new_val.0.in.lobit.i1039 to i8
  store i8 %conv95.i1040, ptr %sf.i1038, align 1
  %of.i1041 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %149, ptr %of.i1041, align 1
  store ptr %148, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %144
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 3
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %RCX, align 8
  %157 = load ptr, ptr %MEMORY, align 8
  store i64 %156, ptr %RDI, align 8
  store ptr %157, ptr %MEMORY, align 8
  br label %158

158:                                              ; preds = %153
  %159 = load i64, ptr %NEXT_PC, align 8
  store i64 %159, ptr %PC, align 8
  %160 = add i64 %159, 4
  store i64 %160, ptr %NEXT_PC, align 8
  %161 = load i64, ptr %RDI, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i1008 = ashr i64 %161, 62
  %call36.i1009 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i1010 = icmp ne i8 %call36.i1009, 0
  %163 = zext i1 %tobool.i1010 to i8
  %new_val.0.i1011 = ashr i64 %shr.i152.i1008, 1
  store i64 %new_val.0.i1011, ptr %RDI, align 8
  %cf.i1012 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %164 = trunc i64 %shr.i152.i1008 to i8
  %conv.i1013 = and i8 %164, 1
  store i8 %conv.i1013, ptr %cf.i1012, align 1
  %pf.i1014 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1015 = trunc i64 %new_val.0.i1011 to i8
  %165 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1015)
  %166 = and i8 %165, 1
  %conv75.i1016 = xor i8 %166, 1
  store i8 %conv75.i1016, ptr %pf.i1014, align 1
  %af.i1017 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i1009, ptr %af.i1017, align 1
  %zf.i1018 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1019 = icmp ult i64 %shr.i152.i1008, 2
  %conv88.i1020 = zext i1 %cmp.i157.i1019 to i8
  store i8 %conv88.i1020, ptr %zf.i1018, align 1
  %sf.i1021 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i1022 = lshr i64 %shr.i152.i1008, 63
  %conv95.i1023 = trunc i64 %new_val.0.in.lobit.i1022 to i8
  store i8 %conv95.i1023, ptr %sf.i1021, align 1
  %of.i1024 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %163, ptr %of.i1024, align 1
  store ptr %162, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %158
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 3
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i64, ptr %RAX, align 8
  %171 = load i64, ptr %RDI, align 8
  %172 = load ptr, ptr %MEMORY, align 8
  %sub.i.i600 = sub i64 %170, %171
  store i64 %sub.i.i600, ptr %RAX, align 8
  %cmp.i.i.i601 = icmp ult i64 %170, %171
  %call.i.i.i602 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i601, i64 noundef %170, i64 noundef %171, i64 noundef %sub.i.i600) #16
  %conv.i.i603 = zext i1 %call.i.i.i602 to i8
  %cf.i.i604 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i603, ptr %cf.i.i604, align 1
  %conv.i.i.i.i605 = trunc i64 %sub.i.i600 to i8
  %173 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i605)
  %174 = and i8 %173, 1
  %conv.i.i.i606 = xor i8 %174, 1
  %pf.i.i.i607 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i606, ptr %pf.i.i.i607, align 1
  %xor.i.i.i.i608 = xor i64 %171, %170
  %xor1.i.i.i.i609 = xor i64 %xor.i.i.i.i608, %sub.i.i600
  %175 = trunc i64 %xor1.i.i.i.i609 to i8
  %176 = lshr i8 %175, 4
  %conv2.i.i.i610 = and i8 %176, 1
  %af.i.i.i611 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i610, ptr %af.i.i.i611, align 1
  %cmp.i.i.i.i612 = icmp eq i64 %170, %171
  %call.i.i.i.i613 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i612, i64 noundef %170, i64 noundef %171, i64 noundef %sub.i.i600) #16
  %conv5.i.i.i614 = zext i1 %call.i.i.i.i613 to i8
  %zf.i.i.i615 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i614, ptr %zf.i.i.i615, align 1
  %cmp.i27.i.i.i616 = icmp slt i64 %sub.i.i600, 0
  %call1.i.i.i.i617 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i616, i64 noundef %170, i64 noundef %171, i64 noundef %sub.i.i600) #16
  %conv8.i.i.i618 = zext i1 %call1.i.i.i.i617 to i8
  %sf.i.i.i619 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i618, ptr %sf.i.i.i619, align 1
  %xor.i28.i.i.i620 = lshr i64 %xor.i.i.i.i608, 63
  %shr9.i.i.i.i621 = xor i64 %sub.i.i600, %170
  %xor3.i.i.i.i622 = lshr i64 %shr9.i.i.i.i621, 63
  %add.i.i.i.i623 = add nuw nsw i64 %xor3.i.i.i.i622, %xor.i28.i.i.i620
  %cmp.i29.i.i.i624 = icmp eq i64 %add.i.i.i.i623, 2
  %call.i30.i.i.i625 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i624, i64 noundef %170, i64 noundef %171, i64 noundef %sub.i.i600) #16
  %conv11.i.i.i626 = zext i1 %call.i30.i.i.i625 to i8
  %of.i.i.i627 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i626, ptr %of.i.i.i627, align 1
  store ptr %172, ptr %MEMORY, align 8
  br label %177

177:                                              ; preds = %167
  %178 = load i64, ptr %NEXT_PC, align 8
  store i64 %178, ptr %PC, align 8
  %179 = add i64 %178, 3
  store i64 %179, ptr %NEXT_PC, align 8
  %180 = load i64, ptr %RAX, align 8
  %181 = load ptr, ptr %MEMORY, align 8
  store i64 %180, ptr %RDX, align 8
  store ptr %181, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %177
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 3
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load i64, ptr %RDX, align 8
  %186 = load ptr, ptr %MEMORY, align 8
  store i64 %185, ptr %RAX, align 8
  store ptr %186, ptr %MEMORY, align 8
  br label %187

187:                                              ; preds = %182
  %188 = load i64, ptr %NEXT_PC, align 8
  store i64 %188, ptr %PC, align 8
  %189 = add i64 %188, 4
  store i64 %189, ptr %NEXT_PC, align 8
  %190 = load i64, ptr %RAX, align 8
  %191 = load ptr, ptr %MEMORY, align 8
  %shl.i145.i1106 = shl i64 %190, 1
  %call42.i1107 = call zeroext i8 @__remill_undefined_8() #17
  %tobool43.i1108 = icmp ne i8 %call42.i1107, 0
  %shl.i147.i1109 = shl i64 %shl.i145.i1106, 1
  store i64 %shl.i147.i1109, ptr %RAX, align 8
  %cf.i1111 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i1112 = lshr i64 %shl.i145.i1106, 63
  %conv.i1113 = trunc i64 %new_cf.0.shrunk.in.lobit.i1112 to i8
  store i8 %conv.i1113, ptr %cf.i1111, align 1
  %pf.i1114 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1115 = trunc i64 %shl.i147.i1109 to i8
  %192 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1115)
  %193 = and i8 %192, 1
  %conv72.i1116 = xor i8 %193, 1
  store i8 %conv72.i1116, ptr %pf.i1114, align 1
  %af.i1117 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i1107, ptr %af.i1117, align 1
  %zf.i1118 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i148.i1119 = icmp eq i64 %shl.i147.i1109, 0
  %conv85.i1120 = zext i1 %cmp.i148.i1119 to i8
  store i8 %conv85.i1120, ptr %zf.i1118, align 1
  %sf.i1121 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1122 = lshr i64 %shl.i147.i1109, 63
  %conv92.i1123 = trunc i64 %new_val.0.lobit.i1122 to i8
  store i8 %conv92.i1123, ptr %sf.i1121, align 1
  %of.i1124 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %conv99.i1125 = zext i1 %tobool43.i1108 to i8
  store i8 %conv99.i1125, ptr %of.i1124, align 1
  store ptr %191, ptr %MEMORY, align 8
  br label %194

194:                                              ; preds = %187
  %195 = load i64, ptr %NEXT_PC, align 8
  store i64 %195, ptr %PC, align 8
  %196 = add i64 %195, 3
  store i64 %196, ptr %NEXT_PC, align 8
  %197 = load i64, ptr %RAX, align 8
  %198 = load i64, ptr %RDX, align 8
  %199 = load ptr, ptr %MEMORY, align 8
  %add.i.i291 = add i64 %198, %197
  store i64 %add.i.i291, ptr %RAX, align 8
  %cmp.i.i.i292 = icmp ult i64 %add.i.i291, %197
  %cmp1.i.i.i293 = icmp ult i64 %add.i.i291, %198
  %200 = or i1 %cmp.i.i.i292, %cmp1.i.i.i293
  %call.i.i.i294 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %200, i64 noundef %197, i64 noundef %198, i64 noundef %add.i.i291) #16
  %conv.i.i295 = zext i1 %call.i.i.i294 to i8
  %cf.i.i296 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i295, ptr %cf.i.i296, align 1
  %conv.i.i.i.i297 = trunc i64 %add.i.i291 to i8
  %201 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i297)
  %202 = and i8 %201, 1
  %conv.i.i.i298 = xor i8 %202, 1
  %pf.i.i.i299 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i298, ptr %pf.i.i.i299, align 1
  %xor.i.i.i.i300 = xor i64 %add.i.i291, %198
  %xor1.i.i.i.i301 = xor i64 %xor.i.i.i.i300, %197
  %203 = trunc i64 %xor1.i.i.i.i301 to i8
  %204 = lshr i8 %203, 4
  %conv2.i.i.i302 = and i8 %204, 1
  %af.i.i.i303 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i302, ptr %af.i.i.i303, align 1
  %cmp.i.i.i.i304 = icmp eq i64 %add.i.i291, 0
  %call.i.i.i.i305 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i304, i64 noundef %197, i64 noundef %198, i64 noundef %add.i.i291) #16
  %conv5.i.i.i306 = zext i1 %call.i.i.i.i305 to i8
  %zf.i.i.i307 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i306, ptr %zf.i.i.i307, align 1
  %cmp.i27.i.i.i308 = icmp slt i64 %add.i.i291, 0
  %call1.i.i.i.i309 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i308, i64 noundef %197, i64 noundef %198, i64 noundef %add.i.i291) #16
  %conv8.i.i.i310 = zext i1 %call1.i.i.i.i309 to i8
  %sf.i.i.i311 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i310, ptr %sf.i.i.i311, align 1
  %shr8.i.i.i.i312 = xor i64 %add.i.i291, %197
  %xor.i28.i.i.i313 = lshr i64 %shr8.i.i.i.i312, 63
  %xor3.i.i.i.i314 = lshr i64 %xor.i.i.i.i300, 63
  %add.i.i.i.i315 = add nuw nsw i64 %xor.i28.i.i.i313, %xor3.i.i.i.i314
  %cmp.i29.i.i.i316 = icmp eq i64 %add.i.i.i.i315, 2
  %call.i30.i.i.i317 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i316, i64 noundef %197, i64 noundef %198, i64 noundef %add.i.i291) #16
  %conv11.i.i.i318 = zext i1 %call.i30.i.i.i317 to i8
  %of.i.i.i319 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i318, ptr %of.i.i.i319, align 1
  store ptr %199, ptr %MEMORY, align 8
  br label %205

205:                                              ; preds = %194
  %206 = load i64, ptr %NEXT_PC, align 8
  store i64 %206, ptr %PC, align 8
  %207 = add i64 %206, 3
  store i64 %207, ptr %NEXT_PC, align 8
  %208 = load i64, ptr %RAX, align 8
  %209 = load i64, ptr %RAX, align 8
  %210 = load ptr, ptr %MEMORY, align 8
  %add.i.i262 = add i64 %209, %208
  store i64 %add.i.i262, ptr %RAX, align 8
  %cmp.i.i.i263 = icmp ult i64 %add.i.i262, %208
  %cmp1.i.i.i264 = icmp ult i64 %add.i.i262, %209
  %211 = or i1 %cmp.i.i.i263, %cmp1.i.i.i264
  %call.i.i.i265 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %211, i64 noundef %208, i64 noundef %209, i64 noundef %add.i.i262) #16
  %conv.i.i266 = zext i1 %call.i.i.i265 to i8
  %cf.i.i267 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i266, ptr %cf.i.i267, align 1
  %conv.i.i.i.i268 = trunc i64 %add.i.i262 to i8
  %212 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i268)
  %213 = and i8 %212, 1
  %conv.i.i.i269 = xor i8 %213, 1
  %pf.i.i.i270 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i269, ptr %pf.i.i.i270, align 1
  %xor.i.i.i.i271 = xor i64 %add.i.i262, %209
  %xor1.i.i.i.i272 = xor i64 %xor.i.i.i.i271, %208
  %214 = trunc i64 %xor1.i.i.i.i272 to i8
  %215 = lshr i8 %214, 4
  %conv2.i.i.i273 = and i8 %215, 1
  %af.i.i.i274 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i273, ptr %af.i.i.i274, align 1
  %cmp.i.i.i.i275 = icmp eq i64 %add.i.i262, 0
  %call.i.i.i.i276 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i275, i64 noundef %208, i64 noundef %209, i64 noundef %add.i.i262) #16
  %conv5.i.i.i277 = zext i1 %call.i.i.i.i276 to i8
  %zf.i.i.i278 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i277, ptr %zf.i.i.i278, align 1
  %cmp.i27.i.i.i279 = icmp slt i64 %add.i.i262, 0
  %call1.i.i.i.i280 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i279, i64 noundef %208, i64 noundef %209, i64 noundef %add.i.i262) #16
  %conv8.i.i.i281 = zext i1 %call1.i.i.i.i280 to i8
  %sf.i.i.i282 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i281, ptr %sf.i.i.i282, align 1
  %shr8.i.i.i.i283 = xor i64 %add.i.i262, %208
  %xor.i28.i.i.i284 = lshr i64 %shr8.i.i.i.i283, 63
  %xor3.i.i.i.i285 = lshr i64 %xor.i.i.i.i271, 63
  %add.i.i.i.i286 = add nuw nsw i64 %xor.i28.i.i.i284, %xor3.i.i.i.i285
  %cmp.i29.i.i.i287 = icmp eq i64 %add.i.i.i.i286, 2
  %call.i30.i.i.i288 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i287, i64 noundef %208, i64 noundef %209, i64 noundef %add.i.i262) #16
  %conv11.i.i.i289 = zext i1 %call.i30.i.i.i288 to i8
  %of.i.i.i290 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i289, ptr %of.i.i.i290, align 1
  store ptr %210, ptr %MEMORY, align 8
  br label %216

216:                                              ; preds = %205
  %217 = load i64, ptr %NEXT_PC, align 8
  store i64 %217, ptr %PC, align 8
  %218 = add i64 %217, 3
  store i64 %218, ptr %NEXT_PC, align 8
  %219 = load i64, ptr %RCX, align 8
  %220 = load i64, ptr %RAX, align 8
  %221 = load ptr, ptr %MEMORY, align 8
  %sub.i.i572 = sub i64 %219, %220
  store i64 %sub.i.i572, ptr %RCX, align 8
  %cmp.i.i.i573 = icmp ult i64 %219, %220
  %call.i.i.i574 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i573, i64 noundef %219, i64 noundef %220, i64 noundef %sub.i.i572) #16
  %conv.i.i575 = zext i1 %call.i.i.i574 to i8
  %cf.i.i576 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i575, ptr %cf.i.i576, align 1
  %conv.i.i.i.i577 = trunc i64 %sub.i.i572 to i8
  %222 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i577)
  %223 = and i8 %222, 1
  %conv.i.i.i578 = xor i8 %223, 1
  %pf.i.i.i579 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i578, ptr %pf.i.i.i579, align 1
  %xor.i.i.i.i580 = xor i64 %220, %219
  %xor1.i.i.i.i581 = xor i64 %xor.i.i.i.i580, %sub.i.i572
  %224 = trunc i64 %xor1.i.i.i.i581 to i8
  %225 = lshr i8 %224, 4
  %conv2.i.i.i582 = and i8 %225, 1
  %af.i.i.i583 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i582, ptr %af.i.i.i583, align 1
  %cmp.i.i.i.i584 = icmp eq i64 %219, %220
  %call.i.i.i.i585 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i584, i64 noundef %219, i64 noundef %220, i64 noundef %sub.i.i572) #16
  %conv5.i.i.i586 = zext i1 %call.i.i.i.i585 to i8
  %zf.i.i.i587 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i586, ptr %zf.i.i.i587, align 1
  %cmp.i27.i.i.i588 = icmp slt i64 %sub.i.i572, 0
  %call1.i.i.i.i589 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i588, i64 noundef %219, i64 noundef %220, i64 noundef %sub.i.i572) #16
  %conv8.i.i.i590 = zext i1 %call1.i.i.i.i589 to i8
  %sf.i.i.i591 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i590, ptr %sf.i.i.i591, align 1
  %xor.i28.i.i.i592 = lshr i64 %xor.i.i.i.i580, 63
  %shr9.i.i.i.i593 = xor i64 %sub.i.i572, %219
  %xor3.i.i.i.i594 = lshr i64 %shr9.i.i.i.i593, 63
  %add.i.i.i.i595 = add nuw nsw i64 %xor3.i.i.i.i594, %xor.i28.i.i.i592
  %cmp.i29.i.i.i596 = icmp eq i64 %add.i.i.i.i595, 2
  %call.i30.i.i.i597 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i596, i64 noundef %219, i64 noundef %220, i64 noundef %sub.i.i572) #16
  %conv11.i.i.i598 = zext i1 %call.i30.i.i.i597 to i8
  %of.i.i.i599 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i598, ptr %of.i.i.i599, align 1
  store ptr %221, ptr %MEMORY, align 8
  br label %226

226:                                              ; preds = %216
  %227 = load i64, ptr %NEXT_PC, align 8
  store i64 %227, ptr %PC, align 8
  %228 = add i64 %227, 3
  store i64 %228, ptr %NEXT_PC, align 8
  %229 = load i64, ptr %RCX, align 8
  %230 = load ptr, ptr %MEMORY, align 8
  store i64 %229, ptr %RDX, align 8
  store ptr %230, ptr %MEMORY, align 8
  br label %231

231:                                              ; preds = %226
  %232 = load i64, ptr %NEXT_PC, align 8
  store i64 %232, ptr %PC, align 8
  %233 = add i64 %232, 3
  store i64 %233, ptr %NEXT_PC, align 8
  %234 = load i64, ptr %RDX, align 8
  %235 = load i64, ptr %RSI, align 8
  %236 = load ptr, ptr %MEMORY, align 8
  %add.i.i233 = add i64 %235, %234
  store i64 %add.i.i233, ptr %RDX, align 8
  %cmp.i.i.i234 = icmp ult i64 %add.i.i233, %234
  %cmp1.i.i.i235 = icmp ult i64 %add.i.i233, %235
  %237 = or i1 %cmp.i.i.i234, %cmp1.i.i.i235
  %call.i.i.i236 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %237, i64 noundef %234, i64 noundef %235, i64 noundef %add.i.i233) #16
  %conv.i.i237 = zext i1 %call.i.i.i236 to i8
  %cf.i.i238 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i237, ptr %cf.i.i238, align 1
  %conv.i.i.i.i239 = trunc i64 %add.i.i233 to i8
  %238 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i239)
  %239 = and i8 %238, 1
  %conv.i.i.i240 = xor i8 %239, 1
  %pf.i.i.i241 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i240, ptr %pf.i.i.i241, align 1
  %xor.i.i.i.i242 = xor i64 %add.i.i233, %235
  %xor1.i.i.i.i243 = xor i64 %xor.i.i.i.i242, %234
  %240 = trunc i64 %xor1.i.i.i.i243 to i8
  %241 = lshr i8 %240, 4
  %conv2.i.i.i244 = and i8 %241, 1
  %af.i.i.i245 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i244, ptr %af.i.i.i245, align 1
  %cmp.i.i.i.i246 = icmp eq i64 %add.i.i233, 0
  %call.i.i.i.i247 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i246, i64 noundef %234, i64 noundef %235, i64 noundef %add.i.i233) #16
  %conv5.i.i.i248 = zext i1 %call.i.i.i.i247 to i8
  %zf.i.i.i249 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i248, ptr %zf.i.i.i249, align 1
  %cmp.i27.i.i.i250 = icmp slt i64 %add.i.i233, 0
  %call1.i.i.i.i251 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i250, i64 noundef %234, i64 noundef %235, i64 noundef %add.i.i233) #16
  %conv8.i.i.i252 = zext i1 %call1.i.i.i.i251 to i8
  %sf.i.i.i253 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i252, ptr %sf.i.i.i253, align 1
  %shr8.i.i.i.i254 = xor i64 %add.i.i233, %234
  %xor.i28.i.i.i255 = lshr i64 %shr8.i.i.i.i254, 63
  %xor3.i.i.i.i256 = lshr i64 %xor.i.i.i.i242, 63
  %add.i.i.i.i257 = add nuw nsw i64 %xor.i28.i.i.i255, %xor3.i.i.i.i256
  %cmp.i29.i.i.i258 = icmp eq i64 %add.i.i.i.i257, 2
  %call.i30.i.i.i259 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i258, i64 noundef %234, i64 noundef %235, i64 noundef %add.i.i233) #16
  %conv11.i.i.i260 = zext i1 %call.i30.i.i.i259 to i8
  %of.i.i.i261 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i260, ptr %of.i.i.i261, align 1
  store ptr %236, ptr %MEMORY, align 8
  br label %242

242:                                              ; preds = %231
  %243 = load i64, ptr %NEXT_PC, align 8
  store i64 %243, ptr %PC, align 8
  %244 = add i64 %243, 3
  store i64 %244, ptr %NEXT_PC, align 8
  %245 = load i64, ptr %RBP, align 8
  %246 = sub i64 %245, 24
  %247 = load ptr, ptr %MEMORY, align 8
  %call.i.i829 = call i32 @__remill_read_memory_32(ptr noundef %247, i64 noundef %246) #16
  %conv.i.i830 = zext i32 %call.i.i829 to i64
  store i64 %conv.i.i830, ptr %RAX, align 8
  store ptr %247, ptr %MEMORY, align 8
  br label %248

248:                                              ; preds = %242
  %249 = load i64, ptr %NEXT_PC, align 8
  store i64 %249, ptr %PC, align 8
  %250 = add i64 %249, 2
  store i64 %250, ptr %NEXT_PC, align 8
  %251 = load ptr, ptr %MEMORY, align 8
  %rax.i817 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %252 = load i32, ptr %rax.i817, align 8
  %conv.i.i818 = sext i32 %252 to i64
  store i64 %conv.i.i818, ptr %rax.i817, align 8
  store ptr %251, ptr %MEMORY, align 8
  br label %253

253:                                              ; preds = %248
  %254 = load i64, ptr %NEXT_PC, align 8
  store i64 %254, ptr %PC, align 8
  %255 = add i64 %254, 3
  store i64 %255, ptr %NEXT_PC, align 8
  %256 = load i64, ptr %RAX, align 8
  %257 = load i64, ptr %RDX, align 8
  %258 = load ptr, ptr %MEMORY, align 8
  %add.i.i204 = add i64 %257, %256
  store i64 %add.i.i204, ptr %RAX, align 8
  %cmp.i.i.i205 = icmp ult i64 %add.i.i204, %256
  %cmp1.i.i.i206 = icmp ult i64 %add.i.i204, %257
  %259 = or i1 %cmp.i.i.i205, %cmp1.i.i.i206
  %call.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %259, i64 noundef %256, i64 noundef %257, i64 noundef %add.i.i204) #16
  %conv.i.i208 = zext i1 %call.i.i.i207 to i8
  %cf.i.i209 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i208, ptr %cf.i.i209, align 1
  %conv.i.i.i.i210 = trunc i64 %add.i.i204 to i8
  %260 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i210)
  %261 = and i8 %260, 1
  %conv.i.i.i211 = xor i8 %261, 1
  %pf.i.i.i212 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i211, ptr %pf.i.i.i212, align 1
  %xor.i.i.i.i213 = xor i64 %add.i.i204, %257
  %xor1.i.i.i.i214 = xor i64 %xor.i.i.i.i213, %256
  %262 = trunc i64 %xor1.i.i.i.i214 to i8
  %263 = lshr i8 %262, 4
  %conv2.i.i.i215 = and i8 %263, 1
  %af.i.i.i216 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i215, ptr %af.i.i.i216, align 1
  %cmp.i.i.i.i217 = icmp eq i64 %add.i.i204, 0
  %call.i.i.i.i218 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i217, i64 noundef %256, i64 noundef %257, i64 noundef %add.i.i204) #16
  %conv5.i.i.i219 = zext i1 %call.i.i.i.i218 to i8
  %zf.i.i.i220 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i219, ptr %zf.i.i.i220, align 1
  %cmp.i27.i.i.i221 = icmp slt i64 %add.i.i204, 0
  %call1.i.i.i.i222 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i221, i64 noundef %256, i64 noundef %257, i64 noundef %add.i.i204) #16
  %conv8.i.i.i223 = zext i1 %call1.i.i.i.i222 to i8
  %sf.i.i.i224 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i223, ptr %sf.i.i.i224, align 1
  %shr8.i.i.i.i225 = xor i64 %add.i.i204, %256
  %xor.i28.i.i.i226 = lshr i64 %shr8.i.i.i.i225, 63
  %xor3.i.i.i.i227 = lshr i64 %xor.i.i.i.i213, 63
  %add.i.i.i.i228 = add nuw nsw i64 %xor.i28.i.i.i226, %xor3.i.i.i.i227
  %cmp.i29.i.i.i229 = icmp eq i64 %add.i.i.i.i228, 2
  %call.i30.i.i.i230 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i229, i64 noundef %256, i64 noundef %257, i64 noundef %add.i.i204) #16
  %conv11.i.i.i231 = zext i1 %call.i30.i.i.i230 to i8
  %of.i.i.i232 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i231, ptr %of.i.i.i232, align 1
  store ptr %258, ptr %MEMORY, align 8
  br label %264

264:                                              ; preds = %253
  %265 = load i64, ptr %NEXT_PC, align 8
  store i64 %265, ptr %PC, align 8
  %266 = add i64 %265, 2
  store i64 %266, ptr %NEXT_PC, align 8
  %267 = load ptr, ptr %MEMORY, align 8
  %rdx.i819 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  %rax.i820 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %268 = load i64, ptr %rax.i820, align 8
  %shr.i.neg.i = ashr i64 %268, 63
  store i64 %shr.i.neg.i, ptr %rdx.i819, align 8
  store ptr %267, ptr %MEMORY, align 8
  br label %269

269:                                              ; preds = %264
  %270 = load i64, ptr %NEXT_PC, align 8
  store i64 %270, ptr %PC, align 8
  %271 = add i64 %270, 4
  store i64 %271, ptr %NEXT_PC, align 8
  %272 = load i64, ptr %RDX, align 8
  %273 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i849 = lshr i64 %272, 62
  %call34.i850 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i851 = icmp ne i8 %call34.i850, 0
  %new_val.0.i852 = lshr i64 %shr.i136.i849, 1
  store i64 %new_val.0.i852, ptr %RDX, align 8
  %cf.i853 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %274 = trunc i64 %shr.i136.i849 to i8
  %conv.i854 = and i8 %274, 1
  store i8 %conv.i854, ptr %cf.i853, align 1
  %pf.i855 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i856 = trunc i64 %new_val.0.i852 to i8
  %275 = call i8 @llvm.ctpop.i8(i8 %conv.i.i856)
  %276 = and i8 %275, 1
  %conv67.i857 = xor i8 %276, 1
  store i8 %conv67.i857, ptr %pf.i855, align 1
  %af.i858 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i850, ptr %af.i858, align 1
  %zf.i859 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i860 = icmp ult i64 %shr.i136.i849, 2
  %conv80.i861 = zext i1 %cmp.i140.i860 to i8
  store i8 %conv80.i861, ptr %zf.i859, align 1
  %sf.i862 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i862, align 1
  %of.i863 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %conv92.i864 = zext i1 %tobool.i851 to i8
  store i8 %conv92.i864, ptr %of.i863, align 1
  store ptr %273, ptr %MEMORY, align 8
  br label %277

277:                                              ; preds = %269
  %278 = load i64, ptr %NEXT_PC, align 8
  store i64 %278, ptr %PC, align 8
  %279 = add i64 %278, 3
  store i64 %279, ptr %NEXT_PC, align 8
  %280 = load i64, ptr %RAX, align 8
  %281 = load i64, ptr %RDX, align 8
  %282 = load ptr, ptr %MEMORY, align 8
  %add.i.i175 = add i64 %281, %280
  store i64 %add.i.i175, ptr %RAX, align 8
  %cmp.i.i.i176 = icmp ult i64 %add.i.i175, %280
  %cmp1.i.i.i177 = icmp ult i64 %add.i.i175, %281
  %283 = or i1 %cmp.i.i.i176, %cmp1.i.i.i177
  %call.i.i.i178 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %283, i64 noundef %280, i64 noundef %281, i64 noundef %add.i.i175) #16
  %conv.i.i179 = zext i1 %call.i.i.i178 to i8
  %cf.i.i180 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i179, ptr %cf.i.i180, align 1
  %conv.i.i.i.i181 = trunc i64 %add.i.i175 to i8
  %284 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i181)
  %285 = and i8 %284, 1
  %conv.i.i.i182 = xor i8 %285, 1
  %pf.i.i.i183 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i182, ptr %pf.i.i.i183, align 1
  %xor.i.i.i.i184 = xor i64 %add.i.i175, %281
  %xor1.i.i.i.i185 = xor i64 %xor.i.i.i.i184, %280
  %286 = trunc i64 %xor1.i.i.i.i185 to i8
  %287 = lshr i8 %286, 4
  %conv2.i.i.i186 = and i8 %287, 1
  %af.i.i.i187 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i186, ptr %af.i.i.i187, align 1
  %cmp.i.i.i.i188 = icmp eq i64 %add.i.i175, 0
  %call.i.i.i.i189 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i188, i64 noundef %280, i64 noundef %281, i64 noundef %add.i.i175) #16
  %conv5.i.i.i190 = zext i1 %call.i.i.i.i189 to i8
  %zf.i.i.i191 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i190, ptr %zf.i.i.i191, align 1
  %cmp.i27.i.i.i192 = icmp slt i64 %add.i.i175, 0
  %call1.i.i.i.i193 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i192, i64 noundef %280, i64 noundef %281, i64 noundef %add.i.i175) #16
  %conv8.i.i.i194 = zext i1 %call1.i.i.i.i193 to i8
  %sf.i.i.i195 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i194, ptr %sf.i.i.i195, align 1
  %shr8.i.i.i.i196 = xor i64 %add.i.i175, %280
  %xor.i28.i.i.i197 = lshr i64 %shr8.i.i.i.i196, 63
  %xor3.i.i.i.i198 = lshr i64 %xor.i.i.i.i184, 63
  %add.i.i.i.i199 = add nuw nsw i64 %xor.i28.i.i.i197, %xor3.i.i.i.i198
  %cmp.i29.i.i.i200 = icmp eq i64 %add.i.i.i.i199, 2
  %call.i30.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i200, i64 noundef %280, i64 noundef %281, i64 noundef %add.i.i175) #16
  %conv11.i.i.i202 = zext i1 %call.i30.i.i.i201 to i8
  %of.i.i.i203 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i202, ptr %of.i.i.i203, align 1
  store ptr %282, ptr %MEMORY, align 8
  br label %288

288:                                              ; preds = %277
  %289 = load i64, ptr %NEXT_PC, align 8
  store i64 %289, ptr %PC, align 8
  %290 = add i64 %289, 3
  store i64 %290, ptr %NEXT_PC, align 8
  %291 = load i64, ptr %RAX, align 8
  %292 = load ptr, ptr %MEMORY, align 8
  %conv.i.i837 = trunc i64 %291 to i32
  %and3.i.i = and i32 1, %conv.i.i837
  %conv.i22.i = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cf.i.i838 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i838, align 1
  %conv.i.i.i839 = trunc i32 %and3.i.i to i8
  %293 = and i8 %conv.i.i.i839, 1
  %conv.i23.i = xor i8 %293, 1
  %pf.i.i840 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i, ptr %pf.i.i840, align 1
  %cmp.i.i.i841 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i842 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i841, i32 noundef %conv.i.i837, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv3.i.i = zext i1 %call.i.i.i842 to i8
  %zf.i.i843 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i843, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i837, i32 noundef 1, i32 noundef %and3.i.i) #16
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i844 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i844, align 1
  %of.i.i845 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i845, align 1
  %af.i.i846 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i846, align 1
  store ptr %292, ptr %MEMORY, align 8
  br label %294

294:                                              ; preds = %288
  %295 = load i64, ptr %NEXT_PC, align 8
  store i64 %295, ptr %PC, align 8
  %296 = add i64 %295, 3
  store i64 %296, ptr %NEXT_PC, align 8
  %297 = load i64, ptr %RAX, align 8
  %298 = load i64, ptr %RDX, align 8
  %299 = load ptr, ptr %MEMORY, align 8
  %sub.i.i544 = sub i64 %297, %298
  store i64 %sub.i.i544, ptr %RAX, align 8
  %cmp.i.i.i545 = icmp ult i64 %297, %298
  %call.i.i.i546 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i545, i64 noundef %297, i64 noundef %298, i64 noundef %sub.i.i544) #16
  %conv.i.i547 = zext i1 %call.i.i.i546 to i8
  %cf.i.i548 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i547, ptr %cf.i.i548, align 1
  %conv.i.i.i.i549 = trunc i64 %sub.i.i544 to i8
  %300 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i549)
  %301 = and i8 %300, 1
  %conv.i.i.i550 = xor i8 %301, 1
  %pf.i.i.i551 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i550, ptr %pf.i.i.i551, align 1
  %xor.i.i.i.i552 = xor i64 %298, %297
  %xor1.i.i.i.i553 = xor i64 %xor.i.i.i.i552, %sub.i.i544
  %302 = trunc i64 %xor1.i.i.i.i553 to i8
  %303 = lshr i8 %302, 4
  %conv2.i.i.i554 = and i8 %303, 1
  %af.i.i.i555 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i554, ptr %af.i.i.i555, align 1
  %cmp.i.i.i.i556 = icmp eq i64 %297, %298
  %call.i.i.i.i557 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i556, i64 noundef %297, i64 noundef %298, i64 noundef %sub.i.i544) #16
  %conv5.i.i.i558 = zext i1 %call.i.i.i.i557 to i8
  %zf.i.i.i559 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i558, ptr %zf.i.i.i559, align 1
  %cmp.i27.i.i.i560 = icmp slt i64 %sub.i.i544, 0
  %call1.i.i.i.i561 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i560, i64 noundef %297, i64 noundef %298, i64 noundef %sub.i.i544) #16
  %conv8.i.i.i562 = zext i1 %call1.i.i.i.i561 to i8
  %sf.i.i.i563 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i562, ptr %sf.i.i.i563, align 1
  %xor.i28.i.i.i564 = lshr i64 %xor.i.i.i.i552, 63
  %shr9.i.i.i.i565 = xor i64 %sub.i.i544, %297
  %xor3.i.i.i.i566 = lshr i64 %shr9.i.i.i.i565, 63
  %add.i.i.i.i567 = add nuw nsw i64 %xor3.i.i.i.i566, %xor.i28.i.i.i564
  %cmp.i29.i.i.i568 = icmp eq i64 %add.i.i.i.i567, 2
  %call.i30.i.i.i569 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i568, i64 noundef %297, i64 noundef %298, i64 noundef %sub.i.i544) #16
  %conv11.i.i.i570 = zext i1 %call.i30.i.i.i569 to i8
  %of.i.i.i571 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i570, ptr %of.i.i.i571, align 1
  store ptr %299, ptr %MEMORY, align 8
  br label %304

304:                                              ; preds = %294
  %305 = load i64, ptr %NEXT_PC, align 8
  store i64 %305, ptr %PC, align 8
  %306 = add i64 %305, 3
  store i64 %306, ptr %NEXT_PC, align 8
  %307 = load i64, ptr %RAX, align 8
  %308 = load ptr, ptr %MEMORY, align 8
  store i64 %307, ptr %RCX, align 8
  store ptr %308, ptr %MEMORY, align 8
  br label %309

309:                                              ; preds = %304
  %310 = load i64, ptr %NEXT_PC, align 8
  store i64 %310, ptr %PC, align 8
  %311 = add i64 %310, 3
  store i64 %311, ptr %NEXT_PC, align 8
  %312 = load i64, ptr %RBP, align 8
  %313 = sub i64 %312, 20
  %314 = load ptr, ptr %MEMORY, align 8
  %call.i.i827 = call i32 @__remill_read_memory_32(ptr noundef %314, i64 noundef %313) #16
  %conv.i.i828 = zext i32 %call.i.i827 to i64
  store i64 %conv.i.i828, ptr %RAX, align 8
  store ptr %314, ptr %MEMORY, align 8
  br label %315

315:                                              ; preds = %309
  %316 = load i64, ptr %NEXT_PC, align 8
  store i64 %316, ptr %PC, align 8
  %317 = add i64 %316, 3
  store i64 %317, ptr %NEXT_PC, align 8
  %318 = load i64, ptr %RAX, align 8
  %319 = add i64 %318, 1
  %320 = load ptr, ptr %MEMORY, align 8
  %conv.i.i847 = and i64 %319, 4294967295
  store i64 %conv.i.i847, ptr %RDX, align 8
  store ptr %320, ptr %MEMORY, align 8
  br label %321

321:                                              ; preds = %315
  %322 = load i64, ptr %NEXT_PC, align 8
  store i64 %322, ptr %PC, align 8
  %323 = add i64 %322, 3
  store i64 %323, ptr %NEXT_PC, align 8
  %324 = load i64, ptr %RBP, align 8
  %325 = sub i64 %324, 20
  %326 = load i32, ptr %EDX, align 4
  %327 = zext i32 %326 to i64
  %328 = load ptr, ptr %MEMORY, align 8
  %call.i.i822 = call ptr @__remill_write_memory_32(ptr noundef %328, i64 noundef %325, i32 noundef %326) #16
  store ptr %call.i.i822, ptr %MEMORY, align 8
  br label %329

329:                                              ; preds = %321
  %330 = load i64, ptr %NEXT_PC, align 8
  store i64 %330, ptr %PC, align 8
  %331 = add i64 %330, 2
  store i64 %331, ptr %NEXT_PC, align 8
  %332 = load i32, ptr %ECX, align 4
  %333 = zext i32 %332 to i64
  %334 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %333, 4294967295
  store i64 %conv.i11.i, ptr %RDX, align 8
  store ptr %334, ptr %MEMORY, align 8
  br label %335

335:                                              ; preds = %329
  %336 = load i64, ptr %NEXT_PC, align 8
  store i64 %336, ptr %PC, align 8
  %337 = add i64 %336, 2
  store i64 %337, ptr %NEXT_PC, align 8
  %338 = load ptr, ptr %MEMORY, align 8
  %rax.i815 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %339 = load i32, ptr %rax.i815, align 8
  %conv.i.i816 = sext i32 %339 to i64
  store i64 %conv.i.i816, ptr %rax.i815, align 8
  store ptr %338, ptr %MEMORY, align 8
  br label %340

340:                                              ; preds = %335
  %341 = load i64, ptr %NEXT_PC, align 8
  store i64 %341, ptr %PC, align 8
  %342 = add i64 %341, 4
  store i64 %342, ptr %NEXT_PC, align 8
  %343 = load i64, ptr %RBP, align 8
  %344 = load i64, ptr %RAX, align 8
  %345 = mul i64 %344, 4
  %346 = add i64 %343, %345
  %347 = sub i64 %346, 112
  %348 = load i32, ptr %EDX, align 4
  %349 = zext i32 %348 to i64
  %350 = load ptr, ptr %MEMORY, align 8
  %call.i.i821 = call ptr @__remill_write_memory_32(ptr noundef %350, i64 noundef %347, i32 noundef %348) #16
  store ptr %call.i.i821, ptr %MEMORY, align 8
  br label %351

351:                                              ; preds = %340
  %352 = load i64, ptr %NEXT_PC, align 8
  store i64 %352, ptr %PC, align 8
  %353 = add i64 %352, 4
  store i64 %353, ptr %NEXT_PC, align 8
  %354 = load i64, ptr %RBP, align 8
  %355 = sub i64 %354, 8
  %356 = load ptr, ptr %MEMORY, align 8
  %call.i.i834 = call i64 @__remill_read_memory_64(ptr noundef %356, i64 noundef %355) #16
  store i64 %call.i.i834, ptr %RCX, align 8
  store ptr %356, ptr %MEMORY, align 8
  br label %357

357:                                              ; preds = %351
  %358 = load i64, ptr %NEXT_PC, align 8
  store i64 %358, ptr %PC, align 8
  %359 = add i64 %358, 10
  store i64 %359, ptr %NEXT_PC, align 8
  %360 = load ptr, ptr %MEMORY, align 8
  store i64 7378697629483820647, ptr %RDX, align 8
  store ptr %360, ptr %MEMORY, align 8
  br label %361

361:                                              ; preds = %357
  %362 = load i64, ptr %NEXT_PC, align 8
  store i64 %362, ptr %PC, align 8
  %363 = add i64 %362, 3
  store i64 %363, ptr %NEXT_PC, align 8
  %364 = load i64, ptr %RCX, align 8
  %365 = load ptr, ptr %MEMORY, align 8
  store i64 %364, ptr %RAX, align 8
  store ptr %365, ptr %MEMORY, align 8
  br label %366

366:                                              ; preds = %361
  %367 = load i64, ptr %NEXT_PC, align 8
  store i64 %367, ptr %PC, align 8
  %368 = add i64 %367, 3
  store i64 %368, ptr %NEXT_PC, align 8
  %369 = load i64, ptr %RDX, align 8
  %370 = load ptr, ptr %MEMORY, align 8
  %rax.i738 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %371 = load i64, ptr %rax.i738, align 8
  %372 = ashr i64 %371, 63
  %373 = ashr i64 %369, 63
  %L.sroa.2.0.insert.ext.i.i739 = zext i64 %372 to i128
  %L.sroa.2.0.insert.shift.i.i740 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i739, 64
  %L.sroa.0.0.insert.ext.i.i741 = zext i64 %371 to i128
  %L.sroa.0.0.insert.insert.i.i742 = or i128 %L.sroa.2.0.insert.shift.i.i740, %L.sroa.0.0.insert.ext.i.i741
  %R.sroa.2.0.insert.ext.i.i743 = zext i64 %373 to i128
  %R.sroa.2.0.insert.shift.i.i744 = shl nuw i128 %R.sroa.2.0.insert.ext.i.i743, 64
  %R.sroa.0.0.insert.ext.i.i745 = zext i64 %369 to i128
  %R.sroa.0.0.insert.insert.i.i746 = or i128 %R.sroa.2.0.insert.shift.i.i744, %R.sroa.0.0.insert.ext.i.i745
  %mul.i.i747 = mul nsw i128 %L.sroa.0.0.insert.insert.i.i742, %R.sroa.0.0.insert.insert.i.i746
  %retval.sroa.0.0.extract.trunc.i.i748 = trunc i128 %mul.i.i747 to i64
  %retval.sroa.2.0.extract.shift.i.i749 = lshr i128 %mul.i.i747, 64
  %retval.sroa.2.0.extract.trunc.i.i750 = trunc i128 %retval.sroa.2.0.extract.shift.i.i749 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i748, ptr %rax.i738, align 8
  %rdx.i751 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %retval.sroa.2.0.extract.trunc.i.i750, ptr %rdx.i751, align 8
  %conv2.i.i.i752 = sext i64 %retval.sroa.0.0.extract.trunc.i.i748 to i128
  %cmp.i.i.i753 = icmp ne i128 %mul.i.i747, %conv2.i.i.i752
  %call.i.i.i754 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i753, i64 noundef %371, i64 noundef %369, i64 noundef %retval.sroa.0.0.extract.trunc.i.i748, i64 noundef %retval.sroa.2.0.extract.trunc.i.i750) #16
  %frombool.i.i755 = zext i1 %call.i.i.i754 to i8
  %cf.i.i756 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i755, ptr %cf.i.i756, align 1
  %call2.i.i757 = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i758 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i757, ptr %pf.i.i758, align 1
  %af.i.i759 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i757, ptr %af.i.i759, align 1
  %zf.i.i760 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i757, ptr %zf.i.i760, align 1
  %sf.i.i761 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i757, ptr %sf.i.i761, align 1
  %of.i.i762 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i755, ptr %of.i.i762, align 1
  store ptr %370, ptr %MEMORY, align 8
  br label %374

374:                                              ; preds = %366
  %375 = load i64, ptr %NEXT_PC, align 8
  store i64 %375, ptr %PC, align 8
  %376 = add i64 %375, 3
  store i64 %376, ptr %NEXT_PC, align 8
  %377 = load i64, ptr %RDX, align 8
  %378 = load ptr, ptr %MEMORY, align 8
  store i64 %377, ptr %RAX, align 8
  store ptr %378, ptr %MEMORY, align 8
  br label %379

379:                                              ; preds = %374
  %380 = load i64, ptr %NEXT_PC, align 8
  store i64 %380, ptr %PC, align 8
  %381 = add i64 %380, 4
  store i64 %381, ptr %NEXT_PC, align 8
  %382 = load i64, ptr %RAX, align 8
  %383 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i991 = ashr i64 %382, 1
  %call36.i992 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i993 = icmp ne i8 %call36.i992, 0
  %384 = zext i1 %tobool.i993 to i8
  %new_val.0.i994 = ashr i64 %shr.i152.i991, 1
  store i64 %new_val.0.i994, ptr %RAX, align 8
  %cf.i995 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %385 = trunc i64 %shr.i152.i991 to i8
  %conv.i996 = and i8 %385, 1
  store i8 %conv.i996, ptr %cf.i995, align 1
  %pf.i997 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i998 = trunc i64 %new_val.0.i994 to i8
  %386 = call i8 @llvm.ctpop.i8(i8 %conv.i.i998)
  %387 = and i8 %386, 1
  %conv75.i999 = xor i8 %387, 1
  store i8 %conv75.i999, ptr %pf.i997, align 1
  %af.i1000 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i992, ptr %af.i1000, align 1
  %zf.i1001 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i1002 = icmp ult i64 %shr.i152.i991, 2
  %conv88.i1003 = zext i1 %cmp.i157.i1002 to i8
  store i8 %conv88.i1003, ptr %zf.i1001, align 1
  %sf.i1004 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i1005 = lshr i64 %shr.i152.i991, 63
  %conv95.i1006 = trunc i64 %new_val.0.in.lobit.i1005 to i8
  store i8 %conv95.i1006, ptr %sf.i1004, align 1
  %of.i1007 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %384, ptr %of.i1007, align 1
  store ptr %383, ptr %MEMORY, align 8
  br label %388

388:                                              ; preds = %379
  %389 = load i64, ptr %NEXT_PC, align 8
  store i64 %389, ptr %PC, align 8
  %390 = add i64 %389, 3
  store i64 %390, ptr %NEXT_PC, align 8
  %391 = load i64, ptr %RCX, align 8
  %392 = load ptr, ptr %MEMORY, align 8
  store i64 %391, ptr %RDX, align 8
  store ptr %392, ptr %MEMORY, align 8
  br label %393

393:                                              ; preds = %388
  %394 = load i64, ptr %NEXT_PC, align 8
  store i64 %394, ptr %PC, align 8
  %395 = add i64 %394, 4
  store i64 %395, ptr %NEXT_PC, align 8
  %396 = load i64, ptr %RDX, align 8
  %397 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i974 = ashr i64 %396, 62
  %call36.i975 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i976 = icmp ne i8 %call36.i975, 0
  %398 = zext i1 %tobool.i976 to i8
  %new_val.0.i977 = ashr i64 %shr.i152.i974, 1
  store i64 %new_val.0.i977, ptr %RDX, align 8
  %cf.i978 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %399 = trunc i64 %shr.i152.i974 to i8
  %conv.i979 = and i8 %399, 1
  store i8 %conv.i979, ptr %cf.i978, align 1
  %pf.i980 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i981 = trunc i64 %new_val.0.i977 to i8
  %400 = call i8 @llvm.ctpop.i8(i8 %conv.i.i981)
  %401 = and i8 %400, 1
  %conv75.i982 = xor i8 %401, 1
  store i8 %conv75.i982, ptr %pf.i980, align 1
  %af.i983 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i975, ptr %af.i983, align 1
  %zf.i984 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i985 = icmp ult i64 %shr.i152.i974, 2
  %conv88.i986 = zext i1 %cmp.i157.i985 to i8
  store i8 %conv88.i986, ptr %zf.i984, align 1
  %sf.i987 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i988 = lshr i64 %shr.i152.i974, 63
  %conv95.i989 = trunc i64 %new_val.0.in.lobit.i988 to i8
  store i8 %conv95.i989, ptr %sf.i987, align 1
  %of.i990 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %398, ptr %of.i990, align 1
  store ptr %397, ptr %MEMORY, align 8
  br label %402

402:                                              ; preds = %393
  %403 = load i64, ptr %NEXT_PC, align 8
  store i64 %403, ptr %PC, align 8
  %404 = add i64 %403, 3
  store i64 %404, ptr %NEXT_PC, align 8
  %405 = load i64, ptr %RAX, align 8
  %406 = load i64, ptr %RDX, align 8
  %407 = load ptr, ptr %MEMORY, align 8
  %sub.i.i516 = sub i64 %405, %406
  store i64 %sub.i.i516, ptr %RAX, align 8
  %cmp.i.i.i517 = icmp ult i64 %405, %406
  %call.i.i.i518 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i517, i64 noundef %405, i64 noundef %406, i64 noundef %sub.i.i516) #16
  %conv.i.i519 = zext i1 %call.i.i.i518 to i8
  %cf.i.i520 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i519, ptr %cf.i.i520, align 1
  %conv.i.i.i.i521 = trunc i64 %sub.i.i516 to i8
  %408 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i521)
  %409 = and i8 %408, 1
  %conv.i.i.i522 = xor i8 %409, 1
  %pf.i.i.i523 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i522, ptr %pf.i.i.i523, align 1
  %xor.i.i.i.i524 = xor i64 %406, %405
  %xor1.i.i.i.i525 = xor i64 %xor.i.i.i.i524, %sub.i.i516
  %410 = trunc i64 %xor1.i.i.i.i525 to i8
  %411 = lshr i8 %410, 4
  %conv2.i.i.i526 = and i8 %411, 1
  %af.i.i.i527 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i526, ptr %af.i.i.i527, align 1
  %cmp.i.i.i.i528 = icmp eq i64 %405, %406
  %call.i.i.i.i529 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i528, i64 noundef %405, i64 noundef %406, i64 noundef %sub.i.i516) #16
  %conv5.i.i.i530 = zext i1 %call.i.i.i.i529 to i8
  %zf.i.i.i531 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i530, ptr %zf.i.i.i531, align 1
  %cmp.i27.i.i.i532 = icmp slt i64 %sub.i.i516, 0
  %call1.i.i.i.i533 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i532, i64 noundef %405, i64 noundef %406, i64 noundef %sub.i.i516) #16
  %conv8.i.i.i534 = zext i1 %call1.i.i.i.i533 to i8
  %sf.i.i.i535 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i534, ptr %sf.i.i.i535, align 1
  %xor.i28.i.i.i536 = lshr i64 %xor.i.i.i.i524, 63
  %shr9.i.i.i.i537 = xor i64 %sub.i.i516, %405
  %xor3.i.i.i.i538 = lshr i64 %shr9.i.i.i.i537, 63
  %add.i.i.i.i539 = add nuw nsw i64 %xor3.i.i.i.i538, %xor.i28.i.i.i536
  %cmp.i29.i.i.i540 = icmp eq i64 %add.i.i.i.i539, 2
  %call.i30.i.i.i541 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i540, i64 noundef %405, i64 noundef %406, i64 noundef %sub.i.i516) #16
  %conv11.i.i.i542 = zext i1 %call.i30.i.i.i541 to i8
  %of.i.i.i543 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i542, ptr %of.i.i.i543, align 1
  store ptr %407, ptr %MEMORY, align 8
  br label %412

412:                                              ; preds = %402
  %413 = load i64, ptr %NEXT_PC, align 8
  store i64 %413, ptr %PC, align 8
  %414 = add i64 %413, 3
  store i64 %414, ptr %NEXT_PC, align 8
  %415 = load i64, ptr %RAX, align 8
  %416 = load ptr, ptr %MEMORY, align 8
  store i64 %415, ptr %RSI, align 8
  store ptr %416, ptr %MEMORY, align 8
  br label %417

417:                                              ; preds = %412
  %418 = load i64, ptr %NEXT_PC, align 8
  store i64 %418, ptr %PC, align 8
  %419 = add i64 %418, 3
  store i64 %419, ptr %NEXT_PC, align 8
  %420 = load i64, ptr %RSI, align 8
  %421 = load ptr, ptr %MEMORY, align 8
  store i64 %420, ptr %RAX, align 8
  store ptr %421, ptr %MEMORY, align 8
  br label %422

422:                                              ; preds = %417
  %423 = load i64, ptr %NEXT_PC, align 8
  store i64 %423, ptr %PC, align 8
  %424 = add i64 %423, 4
  store i64 %424, ptr %NEXT_PC, align 8
  %425 = load i64, ptr %RAX, align 8
  %426 = load ptr, ptr %MEMORY, align 8
  %shl.i145.i1086 = shl i64 %425, 1
  %call42.i1087 = call zeroext i8 @__remill_undefined_8() #17
  %tobool43.i1088 = icmp ne i8 %call42.i1087, 0
  %shl.i147.i1089 = shl i64 %shl.i145.i1086, 1
  store i64 %shl.i147.i1089, ptr %RAX, align 8
  %cf.i1091 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i1092 = lshr i64 %shl.i145.i1086, 63
  %conv.i1093 = trunc i64 %new_cf.0.shrunk.in.lobit.i1092 to i8
  store i8 %conv.i1093, ptr %cf.i1091, align 1
  %pf.i1094 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1095 = trunc i64 %shl.i147.i1089 to i8
  %427 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1095)
  %428 = and i8 %427, 1
  %conv72.i1096 = xor i8 %428, 1
  store i8 %conv72.i1096, ptr %pf.i1094, align 1
  %af.i1097 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i1087, ptr %af.i1097, align 1
  %zf.i1098 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i148.i1099 = icmp eq i64 %shl.i147.i1089, 0
  %conv85.i1100 = zext i1 %cmp.i148.i1099 to i8
  store i8 %conv85.i1100, ptr %zf.i1098, align 1
  %sf.i1101 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i1102 = lshr i64 %shl.i147.i1089, 63
  %conv92.i1103 = trunc i64 %new_val.0.lobit.i1102 to i8
  store i8 %conv92.i1103, ptr %sf.i1101, align 1
  %of.i1104 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %conv99.i1105 = zext i1 %tobool43.i1088 to i8
  store i8 %conv99.i1105, ptr %of.i1104, align 1
  store ptr %426, ptr %MEMORY, align 8
  br label %429

429:                                              ; preds = %422
  %430 = load i64, ptr %NEXT_PC, align 8
  store i64 %430, ptr %PC, align 8
  %431 = add i64 %430, 3
  store i64 %431, ptr %NEXT_PC, align 8
  %432 = load i64, ptr %RAX, align 8
  %433 = load i64, ptr %RSI, align 8
  %434 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 %433, %432
  store i64 %add.i.i146, ptr %RAX, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %432
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, %433
  %435 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %435, i64 noundef %432, i64 noundef %433, i64 noundef %add.i.i146) #16
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %436 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %437 = and i8 %436, 1
  %conv.i.i.i153 = xor i8 %437, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, %433
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %432
  %438 = trunc i64 %xor1.i.i.i.i156 to i8
  %439 = lshr i8 %438, 4
  %conv2.i.i.i157 = and i8 %439, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %432, i64 noundef %433, i64 noundef %add.i.i146) #16
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %432, i64 noundef %433, i64 noundef %add.i.i146) #16
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %432
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %432, i64 noundef %433, i64 noundef %add.i.i146) #16
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %434, ptr %MEMORY, align 8
  br label %440

440:                                              ; preds = %429
  %441 = load i64, ptr %NEXT_PC, align 8
  store i64 %441, ptr %PC, align 8
  %442 = add i64 %441, 3
  store i64 %442, ptr %NEXT_PC, align 8
  %443 = load i64, ptr %RAX, align 8
  %444 = load i64, ptr %RAX, align 8
  %445 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 %444, %443
  store i64 %add.i.i117, ptr %RAX, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %443
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, %444
  %446 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %446, i64 noundef %443, i64 noundef %444, i64 noundef %add.i.i117) #16
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %447 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %448 = and i8 %447, 1
  %conv.i.i.i124 = xor i8 %448, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, %444
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %443
  %449 = trunc i64 %xor1.i.i.i.i127 to i8
  %450 = lshr i8 %449, 4
  %conv2.i.i.i128 = and i8 %450, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %443, i64 noundef %444, i64 noundef %add.i.i117) #16
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %443, i64 noundef %444, i64 noundef %add.i.i117) #16
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %443
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %443, i64 noundef %444, i64 noundef %add.i.i117) #16
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %445, ptr %MEMORY, align 8
  br label %451

451:                                              ; preds = %440
  %452 = load i64, ptr %NEXT_PC, align 8
  store i64 %452, ptr %PC, align 8
  %453 = add i64 %452, 3
  store i64 %453, ptr %NEXT_PC, align 8
  %454 = load i64, ptr %RCX, align 8
  %455 = load ptr, ptr %MEMORY, align 8
  store i64 %454, ptr %RSI, align 8
  store ptr %455, ptr %MEMORY, align 8
  br label %456

456:                                              ; preds = %451
  %457 = load i64, ptr %NEXT_PC, align 8
  store i64 %457, ptr %PC, align 8
  %458 = add i64 %457, 3
  store i64 %458, ptr %NEXT_PC, align 8
  %459 = load i64, ptr %RSI, align 8
  %460 = load i64, ptr %RAX, align 8
  %461 = load ptr, ptr %MEMORY, align 8
  %sub.i.i488 = sub i64 %459, %460
  store i64 %sub.i.i488, ptr %RSI, align 8
  %cmp.i.i.i489 = icmp ult i64 %459, %460
  %call.i.i.i490 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i489, i64 noundef %459, i64 noundef %460, i64 noundef %sub.i.i488) #16
  %conv.i.i491 = zext i1 %call.i.i.i490 to i8
  %cf.i.i492 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i491, ptr %cf.i.i492, align 1
  %conv.i.i.i.i493 = trunc i64 %sub.i.i488 to i8
  %462 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i493)
  %463 = and i8 %462, 1
  %conv.i.i.i494 = xor i8 %463, 1
  %pf.i.i.i495 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i494, ptr %pf.i.i.i495, align 1
  %xor.i.i.i.i496 = xor i64 %460, %459
  %xor1.i.i.i.i497 = xor i64 %xor.i.i.i.i496, %sub.i.i488
  %464 = trunc i64 %xor1.i.i.i.i497 to i8
  %465 = lshr i8 %464, 4
  %conv2.i.i.i498 = and i8 %465, 1
  %af.i.i.i499 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i498, ptr %af.i.i.i499, align 1
  %cmp.i.i.i.i500 = icmp eq i64 %459, %460
  %call.i.i.i.i501 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i500, i64 noundef %459, i64 noundef %460, i64 noundef %sub.i.i488) #16
  %conv5.i.i.i502 = zext i1 %call.i.i.i.i501 to i8
  %zf.i.i.i503 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i502, ptr %zf.i.i.i503, align 1
  %cmp.i27.i.i.i504 = icmp slt i64 %sub.i.i488, 0
  %call1.i.i.i.i505 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i504, i64 noundef %459, i64 noundef %460, i64 noundef %sub.i.i488) #16
  %conv8.i.i.i506 = zext i1 %call1.i.i.i.i505 to i8
  %sf.i.i.i507 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i506, ptr %sf.i.i.i507, align 1
  %xor.i28.i.i.i508 = lshr i64 %xor.i.i.i.i496, 63
  %shr9.i.i.i.i509 = xor i64 %sub.i.i488, %459
  %xor3.i.i.i.i510 = lshr i64 %shr9.i.i.i.i509, 63
  %add.i.i.i.i511 = add nuw nsw i64 %xor3.i.i.i.i510, %xor.i28.i.i.i508
  %cmp.i29.i.i.i512 = icmp eq i64 %add.i.i.i.i511, 2
  %call.i30.i.i.i513 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i512, i64 noundef %459, i64 noundef %460, i64 noundef %sub.i.i488) #16
  %conv11.i.i.i514 = zext i1 %call.i30.i.i.i513 to i8
  %of.i.i.i515 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i514, ptr %of.i.i.i515, align 1
  store ptr %461, ptr %MEMORY, align 8
  br label %466

466:                                              ; preds = %456
  %467 = load i64, ptr %NEXT_PC, align 8
  store i64 %467, ptr %PC, align 8
  %468 = add i64 %467, 4
  store i64 %468, ptr %NEXT_PC, align 8
  %469 = load i64, ptr %RBP, align 8
  %470 = sub i64 %469, 16
  %471 = load ptr, ptr %MEMORY, align 8
  %call.i.i833 = call i64 @__remill_read_memory_64(ptr noundef %471, i64 noundef %470) #16
  store i64 %call.i.i833, ptr %RCX, align 8
  store ptr %471, ptr %MEMORY, align 8
  br label %472

472:                                              ; preds = %466
  %473 = load i64, ptr %NEXT_PC, align 8
  store i64 %473, ptr %PC, align 8
  %474 = add i64 %473, 10
  store i64 %474, ptr %NEXT_PC, align 8
  %475 = load ptr, ptr %MEMORY, align 8
  store i64 7378697629483820647, ptr %RDX, align 8
  store ptr %475, ptr %MEMORY, align 8
  br label %476

476:                                              ; preds = %472
  %477 = load i64, ptr %NEXT_PC, align 8
  store i64 %477, ptr %PC, align 8
  %478 = add i64 %477, 3
  store i64 %478, ptr %NEXT_PC, align 8
  %479 = load i64, ptr %RCX, align 8
  %480 = load ptr, ptr %MEMORY, align 8
  store i64 %479, ptr %RAX, align 8
  store ptr %480, ptr %MEMORY, align 8
  br label %481

481:                                              ; preds = %476
  %482 = load i64, ptr %NEXT_PC, align 8
  store i64 %482, ptr %PC, align 8
  %483 = add i64 %482, 3
  store i64 %483, ptr %NEXT_PC, align 8
  %484 = load i64, ptr %RDX, align 8
  %485 = load ptr, ptr %MEMORY, align 8
  %rax.i713 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %486 = load i64, ptr %rax.i713, align 8
  %487 = ashr i64 %486, 63
  %488 = ashr i64 %484, 63
  %L.sroa.2.0.insert.ext.i.i714 = zext i64 %487 to i128
  %L.sroa.2.0.insert.shift.i.i715 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i714, 64
  %L.sroa.0.0.insert.ext.i.i716 = zext i64 %486 to i128
  %L.sroa.0.0.insert.insert.i.i717 = or i128 %L.sroa.2.0.insert.shift.i.i715, %L.sroa.0.0.insert.ext.i.i716
  %R.sroa.2.0.insert.ext.i.i718 = zext i64 %488 to i128
  %R.sroa.2.0.insert.shift.i.i719 = shl nuw i128 %R.sroa.2.0.insert.ext.i.i718, 64
  %R.sroa.0.0.insert.ext.i.i720 = zext i64 %484 to i128
  %R.sroa.0.0.insert.insert.i.i721 = or i128 %R.sroa.2.0.insert.shift.i.i719, %R.sroa.0.0.insert.ext.i.i720
  %mul.i.i722 = mul nsw i128 %L.sroa.0.0.insert.insert.i.i717, %R.sroa.0.0.insert.insert.i.i721
  %retval.sroa.0.0.extract.trunc.i.i723 = trunc i128 %mul.i.i722 to i64
  %retval.sroa.2.0.extract.shift.i.i724 = lshr i128 %mul.i.i722, 64
  %retval.sroa.2.0.extract.trunc.i.i725 = trunc i128 %retval.sroa.2.0.extract.shift.i.i724 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i723, ptr %rax.i713, align 8
  %rdx.i726 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %retval.sroa.2.0.extract.trunc.i.i725, ptr %rdx.i726, align 8
  %conv2.i.i.i727 = sext i64 %retval.sroa.0.0.extract.trunc.i.i723 to i128
  %cmp.i.i.i728 = icmp ne i128 %mul.i.i722, %conv2.i.i.i727
  %call.i.i.i729 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i728, i64 noundef %486, i64 noundef %484, i64 noundef %retval.sroa.0.0.extract.trunc.i.i723, i64 noundef %retval.sroa.2.0.extract.trunc.i.i725) #16
  %frombool.i.i730 = zext i1 %call.i.i.i729 to i8
  %cf.i.i731 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i730, ptr %cf.i.i731, align 1
  %call2.i.i732 = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i733 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i732, ptr %pf.i.i733, align 1
  %af.i.i734 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i732, ptr %af.i.i734, align 1
  %zf.i.i735 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i732, ptr %zf.i.i735, align 1
  %sf.i.i736 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i732, ptr %sf.i.i736, align 1
  %of.i.i737 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i730, ptr %of.i.i737, align 1
  store ptr %485, ptr %MEMORY, align 8
  br label %489

489:                                              ; preds = %481
  %490 = load i64, ptr %NEXT_PC, align 8
  store i64 %490, ptr %PC, align 8
  %491 = add i64 %490, 3
  store i64 %491, ptr %NEXT_PC, align 8
  %492 = load i64, ptr %RDX, align 8
  %493 = load ptr, ptr %MEMORY, align 8
  store i64 %492, ptr %RAX, align 8
  store ptr %493, ptr %MEMORY, align 8
  br label %494

494:                                              ; preds = %489
  %495 = load i64, ptr %NEXT_PC, align 8
  store i64 %495, ptr %PC, align 8
  %496 = add i64 %495, 4
  store i64 %496, ptr %NEXT_PC, align 8
  %497 = load i64, ptr %RAX, align 8
  %498 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i957 = ashr i64 %497, 1
  %call36.i958 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i959 = icmp ne i8 %call36.i958, 0
  %499 = zext i1 %tobool.i959 to i8
  %new_val.0.i960 = ashr i64 %shr.i152.i957, 1
  store i64 %new_val.0.i960, ptr %RAX, align 8
  %cf.i961 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %500 = trunc i64 %shr.i152.i957 to i8
  %conv.i962 = and i8 %500, 1
  store i8 %conv.i962, ptr %cf.i961, align 1
  %pf.i963 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i964 = trunc i64 %new_val.0.i960 to i8
  %501 = call i8 @llvm.ctpop.i8(i8 %conv.i.i964)
  %502 = and i8 %501, 1
  %conv75.i965 = xor i8 %502, 1
  store i8 %conv75.i965, ptr %pf.i963, align 1
  %af.i966 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i958, ptr %af.i966, align 1
  %zf.i967 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i968 = icmp ult i64 %shr.i152.i957, 2
  %conv88.i969 = zext i1 %cmp.i157.i968 to i8
  store i8 %conv88.i969, ptr %zf.i967, align 1
  %sf.i970 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i971 = lshr i64 %shr.i152.i957, 63
  %conv95.i972 = trunc i64 %new_val.0.in.lobit.i971 to i8
  store i8 %conv95.i972, ptr %sf.i970, align 1
  %of.i973 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %499, ptr %of.i973, align 1
  store ptr %498, ptr %MEMORY, align 8
  br label %503

503:                                              ; preds = %494
  %504 = load i64, ptr %NEXT_PC, align 8
  store i64 %504, ptr %PC, align 8
  %505 = add i64 %504, 3
  store i64 %505, ptr %NEXT_PC, align 8
  %506 = load i64, ptr %RCX, align 8
  %507 = load ptr, ptr %MEMORY, align 8
  store i64 %506, ptr %RDI, align 8
  store ptr %507, ptr %MEMORY, align 8
  br label %508

508:                                              ; preds = %503
  %509 = load i64, ptr %NEXT_PC, align 8
  store i64 %509, ptr %PC, align 8
  %510 = add i64 %509, 4
  store i64 %510, ptr %NEXT_PC, align 8
  %511 = load i64, ptr %RDI, align 8
  %512 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i940 = ashr i64 %511, 62
  %call36.i941 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i942 = icmp ne i8 %call36.i941, 0
  %513 = zext i1 %tobool.i942 to i8
  %new_val.0.i943 = ashr i64 %shr.i152.i940, 1
  store i64 %new_val.0.i943, ptr %RDI, align 8
  %cf.i944 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %514 = trunc i64 %shr.i152.i940 to i8
  %conv.i945 = and i8 %514, 1
  store i8 %conv.i945, ptr %cf.i944, align 1
  %pf.i946 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i947 = trunc i64 %new_val.0.i943 to i8
  %515 = call i8 @llvm.ctpop.i8(i8 %conv.i.i947)
  %516 = and i8 %515, 1
  %conv75.i948 = xor i8 %516, 1
  store i8 %conv75.i948, ptr %pf.i946, align 1
  %af.i949 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i941, ptr %af.i949, align 1
  %zf.i950 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i951 = icmp ult i64 %shr.i152.i940, 2
  %conv88.i952 = zext i1 %cmp.i157.i951 to i8
  store i8 %conv88.i952, ptr %zf.i950, align 1
  %sf.i953 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i954 = lshr i64 %shr.i152.i940, 63
  %conv95.i955 = trunc i64 %new_val.0.in.lobit.i954 to i8
  store i8 %conv95.i955, ptr %sf.i953, align 1
  %of.i956 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %513, ptr %of.i956, align 1
  store ptr %512, ptr %MEMORY, align 8
  br label %517

517:                                              ; preds = %508
  %518 = load i64, ptr %NEXT_PC, align 8
  store i64 %518, ptr %PC, align 8
  %519 = add i64 %518, 3
  store i64 %519, ptr %NEXT_PC, align 8
  %520 = load i64, ptr %RAX, align 8
  %521 = load i64, ptr %RDI, align 8
  %522 = load ptr, ptr %MEMORY, align 8
  %sub.i.i460 = sub i64 %520, %521
  store i64 %sub.i.i460, ptr %RAX, align 8
  %cmp.i.i.i461 = icmp ult i64 %520, %521
  %call.i.i.i462 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i461, i64 noundef %520, i64 noundef %521, i64 noundef %sub.i.i460) #16
  %conv.i.i463 = zext i1 %call.i.i.i462 to i8
  %cf.i.i464 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i463, ptr %cf.i.i464, align 1
  %conv.i.i.i.i465 = trunc i64 %sub.i.i460 to i8
  %523 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i465)
  %524 = and i8 %523, 1
  %conv.i.i.i466 = xor i8 %524, 1
  %pf.i.i.i467 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i466, ptr %pf.i.i.i467, align 1
  %xor.i.i.i.i468 = xor i64 %521, %520
  %xor1.i.i.i.i469 = xor i64 %xor.i.i.i.i468, %sub.i.i460
  %525 = trunc i64 %xor1.i.i.i.i469 to i8
  %526 = lshr i8 %525, 4
  %conv2.i.i.i470 = and i8 %526, 1
  %af.i.i.i471 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i470, ptr %af.i.i.i471, align 1
  %cmp.i.i.i.i472 = icmp eq i64 %520, %521
  %call.i.i.i.i473 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i472, i64 noundef %520, i64 noundef %521, i64 noundef %sub.i.i460) #16
  %conv5.i.i.i474 = zext i1 %call.i.i.i.i473 to i8
  %zf.i.i.i475 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i474, ptr %zf.i.i.i475, align 1
  %cmp.i27.i.i.i476 = icmp slt i64 %sub.i.i460, 0
  %call1.i.i.i.i477 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i476, i64 noundef %520, i64 noundef %521, i64 noundef %sub.i.i460) #16
  %conv8.i.i.i478 = zext i1 %call1.i.i.i.i477 to i8
  %sf.i.i.i479 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i478, ptr %sf.i.i.i479, align 1
  %xor.i28.i.i.i480 = lshr i64 %xor.i.i.i.i468, 63
  %shr9.i.i.i.i481 = xor i64 %sub.i.i460, %520
  %xor3.i.i.i.i482 = lshr i64 %shr9.i.i.i.i481, 63
  %add.i.i.i.i483 = add nuw nsw i64 %xor3.i.i.i.i482, %xor.i28.i.i.i480
  %cmp.i29.i.i.i484 = icmp eq i64 %add.i.i.i.i483, 2
  %call.i30.i.i.i485 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i484, i64 noundef %520, i64 noundef %521, i64 noundef %sub.i.i460) #16
  %conv11.i.i.i486 = zext i1 %call.i30.i.i.i485 to i8
  %of.i.i.i487 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i486, ptr %of.i.i.i487, align 1
  store ptr %522, ptr %MEMORY, align 8
  br label %527

527:                                              ; preds = %517
  %528 = load i64, ptr %NEXT_PC, align 8
  store i64 %528, ptr %PC, align 8
  %529 = add i64 %528, 3
  store i64 %529, ptr %NEXT_PC, align 8
  %530 = load i64, ptr %RAX, align 8
  %531 = load ptr, ptr %MEMORY, align 8
  store i64 %530, ptr %RDX, align 8
  store ptr %531, ptr %MEMORY, align 8
  br label %532

532:                                              ; preds = %527
  %533 = load i64, ptr %NEXT_PC, align 8
  store i64 %533, ptr %PC, align 8
  %534 = add i64 %533, 3
  store i64 %534, ptr %NEXT_PC, align 8
  %535 = load i64, ptr %RDX, align 8
  %536 = load ptr, ptr %MEMORY, align 8
  store i64 %535, ptr %RAX, align 8
  store ptr %536, ptr %MEMORY, align 8
  br label %537

537:                                              ; preds = %532
  %538 = load i64, ptr %NEXT_PC, align 8
  store i64 %538, ptr %PC, align 8
  %539 = add i64 %538, 4
  store i64 %539, ptr %NEXT_PC, align 8
  %540 = load i64, ptr %RAX, align 8
  %541 = load ptr, ptr %MEMORY, align 8
  %shl.i145.i = shl i64 %540, 1
  %call42.i = call zeroext i8 @__remill_undefined_8() #17
  %tobool43.i = icmp ne i8 %call42.i, 0
  %shl.i147.i = shl i64 %shl.i145.i, 1
  store i64 %shl.i147.i, ptr %RAX, align 8
  %cf.i1077 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %new_cf.0.shrunk.in.lobit.i = lshr i64 %shl.i145.i, 63
  %conv.i1078 = trunc i64 %new_cf.0.shrunk.in.lobit.i to i8
  store i8 %conv.i1078, ptr %cf.i1077, align 1
  %pf.i1079 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i1080 = trunc i64 %shl.i147.i to i8
  %542 = call i8 @llvm.ctpop.i8(i8 %conv.i.i1080)
  %543 = and i8 %542, 1
  %conv72.i = xor i8 %543, 1
  store i8 %conv72.i, ptr %pf.i1079, align 1
  %af.i1081 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call42.i, ptr %af.i1081, align 1
  %zf.i1082 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i148.i = icmp eq i64 %shl.i147.i, 0
  %conv85.i = zext i1 %cmp.i148.i to i8
  store i8 %conv85.i, ptr %zf.i1082, align 1
  %sf.i1083 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.lobit.i = lshr i64 %shl.i147.i, 63
  %conv92.i1084 = trunc i64 %new_val.0.lobit.i to i8
  store i8 %conv92.i1084, ptr %sf.i1083, align 1
  %of.i1085 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %conv99.i = zext i1 %tobool43.i to i8
  store i8 %conv99.i, ptr %of.i1085, align 1
  store ptr %541, ptr %MEMORY, align 8
  br label %544

544:                                              ; preds = %537
  %545 = load i64, ptr %NEXT_PC, align 8
  store i64 %545, ptr %PC, align 8
  %546 = add i64 %545, 3
  store i64 %546, ptr %NEXT_PC, align 8
  %547 = load i64, ptr %RAX, align 8
  %548 = load i64, ptr %RDX, align 8
  %549 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 %548, %547
  store i64 %add.i.i88, ptr %RAX, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %547
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, %548
  %550 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %550, i64 noundef %547, i64 noundef %548, i64 noundef %add.i.i88) #16
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %551 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %552 = and i8 %551, 1
  %conv.i.i.i95 = xor i8 %552, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, %548
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %547
  %553 = trunc i64 %xor1.i.i.i.i98 to i8
  %554 = lshr i8 %553, 4
  %conv2.i.i.i99 = and i8 %554, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %547, i64 noundef %548, i64 noundef %add.i.i88) #16
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %547, i64 noundef %548, i64 noundef %add.i.i88) #16
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %547
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %547, i64 noundef %548, i64 noundef %add.i.i88) #16
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %549, ptr %MEMORY, align 8
  br label %555

555:                                              ; preds = %544
  %556 = load i64, ptr %NEXT_PC, align 8
  store i64 %556, ptr %PC, align 8
  %557 = add i64 %556, 3
  store i64 %557, ptr %NEXT_PC, align 8
  %558 = load i64, ptr %RAX, align 8
  %559 = load i64, ptr %RAX, align 8
  %560 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 %559, %558
  store i64 %add.i.i59, ptr %RAX, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %558
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, %559
  %561 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %561, i64 noundef %558, i64 noundef %559, i64 noundef %add.i.i59) #16
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %562 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %563 = and i8 %562, 1
  %conv.i.i.i66 = xor i8 %563, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, %559
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %558
  %564 = trunc i64 %xor1.i.i.i.i69 to i8
  %565 = lshr i8 %564, 4
  %conv2.i.i.i70 = and i8 %565, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %558, i64 noundef %559, i64 noundef %add.i.i59) #16
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %558, i64 noundef %559, i64 noundef %add.i.i59) #16
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %558
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %558, i64 noundef %559, i64 noundef %add.i.i59) #16
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %560, ptr %MEMORY, align 8
  br label %566

566:                                              ; preds = %555
  %567 = load i64, ptr %NEXT_PC, align 8
  store i64 %567, ptr %PC, align 8
  %568 = add i64 %567, 3
  store i64 %568, ptr %NEXT_PC, align 8
  %569 = load i64, ptr %RCX, align 8
  %570 = load i64, ptr %RAX, align 8
  %571 = load ptr, ptr %MEMORY, align 8
  %sub.i.i432 = sub i64 %569, %570
  store i64 %sub.i.i432, ptr %RCX, align 8
  %cmp.i.i.i433 = icmp ult i64 %569, %570
  %call.i.i.i434 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i433, i64 noundef %569, i64 noundef %570, i64 noundef %sub.i.i432) #16
  %conv.i.i435 = zext i1 %call.i.i.i434 to i8
  %cf.i.i436 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i435, ptr %cf.i.i436, align 1
  %conv.i.i.i.i437 = trunc i64 %sub.i.i432 to i8
  %572 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i437)
  %573 = and i8 %572, 1
  %conv.i.i.i438 = xor i8 %573, 1
  %pf.i.i.i439 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i438, ptr %pf.i.i.i439, align 1
  %xor.i.i.i.i440 = xor i64 %570, %569
  %xor1.i.i.i.i441 = xor i64 %xor.i.i.i.i440, %sub.i.i432
  %574 = trunc i64 %xor1.i.i.i.i441 to i8
  %575 = lshr i8 %574, 4
  %conv2.i.i.i442 = and i8 %575, 1
  %af.i.i.i443 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i442, ptr %af.i.i.i443, align 1
  %cmp.i.i.i.i444 = icmp eq i64 %569, %570
  %call.i.i.i.i445 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i444, i64 noundef %569, i64 noundef %570, i64 noundef %sub.i.i432) #16
  %conv5.i.i.i446 = zext i1 %call.i.i.i.i445 to i8
  %zf.i.i.i447 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i446, ptr %zf.i.i.i447, align 1
  %cmp.i27.i.i.i448 = icmp slt i64 %sub.i.i432, 0
  %call1.i.i.i.i449 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i448, i64 noundef %569, i64 noundef %570, i64 noundef %sub.i.i432) #16
  %conv8.i.i.i450 = zext i1 %call1.i.i.i.i449 to i8
  %sf.i.i.i451 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i450, ptr %sf.i.i.i451, align 1
  %xor.i28.i.i.i452 = lshr i64 %xor.i.i.i.i440, 63
  %shr9.i.i.i.i453 = xor i64 %sub.i.i432, %569
  %xor3.i.i.i.i454 = lshr i64 %shr9.i.i.i.i453, 63
  %add.i.i.i.i455 = add nuw nsw i64 %xor3.i.i.i.i454, %xor.i28.i.i.i452
  %cmp.i29.i.i.i456 = icmp eq i64 %add.i.i.i.i455, 2
  %call.i30.i.i.i457 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i456, i64 noundef %569, i64 noundef %570, i64 noundef %sub.i.i432) #16
  %conv11.i.i.i458 = zext i1 %call.i30.i.i.i457 to i8
  %of.i.i.i459 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i458, ptr %of.i.i.i459, align 1
  store ptr %571, ptr %MEMORY, align 8
  br label %576

576:                                              ; preds = %566
  %577 = load i64, ptr %NEXT_PC, align 8
  store i64 %577, ptr %PC, align 8
  %578 = add i64 %577, 3
  store i64 %578, ptr %NEXT_PC, align 8
  %579 = load i64, ptr %RCX, align 8
  %580 = load ptr, ptr %MEMORY, align 8
  store i64 %579, ptr %RDX, align 8
  store ptr %580, ptr %MEMORY, align 8
  br label %581

581:                                              ; preds = %576
  %582 = load i64, ptr %NEXT_PC, align 8
  store i64 %582, ptr %PC, align 8
  %583 = add i64 %582, 3
  store i64 %583, ptr %NEXT_PC, align 8
  %584 = load i64, ptr %RDX, align 8
  %585 = load i64, ptr %RSI, align 8
  %586 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 %585, %584
  store i64 %add.i.i30, ptr %RDX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %584
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, %585
  %587 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %587, i64 noundef %584, i64 noundef %585, i64 noundef %add.i.i30) #16
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %588 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %589 = and i8 %588, 1
  %conv.i.i.i37 = xor i8 %589, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, %585
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %584
  %590 = trunc i64 %xor1.i.i.i.i40 to i8
  %591 = lshr i8 %590, 4
  %conv2.i.i.i41 = and i8 %591, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %584, i64 noundef %585, i64 noundef %add.i.i30) #16
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %584, i64 noundef %585, i64 noundef %add.i.i30) #16
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %584
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %584, i64 noundef %585, i64 noundef %add.i.i30) #16
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %586, ptr %MEMORY, align 8
  br label %592

592:                                              ; preds = %581
  %593 = load i64, ptr %NEXT_PC, align 8
  store i64 %593, ptr %PC, align 8
  %594 = add i64 %593, 3
  store i64 %594, ptr %NEXT_PC, align 8
  %595 = load i64, ptr %RBP, align 8
  %596 = sub i64 %595, 24
  %597 = load ptr, ptr %MEMORY, align 8
  %call.i.i825 = call i32 @__remill_read_memory_32(ptr noundef %597, i64 noundef %596) #16
  %conv.i.i826 = zext i32 %call.i.i825 to i64
  store i64 %conv.i.i826, ptr %RAX, align 8
  store ptr %597, ptr %MEMORY, align 8
  br label %598

598:                                              ; preds = %592
  %599 = load i64, ptr %NEXT_PC, align 8
  store i64 %599, ptr %PC, align 8
  %600 = add i64 %599, 2
  store i64 %600, ptr %NEXT_PC, align 8
  %601 = load ptr, ptr %MEMORY, align 8
  %rax.i813 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %602 = load i32, ptr %rax.i813, align 8
  %conv.i.i814 = sext i32 %602 to i64
  store i64 %conv.i.i814, ptr %rax.i813, align 8
  store ptr %601, ptr %MEMORY, align 8
  br label %603

603:                                              ; preds = %598
  %604 = load i64, ptr %NEXT_PC, align 8
  store i64 %604, ptr %PC, align 8
  %605 = add i64 %604, 3
  store i64 %605, ptr %NEXT_PC, align 8
  %606 = load i64, ptr %RAX, align 8
  %607 = load i64, ptr %RDX, align 8
  %608 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 %607, %606
  store i64 %add.i.i1, ptr %RAX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %606
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, %607
  %609 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %609, i64 noundef %606, i64 noundef %607, i64 noundef %add.i.i1) #16
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %610 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %611 = and i8 %610, 1
  %conv.i.i.i8 = xor i8 %611, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, %607
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %606
  %612 = trunc i64 %xor1.i.i.i.i11 to i8
  %613 = lshr i8 %612, 4
  %conv2.i.i.i12 = and i8 %613, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %606, i64 noundef %607, i64 noundef %add.i.i1) #16
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %606, i64 noundef %607, i64 noundef %add.i.i1) #16
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %606
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %606, i64 noundef %607, i64 noundef %add.i.i1) #16
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %608, ptr %MEMORY, align 8
  br label %614

614:                                              ; preds = %603
  %615 = load i64, ptr %NEXT_PC, align 8
  store i64 %615, ptr %PC, align 8
  %616 = add i64 %615, 3
  store i64 %616, ptr %NEXT_PC, align 8
  %617 = load i64, ptr %RAX, align 8
  %618 = load ptr, ptr %MEMORY, align 8
  store i64 %617, ptr %RDX, align 8
  store ptr %618, ptr %MEMORY, align 8
  br label %619

619:                                              ; preds = %614
  %620 = load i64, ptr %NEXT_PC, align 8
  store i64 %620, ptr %PC, align 8
  %621 = add i64 %620, 4
  store i64 %621, ptr %NEXT_PC, align 8
  %622 = load i64, ptr %RDX, align 8
  %623 = load ptr, ptr %MEMORY, align 8
  %shr.i136.i = lshr i64 %622, 62
  %call34.i = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i = icmp ne i8 %call34.i, 0
  %new_val.0.i = lshr i64 %shr.i136.i, 1
  store i64 %new_val.0.i, ptr %RDX, align 8
  %cf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %624 = trunc i64 %shr.i136.i to i8
  %conv.i = and i8 %624, 1
  store i8 %conv.i, ptr %cf.i, align 1
  %pf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i848 = trunc i64 %new_val.0.i to i8
  %625 = call i8 @llvm.ctpop.i8(i8 %conv.i.i848)
  %626 = and i8 %625, 1
  %conv67.i = xor i8 %626, 1
  store i8 %conv67.i, ptr %pf.i, align 1
  %af.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call34.i, ptr %af.i, align 1
  %zf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i140.i = icmp ult i64 %shr.i136.i, 2
  %conv80.i = zext i1 %cmp.i140.i to i8
  store i8 %conv80.i, ptr %zf.i, align 1
  %sf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 0, ptr %sf.i, align 1
  %of.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  %conv92.i = zext i1 %tobool.i to i8
  store i8 %conv92.i, ptr %of.i, align 1
  store ptr %623, ptr %MEMORY, align 8
  br label %627

627:                                              ; preds = %619
  %628 = load i64, ptr %NEXT_PC, align 8
  store i64 %628, ptr %PC, align 8
  %629 = add i64 %628, 3
  store i64 %629, ptr %NEXT_PC, align 8
  %630 = load i64, ptr %RAX, align 8
  %631 = load i64, ptr %RDX, align 8
  %632 = load ptr, ptr %MEMORY, align 8
  %add.i.i = add i64 %631, %630
  store i64 %add.i.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i64 %add.i.i, %630
  %cmp1.i.i.i = icmp ult i64 %add.i.i, %631
  %633 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %633, i64 noundef %630, i64 noundef %631, i64 noundef %add.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %add.i.i to i8
  %634 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %635 = and i8 %634, 1
  %conv.i.i.i = xor i8 %635, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i64 %add.i.i, %631
  %xor1.i.i.i.i = xor i64 %xor.i.i.i.i, %630
  %636 = trunc i64 %xor1.i.i.i.i to i8
  %637 = lshr i8 %636, 4
  %conv2.i.i.i = and i8 %637, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %630, i64 noundef %631, i64 noundef %add.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %630, i64 noundef %631, i64 noundef %add.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i64 %add.i.i, %630
  %xor.i28.i.i.i = lshr i64 %shr8.i.i.i.i, 63
  %xor3.i.i.i.i = lshr i64 %xor.i.i.i.i, 63
  %add.i.i.i.i = add nuw nsw i64 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i64 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i64 noundef %630, i64 noundef %631, i64 noundef %add.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %632, ptr %MEMORY, align 8
  br label %638

638:                                              ; preds = %627
  %639 = load i64, ptr %NEXT_PC, align 8
  store i64 %639, ptr %PC, align 8
  %640 = add i64 %639, 3
  store i64 %640, ptr %NEXT_PC, align 8
  %641 = load i64, ptr %RAX, align 8
  %642 = load ptr, ptr %MEMORY, align 8
  %.pre.i = call zeroext i8 @__remill_undefined_8() #17
  %new_val.0.i926 = ashr i64 %641, 1
  store i64 %new_val.0.i926, ptr %RAX, align 8
  %cf.i927 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %643 = trunc i64 %641 to i8
  %conv.i928 = and i8 %643, 1
  store i8 %conv.i928, ptr %cf.i927, align 1
  %pf.i929 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i930 = trunc i64 %new_val.0.i926 to i8
  %644 = call i8 @llvm.ctpop.i8(i8 %conv.i.i930)
  %645 = and i8 %644, 1
  %conv75.i931 = xor i8 %645, 1
  store i8 %conv75.i931, ptr %pf.i929, align 1
  %af.i932 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %.pre.i, ptr %af.i932, align 1
  %zf.i933 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i934 = icmp ult i64 %641, 2
  %conv88.i935 = zext i1 %cmp.i157.i934 to i8
  store i8 %conv88.i935, ptr %zf.i933, align 1
  %sf.i936 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i937 = lshr i64 %641, 63
  %conv95.i938 = trunc i64 %new_val.0.in.lobit.i937 to i8
  store i8 %conv95.i938, ptr %sf.i936, align 1
  %of.i939 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i939, align 1
  store ptr %642, ptr %MEMORY, align 8
  br label %646

646:                                              ; preds = %638
  %647 = load i64, ptr %NEXT_PC, align 8
  store i64 %647, ptr %PC, align 8
  %648 = add i64 %647, 3
  store i64 %648, ptr %NEXT_PC, align 8
  %649 = load i64, ptr %RBP, align 8
  %650 = sub i64 %649, 24
  %651 = load i32, ptr %EAX, align 4
  %652 = zext i32 %651 to i64
  %653 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %653, i64 noundef %650, i32 noundef %651) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %654

654:                                              ; preds = %646
  %655 = load i64, ptr %NEXT_PC, align 8
  store i64 %655, ptr %PC, align 8
  %656 = add i64 %655, 4
  store i64 %656, ptr %NEXT_PC, align 8
  %657 = load i64, ptr %RBP, align 8
  %658 = sub i64 %657, 8
  %659 = load ptr, ptr %MEMORY, align 8
  %call.i.i832 = call i64 @__remill_read_memory_64(ptr noundef %659, i64 noundef %658) #16
  store i64 %call.i.i832, ptr %RCX, align 8
  store ptr %659, ptr %MEMORY, align 8
  br label %660

660:                                              ; preds = %654
  %661 = load i64, ptr %NEXT_PC, align 8
  store i64 %661, ptr %PC, align 8
  %662 = add i64 %661, 10
  store i64 %662, ptr %NEXT_PC, align 8
  %663 = load ptr, ptr %MEMORY, align 8
  store i64 7378697629483820647, ptr %RDX, align 8
  store ptr %663, ptr %MEMORY, align 8
  br label %664

664:                                              ; preds = %660
  %665 = load i64, ptr %NEXT_PC, align 8
  store i64 %665, ptr %PC, align 8
  %666 = add i64 %665, 3
  store i64 %666, ptr %NEXT_PC, align 8
  %667 = load i64, ptr %RCX, align 8
  %668 = load ptr, ptr %MEMORY, align 8
  store i64 %667, ptr %RAX, align 8
  store ptr %668, ptr %MEMORY, align 8
  br label %669

669:                                              ; preds = %664
  %670 = load i64, ptr %NEXT_PC, align 8
  store i64 %670, ptr %PC, align 8
  %671 = add i64 %670, 3
  store i64 %671, ptr %NEXT_PC, align 8
  %672 = load i64, ptr %RDX, align 8
  %673 = load ptr, ptr %MEMORY, align 8
  %rax.i688 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %674 = load i64, ptr %rax.i688, align 8
  %675 = ashr i64 %674, 63
  %676 = ashr i64 %672, 63
  %L.sroa.2.0.insert.ext.i.i689 = zext i64 %675 to i128
  %L.sroa.2.0.insert.shift.i.i690 = shl nuw i128 %L.sroa.2.0.insert.ext.i.i689, 64
  %L.sroa.0.0.insert.ext.i.i691 = zext i64 %674 to i128
  %L.sroa.0.0.insert.insert.i.i692 = or i128 %L.sroa.2.0.insert.shift.i.i690, %L.sroa.0.0.insert.ext.i.i691
  %R.sroa.2.0.insert.ext.i.i693 = zext i64 %676 to i128
  %R.sroa.2.0.insert.shift.i.i694 = shl nuw i128 %R.sroa.2.0.insert.ext.i.i693, 64
  %R.sroa.0.0.insert.ext.i.i695 = zext i64 %672 to i128
  %R.sroa.0.0.insert.insert.i.i696 = or i128 %R.sroa.2.0.insert.shift.i.i694, %R.sroa.0.0.insert.ext.i.i695
  %mul.i.i697 = mul nsw i128 %L.sroa.0.0.insert.insert.i.i692, %R.sroa.0.0.insert.insert.i.i696
  %retval.sroa.0.0.extract.trunc.i.i698 = trunc i128 %mul.i.i697 to i64
  %retval.sroa.2.0.extract.shift.i.i699 = lshr i128 %mul.i.i697, 64
  %retval.sroa.2.0.extract.trunc.i.i700 = trunc i128 %retval.sroa.2.0.extract.shift.i.i699 to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i698, ptr %rax.i688, align 8
  %rdx.i701 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %retval.sroa.2.0.extract.trunc.i.i700, ptr %rdx.i701, align 8
  %conv2.i.i.i702 = sext i64 %retval.sroa.0.0.extract.trunc.i.i698 to i128
  %cmp.i.i.i703 = icmp ne i128 %mul.i.i697, %conv2.i.i.i702
  %call.i.i.i704 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i703, i64 noundef %674, i64 noundef %672, i64 noundef %retval.sroa.0.0.extract.trunc.i.i698, i64 noundef %retval.sroa.2.0.extract.trunc.i.i700) #16
  %frombool.i.i705 = zext i1 %call.i.i.i704 to i8
  %cf.i.i706 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i705, ptr %cf.i.i706, align 1
  %call2.i.i707 = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i708 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i707, ptr %pf.i.i708, align 1
  %af.i.i709 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i707, ptr %af.i.i709, align 1
  %zf.i.i710 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i707, ptr %zf.i.i710, align 1
  %sf.i.i711 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i707, ptr %sf.i.i711, align 1
  %of.i.i712 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i705, ptr %of.i.i712, align 1
  store ptr %673, ptr %MEMORY, align 8
  br label %677

677:                                              ; preds = %669
  %678 = load i64, ptr %NEXT_PC, align 8
  store i64 %678, ptr %PC, align 8
  %679 = add i64 %678, 3
  store i64 %679, ptr %NEXT_PC, align 8
  %680 = load i64, ptr %RDX, align 8
  %681 = load ptr, ptr %MEMORY, align 8
  store i64 %680, ptr %RAX, align 8
  store ptr %681, ptr %MEMORY, align 8
  br label %682

682:                                              ; preds = %677
  %683 = load i64, ptr %NEXT_PC, align 8
  store i64 %683, ptr %PC, align 8
  %684 = add i64 %683, 4
  store i64 %684, ptr %NEXT_PC, align 8
  %685 = load i64, ptr %RAX, align 8
  %686 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i909 = ashr i64 %685, 1
  %call36.i910 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i911 = icmp ne i8 %call36.i910, 0
  %687 = zext i1 %tobool.i911 to i8
  %new_val.0.i912 = ashr i64 %shr.i152.i909, 1
  store i64 %new_val.0.i912, ptr %RAX, align 8
  %cf.i913 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %688 = trunc i64 %shr.i152.i909 to i8
  %conv.i914 = and i8 %688, 1
  store i8 %conv.i914, ptr %cf.i913, align 1
  %pf.i915 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i916 = trunc i64 %new_val.0.i912 to i8
  %689 = call i8 @llvm.ctpop.i8(i8 %conv.i.i916)
  %690 = and i8 %689, 1
  %conv75.i917 = xor i8 %690, 1
  store i8 %conv75.i917, ptr %pf.i915, align 1
  %af.i918 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i910, ptr %af.i918, align 1
  %zf.i919 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i920 = icmp ult i64 %shr.i152.i909, 2
  %conv88.i921 = zext i1 %cmp.i157.i920 to i8
  store i8 %conv88.i921, ptr %zf.i919, align 1
  %sf.i922 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i923 = lshr i64 %shr.i152.i909, 63
  %conv95.i924 = trunc i64 %new_val.0.in.lobit.i923 to i8
  store i8 %conv95.i924, ptr %sf.i922, align 1
  %of.i925 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %687, ptr %of.i925, align 1
  store ptr %686, ptr %MEMORY, align 8
  br label %691

691:                                              ; preds = %682
  %692 = load i64, ptr %NEXT_PC, align 8
  store i64 %692, ptr %PC, align 8
  %693 = add i64 %692, 4
  store i64 %693, ptr %NEXT_PC, align 8
  %694 = load i64, ptr %RCX, align 8
  %695 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i892 = ashr i64 %694, 62
  %call36.i893 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i894 = icmp ne i8 %call36.i893, 0
  %696 = zext i1 %tobool.i894 to i8
  %new_val.0.i895 = ashr i64 %shr.i152.i892, 1
  store i64 %new_val.0.i895, ptr %RCX, align 8
  %cf.i896 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %697 = trunc i64 %shr.i152.i892 to i8
  %conv.i897 = and i8 %697, 1
  store i8 %conv.i897, ptr %cf.i896, align 1
  %pf.i898 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i899 = trunc i64 %new_val.0.i895 to i8
  %698 = call i8 @llvm.ctpop.i8(i8 %conv.i.i899)
  %699 = and i8 %698, 1
  %conv75.i900 = xor i8 %699, 1
  store i8 %conv75.i900, ptr %pf.i898, align 1
  %af.i901 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i893, ptr %af.i901, align 1
  %zf.i902 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i903 = icmp ult i64 %shr.i152.i892, 2
  %conv88.i904 = zext i1 %cmp.i157.i903 to i8
  store i8 %conv88.i904, ptr %zf.i902, align 1
  %sf.i905 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i906 = lshr i64 %shr.i152.i892, 63
  %conv95.i907 = trunc i64 %new_val.0.in.lobit.i906 to i8
  store i8 %conv95.i907, ptr %sf.i905, align 1
  %of.i908 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %696, ptr %of.i908, align 1
  store ptr %695, ptr %MEMORY, align 8
  br label %700

700:                                              ; preds = %691
  %701 = load i64, ptr %NEXT_PC, align 8
  store i64 %701, ptr %PC, align 8
  %702 = add i64 %701, 3
  store i64 %702, ptr %NEXT_PC, align 8
  %703 = load i64, ptr %RCX, align 8
  %704 = load ptr, ptr %MEMORY, align 8
  store i64 %703, ptr %RDX, align 8
  store ptr %704, ptr %MEMORY, align 8
  br label %705

705:                                              ; preds = %700
  %706 = load i64, ptr %NEXT_PC, align 8
  store i64 %706, ptr %PC, align 8
  %707 = add i64 %706, 3
  store i64 %707, ptr %NEXT_PC, align 8
  %708 = load i64, ptr %RAX, align 8
  %709 = load i64, ptr %RDX, align 8
  %710 = load ptr, ptr %MEMORY, align 8
  %sub.i.i404 = sub i64 %708, %709
  store i64 %sub.i.i404, ptr %RAX, align 8
  %cmp.i.i.i405 = icmp ult i64 %708, %709
  %call.i.i.i406 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i405, i64 noundef %708, i64 noundef %709, i64 noundef %sub.i.i404) #16
  %conv.i.i407 = zext i1 %call.i.i.i406 to i8
  %cf.i.i408 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i407, ptr %cf.i.i408, align 1
  %conv.i.i.i.i409 = trunc i64 %sub.i.i404 to i8
  %711 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i409)
  %712 = and i8 %711, 1
  %conv.i.i.i410 = xor i8 %712, 1
  %pf.i.i.i411 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i410, ptr %pf.i.i.i411, align 1
  %xor.i.i.i.i412 = xor i64 %709, %708
  %xor1.i.i.i.i413 = xor i64 %xor.i.i.i.i412, %sub.i.i404
  %713 = trunc i64 %xor1.i.i.i.i413 to i8
  %714 = lshr i8 %713, 4
  %conv2.i.i.i414 = and i8 %714, 1
  %af.i.i.i415 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i414, ptr %af.i.i.i415, align 1
  %cmp.i.i.i.i416 = icmp eq i64 %708, %709
  %call.i.i.i.i417 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i416, i64 noundef %708, i64 noundef %709, i64 noundef %sub.i.i404) #16
  %conv5.i.i.i418 = zext i1 %call.i.i.i.i417 to i8
  %zf.i.i.i419 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i418, ptr %zf.i.i.i419, align 1
  %cmp.i27.i.i.i420 = icmp slt i64 %sub.i.i404, 0
  %call1.i.i.i.i421 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i420, i64 noundef %708, i64 noundef %709, i64 noundef %sub.i.i404) #16
  %conv8.i.i.i422 = zext i1 %call1.i.i.i.i421 to i8
  %sf.i.i.i423 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i422, ptr %sf.i.i.i423, align 1
  %xor.i28.i.i.i424 = lshr i64 %xor.i.i.i.i412, 63
  %shr9.i.i.i.i425 = xor i64 %sub.i.i404, %708
  %xor3.i.i.i.i426 = lshr i64 %shr9.i.i.i.i425, 63
  %add.i.i.i.i427 = add nuw nsw i64 %xor3.i.i.i.i426, %xor.i28.i.i.i424
  %cmp.i29.i.i.i428 = icmp eq i64 %add.i.i.i.i427, 2
  %call.i30.i.i.i429 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i428, i64 noundef %708, i64 noundef %709, i64 noundef %sub.i.i404) #16
  %conv11.i.i.i430 = zext i1 %call.i30.i.i.i429 to i8
  %of.i.i.i431 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i430, ptr %of.i.i.i431, align 1
  store ptr %710, ptr %MEMORY, align 8
  br label %715

715:                                              ; preds = %705
  %716 = load i64, ptr %NEXT_PC, align 8
  store i64 %716, ptr %PC, align 8
  %717 = add i64 %716, 4
  store i64 %717, ptr %NEXT_PC, align 8
  %718 = load i64, ptr %RBP, align 8
  %719 = sub i64 %718, 8
  %720 = load i64, ptr %RAX, align 8
  %721 = load ptr, ptr %MEMORY, align 8
  %call.i.i824 = call ptr @__remill_write_memory_64(ptr noundef %721, i64 noundef %719, i64 noundef %720) #16
  store ptr %call.i.i824, ptr %MEMORY, align 8
  br label %722

722:                                              ; preds = %715
  %723 = load i64, ptr %NEXT_PC, align 8
  store i64 %723, ptr %PC, align 8
  %724 = add i64 %723, 4
  store i64 %724, ptr %NEXT_PC, align 8
  %725 = load i64, ptr %RBP, align 8
  %726 = sub i64 %725, 16
  %727 = load ptr, ptr %MEMORY, align 8
  %call.i.i831 = call i64 @__remill_read_memory_64(ptr noundef %727, i64 noundef %726) #16
  store i64 %call.i.i831, ptr %RCX, align 8
  store ptr %727, ptr %MEMORY, align 8
  br label %728

728:                                              ; preds = %722
  %729 = load i64, ptr %NEXT_PC, align 8
  store i64 %729, ptr %PC, align 8
  %730 = add i64 %729, 10
  store i64 %730, ptr %NEXT_PC, align 8
  %731 = load ptr, ptr %MEMORY, align 8
  store i64 7378697629483820647, ptr %RDX, align 8
  store ptr %731, ptr %MEMORY, align 8
  br label %732

732:                                              ; preds = %728
  %733 = load i64, ptr %NEXT_PC, align 8
  store i64 %733, ptr %PC, align 8
  %734 = add i64 %733, 3
  store i64 %734, ptr %NEXT_PC, align 8
  %735 = load i64, ptr %RCX, align 8
  %736 = load ptr, ptr %MEMORY, align 8
  store i64 %735, ptr %RAX, align 8
  store ptr %736, ptr %MEMORY, align 8
  br label %737

737:                                              ; preds = %732
  %738 = load i64, ptr %NEXT_PC, align 8
  store i64 %738, ptr %PC, align 8
  %739 = add i64 %738, 3
  store i64 %739, ptr %NEXT_PC, align 8
  %740 = load i64, ptr %RDX, align 8
  %741 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %742 = load i64, ptr %rax.i, align 8
  %743 = ashr i64 %742, 63
  %744 = ashr i64 %740, 63
  %L.sroa.2.0.insert.ext.i.i = zext i64 %743 to i128
  %L.sroa.2.0.insert.shift.i.i = shl nuw i128 %L.sroa.2.0.insert.ext.i.i, 64
  %L.sroa.0.0.insert.ext.i.i = zext i64 %742 to i128
  %L.sroa.0.0.insert.insert.i.i = or i128 %L.sroa.2.0.insert.shift.i.i, %L.sroa.0.0.insert.ext.i.i
  %R.sroa.2.0.insert.ext.i.i = zext i64 %744 to i128
  %R.sroa.2.0.insert.shift.i.i = shl nuw i128 %R.sroa.2.0.insert.ext.i.i, 64
  %R.sroa.0.0.insert.ext.i.i = zext i64 %740 to i128
  %R.sroa.0.0.insert.insert.i.i = or i128 %R.sroa.2.0.insert.shift.i.i, %R.sroa.0.0.insert.ext.i.i
  %mul.i.i = mul nsw i128 %L.sroa.0.0.insert.insert.i.i, %R.sroa.0.0.insert.insert.i.i
  %retval.sroa.0.0.extract.trunc.i.i = trunc i128 %mul.i.i to i64
  %retval.sroa.2.0.extract.shift.i.i = lshr i128 %mul.i.i, 64
  %retval.sroa.2.0.extract.trunc.i.i = trunc i128 %retval.sroa.2.0.extract.shift.i.i to i64
  store i64 %retval.sroa.0.0.extract.trunc.i.i, ptr %rax.i, align 8
  %rdx.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %retval.sroa.2.0.extract.trunc.i.i, ptr %rdx.i, align 8
  %conv2.i.i.i684 = sext i64 %retval.sroa.0.0.extract.trunc.i.i to i128
  %cmp.i.i.i685 = icmp ne i128 %mul.i.i, %conv2.i.i.i684
  %call.i.i.i686 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i685, i64 noundef %742, i64 noundef %740, i64 noundef %retval.sroa.0.0.extract.trunc.i.i, i64 noundef %retval.sroa.2.0.extract.trunc.i.i) #16
  %frombool.i.i = zext i1 %call.i.i.i686 to i8
  %cf.i.i687 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i687, align 1
  %call2.i.i = call zeroext i8 @__remill_undefined_8() #16
  %pf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %call2.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call2.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %call2.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %call2.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %741, ptr %MEMORY, align 8
  br label %745

745:                                              ; preds = %737
  %746 = load i64, ptr %NEXT_PC, align 8
  store i64 %746, ptr %PC, align 8
  %747 = add i64 %746, 3
  store i64 %747, ptr %NEXT_PC, align 8
  %748 = load i64, ptr %RDX, align 8
  %749 = load ptr, ptr %MEMORY, align 8
  store i64 %748, ptr %RAX, align 8
  store ptr %749, ptr %MEMORY, align 8
  br label %750

750:                                              ; preds = %745
  %751 = load i64, ptr %NEXT_PC, align 8
  store i64 %751, ptr %PC, align 8
  %752 = add i64 %751, 4
  store i64 %752, ptr %NEXT_PC, align 8
  %753 = load i64, ptr %RAX, align 8
  %754 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i875 = ashr i64 %753, 1
  %call36.i876 = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i877 = icmp ne i8 %call36.i876, 0
  %755 = zext i1 %tobool.i877 to i8
  %new_val.0.i878 = ashr i64 %shr.i152.i875, 1
  store i64 %new_val.0.i878, ptr %RAX, align 8
  %cf.i879 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %756 = trunc i64 %shr.i152.i875 to i8
  %conv.i880 = and i8 %756, 1
  store i8 %conv.i880, ptr %cf.i879, align 1
  %pf.i881 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i882 = trunc i64 %new_val.0.i878 to i8
  %757 = call i8 @llvm.ctpop.i8(i8 %conv.i.i882)
  %758 = and i8 %757, 1
  %conv75.i883 = xor i8 %758, 1
  store i8 %conv75.i883, ptr %pf.i881, align 1
  %af.i884 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i876, ptr %af.i884, align 1
  %zf.i885 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i886 = icmp ult i64 %shr.i152.i875, 2
  %conv88.i887 = zext i1 %cmp.i157.i886 to i8
  store i8 %conv88.i887, ptr %zf.i885, align 1
  %sf.i888 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i889 = lshr i64 %shr.i152.i875, 63
  %conv95.i890 = trunc i64 %new_val.0.in.lobit.i889 to i8
  store i8 %conv95.i890, ptr %sf.i888, align 1
  %of.i891 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %755, ptr %of.i891, align 1
  store ptr %754, ptr %MEMORY, align 8
  br label %759

759:                                              ; preds = %750
  %760 = load i64, ptr %NEXT_PC, align 8
  store i64 %760, ptr %PC, align 8
  %761 = add i64 %760, 4
  store i64 %761, ptr %NEXT_PC, align 8
  %762 = load i64, ptr %RCX, align 8
  %763 = load ptr, ptr %MEMORY, align 8
  %shr.i152.i = ashr i64 %762, 62
  %call36.i = call zeroext i8 @__remill_undefined_8() #17
  %tobool.i865 = icmp ne i8 %call36.i, 0
  %764 = zext i1 %tobool.i865 to i8
  %new_val.0.i866 = ashr i64 %shr.i152.i, 1
  store i64 %new_val.0.i866, ptr %RCX, align 8
  %cf.i867 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  %765 = trunc i64 %shr.i152.i to i8
  %conv.i868 = and i8 %765, 1
  store i8 %conv.i868, ptr %cf.i867, align 1
  %pf.i869 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  %conv.i.i870 = trunc i64 %new_val.0.i866 to i8
  %766 = call i8 @llvm.ctpop.i8(i8 %conv.i.i870)
  %767 = and i8 %766, 1
  %conv75.i = xor i8 %767, 1
  store i8 %conv75.i, ptr %pf.i869, align 1
  %af.i871 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %call36.i, ptr %af.i871, align 1
  %zf.i872 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %cmp.i157.i = icmp ult i64 %shr.i152.i, 2
  %conv88.i = zext i1 %cmp.i157.i to i8
  store i8 %conv88.i, ptr %zf.i872, align 1
  %sf.i873 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %new_val.0.in.lobit.i = lshr i64 %shr.i152.i, 63
  %conv95.i = trunc i64 %new_val.0.in.lobit.i to i8
  store i8 %conv95.i, ptr %sf.i873, align 1
  %of.i874 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %764, ptr %of.i874, align 1
  store ptr %763, ptr %MEMORY, align 8
  br label %768

768:                                              ; preds = %759
  %769 = load i64, ptr %NEXT_PC, align 8
  store i64 %769, ptr %PC, align 8
  %770 = add i64 %769, 3
  store i64 %770, ptr %NEXT_PC, align 8
  %771 = load i64, ptr %RCX, align 8
  %772 = load ptr, ptr %MEMORY, align 8
  store i64 %771, ptr %RDX, align 8
  store ptr %772, ptr %MEMORY, align 8
  br label %773

773:                                              ; preds = %768
  %774 = load i64, ptr %NEXT_PC, align 8
  store i64 %774, ptr %PC, align 8
  %775 = add i64 %774, 3
  store i64 %775, ptr %NEXT_PC, align 8
  %776 = load i64, ptr %RAX, align 8
  %777 = load i64, ptr %RDX, align 8
  %778 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %776, %777
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i378 = icmp ult i64 %776, %777
  %call.i.i.i379 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i378, i64 noundef %776, i64 noundef %777, i64 noundef %sub.i.i) #16
  %conv.i.i380 = zext i1 %call.i.i.i379 to i8
  %cf.i.i381 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i380, ptr %cf.i.i381, align 1
  %conv.i.i.i.i382 = trunc i64 %sub.i.i to i8
  %779 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i382)
  %780 = and i8 %779, 1
  %conv.i.i.i383 = xor i8 %780, 1
  %pf.i.i.i384 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i383, ptr %pf.i.i.i384, align 1
  %xor.i.i.i.i385 = xor i64 %777, %776
  %xor1.i.i.i.i386 = xor i64 %xor.i.i.i.i385, %sub.i.i
  %781 = trunc i64 %xor1.i.i.i.i386 to i8
  %782 = lshr i8 %781, 4
  %conv2.i.i.i387 = and i8 %782, 1
  %af.i.i.i388 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i387, ptr %af.i.i.i388, align 1
  %cmp.i.i.i.i389 = icmp eq i64 %776, %777
  %call.i.i.i.i390 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i389, i64 noundef %776, i64 noundef %777, i64 noundef %sub.i.i) #16
  %conv5.i.i.i391 = zext i1 %call.i.i.i.i390 to i8
  %zf.i.i.i392 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i391, ptr %zf.i.i.i392, align 1
  %cmp.i27.i.i.i393 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i394 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i393, i64 noundef %776, i64 noundef %777, i64 noundef %sub.i.i) #16
  %conv8.i.i.i395 = zext i1 %call1.i.i.i.i394 to i8
  %sf.i.i.i396 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i395, ptr %sf.i.i.i396, align 1
  %xor.i28.i.i.i397 = lshr i64 %xor.i.i.i.i385, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %776
  %xor3.i.i.i.i398 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i399 = add nuw nsw i64 %xor3.i.i.i.i398, %xor.i28.i.i.i397
  %cmp.i29.i.i.i400 = icmp eq i64 %add.i.i.i.i399, 2
  %call.i30.i.i.i401 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i400, i64 noundef %776, i64 noundef %777, i64 noundef %sub.i.i) #16
  %conv11.i.i.i402 = zext i1 %call.i30.i.i.i401 to i8
  %of.i.i.i403 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i402, ptr %of.i.i.i403, align 1
  store ptr %778, ptr %MEMORY, align 8
  br label %783

783:                                              ; preds = %773
  %784 = load i64, ptr %NEXT_PC, align 8
  store i64 %784, ptr %PC, align 8
  %785 = add i64 %784, 4
  store i64 %785, ptr %NEXT_PC, align 8
  %786 = load i64, ptr %RBP, align 8
  %787 = sub i64 %786, 16
  %788 = load i64, ptr %RAX, align 8
  %789 = load ptr, ptr %MEMORY, align 8
  %call.i.i823 = call ptr @__remill_write_memory_64(ptr noundef %789, i64 noundef %787, i64 noundef %788) #16
  store ptr %call.i.i823, ptr %MEMORY, align 8
  br label %790

790:                                              ; preds = %783
  %791 = load i64, ptr %NEXT_PC, align 8
  store i64 %791, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_132d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 16
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #16
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv.i.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i64 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i64 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i64 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i64 %call.i.i, 63
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %call.i.i, i64 noundef 0, i64 noundef %call.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 6
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 413
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #17
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_1338(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = add i64 %12, 18
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  %16 = load i8, ptr %zf.i, align 1
  %tobool.i = icmp ne i8 %16, 0
  %call8.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i) #17
  %frombool.i = zext i1 %call8.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call8.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_1350(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load i64, ptr %RBP, align 8
  %7 = sub i64 %6, 20
  %8 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %8, i64 noundef %7) #16
  %sub.i.i = sub i32 %call.i.i, 1
  %call.i18.i = call ptr @__remill_write_memory_32(ptr noundef %8, i64 noundef %5, i32 noundef %sub.i.i) #16
  %cmp.i.i.i = icmp ult i32 %call.i.i, 1
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv.i19.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %9 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %10 = and i8 %9, 1
  %conv.i.i.i = xor i8 %10, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %call.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %11 = trunc i32 %xor1.i.i.i.i to i8
  %12 = lshr i8 %11, 4
  %conv2.i.i.i = and i8 %12, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 1
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %call.i.i, i32 noundef 1, i32 noundef %sub.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %call.i18.i, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %1
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 7
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = add i64 %16, 3237
  %18 = load ptr, ptr %MEMORY, align 8
  store i64 %17, ptr %RAX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  store i64 %22, ptr %RDI, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 5
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %27, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %24
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 5
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %NEXT_PC, align 8
  %32 = sub i64 %31, 760
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %35 = load i64, ptr %rsp.i, align 8
  %sub.i.i1 = add i64 %35, -8
  %call.i.i2 = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %sub.i.i1, i64 noundef %33) #16
  store i64 %sub.i.i1, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %32, ptr %rip.i, align 8
  store i64 %32, ptr %NEXT_PC, align 8
  store i64 %33, ptr %RETURN_PC, align 8
  store ptr %call.i.i2, ptr %MEMORY, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  ret ptr %36
}

define ptr @BB_133e(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %conv.i.i5 = zext i32 %call.i.i4 to i64
  store i64 %conv.i.i5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = add i64 %10, 1
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i.i6 = and i64 %11, 4294967295
  store i64 %conv.i.i6, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 20
  %18 = load i32, ptr %EDX, align 4
  %19 = zext i32 %18 to i64
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %20, i64 noundef %17, i32 noundef %18) #16
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %25 = load i32, ptr %rax.i, align 8
  %conv.i.i = sext i32 %25 to i64
  store i64 %conv.i.i, ptr %rax.i, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %21
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 3
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RBP, align 8
  %30 = sub i64 %29, 24
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #16
  %conv.i.i3 = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i3, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %26
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 4
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RBP, align 8
  %36 = load i64, ptr %RAX, align 8
  %37 = mul i64 %36, 4
  %38 = add i64 %35, %37
  %39 = sub i64 %38, 112
  %40 = load i32, ptr %EDX, align 4
  %41 = zext i32 %40 to i64
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %42, i64 noundef %39, i32 noundef %40) #16
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %32
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  ret ptr %memory
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_1368(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 37
  %6 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %5, ptr %rip.i, align 8
  store i64 %5, ptr %NEXT_PC, align 8
  store ptr %6, ptr %MEMORY, align 8
  %7 = load i64, ptr %NEXT_PC, align 8
  store i64 %7, ptr %PC, align 8
  %8 = load ptr, ptr %MEMORY, align 8
  ret ptr %8
}

define ptr @BB_138f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv.i9.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %call.i.i to i8
  %7 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %8 = and i8 %7, 1
  %conv.i.i.i = xor i8 %8, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %call.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %call.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %call.i.i, 31
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %call.i.i, i32 noundef 0, i32 noundef %call.i.i) #16
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %6, ptr %MEMORY, align 8
  br label %9

9:                                                ; preds = %1
  %10 = load i64, ptr %NEXT_PC, align 8
  store i64 %10, ptr %PC, align 8
  %11 = add i64 %10, 2
  store i64 %11, ptr %NEXT_PC, align 8
  %12 = load i64, ptr %NEXT_PC, align 8
  %13 = sub i64 %12, 43
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 2, i32 9
  %16 = load i8, ptr %sf.i, align 1
  %tobool.not.i = icmp eq i8 %16, 0
  %frombool.i = zext i1 %tobool.not.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %tobool.not.i, i64 %13, i64 %14
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %15, ptr %MEMORY, align 8
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  ret ptr %18
}

define ptr @BB_136a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 3
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 20
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #16
  %conv.i.i5 = zext i32 %call.i.i4 to i64
  store i64 %conv.i.i5, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = sub i64 %10, 1
  %12 = load ptr, ptr %MEMORY, align 8
  %conv.i.i6 = and i64 %11, 4294967295
  store i64 %conv.i.i6, ptr %RDX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 20
  %18 = load i32, ptr %EDX, align 4
  %19 = zext i32 %18 to i64
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %20, i64 noundef %17, i32 noundef %18) #16
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %13
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 2
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  %rax.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %25 = load i32, ptr %rax.i, align 8
  %conv.i.i = sext i32 %25 to i64
  store i64 %conv.i.i, ptr %rax.i, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %21
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 4
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RBP, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = mul i64 %30, 4
  %32 = add i64 %29, %31
  %33 = sub i64 %32, 112
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i32 @__remill_read_memory_32(ptr noundef %34, i64 noundef %33) #16
  %conv.i.i3 = zext i32 %call.i.i2 to i64
  store i64 %conv.i.i3, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %26
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 2
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i32, ptr %EAX, align 4
  %39 = zext i32 %38 to i64
  %40 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %39, 4294967295
  store i64 %conv.i11.i, ptr %RSI, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %35
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 7
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load i64, ptr %NEXT_PC, align 8
  %45 = add i64 %44, 3226
  %46 = load ptr, ptr %MEMORY, align 8
  store i64 %45, ptr %RAX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %41
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RAX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  store i64 %50, ptr %RDI, align 8
  store ptr %51, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %47
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 5
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %52
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 5
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = sub i64 %59, 799
  %61 = load i64, ptr %NEXT_PC, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %63 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %63, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %62, i64 noundef %sub.i.i, i64 noundef %61) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %60, ptr %rip.i, align 8
  store i64 %60, ptr %NEXT_PC, align 8
  store i64 %61, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  ret ptr %64
}

define ptr @BB_1395(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RDI = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RDI, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  %7 = add i64 %6, 5
  store i64 %7, ptr %NEXT_PC, align 8
  %8 = load i64, ptr %NEXT_PC, align 8
  %9 = sub i64 %8, 831
  %10 = load i64, ptr %NEXT_PC, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %12 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %12, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %11, i64 noundef %sub.i.i, i64 noundef %10) #16
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %9, ptr %rip.i, align 8
  store i64 %9, ptr %NEXT_PC, align 8
  store i64 %10, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %13 = load ptr, ptr %MEMORY, align 8
  ret ptr %13
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_ffff000000000002_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #4 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !23)
  %rsp.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_putchar(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !26)
  %rip.i.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !29)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

declare ptr @__lifted_ext_call_putchar(ptr, i64, ptr) #4

define ptr @BB_139f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.18764, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 5
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load ptr, ptr %MEMORY, align 8
  store i64 0, ptr %RAX, align 8
  store ptr %4, ptr %MEMORY, align 8
  br label %5

5:                                                ; preds = %1
  %6 = load i64, ptr %NEXT_PC, align 8
  store i64 %6, ptr %PC, align 8
  ret ptr %memory
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #5 {
entry:
  %agg.tmp = alloca %struct.State.18764, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.18764) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #18
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #6

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.18764) align 16, i64 noundef, ptr noundef) local_unnamed_addr #7

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !32
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rax = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #9 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !32
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #10 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4409, label %bb_1139
    i64 4434, label %bb_1152
    i64 4444, label %bb_115C
    i64 4507, label %bb_119B
    i64 4898, label %bb_1322
    i64 4909, label %bb_132D
    i64 4920, label %bb_1338
    i64 4926, label %bb_133E
    i64 4944, label %bb_1350
    i64 4968, label %bb_1368
    i64 4970, label %bb_136A
    i64 5007, label %bb_138F
    i64 5013, label %bb_1395
    i64 5023, label %bb_139F
    i64 5028, label %bb_13A4
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
    i64 -281474976710654, label %bb_FFFF000000000002
  ]

dead_end:                                         ; preds = %bb_FFFF000000000002, %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_139F, %bb_1395, %bb_138F, %bb_136A, %bb_1368, %bb_1350, %bb_133E, %bb_1338, %bb_132D, %bb_1322, %bb_119B, %bb_115C, %bb_1152, %bb_1139, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1139:                                          ; preds = %entry
  %block_pc = add i64 4409, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4409, ptr %1)
  %4 = call ptr @BB_1139(ptr %state, i64 %2, ptr %1) #19
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4434, label %bb_1152
    i64 4444, label %bb_115C
  ]

bb_1152:                                          ; preds = %bb_1139, %entry
  %block_pc1 = add i64 4434, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4434, ptr %6)
  %9 = call ptr @BB_1152(ptr %state, i64 %7, ptr %6) #19
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 5028, label %bb_13A4
  ]

bb_115C:                                          ; preds = %bb_1139, %entry
  %block_pc3 = add i64 4444, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4444, ptr %11)
  %14 = call ptr @BB_115c(ptr %state, i64 %12, ptr %11) #19
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4898, label %bb_1322
  ]

bb_119B:                                          ; preds = %bb_132D, %bb_1322, %entry
  %block_pc5 = add i64 4507, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4507, ptr %16)
  %19 = call ptr @BB_119b(ptr %state, i64 %17, ptr %16) #19
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4898, label %bb_1322
  ]

bb_1322:                                          ; preds = %bb_119B, %bb_115C, %entry
  %block_pc7 = add i64 4898, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4898, ptr %21)
  %24 = call ptr @BB_1322(ptr %state, i64 %22, ptr %21) #19
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4507, label %bb_119B
    i64 4909, label %bb_132D
  ]

bb_132D:                                          ; preds = %bb_1322, %entry
  %block_pc9 = add i64 4909, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4909, ptr %26)
  %29 = call ptr @BB_132d(ptr %state, i64 %27, ptr %26) #19
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4507, label %bb_119B
    i64 4920, label %bb_1338
  ]

bb_1338:                                          ; preds = %bb_132D, %entry
  %block_pc11 = add i64 4920, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4920, ptr %31)
  %34 = call ptr @BB_1338(ptr %state, i64 %32, ptr %31) #19
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4926, label %bb_133E
    i64 4944, label %bb_1350
  ]

bb_133E:                                          ; preds = %bb_1338, %entry
  %block_pc13 = add i64 4926, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4926, ptr %36)
  %39 = call ptr @BB_133e(ptr %state, i64 %37, ptr %36) #19
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4944, label %bb_1350
  ]

bb_1350:                                          ; preds = %bb_133E, %bb_1338, %entry
  %block_pc15 = add i64 4944, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4944, ptr %41)
  %44 = call ptr @BB_1350(ptr %state, i64 %42, ptr %41) #19
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4208, label %bb_FFFF000000000000
  ]

bb_1368:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc17 = add i64 4968, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4968, ptr %46)
  %49 = call ptr @BB_1368(ptr %state, i64 %47, ptr %46) #19
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 5007, label %bb_138F
  ]

bb_136A:                                          ; preds = %bb_138F, %entry
  %block_pc19 = add i64 4970, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4970, ptr %51)
  %54 = call ptr @BB_136a(ptr %state, i64 %52, ptr %51) #19
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 4208, label %bb_FFFF000000000001
  ]

bb_138F:                                          ; preds = %bb_FFFF000000000001, %bb_1368, %entry
  %block_pc21 = add i64 5007, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 5007, ptr %56)
  %59 = call ptr @BB_138f(ptr %state, i64 %57, ptr %56) #19
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4970, label %bb_136A
    i64 5013, label %bb_1395
  ]

bb_1395:                                          ; preds = %bb_138F, %entry
  %block_pc23 = add i64 5013, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 5013, ptr %61)
  %64 = call ptr @BB_1395(ptr %state, i64 %62, ptr %61) #19
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 4192, label %bb_FFFF000000000002
  ]

bb_139F:                                          ; preds = %bb_FFFF000000000002, %entry
  %block_pc25 = add i64 5023, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 5023, ptr %66)
  %69 = call ptr @BB_139f(ptr %state, i64 %67, ptr %66) #19
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 5028, label %bb_13A4
  ]

bb_13A4:                                          ; preds = %bb_139F, %bb_1152, %entry
  %block_pc27 = add i64 5028, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 5028, ptr %71)
  %74 = call ptr @BB_13a4(ptr %state, i64 %72, ptr %71) #19
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  %76 = load ptr, ptr %mem_var, align 8
  ret ptr %76

bb_FFFF000000000000:                              ; preds = %bb_1350, %entry
  %77 = load ptr, ptr %mem_var, align 8
  %78 = load i64, ptr %pc_var, align 4
  %79 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %78, ptr %77) #19
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva29 = sub i64 %80, %base
  switch i64 %next_rva29, label %dead_end [
    i64 4968, label %bb_1368
  ]

bb_FFFF000000000001:                              ; preds = %bb_136A, %entry
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %82, ptr %81) #19
  store ptr %83, ptr %mem_var, align 8
  %84 = call i64 @__extract_rip(ptr %state)
  store i64 %84, ptr %pc_var, align 4
  %next_rva30 = sub i64 %84, %base
  switch i64 %next_rva30, label %dead_end [
    i64 5007, label %bb_138F
  ]

bb_FFFF000000000002:                              ; preds = %bb_1395, %entry
  %85 = load ptr, ptr %mem_var, align 8
  %86 = load i64, ptr %pc_var, align 4
  %87 = call ptr @BB_ffff000000000002_ext(ptr %state, i64 %86, ptr %85) #19
  store ptr %87, ptr %mem_var, align 8
  %88 = call i64 @__extract_rip(ptr %state)
  store i64 %88, ptr %pc_var, align 4
  %next_rva31 = sub i64 %88, %base
  switch i64 %next_rva31, label %dead_end [
    i64 5023, label %bb_139F
  ]

return_bb:                                        ; No predecessors!
  %89 = load ptr, ptr %mem_var, align 8
  ret ptr %89
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #11 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4409, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #12 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #12 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #12 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #12 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #12 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #12 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #13 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #9 {
entry:
  %rip = getelementptr inbounds %struct.X86State.18763, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !32
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #15 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { "lifted.annotation_id"="4" "lifted.state_form"="folded" }
attributes #5 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #6 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #7 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #10 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #12 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #16 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #18 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #19 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24}
!24 = distinct !{!24, !25, !"__extract_rsp: %state"}
!25 = distinct !{!25, !"__extract_rsp"}
!26 = !{!27}
!27 = distinct !{!27, !28, !"__store_rip: %state"}
!28 = distinct !{!28, !"__store_rip"}
!29 = !{!30}
!30 = distinct !{!30, !31, !"__store_rsp: %state"}
!31 = distinct !{!31, !"__store_rsp"}
!32 = !{!33, !33, i64 0}
!33 = !{!"omnipotent char", !34, i64 0}
!34 = !{!"Simple C++ TBAA"}
