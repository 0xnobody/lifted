; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.125295 = type { %struct.X86State.125294 }
%struct.X86State.125294 = type { %struct.ArchState.125263, [32 x %union.VectorReg.125266], %struct.ArithFlags.125267, %union.anon.125262, %struct.Segments.125269, %struct.AddressSpace.125271, %struct.GPR.125272, %struct.X87Stack.125275, %struct.MMX.125279, %struct.FPUStatusFlags.125280, %union.anon.125262, %union.FPU.125289, %struct.SegmentCaches.125291, %struct.K_REG.125293 }
%struct.ArchState.125263 = type { i32, i32, %union.anon.125262 }
%union.VectorReg.125266 = type { %union.vec512_t.125265 }
%union.vec512_t.125265 = type { %struct.uint64v8_t.125264 }
%struct.uint64v8_t.125264 = type { [8 x i64] }
%struct.ArithFlags.125267 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.125269 = type { i16, %union.SegmentSelector.125268, i16, %union.SegmentSelector.125268, i16, %union.SegmentSelector.125268, i16, %union.SegmentSelector.125268, i16, %union.SegmentSelector.125268, i16, %union.SegmentSelector.125268 }
%union.SegmentSelector.125268 = type { i16 }
%struct.AddressSpace.125271 = type { i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270 }
%struct.Reg.125270 = type { %union.anon.125262 }
%struct.GPR.125272 = type { i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270, i64, %struct.Reg.125270 }
%struct.X87Stack.125275 = type { [8 x %struct.anon.3.125274] }
%struct.anon.3.125274 = type { [6 x i8], %struct.float80_t.125273 }
%struct.float80_t.125273 = type { [10 x i8] }
%struct.MMX.125279 = type { [8 x %struct.anon.4.125278] }
%struct.anon.4.125278 = type { i64, %union.vec64_t.125277 }
%union.vec64_t.125277 = type { %struct.uint64v1_t.125276 }
%struct.uint64v1_t.125276 = type { [1 x i64] }
%struct.FPUStatusFlags.125280 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.125262 = type { i64 }
%union.FPU.125289 = type { %struct.anon.13.125288 }
%struct.anon.13.125288 = type { %struct.FpuFXSAVE.125287, [96 x i8] }
%struct.FpuFXSAVE.125287 = type { %union.SegmentSelector.125268, %union.SegmentSelector.125268, %union.FPUAbridgedTagWord.125281, i8, i16, i32, %union.SegmentSelector.125268, i16, i32, %union.SegmentSelector.125268, i16, %union.FPUControlStatus.125282, %union.FPUControlStatus.125282, [8 x %struct.FPUStackElem.125284], [16 x %union.vec128_t.125286] }
%union.FPUAbridgedTagWord.125281 = type { i8 }
%union.FPUControlStatus.125282 = type { i32 }
%struct.FPUStackElem.125284 = type { %union.anon.11.125283, [6 x i8] }
%union.anon.11.125283 = type { %struct.float80_t.125273 }
%union.vec128_t.125286 = type { %struct.uint128v1_t.125285 }
%struct.uint128v1_t.125285 = type { [1 x i128] }
%struct.SegmentCaches.125291 = type { %struct.SegmentShadow.125290, %struct.SegmentShadow.125290, %struct.SegmentShadow.125290, %struct.SegmentShadow.125290, %struct.SegmentShadow.125290, %struct.SegmentShadow.125290 }
%struct.SegmentShadow.125290 = type { %union.anon.125262, i32, i32 }
%struct.K_REG.125293 = type { [8 x %struct.anon.18.125292] }
%struct.anon.18.125292 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_1110(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i121 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i121, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 4
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 112
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 112
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #15
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 112, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 112
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 112, i64 noundef %sub.i.i) #15
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 12
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 8
  %34 = load i64, ptr %RSI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_64(ptr noundef %35, i64 noundef %33, i64 noundef %34) #15
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 11722
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #15
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #15
  %conv.i.i80 = zext i32 %call.i.i79 to i64
  store i64 %conv.i.i80, ptr %RDX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 7
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %NEXT_PC, align 8
  %51 = add i64 %50, 11865
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %52, i64 noundef %51) #15
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %57, i64 noundef %56) #15
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %59 = and i8 %58, 1
  %conv.i.i.i32 = xor i8 %59, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %60 = trunc i32 %xor1.i.i.i.i35 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i36 = and i8 %61, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %53
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %66 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %66, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %67 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %67, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %EDX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %72, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RCX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %77 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %79 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %79, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %80 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %81 = and i8 %80, 1
  %conv.i.i.i = xor i8 %81, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %82 = trunc i32 %xor1.i.i.i.i to i8
  %83 = lshr i8 %82, 4
  %conv2.i.i.i = and i8 %83, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %74
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 3
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RCX, align 8
  %88 = load i32, ptr %EDX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %87 to i32
  %sext.i = shl i64 %87, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %89, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %91 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %91, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %88, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %84
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %conv.i.i83 = trunc i64 %95 to i32
  %and3.i.i = and i32 1, %conv.i.i83
  %conv.i22.i84 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i84, ptr %RCX, align 8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i85, align 1
  %conv.i.i.i86 = trunc i32 %and3.i.i to i8
  %97 = and i8 %conv.i.i.i86, 1
  %conv.i23.i87 = xor i8 %97, 1
  %pf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i87, ptr %pf.i.i88, align 1
  %cmp.i.i.i89 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i90 to i8
  %zf.i.i91 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i91, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i94, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i32, ptr %ECX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %101 to i8
  %104 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %105 = and i8 %104, 1
  %conv.i.i.i57 = xor i8 %105, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %101, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %101, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %101, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %98
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %110 = load i8, ptr %zf.i, align 1
  store i8 %110, ptr %CL, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %106
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 2
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i8, ptr %AL, align 1
  %115 = zext i8 %114 to i64
  %116 = load i8, ptr %CL, align 1
  %117 = zext i8 %116 to i64
  %118 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %117, %115
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i95 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %119 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %120 = and i8 %119, 1
  %conv.i27.i = xor i8 %120, 1
  %pf.i.i96 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i96, align 1
  %121 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i97 = and i32 %121, 255
  %cmp.i.i.i98 = icmp eq i8 %or3.i.i, 0
  %122 = trunc i64 %115 to i32
  %conv1.i.i.i = and i32 %122, 255
  %123 = trunc i64 %117 to i32
  %conv2.i.i.i99 = and i32 %123, 255
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i98, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #15
  %conv3.i.i101 = zext i1 %call.i.i.i100 to i8
  %zf.i.i102 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i101, ptr %zf.i.i102, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #15
  %conv6.i.i103 = zext i1 %call4.i.i.i to i8
  %sf.i.i104 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i103, ptr %sf.i.i104, align 1
  %of.i.i105 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i105, align 1
  %af.i.i106 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i106, align 1
  store ptr %118, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %111
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %128
  %and3.i.i107 = trunc i64 %and3.i15.i to i8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i108, align 1
  %130 = and i8 %and3.i.i107, 1
  %conv.i14.i = xor i8 %130, 1
  %pf.i.i109 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i109, align 1
  %131 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i110 = and i32 %131, 255
  %cmp.i.i.i111 = icmp eq i8 %and3.i.i107, 0
  %132 = trunc i64 %128 to i32
  %conv1.i.i.i112 = and i32 %132, 255
  %call.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #15
  %conv3.i.i114 = zext i1 %call.i.i.i113 to i8
  %zf.i.i115 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i114, ptr %zf.i.i115, align 1
  %call4.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #15
  %conv6.i.i117 = zext i1 %call4.i.i.i116 to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i117, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i120, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %124
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 6
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %NEXT_PC, align 8
  %137 = add i64 %136, 5
  %138 = load i64, ptr %NEXT_PC, align 8
  %139 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %140 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %140, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %137, i64 %138
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %139, ptr %MEMORY, align 8
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  ret ptr %142
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_1155(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %R8D = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %R9 = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 19, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i230 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i230, ptr %RSI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 12
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i225 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #15
  %conv.i.i226 = zext i32 %call.i.i225 to i64
  store i64 %conv.i.i226, ptr %R8, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RSP, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %R9, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %R9, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %21
  store i64 %add.i.i117, ptr %R9, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %21
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %23 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %23, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %25 = and i8 %24, 1
  %conv.i.i.i124 = xor i8 %25, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %21
  %26 = trunc i64 %xor1.i.i.i.i127 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i128 = and i8 %27, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %21
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %18
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 3
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %R9, align 8
  %32 = load ptr, ptr %MEMORY, align 8
  store i64 %31, ptr %RSP, align 8
  store ptr %32, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %28
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 3
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i64, ptr %RSP, align 8
  %37 = load ptr, ptr %MEMORY, align 8
  store i64 %36, ptr %RDI, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %33
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 4
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RDI, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -16, %41
  store i64 %add.i.i88, ptr %RDI, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %41
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -16
  %43 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %43, i64 noundef %41, i64 noundef -16, i64 noundef %add.i.i88) #15
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %44 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %45 = and i8 %44, 1
  %conv.i.i.i95 = xor i8 %45, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -16
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %41
  %46 = trunc i64 %xor1.i.i.i.i98 to i8
  %47 = lshr i8 %46, 4
  %conv2.i.i.i99 = and i8 %47, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %41, i64 noundef -16, i64 noundef %add.i.i88) #15
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %41, i64 noundef -16, i64 noundef %add.i.i88) #15
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %41
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %41, i64 noundef -16, i64 noundef %add.i.i88) #15
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %38
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 4
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RBP, align 8
  %52 = sub i64 %51, 56
  %53 = load i64, ptr %RDI, align 8
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i222 = call ptr @__remill_write_memory_64(ptr noundef %54, i64 noundef %52, i64 noundef %53) #15
  store ptr %call.i.i222, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %48
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 3
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RDI, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  store i64 %58, ptr %RSP, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 3
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %RSP, align 8
  %64 = load ptr, ptr %MEMORY, align 8
  store i64 %63, ptr %RDX, align 8
  store ptr %64, ptr %MEMORY, align 8
  br label %65

65:                                               ; preds = %60
  %66 = load i64, ptr %NEXT_PC, align 8
  store i64 %66, ptr %PC, align 8
  %67 = add i64 %66, 4
  store i64 %67, ptr %NEXT_PC, align 8
  %68 = load i64, ptr %RDX, align 8
  %69 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %68
  store i64 %add.i.i59, ptr %RDX, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %68
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %70 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %70, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %72 = and i8 %71, 1
  %conv.i.i.i66 = xor i8 %72, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %68
  %73 = trunc i64 %xor1.i.i.i.i69 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i70 = and i8 %74, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %68
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %68, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %69, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %65
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 4
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %RBP, align 8
  %79 = sub i64 %78, 48
  %80 = load i64, ptr %RDX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %call.i.i221 = call ptr @__remill_write_memory_64(ptr noundef %81, i64 noundef %79, i64 noundef %80) #15
  store ptr %call.i.i221, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %75
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RDX, align 8
  %86 = load ptr, ptr %MEMORY, align 8
  store i64 %85, ptr %RSP, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %82
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RSP, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  store i64 %90, ptr %RAX, align 8
  store ptr %91, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %87
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 4
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RAX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %95
  store i64 %add.i.i30, ptr %RAX, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %95
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %97 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %97, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %98 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %99 = and i8 %98, 1
  %conv.i.i.i37 = xor i8 %99, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %95
  %100 = trunc i64 %xor1.i.i.i.i40 to i8
  %101 = lshr i8 %100, 4
  %conv2.i.i.i41 = and i8 %101, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %95
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %95, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %92
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 4
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load i64, ptr %RBP, align 8
  %106 = sub i64 %105, 40
  %107 = load i64, ptr %RAX, align 8
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i220 = call ptr @__remill_write_memory_64(ptr noundef %108, i64 noundef %106, i64 noundef %107) #15
  store ptr %call.i.i220, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %102
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 3
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RAX, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  store i64 %112, ptr %RSP, align 8
  store ptr %113, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %109
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RSP, align 8
  %118 = load ptr, ptr %MEMORY, align 8
  store i64 %117, ptr %RCX, align 8
  store ptr %118, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %114
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 4
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load i64, ptr %RCX, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %122
  store i64 %add.i.i1, ptr %RCX, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %122
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %124 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %124, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %125 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %126 = and i8 %125, 1
  %conv.i.i.i8 = xor i8 %126, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %122
  %127 = trunc i64 %xor1.i.i.i.i11 to i8
  %128 = lshr i8 %127, 4
  %conv2.i.i.i12 = and i8 %128, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %122
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %122, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %119
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 4
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %RBP, align 8
  %133 = sub i64 %132, 32
  %134 = load i64, ptr %RCX, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %call.i.i219 = call ptr @__remill_write_memory_64(ptr noundef %135, i64 noundef %133, i64 noundef %134) #15
  store ptr %call.i.i219, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %129
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 3
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %RCX, align 8
  %140 = load ptr, ptr %MEMORY, align 8
  store i64 %139, ptr %RSP, align 8
  store ptr %140, ptr %MEMORY, align 8
  br label %141

141:                                              ; preds = %136
  %142 = load i64, ptr %NEXT_PC, align 8
  store i64 %142, ptr %PC, align 8
  %143 = add i64 %142, 7
  store i64 %143, ptr %NEXT_PC, align 8
  %144 = load i64, ptr %R9, align 8
  %145 = load ptr, ptr %MEMORY, align 8
  %call.i.i215 = call ptr @__remill_write_memory_32(ptr noundef %145, i64 noundef %144, i32 noundef 0) #15
  store ptr %call.i.i215, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %141
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 3
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %RDI, align 8
  %150 = load i32, ptr %R8D, align 4
  %151 = zext i32 %150 to i64
  %152 = load ptr, ptr %MEMORY, align 8
  %call.i.i216 = call ptr @__remill_write_memory_32(ptr noundef %152, i64 noundef %149, i32 noundef %150) #15
  store ptr %call.i.i216, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %146
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 3
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %RDX, align 8
  %157 = load i64, ptr %RSI, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  %call.i.i218 = call ptr @__remill_write_memory_64(ptr noundef %158, i64 noundef %156, i64 noundef %157) #15
  store ptr %call.i.i218, ptr %MEMORY, align 8
  br label %159

159:                                              ; preds = %153
  %160 = load i64, ptr %NEXT_PC, align 8
  store i64 %160, ptr %PC, align 8
  %161 = add i64 %160, 6
  store i64 %161, ptr %NEXT_PC, align 8
  %162 = load i64, ptr %RCX, align 8
  %163 = load ptr, ptr %MEMORY, align 8
  %call.i.i214 = call ptr @__remill_write_memory_32(ptr noundef %163, i64 noundef %162, i32 noundef 0) #15
  store ptr %call.i.i214, ptr %MEMORY, align 8
  br label %164

164:                                              ; preds = %159
  %165 = load i64, ptr %NEXT_PC, align 8
  store i64 %165, ptr %PC, align 8
  %166 = add i64 %165, 6
  store i64 %166, ptr %NEXT_PC, align 8
  %167 = load i64, ptr %RAX, align 8
  %168 = load ptr, ptr %MEMORY, align 8
  %call.i.i213 = call ptr @__remill_write_memory_32(ptr noundef %168, i64 noundef %167, i32 noundef 0) #15
  store ptr %call.i.i213, ptr %MEMORY, align 8
  br label %169

169:                                              ; preds = %164
  %170 = load i64, ptr %NEXT_PC, align 8
  store i64 %170, ptr %PC, align 8
  %171 = add i64 %170, 7
  store i64 %171, ptr %NEXT_PC, align 8
  %172 = load i64, ptr %NEXT_PC, align 8
  %173 = add i64 %172, 11889
  %174 = load ptr, ptr %MEMORY, align 8
  %call.i.i229 = call i64 @__remill_read_memory_64(ptr noundef %174, i64 noundef %173) #15
  store i64 %call.i.i229, ptr %RAX, align 8
  store ptr %174, ptr %MEMORY, align 8
  br label %175

175:                                              ; preds = %169
  %176 = load i64, ptr %NEXT_PC, align 8
  store i64 %176, ptr %PC, align 8
  %177 = add i64 %176, 4
  store i64 %177, ptr %NEXT_PC, align 8
  %178 = load i64, ptr %RAX, align 8
  %179 = load ptr, ptr %MEMORY, align 8
  store i64 %178, ptr %RAX, align 8
  %call.i.i.i146 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %178, i64 noundef 0, i64 noundef %178) #15
  %conv.i.i147 = zext i1 %call.i.i.i146 to i8
  %cf.i.i148 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i147, ptr %cf.i.i148, align 1
  %conv.i.i.i.i149 = trunc i64 %178 to i8
  %180 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i149)
  %181 = and i8 %180, 1
  %conv.i.i.i150 = xor i8 %181, 1
  %pf.i.i.i151 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i150, ptr %pf.i.i.i151, align 1
  %af.i.i.i152 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i152, align 1
  %cmp.i.i.i.i153 = icmp eq i64 %178, 0
  %call.i.i.i.i154 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i153, i64 noundef %178, i64 noundef 0, i64 noundef %178) #15
  %conv5.i.i.i155 = zext i1 %call.i.i.i.i154 to i8
  %zf.i.i.i156 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i155, ptr %zf.i.i.i156, align 1
  %cmp.i27.i.i.i157 = icmp slt i64 %178, 0
  %call1.i.i.i.i158 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i157, i64 noundef %178, i64 noundef 0, i64 noundef %178) #15
  %conv8.i.i.i159 = zext i1 %call1.i.i.i.i158 to i8
  %sf.i.i.i160 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i159, ptr %sf.i.i.i160, align 1
  %xor.i28.i.i.i161 = lshr i64 %178, 63
  %call.i30.i.i.i162 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %178, i64 noundef 0, i64 noundef %178) #15
  %conv11.i.i.i163 = zext i1 %call.i30.i.i.i162 to i8
  %of.i.i.i164 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i163, ptr %of.i.i.i164, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %182

182:                                              ; preds = %175
  %183 = load i64, ptr %NEXT_PC, align 8
  store i64 %183, ptr %PC, align 8
  %184 = add i64 %183, 4
  store i64 %184, ptr %NEXT_PC, align 8
  %185 = load i64, ptr %RBP, align 8
  %186 = sub i64 %185, 24
  %187 = load i64, ptr %RAX, align 8
  %188 = load ptr, ptr %MEMORY, align 8
  %call.i.i217 = call ptr @__remill_write_memory_64(ptr noundef %188, i64 noundef %186, i64 noundef %187) #15
  store ptr %call.i.i217, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %182
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 7
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i64, ptr %NEXT_PC, align 8
  %193 = add i64 %192, 11594
  %194 = load ptr, ptr %MEMORY, align 8
  %call.i.i228 = call i64 @__remill_read_memory_64(ptr noundef %194, i64 noundef %193) #15
  store i64 %call.i.i228, ptr %RAX, align 8
  store ptr %194, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %189
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 2
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load i64, ptr %RAX, align 8
  %199 = load ptr, ptr %MEMORY, align 8
  %call.i.i223 = call i32 @__remill_read_memory_32(ptr noundef %199, i64 noundef %198) #15
  %conv.i.i224 = zext i32 %call.i.i223 to i64
  store i64 %conv.i.i224, ptr %RDX, align 8
  store ptr %199, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %195
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 7
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i64, ptr %NEXT_PC, align 8
  %204 = add i64 %203, 11777
  %205 = load ptr, ptr %MEMORY, align 8
  %call.i.i227 = call i64 @__remill_read_memory_64(ptr noundef %205, i64 noundef %204) #15
  store i64 %call.i.i227, ptr %RAX, align 8
  store ptr %205, ptr %MEMORY, align 8
  br label %206

206:                                              ; preds = %200
  %207 = load i64, ptr %NEXT_PC, align 8
  store i64 %207, ptr %PC, align 8
  %208 = add i64 %207, 3
  store i64 %208, ptr %NEXT_PC, align 8
  %209 = load i64, ptr %RAX, align 8
  %210 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %210, i64 noundef %209) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i165 = icmp ult i32 %call.i.i, 10
  %call.i.i.i166 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i165, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i166 to i8
  %cf.i.i167 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i167, align 1
  %conv.i.i.i.i168 = trunc i32 %sub.i.i to i8
  %211 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i168)
  %212 = and i8 %211, 1
  %conv.i.i.i169 = xor i8 %212, 1
  %pf.i.i.i170 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i169, ptr %pf.i.i.i170, align 1
  %xor.i.i.i.i171 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i172 = xor i32 %xor.i.i.i.i171, %sub.i.i
  %213 = trunc i32 %xor1.i.i.i.i172 to i8
  %214 = lshr i8 %213, 4
  %conv2.i.i.i173 = and i8 %214, 1
  %af.i.i.i174 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i173, ptr %af.i.i.i174, align 1
  %cmp.i.i.i.i175 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i176 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i175, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i177 = zext i1 %call.i.i.i.i176 to i8
  %zf.i.i.i178 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i177, ptr %zf.i.i.i178, align 1
  %cmp.i27.i.i.i179 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i180 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i179, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i181 = zext i1 %call1.i.i.i.i180 to i8
  %sf.i.i.i182 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i181, ptr %sf.i.i.i182, align 1
  %xor.i28.i.i.i183 = lshr i32 %xor.i.i.i.i171, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i184 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i185 = add nuw nsw i32 %xor3.i.i.i.i184, %xor.i28.i.i.i183
  %cmp.i29.i.i.i186 = icmp eq i32 %add.i.i.i.i185, 2
  %call.i30.i.i.i187 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i186, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i188 = zext i1 %call.i30.i.i.i187 to i8
  %of.i.i.i189 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i188, ptr %of.i.i.i189, align 1
  store ptr %210, ptr %MEMORY, align 8
  br label %215

215:                                              ; preds = %206
  %216 = load i64, ptr %NEXT_PC, align 8
  store i64 %216, ptr %PC, align 8
  %217 = add i64 %216, 3
  store i64 %217, ptr %NEXT_PC, align 8
  %218 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %219 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %219, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %220 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %220, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %218, ptr %MEMORY, align 8
  br label %221

221:                                              ; preds = %215
  %222 = load i64, ptr %NEXT_PC, align 8
  store i64 %222, ptr %PC, align 8
  %223 = add i64 %222, 2
  store i64 %223, ptr %NEXT_PC, align 8
  %224 = load i32, ptr %EDX, align 4
  %225 = zext i32 %224 to i64
  %226 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %225, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %226, ptr %MEMORY, align 8
  br label %227

227:                                              ; preds = %221
  %228 = load i64, ptr %NEXT_PC, align 8
  store i64 %228, ptr %PC, align 8
  %229 = add i64 %228, 3
  store i64 %229, ptr %NEXT_PC, align 8
  %230 = load i64, ptr %RCX, align 8
  %231 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %230 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %232 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %232, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %233 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %234 = and i8 %233, 1
  %conv.i.i.i = xor i8 %234, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %235 = trunc i32 %xor1.i.i.i.i to i8
  %236 = lshr i8 %235, 4
  %conv2.i.i.i = and i8 %236, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %231, ptr %MEMORY, align 8
  br label %237

237:                                              ; preds = %227
  %238 = load i64, ptr %NEXT_PC, align 8
  store i64 %238, ptr %PC, align 8
  %239 = add i64 %238, 3
  store i64 %239, ptr %NEXT_PC, align 8
  %240 = load i64, ptr %RCX, align 8
  %241 = load i32, ptr %EDX, align 4
  %242 = zext i32 %241 to i64
  %243 = load ptr, ptr %MEMORY, align 8
  %conv.i.i208 = trunc i64 %240 to i32
  %sext.i = shl i64 %240, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %242, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %244 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i209 = icmp ult i64 %244, -4294967296
  %call.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i209, i32 noundef %conv.i.i208, i32 noundef %241, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i210 to i8
  %cf.i.i211 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i211, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %243, ptr %MEMORY, align 8
  br label %245

245:                                              ; preds = %237
  %246 = load i64, ptr %NEXT_PC, align 8
  store i64 %246, ptr %PC, align 8
  %247 = add i64 %246, 3
  store i64 %247, ptr %NEXT_PC, align 8
  %248 = load i64, ptr %RCX, align 8
  %249 = load ptr, ptr %MEMORY, align 8
  %conv.i.i231 = trunc i64 %248 to i32
  %and3.i.i = and i32 1, %conv.i.i231
  %conv.i22.i232 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i232, ptr %RCX, align 8
  %cf.i.i233 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i233, align 1
  %conv.i.i.i234 = trunc i32 %and3.i.i to i8
  %250 = and i8 %conv.i.i.i234, 1
  %conv.i23.i235 = xor i8 %250, 1
  %pf.i.i236 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i235, ptr %pf.i.i236, align 1
  %cmp.i.i.i237 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i238 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i237, i32 noundef %conv.i.i231, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i238 to i8
  %zf.i.i239 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i239, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i231, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i240 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i240, align 1
  %of.i.i241 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i241, align 1
  %af.i.i242 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i242, align 1
  store ptr %249, ptr %MEMORY, align 8
  br label %251

251:                                              ; preds = %245
  %252 = load i64, ptr %NEXT_PC, align 8
  store i64 %252, ptr %PC, align 8
  %253 = add i64 %252, 3
  store i64 %253, ptr %NEXT_PC, align 8
  %254 = load i32, ptr %ECX, align 4
  %255 = zext i32 %254 to i64
  %256 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i190 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %254, i32 noundef 0, i32 noundef %254) #15
  %conv.i12.i = zext i1 %call.i.i.i190 to i8
  %cf.i.i191 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i191, align 1
  %conv.i.i.i.i192 = trunc i32 %254 to i8
  %257 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i192)
  %258 = and i8 %257, 1
  %conv.i.i.i193 = xor i8 %258, 1
  %pf.i.i.i194 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i193, ptr %pf.i.i.i194, align 1
  %af.i.i.i195 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i195, align 1
  %cmp.i.i.i.i196 = icmp eq i32 %254, 0
  %call.i.i.i.i197 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i196, i32 noundef %254, i32 noundef 0, i32 noundef %254) #15
  %conv5.i.i.i198 = zext i1 %call.i.i.i.i197 to i8
  %zf.i.i.i199 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i198, ptr %zf.i.i.i199, align 1
  %cmp.i27.i.i.i200 = icmp slt i32 %254, 0
  %call1.i.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i200, i32 noundef %254, i32 noundef 0, i32 noundef %254) #15
  %conv8.i.i.i202 = zext i1 %call1.i.i.i.i201 to i8
  %sf.i.i.i203 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i202, ptr %sf.i.i.i203, align 1
  %xor.i28.i.i.i204 = lshr i32 %254, 31
  %call.i30.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %254, i32 noundef 0, i32 noundef %254) #15
  %conv11.i.i.i206 = zext i1 %call.i30.i.i.i205 to i8
  %of.i.i.i207 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i206, ptr %of.i.i.i207, align 1
  store ptr %256, ptr %MEMORY, align 8
  br label %259

259:                                              ; preds = %251
  %260 = load i64, ptr %NEXT_PC, align 8
  store i64 %260, ptr %PC, align 8
  %261 = add i64 %260, 3
  store i64 %261, ptr %NEXT_PC, align 8
  %262 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %263 = load i8, ptr %zf.i, align 1
  store i8 %263, ptr %CL, align 1
  store ptr %262, ptr %MEMORY, align 8
  br label %264

264:                                              ; preds = %259
  %265 = load i64, ptr %NEXT_PC, align 8
  store i64 %265, ptr %PC, align 8
  %266 = add i64 %265, 2
  store i64 %266, ptr %NEXT_PC, align 8
  %267 = load i8, ptr %AL, align 1
  %268 = zext i8 %267 to i64
  %269 = load i8, ptr %CL, align 1
  %270 = zext i8 %269 to i64
  %271 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %270, %268
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i243 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i243, align 1
  %272 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %273 = and i8 %272, 1
  %conv.i27.i = xor i8 %273, 1
  %pf.i.i244 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i244, align 1
  %274 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i245 = and i32 %274, 255
  %cmp.i.i.i246 = icmp eq i8 %or3.i.i, 0
  %275 = trunc i64 %268 to i32
  %conv1.i.i.i = and i32 %275, 255
  %276 = trunc i64 %270 to i32
  %conv2.i.i.i247 = and i32 %276, 255
  %call.i.i.i248 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i246, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i247, i32 noundef %conv.i.i.i245) #15
  %conv3.i.i249 = zext i1 %call.i.i.i248 to i8
  %zf.i.i250 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i249, ptr %zf.i.i250, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i247, i32 noundef %conv.i.i.i245) #15
  %conv6.i.i251 = zext i1 %call4.i.i.i to i8
  %sf.i.i252 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i251, ptr %sf.i.i252, align 1
  %of.i.i253 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i253, align 1
  %af.i.i254 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i254, align 1
  store ptr %271, ptr %MEMORY, align 8
  br label %277

277:                                              ; preds = %264
  %278 = load i64, ptr %NEXT_PC, align 8
  store i64 %278, ptr %PC, align 8
  %279 = add i64 %278, 2
  store i64 %279, ptr %NEXT_PC, align 8
  %280 = load i8, ptr %AL, align 1
  %281 = zext i8 %280 to i64
  %282 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %281
  %and3.i.i255 = trunc i64 %and3.i15.i to i8
  %cf.i.i256 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i256, align 1
  %283 = and i8 %and3.i.i255, 1
  %conv.i14.i = xor i8 %283, 1
  %pf.i.i257 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i257, align 1
  %284 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i258 = and i32 %284, 255
  %cmp.i.i.i259 = icmp eq i8 %and3.i.i255, 0
  %285 = trunc i64 %281 to i32
  %conv1.i.i.i260 = and i32 %285, 255
  %call.i.i.i261 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i259, i32 noundef %conv1.i.i.i260, i32 noundef 1, i32 noundef %conv.i.i.i258) #15
  %conv3.i.i262 = zext i1 %call.i.i.i261 to i8
  %zf.i.i263 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i262, ptr %zf.i.i263, align 1
  %call4.i.i.i264 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i260, i32 noundef 1, i32 noundef %conv.i.i.i258) #15
  %conv6.i.i265 = zext i1 %call4.i.i.i264 to i8
  %sf.i.i266 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i265, ptr %sf.i.i266, align 1
  %of.i.i267 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i267, align 1
  %af.i.i268 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i268, align 1
  store ptr %282, ptr %MEMORY, align 8
  br label %286

286:                                              ; preds = %277
  %287 = load i64, ptr %NEXT_PC, align 8
  store i64 %287, ptr %PC, align 8
  %288 = add i64 %287, 6
  store i64 %288, ptr %NEXT_PC, align 8
  %289 = load i64, ptr %NEXT_PC, align 8
  %290 = add i64 %289, 5
  %291 = load i64, ptr %NEXT_PC, align 8
  %292 = load ptr, ptr %MEMORY, align 8
  %zf.i212 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %293 = load i8, ptr %zf.i212, align 1
  %tobool.not.i = icmp eq i8 %293, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %290, i64 %291
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %292, ptr %MEMORY, align 8
  %294 = load i64, ptr %NEXT_PC, align 8
  store i64 %294, ptr %PC, align 8
  %295 = load ptr, ptr %MEMORY, align 8
  ret ptr %295
}

define ptr @BB_11fd(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1203(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11542
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11725
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1239(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 40
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i156 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i156, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #15
  %conv.i.i152 = zext i32 %call.i.i151 to i64
  store i64 %conv.i.i152, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %conv.i.i150 = zext i32 %call.i.i149 to i64
  store i64 %conv.i.i150, ptr %RSI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 5
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  store i64 2, ptr %RCX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %23
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 5
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RAX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %27
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 2
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i32, ptr %EDX, align 4
  %35 = zext i32 %34 to i64
  %36 = load i32, ptr %ESI, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %34, %36
  %cmp.i.i.i101 = icmp ult i32 %34, %36
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #15
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %39 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %40 = and i8 %39, 1
  %conv.i.i.i106 = xor i8 %40, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %36, %34
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %41 = trunc i32 %xor1.i.i.i.i109 to i8
  %42 = lshr i8 %41, 4
  %conv2.i.i.i110 = and i8 %42, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %34, %36
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #15
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #15
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %34
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %34, i32 noundef %36, i32 noundef %sub.i.i100) #15
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %38, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %31
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 3
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i32, ptr %EAX, align 4
  %47 = zext i32 %46 to i64
  %48 = load ptr, ptr %MEMORY, align 8
  %sf.i132 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %49 = load i8, ptr %sf.i132, align 1
  %tobool.i133 = icmp ne i8 %49, 0
  %of.i134 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %50 = load i8, ptr %of.i134, align 1
  %tobool4.i = icmp ne i8 %50, 0
  %cmp.i.i135 = xor i1 %tobool.i133, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i135) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %47, i64 %dst.coerce.val.i
  %conv.i23.i136 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i136, ptr %RCX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %51

51:                                               ; preds = %43
  %52 = load i64, ptr %NEXT_PC, align 8
  store i64 %52, ptr %PC, align 8
  %53 = add i64 %52, 7
  store i64 %53, ptr %NEXT_PC, align 8
  %54 = load i64, ptr %NEXT_PC, align 8
  %55 = add i64 %54, 11733
  %56 = load ptr, ptr %MEMORY, align 8
  store i64 %55, ptr %RAX, align 8
  store ptr %56, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %51
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i32, ptr %ECX, align 4
  %61 = zext i32 %60 to i64
  %62 = load ptr, ptr %MEMORY, align 8
  %sext.i158 = shl i64 %61, 32
  %conv.i12.i159 = ashr exact i64 %sext.i158, 32
  store i64 %conv.i12.i159, ptr %RCX, align 8
  store ptr %62, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 4
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %RAX, align 8
  %67 = load i64, ptr %RCX, align 8
  %68 = mul i64 %67, 8
  %69 = add i64 %66, %68
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i64 @__remill_read_memory_64(ptr noundef %70, i64 noundef %69) #15
  store i64 %call.i.i155, ptr %RAX, align 8
  store ptr %70, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 2
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load i64, ptr %RCX, align 8
  %75 = load i32, ptr %ECX, align 4
  %76 = zext i32 %75 to i64
  %77 = load ptr, ptr %MEMORY, align 8
  %conv.i.i184 = trunc i64 %74 to i32
  %xor3.i.i = xor i32 %75, %conv.i.i184
  %conv.i27.i185 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i185, ptr %RCX, align 8
  %cf.i.i186 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i186, align 1
  %conv.i.i.i187 = trunc i32 %xor3.i.i to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i187)
  %79 = and i8 %78, 1
  %conv.i28.i188 = xor i8 %79, 1
  %pf.i.i189 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i188, ptr %pf.i.i189, align 1
  %cmp.i.i.i190 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i191 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i190, i32 noundef %conv.i.i184, i32 noundef %75, i32 noundef %xor3.i.i) #15
  %conv3.i.i192 = zext i1 %call.i.i.i191 to i8
  %zf.i.i193 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i192, ptr %zf.i.i193, align 1
  %cmp.i19.i.i194 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i195 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i194, i32 noundef %conv.i.i184, i32 noundef %75, i32 noundef %xor3.i.i) #15
  %conv6.i.i196 = zext i1 %call1.i.i.i195 to i8
  %sf.i.i197 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i196, ptr %sf.i.i197, align 1
  %of.i.i198 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i198, align 1
  %af.i.i199 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i200 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i200, ptr %af.i.i199, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %71
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 2
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i32, ptr %EDX, align 4
  %84 = zext i32 %83 to i64
  %85 = load i32, ptr %ESI, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %83, %85
  %cmp.i.i.i73 = icmp ult i32 %83, %85
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #15
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %89 = and i8 %88, 1
  %conv.i.i.i78 = xor i8 %89, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %85, %83
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %90 = trunc i32 %xor1.i.i.i.i81 to i8
  %91 = lshr i8 %90, 4
  %conv2.i.i.i82 = and i8 %91, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %83, %85
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #15
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #15
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %83
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %83, i32 noundef %85, i32 noundef %sub.i.i72) #15
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %80
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 4
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %sf.i137 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %97 = load i8, ptr %sf.i137, align 1
  %tobool.i138 = icmp ne i8 %97, 0
  %of.i139 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %98 = load i8, ptr %of.i139, align 1
  %tobool4.i140 = icmp ne i8 %98, 0
  %cmp.i.i141 = xor i1 %tobool.i138, %tobool4.i140
  %call5.i142 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i141) #16
  %dst.coerce.val.i143 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i142, i64 %95, i64 %dst.coerce.val.i143
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %96, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %92
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 3
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %RAX, align 8
  %103 = load i64, ptr %RCX, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %102, %103
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %102, %103
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #15
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %106 = and i8 %105, 1
  %conv.i.i.i6 = xor i8 %106, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %103, %102
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %107 = trunc i64 %xor1.i.i.i.i9 to i8
  %108 = lshr i8 %107, 4
  %conv2.i.i.i10 = and i8 %108, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %102, %103
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %102
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %102, i64 noundef %103, i64 noundef %sub.i.i) #15
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %99
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 4
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RBP, align 8
  %113 = sub i64 %112, 64
  %114 = load i64, ptr %RAX, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %call.i.i146 = call ptr @__remill_write_memory_64(ptr noundef %115, i64 noundef %113, i64 noundef %114) #15
  store ptr %call.i.i146, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %109
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 7
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %NEXT_PC, align 8
  %120 = add i64 %119, 11440
  %121 = load ptr, ptr %MEMORY, align 8
  %call.i.i154 = call i64 @__remill_read_memory_64(ptr noundef %121, i64 noundef %120) #15
  store i64 %call.i.i154, ptr %RAX, align 8
  store ptr %121, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %116
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 2
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load i64, ptr %RAX, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  %call.i.i147 = call i32 @__remill_read_memory_32(ptr noundef %126, i64 noundef %125) #15
  %conv.i.i148 = zext i32 %call.i.i147 to i64
  store i64 %conv.i.i148, ptr %RDX, align 8
  store ptr %126, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %122
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 7
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i64, ptr %NEXT_PC, align 8
  %131 = add i64 %130, 11623
  %132 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i64 @__remill_read_memory_64(ptr noundef %132, i64 noundef %131) #15
  store i64 %call.i.i153, ptr %RAX, align 8
  store ptr %132, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %127
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 3
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %RAX, align 8
  %137 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %137, i64 noundef %136) #15
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %138 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %139 = and i8 %138, 1
  %conv.i.i.i32 = xor i8 %139, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %140 = trunc i32 %xor1.i.i.i.i35 to i8
  %141 = lshr i8 %140, 4
  %conv2.i.i.i36 = and i8 %141, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %133
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %146 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %146, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %147 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %147, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %145, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 2
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i32, ptr %EDX, align 4
  %152 = zext i32 %151 to i64
  %153 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %152, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %153, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %148
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i64, ptr %RCX, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %157 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %159 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %159, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %160 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %161 = and i8 %160, 1
  %conv.i.i.i = xor i8 %161, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %162 = trunc i32 %xor1.i.i.i.i to i8
  %163 = lshr i8 %162, 4
  %conv2.i.i.i = and i8 %163, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %158, ptr %MEMORY, align 8
  br label %164

164:                                              ; preds = %154
  %165 = load i64, ptr %NEXT_PC, align 8
  store i64 %165, ptr %PC, align 8
  %166 = add i64 %165, 3
  store i64 %166, ptr %NEXT_PC, align 8
  %167 = load i64, ptr %RCX, align 8
  %168 = load i32, ptr %EDX, align 4
  %169 = zext i32 %168 to i64
  %170 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %167 to i32
  %sext.i = shl i64 %167, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %169, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %171 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %171, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %168, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %170, ptr %MEMORY, align 8
  br label %172

172:                                              ; preds = %164
  %173 = load i64, ptr %NEXT_PC, align 8
  store i64 %173, ptr %PC, align 8
  %174 = add i64 %173, 3
  store i64 %174, ptr %NEXT_PC, align 8
  %175 = load i64, ptr %RCX, align 8
  %176 = load ptr, ptr %MEMORY, align 8
  %conv.i.i160 = trunc i64 %175 to i32
  %and3.i.i = and i32 1, %conv.i.i160
  %conv.i22.i161 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i161, ptr %RCX, align 8
  %cf.i.i162 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i162, align 1
  %conv.i.i.i163 = trunc i32 %and3.i.i to i8
  %177 = and i8 %conv.i.i.i163, 1
  %conv.i23.i164 = xor i8 %177, 1
  %pf.i.i165 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i164, ptr %pf.i.i165, align 1
  %cmp.i.i.i166 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i167 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i166, i32 noundef %conv.i.i160, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i167 to i8
  %zf.i.i168 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i168, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i160, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i169 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i169, align 1
  %of.i.i170 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i170, align 1
  %af.i.i171 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i171, align 1
  store ptr %176, ptr %MEMORY, align 8
  br label %178

178:                                              ; preds = %172
  %179 = load i64, ptr %NEXT_PC, align 8
  store i64 %179, ptr %PC, align 8
  %180 = add i64 %179, 3
  store i64 %180, ptr %NEXT_PC, align 8
  %181 = load i32, ptr %ECX, align 4
  %182 = zext i32 %181 to i64
  %183 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %181, i32 noundef 0, i32 noundef %181) #15
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %181 to i8
  %184 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %185 = and i8 %184, 1
  %conv.i.i.i57 = xor i8 %185, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %181, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %181, i32 noundef 0, i32 noundef %181) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %181, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %181, i32 noundef 0, i32 noundef %181) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %181, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %181, i32 noundef 0, i32 noundef %181) #15
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %183, ptr %MEMORY, align 8
  br label %186

186:                                              ; preds = %178
  %187 = load i64, ptr %NEXT_PC, align 8
  store i64 %187, ptr %PC, align 8
  %188 = add i64 %187, 3
  store i64 %188, ptr %NEXT_PC, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %190 = load i8, ptr %zf.i, align 1
  store i8 %190, ptr %CL, align 1
  store ptr %189, ptr %MEMORY, align 8
  br label %191

191:                                              ; preds = %186
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = add i64 %192, 2
  store i64 %193, ptr %NEXT_PC, align 8
  %194 = load i8, ptr %AL, align 1
  %195 = zext i8 %194 to i64
  %196 = load i8, ptr %CL, align 1
  %197 = zext i8 %196 to i64
  %198 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %197, %195
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i172 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i172, align 1
  %199 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %200 = and i8 %199, 1
  %conv.i27.i = xor i8 %200, 1
  %pf.i.i173 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i173, align 1
  %201 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i174 = and i32 %201, 255
  %cmp.i.i.i175 = icmp eq i8 %or3.i.i, 0
  %202 = trunc i64 %195 to i32
  %conv1.i.i.i = and i32 %202, 255
  %203 = trunc i64 %197 to i32
  %conv2.i.i.i176 = and i32 %203, 255
  %call.i.i.i177 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i175, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i176, i32 noundef %conv.i.i.i174) #15
  %conv3.i.i178 = zext i1 %call.i.i.i177 to i8
  %zf.i.i179 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i178, ptr %zf.i.i179, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i176, i32 noundef %conv.i.i.i174) #15
  %conv6.i.i180 = zext i1 %call4.i.i.i to i8
  %sf.i.i181 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i180, ptr %sf.i.i181, align 1
  %of.i.i182 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i182, align 1
  %af.i.i183 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i183, align 1
  store ptr %198, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %191
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 2
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i8, ptr %AL, align 1
  %208 = zext i8 %207 to i64
  %209 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %208
  %and3.i.i201 = trunc i64 %and3.i15.i to i8
  %cf.i.i202 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i202, align 1
  %210 = and i8 %and3.i.i201, 1
  %conv.i14.i = xor i8 %210, 1
  %pf.i.i203 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i203, align 1
  %211 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i204 = and i32 %211, 255
  %cmp.i.i.i205 = icmp eq i8 %and3.i.i201, 0
  %212 = trunc i64 %208 to i32
  %conv1.i.i.i206 = and i32 %212, 255
  %call.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i205, i32 noundef %conv1.i.i.i206, i32 noundef 1, i32 noundef %conv.i.i.i204) #15
  %conv3.i.i208 = zext i1 %call.i.i.i207 to i8
  %zf.i.i209 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i208, ptr %zf.i.i209, align 1
  %call4.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i206, i32 noundef 1, i32 noundef %conv.i.i.i204) #15
  %conv6.i.i211 = zext i1 %call4.i.i.i210 to i8
  %sf.i.i212 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i211, ptr %sf.i.i212, align 1
  %of.i.i213 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i213, align 1
  %af.i.i214 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i214, align 1
  store ptr %209, ptr %MEMORY, align 8
  br label %213

213:                                              ; preds = %204
  %214 = load i64, ptr %NEXT_PC, align 8
  store i64 %214, ptr %PC, align 8
  %215 = add i64 %214, 6
  store i64 %215, ptr %NEXT_PC, align 8
  %216 = load i64, ptr %NEXT_PC, align 8
  %217 = add i64 %216, 5
  %218 = load i64, ptr %NEXT_PC, align 8
  %219 = load ptr, ptr %MEMORY, align 8
  %zf.i144 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %220 = load i8, ptr %zf.i144, align 1
  %tobool.not.i = icmp eq i8 %220, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i145 = select i1 %call9.i, i64 %217, i64 %218
  store i64 %cond1.i.i145, ptr %NEXT_PC, align 8
  store ptr %219, ptr %MEMORY, align 8
  %221 = load i64, ptr %NEXT_PC, align 8
  store i64 %221, ptr %PC, align 8
  %222 = load ptr, ptr %MEMORY, align 8
  ret ptr %222
}

define ptr @BB_12a7(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 64
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_12ad(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11396
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11443
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_13c8(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11025
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11152
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_12e3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 40
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i107, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i102 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #15
  %conv.i.i103 = zext i32 %call.i.i102 to i64
  store i64 %conv.i.i103, ptr %RCX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RCX, align 8
  %22 = load i64, ptr %RAX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %21 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %23, i64 noundef %22) #15
  %add.i.i2 = add i32 %call.i.i, %conv.i.i1
  %conv.i18.i = zext i32 %add.i.i2 to i64
  store i64 %conv.i18.i, ptr %RCX, align 8
  %cmp.i.i.i3 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i4 = icmp ult i32 %add.i.i2, %call.i.i
  %24 = or i1 %cmp.i.i.i3, %cmp1.i.i.i4
  %call.i.i.i5 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %24, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv.i19.i = zext i1 %call.i.i.i5 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %add.i.i2 to i8
  %25 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %26 = and i8 %25, 1
  %conv.i.i.i8 = xor i8 %26, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 %add.i.i2, %call.i.i
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %conv.i.i1
  %27 = trunc i32 %xor1.i.i.i.i11 to i8
  %28 = lshr i8 %27, 4
  %conv2.i.i.i12 = and i8 %28, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i23 = lshr i32 %shr8.i.i.i.i22, 31
  %xor3.i.i.i.i24 = lshr i32 %xor.i.i.i.i10, 31
  %add.i.i.i.i25 = add nuw nsw i32 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i32 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %23, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %18
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load i32, ptr %ECX, align 4
  %34 = zext i32 %33 to i64
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_32(ptr noundef %35, i64 noundef %32, i32 noundef %33) #15
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 11600
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  store i64 %45, ptr %RAX, align 8
  %call.i.i.i30 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %45, i64 noundef 0, i64 noundef %45) #15
  %conv.i.i31 = zext i1 %call.i.i.i30 to i8
  %cf.i.i32 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i31, ptr %cf.i.i32, align 1
  %conv.i.i.i.i33 = trunc i64 %45 to i8
  %47 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i33)
  %48 = and i8 %47, 1
  %conv.i.i.i34 = xor i8 %48, 1
  %pf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i34, ptr %pf.i.i.i35, align 1
  %af.i.i.i36 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i36, align 1
  %cmp.i.i.i.i37 = icmp eq i64 %45, 0
  %call.i.i.i.i38 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i37, i64 noundef %45, i64 noundef 0, i64 noundef %45) #15
  %conv5.i.i.i39 = zext i1 %call.i.i.i.i38 to i8
  %zf.i.i.i40 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i39, ptr %zf.i.i.i40, align 1
  %cmp.i27.i.i.i41 = icmp slt i64 %45, 0
  %call1.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i41, i64 noundef %45, i64 noundef 0, i64 noundef %45) #15
  %conv8.i.i.i43 = zext i1 %call1.i.i.i.i42 to i8
  %sf.i.i.i44 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i43, ptr %sf.i.i.i44, align 1
  %xor.i28.i.i.i45 = lshr i64 %45, 63
  %call.i30.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %45, i64 noundef 0, i64 noundef %45) #15
  %conv11.i.i.i47 = zext i1 %call.i30.i.i.i46 to i8
  %of.i.i.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i47, ptr %of.i.i.i48, align 1
  store ptr %46, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 4
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RBP, align 8
  %53 = sub i64 %52, 72
  %54 = load i64, ptr %RAX, align 8
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_64(ptr noundef %55, i64 noundef %53, i64 noundef %54) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %49
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 7
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %NEXT_PC, align 8
  %60 = add i64 %59, 11233
  %61 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %61, i64 noundef %60) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %61, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %56
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 2
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RAX, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call i32 @__remill_read_memory_32(ptr noundef %66, i64 noundef %65) #15
  %conv.i.i101 = zext i32 %call.i.i100 to i64
  store i64 %conv.i.i101, ptr %RDX, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %62
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 7
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %NEXT_PC, align 8
  %71 = add i64 %70, 11376
  %72 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call i64 @__remill_read_memory_64(ptr noundef %72, i64 noundef %71) #15
  store i64 %call.i.i104, ptr %RAX, align 8
  store ptr %72, ptr %MEMORY, align 8
  br label %73

73:                                               ; preds = %67
  %74 = load i64, ptr %NEXT_PC, align 8
  store i64 %74, ptr %PC, align 8
  %75 = add i64 %74, 3
  store i64 %75, ptr %NEXT_PC, align 8
  %76 = load i64, ptr %RAX, align 8
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %77, i64 noundef %76) #15
  %sub.i.i = sub i32 %call.i.i49, 10
  %cmp.i.i.i50 = icmp ult i32 %call.i.i49, 10
  %call.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i50, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i51 to i8
  %cf.i.i52 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i52, align 1
  %conv.i.i.i.i53 = trunc i32 %sub.i.i to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i53)
  %79 = and i8 %78, 1
  %conv.i.i.i54 = xor i8 %79, 1
  %pf.i.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i54, ptr %pf.i.i.i55, align 1
  %xor.i.i.i.i56 = xor i32 %call.i.i49, 10
  %xor1.i.i.i.i57 = xor i32 %xor.i.i.i.i56, %sub.i.i
  %80 = trunc i32 %xor1.i.i.i.i57 to i8
  %81 = lshr i8 %80, 4
  %conv2.i.i.i58 = and i8 %81, 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i58, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %call.i.i49, 10
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %xor.i.i.i.i56, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i49
  %xor3.i.i.i.i69 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i70 = add nuw nsw i32 %xor3.i.i.i.i69, %xor.i28.i.i.i68
  %cmp.i29.i.i.i71 = icmp eq i32 %add.i.i.i.i70, 2
  %call.i30.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i71, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i73 = zext i1 %call.i30.i.i.i72 to i8
  %of.i.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i73, ptr %of.i.i.i74, align 1
  store ptr %77, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %73
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %86 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %86, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %87 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %87, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %85, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %82
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 2
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i32, ptr %EDX, align 4
  %92 = zext i32 %91 to i64
  %93 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %92, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i64, ptr %RCX, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %97 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %99 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %99, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %100 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %101 = and i8 %100, 1
  %conv.i.i.i = xor i8 %101, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %102 = trunc i32 %xor1.i.i.i.i to i8
  %103 = lshr i8 %102, 4
  %conv2.i.i.i = and i8 %103, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %98, ptr %MEMORY, align 8
  br label %104

104:                                              ; preds = %94
  %105 = load i64, ptr %NEXT_PC, align 8
  store i64 %105, ptr %PC, align 8
  %106 = add i64 %105, 3
  store i64 %106, ptr %NEXT_PC, align 8
  %107 = load i64, ptr %RCX, align 8
  %108 = load i32, ptr %EDX, align 4
  %109 = zext i32 %108 to i64
  %110 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %107 to i32
  %sext.i = shl i64 %107, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %109, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %111 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i94 = icmp ult i64 %111, -4294967296
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i93, i32 noundef %108, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i95 to i8
  %cf.i.i96 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i96, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %110, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %104
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %RCX, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %115 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %117 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %117, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %112
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 3
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i32, ptr %ECX, align 4
  %122 = zext i32 %121 to i64
  %123 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %121, i32 noundef 0, i32 noundef %121) #15
  %conv.i12.i = zext i1 %call.i.i.i75 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %121 to i8
  %124 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %125 = and i8 %124, 1
  %conv.i.i.i78 = xor i8 %125, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %af.i.i.i80 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i80, align 1
  %cmp.i.i.i.i81 = icmp eq i32 %121, 0
  %call.i.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i81, i32 noundef %121, i32 noundef 0, i32 noundef %121) #15
  %conv5.i.i.i83 = zext i1 %call.i.i.i.i82 to i8
  %zf.i.i.i84 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i83, ptr %zf.i.i.i84, align 1
  %cmp.i27.i.i.i85 = icmp slt i32 %121, 0
  %call1.i.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i85, i32 noundef %121, i32 noundef 0, i32 noundef %121) #15
  %conv8.i.i.i87 = zext i1 %call1.i.i.i.i86 to i8
  %sf.i.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i87, ptr %sf.i.i.i88, align 1
  %xor.i28.i.i.i89 = lshr i32 %121, 31
  %call.i30.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %121, i32 noundef 0, i32 noundef %121) #15
  %conv11.i.i.i91 = zext i1 %call.i30.i.i.i90 to i8
  %of.i.i.i92 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i91, ptr %of.i.i.i92, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %118
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 3
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %130 = load i8, ptr %zf.i, align 1
  store i8 %130, ptr %CL, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %126
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 2
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i8, ptr %AL, align 1
  %135 = zext i8 %134 to i64
  %136 = load i8, ptr %CL, align 1
  %137 = zext i8 %136 to i64
  %138 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %137, %135
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %139 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %140 = and i8 %139, 1
  %conv.i27.i = xor i8 %140, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %141 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %141, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %142 = trunc i64 %135 to i32
  %conv1.i.i.i = and i32 %142, 255
  %143 = trunc i64 %137 to i32
  %conv2.i.i.i125 = and i32 %143, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %138, ptr %MEMORY, align 8
  br label %144

144:                                              ; preds = %131
  %145 = load i64, ptr %NEXT_PC, align 8
  store i64 %145, ptr %PC, align 8
  %146 = add i64 %145, 2
  store i64 %146, ptr %NEXT_PC, align 8
  %147 = load i8, ptr %AL, align 1
  %148 = zext i8 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %148
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %150 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %150, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %151 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %151, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %152 = trunc i64 %148 to i32
  %conv1.i.i.i138 = and i32 %152, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %144
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 6
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %NEXT_PC, align 8
  %157 = add i64 %156, 5
  %158 = load i64, ptr %NEXT_PC, align 8
  %159 = load ptr, ptr %MEMORY, align 8
  %zf.i97 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %160 = load i8, ptr %zf.i97, align 1
  %tobool.not.i = icmp eq i8 %160, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %157, i64 %158
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %159, ptr %MEMORY, align 8
  %161 = load i64, ptr %NEXT_PC, align 8
  store i64 %161, ptr %PC, align 8
  %162 = load ptr, ptr %MEMORY, align 8
  ret ptr %162
}

define ptr @BB_13fe(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i75 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i75, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 1) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11329
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i74, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  store i64 %21, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %21 to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %21, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %21, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %21, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %18
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 4
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 88
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_64(ptr noundef %31, i64 noundef %29, i64 noundef %30) #15
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %25
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 10938
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 2
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RDX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %38
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 7
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %NEXT_PC, align 8
  %47 = add i64 %46, 11017
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %48, i64 noundef %47) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %53, i64 noundef %52) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %54 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %55 = and i8 %54, 1
  %conv.i.i.i24 = xor i8 %55, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %56 = trunc i32 %xor1.i.i.i.i27 to i8
  %57 = lshr i8 %56, 4
  %conv2.i.i.i28 = and i8 %57, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %53, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %49
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 2
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %68, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RCX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %73 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %75 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %75, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %76 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %77 = and i8 %76, 1
  %conv.i.i.i = xor i8 %77, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %78 = trunc i32 %xor1.i.i.i.i to i8
  %79 = lshr i8 %78, 4
  %conv2.i.i.i = and i8 %79, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %70
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RCX, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %83 to i32
  %sext.i = shl i64 %83, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %85, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %87 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %87, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %84, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %80
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %conv.i.i76 = trunc i64 %91 to i32
  %and3.i.i = and i32 1, %conv.i.i76
  %conv.i22.i77 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i77, ptr %RCX, align 8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %conv.i.i.i79 = trunc i32 %and3.i.i to i8
  %93 = and i8 %conv.i.i.i79, 1
  %conv.i23.i80 = xor i8 %93, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i80, ptr %pf.i.i81, align 1
  %cmp.i.i.i82 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i82, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i83 to i8
  %zf.i.i84 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i84, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i85, align 1
  %of.i.i86 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i86, align 1
  %af.i.i87 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i87, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i32, ptr %ECX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %97 to i8
  %100 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %101 = and i8 %100, 1
  %conv.i.i.i48 = xor i8 %101, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %97, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %97, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %97, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %94
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 3
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %106 = load i8, ptr %zf.i, align 1
  store i8 %106, ptr %CL, align 1
  store ptr %105, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %102
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 2
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i8, ptr %AL, align 1
  %111 = zext i8 %110 to i64
  %112 = load i8, ptr %CL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %113, %111
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i88, align 1
  %115 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %116 = and i8 %115, 1
  %conv.i27.i = xor i8 %116, 1
  %pf.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i89, align 1
  %117 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i90 = and i32 %117, 255
  %cmp.i.i.i91 = icmp eq i8 %or3.i.i, 0
  %118 = trunc i64 %111 to i32
  %conv1.i.i.i = and i32 %118, 255
  %119 = trunc i64 %113 to i32
  %conv2.i.i.i92 = and i32 %119, 255
  %call.i.i.i93 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i91, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #15
  %conv3.i.i94 = zext i1 %call.i.i.i93 to i8
  %zf.i.i95 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i94, ptr %zf.i.i95, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #15
  %conv6.i.i96 = zext i1 %call4.i.i.i to i8
  %sf.i.i97 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i96, ptr %sf.i.i97, align 1
  %of.i.i98 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i98, align 1
  %af.i.i99 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i99, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %107
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 2
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i8, ptr %AL, align 1
  %124 = zext i8 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %124
  %and3.i.i100 = trunc i64 %and3.i15.i to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i101, align 1
  %126 = and i8 %and3.i.i100, 1
  %conv.i14.i = xor i8 %126, 1
  %pf.i.i102 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i102, align 1
  %127 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i103 = and i32 %127, 255
  %cmp.i.i.i104 = icmp eq i8 %and3.i.i100, 0
  %128 = trunc i64 %124 to i32
  %conv1.i.i.i105 = and i32 %128, 255
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i104, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #15
  %conv3.i.i107 = zext i1 %call.i.i.i106 to i8
  %zf.i.i108 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i107, ptr %zf.i.i108, align 1
  %call4.i.i.i109 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #15
  %conv6.i.i110 = zext i1 %call4.i.i.i109 to i8
  %sf.i.i111 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i110, ptr %sf.i.i111, align 1
  %of.i.i112 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i112, align 1
  %af.i.i113 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i113, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %120
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 6
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %NEXT_PC, align 8
  %133 = add i64 %132, 5
  %134 = load i64, ptr %NEXT_PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %136 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %136, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %133, i64 %134
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %135, ptr %MEMORY, align 8
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  ret ptr %138
}

define ptr @BB_1336(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_144d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 88
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_133c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11149
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11284
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1453(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11110
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10909
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1372(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 11436
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #15
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 80
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #15
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 11061
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #15
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 11196
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_1489(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i159 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i159, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 40
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i158 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i158, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #15
  %conv.i.i152 = zext i32 %call.i.i151 to i64
  store i64 %conv.i.i152, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i157 = call i64 @__remill_read_memory_64(ptr noundef %22, i64 noundef %21) #15
  store i64 %call.i.i157, ptr %RAX, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 4
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RAX, align 8
  %27 = add i64 %26, 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i156 = call i64 @__remill_read_memory_64(ptr noundef %28, i64 noundef %27) #15
  store i64 %call.i.i156, ptr %RAX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %23
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 3
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %call.i.i160 = call zeroext i8 @__remill_read_memory_8(ptr noundef %33, i64 noundef %32) #15
  %conv.i.i161 = sext i8 %call.i.i160 to i64
  %conv.i10.i = and i64 %conv.i.i161, 4294967295
  store i64 %conv.i10.i, ptr %RSI, align 8
  store ptr %33, ptr %MEMORY, align 8
  br label %34

34:                                               ; preds = %29
  %35 = load i64, ptr %NEXT_PC, align 8
  store i64 %35, ptr %PC, align 8
  %36 = add i64 %35, 5
  store i64 %36, ptr %NEXT_PC, align 8
  %37 = load ptr, ptr %MEMORY, align 8
  store i64 6, ptr %RCX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %34
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 5
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  store i64 5, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %38
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i32, ptr %EDX, align 4
  %46 = zext i32 %45 to i64
  %47 = load i32, ptr %ESI, align 4
  %48 = zext i32 %47 to i64
  %49 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %45, %47
  %cmp.i.i.i101 = icmp ult i32 %45, %47
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %45, i32 noundef %47, i32 noundef %sub.i.i100) #15
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %50 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %51 = and i8 %50, 1
  %conv.i.i.i106 = xor i8 %51, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %47, %45
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %52 = trunc i32 %xor1.i.i.i.i109 to i8
  %53 = lshr i8 %52, 4
  %conv2.i.i.i110 = and i8 %53, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %45, %47
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %45, i32 noundef %47, i32 noundef %sub.i.i100) #15
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %45, i32 noundef %47, i32 noundef %sub.i.i100) #15
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %45
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %45, i32 noundef %47, i32 noundef %sub.i.i100) #15
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %54

54:                                               ; preds = %42
  %55 = load i64, ptr %NEXT_PC, align 8
  store i64 %55, ptr %PC, align 8
  %56 = add i64 %55, 3
  store i64 %56, ptr %NEXT_PC, align 8
  %57 = load i32, ptr %EAX, align 4
  %58 = zext i32 %57 to i64
  %59 = load ptr, ptr %MEMORY, align 8
  %zf.i132 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %60 = load i8, ptr %zf.i132, align 1
  %tobool.i133 = icmp ne i8 %60, 0
  %sf.i134 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %61 = load i8, ptr %sf.i134, align 1
  %tobool4.i = icmp ne i8 %61, 0
  %of.i135 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %62 = load i8, ptr %of.i135, align 1
  %tobool6.i = icmp ne i8 %62, 0
  %cmp.i.i136 = xor i1 %tobool4.i, %tobool6.i
  %63 = or i1 %tobool.i133, %cmp.i.i136
  %call8.i = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %63) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call8.i, i64 %58, i64 %dst.coerce.val.i
  %conv.i27.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i27.i, ptr %RCX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %54
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 7
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %NEXT_PC, align 8
  %68 = add i64 %67, 11133
  %69 = load ptr, ptr %MEMORY, align 8
  store i64 %68, ptr %RAX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i32, ptr %ECX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %sext.i162 = shl i64 %74, 32
  %conv.i12.i163 = ashr exact i64 %sext.i162, 32
  store i64 %conv.i12.i163, ptr %RCX, align 8
  store ptr %75, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %70
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 4
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RAX, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = mul i64 %80, 8
  %82 = add i64 %79, %81
  %83 = load ptr, ptr %MEMORY, align 8
  %call.i.i155 = call i64 @__remill_read_memory_64(ptr noundef %83, i64 noundef %82) #15
  store i64 %call.i.i155, ptr %RAX, align 8
  store ptr %83, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %76
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 2
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RCX, align 8
  %88 = load i32, ptr %ECX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i189 = trunc i64 %87 to i32
  %xor3.i.i = xor i32 %88, %conv.i.i189
  %conv.i27.i190 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i190, ptr %RCX, align 8
  %cf.i.i191 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i191, align 1
  %conv.i.i.i192 = trunc i32 %xor3.i.i to i8
  %91 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i192)
  %92 = and i8 %91, 1
  %conv.i28.i193 = xor i8 %92, 1
  %pf.i.i194 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i193, ptr %pf.i.i194, align 1
  %cmp.i.i.i195 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i196 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i195, i32 noundef %conv.i.i189, i32 noundef %88, i32 noundef %xor3.i.i) #15
  %conv3.i.i197 = zext i1 %call.i.i.i196 to i8
  %zf.i.i198 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i197, ptr %zf.i.i198, align 1
  %cmp.i19.i.i199 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i200 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i199, i32 noundef %conv.i.i189, i32 noundef %88, i32 noundef %xor3.i.i) #15
  %conv6.i.i201 = zext i1 %call1.i.i.i200 to i8
  %sf.i.i202 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i201, ptr %sf.i.i202, align 1
  %of.i.i203 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i203, align 1
  %af.i.i204 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i205 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i205, ptr %af.i.i204, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %84
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 2
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i32, ptr %EDX, align 4
  %97 = zext i32 %96 to i64
  %98 = load i32, ptr %ESI, align 4
  %99 = zext i32 %98 to i64
  %100 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %96, %98
  %cmp.i.i.i73 = icmp ult i32 %96, %98
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %101 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %102 = and i8 %101, 1
  %conv.i.i.i78 = xor i8 %102, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %98, %96
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %103 = trunc i32 %xor1.i.i.i.i81 to i8
  %104 = lshr i8 %103, 4
  %conv2.i.i.i82 = and i8 %104, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %96, %98
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %96
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %100, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %93
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 4
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %zf.i137 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %110 = load i8, ptr %zf.i137, align 1
  %tobool.i138 = icmp ne i8 %110, 0
  %sf.i139 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %111 = load i8, ptr %sf.i139, align 1
  %tobool4.i140 = icmp ne i8 %111, 0
  %of.i141 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %112 = load i8, ptr %of.i141, align 1
  %tobool6.i142 = icmp ne i8 %112, 0
  %cmp.i.i143 = xor i1 %tobool4.i140, %tobool6.i142
  %113 = or i1 %tobool.i138, %cmp.i.i143
  %call8.i144 = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %113) #16
  %dst.coerce.val.i145 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call8.i144, i64 %108, i64 %dst.coerce.val.i145
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %109, ptr %MEMORY, align 8
  br label %114

114:                                              ; preds = %105
  %115 = load i64, ptr %NEXT_PC, align 8
  store i64 %115, ptr %PC, align 8
  %116 = add i64 %115, 3
  store i64 %116, ptr %NEXT_PC, align 8
  %117 = load i64, ptr %RAX, align 8
  %118 = load i64, ptr %RCX, align 8
  %119 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %117, %118
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %117, %118
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %117, i64 noundef %118, i64 noundef %sub.i.i) #15
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %120 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %121 = and i8 %120, 1
  %conv.i.i.i6 = xor i8 %121, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %118, %117
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %122 = trunc i64 %xor1.i.i.i.i9 to i8
  %123 = lshr i8 %122, 4
  %conv2.i.i.i10 = and i8 %123, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %117, %118
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %117, i64 noundef %118, i64 noundef %sub.i.i) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %117, i64 noundef %118, i64 noundef %sub.i.i) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %117
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %117, i64 noundef %118, i64 noundef %sub.i.i) #15
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %119, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %114
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 4
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i64, ptr %RBP, align 8
  %128 = sub i64 %127, 96
  %129 = load i64, ptr %RAX, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call ptr @__remill_write_memory_64(ptr noundef %130, i64 noundef %128, i64 noundef %129) #15
  store ptr %call.i.i148, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %124
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 7
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i64, ptr %NEXT_PC, align 8
  %135 = add i64 %134, 10984
  %136 = load ptr, ptr %MEMORY, align 8
  %call.i.i154 = call i64 @__remill_read_memory_64(ptr noundef %136, i64 noundef %135) #15
  store i64 %call.i.i154, ptr %RAX, align 8
  store ptr %136, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %131
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i64, ptr %RAX, align 8
  %141 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i32 @__remill_read_memory_32(ptr noundef %141, i64 noundef %140) #15
  %conv.i.i150 = zext i32 %call.i.i149 to i64
  store i64 %conv.i.i150, ptr %RDX, align 8
  store ptr %141, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %137
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 7
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %NEXT_PC, align 8
  %146 = add i64 %145, 10783
  %147 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i64 @__remill_read_memory_64(ptr noundef %147, i64 noundef %146) #15
  store i64 %call.i.i153, ptr %RAX, align 8
  store ptr %147, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %142
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RAX, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %152, i64 noundef %151) #15
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %153 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %154 = and i8 %153, 1
  %conv.i.i.i32 = xor i8 %154, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %155 = trunc i32 %xor1.i.i.i.i35 to i8
  %156 = lshr i8 %155, 4
  %conv2.i.i.i36 = and i8 %156, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %152, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %148
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 3
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %161 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %161, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %162 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %162, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %160, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %157
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 2
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i32, ptr %EDX, align 4
  %167 = zext i32 %166 to i64
  %168 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %167, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %168, ptr %MEMORY, align 8
  br label %169

169:                                              ; preds = %163
  %170 = load i64, ptr %NEXT_PC, align 8
  store i64 %170, ptr %PC, align 8
  %171 = add i64 %170, 3
  store i64 %171, ptr %NEXT_PC, align 8
  %172 = load i64, ptr %RCX, align 8
  %173 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %172 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %174 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %174, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %175 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %176 = and i8 %175, 1
  %conv.i.i.i = xor i8 %176, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %177 = trunc i32 %xor1.i.i.i.i to i8
  %178 = lshr i8 %177, 4
  %conv2.i.i.i = and i8 %178, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %173, ptr %MEMORY, align 8
  br label %179

179:                                              ; preds = %169
  %180 = load i64, ptr %NEXT_PC, align 8
  store i64 %180, ptr %PC, align 8
  %181 = add i64 %180, 3
  store i64 %181, ptr %NEXT_PC, align 8
  %182 = load i64, ptr %RCX, align 8
  %183 = load i32, ptr %EDX, align 4
  %184 = zext i32 %183 to i64
  %185 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %182 to i32
  %sext.i = shl i64 %182, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %184, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %186 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %186, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %183, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %187

187:                                              ; preds = %179
  %188 = load i64, ptr %NEXT_PC, align 8
  store i64 %188, ptr %PC, align 8
  %189 = add i64 %188, 3
  store i64 %189, ptr %NEXT_PC, align 8
  %190 = load i64, ptr %RCX, align 8
  %191 = load ptr, ptr %MEMORY, align 8
  %conv.i.i164 = trunc i64 %190 to i32
  %and3.i.i = and i32 1, %conv.i.i164
  %conv.i22.i165 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i165, ptr %RCX, align 8
  %cf.i.i166 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i166, align 1
  %conv.i.i.i167 = trunc i32 %and3.i.i to i8
  %192 = and i8 %conv.i.i.i167, 1
  %conv.i23.i168 = xor i8 %192, 1
  %pf.i.i169 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i168, ptr %pf.i.i169, align 1
  %cmp.i.i.i170 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i171 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i170, i32 noundef %conv.i.i164, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i171 to i8
  %zf.i.i172 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i172, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i164, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i173 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i173, align 1
  %of.i.i174 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i174, align 1
  %af.i.i175 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i175, align 1
  store ptr %191, ptr %MEMORY, align 8
  br label %193

193:                                              ; preds = %187
  %194 = load i64, ptr %NEXT_PC, align 8
  store i64 %194, ptr %PC, align 8
  %195 = add i64 %194, 3
  store i64 %195, ptr %NEXT_PC, align 8
  %196 = load i32, ptr %ECX, align 4
  %197 = zext i32 %196 to i64
  %198 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %196, i32 noundef 0, i32 noundef %196) #15
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %196 to i8
  %199 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %200 = and i8 %199, 1
  %conv.i.i.i57 = xor i8 %200, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %196, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %196, i32 noundef 0, i32 noundef %196) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %196, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %196, i32 noundef 0, i32 noundef %196) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %196, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %196, i32 noundef 0, i32 noundef %196) #15
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %198, ptr %MEMORY, align 8
  br label %201

201:                                              ; preds = %193
  %202 = load i64, ptr %NEXT_PC, align 8
  store i64 %202, ptr %PC, align 8
  %203 = add i64 %202, 3
  store i64 %203, ptr %NEXT_PC, align 8
  %204 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %205 = load i8, ptr %zf.i, align 1
  store i8 %205, ptr %CL, align 1
  store ptr %204, ptr %MEMORY, align 8
  br label %206

206:                                              ; preds = %201
  %207 = load i64, ptr %NEXT_PC, align 8
  store i64 %207, ptr %PC, align 8
  %208 = add i64 %207, 2
  store i64 %208, ptr %NEXT_PC, align 8
  %209 = load i8, ptr %AL, align 1
  %210 = zext i8 %209 to i64
  %211 = load i8, ptr %CL, align 1
  %212 = zext i8 %211 to i64
  %213 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %212, %210
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i176 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i176, align 1
  %214 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %215 = and i8 %214, 1
  %conv.i27.i177 = xor i8 %215, 1
  %pf.i.i178 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i177, ptr %pf.i.i178, align 1
  %216 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i179 = and i32 %216, 255
  %cmp.i.i.i180 = icmp eq i8 %or3.i.i, 0
  %217 = trunc i64 %210 to i32
  %conv1.i.i.i = and i32 %217, 255
  %218 = trunc i64 %212 to i32
  %conv2.i.i.i181 = and i32 %218, 255
  %call.i.i.i182 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i180, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i181, i32 noundef %conv.i.i.i179) #15
  %conv3.i.i183 = zext i1 %call.i.i.i182 to i8
  %zf.i.i184 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i183, ptr %zf.i.i184, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i181, i32 noundef %conv.i.i.i179) #15
  %conv6.i.i185 = zext i1 %call4.i.i.i to i8
  %sf.i.i186 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i185, ptr %sf.i.i186, align 1
  %of.i.i187 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i187, align 1
  %af.i.i188 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i188, align 1
  store ptr %213, ptr %MEMORY, align 8
  br label %219

219:                                              ; preds = %206
  %220 = load i64, ptr %NEXT_PC, align 8
  store i64 %220, ptr %PC, align 8
  %221 = add i64 %220, 2
  store i64 %221, ptr %NEXT_PC, align 8
  %222 = load i8, ptr %AL, align 1
  %223 = zext i8 %222 to i64
  %224 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %223
  %and3.i.i206 = trunc i64 %and3.i15.i to i8
  %cf.i.i207 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i207, align 1
  %225 = and i8 %and3.i.i206, 1
  %conv.i14.i = xor i8 %225, 1
  %pf.i.i208 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i208, align 1
  %226 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i209 = and i32 %226, 255
  %cmp.i.i.i210 = icmp eq i8 %and3.i.i206, 0
  %227 = trunc i64 %223 to i32
  %conv1.i.i.i211 = and i32 %227, 255
  %call.i.i.i212 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i210, i32 noundef %conv1.i.i.i211, i32 noundef 1, i32 noundef %conv.i.i.i209) #15
  %conv3.i.i213 = zext i1 %call.i.i.i212 to i8
  %zf.i.i214 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i213, ptr %zf.i.i214, align 1
  %call4.i.i.i215 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i211, i32 noundef 1, i32 noundef %conv.i.i.i209) #15
  %conv6.i.i216 = zext i1 %call4.i.i.i215 to i8
  %sf.i.i217 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i216, ptr %sf.i.i217, align 1
  %of.i.i218 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i218, align 1
  %af.i.i219 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i219, align 1
  store ptr %224, ptr %MEMORY, align 8
  br label %228

228:                                              ; preds = %219
  %229 = load i64, ptr %NEXT_PC, align 8
  store i64 %229, ptr %PC, align 8
  %230 = add i64 %229, 6
  store i64 %230, ptr %NEXT_PC, align 8
  %231 = load i64, ptr %NEXT_PC, align 8
  %232 = add i64 %231, 5
  %233 = load i64, ptr %NEXT_PC, align 8
  %234 = load ptr, ptr %MEMORY, align 8
  %zf.i146 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %235 = load i8, ptr %zf.i146, align 1
  %tobool.not.i = icmp eq i8 %235, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i147 = select i1 %call9.i, i64 %232, i64 %233
  store i64 %cond1.i.i147, ptr %NEXT_PC, align 8
  store ptr %234, ptr %MEMORY, align 8
  %236 = load i64, ptr %NEXT_PC, align 8
  store i64 %236, ptr %PC, align 8
  %237 = load ptr, ptr %MEMORY, align 8
  ret ptr %237
}

define ptr @BB_13c2(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_14ff(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 96
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_1505(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10948
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10747
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_161c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10541
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10596
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_153b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i102 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i103 = zext i32 %call.i.i102 to i64
  store i64 %conv.i.i103, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 2
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load i64, ptr %RAX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #15
  %add.i.i2 = add i32 %call.i.i, %conv.i.i1
  %conv.i18.i = zext i32 %add.i.i2 to i64
  store i64 %conv.i18.i, ptr %RCX, align 8
  %cmp.i.i.i3 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i4 = icmp ult i32 %add.i.i2, %call.i.i
  %18 = or i1 %cmp.i.i.i3, %cmp1.i.i.i4
  %call.i.i.i5 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %18, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv.i19.i = zext i1 %call.i.i.i5 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i19.i, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %add.i.i2 to i8
  %19 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %20 = and i8 %19, 1
  %conv.i.i.i8 = xor i8 %20, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 %add.i.i2, %call.i.i
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %conv.i.i1
  %21 = trunc i32 %xor1.i.i.i.i11 to i8
  %22 = lshr i8 %21, 4
  %conv2.i.i.i12 = and i8 %22, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i23 = lshr i32 %shr8.i.i.i.i22, 31
  %xor3.i.i.i.i24 = lshr i32 %xor.i.i.i.i10, 31
  %add.i.i.i.i25 = add nuw nsw i32 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i32 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i32 noundef %conv.i.i1, i32 noundef %call.i.i, i32 noundef %add.i.i2) #15
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %17, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %12
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 2
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RAX, align 8
  %27 = load i32, ptr %ECX, align 4
  %28 = zext i32 %27 to i64
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_32(ptr noundef %29, i64 noundef %26, i32 noundef %27) #15
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %23
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 7
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %NEXT_PC, align 8
  %34 = add i64 %33, 11036
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %35, i64 noundef %34) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %30
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 4
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %RAX, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  store i64 %39, ptr %RAX, align 8
  %call.i.i.i30 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %39, i64 noundef 0, i64 noundef %39) #15
  %conv.i.i31 = zext i1 %call.i.i.i30 to i8
  %cf.i.i32 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i31, ptr %cf.i.i32, align 1
  %conv.i.i.i.i33 = trunc i64 %39 to i8
  %41 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i33)
  %42 = and i8 %41, 1
  %conv.i.i.i34 = xor i8 %42, 1
  %pf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i34, ptr %pf.i.i.i35, align 1
  %af.i.i.i36 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i36, align 1
  %cmp.i.i.i.i37 = icmp eq i64 %39, 0
  %call.i.i.i.i38 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i37, i64 noundef %39, i64 noundef 0, i64 noundef %39) #15
  %conv5.i.i.i39 = zext i1 %call.i.i.i.i38 to i8
  %zf.i.i.i40 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i39, ptr %zf.i.i.i40, align 1
  %cmp.i27.i.i.i41 = icmp slt i64 %39, 0
  %call1.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i41, i64 noundef %39, i64 noundef 0, i64 noundef %39) #15
  %conv8.i.i.i43 = zext i1 %call1.i.i.i.i42 to i8
  %sf.i.i.i44 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i43, ptr %sf.i.i.i44, align 1
  %xor.i28.i.i.i45 = lshr i64 %39, 63
  %call.i30.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %39, i64 noundef 0, i64 noundef %39) #15
  %conv11.i.i.i47 = zext i1 %call.i30.i.i.i46 to i8
  %of.i.i.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i47, ptr %of.i.i.i48, align 1
  store ptr %40, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %36
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 4
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %RBP, align 8
  %47 = sub i64 %46, 104
  %48 = load i64, ptr %RAX, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_64(ptr noundef %49, i64 noundef %47, i64 noundef %48) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %43
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 7
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %NEXT_PC, align 8
  %54 = add i64 %53, 10861
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %55, i64 noundef %54) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %50
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call i32 @__remill_read_memory_32(ptr noundef %60, i64 noundef %59) #15
  %conv.i.i101 = zext i32 %call.i.i100 to i64
  store i64 %conv.i.i101, ptr %RDX, align 8
  store ptr %60, ptr %MEMORY, align 8
  br label %61

61:                                               ; preds = %56
  %62 = load i64, ptr %NEXT_PC, align 8
  store i64 %62, ptr %PC, align 8
  %63 = add i64 %62, 7
  store i64 %63, ptr %NEXT_PC, align 8
  %64 = load i64, ptr %NEXT_PC, align 8
  %65 = add i64 %64, 10660
  %66 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call i64 @__remill_read_memory_64(ptr noundef %66, i64 noundef %65) #15
  store i64 %call.i.i104, ptr %RAX, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %61
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RAX, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %71, i64 noundef %70) #15
  %sub.i.i = sub i32 %call.i.i49, 10
  %cmp.i.i.i50 = icmp ult i32 %call.i.i49, 10
  %call.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i50, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i51 to i8
  %cf.i.i52 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i52, align 1
  %conv.i.i.i.i53 = trunc i32 %sub.i.i to i8
  %72 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i53)
  %73 = and i8 %72, 1
  %conv.i.i.i54 = xor i8 %73, 1
  %pf.i.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i54, ptr %pf.i.i.i55, align 1
  %xor.i.i.i.i56 = xor i32 %call.i.i49, 10
  %xor1.i.i.i.i57 = xor i32 %xor.i.i.i.i56, %sub.i.i
  %74 = trunc i32 %xor1.i.i.i.i57 to i8
  %75 = lshr i8 %74, 4
  %conv2.i.i.i58 = and i8 %75, 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i58, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %call.i.i49, 10
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %xor.i.i.i.i56, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i49
  %xor3.i.i.i.i69 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i70 = add nuw nsw i32 %xor3.i.i.i.i69, %xor.i28.i.i.i68
  %cmp.i29.i.i.i71 = icmp eq i32 %add.i.i.i.i70, 2
  %call.i30.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i71, i32 noundef %call.i.i49, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i73 = zext i1 %call.i30.i.i.i72 to i8
  %of.i.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i73, ptr %of.i.i.i74, align 1
  store ptr %71, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %67
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %80 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %80, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %81 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %81, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %79, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 2
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %EDX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %86, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %87, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %82
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %91 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %93 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %93, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %94 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %95 = and i8 %94, 1
  %conv.i.i.i = xor i8 %95, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %96 = trunc i32 %xor1.i.i.i.i to i8
  %97 = lshr i8 %96, 4
  %conv2.i.i.i = and i8 %97, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %88
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RCX, align 8
  %102 = load i32, ptr %EDX, align 4
  %103 = zext i32 %102 to i64
  %104 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %101 to i32
  %sext.i = shl i64 %101, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %103, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %105 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i94 = icmp ult i64 %105, -4294967296
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i93, i32 noundef %102, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i95 to i8
  %cf.i.i96 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i96, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %104, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %98
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %RCX, align 8
  %110 = load ptr, ptr %MEMORY, align 8
  %conv.i.i108 = trunc i64 %109 to i32
  %and3.i.i = and i32 1, %conv.i.i108
  %conv.i22.i109 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i109, ptr %RCX, align 8
  %cf.i.i110 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i110, align 1
  %conv.i.i.i111 = trunc i32 %and3.i.i to i8
  %111 = and i8 %conv.i.i.i111, 1
  %conv.i23.i112 = xor i8 %111, 1
  %pf.i.i113 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i112, ptr %pf.i.i113, align 1
  %cmp.i.i.i114 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i114, i32 noundef %conv.i.i108, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i115 to i8
  %zf.i.i116 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i116, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i108, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i117 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i117, align 1
  %of.i.i118 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i118, align 1
  %af.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i119, align 1
  store ptr %110, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %106
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i32, ptr %ECX, align 4
  %116 = zext i32 %115 to i64
  %117 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %115, i32 noundef 0, i32 noundef %115) #15
  %conv.i12.i = zext i1 %call.i.i.i75 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %115 to i8
  %118 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %119 = and i8 %118, 1
  %conv.i.i.i78 = xor i8 %119, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %af.i.i.i80 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i80, align 1
  %cmp.i.i.i.i81 = icmp eq i32 %115, 0
  %call.i.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i81, i32 noundef %115, i32 noundef 0, i32 noundef %115) #15
  %conv5.i.i.i83 = zext i1 %call.i.i.i.i82 to i8
  %zf.i.i.i84 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i83, ptr %zf.i.i.i84, align 1
  %cmp.i27.i.i.i85 = icmp slt i32 %115, 0
  %call1.i.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i85, i32 noundef %115, i32 noundef 0, i32 noundef %115) #15
  %conv8.i.i.i87 = zext i1 %call1.i.i.i.i86 to i8
  %sf.i.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i87, ptr %sf.i.i.i88, align 1
  %xor.i28.i.i.i89 = lshr i32 %115, 31
  %call.i30.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %115, i32 noundef 0, i32 noundef %115) #15
  %conv11.i.i.i91 = zext i1 %call.i30.i.i.i90 to i8
  %of.i.i.i92 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i91, ptr %of.i.i.i92, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %112
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 3
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i, align 1
  store i8 %124, ptr %CL, align 1
  store ptr %123, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %120
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 2
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i8, ptr %AL, align 1
  %129 = zext i8 %128 to i64
  %130 = load i8, ptr %CL, align 1
  %131 = zext i8 %130 to i64
  %132 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %131, %129
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i120 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i120, align 1
  %133 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %134 = and i8 %133, 1
  %conv.i27.i = xor i8 %134, 1
  %pf.i.i121 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i121, align 1
  %135 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i122 = and i32 %135, 255
  %cmp.i.i.i123 = icmp eq i8 %or3.i.i, 0
  %136 = trunc i64 %129 to i32
  %conv1.i.i.i = and i32 %136, 255
  %137 = trunc i64 %131 to i32
  %conv2.i.i.i124 = and i32 %137, 255
  %call.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i123, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i124, i32 noundef %conv.i.i.i122) #15
  %conv3.i.i126 = zext i1 %call.i.i.i125 to i8
  %zf.i.i127 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i126, ptr %zf.i.i127, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i124, i32 noundef %conv.i.i.i122) #15
  %conv6.i.i128 = zext i1 %call4.i.i.i to i8
  %sf.i.i129 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i128, ptr %sf.i.i129, align 1
  %of.i.i130 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i130, align 1
  %af.i.i131 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i131, align 1
  store ptr %132, ptr %MEMORY, align 8
  br label %138

138:                                              ; preds = %125
  %139 = load i64, ptr %NEXT_PC, align 8
  store i64 %139, ptr %PC, align 8
  %140 = add i64 %139, 2
  store i64 %140, ptr %NEXT_PC, align 8
  %141 = load i8, ptr %AL, align 1
  %142 = zext i8 %141 to i64
  %143 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %142
  %and3.i.i132 = trunc i64 %and3.i15.i to i8
  %cf.i.i133 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i133, align 1
  %144 = and i8 %and3.i.i132, 1
  %conv.i14.i = xor i8 %144, 1
  %pf.i.i134 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i134, align 1
  %145 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i135 = and i32 %145, 255
  %cmp.i.i.i136 = icmp eq i8 %and3.i.i132, 0
  %146 = trunc i64 %142 to i32
  %conv1.i.i.i137 = and i32 %146, 255
  %call.i.i.i138 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i136, i32 noundef %conv1.i.i.i137, i32 noundef 1, i32 noundef %conv.i.i.i135) #15
  %conv3.i.i139 = zext i1 %call.i.i.i138 to i8
  %zf.i.i140 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i139, ptr %zf.i.i140, align 1
  %call4.i.i.i141 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i137, i32 noundef 1, i32 noundef %conv.i.i.i135) #15
  %conv6.i.i142 = zext i1 %call4.i.i.i141 to i8
  %sf.i.i143 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i142, ptr %sf.i.i143, align 1
  %of.i.i144 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i144, align 1
  %af.i.i145 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i145, align 1
  store ptr %143, ptr %MEMORY, align 8
  br label %147

147:                                              ; preds = %138
  %148 = load i64, ptr %NEXT_PC, align 8
  store i64 %148, ptr %PC, align 8
  %149 = add i64 %148, 6
  store i64 %149, ptr %NEXT_PC, align 8
  %150 = load i64, ptr %NEXT_PC, align 8
  %151 = add i64 %150, 5
  %152 = load i64, ptr %NEXT_PC, align 8
  %153 = load ptr, ptr %MEMORY, align 8
  %zf.i97 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %154 = load i8, ptr %zf.i97, align 1
  %tobool.not.i = icmp eq i8 %154, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %151, i64 %152
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %153, ptr %MEMORY, align 8
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = load ptr, ptr %MEMORY, align 8
  ret ptr %156
}

define ptr @BB_1652(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RSI, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 2465
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RDI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %21, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %18
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 5
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %NEXT_PC, align 8
  %26 = sub i64 %25, 1590
  %27 = load i64, ptr %NEXT_PC, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  %29 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %29, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %28, i64 noundef %sub.i.i, i64 noundef %27) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %26, ptr %rip.i, align 8
  store i64 %26, ptr %NEXT_PC, align 8
  store i64 %27, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  ret ptr %30
}

define ptr @BB_158a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 104
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_1590(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10777
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10760
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_1666(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10459
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10538
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_15c6(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 10872
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #15
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 112
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #15
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 10585
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #15
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 10664
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_169c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 2
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RAX, align 8
  %5 = load i32, ptr %EAX, align 4
  %6 = zext i32 %5 to i64
  %7 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %4 to i32
  %xor3.i.i = xor i32 %5, %conv.i.i
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RAX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %xor3.i.i to i8
  %8 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %9 = and i8 %8, 1
  %conv.i28.i = xor i8 %9, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef %5, i32 noundef %xor3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i, i32 noundef %5, i32 noundef %xor3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %7, ptr %MEMORY, align 8
  br label %10

10:                                               ; preds = %1
  %11 = load i64, ptr %NEXT_PC, align 8
  store i64 %11, ptr %PC, align 8
  %12 = add i64 %11, 3
  store i64 %12, ptr %NEXT_PC, align 8
  %13 = load i64, ptr %RBP, align 8
  %14 = load ptr, ptr %MEMORY, align 8
  store i64 %13, ptr %RSP, align 8
  store ptr %14, ptr %MEMORY, align 8
  br label %15

15:                                               ; preds = %10
  %16 = load i64, ptr %NEXT_PC, align 8
  store i64 %16, ptr %PC, align 8
  %17 = add i64 %16, 1
  store i64 %17, ptr %NEXT_PC, align 8
  %18 = load ptr, ptr %MEMORY, align 8
  %rsp.i1 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  %19 = load i64, ptr %rsp.i1, align 8
  %add.i.i2 = add i64 %19, 8
  store i64 %add.i.i2, ptr %rsp.i1, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %19) #15
  store i64 %call.i.i3, ptr %RBP, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %15
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 1
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  %24 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %24) #15
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %25, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %23, ptr %MEMORY, align 8
  %26 = load ptr, ptr %MEMORY, align 8
  ret ptr %26
}

define ptr @BB_1616(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.125295, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 112
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.125295, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.125295) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #17
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.125295) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !14
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !14
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 4368, label %bb_1110
    i64 4437, label %bb_1155
    i64 4605, label %bb_11FD
    i64 4611, label %bb_1203
    i64 4665, label %bb_1239
    i64 4775, label %bb_12A7
    i64 4781, label %bb_12AD
    i64 4835, label %bb_12E3
    i64 4918, label %bb_1336
    i64 4924, label %bb_133C
    i64 4978, label %bb_1372
    i64 5058, label %bb_13C2
    i64 5064, label %bb_13C8
    i64 5118, label %bb_13FE
    i64 5197, label %bb_144D
    i64 5203, label %bb_1453
    i64 5257, label %bb_1489
    i64 5375, label %bb_14FF
    i64 5381, label %bb_1505
    i64 5435, label %bb_153B
    i64 5514, label %bb_158A
    i64 5520, label %bb_1590
    i64 5574, label %bb_15C6
    i64 5654, label %bb_1616
    i64 5660, label %bb_161C
    i64 5714, label %bb_1652
    i64 5734, label %bb_1666
    i64 5788, label %bb_169C
    i64 -281474976710656, label %bb_FFFF000000000000
  ]

dead_end:                                         ; preds = %bb_FFFF000000000000, %bb_1666, %bb_1652, %bb_161C, %bb_1616, %bb_15C6, %bb_1590, %bb_158A, %bb_153B, %bb_1505, %bb_14FF, %bb_1489, %bb_1453, %bb_144D, %bb_13FE, %bb_13C8, %bb_13C2, %bb_1372, %bb_133C, %bb_1336, %bb_12E3, %bb_12AD, %bb_12A7, %bb_1239, %bb_1203, %bb_11FD, %bb_1155, %bb_1110, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_1110:                                          ; preds = %entry
  %block_pc = add i64 4368, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 4368, ptr %1)
  %4 = call ptr @BB_1110(ptr %state, i64 %2, ptr %1) #18
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 4437, label %bb_1155
  ]

bb_1155:                                          ; preds = %bb_1110, %entry
  %block_pc1 = add i64 4437, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 4437, ptr %6)
  %9 = call ptr @BB_1155(ptr %state, i64 %7, ptr %6) #18
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 4605, label %bb_11FD
  ]

bb_11FD:                                          ; preds = %bb_1155, %entry
  %block_pc3 = add i64 4605, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 4605, ptr %11)
  %14 = call ptr @BB_11fd(ptr %state, i64 %12, ptr %11) #18
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 4611, label %bb_1203
  ]

bb_1203:                                          ; preds = %bb_13C2, %bb_11FD, %entry
  %block_pc5 = add i64 4611, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 4611, ptr %16)
  %19 = call ptr @BB_1203(ptr %state, i64 %17, ptr %16) #18
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 4665, label %bb_1239
  ]

bb_1239:                                          ; preds = %bb_1203, %entry
  %block_pc7 = add i64 4665, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 4665, ptr %21)
  %24 = call ptr @BB_1239(ptr %state, i64 %22, ptr %21) #18
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 4775, label %bb_12A7
  ]

bb_12A7:                                          ; preds = %bb_1239, %entry
  %block_pc9 = add i64 4775, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 4775, ptr %26)
  %29 = call ptr @BB_12a7(ptr %state, i64 %27, ptr %26) #18
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 4781, label %bb_12AD
    i64 5064, label %bb_13C8
  ]

bb_12AD:                                          ; preds = %bb_12A7, %entry
  %block_pc11 = add i64 4781, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 4781, ptr %31)
  %34 = call ptr @BB_12ad(ptr %state, i64 %32, ptr %31) #18
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 4835, label %bb_12E3
  ]

bb_12E3:                                          ; preds = %bb_12AD, %entry
  %block_pc13 = add i64 4835, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 4835, ptr %36)
  %39 = call ptr @BB_12e3(ptr %state, i64 %37, ptr %36) #18
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 4918, label %bb_1336
  ]

bb_1336:                                          ; preds = %bb_12E3, %entry
  %block_pc15 = add i64 4918, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 4918, ptr %41)
  %44 = call ptr @BB_1336(ptr %state, i64 %42, ptr %41) #18
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 4924, label %bb_133C
  ]

bb_133C:                                          ; preds = %bb_1336, %entry
  %block_pc17 = add i64 4924, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 4924, ptr %46)
  %49 = call ptr @BB_133c(ptr %state, i64 %47, ptr %46) #18
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 4978, label %bb_1372
  ]

bb_1372:                                          ; preds = %bb_133C, %entry
  %block_pc19 = add i64 4978, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 4978, ptr %51)
  %54 = call ptr @BB_1372(ptr %state, i64 %52, ptr %51) #18
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 5058, label %bb_13C2
  ]

bb_13C2:                                          ; preds = %bb_1372, %entry
  %block_pc21 = add i64 5058, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 5058, ptr %56)
  %59 = call ptr @BB_13c2(ptr %state, i64 %57, ptr %56) #18
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 4611, label %bb_1203
  ]

bb_13C8:                                          ; preds = %bb_12A7, %entry
  %block_pc23 = add i64 5064, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 5064, ptr %61)
  %64 = call ptr @BB_13c8(ptr %state, i64 %62, ptr %61) #18
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 5118, label %bb_13FE
  ]

bb_13FE:                                          ; preds = %bb_13C8, %entry
  %block_pc25 = add i64 5118, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 5118, ptr %66)
  %69 = call ptr @BB_13fe(ptr %state, i64 %67, ptr %66) #18
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 5197, label %bb_144D
  ]

bb_144D:                                          ; preds = %bb_13FE, %entry
  %block_pc27 = add i64 5197, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 5197, ptr %71)
  %74 = call ptr @BB_144d(ptr %state, i64 %72, ptr %71) #18
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 5203, label %bb_1453
  ]

bb_1453:                                          ; preds = %bb_1616, %bb_144D, %entry
  %block_pc29 = add i64 5203, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 5203, ptr %76)
  %79 = call ptr @BB_1453(ptr %state, i64 %77, ptr %76) #18
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 5257, label %bb_1489
  ]

bb_1489:                                          ; preds = %bb_1453, %entry
  %block_pc31 = add i64 5257, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 5257, ptr %81)
  %84 = call ptr @BB_1489(ptr %state, i64 %82, ptr %81) #18
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 5375, label %bb_14FF
  ]

bb_14FF:                                          ; preds = %bb_1489, %entry
  %block_pc33 = add i64 5375, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 5375, ptr %86)
  %89 = call ptr @BB_14ff(ptr %state, i64 %87, ptr %86) #18
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  switch i64 %next_rva34, label %dead_end [
    i64 5381, label %bb_1505
    i64 5660, label %bb_161C
  ]

bb_1505:                                          ; preds = %bb_14FF, %entry
  %block_pc35 = add i64 5381, %base
  store i64 %block_pc35, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc35)
  %91 = load ptr, ptr %mem_var, align 8
  %92 = load i64, ptr %pc_var, align 4
  %93 = call ptr @__lifted_bb_entered(ptr %state, i64 5381, ptr %91)
  %94 = call ptr @BB_1505(ptr %state, i64 %92, ptr %91) #18
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva36 = sub i64 %95, %base
  switch i64 %next_rva36, label %dead_end [
    i64 5435, label %bb_153B
  ]

bb_153B:                                          ; preds = %bb_1505, %entry
  %block_pc37 = add i64 5435, %base
  store i64 %block_pc37, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc37)
  %96 = load ptr, ptr %mem_var, align 8
  %97 = load i64, ptr %pc_var, align 4
  %98 = call ptr @__lifted_bb_entered(ptr %state, i64 5435, ptr %96)
  %99 = call ptr @BB_153b(ptr %state, i64 %97, ptr %96) #18
  store ptr %99, ptr %mem_var, align 8
  %100 = call i64 @__extract_rip(ptr %state)
  store i64 %100, ptr %pc_var, align 4
  %next_rva38 = sub i64 %100, %base
  switch i64 %next_rva38, label %dead_end [
    i64 5514, label %bb_158A
  ]

bb_158A:                                          ; preds = %bb_153B, %entry
  %block_pc39 = add i64 5514, %base
  store i64 %block_pc39, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc39)
  %101 = load ptr, ptr %mem_var, align 8
  %102 = load i64, ptr %pc_var, align 4
  %103 = call ptr @__lifted_bb_entered(ptr %state, i64 5514, ptr %101)
  %104 = call ptr @BB_158a(ptr %state, i64 %102, ptr %101) #18
  store ptr %104, ptr %mem_var, align 8
  %105 = call i64 @__extract_rip(ptr %state)
  store i64 %105, ptr %pc_var, align 4
  %next_rva40 = sub i64 %105, %base
  switch i64 %next_rva40, label %dead_end [
    i64 5520, label %bb_1590
  ]

bb_1590:                                          ; preds = %bb_158A, %entry
  %block_pc41 = add i64 5520, %base
  store i64 %block_pc41, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc41)
  %106 = load ptr, ptr %mem_var, align 8
  %107 = load i64, ptr %pc_var, align 4
  %108 = call ptr @__lifted_bb_entered(ptr %state, i64 5520, ptr %106)
  %109 = call ptr @BB_1590(ptr %state, i64 %107, ptr %106) #18
  store ptr %109, ptr %mem_var, align 8
  %110 = call i64 @__extract_rip(ptr %state)
  store i64 %110, ptr %pc_var, align 4
  %next_rva42 = sub i64 %110, %base
  switch i64 %next_rva42, label %dead_end [
    i64 5574, label %bb_15C6
  ]

bb_15C6:                                          ; preds = %bb_1590, %entry
  %block_pc43 = add i64 5574, %base
  store i64 %block_pc43, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc43)
  %111 = load ptr, ptr %mem_var, align 8
  %112 = load i64, ptr %pc_var, align 4
  %113 = call ptr @__lifted_bb_entered(ptr %state, i64 5574, ptr %111)
  %114 = call ptr @BB_15c6(ptr %state, i64 %112, ptr %111) #18
  store ptr %114, ptr %mem_var, align 8
  %115 = call i64 @__extract_rip(ptr %state)
  store i64 %115, ptr %pc_var, align 4
  %next_rva44 = sub i64 %115, %base
  switch i64 %next_rva44, label %dead_end [
    i64 5654, label %bb_1616
  ]

bb_1616:                                          ; preds = %bb_15C6, %entry
  %block_pc45 = add i64 5654, %base
  store i64 %block_pc45, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc45)
  %116 = load ptr, ptr %mem_var, align 8
  %117 = load i64, ptr %pc_var, align 4
  %118 = call ptr @__lifted_bb_entered(ptr %state, i64 5654, ptr %116)
  %119 = call ptr @BB_1616(ptr %state, i64 %117, ptr %116) #18
  store ptr %119, ptr %mem_var, align 8
  %120 = call i64 @__extract_rip(ptr %state)
  store i64 %120, ptr %pc_var, align 4
  %next_rva46 = sub i64 %120, %base
  switch i64 %next_rva46, label %dead_end [
    i64 5203, label %bb_1453
  ]

bb_161C:                                          ; preds = %bb_14FF, %entry
  %block_pc47 = add i64 5660, %base
  store i64 %block_pc47, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc47)
  %121 = load ptr, ptr %mem_var, align 8
  %122 = load i64, ptr %pc_var, align 4
  %123 = call ptr @__lifted_bb_entered(ptr %state, i64 5660, ptr %121)
  %124 = call ptr @BB_161c(ptr %state, i64 %122, ptr %121) #18
  store ptr %124, ptr %mem_var, align 8
  %125 = call i64 @__extract_rip(ptr %state)
  store i64 %125, ptr %pc_var, align 4
  %next_rva48 = sub i64 %125, %base
  switch i64 %next_rva48, label %dead_end [
    i64 5714, label %bb_1652
  ]

bb_1652:                                          ; preds = %bb_161C, %entry
  %block_pc49 = add i64 5714, %base
  store i64 %block_pc49, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc49)
  %126 = load ptr, ptr %mem_var, align 8
  %127 = load i64, ptr %pc_var, align 4
  %128 = call ptr @__lifted_bb_entered(ptr %state, i64 5714, ptr %126)
  %129 = call ptr @BB_1652(ptr %state, i64 %127, ptr %126) #18
  store ptr %129, ptr %mem_var, align 8
  %130 = call i64 @__extract_rip(ptr %state)
  store i64 %130, ptr %pc_var, align 4
  %next_rva50 = sub i64 %130, %base
  switch i64 %next_rva50, label %dead_end [
    i64 4144, label %bb_FFFF000000000000
  ]

bb_1666:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc51 = add i64 5734, %base
  store i64 %block_pc51, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc51)
  %131 = load ptr, ptr %mem_var, align 8
  %132 = load i64, ptr %pc_var, align 4
  %133 = call ptr @__lifted_bb_entered(ptr %state, i64 5734, ptr %131)
  %134 = call ptr @BB_1666(ptr %state, i64 %132, ptr %131) #18
  store ptr %134, ptr %mem_var, align 8
  %135 = call i64 @__extract_rip(ptr %state)
  store i64 %135, ptr %pc_var, align 4
  %next_rva52 = sub i64 %135, %base
  switch i64 %next_rva52, label %dead_end [
    i64 5788, label %bb_169C
  ]

bb_169C:                                          ; preds = %bb_1666, %entry
  %block_pc53 = add i64 5788, %base
  store i64 %block_pc53, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc53)
  %136 = load ptr, ptr %mem_var, align 8
  %137 = load i64, ptr %pc_var, align 4
  %138 = call ptr @__lifted_bb_entered(ptr %state, i64 5788, ptr %136)
  %139 = call ptr @BB_169c(ptr %state, i64 %137, ptr %136) #18
  store ptr %139, ptr %mem_var, align 8
  %140 = call i64 @__extract_rip(ptr %state)
  store i64 %140, ptr %pc_var, align 4
  %next_rva54 = sub i64 %140, %base
  %141 = load ptr, ptr %mem_var, align 8
  ret ptr %141

bb_FFFF000000000000:                              ; preds = %bb_1652, %entry
  %142 = load ptr, ptr %mem_var, align 8
  %143 = load i64, ptr %pc_var, align 4
  %144 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %143, ptr %142) #18
  store ptr %144, ptr %mem_var, align 8
  %145 = call i64 @__extract_rip(ptr %state)
  store i64 %145, ptr %pc_var, align 4
  %next_rva55 = sub i64 %145, %base
  switch i64 %next_rva55, label %dead_end [
    i64 5734, label %bb_1666
  ]

return_bb:                                        ; No predecessors!
  %146 = load ptr, ptr %mem_var, align 8
  ret ptr %146
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 4368, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.125294, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !14
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #18 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15, !15, i64 0}
!15 = !{!"omnipotent char", !16, i64 0}
!16 = !{!"Simple C++ TBAA"}
