; ModuleID = 'bb_cache'
source_filename = "bb_cache"

%struct.State.298969 = type { %struct.X86State.298968 }
%struct.X86State.298968 = type { %struct.ArchState.298937, [32 x %union.VectorReg.298940], %struct.ArithFlags.298941, %union.anon.298936, %struct.Segments.298943, %struct.AddressSpace.298945, %struct.GPR.298946, %struct.X87Stack.298949, %struct.MMX.298953, %struct.FPUStatusFlags.298954, %union.anon.298936, %union.FPU.298963, %struct.SegmentCaches.298965, %struct.K_REG.298967 }
%struct.ArchState.298937 = type { i32, i32, %union.anon.298936 }
%union.VectorReg.298940 = type { %union.vec512_t.298939 }
%union.vec512_t.298939 = type { %struct.uint64v8_t.298938 }
%struct.uint64v8_t.298938 = type { [8 x i64] }
%struct.ArithFlags.298941 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8 }
%struct.Segments.298943 = type { i16, %union.SegmentSelector.298942, i16, %union.SegmentSelector.298942, i16, %union.SegmentSelector.298942, i16, %union.SegmentSelector.298942, i16, %union.SegmentSelector.298942, i16, %union.SegmentSelector.298942 }
%union.SegmentSelector.298942 = type { i16 }
%struct.AddressSpace.298945 = type { i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944 }
%struct.Reg.298944 = type { %union.anon.298936 }
%struct.GPR.298946 = type { i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944, i64, %struct.Reg.298944 }
%struct.X87Stack.298949 = type { [8 x %struct.anon.3.298948] }
%struct.anon.3.298948 = type { [6 x i8], %struct.float80_t.298947 }
%struct.float80_t.298947 = type { [10 x i8] }
%struct.MMX.298953 = type { [8 x %struct.anon.4.298952] }
%struct.anon.4.298952 = type { i64, %union.vec64_t.298951 }
%union.vec64_t.298951 = type { %struct.uint64v1_t.298950 }
%struct.uint64v1_t.298950 = type { [1 x i64] }
%struct.FPUStatusFlags.298954 = type { i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, i8, [4 x i8] }
%union.anon.298936 = type { i64 }
%union.FPU.298963 = type { %struct.anon.13.298962 }
%struct.anon.13.298962 = type { %struct.FpuFXSAVE.298961, [96 x i8] }
%struct.FpuFXSAVE.298961 = type { %union.SegmentSelector.298942, %union.SegmentSelector.298942, %union.FPUAbridgedTagWord.298955, i8, i16, i32, %union.SegmentSelector.298942, i16, i32, %union.SegmentSelector.298942, i16, %union.FPUControlStatus.298956, %union.FPUControlStatus.298956, [8 x %struct.FPUStackElem.298958], [16 x %union.vec128_t.298960] }
%union.FPUAbridgedTagWord.298955 = type { i8 }
%union.FPUControlStatus.298956 = type { i32 }
%struct.FPUStackElem.298958 = type { %union.anon.11.298957, [6 x i8] }
%union.anon.11.298957 = type { %struct.float80_t.298947 }
%union.vec128_t.298960 = type { %struct.uint128v1_t.298959 }
%struct.uint128v1_t.298959 = type { [1 x i128] }
%struct.SegmentCaches.298965 = type { %struct.SegmentShadow.298964, %struct.SegmentShadow.298964, %struct.SegmentShadow.298964, %struct.SegmentShadow.298964, %struct.SegmentShadow.298964, %struct.SegmentShadow.298964 }
%struct.SegmentShadow.298964 = type { %union.anon.298936, i32, i32 }
%struct.K_REG.298967 = type { [8 x %struct.anon.18.298966] }
%struct.anon.18.298966 = type { i64, i64 }

@RAM = external local_unnamed_addr global [0 x i8], align 1

define ptr @BB_2110(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 1
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = load ptr, ptr %MEMORY, align 8
  %rsp.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %6 = load i64, ptr %rsp.i.i, align 8
  %sub.i.i.i = add i64 %6, -8
  %call.i.i.i121 = call ptr @__remill_write_memory_64(ptr noundef %5, i64 noundef %sub.i.i.i, i64 noundef %4) #15
  store i64 %sub.i.i.i, ptr %rsp.i.i, align 8
  store ptr %call.i.i.i121, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RSP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RBP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RSP, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %15, 176
  store i64 %sub.i.i, ptr %RSP, align 8
  %cmp.i.i.i1 = icmp ult i64 %15, 176
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %15, i64 noundef 176, i64 noundef %sub.i.i) #15
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %18 = and i8 %17, 1
  %conv.i.i.i6 = xor i8 %18, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 176, %15
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %19 = trunc i64 %xor1.i.i.i.i9 to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i10 = and i8 %20, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %15, 176
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %15, i64 noundef 176, i64 noundef %sub.i.i) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %15, i64 noundef 176, i64 noundef %sub.i.i) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %15
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %15, i64 noundef 176, i64 noundef %sub.i.i) #15
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 3
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %RBP, align 8
  %25 = sub i64 %24, 12
  %26 = load i32, ptr %EDI, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i77 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i77, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %21
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RBP, align 8
  %33 = sub i64 %32, 8
  %34 = load i64, ptr %RSI, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  %call.i.i78 = call ptr @__remill_write_memory_64(ptr noundef %35, i64 noundef %33, i64 noundef %34) #15
  store ptr %call.i.i78, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %29
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 7
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i64, ptr %NEXT_PC, align 8
  %40 = add i64 %39, 11631
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i82 = call i64 @__remill_read_memory_64(ptr noundef %41, i64 noundef %40) #15
  store i64 %call.i.i82, ptr %RAX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RAX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i79 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #15
  %conv.i.i80 = zext i32 %call.i.i79 to i64
  store i64 %conv.i.i80, ptr %RDX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 7
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %NEXT_PC, align 8
  %51 = add i64 %50, 11806
  %52 = load ptr, ptr %MEMORY, align 8
  %call.i.i81 = call i64 @__remill_read_memory_64(ptr noundef %52, i64 noundef %51) #15
  store i64 %call.i.i81, ptr %RAX, align 8
  store ptr %52, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 3
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i64, ptr %RAX, align 8
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %57, i64 noundef %56) #15
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %58 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %59 = and i8 %58, 1
  %conv.i.i.i32 = xor i8 %59, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %60 = trunc i32 %xor1.i.i.i.i35 to i8
  %61 = lshr i8 %60, 4
  %conv2.i.i.i36 = and i8 %61, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %53
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %66 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %66, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %67 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %67, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %65, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 2
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %EDX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %72, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 3
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RCX, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %77 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %79 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %79, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %80 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %81 = and i8 %80, 1
  %conv.i.i.i = xor i8 %81, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %82 = trunc i32 %xor1.i.i.i.i to i8
  %83 = lshr i8 %82, 4
  %conv2.i.i.i = and i8 %83, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %74
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 3
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RCX, align 8
  %88 = load i32, ptr %EDX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i72 = trunc i64 %87 to i32
  %sext.i = shl i64 %87, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %89, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %91 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i73 = icmp ult i64 %91, -4294967296
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %conv.i.i72, i32 noundef %88, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i74 to i8
  %cf.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i75, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %84
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 3
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %RCX, align 8
  %96 = load ptr, ptr %MEMORY, align 8
  %conv.i.i83 = trunc i64 %95 to i32
  %and3.i.i = and i32 1, %conv.i.i83
  %conv.i22.i84 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i84, ptr %RCX, align 8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i85, align 1
  %conv.i.i.i86 = trunc i32 %and3.i.i to i8
  %97 = and i8 %conv.i.i.i86, 1
  %conv.i23.i87 = xor i8 %97, 1
  %pf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i87, ptr %pf.i.i88, align 1
  %cmp.i.i.i89 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i90 to i8
  %zf.i.i91 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i91, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i83, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i94, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 3
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i32, ptr %ECX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %101 to i8
  %104 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %105 = and i8 %104, 1
  %conv.i.i.i57 = xor i8 %105, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %101, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %101, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %101, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %101, i32 noundef 0, i32 noundef %101) #15
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %98
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 3
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %110 = load i8, ptr %zf.i, align 1
  store i8 %110, ptr %CL, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %106
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 2
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i8, ptr %AL, align 1
  %115 = zext i8 %114 to i64
  %116 = load i8, ptr %CL, align 1
  %117 = zext i8 %116 to i64
  %118 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %117, %115
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i95 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i95, align 1
  %119 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %120 = and i8 %119, 1
  %conv.i27.i = xor i8 %120, 1
  %pf.i.i96 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i96, align 1
  %121 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i97 = and i32 %121, 255
  %cmp.i.i.i98 = icmp eq i8 %or3.i.i, 0
  %122 = trunc i64 %115 to i32
  %conv1.i.i.i = and i32 %122, 255
  %123 = trunc i64 %117 to i32
  %conv2.i.i.i99 = and i32 %123, 255
  %call.i.i.i100 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i98, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #15
  %conv3.i.i101 = zext i1 %call.i.i.i100 to i8
  %zf.i.i102 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i101, ptr %zf.i.i102, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i99, i32 noundef %conv.i.i.i97) #15
  %conv6.i.i103 = zext i1 %call4.i.i.i to i8
  %sf.i.i104 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i103, ptr %sf.i.i104, align 1
  %of.i.i105 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i105, align 1
  %af.i.i106 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i106, align 1
  store ptr %118, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %111
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %128
  %and3.i.i107 = trunc i64 %and3.i15.i to i8
  %cf.i.i108 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i108, align 1
  %130 = and i8 %and3.i.i107, 1
  %conv.i14.i = xor i8 %130, 1
  %pf.i.i109 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i109, align 1
  %131 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i110 = and i32 %131, 255
  %cmp.i.i.i111 = icmp eq i8 %and3.i.i107, 0
  %132 = trunc i64 %128 to i32
  %conv1.i.i.i112 = and i32 %132, 255
  %call.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i111, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #15
  %conv3.i.i114 = zext i1 %call.i.i.i113 to i8
  %zf.i.i115 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i114, ptr %zf.i.i115, align 1
  %call4.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i112, i32 noundef 1, i32 noundef %conv.i.i.i110) #15
  %conv6.i.i117 = zext i1 %call4.i.i.i116 to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i117, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i120, align 1
  store ptr %129, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %124
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 6
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %NEXT_PC, align 8
  %137 = add i64 %136, 5
  %138 = load i64, ptr %NEXT_PC, align 8
  %139 = load ptr, ptr %MEMORY, align 8
  %zf.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %140 = load i8, ptr %zf.i76, align 1
  %tobool.not.i = icmp eq i8 %140, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %137, i64 %138
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %139, ptr %MEMORY, align 8
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  ret ptr %142
}

; Function Attrs: nocallback nofree nosync nounwind speculatable willreturn memory(none)
declare i8 @llvm.ctpop.i8(i8) #1

define ptr @BB_2158(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %R8 = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 17, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RSP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 8
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i369 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i369, ptr %RDX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 12
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i364 = call i32 @__remill_read_memory_32(ptr noundef %12, i64 noundef %11) #15
  %conv.i.i365 = zext i32 %call.i.i364 to i64
  store i64 %conv.i.i365, ptr %RSI, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 3
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RSP, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  store i64 %16, ptr %RDI, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RDI, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %add.i.i175 = add i64 -16, %21
  store i64 %add.i.i175, ptr %RDI, align 8
  %cmp.i.i.i176 = icmp ult i64 %add.i.i175, %21
  %cmp1.i.i.i177 = icmp ult i64 %add.i.i175, -16
  %23 = or i1 %cmp.i.i.i176, %cmp1.i.i.i177
  %call.i.i.i178 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %23, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #15
  %conv.i.i179 = zext i1 %call.i.i.i178 to i8
  %cf.i.i180 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i179, ptr %cf.i.i180, align 1
  %conv.i.i.i.i181 = trunc i64 %add.i.i175 to i8
  %24 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i181)
  %25 = and i8 %24, 1
  %conv.i.i.i182 = xor i8 %25, 1
  %pf.i.i.i183 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i182, ptr %pf.i.i.i183, align 1
  %xor.i.i.i.i184 = xor i64 %add.i.i175, -16
  %xor1.i.i.i.i185 = xor i64 %xor.i.i.i.i184, %21
  %26 = trunc i64 %xor1.i.i.i.i185 to i8
  %27 = lshr i8 %26, 4
  %conv2.i.i.i186 = and i8 %27, 1
  %af.i.i.i187 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i186, ptr %af.i.i.i187, align 1
  %cmp.i.i.i.i188 = icmp eq i64 %add.i.i175, 0
  %call.i.i.i.i189 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i188, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #15
  %conv5.i.i.i190 = zext i1 %call.i.i.i.i189 to i8
  %zf.i.i.i191 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i190, ptr %zf.i.i.i191, align 1
  %cmp.i27.i.i.i192 = icmp slt i64 %add.i.i175, 0
  %call1.i.i.i.i193 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i192, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #15
  %conv8.i.i.i194 = zext i1 %call1.i.i.i.i193 to i8
  %sf.i.i.i195 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i194, ptr %sf.i.i.i195, align 1
  %shr8.i.i.i.i196 = xor i64 %add.i.i175, %21
  %xor.i28.i.i.i197 = lshr i64 %shr8.i.i.i.i196, 63
  %xor3.i.i.i.i198 = lshr i64 %xor.i.i.i.i184, 63
  %add.i.i.i.i199 = add nuw nsw i64 %xor.i28.i.i.i197, %xor3.i.i.i.i198
  %cmp.i29.i.i.i200 = icmp eq i64 %add.i.i.i.i199, 2
  %call.i30.i.i.i201 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i200, i64 noundef %21, i64 noundef -16, i64 noundef %add.i.i175) #15
  %conv11.i.i.i202 = zext i1 %call.i30.i.i.i201 to i8
  %of.i.i.i203 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i202, ptr %of.i.i.i203, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %28

28:                                               ; preds = %18
  %29 = load i64, ptr %NEXT_PC, align 8
  store i64 %29, ptr %PC, align 8
  %30 = add i64 %29, 4
  store i64 %30, ptr %NEXT_PC, align 8
  %31 = load i64, ptr %RBP, align 8
  %32 = sub i64 %31, 80
  %33 = load i64, ptr %RDI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i359 = call ptr @__remill_write_memory_64(ptr noundef %34, i64 noundef %32, i64 noundef %33) #15
  store ptr %call.i.i359, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %28
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RDI, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RSP, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %35
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 3
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i64, ptr %RSP, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  store i64 %43, ptr %RAX, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %40
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 4
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i64, ptr %RAX, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %add.i.i146 = add i64 -16, %48
  store i64 %add.i.i146, ptr %RAX, align 8
  %cmp.i.i.i147 = icmp ult i64 %add.i.i146, %48
  %cmp1.i.i.i148 = icmp ult i64 %add.i.i146, -16
  %50 = or i1 %cmp.i.i.i147, %cmp1.i.i.i148
  %call.i.i.i149 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %50, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #15
  %conv.i.i150 = zext i1 %call.i.i.i149 to i8
  %cf.i.i151 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i150, ptr %cf.i.i151, align 1
  %conv.i.i.i.i152 = trunc i64 %add.i.i146 to i8
  %51 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i152)
  %52 = and i8 %51, 1
  %conv.i.i.i153 = xor i8 %52, 1
  %pf.i.i.i154 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i153, ptr %pf.i.i.i154, align 1
  %xor.i.i.i.i155 = xor i64 %add.i.i146, -16
  %xor1.i.i.i.i156 = xor i64 %xor.i.i.i.i155, %48
  %53 = trunc i64 %xor1.i.i.i.i156 to i8
  %54 = lshr i8 %53, 4
  %conv2.i.i.i157 = and i8 %54, 1
  %af.i.i.i158 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i157, ptr %af.i.i.i158, align 1
  %cmp.i.i.i.i159 = icmp eq i64 %add.i.i146, 0
  %call.i.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i159, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #15
  %conv5.i.i.i161 = zext i1 %call.i.i.i.i160 to i8
  %zf.i.i.i162 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i161, ptr %zf.i.i.i162, align 1
  %cmp.i27.i.i.i163 = icmp slt i64 %add.i.i146, 0
  %call1.i.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i163, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #15
  %conv8.i.i.i165 = zext i1 %call1.i.i.i.i164 to i8
  %sf.i.i.i166 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i165, ptr %sf.i.i.i166, align 1
  %shr8.i.i.i.i167 = xor i64 %add.i.i146, %48
  %xor.i28.i.i.i168 = lshr i64 %shr8.i.i.i.i167, 63
  %xor3.i.i.i.i169 = lshr i64 %xor.i.i.i.i155, 63
  %add.i.i.i.i170 = add nuw nsw i64 %xor.i28.i.i.i168, %xor3.i.i.i.i169
  %cmp.i29.i.i.i171 = icmp eq i64 %add.i.i.i.i170, 2
  %call.i30.i.i.i172 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i171, i64 noundef %48, i64 noundef -16, i64 noundef %add.i.i146) #15
  %conv11.i.i.i173 = zext i1 %call.i30.i.i.i172 to i8
  %of.i.i.i174 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i173, ptr %of.i.i.i174, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %45
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 4
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RBP, align 8
  %59 = sub i64 %58, 72
  %60 = load i64, ptr %RAX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %call.i.i358 = call ptr @__remill_write_memory_64(ptr noundef %61, i64 noundef %59, i64 noundef %60) #15
  store ptr %call.i.i358, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %55
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RAX, align 8
  %66 = load ptr, ptr %MEMORY, align 8
  store i64 %65, ptr %RSP, align 8
  store ptr %66, ptr %MEMORY, align 8
  br label %67

67:                                               ; preds = %62
  %68 = load i64, ptr %NEXT_PC, align 8
  store i64 %68, ptr %PC, align 8
  %69 = add i64 %68, 3
  store i64 %69, ptr %NEXT_PC, align 8
  %70 = load i64, ptr %RSP, align 8
  %71 = load ptr, ptr %MEMORY, align 8
  store i64 %70, ptr %RCX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %67
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RCX, align 8
  %76 = load ptr, ptr %MEMORY, align 8
  %add.i.i117 = add i64 -16, %75
  store i64 %add.i.i117, ptr %RCX, align 8
  %cmp.i.i.i118 = icmp ult i64 %add.i.i117, %75
  %cmp1.i.i.i119 = icmp ult i64 %add.i.i117, -16
  %77 = or i1 %cmp.i.i.i118, %cmp1.i.i.i119
  %call.i.i.i120 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %77, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv.i.i121 = zext i1 %call.i.i.i120 to i8
  %cf.i.i122 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i121, ptr %cf.i.i122, align 1
  %conv.i.i.i.i123 = trunc i64 %add.i.i117 to i8
  %78 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i123)
  %79 = and i8 %78, 1
  %conv.i.i.i124 = xor i8 %79, 1
  %pf.i.i.i125 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i124, ptr %pf.i.i.i125, align 1
  %xor.i.i.i.i126 = xor i64 %add.i.i117, -16
  %xor1.i.i.i.i127 = xor i64 %xor.i.i.i.i126, %75
  %80 = trunc i64 %xor1.i.i.i.i127 to i8
  %81 = lshr i8 %80, 4
  %conv2.i.i.i128 = and i8 %81, 1
  %af.i.i.i129 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i128, ptr %af.i.i.i129, align 1
  %cmp.i.i.i.i130 = icmp eq i64 %add.i.i117, 0
  %call.i.i.i.i131 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i130, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv5.i.i.i132 = zext i1 %call.i.i.i.i131 to i8
  %zf.i.i.i133 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i132, ptr %zf.i.i.i133, align 1
  %cmp.i27.i.i.i134 = icmp slt i64 %add.i.i117, 0
  %call1.i.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i134, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv8.i.i.i136 = zext i1 %call1.i.i.i.i135 to i8
  %sf.i.i.i137 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i136, ptr %sf.i.i.i137, align 1
  %shr8.i.i.i.i138 = xor i64 %add.i.i117, %75
  %xor.i28.i.i.i139 = lshr i64 %shr8.i.i.i.i138, 63
  %xor3.i.i.i.i140 = lshr i64 %xor.i.i.i.i126, 63
  %add.i.i.i.i141 = add nuw nsw i64 %xor.i28.i.i.i139, %xor3.i.i.i.i140
  %cmp.i29.i.i.i142 = icmp eq i64 %add.i.i.i.i141, 2
  %call.i30.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i142, i64 noundef %75, i64 noundef -16, i64 noundef %add.i.i117) #15
  %conv11.i.i.i144 = zext i1 %call.i30.i.i.i143 to i8
  %of.i.i.i145 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i144, ptr %of.i.i.i145, align 1
  store ptr %76, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %72
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 4
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RBP, align 8
  %86 = sub i64 %85, 64
  %87 = load i64, ptr %RCX, align 8
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i357 = call ptr @__remill_write_memory_64(ptr noundef %88, i64 noundef %86, i64 noundef %87) #15
  store ptr %call.i.i357, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %82
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 3
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i64, ptr %RCX, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  store i64 %92, ptr %RSP, align 8
  store ptr %93, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %89
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i64, ptr %RSP, align 8
  %98 = load ptr, ptr %MEMORY, align 8
  store i64 %97, ptr %R8, align 8
  store ptr %98, ptr %MEMORY, align 8
  br label %99

99:                                               ; preds = %94
  %100 = load i64, ptr %NEXT_PC, align 8
  store i64 %100, ptr %PC, align 8
  %101 = add i64 %100, 4
  store i64 %101, ptr %NEXT_PC, align 8
  %102 = load i64, ptr %R8, align 8
  %103 = load ptr, ptr %MEMORY, align 8
  %add.i.i88 = add i64 -48, %102
  store i64 %add.i.i88, ptr %R8, align 8
  %cmp.i.i.i89 = icmp ult i64 %add.i.i88, %102
  %cmp1.i.i.i90 = icmp ult i64 %add.i.i88, -48
  %104 = or i1 %cmp.i.i.i89, %cmp1.i.i.i90
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %104, i64 noundef %102, i64 noundef -48, i64 noundef %add.i.i88) #15
  %conv.i.i92 = zext i1 %call.i.i.i91 to i8
  %cf.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i92, ptr %cf.i.i93, align 1
  %conv.i.i.i.i94 = trunc i64 %add.i.i88 to i8
  %105 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i94)
  %106 = and i8 %105, 1
  %conv.i.i.i95 = xor i8 %106, 1
  %pf.i.i.i96 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i95, ptr %pf.i.i.i96, align 1
  %xor.i.i.i.i97 = xor i64 %add.i.i88, -48
  %xor1.i.i.i.i98 = xor i64 %xor.i.i.i.i97, %102
  %107 = trunc i64 %xor1.i.i.i.i98 to i8
  %108 = lshr i8 %107, 4
  %conv2.i.i.i99 = and i8 %108, 1
  %af.i.i.i100 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i99, ptr %af.i.i.i100, align 1
  %cmp.i.i.i.i101 = icmp eq i64 %add.i.i88, 0
  %call.i.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i101, i64 noundef %102, i64 noundef -48, i64 noundef %add.i.i88) #15
  %conv5.i.i.i103 = zext i1 %call.i.i.i.i102 to i8
  %zf.i.i.i104 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i103, ptr %zf.i.i.i104, align 1
  %cmp.i27.i.i.i105 = icmp slt i64 %add.i.i88, 0
  %call1.i.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i105, i64 noundef %102, i64 noundef -48, i64 noundef %add.i.i88) #15
  %conv8.i.i.i107 = zext i1 %call1.i.i.i.i106 to i8
  %sf.i.i.i108 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i107, ptr %sf.i.i.i108, align 1
  %shr8.i.i.i.i109 = xor i64 %add.i.i88, %102
  %xor.i28.i.i.i110 = lshr i64 %shr8.i.i.i.i109, 63
  %xor3.i.i.i.i111 = lshr i64 %xor.i.i.i.i97, 63
  %add.i.i.i.i112 = add nuw nsw i64 %xor.i28.i.i.i110, %xor3.i.i.i.i111
  %cmp.i29.i.i.i113 = icmp eq i64 %add.i.i.i.i112, 2
  %call.i30.i.i.i114 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i113, i64 noundef %102, i64 noundef -48, i64 noundef %add.i.i88) #15
  %conv11.i.i.i115 = zext i1 %call.i30.i.i.i114 to i8
  %of.i.i.i116 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i115, ptr %of.i.i.i116, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %99
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 4
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RBP, align 8
  %113 = sub i64 %112, 56
  %114 = load i64, ptr %R8, align 8
  %115 = load ptr, ptr %MEMORY, align 8
  %call.i.i356 = call ptr @__remill_write_memory_64(ptr noundef %115, i64 noundef %113, i64 noundef %114) #15
  store ptr %call.i.i356, ptr %MEMORY, align 8
  br label %116

116:                                              ; preds = %109
  %117 = load i64, ptr %NEXT_PC, align 8
  store i64 %117, ptr %PC, align 8
  %118 = add i64 %117, 3
  store i64 %118, ptr %NEXT_PC, align 8
  %119 = load i64, ptr %R8, align 8
  %120 = load ptr, ptr %MEMORY, align 8
  store i64 %119, ptr %RSP, align 8
  store ptr %120, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %116
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load i64, ptr %RSP, align 8
  %125 = load ptr, ptr %MEMORY, align 8
  store i64 %124, ptr %R8, align 8
  store ptr %125, ptr %MEMORY, align 8
  br label %126

126:                                              ; preds = %121
  %127 = load i64, ptr %NEXT_PC, align 8
  store i64 %127, ptr %PC, align 8
  %128 = add i64 %127, 4
  store i64 %128, ptr %NEXT_PC, align 8
  %129 = load i64, ptr %R8, align 8
  %130 = load ptr, ptr %MEMORY, align 8
  %add.i.i59 = add i64 -16, %129
  store i64 %add.i.i59, ptr %R8, align 8
  %cmp.i.i.i60 = icmp ult i64 %add.i.i59, %129
  %cmp1.i.i.i61 = icmp ult i64 %add.i.i59, -16
  %131 = or i1 %cmp.i.i.i60, %cmp1.i.i.i61
  %call.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %131, i64 noundef %129, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv.i.i63 = zext i1 %call.i.i.i62 to i8
  %cf.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i63, ptr %cf.i.i64, align 1
  %conv.i.i.i.i65 = trunc i64 %add.i.i59 to i8
  %132 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i65)
  %133 = and i8 %132, 1
  %conv.i.i.i66 = xor i8 %133, 1
  %pf.i.i.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i66, ptr %pf.i.i.i67, align 1
  %xor.i.i.i.i68 = xor i64 %add.i.i59, -16
  %xor1.i.i.i.i69 = xor i64 %xor.i.i.i.i68, %129
  %134 = trunc i64 %xor1.i.i.i.i69 to i8
  %135 = lshr i8 %134, 4
  %conv2.i.i.i70 = and i8 %135, 1
  %af.i.i.i71 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i70, ptr %af.i.i.i71, align 1
  %cmp.i.i.i.i72 = icmp eq i64 %add.i.i59, 0
  %call.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i72, i64 noundef %129, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv5.i.i.i74 = zext i1 %call.i.i.i.i73 to i8
  %zf.i.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i74, ptr %zf.i.i.i75, align 1
  %cmp.i27.i.i.i76 = icmp slt i64 %add.i.i59, 0
  %call1.i.i.i.i77 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i76, i64 noundef %129, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv8.i.i.i78 = zext i1 %call1.i.i.i.i77 to i8
  %sf.i.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i78, ptr %sf.i.i.i79, align 1
  %shr8.i.i.i.i80 = xor i64 %add.i.i59, %129
  %xor.i28.i.i.i81 = lshr i64 %shr8.i.i.i.i80, 63
  %xor3.i.i.i.i82 = lshr i64 %xor.i.i.i.i68, 63
  %add.i.i.i.i83 = add nuw nsw i64 %xor.i28.i.i.i81, %xor3.i.i.i.i82
  %cmp.i29.i.i.i84 = icmp eq i64 %add.i.i.i.i83, 2
  %call.i30.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i84, i64 noundef %129, i64 noundef -16, i64 noundef %add.i.i59) #15
  %conv11.i.i.i86 = zext i1 %call.i30.i.i.i85 to i8
  %of.i.i.i87 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i86, ptr %of.i.i.i87, align 1
  store ptr %130, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %126
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 4
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %RBP, align 8
  %140 = sub i64 %139, 48
  %141 = load i64, ptr %R8, align 8
  %142 = load ptr, ptr %MEMORY, align 8
  %call.i.i355 = call ptr @__remill_write_memory_64(ptr noundef %142, i64 noundef %140, i64 noundef %141) #15
  store ptr %call.i.i355, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %136
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 3
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %R8, align 8
  %147 = load ptr, ptr %MEMORY, align 8
  store i64 %146, ptr %RSP, align 8
  store ptr %147, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %143
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RSP, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  store i64 %151, ptr %R8, align 8
  store ptr %152, ptr %MEMORY, align 8
  br label %153

153:                                              ; preds = %148
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = add i64 %154, 4
  store i64 %155, ptr %NEXT_PC, align 8
  %156 = load i64, ptr %R8, align 8
  %157 = load ptr, ptr %MEMORY, align 8
  %add.i.i30 = add i64 -16, %156
  store i64 %add.i.i30, ptr %R8, align 8
  %cmp.i.i.i31 = icmp ult i64 %add.i.i30, %156
  %cmp1.i.i.i32 = icmp ult i64 %add.i.i30, -16
  %158 = or i1 %cmp.i.i.i31, %cmp1.i.i.i32
  %call.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %158, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv.i.i34 = zext i1 %call.i.i.i33 to i8
  %cf.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i34, ptr %cf.i.i35, align 1
  %conv.i.i.i.i36 = trunc i64 %add.i.i30 to i8
  %159 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i36)
  %160 = and i8 %159, 1
  %conv.i.i.i37 = xor i8 %160, 1
  %pf.i.i.i38 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i37, ptr %pf.i.i.i38, align 1
  %xor.i.i.i.i39 = xor i64 %add.i.i30, -16
  %xor1.i.i.i.i40 = xor i64 %xor.i.i.i.i39, %156
  %161 = trunc i64 %xor1.i.i.i.i40 to i8
  %162 = lshr i8 %161, 4
  %conv2.i.i.i41 = and i8 %162, 1
  %af.i.i.i42 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i41, ptr %af.i.i.i42, align 1
  %cmp.i.i.i.i43 = icmp eq i64 %add.i.i30, 0
  %call.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i43, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv5.i.i.i45 = zext i1 %call.i.i.i.i44 to i8
  %zf.i.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i45, ptr %zf.i.i.i46, align 1
  %cmp.i27.i.i.i47 = icmp slt i64 %add.i.i30, 0
  %call1.i.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i47, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv8.i.i.i49 = zext i1 %call1.i.i.i.i48 to i8
  %sf.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i49, ptr %sf.i.i.i50, align 1
  %shr8.i.i.i.i51 = xor i64 %add.i.i30, %156
  %xor.i28.i.i.i52 = lshr i64 %shr8.i.i.i.i51, 63
  %xor3.i.i.i.i53 = lshr i64 %xor.i.i.i.i39, 63
  %add.i.i.i.i54 = add nuw nsw i64 %xor.i28.i.i.i52, %xor3.i.i.i.i53
  %cmp.i29.i.i.i55 = icmp eq i64 %add.i.i.i.i54, 2
  %call.i30.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i55, i64 noundef %156, i64 noundef -16, i64 noundef %add.i.i30) #15
  %conv11.i.i.i57 = zext i1 %call.i30.i.i.i56 to i8
  %of.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i57, ptr %of.i.i.i58, align 1
  store ptr %157, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %153
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 4
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %RBP, align 8
  %167 = sub i64 %166, 40
  %168 = load i64, ptr %R8, align 8
  %169 = load ptr, ptr %MEMORY, align 8
  %call.i.i354 = call ptr @__remill_write_memory_64(ptr noundef %169, i64 noundef %167, i64 noundef %168) #15
  store ptr %call.i.i354, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %163
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 3
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i64, ptr %R8, align 8
  %174 = load ptr, ptr %MEMORY, align 8
  store i64 %173, ptr %RSP, align 8
  store ptr %174, ptr %MEMORY, align 8
  br label %175

175:                                              ; preds = %170
  %176 = load i64, ptr %NEXT_PC, align 8
  store i64 %176, ptr %PC, align 8
  %177 = add i64 %176, 3
  store i64 %177, ptr %NEXT_PC, align 8
  %178 = load i64, ptr %RSP, align 8
  %179 = load ptr, ptr %MEMORY, align 8
  store i64 %178, ptr %R8, align 8
  store ptr %179, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %175
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 4
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i64, ptr %R8, align 8
  %184 = load ptr, ptr %MEMORY, align 8
  %add.i.i1 = add i64 -16, %183
  store i64 %add.i.i1, ptr %R8, align 8
  %cmp.i.i.i2 = icmp ult i64 %add.i.i1, %183
  %cmp1.i.i.i3 = icmp ult i64 %add.i.i1, -16
  %185 = or i1 %cmp.i.i.i2, %cmp1.i.i.i3
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %185, i64 noundef %183, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv.i.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i64 %add.i.i1 to i8
  %186 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %187 = and i8 %186, 1
  %conv.i.i.i8 = xor i8 %187, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i64 %add.i.i1, -16
  %xor1.i.i.i.i11 = xor i64 %xor.i.i.i.i10, %183
  %188 = trunc i64 %xor1.i.i.i.i11 to i8
  %189 = lshr i8 %188, 4
  %conv2.i.i.i12 = and i8 %189, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i64 %add.i.i1, 0
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i64 noundef %183, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i64 %add.i.i1, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i64 noundef %183, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %shr8.i.i.i.i22 = xor i64 %add.i.i1, %183
  %xor.i28.i.i.i23 = lshr i64 %shr8.i.i.i.i22, 63
  %xor3.i.i.i.i24 = lshr i64 %xor.i.i.i.i10, 63
  %add.i.i.i.i25 = add nuw nsw i64 %xor.i28.i.i.i23, %xor3.i.i.i.i24
  %cmp.i29.i.i.i26 = icmp eq i64 %add.i.i.i.i25, 2
  %call.i30.i.i.i27 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i26, i64 noundef %183, i64 noundef -16, i64 noundef %add.i.i1) #15
  %conv11.i.i.i28 = zext i1 %call.i30.i.i.i27 to i8
  %of.i.i.i29 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i28, ptr %of.i.i.i29, align 1
  store ptr %184, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %180
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 4
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i64, ptr %RBP, align 8
  %194 = sub i64 %193, 32
  %195 = load i64, ptr %R8, align 8
  %196 = load ptr, ptr %MEMORY, align 8
  %call.i.i353 = call ptr @__remill_write_memory_64(ptr noundef %196, i64 noundef %194, i64 noundef %195) #15
  store ptr %call.i.i353, ptr %MEMORY, align 8
  br label %197

197:                                              ; preds = %190
  %198 = load i64, ptr %NEXT_PC, align 8
  store i64 %198, ptr %PC, align 8
  %199 = add i64 %198, 3
  store i64 %199, ptr %NEXT_PC, align 8
  %200 = load i64, ptr %R8, align 8
  %201 = load ptr, ptr %MEMORY, align 8
  store i64 %200, ptr %RSP, align 8
  store ptr %201, ptr %MEMORY, align 8
  br label %202

202:                                              ; preds = %197
  %203 = load i64, ptr %NEXT_PC, align 8
  store i64 %203, ptr %PC, align 8
  %204 = add i64 %203, 6
  store i64 %204, ptr %NEXT_PC, align 8
  %205 = load i64, ptr %RDI, align 8
  %206 = load ptr, ptr %MEMORY, align 8
  %call.i.i349 = call ptr @__remill_write_memory_32(ptr noundef %206, i64 noundef %205, i32 noundef 0) #15
  store ptr %call.i.i349, ptr %MEMORY, align 8
  br label %207

207:                                              ; preds = %202
  %208 = load i64, ptr %NEXT_PC, align 8
  store i64 %208, ptr %PC, align 8
  %209 = add i64 %208, 2
  store i64 %209, ptr %NEXT_PC, align 8
  %210 = load i64, ptr %RAX, align 8
  %211 = load i32, ptr %ESI, align 4
  %212 = zext i32 %211 to i64
  %213 = load ptr, ptr %MEMORY, align 8
  %call.i.i350 = call ptr @__remill_write_memory_32(ptr noundef %213, i64 noundef %210, i32 noundef %211) #15
  store ptr %call.i.i350, ptr %MEMORY, align 8
  br label %214

214:                                              ; preds = %207
  %215 = load i64, ptr %NEXT_PC, align 8
  store i64 %215, ptr %PC, align 8
  %216 = add i64 %215, 3
  store i64 %216, ptr %NEXT_PC, align 8
  %217 = load i64, ptr %RCX, align 8
  %218 = load i64, ptr %RDX, align 8
  %219 = load ptr, ptr %MEMORY, align 8
  %call.i.i352 = call ptr @__remill_write_memory_64(ptr noundef %219, i64 noundef %217, i64 noundef %218) #15
  store ptr %call.i.i352, ptr %MEMORY, align 8
  br label %220

220:                                              ; preds = %214
  %221 = load i64, ptr %NEXT_PC, align 8
  store i64 %221, ptr %PC, align 8
  %222 = add i64 %221, 2
  store i64 %222, ptr %NEXT_PC, align 8
  %223 = load i64, ptr %RAX, align 8
  %224 = load ptr, ptr %MEMORY, align 8
  %call.i.i362 = call i32 @__remill_read_memory_32(ptr noundef %224, i64 noundef %223) #15
  %conv.i.i363 = zext i32 %call.i.i362 to i64
  store i64 %conv.i.i363, ptr %RDX, align 8
  store ptr %224, ptr %MEMORY, align 8
  br label %225

225:                                              ; preds = %220
  %226 = load i64, ptr %NEXT_PC, align 8
  store i64 %226, ptr %PC, align 8
  %227 = add i64 %226, 5
  store i64 %227, ptr %NEXT_PC, align 8
  %228 = load ptr, ptr %MEMORY, align 8
  store i64 1, ptr %RCX, align 8
  store ptr %228, ptr %MEMORY, align 8
  br label %229

229:                                              ; preds = %225
  %230 = load i64, ptr %NEXT_PC, align 8
  store i64 %230, ptr %PC, align 8
  %231 = add i64 %230, 2
  store i64 %231, ptr %NEXT_PC, align 8
  %232 = load i64, ptr %RAX, align 8
  %233 = load i32, ptr %EAX, align 4
  %234 = zext i32 %233 to i64
  %235 = load ptr, ptr %MEMORY, align 8
  %conv.i.i413 = trunc i64 %232 to i32
  %xor3.i.i414 = xor i32 %233, %conv.i.i413
  %conv.i27.i415 = zext i32 %xor3.i.i414 to i64
  store i64 %conv.i27.i415, ptr %RAX, align 8
  %cf.i.i416 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i416, align 1
  %conv.i.i.i417 = trunc i32 %xor3.i.i414 to i8
  %236 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i417)
  %237 = and i8 %236, 1
  %conv.i28.i418 = xor i8 %237, 1
  %pf.i.i419 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i418, ptr %pf.i.i419, align 1
  %cmp.i.i.i420 = icmp eq i32 %xor3.i.i414, 0
  %call.i.i.i421 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i420, i32 noundef %conv.i.i413, i32 noundef %233, i32 noundef %xor3.i.i414) #15
  %conv3.i.i422 = zext i1 %call.i.i.i421 to i8
  %zf.i.i423 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i422, ptr %zf.i.i423, align 1
  %cmp.i19.i.i424 = icmp slt i32 %xor3.i.i414, 0
  %call1.i.i.i425 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i424, i32 noundef %conv.i.i413, i32 noundef %233, i32 noundef %xor3.i.i414) #15
  %conv6.i.i426 = zext i1 %call1.i.i.i425 to i8
  %sf.i.i427 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i426, ptr %sf.i.i427, align 1
  %of.i.i428 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i428, align 1
  %af.i.i429 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i430 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i430, ptr %af.i.i429, align 1
  store ptr %235, ptr %MEMORY, align 8
  br label %238

238:                                              ; preds = %229
  %239 = load i64, ptr %NEXT_PC, align 8
  store i64 %239, ptr %PC, align 8
  %240 = add i64 %239, 3
  store i64 %240, ptr %NEXT_PC, align 8
  %241 = load i32, ptr %EDX, align 4
  %242 = zext i32 %241 to i64
  %243 = load ptr, ptr %MEMORY, align 8
  %sub.i.i303 = sub i32 %241, 12
  %cmp.i.i.i304 = icmp ult i32 %241, 12
  %call.i.i.i305 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i304, i32 noundef %241, i32 noundef 12, i32 noundef %sub.i.i303) #15
  %conv.i12.i306 = zext i1 %call.i.i.i305 to i8
  %cf.i.i307 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i306, ptr %cf.i.i307, align 1
  %conv.i.i.i.i308 = trunc i32 %sub.i.i303 to i8
  %244 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i308)
  %245 = and i8 %244, 1
  %conv.i.i.i309 = xor i8 %245, 1
  %pf.i.i.i310 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i309, ptr %pf.i.i.i310, align 1
  %xor.i.i.i.i311 = xor i32 12, %241
  %xor1.i.i.i.i312 = xor i32 %xor.i.i.i.i311, %sub.i.i303
  %246 = trunc i32 %xor1.i.i.i.i312 to i8
  %247 = lshr i8 %246, 4
  %conv2.i.i.i313 = and i8 %247, 1
  %af.i.i.i314 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i313, ptr %af.i.i.i314, align 1
  %cmp.i.i.i.i315 = icmp eq i32 %241, 12
  %call.i.i.i.i316 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i315, i32 noundef %241, i32 noundef 12, i32 noundef %sub.i.i303) #15
  %conv5.i.i.i317 = zext i1 %call.i.i.i.i316 to i8
  %zf.i.i.i318 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i317, ptr %zf.i.i.i318, align 1
  %cmp.i27.i.i.i319 = icmp slt i32 %sub.i.i303, 0
  %call1.i.i.i.i320 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i319, i32 noundef %241, i32 noundef 12, i32 noundef %sub.i.i303) #15
  %conv8.i.i.i321 = zext i1 %call1.i.i.i.i320 to i8
  %sf.i.i.i322 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i321, ptr %sf.i.i.i322, align 1
  %xor.i28.i.i.i323 = lshr i32 %xor.i.i.i.i311, 31
  %shr9.i.i.i.i324 = xor i32 %sub.i.i303, %241
  %xor3.i.i.i.i325 = lshr i32 %shr9.i.i.i.i324, 31
  %add.i.i.i.i326 = add nuw nsw i32 %xor3.i.i.i.i325, %xor.i28.i.i.i323
  %cmp.i29.i.i.i327 = icmp eq i32 %add.i.i.i.i326, 2
  %call.i30.i.i.i328 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i327, i32 noundef %241, i32 noundef 12, i32 noundef %sub.i.i303) #15
  %conv11.i.i.i329 = zext i1 %call.i30.i.i.i328 to i8
  %of.i.i.i330 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i329, ptr %of.i.i.i330, align 1
  store ptr %243, ptr %MEMORY, align 8
  br label %248

248:                                              ; preds = %238
  %249 = load i64, ptr %NEXT_PC, align 8
  store i64 %249, ptr %PC, align 8
  %250 = add i64 %249, 3
  store i64 %250, ptr %NEXT_PC, align 8
  %251 = load i32, ptr %EAX, align 4
  %252 = zext i32 %251 to i64
  %253 = load ptr, ptr %MEMORY, align 8
  %sf.i335 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %254 = load i8, ptr %sf.i335, align 1
  %tobool.i336 = icmp ne i8 %254, 0
  %of.i337 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %255 = load i8, ptr %of.i337, align 1
  %tobool4.i = icmp ne i8 %255, 0
  %cmp.i.i338 = xor i1 %tobool.i336, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i338) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %252, i64 %dst.coerce.val.i
  %conv.i23.i339 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i339, ptr %RCX, align 8
  store ptr %253, ptr %MEMORY, align 8
  br label %256

256:                                              ; preds = %248
  %257 = load i64, ptr %NEXT_PC, align 8
  store i64 %257, ptr %PC, align 8
  %258 = add i64 %257, 7
  store i64 %258, ptr %NEXT_PC, align 8
  %259 = load i64, ptr %NEXT_PC, align 8
  %260 = add i64 %259, 11854
  %261 = load ptr, ptr %MEMORY, align 8
  store i64 %260, ptr %RAX, align 8
  store ptr %261, ptr %MEMORY, align 8
  br label %262

262:                                              ; preds = %256
  %263 = load i64, ptr %NEXT_PC, align 8
  store i64 %263, ptr %PC, align 8
  %264 = add i64 %263, 3
  store i64 %264, ptr %NEXT_PC, align 8
  %265 = load i32, ptr %ECX, align 4
  %266 = zext i32 %265 to i64
  %267 = load ptr, ptr %MEMORY, align 8
  %sext.i370 = shl i64 %266, 32
  %conv.i12.i371 = ashr exact i64 %sext.i370, 32
  store i64 %conv.i12.i371, ptr %RCX, align 8
  store ptr %267, ptr %MEMORY, align 8
  br label %268

268:                                              ; preds = %262
  %269 = load i64, ptr %NEXT_PC, align 8
  store i64 %269, ptr %PC, align 8
  %270 = add i64 %269, 4
  store i64 %270, ptr %NEXT_PC, align 8
  %271 = load i64, ptr %RAX, align 8
  %272 = load i64, ptr %RCX, align 8
  %273 = mul i64 %272, 8
  %274 = add i64 %271, %273
  %275 = load ptr, ptr %MEMORY, align 8
  %call.i.i368 = call i64 @__remill_read_memory_64(ptr noundef %275, i64 noundef %274) #15
  store i64 %call.i.i368, ptr %RAX, align 8
  store ptr %275, ptr %MEMORY, align 8
  br label %276

276:                                              ; preds = %268
  %277 = load i64, ptr %NEXT_PC, align 8
  store i64 %277, ptr %PC, align 8
  %278 = add i64 %277, 2
  store i64 %278, ptr %NEXT_PC, align 8
  %279 = load i64, ptr %RCX, align 8
  %280 = load i32, ptr %ECX, align 4
  %281 = zext i32 %280 to i64
  %282 = load ptr, ptr %MEMORY, align 8
  %conv.i.i396 = trunc i64 %279 to i32
  %xor3.i.i = xor i32 %280, %conv.i.i396
  %conv.i27.i397 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i397, ptr %RCX, align 8
  %cf.i.i398 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i398, align 1
  %conv.i.i.i399 = trunc i32 %xor3.i.i to i8
  %283 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i399)
  %284 = and i8 %283, 1
  %conv.i28.i400 = xor i8 %284, 1
  %pf.i.i401 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i400, ptr %pf.i.i401, align 1
  %cmp.i.i.i402 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i403 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i402, i32 noundef %conv.i.i396, i32 noundef %280, i32 noundef %xor3.i.i) #15
  %conv3.i.i404 = zext i1 %call.i.i.i403 to i8
  %zf.i.i405 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i404, ptr %zf.i.i405, align 1
  %cmp.i19.i.i406 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i407 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i406, i32 noundef %conv.i.i396, i32 noundef %280, i32 noundef %xor3.i.i) #15
  %conv6.i.i408 = zext i1 %call1.i.i.i407 to i8
  %sf.i.i409 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i408, ptr %sf.i.i409, align 1
  %of.i.i410 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i410, align 1
  %af.i.i411 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i412 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i412, ptr %af.i.i411, align 1
  store ptr %282, ptr %MEMORY, align 8
  br label %285

285:                                              ; preds = %276
  %286 = load i64, ptr %NEXT_PC, align 8
  store i64 %286, ptr %PC, align 8
  %287 = add i64 %286, 3
  store i64 %287, ptr %NEXT_PC, align 8
  %288 = load i32, ptr %EDX, align 4
  %289 = zext i32 %288 to i64
  %290 = load ptr, ptr %MEMORY, align 8
  %sub.i.i275 = sub i32 %288, 12
  %cmp.i.i.i276 = icmp ult i32 %288, 12
  %call.i.i.i277 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i276, i32 noundef %288, i32 noundef 12, i32 noundef %sub.i.i275) #15
  %conv.i12.i278 = zext i1 %call.i.i.i277 to i8
  %cf.i.i279 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i278, ptr %cf.i.i279, align 1
  %conv.i.i.i.i280 = trunc i32 %sub.i.i275 to i8
  %291 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i280)
  %292 = and i8 %291, 1
  %conv.i.i.i281 = xor i8 %292, 1
  %pf.i.i.i282 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i281, ptr %pf.i.i.i282, align 1
  %xor.i.i.i.i283 = xor i32 12, %288
  %xor1.i.i.i.i284 = xor i32 %xor.i.i.i.i283, %sub.i.i275
  %293 = trunc i32 %xor1.i.i.i.i284 to i8
  %294 = lshr i8 %293, 4
  %conv2.i.i.i285 = and i8 %294, 1
  %af.i.i.i286 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i285, ptr %af.i.i.i286, align 1
  %cmp.i.i.i.i287 = icmp eq i32 %288, 12
  %call.i.i.i.i288 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i287, i32 noundef %288, i32 noundef 12, i32 noundef %sub.i.i275) #15
  %conv5.i.i.i289 = zext i1 %call.i.i.i.i288 to i8
  %zf.i.i.i290 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i289, ptr %zf.i.i.i290, align 1
  %cmp.i27.i.i.i291 = icmp slt i32 %sub.i.i275, 0
  %call1.i.i.i.i292 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i291, i32 noundef %288, i32 noundef 12, i32 noundef %sub.i.i275) #15
  %conv8.i.i.i293 = zext i1 %call1.i.i.i.i292 to i8
  %sf.i.i.i294 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i293, ptr %sf.i.i.i294, align 1
  %xor.i28.i.i.i295 = lshr i32 %xor.i.i.i.i283, 31
  %shr9.i.i.i.i296 = xor i32 %sub.i.i275, %288
  %xor3.i.i.i.i297 = lshr i32 %shr9.i.i.i.i296, 31
  %add.i.i.i.i298 = add nuw nsw i32 %xor3.i.i.i.i297, %xor.i28.i.i.i295
  %cmp.i29.i.i.i299 = icmp eq i32 %add.i.i.i.i298, 2
  %call.i30.i.i.i300 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i299, i32 noundef %288, i32 noundef 12, i32 noundef %sub.i.i275) #15
  %conv11.i.i.i301 = zext i1 %call.i30.i.i.i300 to i8
  %of.i.i.i302 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i301, ptr %of.i.i.i302, align 1
  store ptr %290, ptr %MEMORY, align 8
  br label %295

295:                                              ; preds = %285
  %296 = load i64, ptr %NEXT_PC, align 8
  store i64 %296, ptr %PC, align 8
  %297 = add i64 %296, 4
  store i64 %297, ptr %NEXT_PC, align 8
  %298 = load i64, ptr %RCX, align 8
  %299 = load ptr, ptr %MEMORY, align 8
  %sf.i340 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %300 = load i8, ptr %sf.i340, align 1
  %tobool.i341 = icmp ne i8 %300, 0
  %of.i342 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %301 = load i8, ptr %of.i342, align 1
  %tobool4.i343 = icmp ne i8 %301, 0
  %cmp.i.i344 = xor i1 %tobool.i341, %tobool4.i343
  %call5.i345 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i344) #16
  %dst.coerce.val.i346 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i345, i64 %298, i64 %dst.coerce.val.i346
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %299, ptr %MEMORY, align 8
  br label %302

302:                                              ; preds = %295
  %303 = load i64, ptr %NEXT_PC, align 8
  store i64 %303, ptr %PC, align 8
  %304 = add i64 %303, 3
  store i64 %304, ptr %NEXT_PC, align 8
  %305 = load i64, ptr %RAX, align 8
  %306 = load i64, ptr %RCX, align 8
  %307 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %305, %306
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i204 = icmp ult i64 %305, %306
  %call.i.i.i205 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i204, i64 noundef %305, i64 noundef %306, i64 noundef %sub.i.i) #15
  %conv.i.i206 = zext i1 %call.i.i.i205 to i8
  %cf.i.i207 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i206, ptr %cf.i.i207, align 1
  %conv.i.i.i.i208 = trunc i64 %sub.i.i to i8
  %308 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i208)
  %309 = and i8 %308, 1
  %conv.i.i.i209 = xor i8 %309, 1
  %pf.i.i.i210 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i209, ptr %pf.i.i.i210, align 1
  %xor.i.i.i.i211 = xor i64 %306, %305
  %xor1.i.i.i.i212 = xor i64 %xor.i.i.i.i211, %sub.i.i
  %310 = trunc i64 %xor1.i.i.i.i212 to i8
  %311 = lshr i8 %310, 4
  %conv2.i.i.i213 = and i8 %311, 1
  %af.i.i.i214 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i213, ptr %af.i.i.i214, align 1
  %cmp.i.i.i.i215 = icmp eq i64 %305, %306
  %call.i.i.i.i216 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i215, i64 noundef %305, i64 noundef %306, i64 noundef %sub.i.i) #15
  %conv5.i.i.i217 = zext i1 %call.i.i.i.i216 to i8
  %zf.i.i.i218 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i217, ptr %zf.i.i.i218, align 1
  %cmp.i27.i.i.i219 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i220 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i219, i64 noundef %305, i64 noundef %306, i64 noundef %sub.i.i) #15
  %conv8.i.i.i221 = zext i1 %call1.i.i.i.i220 to i8
  %sf.i.i.i222 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i221, ptr %sf.i.i.i222, align 1
  %xor.i28.i.i.i223 = lshr i64 %xor.i.i.i.i211, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %305
  %xor3.i.i.i.i224 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i225 = add nuw nsw i64 %xor3.i.i.i.i224, %xor.i28.i.i.i223
  %cmp.i29.i.i.i226 = icmp eq i64 %add.i.i.i.i225, 2
  %call.i30.i.i.i227 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i226, i64 noundef %305, i64 noundef %306, i64 noundef %sub.i.i) #15
  %conv11.i.i.i228 = zext i1 %call.i30.i.i.i227 to i8
  %of.i.i.i229 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i228, ptr %of.i.i.i229, align 1
  store ptr %307, ptr %MEMORY, align 8
  br label %312

312:                                              ; preds = %302
  %313 = load i64, ptr %NEXT_PC, align 8
  store i64 %313, ptr %PC, align 8
  %314 = add i64 %313, 4
  store i64 %314, ptr %NEXT_PC, align 8
  %315 = load i64, ptr %RBP, align 8
  %316 = sub i64 %315, 24
  %317 = load i64, ptr %RAX, align 8
  %318 = load ptr, ptr %MEMORY, align 8
  %call.i.i351 = call ptr @__remill_write_memory_64(ptr noundef %318, i64 noundef %316, i64 noundef %317) #15
  store ptr %call.i.i351, ptr %MEMORY, align 8
  br label %319

319:                                              ; preds = %312
  %320 = load i64, ptr %NEXT_PC, align 8
  store i64 %320, ptr %PC, align 8
  %321 = add i64 %320, 7
  store i64 %321, ptr %NEXT_PC, align 8
  %322 = load i64, ptr %NEXT_PC, align 8
  %323 = add i64 %322, 11672
  %324 = load ptr, ptr %MEMORY, align 8
  %call.i.i367 = call i64 @__remill_read_memory_64(ptr noundef %324, i64 noundef %323) #15
  store i64 %call.i.i367, ptr %RAX, align 8
  store ptr %324, ptr %MEMORY, align 8
  br label %325

325:                                              ; preds = %319
  %326 = load i64, ptr %NEXT_PC, align 8
  store i64 %326, ptr %PC, align 8
  %327 = add i64 %326, 2
  store i64 %327, ptr %NEXT_PC, align 8
  %328 = load i64, ptr %RAX, align 8
  %329 = load ptr, ptr %MEMORY, align 8
  %call.i.i360 = call i32 @__remill_read_memory_32(ptr noundef %329, i64 noundef %328) #15
  %conv.i.i361 = zext i32 %call.i.i360 to i64
  store i64 %conv.i.i361, ptr %RDX, align 8
  store ptr %329, ptr %MEMORY, align 8
  br label %330

330:                                              ; preds = %325
  %331 = load i64, ptr %NEXT_PC, align 8
  store i64 %331, ptr %PC, align 8
  %332 = add i64 %331, 7
  store i64 %332, ptr %NEXT_PC, align 8
  %333 = load i64, ptr %NEXT_PC, align 8
  %334 = add i64 %333, 11487
  %335 = load ptr, ptr %MEMORY, align 8
  %call.i.i366 = call i64 @__remill_read_memory_64(ptr noundef %335, i64 noundef %334) #15
  store i64 %call.i.i366, ptr %RAX, align 8
  store ptr %335, ptr %MEMORY, align 8
  br label %336

336:                                              ; preds = %330
  %337 = load i64, ptr %NEXT_PC, align 8
  store i64 %337, ptr %PC, align 8
  %338 = add i64 %337, 3
  store i64 %338, ptr %NEXT_PC, align 8
  %339 = load i64, ptr %RAX, align 8
  %340 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %340, i64 noundef %339) #15
  %sub.i.i230 = sub i32 %call.i.i, 10
  %cmp.i.i.i231 = icmp ult i32 %call.i.i, 10
  %call.i.i.i232 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i231, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #15
  %conv.i9.i = zext i1 %call.i.i.i232 to i8
  %cf.i.i233 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i233, align 1
  %conv.i.i.i.i234 = trunc i32 %sub.i.i230 to i8
  %341 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i234)
  %342 = and i8 %341, 1
  %conv.i.i.i235 = xor i8 %342, 1
  %pf.i.i.i236 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i235, ptr %pf.i.i.i236, align 1
  %xor.i.i.i.i237 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i238 = xor i32 %xor.i.i.i.i237, %sub.i.i230
  %343 = trunc i32 %xor1.i.i.i.i238 to i8
  %344 = lshr i8 %343, 4
  %conv2.i.i.i239 = and i8 %344, 1
  %af.i.i.i240 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i239, ptr %af.i.i.i240, align 1
  %cmp.i.i.i.i241 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i242 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i241, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #15
  %conv5.i.i.i243 = zext i1 %call.i.i.i.i242 to i8
  %zf.i.i.i244 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i243, ptr %zf.i.i.i244, align 1
  %cmp.i27.i.i.i245 = icmp slt i32 %sub.i.i230, 0
  %call1.i.i.i.i246 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i245, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #15
  %conv8.i.i.i247 = zext i1 %call1.i.i.i.i246 to i8
  %sf.i.i.i248 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i247, ptr %sf.i.i.i248, align 1
  %xor.i28.i.i.i249 = lshr i32 %xor.i.i.i.i237, 31
  %shr9.i.i.i.i250 = xor i32 %sub.i.i230, %call.i.i
  %xor3.i.i.i.i251 = lshr i32 %shr9.i.i.i.i250, 31
  %add.i.i.i.i252 = add nuw nsw i32 %xor3.i.i.i.i251, %xor.i28.i.i.i249
  %cmp.i29.i.i.i253 = icmp eq i32 %add.i.i.i.i252, 2
  %call.i30.i.i.i254 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i253, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i230) #15
  %conv11.i.i.i255 = zext i1 %call.i30.i.i.i254 to i8
  %of.i.i.i256 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i255, ptr %of.i.i.i256, align 1
  store ptr %340, ptr %MEMORY, align 8
  br label %345

345:                                              ; preds = %336
  %346 = load i64, ptr %NEXT_PC, align 8
  store i64 %346, ptr %PC, align 8
  %347 = add i64 %346, 3
  store i64 %347, ptr %NEXT_PC, align 8
  %348 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %349 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %349, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %350 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %350, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %348, ptr %MEMORY, align 8
  br label %351

351:                                              ; preds = %345
  %352 = load i64, ptr %NEXT_PC, align 8
  store i64 %352, ptr %PC, align 8
  %353 = add i64 %352, 2
  store i64 %353, ptr %NEXT_PC, align 8
  %354 = load i32, ptr %EDX, align 4
  %355 = zext i32 %354 to i64
  %356 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %355, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %356, ptr %MEMORY, align 8
  br label %357

357:                                              ; preds = %351
  %358 = load i64, ptr %NEXT_PC, align 8
  store i64 %358, ptr %PC, align 8
  %359 = add i64 %358, 3
  store i64 %359, ptr %NEXT_PC, align 8
  %360 = load i64, ptr %RCX, align 8
  %361 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %360 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %362 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %362, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %363 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %364 = and i8 %363, 1
  %conv.i.i.i = xor i8 %364, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %365 = trunc i32 %xor1.i.i.i.i to i8
  %366 = lshr i8 %365, 4
  %conv2.i.i.i = and i8 %366, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %361, ptr %MEMORY, align 8
  br label %367

367:                                              ; preds = %357
  %368 = load i64, ptr %NEXT_PC, align 8
  store i64 %368, ptr %PC, align 8
  %369 = add i64 %368, 3
  store i64 %369, ptr %NEXT_PC, align 8
  %370 = load i64, ptr %RCX, align 8
  %371 = load i32, ptr %EDX, align 4
  %372 = zext i32 %371 to i64
  %373 = load ptr, ptr %MEMORY, align 8
  %conv.i.i331 = trunc i64 %370 to i32
  %sext.i = shl i64 %370, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %372, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %374 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i332 = icmp ult i64 %374, -4294967296
  %call.i.i.i333 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i332, i32 noundef %conv.i.i331, i32 noundef %371, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i333 to i8
  %cf.i.i334 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i334, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %373, ptr %MEMORY, align 8
  br label %375

375:                                              ; preds = %367
  %376 = load i64, ptr %NEXT_PC, align 8
  store i64 %376, ptr %PC, align 8
  %377 = add i64 %376, 3
  store i64 %377, ptr %NEXT_PC, align 8
  %378 = load i64, ptr %RCX, align 8
  %379 = load ptr, ptr %MEMORY, align 8
  %conv.i.i372 = trunc i64 %378 to i32
  %and3.i.i = and i32 1, %conv.i.i372
  %conv.i22.i373 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i373, ptr %RCX, align 8
  %cf.i.i374 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i374, align 1
  %conv.i.i.i375 = trunc i32 %and3.i.i to i8
  %380 = and i8 %conv.i.i.i375, 1
  %conv.i23.i376 = xor i8 %380, 1
  %pf.i.i377 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i376, ptr %pf.i.i377, align 1
  %cmp.i.i.i378 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i379 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i378, i32 noundef %conv.i.i372, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i379 to i8
  %zf.i.i380 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i380, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i372, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i381 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i381, align 1
  %of.i.i382 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i382, align 1
  %af.i.i383 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i383, align 1
  store ptr %379, ptr %MEMORY, align 8
  br label %381

381:                                              ; preds = %375
  %382 = load i64, ptr %NEXT_PC, align 8
  store i64 %382, ptr %PC, align 8
  %383 = add i64 %382, 3
  store i64 %383, ptr %NEXT_PC, align 8
  %384 = load i32, ptr %ECX, align 4
  %385 = zext i32 %384 to i64
  %386 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i257 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %384, i32 noundef 0, i32 noundef %384) #15
  %conv.i12.i = zext i1 %call.i.i.i257 to i8
  %cf.i.i258 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i258, align 1
  %conv.i.i.i.i259 = trunc i32 %384 to i8
  %387 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i259)
  %388 = and i8 %387, 1
  %conv.i.i.i260 = xor i8 %388, 1
  %pf.i.i.i261 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i260, ptr %pf.i.i.i261, align 1
  %af.i.i.i262 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i262, align 1
  %cmp.i.i.i.i263 = icmp eq i32 %384, 0
  %call.i.i.i.i264 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i263, i32 noundef %384, i32 noundef 0, i32 noundef %384) #15
  %conv5.i.i.i265 = zext i1 %call.i.i.i.i264 to i8
  %zf.i.i.i266 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i265, ptr %zf.i.i.i266, align 1
  %cmp.i27.i.i.i267 = icmp slt i32 %384, 0
  %call1.i.i.i.i268 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i267, i32 noundef %384, i32 noundef 0, i32 noundef %384) #15
  %conv8.i.i.i269 = zext i1 %call1.i.i.i.i268 to i8
  %sf.i.i.i270 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i269, ptr %sf.i.i.i270, align 1
  %xor.i28.i.i.i271 = lshr i32 %384, 31
  %call.i30.i.i.i272 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %384, i32 noundef 0, i32 noundef %384) #15
  %conv11.i.i.i273 = zext i1 %call.i30.i.i.i272 to i8
  %of.i.i.i274 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i273, ptr %of.i.i.i274, align 1
  store ptr %386, ptr %MEMORY, align 8
  br label %389

389:                                              ; preds = %381
  %390 = load i64, ptr %NEXT_PC, align 8
  store i64 %390, ptr %PC, align 8
  %391 = add i64 %390, 3
  store i64 %391, ptr %NEXT_PC, align 8
  %392 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %393 = load i8, ptr %zf.i, align 1
  store i8 %393, ptr %CL, align 1
  store ptr %392, ptr %MEMORY, align 8
  br label %394

394:                                              ; preds = %389
  %395 = load i64, ptr %NEXT_PC, align 8
  store i64 %395, ptr %PC, align 8
  %396 = add i64 %395, 2
  store i64 %396, ptr %NEXT_PC, align 8
  %397 = load i8, ptr %AL, align 1
  %398 = zext i8 %397 to i64
  %399 = load i8, ptr %CL, align 1
  %400 = zext i8 %399 to i64
  %401 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %400, %398
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i384 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i384, align 1
  %402 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %403 = and i8 %402, 1
  %conv.i27.i = xor i8 %403, 1
  %pf.i.i385 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i385, align 1
  %404 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i386 = and i32 %404, 255
  %cmp.i.i.i387 = icmp eq i8 %or3.i.i, 0
  %405 = trunc i64 %398 to i32
  %conv1.i.i.i = and i32 %405, 255
  %406 = trunc i64 %400 to i32
  %conv2.i.i.i388 = and i32 %406, 255
  %call.i.i.i389 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i387, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i388, i32 noundef %conv.i.i.i386) #15
  %conv3.i.i390 = zext i1 %call.i.i.i389 to i8
  %zf.i.i391 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i390, ptr %zf.i.i391, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i388, i32 noundef %conv.i.i.i386) #15
  %conv6.i.i392 = zext i1 %call4.i.i.i to i8
  %sf.i.i393 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i392, ptr %sf.i.i393, align 1
  %of.i.i394 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i394, align 1
  %af.i.i395 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i395, align 1
  store ptr %401, ptr %MEMORY, align 8
  br label %407

407:                                              ; preds = %394
  %408 = load i64, ptr %NEXT_PC, align 8
  store i64 %408, ptr %PC, align 8
  %409 = add i64 %408, 2
  store i64 %409, ptr %NEXT_PC, align 8
  %410 = load i8, ptr %AL, align 1
  %411 = zext i8 %410 to i64
  %412 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %411
  %and3.i.i431 = trunc i64 %and3.i15.i to i8
  %cf.i.i432 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i432, align 1
  %413 = and i8 %and3.i.i431, 1
  %conv.i14.i = xor i8 %413, 1
  %pf.i.i433 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i433, align 1
  %414 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i434 = and i32 %414, 255
  %cmp.i.i.i435 = icmp eq i8 %and3.i.i431, 0
  %415 = trunc i64 %411 to i32
  %conv1.i.i.i436 = and i32 %415, 255
  %call.i.i.i437 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i435, i32 noundef %conv1.i.i.i436, i32 noundef 1, i32 noundef %conv.i.i.i434) #15
  %conv3.i.i438 = zext i1 %call.i.i.i437 to i8
  %zf.i.i439 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i438, ptr %zf.i.i439, align 1
  %call4.i.i.i440 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i436, i32 noundef 1, i32 noundef %conv.i.i.i434) #15
  %conv6.i.i441 = zext i1 %call4.i.i.i440 to i8
  %sf.i.i442 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i441, ptr %sf.i.i442, align 1
  %of.i.i443 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i443, align 1
  %af.i.i444 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i444, align 1
  store ptr %412, ptr %MEMORY, align 8
  br label %416

416:                                              ; preds = %407
  %417 = load i64, ptr %NEXT_PC, align 8
  store i64 %417, ptr %PC, align 8
  %418 = add i64 %417, 6
  store i64 %418, ptr %NEXT_PC, align 8
  %419 = load i64, ptr %NEXT_PC, align 8
  %420 = add i64 %419, 5
  %421 = load i64, ptr %NEXT_PC, align 8
  %422 = load ptr, ptr %MEMORY, align 8
  %zf.i347 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %423 = load i8, ptr %zf.i347, align 1
  %tobool.not.i = icmp eq i8 %423, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i348 = select i1 %call9.i, i64 %420, i64 %421
  store i64 %cond1.i.i348, ptr %NEXT_PC, align 8
  store ptr %422, ptr %MEMORY, align 8
  %424 = load i64, ptr %NEXT_PC, align 8
  store i64 %424, ptr %PC, align 8
  %425 = load ptr, ptr %MEMORY, align 8
  ret ptr %425
}

define ptr @BB_222f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 24
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2235(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11588
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11411
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_22c0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i4, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 32
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i3 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i3, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 6
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call ptr @__remill_write_memory_32(ptr noundef %17, i64 noundef %16, i32 noundef 0) #15
  store ptr %call.i.i1, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 6
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %22, i64 noundef %21, i32 noundef 1) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 7
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %NEXT_PC, align 8
  %27 = add i64 %26, 11629
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %28, i64 noundef %27) #15
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %23
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 2
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RAX, align 8
  %33 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %32, ptr %rip.i, align 8
  store i64 %32, ptr %NEXT_PC, align 8
  store ptr %33, ptr %MEMORY, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  ret ptr %34
}

define ptr @BB_226b(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i75 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i75, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 1) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11716
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i74, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  store i64 %21, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %21 to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %21, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %21, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %21, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %18
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 4
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 88
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_64(ptr noundef %31, i64 noundef %29, i64 noundef %30) #15
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %25
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 11517
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 2
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RDX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %38
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 7
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %NEXT_PC, align 8
  %47 = add i64 %46, 11340
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %48, i64 noundef %47) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %53, i64 noundef %52) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %54 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %55 = and i8 %54, 1
  %conv.i.i.i24 = xor i8 %55, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %56 = trunc i32 %xor1.i.i.i.i27 to i8
  %57 = lshr i8 %56, 4
  %conv2.i.i.i28 = and i8 %57, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %53, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %49
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 2
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %68, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RCX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %73 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %75 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %75, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %76 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %77 = and i8 %76, 1
  %conv.i.i.i = xor i8 %77, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %78 = trunc i32 %xor1.i.i.i.i to i8
  %79 = lshr i8 %78, 4
  %conv2.i.i.i = and i8 %79, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %70
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RCX, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %83 to i32
  %sext.i = shl i64 %83, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %85, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %87 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %87, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %84, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %80
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %conv.i.i76 = trunc i64 %91 to i32
  %and3.i.i = and i32 1, %conv.i.i76
  %conv.i22.i77 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i77, ptr %RCX, align 8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %conv.i.i.i79 = trunc i32 %and3.i.i to i8
  %93 = and i8 %conv.i.i.i79, 1
  %conv.i23.i80 = xor i8 %93, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i80, ptr %pf.i.i81, align 1
  %cmp.i.i.i82 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i82, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i83 to i8
  %zf.i.i84 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i84, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i85, align 1
  %of.i.i86 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i86, align 1
  %af.i.i87 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i87, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i32, ptr %ECX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %97 to i8
  %100 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %101 = and i8 %100, 1
  %conv.i.i.i48 = xor i8 %101, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %97, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %97, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %97, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %94
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 3
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %106 = load i8, ptr %zf.i, align 1
  store i8 %106, ptr %CL, align 1
  store ptr %105, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %102
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 2
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i8, ptr %AL, align 1
  %111 = zext i8 %110 to i64
  %112 = load i8, ptr %CL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %113, %111
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i88, align 1
  %115 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %116 = and i8 %115, 1
  %conv.i27.i = xor i8 %116, 1
  %pf.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i89, align 1
  %117 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i90 = and i32 %117, 255
  %cmp.i.i.i91 = icmp eq i8 %or3.i.i, 0
  %118 = trunc i64 %111 to i32
  %conv1.i.i.i = and i32 %118, 255
  %119 = trunc i64 %113 to i32
  %conv2.i.i.i92 = and i32 %119, 255
  %call.i.i.i93 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i91, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #15
  %conv3.i.i94 = zext i1 %call.i.i.i93 to i8
  %zf.i.i95 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i94, ptr %zf.i.i95, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #15
  %conv6.i.i96 = zext i1 %call4.i.i.i to i8
  %sf.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i96, ptr %sf.i.i97, align 1
  %of.i.i98 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i98, align 1
  %af.i.i99 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i99, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %107
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 2
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i8, ptr %AL, align 1
  %124 = zext i8 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %124
  %and3.i.i100 = trunc i64 %and3.i15.i to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i101, align 1
  %126 = and i8 %and3.i.i100, 1
  %conv.i14.i = xor i8 %126, 1
  %pf.i.i102 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i102, align 1
  %127 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i103 = and i32 %127, 255
  %cmp.i.i.i104 = icmp eq i8 %and3.i.i100, 0
  %128 = trunc i64 %124 to i32
  %conv1.i.i.i105 = and i32 %128, 255
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i104, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #15
  %conv3.i.i107 = zext i1 %call.i.i.i106 to i8
  %zf.i.i108 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i107, ptr %zf.i.i108, align 1
  %call4.i.i.i109 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #15
  %conv6.i.i110 = zext i1 %call4.i.i.i109 to i8
  %sf.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i110, ptr %sf.i.i111, align 1
  %of.i.i112 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i112, align 1
  %af.i.i113 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i113, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %120
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 6
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %NEXT_PC, align 8
  %133 = add i64 %132, 5
  %134 = load i64, ptr %NEXT_PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %136 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %136, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %133, i64 %134
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %135, ptr %MEMORY, align 8
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  ret ptr %138
}

define ptr @BB_22dd(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11380
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11531
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_22ba(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 88
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2313(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i187 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i187, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i186 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i186, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i181 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #15
  %conv.i.i182 = zext i32 %call.i.i181 to i64
  store i64 %conv.i.i182, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i179 = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %conv.i.i180 = zext i32 %call.i.i179 to i64
  store i64 %conv.i.i180, ptr %RSI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 3
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RSI, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %26 to i32
  %sub.i.i = sub i32 %conv.i.i1, 1
  %conv.i22.i2 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i2, ptr %RSI, align 8
  %cmp.i.i.i3 = icmp ult i32 %conv.i.i1, 1
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i3, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv.i23.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %sub.i.i to i8
  %28 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %29 = and i8 %28, 1
  %conv.i.i.i8 = xor i8 %29, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 1, %conv.i.i1
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %sub.i.i
  %30 = trunc i32 %xor1.i.i.i.i11 to i8
  %31 = lshr i8 %30, 4
  %conv2.i.i.i12 = and i8 %31, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %conv.i.i1, 1
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %xor.i28.i.i.i22 = lshr i32 %xor.i.i.i.i10, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i1
  %xor3.i.i.i.i23 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i24 = add nuw nsw i32 %xor3.i.i.i.i23, %xor.i28.i.i.i22
  %cmp.i29.i.i.i25 = icmp eq i32 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %27, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %23
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 5
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  store i64 5, ptr %RCX, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %32
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 5
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 4, ptr %RAX, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %36
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 2
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i32, ptr %EDX, align 4
  %44 = zext i32 %43 to i64
  %45 = load i32, ptr %ESI, align 4
  %46 = zext i32 %45 to i64
  %47 = load ptr, ptr %MEMORY, align 8
  %sub.i.i130 = sub i32 %43, %45
  %cmp.i.i.i131 = icmp ult i32 %43, %45
  %call.i.i.i132 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i131, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv.i12.i133 = zext i1 %call.i.i.i132 to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i133, ptr %cf.i.i134, align 1
  %conv.i.i.i.i135 = trunc i32 %sub.i.i130 to i8
  %48 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i135)
  %49 = and i8 %48, 1
  %conv.i.i.i136 = xor i8 %49, 1
  %pf.i.i.i137 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i136, ptr %pf.i.i.i137, align 1
  %xor.i.i.i.i138 = xor i32 %45, %43
  %xor1.i.i.i.i139 = xor i32 %xor.i.i.i.i138, %sub.i.i130
  %50 = trunc i32 %xor1.i.i.i.i139 to i8
  %51 = lshr i8 %50, 4
  %conv2.i.i.i140 = and i8 %51, 1
  %af.i.i.i141 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i140, ptr %af.i.i.i141, align 1
  %cmp.i.i.i.i142 = icmp eq i32 %43, %45
  %call.i.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i142, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv5.i.i.i144 = zext i1 %call.i.i.i.i143 to i8
  %zf.i.i.i145 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i144, ptr %zf.i.i.i145, align 1
  %cmp.i27.i.i.i146 = icmp slt i32 %sub.i.i130, 0
  %call1.i.i.i.i147 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i146, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv8.i.i.i148 = zext i1 %call1.i.i.i.i147 to i8
  %sf.i.i.i149 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i148, ptr %sf.i.i.i149, align 1
  %xor.i28.i.i.i150 = lshr i32 %xor.i.i.i.i138, 31
  %shr9.i.i.i.i151 = xor i32 %sub.i.i130, %43
  %xor3.i.i.i.i152 = lshr i32 %shr9.i.i.i.i151, 31
  %add.i.i.i.i153 = add nuw nsw i32 %xor3.i.i.i.i152, %xor.i28.i.i.i150
  %cmp.i29.i.i.i154 = icmp eq i32 %add.i.i.i.i153, 2
  %call.i30.i.i.i155 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i154, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv11.i.i.i156 = zext i1 %call.i30.i.i.i155 to i8
  %of.i.i.i157 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i156, ptr %of.i.i.i157, align 1
  store ptr %47, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %40
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EAX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %sf.i162 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %58 = load i8, ptr %sf.i162, align 1
  %tobool.i163 = icmp ne i8 %58, 0
  %of.i164 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %59 = load i8, ptr %of.i164, align 1
  %tobool4.i = icmp ne i8 %59, 0
  %cmp.i.i165 = xor i1 %tobool.i163, %tobool4.i
  %call5.i = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i165) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call5.i, i64 %56, i64 %dst.coerce.val.i
  %conv.i23.i166 = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i23.i166, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %52
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 11512
  %65 = load ptr, ptr %MEMORY, align 8
  store i64 %64, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i32, ptr %ECX, align 4
  %70 = zext i32 %69 to i64
  %71 = load ptr, ptr %MEMORY, align 8
  %sext.i188 = shl i64 %70, 32
  %conv.i12.i189 = ashr exact i64 %sext.i188, 32
  store i64 %conv.i12.i189, ptr %RCX, align 8
  store ptr %71, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %66
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 4
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %RAX, align 8
  %76 = load i64, ptr %RCX, align 8
  %77 = mul i64 %76, 8
  %78 = add i64 %75, %77
  %79 = load ptr, ptr %MEMORY, align 8
  %call.i.i185 = call i64 @__remill_read_memory_64(ptr noundef %79, i64 noundef %78) #15
  store i64 %call.i.i185, ptr %RAX, align 8
  store ptr %79, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %72
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 2
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RCX, align 8
  %84 = load i32, ptr %ECX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i214 = trunc i64 %83 to i32
  %xor3.i.i = xor i32 %84, %conv.i.i214
  %conv.i27.i215 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i215, ptr %RCX, align 8
  %cf.i.i216 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i216, align 1
  %conv.i.i.i217 = trunc i32 %xor3.i.i to i8
  %87 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i217)
  %88 = and i8 %87, 1
  %conv.i28.i218 = xor i8 %88, 1
  %pf.i.i219 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i218, ptr %pf.i.i219, align 1
  %cmp.i.i.i220 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i221 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i220, i32 noundef %conv.i.i214, i32 noundef %84, i32 noundef %xor3.i.i) #15
  %conv3.i.i222 = zext i1 %call.i.i.i221 to i8
  %zf.i.i223 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i222, ptr %zf.i.i223, align 1
  %cmp.i19.i.i224 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i225 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i224, i32 noundef %conv.i.i214, i32 noundef %84, i32 noundef %xor3.i.i) #15
  %conv6.i.i226 = zext i1 %call1.i.i.i225 to i8
  %sf.i.i227 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i226, ptr %sf.i.i227, align 1
  %of.i.i228 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i228, align 1
  %af.i.i229 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i230 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i230, ptr %af.i.i229, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %80
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i32, ptr %EDX, align 4
  %93 = zext i32 %92 to i64
  %94 = load i32, ptr %ESI, align 4
  %95 = zext i32 %94 to i64
  %96 = load ptr, ptr %MEMORY, align 8
  %sub.i.i102 = sub i32 %92, %94
  %cmp.i.i.i103 = icmp ult i32 %92, %94
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i103, i32 noundef %92, i32 noundef %94, i32 noundef %sub.i.i102) #15
  %conv.i12.i105 = zext i1 %call.i.i.i104 to i8
  %cf.i.i106 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i105, ptr %cf.i.i106, align 1
  %conv.i.i.i.i107 = trunc i32 %sub.i.i102 to i8
  %97 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i107)
  %98 = and i8 %97, 1
  %conv.i.i.i108 = xor i8 %98, 1
  %pf.i.i.i109 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i108, ptr %pf.i.i.i109, align 1
  %xor.i.i.i.i110 = xor i32 %94, %92
  %xor1.i.i.i.i111 = xor i32 %xor.i.i.i.i110, %sub.i.i102
  %99 = trunc i32 %xor1.i.i.i.i111 to i8
  %100 = lshr i8 %99, 4
  %conv2.i.i.i112 = and i8 %100, 1
  %af.i.i.i113 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i112, ptr %af.i.i.i113, align 1
  %cmp.i.i.i.i114 = icmp eq i32 %92, %94
  %call.i.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i114, i32 noundef %92, i32 noundef %94, i32 noundef %sub.i.i102) #15
  %conv5.i.i.i116 = zext i1 %call.i.i.i.i115 to i8
  %zf.i.i.i117 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i116, ptr %zf.i.i.i117, align 1
  %cmp.i27.i.i.i118 = icmp slt i32 %sub.i.i102, 0
  %call1.i.i.i.i119 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i118, i32 noundef %92, i32 noundef %94, i32 noundef %sub.i.i102) #15
  %conv8.i.i.i120 = zext i1 %call1.i.i.i.i119 to i8
  %sf.i.i.i121 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i120, ptr %sf.i.i.i121, align 1
  %xor.i28.i.i.i122 = lshr i32 %xor.i.i.i.i110, 31
  %shr9.i.i.i.i123 = xor i32 %sub.i.i102, %92
  %xor3.i.i.i.i124 = lshr i32 %shr9.i.i.i.i123, 31
  %add.i.i.i.i125 = add nuw nsw i32 %xor3.i.i.i.i124, %xor.i28.i.i.i122
  %cmp.i29.i.i.i126 = icmp eq i32 %add.i.i.i.i125, 2
  %call.i30.i.i.i127 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i126, i32 noundef %92, i32 noundef %94, i32 noundef %sub.i.i102) #15
  %conv11.i.i.i128 = zext i1 %call.i30.i.i.i127 to i8
  %of.i.i.i129 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i128, ptr %of.i.i.i129, align 1
  store ptr %96, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %89
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 4
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RCX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %sf.i167 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %106 = load i8, ptr %sf.i167, align 1
  %tobool.i168 = icmp ne i8 %106, 0
  %of.i169 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %107 = load i8, ptr %of.i169, align 1
  %tobool4.i170 = icmp ne i8 %107, 0
  %cmp.i.i171 = xor i1 %tobool.i168, %tobool4.i170
  %call5.i172 = call zeroext i1 @__remill_compare_slt(i1 noundef zeroext %cmp.i.i171) #16
  %dst.coerce.val.i173 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call5.i172, i64 %104, i64 %dst.coerce.val.i173
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %101
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 3
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i64, ptr %RAX, align 8
  %112 = load i64, ptr %RCX, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  %sub.i.i29 = sub i64 %111, %112
  store i64 %sub.i.i29, ptr %RAX, align 8
  %cmp.i.i.i30 = icmp ult i64 %111, %112
  %call.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i30, i64 noundef %111, i64 noundef %112, i64 noundef %sub.i.i29) #15
  %conv.i.i32 = zext i1 %call.i.i.i31 to i8
  %cf.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i32, ptr %cf.i.i33, align 1
  %conv.i.i.i.i34 = trunc i64 %sub.i.i29 to i8
  %114 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i34)
  %115 = and i8 %114, 1
  %conv.i.i.i35 = xor i8 %115, 1
  %pf.i.i.i36 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i35, ptr %pf.i.i.i36, align 1
  %xor.i.i.i.i37 = xor i64 %112, %111
  %xor1.i.i.i.i38 = xor i64 %xor.i.i.i.i37, %sub.i.i29
  %116 = trunc i64 %xor1.i.i.i.i38 to i8
  %117 = lshr i8 %116, 4
  %conv2.i.i.i39 = and i8 %117, 1
  %af.i.i.i40 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i39, ptr %af.i.i.i40, align 1
  %cmp.i.i.i.i41 = icmp eq i64 %111, %112
  %call.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i41, i64 noundef %111, i64 noundef %112, i64 noundef %sub.i.i29) #15
  %conv5.i.i.i43 = zext i1 %call.i.i.i.i42 to i8
  %zf.i.i.i44 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i43, ptr %zf.i.i.i44, align 1
  %cmp.i27.i.i.i45 = icmp slt i64 %sub.i.i29, 0
  %call1.i.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i45, i64 noundef %111, i64 noundef %112, i64 noundef %sub.i.i29) #15
  %conv8.i.i.i47 = zext i1 %call1.i.i.i.i46 to i8
  %sf.i.i.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i47, ptr %sf.i.i.i48, align 1
  %xor.i28.i.i.i49 = lshr i64 %xor.i.i.i.i37, 63
  %shr9.i.i.i.i50 = xor i64 %sub.i.i29, %111
  %xor3.i.i.i.i51 = lshr i64 %shr9.i.i.i.i50, 63
  %add.i.i.i.i52 = add nuw nsw i64 %xor3.i.i.i.i51, %xor.i28.i.i.i49
  %cmp.i29.i.i.i53 = icmp eq i64 %add.i.i.i.i52, 2
  %call.i30.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i53, i64 noundef %111, i64 noundef %112, i64 noundef %sub.i.i29) #15
  %conv11.i.i.i55 = zext i1 %call.i30.i.i.i54 to i8
  %of.i.i.i56 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i55, ptr %of.i.i.i56, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %108
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 4
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %RBP, align 8
  %122 = sub i64 %121, 96
  %123 = load i64, ptr %RAX, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %call.i.i176 = call ptr @__remill_write_memory_64(ptr noundef %124, i64 noundef %122, i64 noundef %123) #15
  store ptr %call.i.i176, ptr %MEMORY, align 8
  br label %125

125:                                              ; preds = %118
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = add i64 %126, 7
  store i64 %127, ptr %NEXT_PC, align 8
  %128 = load i64, ptr %NEXT_PC, align 8
  %129 = add i64 %128, 11235
  %130 = load ptr, ptr %MEMORY, align 8
  %call.i.i184 = call i64 @__remill_read_memory_64(ptr noundef %130, i64 noundef %129) #15
  store i64 %call.i.i184, ptr %RAX, align 8
  store ptr %130, ptr %MEMORY, align 8
  br label %131

131:                                              ; preds = %125
  %132 = load i64, ptr %NEXT_PC, align 8
  store i64 %132, ptr %PC, align 8
  %133 = add i64 %132, 2
  store i64 %133, ptr %NEXT_PC, align 8
  %134 = load i64, ptr %RAX, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %call.i.i177 = call i32 @__remill_read_memory_32(ptr noundef %135, i64 noundef %134) #15
  %conv.i.i178 = zext i32 %call.i.i177 to i64
  store i64 %conv.i.i178, ptr %RDX, align 8
  store ptr %135, ptr %MEMORY, align 8
  br label %136

136:                                              ; preds = %131
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = add i64 %137, 7
  store i64 %138, ptr %NEXT_PC, align 8
  %139 = load i64, ptr %NEXT_PC, align 8
  %140 = add i64 %139, 11386
  %141 = load ptr, ptr %MEMORY, align 8
  %call.i.i183 = call i64 @__remill_read_memory_64(ptr noundef %141, i64 noundef %140) #15
  store i64 %call.i.i183, ptr %RAX, align 8
  store ptr %141, ptr %MEMORY, align 8
  br label %142

142:                                              ; preds = %136
  %143 = load i64, ptr %NEXT_PC, align 8
  store i64 %143, ptr %PC, align 8
  %144 = add i64 %143, 3
  store i64 %144, ptr %NEXT_PC, align 8
  %145 = load i64, ptr %RAX, align 8
  %146 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %146, i64 noundef %145) #15
  %sub.i.i57 = sub i32 %call.i.i, 10
  %cmp.i.i.i58 = icmp ult i32 %call.i.i, 10
  %call.i.i.i59 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i58, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv.i9.i = zext i1 %call.i.i.i59 to i8
  %cf.i.i60 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i60, align 1
  %conv.i.i.i.i61 = trunc i32 %sub.i.i57 to i8
  %147 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i61)
  %148 = and i8 %147, 1
  %conv.i.i.i62 = xor i8 %148, 1
  %pf.i.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i62, ptr %pf.i.i.i63, align 1
  %xor.i.i.i.i64 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i65 = xor i32 %xor.i.i.i.i64, %sub.i.i57
  %149 = trunc i32 %xor1.i.i.i.i65 to i8
  %150 = lshr i8 %149, 4
  %conv2.i.i.i66 = and i8 %150, 1
  %af.i.i.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i66, ptr %af.i.i.i67, align 1
  %cmp.i.i.i.i68 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i68, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv5.i.i.i70 = zext i1 %call.i.i.i.i69 to i8
  %zf.i.i.i71 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i70, ptr %zf.i.i.i71, align 1
  %cmp.i27.i.i.i72 = icmp slt i32 %sub.i.i57, 0
  %call1.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv8.i.i.i74 = zext i1 %call1.i.i.i.i73 to i8
  %sf.i.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i74, ptr %sf.i.i.i75, align 1
  %xor.i28.i.i.i76 = lshr i32 %xor.i.i.i.i64, 31
  %shr9.i.i.i.i77 = xor i32 %sub.i.i57, %call.i.i
  %xor3.i.i.i.i78 = lshr i32 %shr9.i.i.i.i77, 31
  %add.i.i.i.i79 = add nuw nsw i32 %xor3.i.i.i.i78, %xor.i28.i.i.i76
  %cmp.i29.i.i.i80 = icmp eq i32 %add.i.i.i.i79, 2
  %call.i30.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i80, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv11.i.i.i82 = zext i1 %call.i30.i.i.i81 to i8
  %of.i.i.i83 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i82, ptr %of.i.i.i83, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %151

151:                                              ; preds = %142
  %152 = load i64, ptr %NEXT_PC, align 8
  store i64 %152, ptr %PC, align 8
  %153 = add i64 %152, 3
  store i64 %153, ptr %NEXT_PC, align 8
  %154 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %155 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %155, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %156 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %156, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %154, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %151
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 2
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load i32, ptr %EDX, align 4
  %161 = zext i32 %160 to i64
  %162 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %161, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %162, ptr %MEMORY, align 8
  br label %163

163:                                              ; preds = %157
  %164 = load i64, ptr %NEXT_PC, align 8
  store i64 %164, ptr %PC, align 8
  %165 = add i64 %164, 3
  store i64 %165, ptr %NEXT_PC, align 8
  %166 = load i64, ptr %RCX, align 8
  %167 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %166 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %168 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %168, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %169 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %170 = and i8 %169, 1
  %conv.i.i.i = xor i8 %170, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %171 = trunc i32 %xor1.i.i.i.i to i8
  %172 = lshr i8 %171, 4
  %conv2.i.i.i = and i8 %172, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %167, ptr %MEMORY, align 8
  br label %173

173:                                              ; preds = %163
  %174 = load i64, ptr %NEXT_PC, align 8
  store i64 %174, ptr %PC, align 8
  %175 = add i64 %174, 3
  store i64 %175, ptr %NEXT_PC, align 8
  %176 = load i64, ptr %RCX, align 8
  %177 = load i32, ptr %EDX, align 4
  %178 = zext i32 %177 to i64
  %179 = load ptr, ptr %MEMORY, align 8
  %conv.i.i158 = trunc i64 %176 to i32
  %sext.i = shl i64 %176, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %178, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %180 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i159 = icmp ult i64 %180, -4294967296
  %call.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i159, i32 noundef %conv.i.i158, i32 noundef %177, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i160 to i8
  %cf.i.i161 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i161, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %179, ptr %MEMORY, align 8
  br label %181

181:                                              ; preds = %173
  %182 = load i64, ptr %NEXT_PC, align 8
  store i64 %182, ptr %PC, align 8
  %183 = add i64 %182, 3
  store i64 %183, ptr %NEXT_PC, align 8
  %184 = load i64, ptr %RCX, align 8
  %185 = load ptr, ptr %MEMORY, align 8
  %conv.i.i190 = trunc i64 %184 to i32
  %and3.i.i = and i32 1, %conv.i.i190
  %conv.i22.i191 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i191, ptr %RCX, align 8
  %cf.i.i192 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i192, align 1
  %conv.i.i.i193 = trunc i32 %and3.i.i to i8
  %186 = and i8 %conv.i.i.i193, 1
  %conv.i23.i194 = xor i8 %186, 1
  %pf.i.i195 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i194, ptr %pf.i.i195, align 1
  %cmp.i.i.i196 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i197 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i196, i32 noundef %conv.i.i190, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i197 to i8
  %zf.i.i198 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i198, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i190, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i199 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i199, align 1
  %of.i.i200 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i200, align 1
  %af.i.i201 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i201, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %187

187:                                              ; preds = %181
  %188 = load i64, ptr %NEXT_PC, align 8
  store i64 %188, ptr %PC, align 8
  %189 = add i64 %188, 3
  store i64 %189, ptr %NEXT_PC, align 8
  %190 = load i32, ptr %ECX, align 4
  %191 = zext i32 %190 to i64
  %192 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %190, i32 noundef 0, i32 noundef %190) #15
  %conv.i12.i = zext i1 %call.i.i.i84 to i8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i85, align 1
  %conv.i.i.i.i86 = trunc i32 %190 to i8
  %193 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i86)
  %194 = and i8 %193, 1
  %conv.i.i.i87 = xor i8 %194, 1
  %pf.i.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i87, ptr %pf.i.i.i88, align 1
  %af.i.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i89, align 1
  %cmp.i.i.i.i90 = icmp eq i32 %190, 0
  %call.i.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i90, i32 noundef %190, i32 noundef 0, i32 noundef %190) #15
  %conv5.i.i.i92 = zext i1 %call.i.i.i.i91 to i8
  %zf.i.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i92, ptr %zf.i.i.i93, align 1
  %cmp.i27.i.i.i94 = icmp slt i32 %190, 0
  %call1.i.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i94, i32 noundef %190, i32 noundef 0, i32 noundef %190) #15
  %conv8.i.i.i96 = zext i1 %call1.i.i.i.i95 to i8
  %sf.i.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i96, ptr %sf.i.i.i97, align 1
  %xor.i28.i.i.i98 = lshr i32 %190, 31
  %call.i30.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %190, i32 noundef 0, i32 noundef %190) #15
  %conv11.i.i.i100 = zext i1 %call.i30.i.i.i99 to i8
  %of.i.i.i101 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i100, ptr %of.i.i.i101, align 1
  store ptr %192, ptr %MEMORY, align 8
  br label %195

195:                                              ; preds = %187
  %196 = load i64, ptr %NEXT_PC, align 8
  store i64 %196, ptr %PC, align 8
  %197 = add i64 %196, 3
  store i64 %197, ptr %NEXT_PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %199 = load i8, ptr %zf.i, align 1
  store i8 %199, ptr %CL, align 1
  store ptr %198, ptr %MEMORY, align 8
  br label %200

200:                                              ; preds = %195
  %201 = load i64, ptr %NEXT_PC, align 8
  store i64 %201, ptr %PC, align 8
  %202 = add i64 %201, 2
  store i64 %202, ptr %NEXT_PC, align 8
  %203 = load i8, ptr %AL, align 1
  %204 = zext i8 %203 to i64
  %205 = load i8, ptr %CL, align 1
  %206 = zext i8 %205 to i64
  %207 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %206, %204
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i202 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i202, align 1
  %208 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %209 = and i8 %208, 1
  %conv.i27.i = xor i8 %209, 1
  %pf.i.i203 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i203, align 1
  %210 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i204 = and i32 %210, 255
  %cmp.i.i.i205 = icmp eq i8 %or3.i.i, 0
  %211 = trunc i64 %204 to i32
  %conv1.i.i.i = and i32 %211, 255
  %212 = trunc i64 %206 to i32
  %conv2.i.i.i206 = and i32 %212, 255
  %call.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i205, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i206, i32 noundef %conv.i.i.i204) #15
  %conv3.i.i208 = zext i1 %call.i.i.i207 to i8
  %zf.i.i209 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i208, ptr %zf.i.i209, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i206, i32 noundef %conv.i.i.i204) #15
  %conv6.i.i210 = zext i1 %call4.i.i.i to i8
  %sf.i.i211 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i210, ptr %sf.i.i211, align 1
  %of.i.i212 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i212, align 1
  %af.i.i213 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i213, align 1
  store ptr %207, ptr %MEMORY, align 8
  br label %213

213:                                              ; preds = %200
  %214 = load i64, ptr %NEXT_PC, align 8
  store i64 %214, ptr %PC, align 8
  %215 = add i64 %214, 2
  store i64 %215, ptr %NEXT_PC, align 8
  %216 = load i8, ptr %AL, align 1
  %217 = zext i8 %216 to i64
  %218 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %217
  %and3.i.i231 = trunc i64 %and3.i15.i to i8
  %cf.i.i232 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i232, align 1
  %219 = and i8 %and3.i.i231, 1
  %conv.i14.i = xor i8 %219, 1
  %pf.i.i233 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i233, align 1
  %220 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i234 = and i32 %220, 255
  %cmp.i.i.i235 = icmp eq i8 %and3.i.i231, 0
  %221 = trunc i64 %217 to i32
  %conv1.i.i.i236 = and i32 %221, 255
  %call.i.i.i237 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i235, i32 noundef %conv1.i.i.i236, i32 noundef 1, i32 noundef %conv.i.i.i234) #15
  %conv3.i.i238 = zext i1 %call.i.i.i237 to i8
  %zf.i.i239 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i238, ptr %zf.i.i239, align 1
  %call4.i.i.i240 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i236, i32 noundef 1, i32 noundef %conv.i.i.i234) #15
  %conv6.i.i241 = zext i1 %call4.i.i.i240 to i8
  %sf.i.i242 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i241, ptr %sf.i.i242, align 1
  %of.i.i243 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i243, align 1
  %af.i.i244 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i244, align 1
  store ptr %218, ptr %MEMORY, align 8
  br label %222

222:                                              ; preds = %213
  %223 = load i64, ptr %NEXT_PC, align 8
  store i64 %223, ptr %PC, align 8
  %224 = add i64 %223, 6
  store i64 %224, ptr %NEXT_PC, align 8
  %225 = load i64, ptr %NEXT_PC, align 8
  %226 = add i64 %225, 5
  %227 = load i64, ptr %NEXT_PC, align 8
  %228 = load ptr, ptr %MEMORY, align 8
  %zf.i174 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %229 = load i8, ptr %zf.i174, align 1
  %tobool.not.i = icmp eq i8 %229, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i175 = select i1 %call9.i, i64 %226, i64 %227
  store i64 %cond1.i.i175, ptr %NEXT_PC, align 8
  store ptr %228, ptr %MEMORY, align 8
  %230 = load i64, ptr %NEXT_PC, align 8
  store i64 %230, ptr %PC, align 8
  %231 = load ptr, ptr %MEMORY, align 8
  ret ptr %231
}

define ptr @BB_2954(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9493
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9620
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2384(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 96
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_298a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i56 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i56, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i53 = zext i32 %call.i.i52 to i64
  store i64 %conv.i.i53, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 6
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RBP, align 8
  %16 = sub i64 %15, 172
  %17 = load i32, ptr %EAX, align 4
  %18 = zext i32 %17 to i64
  %19 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call ptr @__remill_write_memory_32(ptr noundef %19, i64 noundef %16, i32 noundef %17) #15
  store ptr %call.i.i49, ptr %MEMORY, align 8
  br label %20

20:                                               ; preds = %12
  %21 = load i64, ptr %NEXT_PC, align 8
  store i64 %21, ptr %PC, align 8
  %22 = add i64 %21, 7
  store i64 %22, ptr %NEXT_PC, align 8
  %23 = load i64, ptr %NEXT_PC, align 8
  %24 = add i64 %23, 9435
  %25 = load ptr, ptr %MEMORY, align 8
  %call.i.i55 = call i64 @__remill_read_memory_64(ptr noundef %25, i64 noundef %24) #15
  store i64 %call.i.i55, ptr %RAX, align 8
  store ptr %25, ptr %MEMORY, align 8
  br label %26

26:                                               ; preds = %20
  %27 = load i64, ptr %NEXT_PC, align 8
  store i64 %27, ptr %PC, align 8
  %28 = add i64 %27, 2
  store i64 %28, ptr %NEXT_PC, align 8
  %29 = load i64, ptr %RAX, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %call.i.i50 = call i32 @__remill_read_memory_32(ptr noundef %30, i64 noundef %29) #15
  %conv.i.i51 = zext i32 %call.i.i50 to i64
  store i64 %conv.i.i51, ptr %RDX, align 8
  store ptr %30, ptr %MEMORY, align 8
  br label %31

31:                                               ; preds = %26
  %32 = load i64, ptr %NEXT_PC, align 8
  store i64 %32, ptr %PC, align 8
  %33 = add i64 %32, 7
  store i64 %33, ptr %NEXT_PC, align 8
  %34 = load i64, ptr %NEXT_PC, align 8
  %35 = add i64 %34, 9546
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i54 = call i64 @__remill_read_memory_64(ptr noundef %36, i64 noundef %35) #15
  store i64 %call.i.i54, ptr %RAX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %31
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RAX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %41, i64 noundef %40) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %42 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %43 = and i8 %42, 1
  %conv.i.i.i5 = xor i8 %43, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %44 = trunc i32 %xor1.i.i.i.i8 to i8
  %45 = lshr i8 %44, 4
  %conv2.i.i.i9 = and i8 %45, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %41, ptr %MEMORY, align 8
  br label %46

46:                                               ; preds = %37
  %47 = load i64, ptr %NEXT_PC, align 8
  store i64 %47, ptr %PC, align 8
  %48 = add i64 %47, 3
  store i64 %48, ptr %NEXT_PC, align 8
  %49 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %50 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %50, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %51 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %51, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %49, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %46
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 2
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EDX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %56, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %52
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RCX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %61 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %63 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %63, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %64 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %65 = and i8 %64, 1
  %conv.i.i.i = xor i8 %65, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %66 = trunc i32 %xor1.i.i.i.i to i8
  %67 = lshr i8 %66, 4
  %conv2.i.i.i = and i8 %67, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %62, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %58
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i64, ptr %RCX, align 8
  %72 = load i32, ptr %EDX, align 4
  %73 = zext i32 %72 to i64
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %71 to i32
  %sext.i = shl i64 %71, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %73, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %75 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %75, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %72, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %68
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 3
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RCX, align 8
  %80 = load ptr, ptr %MEMORY, align 8
  %conv.i.i57 = trunc i64 %79 to i32
  %and3.i.i = and i32 1, %conv.i.i57
  %conv.i22.i58 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i58, ptr %RCX, align 8
  %cf.i.i59 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i59, align 1
  %conv.i.i.i60 = trunc i32 %and3.i.i to i8
  %81 = and i8 %conv.i.i.i60, 1
  %conv.i23.i61 = xor i8 %81, 1
  %pf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i61, ptr %pf.i.i62, align 1
  %cmp.i.i.i63 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i63, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i64 to i8
  %zf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i65, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i57, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i66, align 1
  %of.i.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i67, align 1
  %af.i.i68 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i68, align 1
  store ptr %80, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %76
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 3
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i32, ptr %ECX, align 4
  %86 = zext i32 %85 to i64
  %87 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %85 to i8
  %88 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %89 = and i8 %88, 1
  %conv.i.i.i29 = xor i8 %89, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %85, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %85, i32 noundef 0, i32 noundef %85) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %85, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %85, i32 noundef 0, i32 noundef %85) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %85, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %85, i32 noundef 0, i32 noundef %85) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %87, ptr %MEMORY, align 8
  br label %90

90:                                               ; preds = %82
  %91 = load i64, ptr %NEXT_PC, align 8
  store i64 %91, ptr %PC, align 8
  %92 = add i64 %91, 3
  store i64 %92, ptr %NEXT_PC, align 8
  %93 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %94 = load i8, ptr %zf.i, align 1
  store i8 %94, ptr %CL, align 1
  store ptr %93, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %90
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 2
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i8, ptr %AL, align 1
  %99 = zext i8 %98 to i64
  %100 = load i8, ptr %CL, align 1
  %101 = zext i8 %100 to i64
  %102 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %101, %99
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i69 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i69, align 1
  %103 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %104 = and i8 %103, 1
  %conv.i27.i = xor i8 %104, 1
  %pf.i.i70 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i70, align 1
  %105 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i71 = and i32 %105, 255
  %cmp.i.i.i72 = icmp eq i8 %or3.i.i, 0
  %106 = trunc i64 %99 to i32
  %conv1.i.i.i = and i32 %106, 255
  %107 = trunc i64 %101 to i32
  %conv2.i.i.i73 = and i32 %107, 255
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i72, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #15
  %conv3.i.i75 = zext i1 %call.i.i.i74 to i8
  %zf.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i75, ptr %zf.i.i76, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i73, i32 noundef %conv.i.i.i71) #15
  %conv6.i.i77 = zext i1 %call4.i.i.i to i8
  %sf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i77, ptr %sf.i.i78, align 1
  %of.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i79, align 1
  %af.i.i80 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i80, align 1
  store ptr %102, ptr %MEMORY, align 8
  br label %108

108:                                              ; preds = %95
  %109 = load i64, ptr %NEXT_PC, align 8
  store i64 %109, ptr %PC, align 8
  %110 = add i64 %109, 2
  store i64 %110, ptr %NEXT_PC, align 8
  %111 = load i8, ptr %AL, align 1
  %112 = zext i8 %111 to i64
  %113 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %112
  %and3.i.i81 = trunc i64 %and3.i15.i to i8
  %cf.i.i82 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i82, align 1
  %114 = and i8 %and3.i.i81, 1
  %conv.i14.i = xor i8 %114, 1
  %pf.i.i83 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i83, align 1
  %115 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i84 = and i32 %115, 255
  %cmp.i.i.i85 = icmp eq i8 %and3.i.i81, 0
  %116 = trunc i64 %112 to i32
  %conv1.i.i.i86 = and i32 %116, 255
  %call.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i85, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #15
  %conv3.i.i88 = zext i1 %call.i.i.i87 to i8
  %zf.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i88, ptr %zf.i.i89, align 1
  %call4.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i86, i32 noundef 1, i32 noundef %conv.i.i.i84) #15
  %conv6.i.i91 = zext i1 %call4.i.i.i90 to i8
  %sf.i.i92 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i91, ptr %sf.i.i92, align 1
  %of.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i93, align 1
  %af.i.i94 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i94, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %117

117:                                              ; preds = %108
  %118 = load i64, ptr %NEXT_PC, align 8
  store i64 %118, ptr %PC, align 8
  %119 = add i64 %118, 6
  store i64 %119, ptr %NEXT_PC, align 8
  %120 = load i64, ptr %NEXT_PC, align 8
  %121 = add i64 %120, 5
  %122 = load i64, ptr %NEXT_PC, align 8
  %123 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %124 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %124, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %121, i64 %122
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %123, ptr %MEMORY, align 8
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = load ptr, ptr %MEMORY, align 8
  ret ptr %126
}

define ptr @BB_238a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11167
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11318
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_24bb(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10742
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10909
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_29cc(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RSP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 13, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 6
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 172
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i32 @__remill_read_memory_32(ptr noundef %6, i64 noundef %5) #15
  %conv.i.i = zext i32 %call.i.i1 to i64
  store i64 %conv.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 3
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RSP, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 1
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load ptr, ptr %MEMORY, align 8
  %rsp.i2 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %16 = load i64, ptr %rsp.i2, align 8
  %add.i.i3 = add i64 %16, 8
  store i64 %add.i.i3, ptr %rsp.i2, align 8
  %call.i.i4 = call i64 @__remill_read_memory_64(ptr noundef %15, i64 noundef %16) #15
  store i64 %call.i.i4, ptr %RBP, align 8
  store ptr %15, ptr %MEMORY, align 8
  br label %17

17:                                               ; preds = %12
  %18 = load i64, ptr %NEXT_PC, align 8
  store i64 %18, ptr %PC, align 8
  %19 = add i64 %18, 1
  store i64 %19, ptr %NEXT_PC, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %21 = load i64, ptr %rsp.i, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %20, i64 noundef %21) #15
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %call.i.i, ptr %rip.i, align 8
  store i64 %call.i.i, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %rsp.i, align 8
  %add.i.i = add i64 %22, 8
  store i64 %add.i.i, ptr %rsp.i, align 8
  store ptr %20, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

define ptr @BB_23c0(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 56
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i111 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i111, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i110 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i110, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 64
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i109 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #15
  store i64 %call.i.i109, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %23, i64 noundef %22) #15
  store i64 %call.i.i108, ptr %RDX, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RCX, align 8
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i114 = call i32 @__remill_read_memory_32(ptr noundef %28, i64 noundef %27) #15
  %conv.i.i115 = sext i32 %call.i.i114 to i64
  store i64 %conv.i.i115, ptr %RSI, align 8
  store ptr %28, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %24
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 4
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %RDX, align 8
  %33 = load i64, ptr %RSI, align 8
  %34 = mul i64 %33, 8
  %35 = add i64 %32, %34
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %36, i64 noundef %35) #15
  store i64 %call.i.i107, ptr %RDX, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %29
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 3
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load i64, ptr %RDX, align 8
  %41 = load ptr, ptr %MEMORY, align 8
  %call.i.i112 = call zeroext i8 @__remill_read_memory_8(ptr noundef %41, i64 noundef %40) #15
  %conv.i.i113 = sext i8 %call.i.i112 to i64
  %conv.i10.i = and i64 %conv.i.i113, 4294967295
  store i64 %conv.i10.i, ptr %RDX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %37
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 2
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RCX, align 8
  %46 = load ptr, ptr %MEMORY, align 8
  %call.i.i102 = call i32 @__remill_read_memory_32(ptr noundef %46, i64 noundef %45) #15
  %conv.i.i103 = zext i32 %call.i.i102 to i64
  store i64 %conv.i.i103, ptr %RCX, align 8
  store ptr %46, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %42
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load i64, ptr %RCX, align 8
  %51 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %50 to i32
  %sub.i.i = sub i32 %conv.i.i1, 1
  %conv.i22.i2 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i2, ptr %RCX, align 8
  %cmp.i.i.i3 = icmp ult i32 %conv.i.i1, 1
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i3, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv.i23.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %sub.i.i to i8
  %52 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %53 = and i8 %52, 1
  %conv.i.i.i8 = xor i8 %53, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 1, %conv.i.i1
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %sub.i.i
  %54 = trunc i32 %xor1.i.i.i.i11 to i8
  %55 = lshr i8 %54, 4
  %conv2.i.i.i12 = and i8 %55, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %conv.i.i1, 1
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %xor.i28.i.i.i22 = lshr i32 %xor.i.i.i.i10, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i1
  %xor3.i.i.i.i23 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i24 = add nuw nsw i32 %xor3.i.i.i.i23, %xor.i28.i.i.i22
  %cmp.i29.i.i.i25 = icmp eq i32 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %51, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %47
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 3
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i32, ptr %ECX, align 4
  %60 = zext i32 %59 to i64
  %61 = load ptr, ptr %MEMORY, align 8
  %sext.i116 = shl i64 %60, 32
  %conv.i12.i117 = ashr exact i64 %sext.i116, 32
  store i64 %conv.i12.i117, ptr %RCX, align 8
  store ptr %61, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %56
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 3
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %RAX, align 8
  %66 = load i64, ptr %RCX, align 8
  %67 = mul i64 %66, 4
  %68 = add i64 %65, %67
  %69 = load i32, ptr %EDX, align 4
  %70 = zext i32 %69 to i64
  %71 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_32(ptr noundef %71, i64 noundef %68, i32 noundef %69) #15
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %72

72:                                               ; preds = %62
  %73 = load i64, ptr %NEXT_PC, align 8
  store i64 %73, ptr %PC, align 8
  %74 = add i64 %73, 7
  store i64 %74, ptr %NEXT_PC, align 8
  %75 = load i64, ptr %NEXT_PC, align 8
  %76 = add i64 %75, 11381
  %77 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %77, i64 noundef %76) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %77, ptr %MEMORY, align 8
  br label %78

78:                                               ; preds = %72
  %79 = load i64, ptr %NEXT_PC, align 8
  store i64 %79, ptr %PC, align 8
  %80 = add i64 %79, 4
  store i64 %80, ptr %NEXT_PC, align 8
  %81 = load i64, ptr %RAX, align 8
  %82 = load ptr, ptr %MEMORY, align 8
  store i64 %81, ptr %RAX, align 8
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %81, i64 noundef 0, i64 noundef %81) #15
  %conv.i.i30 = zext i1 %call.i.i.i29 to i8
  %cf.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i30, ptr %cf.i.i31, align 1
  %conv.i.i.i.i32 = trunc i64 %81 to i8
  %83 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i32)
  %84 = and i8 %83, 1
  %conv.i.i.i33 = xor i8 %84, 1
  %pf.i.i.i34 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i33, ptr %pf.i.i.i34, align 1
  %af.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i35, align 1
  %cmp.i.i.i.i36 = icmp eq i64 %81, 0
  %call.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i36, i64 noundef %81, i64 noundef 0, i64 noundef %81) #15
  %conv5.i.i.i38 = zext i1 %call.i.i.i.i37 to i8
  %zf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i38, ptr %zf.i.i.i39, align 1
  %cmp.i27.i.i.i40 = icmp slt i64 %81, 0
  %call1.i.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i40, i64 noundef %81, i64 noundef 0, i64 noundef %81) #15
  %conv8.i.i.i42 = zext i1 %call1.i.i.i.i41 to i8
  %sf.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i42, ptr %sf.i.i.i43, align 1
  %xor.i28.i.i.i44 = lshr i64 %81, 63
  %call.i30.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %81, i64 noundef 0, i64 noundef %81) #15
  %conv11.i.i.i46 = zext i1 %call.i30.i.i.i45 to i8
  %of.i.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i46, ptr %of.i.i.i47, align 1
  store ptr %82, ptr %MEMORY, align 8
  br label %85

85:                                               ; preds = %78
  %86 = load i64, ptr %NEXT_PC, align 8
  store i64 %86, ptr %PC, align 8
  %87 = add i64 %86, 4
  store i64 %87, ptr %NEXT_PC, align 8
  %88 = load i64, ptr %RBP, align 8
  %89 = sub i64 %88, 104
  %90 = load i64, ptr %RAX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_64(ptr noundef %91, i64 noundef %89, i64 noundef %90) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %92

92:                                               ; preds = %85
  %93 = load i64, ptr %NEXT_PC, align 8
  store i64 %93, ptr %PC, align 8
  %94 = add i64 %93, 7
  store i64 %94, ptr %NEXT_PC, align 8
  %95 = load i64, ptr %NEXT_PC, align 8
  %96 = add i64 %95, 11086
  %97 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %97, i64 noundef %96) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %97, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %92
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 2
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %RAX, align 8
  %102 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call i32 @__remill_read_memory_32(ptr noundef %102, i64 noundef %101) #15
  %conv.i.i101 = zext i32 %call.i.i100 to i64
  store i64 %conv.i.i101, ptr %RDX, align 8
  store ptr %102, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %98
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 7
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  %107 = add i64 %106, 11237
  %108 = load ptr, ptr %MEMORY, align 8
  %call.i.i104 = call i64 @__remill_read_memory_64(ptr noundef %108, i64 noundef %107) #15
  store i64 %call.i.i104, ptr %RAX, align 8
  store ptr %108, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %103
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 3
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i64, ptr %RAX, align 8
  %113 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %113, i64 noundef %112) #15
  %sub.i.i48 = sub i32 %call.i.i, 10
  %cmp.i.i.i49 = icmp ult i32 %call.i.i, 10
  %call.i.i.i50 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i49, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv.i9.i = zext i1 %call.i.i.i50 to i8
  %cf.i.i51 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i51, align 1
  %conv.i.i.i.i52 = trunc i32 %sub.i.i48 to i8
  %114 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i52)
  %115 = and i8 %114, 1
  %conv.i.i.i53 = xor i8 %115, 1
  %pf.i.i.i54 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i53, ptr %pf.i.i.i54, align 1
  %xor.i.i.i.i55 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i56 = xor i32 %xor.i.i.i.i55, %sub.i.i48
  %116 = trunc i32 %xor1.i.i.i.i56 to i8
  %117 = lshr i8 %116, 4
  %conv2.i.i.i57 = and i8 %117, 1
  %af.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i57, ptr %af.i.i.i58, align 1
  %cmp.i.i.i.i59 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i59, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv5.i.i.i61 = zext i1 %call.i.i.i.i60 to i8
  %zf.i.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i61, ptr %zf.i.i.i62, align 1
  %cmp.i27.i.i.i63 = icmp slt i32 %sub.i.i48, 0
  %call1.i.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i63, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv8.i.i.i65 = zext i1 %call1.i.i.i.i64 to i8
  %sf.i.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i65, ptr %sf.i.i.i66, align 1
  %xor.i28.i.i.i67 = lshr i32 %xor.i.i.i.i55, 31
  %shr9.i.i.i.i68 = xor i32 %sub.i.i48, %call.i.i
  %xor3.i.i.i.i69 = lshr i32 %shr9.i.i.i.i68, 31
  %add.i.i.i.i70 = add nuw nsw i32 %xor3.i.i.i.i69, %xor.i28.i.i.i67
  %cmp.i29.i.i.i71 = icmp eq i32 %add.i.i.i.i70, 2
  %call.i30.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i71, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv11.i.i.i73 = zext i1 %call.i30.i.i.i72 to i8
  %of.i.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i73, ptr %of.i.i.i74, align 1
  store ptr %113, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 3
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %122 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %122, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %123 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %123, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %121, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %118
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i32, ptr %EDX, align 4
  %128 = zext i32 %127 to i64
  %129 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %128, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %129, ptr %MEMORY, align 8
  br label %130

130:                                              ; preds = %124
  %131 = load i64, ptr %NEXT_PC, align 8
  store i64 %131, ptr %PC, align 8
  %132 = add i64 %131, 3
  store i64 %132, ptr %NEXT_PC, align 8
  %133 = load i64, ptr %RCX, align 8
  %134 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %133 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %135 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %135, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %136 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %137 = and i8 %136, 1
  %conv.i.i.i = xor i8 %137, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %138 = trunc i32 %xor1.i.i.i.i to i8
  %139 = lshr i8 %138, 4
  %conv2.i.i.i = and i8 %139, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %134, ptr %MEMORY, align 8
  br label %140

140:                                              ; preds = %130
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = add i64 %141, 3
  store i64 %142, ptr %NEXT_PC, align 8
  %143 = load i64, ptr %RCX, align 8
  %144 = load i32, ptr %EDX, align 4
  %145 = zext i32 %144 to i64
  %146 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %143 to i32
  %sext.i = shl i64 %143, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %145, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %147 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i94 = icmp ult i64 %147, -4294967296
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i93, i32 noundef %144, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i95 to i8
  %cf.i.i96 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i96, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %146, ptr %MEMORY, align 8
  br label %148

148:                                              ; preds = %140
  %149 = load i64, ptr %NEXT_PC, align 8
  store i64 %149, ptr %PC, align 8
  %150 = add i64 %149, 3
  store i64 %150, ptr %NEXT_PC, align 8
  %151 = load i64, ptr %RCX, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %conv.i.i118 = trunc i64 %151 to i32
  %and3.i.i = and i32 1, %conv.i.i118
  %conv.i22.i119 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i119, ptr %RCX, align 8
  %cf.i.i120 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i120, align 1
  %conv.i.i.i121 = trunc i32 %and3.i.i to i8
  %153 = and i8 %conv.i.i.i121, 1
  %conv.i23.i122 = xor i8 %153, 1
  %pf.i.i123 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i122, ptr %pf.i.i123, align 1
  %cmp.i.i.i124 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv.i.i118, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i125 to i8
  %zf.i.i126 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i126, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i118, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i127 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i127, align 1
  %of.i.i128 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i128, align 1
  %af.i.i129 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i129, align 1
  store ptr %152, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %148
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load i32, ptr %ECX, align 4
  %158 = zext i32 %157 to i64
  %159 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %157, i32 noundef 0, i32 noundef %157) #15
  %conv.i12.i = zext i1 %call.i.i.i75 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %157 to i8
  %160 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %161 = and i8 %160, 1
  %conv.i.i.i78 = xor i8 %161, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %af.i.i.i80 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i80, align 1
  %cmp.i.i.i.i81 = icmp eq i32 %157, 0
  %call.i.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i81, i32 noundef %157, i32 noundef 0, i32 noundef %157) #15
  %conv5.i.i.i83 = zext i1 %call.i.i.i.i82 to i8
  %zf.i.i.i84 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i83, ptr %zf.i.i.i84, align 1
  %cmp.i27.i.i.i85 = icmp slt i32 %157, 0
  %call1.i.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i85, i32 noundef %157, i32 noundef 0, i32 noundef %157) #15
  %conv8.i.i.i87 = zext i1 %call1.i.i.i.i86 to i8
  %sf.i.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i87, ptr %sf.i.i.i88, align 1
  %xor.i28.i.i.i89 = lshr i32 %157, 31
  %call.i30.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %157, i32 noundef 0, i32 noundef %157) #15
  %conv11.i.i.i91 = zext i1 %call.i30.i.i.i90 to i8
  %of.i.i.i92 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i91, ptr %of.i.i.i92, align 1
  store ptr %159, ptr %MEMORY, align 8
  br label %162

162:                                              ; preds = %154
  %163 = load i64, ptr %NEXT_PC, align 8
  store i64 %163, ptr %PC, align 8
  %164 = add i64 %163, 3
  store i64 %164, ptr %NEXT_PC, align 8
  %165 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %166 = load i8, ptr %zf.i, align 1
  store i8 %166, ptr %CL, align 1
  store ptr %165, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %162
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 2
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i8, ptr %AL, align 1
  %171 = zext i8 %170 to i64
  %172 = load i8, ptr %CL, align 1
  %173 = zext i8 %172 to i64
  %174 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %173, %171
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i130 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i130, align 1
  %175 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %176 = and i8 %175, 1
  %conv.i27.i = xor i8 %176, 1
  %pf.i.i131 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i131, align 1
  %177 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i132 = and i32 %177, 255
  %cmp.i.i.i133 = icmp eq i8 %or3.i.i, 0
  %178 = trunc i64 %171 to i32
  %conv1.i.i.i = and i32 %178, 255
  %179 = trunc i64 %173 to i32
  %conv2.i.i.i134 = and i32 %179, 255
  %call.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i133, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i134, i32 noundef %conv.i.i.i132) #15
  %conv3.i.i136 = zext i1 %call.i.i.i135 to i8
  %zf.i.i137 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i136, ptr %zf.i.i137, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i134, i32 noundef %conv.i.i.i132) #15
  %conv6.i.i138 = zext i1 %call4.i.i.i to i8
  %sf.i.i139 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i138, ptr %sf.i.i139, align 1
  %of.i.i140 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i140, align 1
  %af.i.i141 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i141, align 1
  store ptr %174, ptr %MEMORY, align 8
  br label %180

180:                                              ; preds = %167
  %181 = load i64, ptr %NEXT_PC, align 8
  store i64 %181, ptr %PC, align 8
  %182 = add i64 %181, 2
  store i64 %182, ptr %NEXT_PC, align 8
  %183 = load i8, ptr %AL, align 1
  %184 = zext i8 %183 to i64
  %185 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %184
  %and3.i.i142 = trunc i64 %and3.i15.i to i8
  %cf.i.i143 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i143, align 1
  %186 = and i8 %and3.i.i142, 1
  %conv.i14.i = xor i8 %186, 1
  %pf.i.i144 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i144, align 1
  %187 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i145 = and i32 %187, 255
  %cmp.i.i.i146 = icmp eq i8 %and3.i.i142, 0
  %188 = trunc i64 %184 to i32
  %conv1.i.i.i147 = and i32 %188, 255
  %call.i.i.i148 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i146, i32 noundef %conv1.i.i.i147, i32 noundef 1, i32 noundef %conv.i.i.i145) #15
  %conv3.i.i149 = zext i1 %call.i.i.i148 to i8
  %zf.i.i150 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i149, ptr %zf.i.i150, align 1
  %call4.i.i.i151 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i147, i32 noundef 1, i32 noundef %conv.i.i.i145) #15
  %conv6.i.i152 = zext i1 %call4.i.i.i151 to i8
  %sf.i.i153 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i152, ptr %sf.i.i153, align 1
  %of.i.i154 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i154, align 1
  %af.i.i155 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i155, align 1
  store ptr %185, ptr %MEMORY, align 8
  br label %189

189:                                              ; preds = %180
  %190 = load i64, ptr %NEXT_PC, align 8
  store i64 %190, ptr %PC, align 8
  %191 = add i64 %190, 6
  store i64 %191, ptr %NEXT_PC, align 8
  %192 = load i64, ptr %NEXT_PC, align 8
  %193 = add i64 %192, 5
  %194 = load i64, ptr %NEXT_PC, align 8
  %195 = load ptr, ptr %MEMORY, align 8
  %zf.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %196 = load i8, ptr %zf.i97, align 1
  %tobool.not.i = icmp eq i8 %196, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %193, i64 %194
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %195, ptr %MEMORY, align 8
  %197 = load i64, ptr %NEXT_PC, align 8
  store i64 %197, ptr %PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  ret ptr %198
}

define ptr @BB_24f1(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i113 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i113, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 40
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i112 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i112, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 72
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i111 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #15
  store i64 %call.i.i111, ptr %RSI, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 4
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RBP, align 8
  %23 = sub i64 %22, 64
  %24 = load ptr, ptr %MEMORY, align 8
  %call.i.i110 = call i64 @__remill_read_memory_64(ptr noundef %24, i64 noundef %23) #15
  store i64 %call.i.i110, ptr %RDX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %19
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RDX, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %call.i.i109 = call i64 @__remill_read_memory_64(ptr noundef %29, i64 noundef %28) #15
  store i64 %call.i.i109, ptr %RDX, align 8
  store ptr %29, ptr %MEMORY, align 8
  br label %30

30:                                               ; preds = %25
  %31 = load i64, ptr %NEXT_PC, align 8
  store i64 %31, ptr %PC, align 8
  %32 = add i64 %31, 2
  store i64 %32, ptr %NEXT_PC, align 8
  %33 = load i64, ptr %RSI, align 8
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %34, i64 noundef %33) #15
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RSI, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %30
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 3
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RSI, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %38 to i32
  %sub.i.i = sub i32 %conv.i.i1, 1
  %conv.i22.i2 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i2, ptr %RSI, align 8
  %cmp.i.i.i3 = icmp ult i32 %conv.i.i1, 1
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i3, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv.i23.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %sub.i.i to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %41 = and i8 %40, 1
  %conv.i.i.i8 = xor i8 %41, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 1, %conv.i.i1
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %sub.i.i
  %42 = trunc i32 %xor1.i.i.i.i11 to i8
  %43 = lshr i8 %42, 4
  %conv2.i.i.i12 = and i8 %43, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %conv.i.i1, 1
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %xor.i28.i.i.i22 = lshr i32 %xor.i.i.i.i10, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i1
  %xor3.i.i.i.i23 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i24 = add nuw nsw i32 %xor3.i.i.i.i23, %xor.i28.i.i.i22
  %cmp.i29.i.i.i25 = icmp eq i32 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %44

44:                                               ; preds = %35
  %45 = load i64, ptr %NEXT_PC, align 8
  store i64 %45, ptr %PC, align 8
  %46 = add i64 %45, 3
  store i64 %46, ptr %NEXT_PC, align 8
  %47 = load i32, ptr %ESI, align 4
  %48 = zext i32 %47 to i64
  %49 = load ptr, ptr %MEMORY, align 8
  %sext.i116 = shl i64 %48, 32
  %conv.i12.i117 = ashr exact i64 %sext.i116, 32
  store i64 %conv.i12.i117, ptr %RSI, align 8
  store ptr %49, ptr %MEMORY, align 8
  br label %50

50:                                               ; preds = %44
  %51 = load i64, ptr %NEXT_PC, align 8
  store i64 %51, ptr %PC, align 8
  %52 = add i64 %51, 4
  store i64 %52, ptr %NEXT_PC, align 8
  %53 = load i64, ptr %RDX, align 8
  %54 = load i64, ptr %RSI, align 8
  %55 = mul i64 %54, 8
  %56 = add i64 %53, %55
  %57 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %57, i64 noundef %56) #15
  store i64 %call.i.i108, ptr %RDX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %50
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load i64, ptr %RDX, align 8
  %62 = load ptr, ptr %MEMORY, align 8
  %call.i.i114 = call zeroext i8 @__remill_read_memory_8(ptr noundef %62, i64 noundef %61) #15
  %conv.i.i115 = sext i8 %call.i.i114 to i64
  %conv.i10.i = and i64 %conv.i.i115, 4294967295
  store i64 %conv.i10.i, ptr %RDX, align 8
  store ptr %62, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %58
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 2
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i64, ptr %RCX, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %69, i64 noundef %66, i32 noundef %67) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %63
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 6
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RAX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %call.i.i98 = call ptr @__remill_write_memory_32(ptr noundef %74, i64 noundef %73, i32 noundef 0) #15
  store ptr %call.i.i98, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %70
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 7
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load i64, ptr %NEXT_PC, align 8
  %79 = add i64 %78, 11078
  %80 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %80, i64 noundef %79) #15
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %80, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 4
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i64, ptr %RAX, align 8
  %85 = load ptr, ptr %MEMORY, align 8
  store i64 %84, ptr %RAX, align 8
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %84, i64 noundef 0, i64 noundef %84) #15
  %conv.i.i30 = zext i1 %call.i.i.i29 to i8
  %cf.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i30, ptr %cf.i.i31, align 1
  %conv.i.i.i.i32 = trunc i64 %84 to i8
  %86 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i32)
  %87 = and i8 %86, 1
  %conv.i.i.i33 = xor i8 %87, 1
  %pf.i.i.i34 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i33, ptr %pf.i.i.i34, align 1
  %af.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i35, align 1
  %cmp.i.i.i.i36 = icmp eq i64 %84, 0
  %call.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i36, i64 noundef %84, i64 noundef 0, i64 noundef %84) #15
  %conv5.i.i.i38 = zext i1 %call.i.i.i.i37 to i8
  %zf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i38, ptr %zf.i.i.i39, align 1
  %cmp.i27.i.i.i40 = icmp slt i64 %84, 0
  %call1.i.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i40, i64 noundef %84, i64 noundef 0, i64 noundef %84) #15
  %conv8.i.i.i42 = zext i1 %call1.i.i.i.i41 to i8
  %sf.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i42, ptr %sf.i.i.i43, align 1
  %xor.i28.i.i.i44 = lshr i64 %84, 63
  %call.i30.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %84, i64 noundef 0, i64 noundef %84) #15
  %conv11.i.i.i46 = zext i1 %call.i30.i.i.i45 to i8
  %of.i.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i46, ptr %of.i.i.i47, align 1
  store ptr %85, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %81
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 4
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RBP, align 8
  %92 = sub i64 %91, 120
  %93 = load i64, ptr %RAX, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %94, i64 noundef %92, i64 noundef %93) #15
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %95

95:                                               ; preds = %88
  %96 = load i64, ptr %NEXT_PC, align 8
  store i64 %96, ptr %PC, align 8
  %97 = add i64 %96, 7
  store i64 %97, ptr %NEXT_PC, align 8
  %98 = load i64, ptr %NEXT_PC, align 8
  %99 = add i64 %98, 10623
  %100 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %100, i64 noundef %99) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %100, ptr %MEMORY, align 8
  br label %101

101:                                              ; preds = %95
  %102 = load i64, ptr %NEXT_PC, align 8
  store i64 %102, ptr %PC, align 8
  %103 = add i64 %102, 2
  store i64 %103, ptr %NEXT_PC, align 8
  %104 = load i64, ptr %RAX, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %105, i64 noundef %104) #15
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %105, ptr %MEMORY, align 8
  br label %106

106:                                              ; preds = %101
  %107 = load i64, ptr %NEXT_PC, align 8
  store i64 %107, ptr %PC, align 8
  %108 = add i64 %107, 7
  store i64 %108, ptr %NEXT_PC, align 8
  %109 = load i64, ptr %NEXT_PC, align 8
  %110 = add i64 %109, 10790
  %111 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %111, i64 noundef %110) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %111, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %106
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %RAX, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %116, i64 noundef %115) #15
  %sub.i.i48 = sub i32 %call.i.i, 10
  %cmp.i.i.i49 = icmp ult i32 %call.i.i, 10
  %call.i.i.i50 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i49, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv.i9.i = zext i1 %call.i.i.i50 to i8
  %cf.i.i51 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i51, align 1
  %conv.i.i.i.i52 = trunc i32 %sub.i.i48 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i52)
  %118 = and i8 %117, 1
  %conv.i.i.i53 = xor i8 %118, 1
  %pf.i.i.i54 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i53, ptr %pf.i.i.i54, align 1
  %xor.i.i.i.i55 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i56 = xor i32 %xor.i.i.i.i55, %sub.i.i48
  %119 = trunc i32 %xor1.i.i.i.i56 to i8
  %120 = lshr i8 %119, 4
  %conv2.i.i.i57 = and i8 %120, 1
  %af.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i57, ptr %af.i.i.i58, align 1
  %cmp.i.i.i.i59 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i59, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv5.i.i.i61 = zext i1 %call.i.i.i.i60 to i8
  %zf.i.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i61, ptr %zf.i.i.i62, align 1
  %cmp.i27.i.i.i63 = icmp slt i32 %sub.i.i48, 0
  %call1.i.i.i.i64 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i63, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv8.i.i.i65 = zext i1 %call1.i.i.i.i64 to i8
  %sf.i.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i65, ptr %sf.i.i.i66, align 1
  %xor.i28.i.i.i67 = lshr i32 %xor.i.i.i.i55, 31
  %shr9.i.i.i.i68 = xor i32 %sub.i.i48, %call.i.i
  %xor3.i.i.i.i69 = lshr i32 %shr9.i.i.i.i68, 31
  %add.i.i.i.i70 = add nuw nsw i32 %xor3.i.i.i.i69, %xor.i28.i.i.i67
  %cmp.i29.i.i.i71 = icmp eq i32 %add.i.i.i.i70, 2
  %call.i30.i.i.i72 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i71, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i48) #15
  %conv11.i.i.i73 = zext i1 %call.i30.i.i.i72 to i8
  %of.i.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i73, ptr %of.i.i.i74, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %112
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 3
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %125 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %125, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %126 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %126, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %124, ptr %MEMORY, align 8
  br label %127

127:                                              ; preds = %121
  %128 = load i64, ptr %NEXT_PC, align 8
  store i64 %128, ptr %PC, align 8
  %129 = add i64 %128, 2
  store i64 %129, ptr %NEXT_PC, align 8
  %130 = load i32, ptr %EDX, align 4
  %131 = zext i32 %130 to i64
  %132 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %131, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %132, ptr %MEMORY, align 8
  br label %133

133:                                              ; preds = %127
  %134 = load i64, ptr %NEXT_PC, align 8
  store i64 %134, ptr %PC, align 8
  %135 = add i64 %134, 3
  store i64 %135, ptr %NEXT_PC, align 8
  %136 = load i64, ptr %RCX, align 8
  %137 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %136 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %138 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %138, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %139 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %140 = and i8 %139, 1
  %conv.i.i.i = xor i8 %140, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %141 = trunc i32 %xor1.i.i.i.i to i8
  %142 = lshr i8 %141, 4
  %conv2.i.i.i = and i8 %142, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %137, ptr %MEMORY, align 8
  br label %143

143:                                              ; preds = %133
  %144 = load i64, ptr %NEXT_PC, align 8
  store i64 %144, ptr %PC, align 8
  %145 = add i64 %144, 3
  store i64 %145, ptr %NEXT_PC, align 8
  %146 = load i64, ptr %RCX, align 8
  %147 = load i32, ptr %EDX, align 4
  %148 = zext i32 %147 to i64
  %149 = load ptr, ptr %MEMORY, align 8
  %conv.i.i93 = trunc i64 %146 to i32
  %sext.i = shl i64 %146, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %148, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %150 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i94 = icmp ult i64 %150, -4294967296
  %call.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i94, i32 noundef %conv.i.i93, i32 noundef %147, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i95 to i8
  %cf.i.i96 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i96, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %151

151:                                              ; preds = %143
  %152 = load i64, ptr %NEXT_PC, align 8
  store i64 %152, ptr %PC, align 8
  %153 = add i64 %152, 3
  store i64 %153, ptr %NEXT_PC, align 8
  %154 = load i64, ptr %RCX, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  %conv.i.i118 = trunc i64 %154 to i32
  %and3.i.i = and i32 1, %conv.i.i118
  %conv.i22.i119 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i119, ptr %RCX, align 8
  %cf.i.i120 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i120, align 1
  %conv.i.i.i121 = trunc i32 %and3.i.i to i8
  %156 = and i8 %conv.i.i.i121, 1
  %conv.i23.i122 = xor i8 %156, 1
  %pf.i.i123 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i122, ptr %pf.i.i123, align 1
  %cmp.i.i.i124 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv.i.i118, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i125 to i8
  %zf.i.i126 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i126, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i118, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i127 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i127, align 1
  %of.i.i128 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i128, align 1
  %af.i.i129 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i129, align 1
  store ptr %155, ptr %MEMORY, align 8
  br label %157

157:                                              ; preds = %151
  %158 = load i64, ptr %NEXT_PC, align 8
  store i64 %158, ptr %PC, align 8
  %159 = add i64 %158, 3
  store i64 %159, ptr %NEXT_PC, align 8
  %160 = load i32, ptr %ECX, align 4
  %161 = zext i32 %160 to i64
  %162 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i75 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %160, i32 noundef 0, i32 noundef %160) #15
  %conv.i12.i = zext i1 %call.i.i.i75 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %160 to i8
  %163 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %164 = and i8 %163, 1
  %conv.i.i.i78 = xor i8 %164, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %af.i.i.i80 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i80, align 1
  %cmp.i.i.i.i81 = icmp eq i32 %160, 0
  %call.i.i.i.i82 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i81, i32 noundef %160, i32 noundef 0, i32 noundef %160) #15
  %conv5.i.i.i83 = zext i1 %call.i.i.i.i82 to i8
  %zf.i.i.i84 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i83, ptr %zf.i.i.i84, align 1
  %cmp.i27.i.i.i85 = icmp slt i32 %160, 0
  %call1.i.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i85, i32 noundef %160, i32 noundef 0, i32 noundef %160) #15
  %conv8.i.i.i87 = zext i1 %call1.i.i.i.i86 to i8
  %sf.i.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i87, ptr %sf.i.i.i88, align 1
  %xor.i28.i.i.i89 = lshr i32 %160, 31
  %call.i30.i.i.i90 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %160, i32 noundef 0, i32 noundef %160) #15
  %conv11.i.i.i91 = zext i1 %call.i30.i.i.i90 to i8
  %of.i.i.i92 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i91, ptr %of.i.i.i92, align 1
  store ptr %162, ptr %MEMORY, align 8
  br label %165

165:                                              ; preds = %157
  %166 = load i64, ptr %NEXT_PC, align 8
  store i64 %166, ptr %PC, align 8
  %167 = add i64 %166, 3
  store i64 %167, ptr %NEXT_PC, align 8
  %168 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %169 = load i8, ptr %zf.i, align 1
  store i8 %169, ptr %CL, align 1
  store ptr %168, ptr %MEMORY, align 8
  br label %170

170:                                              ; preds = %165
  %171 = load i64, ptr %NEXT_PC, align 8
  store i64 %171, ptr %PC, align 8
  %172 = add i64 %171, 2
  store i64 %172, ptr %NEXT_PC, align 8
  %173 = load i8, ptr %AL, align 1
  %174 = zext i8 %173 to i64
  %175 = load i8, ptr %CL, align 1
  %176 = zext i8 %175 to i64
  %177 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %176, %174
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i130 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i130, align 1
  %178 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %179 = and i8 %178, 1
  %conv.i27.i = xor i8 %179, 1
  %pf.i.i131 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i131, align 1
  %180 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i132 = and i32 %180, 255
  %cmp.i.i.i133 = icmp eq i8 %or3.i.i, 0
  %181 = trunc i64 %174 to i32
  %conv1.i.i.i = and i32 %181, 255
  %182 = trunc i64 %176 to i32
  %conv2.i.i.i134 = and i32 %182, 255
  %call.i.i.i135 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i133, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i134, i32 noundef %conv.i.i.i132) #15
  %conv3.i.i136 = zext i1 %call.i.i.i135 to i8
  %zf.i.i137 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i136, ptr %zf.i.i137, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i134, i32 noundef %conv.i.i.i132) #15
  %conv6.i.i138 = zext i1 %call4.i.i.i to i8
  %sf.i.i139 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i138, ptr %sf.i.i139, align 1
  %of.i.i140 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i140, align 1
  %af.i.i141 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i141, align 1
  store ptr %177, ptr %MEMORY, align 8
  br label %183

183:                                              ; preds = %170
  %184 = load i64, ptr %NEXT_PC, align 8
  store i64 %184, ptr %PC, align 8
  %185 = add i64 %184, 2
  store i64 %185, ptr %NEXT_PC, align 8
  %186 = load i8, ptr %AL, align 1
  %187 = zext i8 %186 to i64
  %188 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %187
  %and3.i.i142 = trunc i64 %and3.i15.i to i8
  %cf.i.i143 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i143, align 1
  %189 = and i8 %and3.i.i142, 1
  %conv.i14.i = xor i8 %189, 1
  %pf.i.i144 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i144, align 1
  %190 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i145 = and i32 %190, 255
  %cmp.i.i.i146 = icmp eq i8 %and3.i.i142, 0
  %191 = trunc i64 %187 to i32
  %conv1.i.i.i147 = and i32 %191, 255
  %call.i.i.i148 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i146, i32 noundef %conv1.i.i.i147, i32 noundef 1, i32 noundef %conv.i.i.i145) #15
  %conv3.i.i149 = zext i1 %call.i.i.i148 to i8
  %zf.i.i150 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i149, ptr %zf.i.i150, align 1
  %call4.i.i.i151 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i147, i32 noundef 1, i32 noundef %conv.i.i.i145) #15
  %conv6.i.i152 = zext i1 %call4.i.i.i151 to i8
  %sf.i.i153 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i152, ptr %sf.i.i153, align 1
  %of.i.i154 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i154, align 1
  %af.i.i155 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i155, align 1
  store ptr %188, ptr %MEMORY, align 8
  br label %192

192:                                              ; preds = %183
  %193 = load i64, ptr %NEXT_PC, align 8
  store i64 %193, ptr %PC, align 8
  %194 = add i64 %193, 6
  store i64 %194, ptr %NEXT_PC, align 8
  %195 = load i64, ptr %NEXT_PC, align 8
  %196 = add i64 %195, 5
  %197 = load i64, ptr %NEXT_PC, align 8
  %198 = load ptr, ptr %MEMORY, align 8
  %zf.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %199 = load i8, ptr %zf.i97, align 1
  %tobool.not.i = icmp eq i8 %199, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %196, i64 %197
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %198, ptr %MEMORY, align 8
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = load ptr, ptr %MEMORY, align 8
  ret ptr %201
}

define ptr @BB_2429(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 104
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2560(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 120
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_242f(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 11018
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 11169
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2566(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10587
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10754
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2465(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 11217
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #15
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 4
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 112
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #15
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 10826
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #15
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 11009
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_259c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 72
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i189 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i189, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 48
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i188 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i188, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 2
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RCX, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i183 = call i32 @__remill_read_memory_32(ptr noundef %17, i64 noundef %16) #15
  %conv.i.i184 = zext i32 %call.i.i183 to i64
  store i64 %conv.i.i184, ptr %RDX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %13
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i181 = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %conv.i.i182 = zext i32 %call.i.i181 to i64
  store i64 %conv.i.i182, ptr %RSI, align 8
  store ptr %22, ptr %MEMORY, align 8
  br label %23

23:                                               ; preds = %18
  %24 = load i64, ptr %NEXT_PC, align 8
  store i64 %24, ptr %PC, align 8
  %25 = add i64 %24, 3
  store i64 %25, ptr %NEXT_PC, align 8
  %26 = load i64, ptr %RSI, align 8
  %27 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %26 to i32
  %sub.i.i = sub i32 %conv.i.i1, 2
  %conv.i22.i2 = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i2, ptr %RSI, align 8
  %cmp.i.i.i3 = icmp ult i32 %conv.i.i1, 2
  %call.i.i.i4 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i3, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #15
  %conv.i23.i5 = zext i1 %call.i.i.i4 to i8
  %cf.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i5, ptr %cf.i.i6, align 1
  %conv.i.i.i.i7 = trunc i32 %sub.i.i to i8
  %28 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i7)
  %29 = and i8 %28, 1
  %conv.i.i.i8 = xor i8 %29, 1
  %pf.i.i.i9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i8, ptr %pf.i.i.i9, align 1
  %xor.i.i.i.i10 = xor i32 2, %conv.i.i1
  %xor1.i.i.i.i11 = xor i32 %xor.i.i.i.i10, %sub.i.i
  %30 = trunc i32 %xor1.i.i.i.i11 to i8
  %31 = lshr i8 %30, 4
  %conv2.i.i.i12 = and i8 %31, 1
  %af.i.i.i13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i12, ptr %af.i.i.i13, align 1
  %cmp.i.i.i.i14 = icmp eq i32 %conv.i.i1, 2
  %call.i.i.i.i15 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i14, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #15
  %conv5.i.i.i16 = zext i1 %call.i.i.i.i15 to i8
  %zf.i.i.i17 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i16, ptr %zf.i.i.i17, align 1
  %cmp.i27.i.i.i18 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i19 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i18, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #15
  %conv8.i.i.i20 = zext i1 %call1.i.i.i.i19 to i8
  %sf.i.i.i21 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i20, ptr %sf.i.i.i21, align 1
  %xor.i28.i.i.i22 = lshr i32 %xor.i.i.i.i10, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i1
  %xor3.i.i.i.i23 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i24 = add nuw nsw i32 %xor3.i.i.i.i23, %xor.i28.i.i.i22
  %cmp.i29.i.i.i25 = icmp eq i32 %add.i.i.i.i24, 2
  %call.i30.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i25, i32 noundef %conv.i.i1, i32 noundef 2, i32 noundef %sub.i.i) #15
  %conv11.i.i.i27 = zext i1 %call.i30.i.i.i26 to i8
  %of.i.i.i28 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i27, ptr %of.i.i.i28, align 1
  store ptr %27, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %23
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 5
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load ptr, ptr %MEMORY, align 8
  store i64 9, ptr %RCX, align 8
  store ptr %35, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %32
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 5
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 8, ptr %RAX, align 8
  store ptr %39, ptr %MEMORY, align 8
  br label %40

40:                                               ; preds = %36
  %41 = load i64, ptr %NEXT_PC, align 8
  store i64 %41, ptr %PC, align 8
  %42 = add i64 %41, 2
  store i64 %42, ptr %NEXT_PC, align 8
  %43 = load i32, ptr %EDX, align 4
  %44 = zext i32 %43 to i64
  %45 = load i32, ptr %ESI, align 4
  %46 = zext i32 %45 to i64
  %47 = load ptr, ptr %MEMORY, align 8
  %sub.i.i130 = sub i32 %43, %45
  %cmp.i.i.i131 = icmp ult i32 %43, %45
  %call.i.i.i132 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i131, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv.i12.i133 = zext i1 %call.i.i.i132 to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i133, ptr %cf.i.i134, align 1
  %conv.i.i.i.i135 = trunc i32 %sub.i.i130 to i8
  %48 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i135)
  %49 = and i8 %48, 1
  %conv.i.i.i136 = xor i8 %49, 1
  %pf.i.i.i137 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i136, ptr %pf.i.i.i137, align 1
  %xor.i.i.i.i138 = xor i32 %45, %43
  %xor1.i.i.i.i139 = xor i32 %xor.i.i.i.i138, %sub.i.i130
  %50 = trunc i32 %xor1.i.i.i.i139 to i8
  %51 = lshr i8 %50, 4
  %conv2.i.i.i140 = and i8 %51, 1
  %af.i.i.i141 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i140, ptr %af.i.i.i141, align 1
  %cmp.i.i.i.i142 = icmp eq i32 %43, %45
  %call.i.i.i.i143 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i142, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv5.i.i.i144 = zext i1 %call.i.i.i.i143 to i8
  %zf.i.i.i145 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i144, ptr %zf.i.i.i145, align 1
  %cmp.i27.i.i.i146 = icmp slt i32 %sub.i.i130, 0
  %call1.i.i.i.i147 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i146, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv8.i.i.i148 = zext i1 %call1.i.i.i.i147 to i8
  %sf.i.i.i149 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i148, ptr %sf.i.i.i149, align 1
  %xor.i28.i.i.i150 = lshr i32 %xor.i.i.i.i138, 31
  %shr9.i.i.i.i151 = xor i32 %sub.i.i130, %43
  %xor3.i.i.i.i152 = lshr i32 %shr9.i.i.i.i151, 31
  %add.i.i.i.i153 = add nuw nsw i32 %xor3.i.i.i.i152, %xor.i28.i.i.i150
  %cmp.i29.i.i.i154 = icmp eq i32 %add.i.i.i.i153, 2
  %call.i30.i.i.i155 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i154, i32 noundef %43, i32 noundef %45, i32 noundef %sub.i.i130) #15
  %conv11.i.i.i156 = zext i1 %call.i30.i.i.i155 to i8
  %of.i.i.i157 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i156, ptr %of.i.i.i157, align 1
  store ptr %47, ptr %MEMORY, align 8
  br label %52

52:                                               ; preds = %40
  %53 = load i64, ptr %NEXT_PC, align 8
  store i64 %53, ptr %PC, align 8
  %54 = add i64 %53, 3
  store i64 %54, ptr %NEXT_PC, align 8
  %55 = load i32, ptr %EAX, align 4
  %56 = zext i32 %55 to i64
  %57 = load ptr, ptr %MEMORY, align 8
  %zf.i162 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %58 = load i8, ptr %zf.i162, align 1
  %tobool.i163 = icmp ne i8 %58, 0
  %sf.i164 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %59 = load i8, ptr %sf.i164, align 1
  %tobool4.i = icmp ne i8 %59, 0
  %of.i165 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %60 = load i8, ptr %of.i165, align 1
  %tobool6.i = icmp ne i8 %60, 0
  %cmp.i.i166 = xor i1 %tobool4.i, %tobool6.i
  %61 = or i1 %tobool.i163, %cmp.i.i166
  %call8.i = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %61) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call8.i, i64 %56, i64 %dst.coerce.val.i
  %conv.i27.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i27.i, ptr %RCX, align 8
  store ptr %57, ptr %MEMORY, align 8
  br label %62

62:                                               ; preds = %52
  %63 = load i64, ptr %NEXT_PC, align 8
  store i64 %63, ptr %PC, align 8
  %64 = add i64 %63, 7
  store i64 %64, ptr %NEXT_PC, align 8
  %65 = load i64, ptr %NEXT_PC, align 8
  %66 = add i64 %65, 10863
  %67 = load ptr, ptr %MEMORY, align 8
  store i64 %66, ptr %RAX, align 8
  store ptr %67, ptr %MEMORY, align 8
  br label %68

68:                                               ; preds = %62
  %69 = load i64, ptr %NEXT_PC, align 8
  store i64 %69, ptr %PC, align 8
  %70 = add i64 %69, 3
  store i64 %70, ptr %NEXT_PC, align 8
  %71 = load i32, ptr %ECX, align 4
  %72 = zext i32 %71 to i64
  %73 = load ptr, ptr %MEMORY, align 8
  %sext.i190 = shl i64 %72, 32
  %conv.i12.i191 = ashr exact i64 %sext.i190, 32
  store i64 %conv.i12.i191, ptr %RCX, align 8
  store ptr %73, ptr %MEMORY, align 8
  br label %74

74:                                               ; preds = %68
  %75 = load i64, ptr %NEXT_PC, align 8
  store i64 %75, ptr %PC, align 8
  %76 = add i64 %75, 4
  store i64 %76, ptr %NEXT_PC, align 8
  %77 = load i64, ptr %RAX, align 8
  %78 = load i64, ptr %RCX, align 8
  %79 = mul i64 %78, 8
  %80 = add i64 %77, %79
  %81 = load ptr, ptr %MEMORY, align 8
  %call.i.i187 = call i64 @__remill_read_memory_64(ptr noundef %81, i64 noundef %80) #15
  store i64 %call.i.i187, ptr %RAX, align 8
  store ptr %81, ptr %MEMORY, align 8
  br label %82

82:                                               ; preds = %74
  %83 = load i64, ptr %NEXT_PC, align 8
  store i64 %83, ptr %PC, align 8
  %84 = add i64 %83, 2
  store i64 %84, ptr %NEXT_PC, align 8
  %85 = load i64, ptr %RCX, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %conv.i.i217 = trunc i64 %85 to i32
  %xor3.i.i = xor i32 %86, %conv.i.i217
  %conv.i27.i218 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i218, ptr %RCX, align 8
  %cf.i.i219 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i219, align 1
  %conv.i.i.i220 = trunc i32 %xor3.i.i to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i220)
  %90 = and i8 %89, 1
  %conv.i28.i221 = xor i8 %90, 1
  %pf.i.i222 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i221, ptr %pf.i.i222, align 1
  %cmp.i.i.i223 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i224 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i223, i32 noundef %conv.i.i217, i32 noundef %86, i32 noundef %xor3.i.i) #15
  %conv3.i.i225 = zext i1 %call.i.i.i224 to i8
  %zf.i.i226 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i225, ptr %zf.i.i226, align 1
  %cmp.i19.i.i227 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i228 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i227, i32 noundef %conv.i.i217, i32 noundef %86, i32 noundef %xor3.i.i) #15
  %conv6.i.i229 = zext i1 %call1.i.i.i228 to i8
  %sf.i.i230 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i229, ptr %sf.i.i230, align 1
  %of.i.i231 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i231, align 1
  %af.i.i232 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i233 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i233, ptr %af.i.i232, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %82
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 2
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load i32, ptr %EDX, align 4
  %95 = zext i32 %94 to i64
  %96 = load i32, ptr %ESI, align 4
  %97 = zext i32 %96 to i64
  %98 = load ptr, ptr %MEMORY, align 8
  %sub.i.i102 = sub i32 %94, %96
  %cmp.i.i.i103 = icmp ult i32 %94, %96
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i103, i32 noundef %94, i32 noundef %96, i32 noundef %sub.i.i102) #15
  %conv.i12.i105 = zext i1 %call.i.i.i104 to i8
  %cf.i.i106 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i105, ptr %cf.i.i106, align 1
  %conv.i.i.i.i107 = trunc i32 %sub.i.i102 to i8
  %99 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i107)
  %100 = and i8 %99, 1
  %conv.i.i.i108 = xor i8 %100, 1
  %pf.i.i.i109 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i108, ptr %pf.i.i.i109, align 1
  %xor.i.i.i.i110 = xor i32 %96, %94
  %xor1.i.i.i.i111 = xor i32 %xor.i.i.i.i110, %sub.i.i102
  %101 = trunc i32 %xor1.i.i.i.i111 to i8
  %102 = lshr i8 %101, 4
  %conv2.i.i.i112 = and i8 %102, 1
  %af.i.i.i113 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i112, ptr %af.i.i.i113, align 1
  %cmp.i.i.i.i114 = icmp eq i32 %94, %96
  %call.i.i.i.i115 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i114, i32 noundef %94, i32 noundef %96, i32 noundef %sub.i.i102) #15
  %conv5.i.i.i116 = zext i1 %call.i.i.i.i115 to i8
  %zf.i.i.i117 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i116, ptr %zf.i.i.i117, align 1
  %cmp.i27.i.i.i118 = icmp slt i32 %sub.i.i102, 0
  %call1.i.i.i.i119 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i118, i32 noundef %94, i32 noundef %96, i32 noundef %sub.i.i102) #15
  %conv8.i.i.i120 = zext i1 %call1.i.i.i.i119 to i8
  %sf.i.i.i121 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i120, ptr %sf.i.i.i121, align 1
  %xor.i28.i.i.i122 = lshr i32 %xor.i.i.i.i110, 31
  %shr9.i.i.i.i123 = xor i32 %sub.i.i102, %94
  %xor3.i.i.i.i124 = lshr i32 %shr9.i.i.i.i123, 31
  %add.i.i.i.i125 = add nuw nsw i32 %xor3.i.i.i.i124, %xor.i28.i.i.i122
  %cmp.i29.i.i.i126 = icmp eq i32 %add.i.i.i.i125, 2
  %call.i30.i.i.i127 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i126, i32 noundef %94, i32 noundef %96, i32 noundef %sub.i.i102) #15
  %conv11.i.i.i128 = zext i1 %call.i30.i.i.i127 to i8
  %of.i.i.i129 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i128, ptr %of.i.i.i129, align 1
  store ptr %98, ptr %MEMORY, align 8
  br label %103

103:                                              ; preds = %91
  %104 = load i64, ptr %NEXT_PC, align 8
  store i64 %104, ptr %PC, align 8
  %105 = add i64 %104, 4
  store i64 %105, ptr %NEXT_PC, align 8
  %106 = load i64, ptr %RCX, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  %zf.i167 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %108 = load i8, ptr %zf.i167, align 1
  %tobool.i168 = icmp ne i8 %108, 0
  %sf.i169 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %109 = load i8, ptr %sf.i169, align 1
  %tobool4.i170 = icmp ne i8 %109, 0
  %of.i171 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %110 = load i8, ptr %of.i171, align 1
  %tobool6.i172 = icmp ne i8 %110, 0
  %cmp.i.i173 = xor i1 %tobool4.i170, %tobool6.i172
  %111 = or i1 %tobool.i168, %cmp.i.i173
  %call8.i174 = call zeroext i1 @__remill_compare_sle(i1 noundef zeroext %111) #16
  %dst.coerce.val.i175 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call8.i174, i64 %106, i64 %dst.coerce.val.i175
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %107, ptr %MEMORY, align 8
  br label %112

112:                                              ; preds = %103
  %113 = load i64, ptr %NEXT_PC, align 8
  store i64 %113, ptr %PC, align 8
  %114 = add i64 %113, 3
  store i64 %114, ptr %NEXT_PC, align 8
  %115 = load i64, ptr %RAX, align 8
  %116 = load i64, ptr %RCX, align 8
  %117 = load ptr, ptr %MEMORY, align 8
  %sub.i.i29 = sub i64 %115, %116
  store i64 %sub.i.i29, ptr %RAX, align 8
  %cmp.i.i.i30 = icmp ult i64 %115, %116
  %call.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i30, i64 noundef %115, i64 noundef %116, i64 noundef %sub.i.i29) #15
  %conv.i.i32 = zext i1 %call.i.i.i31 to i8
  %cf.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i32, ptr %cf.i.i33, align 1
  %conv.i.i.i.i34 = trunc i64 %sub.i.i29 to i8
  %118 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i34)
  %119 = and i8 %118, 1
  %conv.i.i.i35 = xor i8 %119, 1
  %pf.i.i.i36 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i35, ptr %pf.i.i.i36, align 1
  %xor.i.i.i.i37 = xor i64 %116, %115
  %xor1.i.i.i.i38 = xor i64 %xor.i.i.i.i37, %sub.i.i29
  %120 = trunc i64 %xor1.i.i.i.i38 to i8
  %121 = lshr i8 %120, 4
  %conv2.i.i.i39 = and i8 %121, 1
  %af.i.i.i40 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i39, ptr %af.i.i.i40, align 1
  %cmp.i.i.i.i41 = icmp eq i64 %115, %116
  %call.i.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i41, i64 noundef %115, i64 noundef %116, i64 noundef %sub.i.i29) #15
  %conv5.i.i.i43 = zext i1 %call.i.i.i.i42 to i8
  %zf.i.i.i44 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i43, ptr %zf.i.i.i44, align 1
  %cmp.i27.i.i.i45 = icmp slt i64 %sub.i.i29, 0
  %call1.i.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i45, i64 noundef %115, i64 noundef %116, i64 noundef %sub.i.i29) #15
  %conv8.i.i.i47 = zext i1 %call1.i.i.i.i46 to i8
  %sf.i.i.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i47, ptr %sf.i.i.i48, align 1
  %xor.i28.i.i.i49 = lshr i64 %xor.i.i.i.i37, 63
  %shr9.i.i.i.i50 = xor i64 %sub.i.i29, %115
  %xor3.i.i.i.i51 = lshr i64 %shr9.i.i.i.i50, 63
  %add.i.i.i.i52 = add nuw nsw i64 %xor3.i.i.i.i51, %xor.i28.i.i.i49
  %cmp.i29.i.i.i53 = icmp eq i64 %add.i.i.i.i52, 2
  %call.i30.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i53, i64 noundef %115, i64 noundef %116, i64 noundef %sub.i.i29) #15
  %conv11.i.i.i55 = zext i1 %call.i30.i.i.i54 to i8
  %of.i.i.i56 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i55, ptr %of.i.i.i56, align 1
  store ptr %117, ptr %MEMORY, align 8
  br label %122

122:                                              ; preds = %112
  %123 = load i64, ptr %NEXT_PC, align 8
  store i64 %123, ptr %PC, align 8
  %124 = add i64 %123, 4
  store i64 %124, ptr %NEXT_PC, align 8
  %125 = load i64, ptr %RBP, align 8
  %126 = sub i64 %125, 128
  %127 = load i64, ptr %RAX, align 8
  %128 = load ptr, ptr %MEMORY, align 8
  %call.i.i178 = call ptr @__remill_write_memory_64(ptr noundef %128, i64 noundef %126, i64 noundef %127) #15
  store ptr %call.i.i178, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %122
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 7
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %NEXT_PC, align 8
  %133 = add i64 %132, 10466
  %134 = load ptr, ptr %MEMORY, align 8
  %call.i.i186 = call i64 @__remill_read_memory_64(ptr noundef %134, i64 noundef %133) #15
  store i64 %call.i.i186, ptr %RAX, align 8
  store ptr %134, ptr %MEMORY, align 8
  br label %135

135:                                              ; preds = %129
  %136 = load i64, ptr %NEXT_PC, align 8
  store i64 %136, ptr %PC, align 8
  %137 = add i64 %136, 2
  store i64 %137, ptr %NEXT_PC, align 8
  %138 = load i64, ptr %RAX, align 8
  %139 = load ptr, ptr %MEMORY, align 8
  %call.i.i179 = call i32 @__remill_read_memory_32(ptr noundef %139, i64 noundef %138) #15
  %conv.i.i180 = zext i32 %call.i.i179 to i64
  store i64 %conv.i.i180, ptr %RDX, align 8
  store ptr %139, ptr %MEMORY, align 8
  br label %140

140:                                              ; preds = %135
  %141 = load i64, ptr %NEXT_PC, align 8
  store i64 %141, ptr %PC, align 8
  %142 = add i64 %141, 7
  store i64 %142, ptr %NEXT_PC, align 8
  %143 = load i64, ptr %NEXT_PC, align 8
  %144 = add i64 %143, 10633
  %145 = load ptr, ptr %MEMORY, align 8
  %call.i.i185 = call i64 @__remill_read_memory_64(ptr noundef %145, i64 noundef %144) #15
  store i64 %call.i.i185, ptr %RAX, align 8
  store ptr %145, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %140
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 3
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %RAX, align 8
  %150 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %150, i64 noundef %149) #15
  %sub.i.i57 = sub i32 %call.i.i, 10
  %cmp.i.i.i58 = icmp ult i32 %call.i.i, 10
  %call.i.i.i59 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i58, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv.i9.i = zext i1 %call.i.i.i59 to i8
  %cf.i.i60 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i60, align 1
  %conv.i.i.i.i61 = trunc i32 %sub.i.i57 to i8
  %151 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i61)
  %152 = and i8 %151, 1
  %conv.i.i.i62 = xor i8 %152, 1
  %pf.i.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i62, ptr %pf.i.i.i63, align 1
  %xor.i.i.i.i64 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i65 = xor i32 %xor.i.i.i.i64, %sub.i.i57
  %153 = trunc i32 %xor1.i.i.i.i65 to i8
  %154 = lshr i8 %153, 4
  %conv2.i.i.i66 = and i8 %154, 1
  %af.i.i.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i66, ptr %af.i.i.i67, align 1
  %cmp.i.i.i.i68 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i68, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv5.i.i.i70 = zext i1 %call.i.i.i.i69 to i8
  %zf.i.i.i71 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i70, ptr %zf.i.i.i71, align 1
  %cmp.i27.i.i.i72 = icmp slt i32 %sub.i.i57, 0
  %call1.i.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv8.i.i.i74 = zext i1 %call1.i.i.i.i73 to i8
  %sf.i.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i74, ptr %sf.i.i.i75, align 1
  %xor.i28.i.i.i76 = lshr i32 %xor.i.i.i.i64, 31
  %shr9.i.i.i.i77 = xor i32 %sub.i.i57, %call.i.i
  %xor3.i.i.i.i78 = lshr i32 %shr9.i.i.i.i77, 31
  %add.i.i.i.i79 = add nuw nsw i32 %xor3.i.i.i.i78, %xor.i28.i.i.i76
  %cmp.i29.i.i.i80 = icmp eq i32 %add.i.i.i.i79, 2
  %call.i30.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i80, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i57) #15
  %conv11.i.i.i82 = zext i1 %call.i30.i.i.i81 to i8
  %of.i.i.i83 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i82, ptr %of.i.i.i83, align 1
  store ptr %150, ptr %MEMORY, align 8
  br label %155

155:                                              ; preds = %146
  %156 = load i64, ptr %NEXT_PC, align 8
  store i64 %156, ptr %PC, align 8
  %157 = add i64 %156, 3
  store i64 %157, ptr %NEXT_PC, align 8
  %158 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %159 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %159, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %160 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %160, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %158, ptr %MEMORY, align 8
  br label %161

161:                                              ; preds = %155
  %162 = load i64, ptr %NEXT_PC, align 8
  store i64 %162, ptr %PC, align 8
  %163 = add i64 %162, 2
  store i64 %163, ptr %NEXT_PC, align 8
  %164 = load i32, ptr %EDX, align 4
  %165 = zext i32 %164 to i64
  %166 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %165, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %166, ptr %MEMORY, align 8
  br label %167

167:                                              ; preds = %161
  %168 = load i64, ptr %NEXT_PC, align 8
  store i64 %168, ptr %PC, align 8
  %169 = add i64 %168, 3
  store i64 %169, ptr %NEXT_PC, align 8
  %170 = load i64, ptr %RCX, align 8
  %171 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %170 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %172 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %172, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %173 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %174 = and i8 %173, 1
  %conv.i.i.i = xor i8 %174, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %175 = trunc i32 %xor1.i.i.i.i to i8
  %176 = lshr i8 %175, 4
  %conv2.i.i.i = and i8 %176, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %171, ptr %MEMORY, align 8
  br label %177

177:                                              ; preds = %167
  %178 = load i64, ptr %NEXT_PC, align 8
  store i64 %178, ptr %PC, align 8
  %179 = add i64 %178, 3
  store i64 %179, ptr %NEXT_PC, align 8
  %180 = load i64, ptr %RCX, align 8
  %181 = load i32, ptr %EDX, align 4
  %182 = zext i32 %181 to i64
  %183 = load ptr, ptr %MEMORY, align 8
  %conv.i.i158 = trunc i64 %180 to i32
  %sext.i = shl i64 %180, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %182, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %184 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i159 = icmp ult i64 %184, -4294967296
  %call.i.i.i160 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i159, i32 noundef %conv.i.i158, i32 noundef %181, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i160 to i8
  %cf.i.i161 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i161, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %183, ptr %MEMORY, align 8
  br label %185

185:                                              ; preds = %177
  %186 = load i64, ptr %NEXT_PC, align 8
  store i64 %186, ptr %PC, align 8
  %187 = add i64 %186, 3
  store i64 %187, ptr %NEXT_PC, align 8
  %188 = load i64, ptr %RCX, align 8
  %189 = load ptr, ptr %MEMORY, align 8
  %conv.i.i192 = trunc i64 %188 to i32
  %and3.i.i = and i32 1, %conv.i.i192
  %conv.i22.i193 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i193, ptr %RCX, align 8
  %cf.i.i194 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i194, align 1
  %conv.i.i.i195 = trunc i32 %and3.i.i to i8
  %190 = and i8 %conv.i.i.i195, 1
  %conv.i23.i196 = xor i8 %190, 1
  %pf.i.i197 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i196, ptr %pf.i.i197, align 1
  %cmp.i.i.i198 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i199 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i198, i32 noundef %conv.i.i192, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i199 to i8
  %zf.i.i200 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i200, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i192, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i201 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i201, align 1
  %of.i.i202 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i202, align 1
  %af.i.i203 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i203, align 1
  store ptr %189, ptr %MEMORY, align 8
  br label %191

191:                                              ; preds = %185
  %192 = load i64, ptr %NEXT_PC, align 8
  store i64 %192, ptr %PC, align 8
  %193 = add i64 %192, 3
  store i64 %193, ptr %NEXT_PC, align 8
  %194 = load i32, ptr %ECX, align 4
  %195 = zext i32 %194 to i64
  %196 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i84 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %194, i32 noundef 0, i32 noundef %194) #15
  %conv.i12.i = zext i1 %call.i.i.i84 to i8
  %cf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i85, align 1
  %conv.i.i.i.i86 = trunc i32 %194 to i8
  %197 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i86)
  %198 = and i8 %197, 1
  %conv.i.i.i87 = xor i8 %198, 1
  %pf.i.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i87, ptr %pf.i.i.i88, align 1
  %af.i.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i89, align 1
  %cmp.i.i.i.i90 = icmp eq i32 %194, 0
  %call.i.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i90, i32 noundef %194, i32 noundef 0, i32 noundef %194) #15
  %conv5.i.i.i92 = zext i1 %call.i.i.i.i91 to i8
  %zf.i.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i92, ptr %zf.i.i.i93, align 1
  %cmp.i27.i.i.i94 = icmp slt i32 %194, 0
  %call1.i.i.i.i95 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i94, i32 noundef %194, i32 noundef 0, i32 noundef %194) #15
  %conv8.i.i.i96 = zext i1 %call1.i.i.i.i95 to i8
  %sf.i.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i96, ptr %sf.i.i.i97, align 1
  %xor.i28.i.i.i98 = lshr i32 %194, 31
  %call.i30.i.i.i99 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %194, i32 noundef 0, i32 noundef %194) #15
  %conv11.i.i.i100 = zext i1 %call.i30.i.i.i99 to i8
  %of.i.i.i101 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i100, ptr %of.i.i.i101, align 1
  store ptr %196, ptr %MEMORY, align 8
  br label %199

199:                                              ; preds = %191
  %200 = load i64, ptr %NEXT_PC, align 8
  store i64 %200, ptr %PC, align 8
  %201 = add i64 %200, 3
  store i64 %201, ptr %NEXT_PC, align 8
  %202 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %203 = load i8, ptr %zf.i, align 1
  store i8 %203, ptr %CL, align 1
  store ptr %202, ptr %MEMORY, align 8
  br label %204

204:                                              ; preds = %199
  %205 = load i64, ptr %NEXT_PC, align 8
  store i64 %205, ptr %PC, align 8
  %206 = add i64 %205, 2
  store i64 %206, ptr %NEXT_PC, align 8
  %207 = load i8, ptr %AL, align 1
  %208 = zext i8 %207 to i64
  %209 = load i8, ptr %CL, align 1
  %210 = zext i8 %209 to i64
  %211 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %210, %208
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i204 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i204, align 1
  %212 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %213 = and i8 %212, 1
  %conv.i27.i205 = xor i8 %213, 1
  %pf.i.i206 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i205, ptr %pf.i.i206, align 1
  %214 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i207 = and i32 %214, 255
  %cmp.i.i.i208 = icmp eq i8 %or3.i.i, 0
  %215 = trunc i64 %208 to i32
  %conv1.i.i.i = and i32 %215, 255
  %216 = trunc i64 %210 to i32
  %conv2.i.i.i209 = and i32 %216, 255
  %call.i.i.i210 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i208, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i209, i32 noundef %conv.i.i.i207) #15
  %conv3.i.i211 = zext i1 %call.i.i.i210 to i8
  %zf.i.i212 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i211, ptr %zf.i.i212, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i209, i32 noundef %conv.i.i.i207) #15
  %conv6.i.i213 = zext i1 %call4.i.i.i to i8
  %sf.i.i214 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i213, ptr %sf.i.i214, align 1
  %of.i.i215 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i215, align 1
  %af.i.i216 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i216, align 1
  store ptr %211, ptr %MEMORY, align 8
  br label %217

217:                                              ; preds = %204
  %218 = load i64, ptr %NEXT_PC, align 8
  store i64 %218, ptr %PC, align 8
  %219 = add i64 %218, 2
  store i64 %219, ptr %NEXT_PC, align 8
  %220 = load i8, ptr %AL, align 1
  %221 = zext i8 %220 to i64
  %222 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %221
  %and3.i.i234 = trunc i64 %and3.i15.i to i8
  %cf.i.i235 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i235, align 1
  %223 = and i8 %and3.i.i234, 1
  %conv.i14.i = xor i8 %223, 1
  %pf.i.i236 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i236, align 1
  %224 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i237 = and i32 %224, 255
  %cmp.i.i.i238 = icmp eq i8 %and3.i.i234, 0
  %225 = trunc i64 %221 to i32
  %conv1.i.i.i239 = and i32 %225, 255
  %call.i.i.i240 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i238, i32 noundef %conv1.i.i.i239, i32 noundef 1, i32 noundef %conv.i.i.i237) #15
  %conv3.i.i241 = zext i1 %call.i.i.i240 to i8
  %zf.i.i242 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i241, ptr %zf.i.i242, align 1
  %call4.i.i.i243 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i239, i32 noundef 1, i32 noundef %conv.i.i.i237) #15
  %conv6.i.i244 = zext i1 %call4.i.i.i243 to i8
  %sf.i.i245 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i244, ptr %sf.i.i245, align 1
  %of.i.i246 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i246, align 1
  %af.i.i247 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i247, align 1
  store ptr %222, ptr %MEMORY, align 8
  br label %226

226:                                              ; preds = %217
  %227 = load i64, ptr %NEXT_PC, align 8
  store i64 %227, ptr %PC, align 8
  %228 = add i64 %227, 6
  store i64 %228, ptr %NEXT_PC, align 8
  %229 = load i64, ptr %NEXT_PC, align 8
  %230 = add i64 %229, 5
  %231 = load i64, ptr %NEXT_PC, align 8
  %232 = load ptr, ptr %MEMORY, align 8
  %zf.i176 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %233 = load i8, ptr %zf.i176, align 1
  %tobool.not.i = icmp eq i8 %233, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i177 = select i1 %call9.i, i64 %230, i64 %231
  store i64 %cond1.i.i177, ptr %NEXT_PC, align 8
  store ptr %232, ptr %MEMORY, align 8
  %234 = load i64, ptr %NEXT_PC, align 8
  store i64 %234, ptr %PC, align 8
  %235 = load ptr, ptr %MEMORY, align 8
  ret ptr %235
}

define ptr @BB_24b5(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 112
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_260d(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 128
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2613(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10654
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10349
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2875(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i6 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i6, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i4 = zext i32 %call.i.i to i64
  store i64 %conv.i.i4, ptr %RAX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RAX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %15 to i32
  %sub.i.i = sub i32 %conv.i.i, 1
  %conv.i22.i = zext i32 %sub.i.i to i64
  store i64 %conv.i22.i, ptr %RAX, align 8
  %cmp.i.i.i = icmp ult i32 %conv.i.i, 1
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %sub.i.i to i8
  %17 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %18 = and i8 %17, 1
  %conv.i.i.i = xor i8 %18, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 1, %conv.i.i
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %sub.i.i
  %19 = trunc i32 %xor1.i.i.i.i to i8
  %20 = lshr i8 %19, 4
  %conv2.i.i.i = and i8 %20, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %conv.i.i, 1
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %xor.i28.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %conv.i.i
  %xor3.i.i.i.i = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor3.i.i.i.i, %xor.i28.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %sub.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %12
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 5
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  store i64 14, ptr %RAX, align 8
  store ptr %24, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %21
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 3
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RAX, align 8
  %29 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %28 to i32
  %cf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  %30 = load i8, ptr %cf.i, align 1
  %conv.i42.i = zext i8 %30 to i32
  %sub.i43.i = sub i32 %conv.i.i1, %conv.i42.i
  %conv.i44.i = zext i32 %sub.i43.i to i64
  store i64 %conv.i44.i, ptr %RAX, align 8
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %conv.i.i1) #15
  br i1 %call.i.i.i2, label %_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit, label %lor.rhs.i.i

lor.rhs.i.i:                                      ; preds = %25
  %cmp.i3.i.i = icmp ult i32 %conv.i.i1, %conv.i42.i
  %call.i4.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i3.i.i, i32 noundef %conv.i.i1, i32 noundef %conv.i42.i, i32 noundef %sub.i43.i) #15
  %31 = zext i1 %call.i4.i.i to i8
  br label %_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit

_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit: ; preds = %lor.rhs.i.i, %25
  %conv.i = phi i8 [ 1, %25 ], [ %31, %lor.rhs.i.i ]
  store i8 %conv.i, ptr %cf.i, align 1
  %conv.i.i.i3 = trunc i32 %sub.i43.i to i8
  %32 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i3)
  %33 = and i8 %32, 1
  %conv.i45.i = xor i8 %33, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i45.i, ptr %pf.i.i, align 1
  %xor1.i.i.i = xor i32 %sub.i43.i, %conv.i.i1
  %34 = trunc i32 %xor1.i.i.i to i8
  %35 = lshr i8 %34, 4
  %conv2.i.i = and i8 %35, 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i, ptr %af.i.i, align 1
  %cmp.i.i46.i = icmp eq i32 %conv.i.i1, %conv.i42.i
  %call.i.i47.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i46.i, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %sub.i43.i) #15
  %conv5.i.i = zext i1 %call.i.i47.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i, ptr %zf.i.i, align 1
  %cmp.i27.i.i = icmp slt i32 %sub.i43.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %sub.i43.i) #15
  %conv8.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i, ptr %sf.i.i, align 1
  %xor.i28.i.i = lshr i32 %conv.i.i1, 31
  %shr9.i.i.i = xor i32 %sub.i43.i, %conv.i.i1
  %xor3.i.i.i = lshr i32 %shr9.i.i.i, 31
  %add.i.i.i = add nuw nsw i32 %xor3.i.i.i, %xor.i28.i.i
  %cmp.i29.i.i = icmp eq i32 %add.i.i.i, 2
  %call.i30.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i, i32 noundef %conv.i.i1, i32 noundef 0, i32 noundef %sub.i43.i) #15
  %conv11.i.i = zext i1 %call.i30.i.i to i8
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i, ptr %of.i.i, align 1
  store ptr %29, ptr %MEMORY, align 8
  br label %36

36:                                               ; preds = %_ZN12_GLOBAL__N_13SBBI3RnWImE2RnIjLb1EE2InIjEEEP6MemoryS8_R5StateT_T0_T1_.exit
  %37 = load i64, ptr %NEXT_PC, align 8
  store i64 %37, ptr %PC, align 8
  %38 = add i64 %37, 2
  store i64 %38, ptr %NEXT_PC, align 8
  %39 = load i32, ptr %EAX, align 4
  %40 = zext i32 %39 to i64
  %41 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %40, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %41, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %36
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 7
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %NEXT_PC, align 8
  %46 = add i64 %45, 10145
  %47 = load ptr, ptr %MEMORY, align 8
  store i64 %46, ptr %RAX, align 8
  store ptr %47, ptr %MEMORY, align 8
  br label %48

48:                                               ; preds = %42
  %49 = load i64, ptr %NEXT_PC, align 8
  store i64 %49, ptr %PC, align 8
  %50 = add i64 %49, 4
  store i64 %50, ptr %NEXT_PC, align 8
  %51 = load i64, ptr %RAX, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = mul i64 %52, 8
  %54 = add i64 %51, %53
  %55 = load ptr, ptr %MEMORY, align 8
  %call.i.i5 = call i64 @__remill_read_memory_64(ptr noundef %55, i64 noundef %54) #15
  store i64 %call.i.i5, ptr %RAX, align 8
  store ptr %55, ptr %MEMORY, align 8
  br label %56

56:                                               ; preds = %48
  %57 = load i64, ptr %NEXT_PC, align 8
  store i64 %57, ptr %PC, align 8
  %58 = add i64 %57, 2
  store i64 %58, ptr %NEXT_PC, align 8
  %59 = load i64, ptr %RAX, align 8
  %60 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %59, ptr %rip.i, align 8
  store i64 %59, ptr %NEXT_PC, align 8
  store ptr %60, ptr %MEMORY, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  ret ptr %61
}

define ptr @BB_2649(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %ESI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RSI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 9, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 40
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i152 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i152, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RBP, align 8
  %11 = sub i64 %10, 56
  %12 = load ptr, ptr %MEMORY, align 8
  %call.i.i151 = call i64 @__remill_read_memory_64(ptr noundef %12, i64 noundef %11) #15
  store i64 %call.i.i151, ptr %RCX, align 8
  store ptr %12, ptr %MEMORY, align 8
  br label %13

13:                                               ; preds = %7
  %14 = load i64, ptr %NEXT_PC, align 8
  store i64 %14, ptr %PC, align 8
  %15 = add i64 %14, 4
  store i64 %15, ptr %NEXT_PC, align 8
  %16 = load i64, ptr %RBP, align 8
  %17 = sub i64 %16, 48
  %18 = load ptr, ptr %MEMORY, align 8
  %call.i.i150 = call i64 @__remill_read_memory_64(ptr noundef %18, i64 noundef %17) #15
  store i64 %call.i.i150, ptr %RDX, align 8
  store ptr %18, ptr %MEMORY, align 8
  br label %19

19:                                               ; preds = %13
  %20 = load i64, ptr %NEXT_PC, align 8
  store i64 %20, ptr %PC, align 8
  %21 = add i64 %20, 3
  store i64 %21, ptr %NEXT_PC, align 8
  %22 = load i64, ptr %RDX, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  %call.i.i153 = call i32 @__remill_read_memory_32(ptr noundef %23, i64 noundef %22) #15
  %conv.i.i154 = sext i32 %call.i.i153 to i64
  store i64 %conv.i.i154, ptr %RDX, align 8
  store ptr %23, ptr %MEMORY, align 8
  br label %24

24:                                               ; preds = %19
  %25 = load i64, ptr %NEXT_PC, align 8
  store i64 %25, ptr %PC, align 8
  %26 = add i64 %25, 3
  store i64 %26, ptr %NEXT_PC, align 8
  %27 = load i64, ptr %RCX, align 8
  %28 = load i64, ptr %RDX, align 8
  %29 = mul i64 %28, 4
  %30 = add i64 %27, %29
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i145 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #15
  %conv.i.i146 = zext i32 %call.i.i145 to i64
  store i64 %conv.i.i146, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %24
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 2
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %RAX, align 8
  %36 = load ptr, ptr %MEMORY, align 8
  %call.i.i143 = call i32 @__remill_read_memory_32(ptr noundef %36, i64 noundef %35) #15
  %conv.i.i144 = zext i32 %call.i.i143 to i64
  store i64 %conv.i.i144, ptr %RSI, align 8
  store ptr %36, ptr %MEMORY, align 8
  br label %37

37:                                               ; preds = %32
  %38 = load i64, ptr %NEXT_PC, align 8
  store i64 %38, ptr %PC, align 8
  %39 = add i64 %38, 5
  store i64 %39, ptr %NEXT_PC, align 8
  %40 = load ptr, ptr %MEMORY, align 8
  store i64 11, ptr %RCX, align 8
  store ptr %40, ptr %MEMORY, align 8
  br label %41

41:                                               ; preds = %37
  %42 = load i64, ptr %NEXT_PC, align 8
  store i64 %42, ptr %PC, align 8
  %43 = add i64 %42, 5
  store i64 %43, ptr %NEXT_PC, align 8
  %44 = load ptr, ptr %MEMORY, align 8
  store i64 10, ptr %RAX, align 8
  store ptr %44, ptr %MEMORY, align 8
  br label %45

45:                                               ; preds = %41
  %46 = load i64, ptr %NEXT_PC, align 8
  store i64 %46, ptr %PC, align 8
  %47 = add i64 %46, 2
  store i64 %47, ptr %NEXT_PC, align 8
  %48 = load i32, ptr %EDX, align 4
  %49 = zext i32 %48 to i64
  %50 = load i32, ptr %ESI, align 4
  %51 = zext i32 %50 to i64
  %52 = load ptr, ptr %MEMORY, align 8
  %sub.i.i100 = sub i32 %48, %50
  %cmp.i.i.i101 = icmp ult i32 %48, %50
  %call.i.i.i102 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i101, i32 noundef %48, i32 noundef %50, i32 noundef %sub.i.i100) #15
  %conv.i12.i103 = zext i1 %call.i.i.i102 to i8
  %cf.i.i104 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i103, ptr %cf.i.i104, align 1
  %conv.i.i.i.i105 = trunc i32 %sub.i.i100 to i8
  %53 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i105)
  %54 = and i8 %53, 1
  %conv.i.i.i106 = xor i8 %54, 1
  %pf.i.i.i107 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i106, ptr %pf.i.i.i107, align 1
  %xor.i.i.i.i108 = xor i32 %50, %48
  %xor1.i.i.i.i109 = xor i32 %xor.i.i.i.i108, %sub.i.i100
  %55 = trunc i32 %xor1.i.i.i.i109 to i8
  %56 = lshr i8 %55, 4
  %conv2.i.i.i110 = and i8 %56, 1
  %af.i.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i110, ptr %af.i.i.i111, align 1
  %cmp.i.i.i.i112 = icmp eq i32 %48, %50
  %call.i.i.i.i113 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i112, i32 noundef %48, i32 noundef %50, i32 noundef %sub.i.i100) #15
  %conv5.i.i.i114 = zext i1 %call.i.i.i.i113 to i8
  %zf.i.i.i115 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i114, ptr %zf.i.i.i115, align 1
  %cmp.i27.i.i.i116 = icmp slt i32 %sub.i.i100, 0
  %call1.i.i.i.i117 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i116, i32 noundef %48, i32 noundef %50, i32 noundef %sub.i.i100) #15
  %conv8.i.i.i118 = zext i1 %call1.i.i.i.i117 to i8
  %sf.i.i.i119 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i118, ptr %sf.i.i.i119, align 1
  %xor.i28.i.i.i120 = lshr i32 %xor.i.i.i.i108, 31
  %shr9.i.i.i.i121 = xor i32 %sub.i.i100, %48
  %xor3.i.i.i.i122 = lshr i32 %shr9.i.i.i.i121, 31
  %add.i.i.i.i123 = add nuw nsw i32 %xor3.i.i.i.i122, %xor.i28.i.i.i120
  %cmp.i29.i.i.i124 = icmp eq i32 %add.i.i.i.i123, 2
  %call.i30.i.i.i125 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i124, i32 noundef %48, i32 noundef %50, i32 noundef %sub.i.i100) #15
  %conv11.i.i.i126 = zext i1 %call.i30.i.i.i125 to i8
  %of.i.i.i127 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i126, ptr %of.i.i.i127, align 1
  store ptr %52, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %45
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i32, ptr %EAX, align 4
  %61 = zext i32 %60 to i64
  %62 = load ptr, ptr %MEMORY, align 8
  %zf.i132 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %63 = load i8, ptr %zf.i132, align 1
  %tobool.i133 = icmp ne i8 %63, 0
  %call.i = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i133) #16
  %dst.coerce.val.i = load i64, ptr %RCX, align 8
  %cond1.i.v.i = select i1 %call.i, i64 %61, i64 %dst.coerce.val.i
  %conv.i19.i = and i64 %cond1.i.v.i, 4294967295
  store i64 %conv.i19.i, ptr %RCX, align 8
  store ptr %62, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %57
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 7
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i64, ptr %NEXT_PC, align 8
  %68 = add i64 %67, 10685
  %69 = load ptr, ptr %MEMORY, align 8
  store i64 %68, ptr %RAX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i32, ptr %ECX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %sext.i155 = shl i64 %74, 32
  %conv.i12.i156 = ashr exact i64 %sext.i155, 32
  store i64 %conv.i12.i156, ptr %RCX, align 8
  store ptr %75, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %70
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 4
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i64, ptr %RAX, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = mul i64 %80, 8
  %82 = add i64 %79, %81
  %83 = load ptr, ptr %MEMORY, align 8
  %call.i.i149 = call i64 @__remill_read_memory_64(ptr noundef %83, i64 noundef %82) #15
  store i64 %call.i.i149, ptr %RAX, align 8
  store ptr %83, ptr %MEMORY, align 8
  br label %84

84:                                               ; preds = %76
  %85 = load i64, ptr %NEXT_PC, align 8
  store i64 %85, ptr %PC, align 8
  %86 = add i64 %85, 2
  store i64 %86, ptr %NEXT_PC, align 8
  %87 = load i64, ptr %RCX, align 8
  %88 = load i32, ptr %ECX, align 4
  %89 = zext i32 %88 to i64
  %90 = load ptr, ptr %MEMORY, align 8
  %conv.i.i181 = trunc i64 %87 to i32
  %xor3.i.i = xor i32 %88, %conv.i.i181
  %conv.i27.i182 = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i182, ptr %RCX, align 8
  %cf.i.i183 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i183, align 1
  %conv.i.i.i184 = trunc i32 %xor3.i.i to i8
  %91 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i184)
  %92 = and i8 %91, 1
  %conv.i28.i185 = xor i8 %92, 1
  %pf.i.i186 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i185, ptr %pf.i.i186, align 1
  %cmp.i.i.i187 = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i188 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i187, i32 noundef %conv.i.i181, i32 noundef %88, i32 noundef %xor3.i.i) #15
  %conv3.i.i189 = zext i1 %call.i.i.i188 to i8
  %zf.i.i190 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i189, ptr %zf.i.i190, align 1
  %cmp.i19.i.i191 = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i192 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i191, i32 noundef %conv.i.i181, i32 noundef %88, i32 noundef %xor3.i.i) #15
  %conv6.i.i193 = zext i1 %call1.i.i.i192 to i8
  %sf.i.i194 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i193, ptr %sf.i.i194, align 1
  %of.i.i195 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i195, align 1
  %af.i.i196 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i197 = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i197, ptr %af.i.i196, align 1
  store ptr %90, ptr %MEMORY, align 8
  br label %93

93:                                               ; preds = %84
  %94 = load i64, ptr %NEXT_PC, align 8
  store i64 %94, ptr %PC, align 8
  %95 = add i64 %94, 2
  store i64 %95, ptr %NEXT_PC, align 8
  %96 = load i32, ptr %EDX, align 4
  %97 = zext i32 %96 to i64
  %98 = load i32, ptr %ESI, align 4
  %99 = zext i32 %98 to i64
  %100 = load ptr, ptr %MEMORY, align 8
  %sub.i.i72 = sub i32 %96, %98
  %cmp.i.i.i73 = icmp ult i32 %96, %98
  %call.i.i.i74 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i73, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv.i12.i75 = zext i1 %call.i.i.i74 to i8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i75, ptr %cf.i.i76, align 1
  %conv.i.i.i.i77 = trunc i32 %sub.i.i72 to i8
  %101 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i77)
  %102 = and i8 %101, 1
  %conv.i.i.i78 = xor i8 %102, 1
  %pf.i.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i78, ptr %pf.i.i.i79, align 1
  %xor.i.i.i.i80 = xor i32 %98, %96
  %xor1.i.i.i.i81 = xor i32 %xor.i.i.i.i80, %sub.i.i72
  %103 = trunc i32 %xor1.i.i.i.i81 to i8
  %104 = lshr i8 %103, 4
  %conv2.i.i.i82 = and i8 %104, 1
  %af.i.i.i83 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i82, ptr %af.i.i.i83, align 1
  %cmp.i.i.i.i84 = icmp eq i32 %96, %98
  %call.i.i.i.i85 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i84, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv5.i.i.i86 = zext i1 %call.i.i.i.i85 to i8
  %zf.i.i.i87 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i86, ptr %zf.i.i.i87, align 1
  %cmp.i27.i.i.i88 = icmp slt i32 %sub.i.i72, 0
  %call1.i.i.i.i89 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i88, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv8.i.i.i90 = zext i1 %call1.i.i.i.i89 to i8
  %sf.i.i.i91 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i90, ptr %sf.i.i.i91, align 1
  %xor.i28.i.i.i92 = lshr i32 %xor.i.i.i.i80, 31
  %shr9.i.i.i.i93 = xor i32 %sub.i.i72, %96
  %xor3.i.i.i.i94 = lshr i32 %shr9.i.i.i.i93, 31
  %add.i.i.i.i95 = add nuw nsw i32 %xor3.i.i.i.i94, %xor.i28.i.i.i92
  %cmp.i29.i.i.i96 = icmp eq i32 %add.i.i.i.i95, 2
  %call.i30.i.i.i97 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i96, i32 noundef %96, i32 noundef %98, i32 noundef %sub.i.i72) #15
  %conv11.i.i.i98 = zext i1 %call.i30.i.i.i97 to i8
  %of.i.i.i99 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i98, ptr %of.i.i.i99, align 1
  store ptr %100, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %93
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 4
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %zf.i134 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %110 = load i8, ptr %zf.i134, align 1
  %tobool.i135 = icmp ne i8 %110, 0
  %call.i136 = call zeroext i1 @__remill_compare_eq(i1 noundef zeroext %tobool.i135) #16
  %dst.coerce.val.i137 = load i64, ptr %RCX, align 8
  %cond1.i.i = select i1 %call.i136, i64 %108, i64 %dst.coerce.val.i137
  store i64 %cond1.i.i, ptr %RCX, align 8
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i64, ptr %RAX, align 8
  %115 = load i64, ptr %RCX, align 8
  %116 = load ptr, ptr %MEMORY, align 8
  %sub.i.i = sub i64 %114, %115
  store i64 %sub.i.i, ptr %RAX, align 8
  %cmp.i.i.i1 = icmp ult i64 %114, %115
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i64 noundef %114, i64 noundef %115, i64 noundef %sub.i.i) #15
  %conv.i.i3 = zext i1 %call.i.i.i2 to i8
  %cf.i.i4 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i3, ptr %cf.i.i4, align 1
  %conv.i.i.i.i5 = trunc i64 %sub.i.i to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i5)
  %118 = and i8 %117, 1
  %conv.i.i.i6 = xor i8 %118, 1
  %pf.i.i.i7 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i6, ptr %pf.i.i.i7, align 1
  %xor.i.i.i.i8 = xor i64 %115, %114
  %xor1.i.i.i.i9 = xor i64 %xor.i.i.i.i8, %sub.i.i
  %119 = trunc i64 %xor1.i.i.i.i9 to i8
  %120 = lshr i8 %119, 4
  %conv2.i.i.i10 = and i8 %120, 1
  %af.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i10, ptr %af.i.i.i11, align 1
  %cmp.i.i.i.i12 = icmp eq i64 %114, %115
  %call.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i12, i64 noundef %114, i64 noundef %115, i64 noundef %sub.i.i) #15
  %conv5.i.i.i14 = zext i1 %call.i.i.i.i13 to i8
  %zf.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i14, ptr %zf.i.i.i15, align 1
  %cmp.i27.i.i.i16 = icmp slt i64 %sub.i.i, 0
  %call1.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i16, i64 noundef %114, i64 noundef %115, i64 noundef %sub.i.i) #15
  %conv8.i.i.i18 = zext i1 %call1.i.i.i.i17 to i8
  %sf.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i18, ptr %sf.i.i.i19, align 1
  %xor.i28.i.i.i20 = lshr i64 %xor.i.i.i.i8, 63
  %shr9.i.i.i.i = xor i64 %sub.i.i, %114
  %xor3.i.i.i.i21 = lshr i64 %shr9.i.i.i.i, 63
  %add.i.i.i.i22 = add nuw nsw i64 %xor3.i.i.i.i21, %xor.i28.i.i.i20
  %cmp.i29.i.i.i23 = icmp eq i64 %add.i.i.i.i22, 2
  %call.i30.i.i.i24 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i23, i64 noundef %114, i64 noundef %115, i64 noundef %sub.i.i) #15
  %conv11.i.i.i25 = zext i1 %call.i30.i.i.i24 to i8
  %of.i.i.i26 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i25, ptr %of.i.i.i26, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %121

121:                                              ; preds = %111
  %122 = load i64, ptr %NEXT_PC, align 8
  store i64 %122, ptr %PC, align 8
  %123 = add i64 %122, 7
  store i64 %123, ptr %NEXT_PC, align 8
  %124 = load i64, ptr %RBP, align 8
  %125 = sub i64 %124, 136
  %126 = load i64, ptr %RAX, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  %call.i.i140 = call ptr @__remill_write_memory_64(ptr noundef %127, i64 noundef %125, i64 noundef %126) #15
  store ptr %call.i.i140, ptr %MEMORY, align 8
  br label %128

128:                                              ; preds = %121
  %129 = load i64, ptr %NEXT_PC, align 8
  store i64 %129, ptr %PC, align 8
  %130 = add i64 %129, 7
  store i64 %130, ptr %NEXT_PC, align 8
  %131 = load i64, ptr %NEXT_PC, align 8
  %132 = add i64 %131, 10525
  %133 = load ptr, ptr %MEMORY, align 8
  %call.i.i148 = call i64 @__remill_read_memory_64(ptr noundef %133, i64 noundef %132) #15
  store i64 %call.i.i148, ptr %RAX, align 8
  store ptr %133, ptr %MEMORY, align 8
  br label %134

134:                                              ; preds = %128
  %135 = load i64, ptr %NEXT_PC, align 8
  store i64 %135, ptr %PC, align 8
  %136 = add i64 %135, 2
  store i64 %136, ptr %NEXT_PC, align 8
  %137 = load i64, ptr %RAX, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  %call.i.i141 = call i32 @__remill_read_memory_32(ptr noundef %138, i64 noundef %137) #15
  %conv.i.i142 = zext i32 %call.i.i141 to i64
  store i64 %conv.i.i142, ptr %RDX, align 8
  store ptr %138, ptr %MEMORY, align 8
  br label %139

139:                                              ; preds = %134
  %140 = load i64, ptr %NEXT_PC, align 8
  store i64 %140, ptr %PC, align 8
  %141 = add i64 %140, 7
  store i64 %141, ptr %NEXT_PC, align 8
  %142 = load i64, ptr %NEXT_PC, align 8
  %143 = add i64 %142, 10220
  %144 = load ptr, ptr %MEMORY, align 8
  %call.i.i147 = call i64 @__remill_read_memory_64(ptr noundef %144, i64 noundef %143) #15
  store i64 %call.i.i147, ptr %RAX, align 8
  store ptr %144, ptr %MEMORY, align 8
  br label %145

145:                                              ; preds = %139
  %146 = load i64, ptr %NEXT_PC, align 8
  store i64 %146, ptr %PC, align 8
  %147 = add i64 %146, 3
  store i64 %147, ptr %NEXT_PC, align 8
  %148 = load i64, ptr %RAX, align 8
  %149 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %149, i64 noundef %148) #15
  %sub.i.i27 = sub i32 %call.i.i, 10
  %cmp.i.i.i28 = icmp ult i32 %call.i.i, 10
  %call.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i28, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv.i9.i = zext i1 %call.i.i.i29 to i8
  %cf.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i30, align 1
  %conv.i.i.i.i31 = trunc i32 %sub.i.i27 to i8
  %150 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i31)
  %151 = and i8 %150, 1
  %conv.i.i.i32 = xor i8 %151, 1
  %pf.i.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i32, ptr %pf.i.i.i33, align 1
  %xor.i.i.i.i34 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i35 = xor i32 %xor.i.i.i.i34, %sub.i.i27
  %152 = trunc i32 %xor1.i.i.i.i35 to i8
  %153 = lshr i8 %152, 4
  %conv2.i.i.i36 = and i8 %153, 1
  %af.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i36, ptr %af.i.i.i37, align 1
  %cmp.i.i.i.i38 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i39 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i38, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv5.i.i.i40 = zext i1 %call.i.i.i.i39 to i8
  %zf.i.i.i41 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i40, ptr %zf.i.i.i41, align 1
  %cmp.i27.i.i.i42 = icmp slt i32 %sub.i.i27, 0
  %call1.i.i.i.i43 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i42, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv8.i.i.i44 = zext i1 %call1.i.i.i.i43 to i8
  %sf.i.i.i45 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i44, ptr %sf.i.i.i45, align 1
  %xor.i28.i.i.i46 = lshr i32 %xor.i.i.i.i34, 31
  %shr9.i.i.i.i47 = xor i32 %sub.i.i27, %call.i.i
  %xor3.i.i.i.i48 = lshr i32 %shr9.i.i.i.i47, 31
  %add.i.i.i.i49 = add nuw nsw i32 %xor3.i.i.i.i48, %xor.i28.i.i.i46
  %cmp.i29.i.i.i50 = icmp eq i32 %add.i.i.i.i49, 2
  %call.i30.i.i.i51 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i50, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i27) #15
  %conv11.i.i.i52 = zext i1 %call.i30.i.i.i51 to i8
  %of.i.i.i53 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i52, ptr %of.i.i.i53, align 1
  store ptr %149, ptr %MEMORY, align 8
  br label %154

154:                                              ; preds = %145
  %155 = load i64, ptr %NEXT_PC, align 8
  store i64 %155, ptr %PC, align 8
  %156 = add i64 %155, 3
  store i64 %156, ptr %NEXT_PC, align 8
  %157 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %158 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %158, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %159 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %159, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %157, ptr %MEMORY, align 8
  br label %160

160:                                              ; preds = %154
  %161 = load i64, ptr %NEXT_PC, align 8
  store i64 %161, ptr %PC, align 8
  %162 = add i64 %161, 2
  store i64 %162, ptr %NEXT_PC, align 8
  %163 = load i32, ptr %EDX, align 4
  %164 = zext i32 %163 to i64
  %165 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %164, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %165, ptr %MEMORY, align 8
  br label %166

166:                                              ; preds = %160
  %167 = load i64, ptr %NEXT_PC, align 8
  store i64 %167, ptr %PC, align 8
  %168 = add i64 %167, 3
  store i64 %168, ptr %NEXT_PC, align 8
  %169 = load i64, ptr %RCX, align 8
  %170 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %169 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %171 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %171, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %172 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %173 = and i8 %172, 1
  %conv.i.i.i = xor i8 %173, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %174 = trunc i32 %xor1.i.i.i.i to i8
  %175 = lshr i8 %174, 4
  %conv2.i.i.i = and i8 %175, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %170, ptr %MEMORY, align 8
  br label %176

176:                                              ; preds = %166
  %177 = load i64, ptr %NEXT_PC, align 8
  store i64 %177, ptr %PC, align 8
  %178 = add i64 %177, 3
  store i64 %178, ptr %NEXT_PC, align 8
  %179 = load i64, ptr %RCX, align 8
  %180 = load i32, ptr %EDX, align 4
  %181 = zext i32 %180 to i64
  %182 = load ptr, ptr %MEMORY, align 8
  %conv.i.i128 = trunc i64 %179 to i32
  %sext.i = shl i64 %179, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %181, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %183 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i129 = icmp ult i64 %183, -4294967296
  %call.i.i.i130 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i129, i32 noundef %conv.i.i128, i32 noundef %180, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i130 to i8
  %cf.i.i131 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i131, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %182, ptr %MEMORY, align 8
  br label %184

184:                                              ; preds = %176
  %185 = load i64, ptr %NEXT_PC, align 8
  store i64 %185, ptr %PC, align 8
  %186 = add i64 %185, 3
  store i64 %186, ptr %NEXT_PC, align 8
  %187 = load i64, ptr %RCX, align 8
  %188 = load ptr, ptr %MEMORY, align 8
  %conv.i.i157 = trunc i64 %187 to i32
  %and3.i.i = and i32 1, %conv.i.i157
  %conv.i22.i158 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i158, ptr %RCX, align 8
  %cf.i.i159 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i159, align 1
  %conv.i.i.i160 = trunc i32 %and3.i.i to i8
  %189 = and i8 %conv.i.i.i160, 1
  %conv.i23.i161 = xor i8 %189, 1
  %pf.i.i162 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i161, ptr %pf.i.i162, align 1
  %cmp.i.i.i163 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i164 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i163, i32 noundef %conv.i.i157, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i164 to i8
  %zf.i.i165 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i165, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i157, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i166 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i166, align 1
  %of.i.i167 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i167, align 1
  %af.i.i168 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i168, align 1
  store ptr %188, ptr %MEMORY, align 8
  br label %190

190:                                              ; preds = %184
  %191 = load i64, ptr %NEXT_PC, align 8
  store i64 %191, ptr %PC, align 8
  %192 = add i64 %191, 3
  store i64 %192, ptr %NEXT_PC, align 8
  %193 = load i32, ptr %ECX, align 4
  %194 = zext i32 %193 to i64
  %195 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i54 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %193, i32 noundef 0, i32 noundef %193) #15
  %conv.i12.i = zext i1 %call.i.i.i54 to i8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i55, align 1
  %conv.i.i.i.i56 = trunc i32 %193 to i8
  %196 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i56)
  %197 = and i8 %196, 1
  %conv.i.i.i57 = xor i8 %197, 1
  %pf.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i57, ptr %pf.i.i.i58, align 1
  %af.i.i.i59 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i59, align 1
  %cmp.i.i.i.i60 = icmp eq i32 %193, 0
  %call.i.i.i.i61 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i60, i32 noundef %193, i32 noundef 0, i32 noundef %193) #15
  %conv5.i.i.i62 = zext i1 %call.i.i.i.i61 to i8
  %zf.i.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i62, ptr %zf.i.i.i63, align 1
  %cmp.i27.i.i.i64 = icmp slt i32 %193, 0
  %call1.i.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i64, i32 noundef %193, i32 noundef 0, i32 noundef %193) #15
  %conv8.i.i.i66 = zext i1 %call1.i.i.i.i65 to i8
  %sf.i.i.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i66, ptr %sf.i.i.i67, align 1
  %xor.i28.i.i.i68 = lshr i32 %193, 31
  %call.i30.i.i.i69 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %193, i32 noundef 0, i32 noundef %193) #15
  %conv11.i.i.i70 = zext i1 %call.i30.i.i.i69 to i8
  %of.i.i.i71 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i70, ptr %of.i.i.i71, align 1
  store ptr %195, ptr %MEMORY, align 8
  br label %198

198:                                              ; preds = %190
  %199 = load i64, ptr %NEXT_PC, align 8
  store i64 %199, ptr %PC, align 8
  %200 = add i64 %199, 3
  store i64 %200, ptr %NEXT_PC, align 8
  %201 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %202 = load i8, ptr %zf.i, align 1
  store i8 %202, ptr %CL, align 1
  store ptr %201, ptr %MEMORY, align 8
  br label %203

203:                                              ; preds = %198
  %204 = load i64, ptr %NEXT_PC, align 8
  store i64 %204, ptr %PC, align 8
  %205 = add i64 %204, 2
  store i64 %205, ptr %NEXT_PC, align 8
  %206 = load i8, ptr %AL, align 1
  %207 = zext i8 %206 to i64
  %208 = load i8, ptr %CL, align 1
  %209 = zext i8 %208 to i64
  %210 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %209, %207
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i169 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i169, align 1
  %211 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %212 = and i8 %211, 1
  %conv.i27.i = xor i8 %212, 1
  %pf.i.i170 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i170, align 1
  %213 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i171 = and i32 %213, 255
  %cmp.i.i.i172 = icmp eq i8 %or3.i.i, 0
  %214 = trunc i64 %207 to i32
  %conv1.i.i.i = and i32 %214, 255
  %215 = trunc i64 %209 to i32
  %conv2.i.i.i173 = and i32 %215, 255
  %call.i.i.i174 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i172, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i173, i32 noundef %conv.i.i.i171) #15
  %conv3.i.i175 = zext i1 %call.i.i.i174 to i8
  %zf.i.i176 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i175, ptr %zf.i.i176, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i173, i32 noundef %conv.i.i.i171) #15
  %conv6.i.i177 = zext i1 %call4.i.i.i to i8
  %sf.i.i178 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i177, ptr %sf.i.i178, align 1
  %of.i.i179 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i179, align 1
  %af.i.i180 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i180, align 1
  store ptr %210, ptr %MEMORY, align 8
  br label %216

216:                                              ; preds = %203
  %217 = load i64, ptr %NEXT_PC, align 8
  store i64 %217, ptr %PC, align 8
  %218 = add i64 %217, 2
  store i64 %218, ptr %NEXT_PC, align 8
  %219 = load i8, ptr %AL, align 1
  %220 = zext i8 %219 to i64
  %221 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %220
  %and3.i.i198 = trunc i64 %and3.i15.i to i8
  %cf.i.i199 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i199, align 1
  %222 = and i8 %and3.i.i198, 1
  %conv.i14.i = xor i8 %222, 1
  %pf.i.i200 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i200, align 1
  %223 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i201 = and i32 %223, 255
  %cmp.i.i.i202 = icmp eq i8 %and3.i.i198, 0
  %224 = trunc i64 %220 to i32
  %conv1.i.i.i203 = and i32 %224, 255
  %call.i.i.i204 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i202, i32 noundef %conv1.i.i.i203, i32 noundef 1, i32 noundef %conv.i.i.i201) #15
  %conv3.i.i205 = zext i1 %call.i.i.i204 to i8
  %zf.i.i206 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i205, ptr %zf.i.i206, align 1
  %call4.i.i.i207 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i203, i32 noundef 1, i32 noundef %conv.i.i.i201) #15
  %conv6.i.i208 = zext i1 %call4.i.i.i207 to i8
  %sf.i.i209 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i208, ptr %sf.i.i209, align 1
  %of.i.i210 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i210, align 1
  %af.i.i211 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i211, align 1
  store ptr %221, ptr %MEMORY, align 8
  br label %225

225:                                              ; preds = %216
  %226 = load i64, ptr %NEXT_PC, align 8
  store i64 %226, ptr %PC, align 8
  %227 = add i64 %226, 6
  store i64 %227, ptr %NEXT_PC, align 8
  %228 = load i64, ptr %NEXT_PC, align 8
  %229 = add i64 %228, 5
  %230 = load i64, ptr %NEXT_PC, align 8
  %231 = load ptr, ptr %MEMORY, align 8
  %zf.i138 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %232 = load i8, ptr %zf.i138, align 1
  %tobool.not.i = icmp eq i8 %232, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i139 = select i1 %call9.i, i64 %229, i64 %230
  store i64 %cond1.i.i139, ptr %NEXT_PC, align 8
  store ptr %231, ptr %MEMORY, align 8
  %233 = load i64, ptr %NEXT_PC, align 8
  store i64 %233, ptr %PC, align 8
  %234 = load ptr, ptr %MEMORY, align 8
  ret ptr %234
}

define ptr @BB_2895(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 9860
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9627
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_292a(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %EAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 1774
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load i32, ptr %EAX, align 4
  %12 = zext i32 %11 to i64
  %13 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %10 to i32
  %xor3.i.i = xor i32 %11, %conv.i.i
  %conv.i27.i = zext i32 %xor3.i.i to i64
  store i64 %conv.i27.i, ptr %RAX, align 8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i, align 1
  %conv.i.i.i = trunc i32 %xor3.i.i to i8
  %14 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i)
  %15 = and i8 %14, 1
  %conv.i28.i = xor i8 %15, 1
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i28.i, ptr %pf.i.i, align 1
  %cmp.i.i.i = icmp eq i32 %xor3.i.i, 0
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i to i8
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i, align 1
  %cmp.i19.i.i = icmp slt i32 %xor3.i.i, 0
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv.i.i, i32 noundef %11, i32 noundef %xor3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i, align 1
  store ptr %13, ptr %MEMORY, align 8
  br label %16

16:                                               ; preds = %7
  %17 = load i64, ptr %NEXT_PC, align 8
  store i64 %17, ptr %PC, align 8
  %18 = add i64 %17, 5
  store i64 %18, ptr %NEXT_PC, align 8
  %19 = load i64, ptr %NEXT_PC, align 8
  %20 = sub i64 %19, 2312
  %21 = load i64, ptr %NEXT_PC, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %23 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %23, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %22, i64 noundef %sub.i.i, i64 noundef %21) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %20, ptr %rip.i, align 8
  store i64 %20, ptr %NEXT_PC, align 8
  store i64 %21, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %24 = load ptr, ptr %MEMORY, align 8
  ret ptr %24
}

define ptr @BB_26c2(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 136
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_28cb(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDI = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 11, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 1838
  %6 = load ptr, ptr %MEMORY, align 8
  store i64 %5, ptr %RDI, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load ptr, ptr %MEMORY, align 8
  store i8 0, ptr %AL, align 1
  store ptr %10, ptr %MEMORY, align 8
  br label %11

11:                                               ; preds = %7
  %12 = load i64, ptr %NEXT_PC, align 8
  store i64 %12, ptr %PC, align 8
  %13 = add i64 %12, 5
  store i64 %13, ptr %NEXT_PC, align 8
  %14 = load i64, ptr %NEXT_PC, align 8
  %15 = sub i64 %14, 2217
  %16 = load i64, ptr %NEXT_PC, align 8
  %17 = load ptr, ptr %MEMORY, align 8
  %rsp.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %18 = load i64, ptr %rsp.i, align 8
  %sub.i.i = add i64 %18, -8
  %call.i.i = call ptr @__remill_write_memory_64(ptr noundef %17, i64 noundef %sub.i.i, i64 noundef %16) #15
  store i64 %sub.i.i, ptr %rsp.i, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %15, ptr %rip.i, align 8
  store i64 %15, ptr %NEXT_PC, align 8
  store i64 %16, ptr %RETURN_PC, align 8
  store ptr %call.i.i, ptr %MEMORY, align 8
  %19 = load ptr, ptr %MEMORY, align 8
  ret ptr %19
}

define ptr @BB_ffff000000000000_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !5)
  %rsp.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !8)
  %rip.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !11)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

; Function Attrs: nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite)
declare void @llvm.experimental.noalias.scope.decl(metadata) #3

declare ptr @__lifted_ext_call_printf(ptr, i64, ptr) #2

define ptr @BB_26cb(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10486
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10189
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_275c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10301
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10004
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_ffff000000000001_ext(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #2 {
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  call void @llvm.experimental.noalias.scope.decl(metadata !14)
  %rsp.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %1 = load i64, ptr %rsp.i.i, align 8
  %retaddr.i = call i64 @__remill_read_memory_64(ptr %memory, i64 %1)
  %2 = call ptr @__lifted_ext_call_printf(ptr %state, i64 %program_counter, ptr %memory)
  call void @llvm.experimental.noalias.scope.decl(metadata !17)
  %rip.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %retaddr.i, ptr %rip.i.i, align 8
  %3 = add i64 %1, 8
  call void @llvm.experimental.noalias.scope.decl(metadata !20)
  %rsp.i1.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  store i64 %3, ptr %rsp.i1.i, align 8
  ret ptr %memory
}

define ptr @BB_2938(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10089
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2701(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 32
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i75 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i75, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 1) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 10598
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i74 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i74, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 4
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  store i64 %21, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %21 to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %21, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %21, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %21, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %21, i64 noundef 0, i64 noundef %21) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %25

25:                                               ; preds = %18
  %26 = load i64, ptr %NEXT_PC, align 8
  store i64 %26, ptr %PC, align 8
  %27 = add i64 %26, 7
  store i64 %27, ptr %NEXT_PC, align 8
  %28 = load i64, ptr %RBP, align 8
  %29 = sub i64 %28, 144
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call ptr @__remill_write_memory_64(ptr noundef %31, i64 noundef %29, i64 noundef %30) #15
  store ptr %call.i.i69, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %25
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 10396
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 2
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i70 = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %conv.i.i71 = zext i32 %call.i.i70 to i64
  store i64 %conv.i.i71, ptr %RDX, align 8
  store ptr %42, ptr %MEMORY, align 8
  br label %43

43:                                               ; preds = %38
  %44 = load i64, ptr %NEXT_PC, align 8
  store i64 %44, ptr %PC, align 8
  %45 = add i64 %44, 7
  store i64 %45, ptr %NEXT_PC, align 8
  %46 = load i64, ptr %NEXT_PC, align 8
  %47 = add i64 %46, 10099
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %48, i64 noundef %47) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %48, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %43
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RAX, align 8
  %53 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %53, i64 noundef %52) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %54 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %55 = and i8 %54, 1
  %conv.i.i.i24 = xor i8 %55, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %56 = trunc i32 %xor1.i.i.i.i27 to i8
  %57 = lshr i8 %56, 4
  %conv2.i.i.i28 = and i8 %57, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %53, ptr %MEMORY, align 8
  br label %58

58:                                               ; preds = %49
  %59 = load i64, ptr %NEXT_PC, align 8
  store i64 %59, ptr %PC, align 8
  %60 = add i64 %59, 3
  store i64 %60, ptr %NEXT_PC, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %62 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %62, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %63 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %63, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %64

64:                                               ; preds = %58
  %65 = load i64, ptr %NEXT_PC, align 8
  store i64 %65, ptr %PC, align 8
  %66 = add i64 %65, 2
  store i64 %66, ptr %NEXT_PC, align 8
  %67 = load i32, ptr %EDX, align 4
  %68 = zext i32 %67 to i64
  %69 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %68, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %69, ptr %MEMORY, align 8
  br label %70

70:                                               ; preds = %64
  %71 = load i64, ptr %NEXT_PC, align 8
  store i64 %71, ptr %PC, align 8
  %72 = add i64 %71, 3
  store i64 %72, ptr %NEXT_PC, align 8
  %73 = load i64, ptr %RCX, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %73 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %75 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %75, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %76 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %77 = and i8 %76, 1
  %conv.i.i.i = xor i8 %77, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %78 = trunc i32 %xor1.i.i.i.i to i8
  %79 = lshr i8 %78, 4
  %conv2.i.i.i = and i8 %79, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %80

80:                                               ; preds = %70
  %81 = load i64, ptr %NEXT_PC, align 8
  store i64 %81, ptr %PC, align 8
  %82 = add i64 %81, 3
  store i64 %82, ptr %NEXT_PC, align 8
  %83 = load i64, ptr %RCX, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %83 to i32
  %sext.i = shl i64 %83, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %85, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %87 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %87, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %84, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %86, ptr %MEMORY, align 8
  br label %88

88:                                               ; preds = %80
  %89 = load i64, ptr %NEXT_PC, align 8
  store i64 %89, ptr %PC, align 8
  %90 = add i64 %89, 3
  store i64 %90, ptr %NEXT_PC, align 8
  %91 = load i64, ptr %RCX, align 8
  %92 = load ptr, ptr %MEMORY, align 8
  %conv.i.i76 = trunc i64 %91 to i32
  %and3.i.i = and i32 1, %conv.i.i76
  %conv.i22.i77 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i77, ptr %RCX, align 8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %conv.i.i.i79 = trunc i32 %and3.i.i to i8
  %93 = and i8 %conv.i.i.i79, 1
  %conv.i23.i80 = xor i8 %93, 1
  %pf.i.i81 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i80, ptr %pf.i.i81, align 1
  %cmp.i.i.i82 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i82, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i83 to i8
  %zf.i.i84 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i84, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i76, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i85, align 1
  %of.i.i86 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i86, align 1
  %af.i.i87 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i87, align 1
  store ptr %92, ptr %MEMORY, align 8
  br label %94

94:                                               ; preds = %88
  %95 = load i64, ptr %NEXT_PC, align 8
  store i64 %95, ptr %PC, align 8
  %96 = add i64 %95, 3
  store i64 %96, ptr %NEXT_PC, align 8
  %97 = load i32, ptr %ECX, align 4
  %98 = zext i32 %97 to i64
  %99 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %97 to i8
  %100 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %101 = and i8 %100, 1
  %conv.i.i.i48 = xor i8 %101, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %97, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %97, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %97, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %97, i32 noundef 0, i32 noundef %97) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %99, ptr %MEMORY, align 8
  br label %102

102:                                              ; preds = %94
  %103 = load i64, ptr %NEXT_PC, align 8
  store i64 %103, ptr %PC, align 8
  %104 = add i64 %103, 3
  store i64 %104, ptr %NEXT_PC, align 8
  %105 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %106 = load i8, ptr %zf.i, align 1
  store i8 %106, ptr %CL, align 1
  store ptr %105, ptr %MEMORY, align 8
  br label %107

107:                                              ; preds = %102
  %108 = load i64, ptr %NEXT_PC, align 8
  store i64 %108, ptr %PC, align 8
  %109 = add i64 %108, 2
  store i64 %109, ptr %NEXT_PC, align 8
  %110 = load i8, ptr %AL, align 1
  %111 = zext i8 %110 to i64
  %112 = load i8, ptr %CL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %113, %111
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i88, align 1
  %115 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %116 = and i8 %115, 1
  %conv.i27.i = xor i8 %116, 1
  %pf.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i89, align 1
  %117 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i90 = and i32 %117, 255
  %cmp.i.i.i91 = icmp eq i8 %or3.i.i, 0
  %118 = trunc i64 %111 to i32
  %conv1.i.i.i = and i32 %118, 255
  %119 = trunc i64 %113 to i32
  %conv2.i.i.i92 = and i32 %119, 255
  %call.i.i.i93 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i91, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #15
  %conv3.i.i94 = zext i1 %call.i.i.i93 to i8
  %zf.i.i95 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i94, ptr %zf.i.i95, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i92, i32 noundef %conv.i.i.i90) #15
  %conv6.i.i96 = zext i1 %call4.i.i.i to i8
  %sf.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i96, ptr %sf.i.i97, align 1
  %of.i.i98 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i98, align 1
  %af.i.i99 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i99, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %120

120:                                              ; preds = %107
  %121 = load i64, ptr %NEXT_PC, align 8
  store i64 %121, ptr %PC, align 8
  %122 = add i64 %121, 2
  store i64 %122, ptr %NEXT_PC, align 8
  %123 = load i8, ptr %AL, align 1
  %124 = zext i8 %123 to i64
  %125 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %124
  %and3.i.i100 = trunc i64 %and3.i15.i to i8
  %cf.i.i101 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i101, align 1
  %126 = and i8 %and3.i.i100, 1
  %conv.i14.i = xor i8 %126, 1
  %pf.i.i102 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i102, align 1
  %127 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i103 = and i32 %127, 255
  %cmp.i.i.i104 = icmp eq i8 %and3.i.i100, 0
  %128 = trunc i64 %124 to i32
  %conv1.i.i.i105 = and i32 %128, 255
  %call.i.i.i106 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i104, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #15
  %conv3.i.i107 = zext i1 %call.i.i.i106 to i8
  %zf.i.i108 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i107, ptr %zf.i.i108, align 1
  %call4.i.i.i109 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i105, i32 noundef 1, i32 noundef %conv.i.i.i103) #15
  %conv6.i.i110 = zext i1 %call4.i.i.i109 to i8
  %sf.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i110, ptr %sf.i.i111, align 1
  %of.i.i112 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i112, align 1
  %af.i.i113 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i113, align 1
  store ptr %125, ptr %MEMORY, align 8
  br label %129

129:                                              ; preds = %120
  %130 = load i64, ptr %NEXT_PC, align 8
  store i64 %130, ptr %PC, align 8
  %131 = add i64 %130, 6
  store i64 %131, ptr %NEXT_PC, align 8
  %132 = load i64, ptr %NEXT_PC, align 8
  %133 = add i64 %132, 5
  %134 = load i64, ptr %NEXT_PC, align 8
  %135 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %136 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %136, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %133, i64 %134
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %135, ptr %MEMORY, align 8
  %137 = load i64, ptr %NEXT_PC, align 8
  store i64 %137, ptr %PC, align 8
  %138 = load ptr, ptr %MEMORY, align 8
  ret ptr %138
}

define ptr @BB_2792(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10487
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 7
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 152
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 10093
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #15
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 9884
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_28d9(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10184
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i73 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i73, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 4
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  store i64 %10, ptr %RAX, align 8
  %call.i.i.i1 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv.i.i2 = zext i1 %call.i.i.i1 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i2, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i64 %10 to i8
  %12 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %13 = and i8 %12, 1
  %conv.i.i.i5 = xor i8 %13, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %af.i.i.i7 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i7, align 1
  %cmp.i.i.i.i8 = icmp eq i64 %10, 0
  %call.i.i.i.i9 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i8, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv5.i.i.i10 = zext i1 %call.i.i.i.i9 to i8
  %zf.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i10, ptr %zf.i.i.i11, align 1
  %cmp.i27.i.i.i12 = icmp slt i64 %10, 0
  %call1.i.i.i.i13 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i12, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv8.i.i.i14 = zext i1 %call1.i.i.i.i13 to i8
  %sf.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i14, ptr %sf.i.i.i15, align 1
  %xor.i28.i.i.i16 = lshr i64 %10, 63
  %call.i30.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %10, i64 noundef 0, i64 noundef %10) #15
  %conv11.i.i.i18 = zext i1 %call.i30.i.i.i17 to i8
  %of.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i18, ptr %of.i.i.i19, align 1
  store ptr %11, ptr %MEMORY, align 8
  br label %14

14:                                               ; preds = %7
  %15 = load i64, ptr %NEXT_PC, align 8
  store i64 %15, ptr %PC, align 8
  %16 = add i64 %15, 7
  store i64 %16, ptr %NEXT_PC, align 8
  %17 = load i64, ptr %RBP, align 8
  %18 = sub i64 %17, 168
  %19 = load i64, ptr %RAX, align 8
  %20 = load ptr, ptr %MEMORY, align 8
  %call.i.i68 = call ptr @__remill_write_memory_64(ptr noundef %20, i64 noundef %18, i64 noundef %19) #15
  store ptr %call.i.i68, ptr %MEMORY, align 8
  br label %21

21:                                               ; preds = %14
  %22 = load i64, ptr %NEXT_PC, align 8
  store i64 %22, ptr %PC, align 8
  %23 = add i64 %22, 7
  store i64 %23, ptr %NEXT_PC, align 8
  %24 = load i64, ptr %NEXT_PC, align 8
  %25 = add i64 %24, 9750
  %26 = load ptr, ptr %MEMORY, align 8
  %call.i.i72 = call i64 @__remill_read_memory_64(ptr noundef %26, i64 noundef %25) #15
  store i64 %call.i.i72, ptr %RAX, align 8
  store ptr %26, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %21
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 2
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load i64, ptr %RAX, align 8
  %31 = load ptr, ptr %MEMORY, align 8
  %call.i.i69 = call i32 @__remill_read_memory_32(ptr noundef %31, i64 noundef %30) #15
  %conv.i.i70 = zext i32 %call.i.i69 to i64
  store i64 %conv.i.i70, ptr %RDX, align 8
  store ptr %31, ptr %MEMORY, align 8
  br label %32

32:                                               ; preds = %27
  %33 = load i64, ptr %NEXT_PC, align 8
  store i64 %33, ptr %PC, align 8
  %34 = add i64 %33, 7
  store i64 %34, ptr %NEXT_PC, align 8
  %35 = load i64, ptr %NEXT_PC, align 8
  %36 = add i64 %35, 9549
  %37 = load ptr, ptr %MEMORY, align 8
  %call.i.i71 = call i64 @__remill_read_memory_64(ptr noundef %37, i64 noundef %36) #15
  store i64 %call.i.i71, ptr %RAX, align 8
  store ptr %37, ptr %MEMORY, align 8
  br label %38

38:                                               ; preds = %32
  %39 = load i64, ptr %NEXT_PC, align 8
  store i64 %39, ptr %PC, align 8
  %40 = add i64 %39, 3
  store i64 %40, ptr %NEXT_PC, align 8
  %41 = load i64, ptr %RAX, align 8
  %42 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %42, i64 noundef %41) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i20 = icmp ult i32 %call.i.i, 10
  %call.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i20, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i21 to i8
  %cf.i.i22 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i22, align 1
  %conv.i.i.i.i23 = trunc i32 %sub.i.i to i8
  %43 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i23)
  %44 = and i8 %43, 1
  %conv.i.i.i24 = xor i8 %44, 1
  %pf.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i24, ptr %pf.i.i.i25, align 1
  %xor.i.i.i.i26 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i27 = xor i32 %xor.i.i.i.i26, %sub.i.i
  %45 = trunc i32 %xor1.i.i.i.i27 to i8
  %46 = lshr i8 %45, 4
  %conv2.i.i.i28 = and i8 %46, 1
  %af.i.i.i29 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i28, ptr %af.i.i.i29, align 1
  %cmp.i.i.i.i30 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i31 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i30, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i32 = zext i1 %call.i.i.i.i31 to i8
  %zf.i.i.i33 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i32, ptr %zf.i.i.i33, align 1
  %cmp.i27.i.i.i34 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i35 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i34, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i36 = zext i1 %call1.i.i.i.i35 to i8
  %sf.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i36, ptr %sf.i.i.i37, align 1
  %xor.i28.i.i.i38 = lshr i32 %xor.i.i.i.i26, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i39 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i40 = add nuw nsw i32 %xor3.i.i.i.i39, %xor.i28.i.i.i38
  %cmp.i29.i.i.i41 = icmp eq i32 %add.i.i.i.i40, 2
  %call.i30.i.i.i42 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i41, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i43 = zext i1 %call.i30.i.i.i42 to i8
  %of.i.i.i44 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i43, ptr %of.i.i.i44, align 1
  store ptr %42, ptr %MEMORY, align 8
  br label %47

47:                                               ; preds = %38
  %48 = load i64, ptr %NEXT_PC, align 8
  store i64 %48, ptr %PC, align 8
  %49 = add i64 %48, 3
  store i64 %49, ptr %NEXT_PC, align 8
  %50 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %51 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %51, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %52 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %52, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %50, ptr %MEMORY, align 8
  br label %53

53:                                               ; preds = %47
  %54 = load i64, ptr %NEXT_PC, align 8
  store i64 %54, ptr %PC, align 8
  %55 = add i64 %54, 2
  store i64 %55, ptr %NEXT_PC, align 8
  %56 = load i32, ptr %EDX, align 4
  %57 = zext i32 %56 to i64
  %58 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %57, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %58, ptr %MEMORY, align 8
  br label %59

59:                                               ; preds = %53
  %60 = load i64, ptr %NEXT_PC, align 8
  store i64 %60, ptr %PC, align 8
  %61 = add i64 %60, 3
  store i64 %61, ptr %NEXT_PC, align 8
  %62 = load i64, ptr %RCX, align 8
  %63 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %62 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %64 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %64, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %65 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %66 = and i8 %65, 1
  %conv.i.i.i = xor i8 %66, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %67 = trunc i32 %xor1.i.i.i.i to i8
  %68 = lshr i8 %67, 4
  %conv2.i.i.i = and i8 %68, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %63, ptr %MEMORY, align 8
  br label %69

69:                                               ; preds = %59
  %70 = load i64, ptr %NEXT_PC, align 8
  store i64 %70, ptr %PC, align 8
  %71 = add i64 %70, 3
  store i64 %71, ptr %NEXT_PC, align 8
  %72 = load i64, ptr %RCX, align 8
  %73 = load i32, ptr %EDX, align 4
  %74 = zext i32 %73 to i64
  %75 = load ptr, ptr %MEMORY, align 8
  %conv.i.i63 = trunc i64 %72 to i32
  %sext.i = shl i64 %72, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %74, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %76 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i64 = icmp ult i64 %76, -4294967296
  %call.i.i.i65 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i64, i32 noundef %conv.i.i63, i32 noundef %73, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i65 to i8
  %cf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i66, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %75, ptr %MEMORY, align 8
  br label %77

77:                                               ; preds = %69
  %78 = load i64, ptr %NEXT_PC, align 8
  store i64 %78, ptr %PC, align 8
  %79 = add i64 %78, 3
  store i64 %79, ptr %NEXT_PC, align 8
  %80 = load i64, ptr %RCX, align 8
  %81 = load ptr, ptr %MEMORY, align 8
  %conv.i.i74 = trunc i64 %80 to i32
  %and3.i.i = and i32 1, %conv.i.i74
  %conv.i22.i75 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i75, ptr %RCX, align 8
  %cf.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i76, align 1
  %conv.i.i.i77 = trunc i32 %and3.i.i to i8
  %82 = and i8 %conv.i.i.i77, 1
  %conv.i23.i78 = xor i8 %82, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i78, ptr %pf.i.i79, align 1
  %cmp.i.i.i80 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i81 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i80, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i81 to i8
  %zf.i.i82 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i82, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i74, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i83 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i83, align 1
  %of.i.i84 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i84, align 1
  %af.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i85, align 1
  store ptr %81, ptr %MEMORY, align 8
  br label %83

83:                                               ; preds = %77
  %84 = load i64, ptr %NEXT_PC, align 8
  store i64 %84, ptr %PC, align 8
  %85 = add i64 %84, 3
  store i64 %85, ptr %NEXT_PC, align 8
  %86 = load i32, ptr %ECX, align 4
  %87 = zext i32 %86 to i64
  %88 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i45 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv.i12.i = zext i1 %call.i.i.i45 to i8
  %cf.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i46, align 1
  %conv.i.i.i.i47 = trunc i32 %86 to i8
  %89 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i47)
  %90 = and i8 %89, 1
  %conv.i.i.i48 = xor i8 %90, 1
  %pf.i.i.i49 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i48, ptr %pf.i.i.i49, align 1
  %af.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i50, align 1
  %cmp.i.i.i.i51 = icmp eq i32 %86, 0
  %call.i.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i51, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv5.i.i.i53 = zext i1 %call.i.i.i.i52 to i8
  %zf.i.i.i54 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i53, ptr %zf.i.i.i54, align 1
  %cmp.i27.i.i.i55 = icmp slt i32 %86, 0
  %call1.i.i.i.i56 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i55, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv8.i.i.i57 = zext i1 %call1.i.i.i.i56 to i8
  %sf.i.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i57, ptr %sf.i.i.i58, align 1
  %xor.i28.i.i.i59 = lshr i32 %86, 31
  %call.i30.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %86, i32 noundef 0, i32 noundef %86) #15
  %conv11.i.i.i61 = zext i1 %call.i30.i.i.i60 to i8
  %of.i.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i61, ptr %of.i.i.i62, align 1
  store ptr %88, ptr %MEMORY, align 8
  br label %91

91:                                               ; preds = %83
  %92 = load i64, ptr %NEXT_PC, align 8
  store i64 %92, ptr %PC, align 8
  %93 = add i64 %92, 3
  store i64 %93, ptr %NEXT_PC, align 8
  %94 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %95 = load i8, ptr %zf.i, align 1
  store i8 %95, ptr %CL, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %96

96:                                               ; preds = %91
  %97 = load i64, ptr %NEXT_PC, align 8
  store i64 %97, ptr %PC, align 8
  %98 = add i64 %97, 2
  store i64 %98, ptr %NEXT_PC, align 8
  %99 = load i8, ptr %AL, align 1
  %100 = zext i8 %99 to i64
  %101 = load i8, ptr %CL, align 1
  %102 = zext i8 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %102, %100
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i86 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i86, align 1
  %104 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %105 = and i8 %104, 1
  %conv.i27.i = xor i8 %105, 1
  %pf.i.i87 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i87, align 1
  %106 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i88 = and i32 %106, 255
  %cmp.i.i.i89 = icmp eq i8 %or3.i.i, 0
  %107 = trunc i64 %100 to i32
  %conv1.i.i.i = and i32 %107, 255
  %108 = trunc i64 %102 to i32
  %conv2.i.i.i90 = and i32 %108, 255
  %call.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i89, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv3.i.i92 = zext i1 %call.i.i.i91 to i8
  %zf.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i92, ptr %zf.i.i93, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i90, i32 noundef %conv.i.i.i88) #15
  %conv6.i.i94 = zext i1 %call4.i.i.i to i8
  %sf.i.i95 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i94, ptr %sf.i.i95, align 1
  %of.i.i96 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i96, align 1
  %af.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i97, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %109

109:                                              ; preds = %96
  %110 = load i64, ptr %NEXT_PC, align 8
  store i64 %110, ptr %PC, align 8
  %111 = add i64 %110, 2
  store i64 %111, ptr %NEXT_PC, align 8
  %112 = load i8, ptr %AL, align 1
  %113 = zext i8 %112 to i64
  %114 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %113
  %and3.i.i98 = trunc i64 %and3.i15.i to i8
  %cf.i.i99 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i99, align 1
  %115 = and i8 %and3.i.i98, 1
  %conv.i14.i = xor i8 %115, 1
  %pf.i.i100 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i100, align 1
  %116 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i101 = and i32 %116, 255
  %cmp.i.i.i102 = icmp eq i8 %and3.i.i98, 0
  %117 = trunc i64 %113 to i32
  %conv1.i.i.i103 = and i32 %117, 255
  %call.i.i.i104 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i102, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv3.i.i105 = zext i1 %call.i.i.i104 to i8
  %zf.i.i106 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i105, ptr %zf.i.i106, align 1
  %call4.i.i.i107 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i103, i32 noundef 1, i32 noundef %conv.i.i.i101) #15
  %conv6.i.i108 = zext i1 %call4.i.i.i107 to i8
  %sf.i.i109 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i108, ptr %sf.i.i109, align 1
  %of.i.i110 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i110, align 1
  %af.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i111, align 1
  store ptr %114, ptr %MEMORY, align 8
  br label %118

118:                                              ; preds = %109
  %119 = load i64, ptr %NEXT_PC, align 8
  store i64 %119, ptr %PC, align 8
  %120 = add i64 %119, 6
  store i64 %120, ptr %NEXT_PC, align 8
  %121 = load i64, ptr %NEXT_PC, align 8
  %122 = add i64 %121, 5
  %123 = load i64, ptr %NEXT_PC, align 8
  %124 = load ptr, ptr %MEMORY, align 8
  %zf.i67 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %125 = load i8, ptr %zf.i67, align 1
  %tobool.not.i = icmp eq i8 %125, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %122, i64 %123
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %124, ptr %MEMORY, align 8
  %126 = load i64, ptr %NEXT_PC, align 8
  store i64 %126, ptr %PC, align 8
  %127 = load ptr, ptr %MEMORY, align 8
  ret ptr %127
}

define ptr @BB_2941(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 80
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i2 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i2, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 6
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call ptr @__remill_write_memory_32(ptr noundef %11, i64 noundef %10, i32 noundef 0) #15
  store ptr %call.i.i, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9966
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i1 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i1, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 2
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %21, ptr %rip.i, align 8
  store i64 %21, ptr %NEXT_PC, align 8
  store ptr %22, ptr %MEMORY, align 8
  %23 = load ptr, ptr %MEMORY, align 8
  ret ptr %23
}

define ptr @BB_2753(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 144
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_27da(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 152
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_2921(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 168
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

define ptr @BB_27e3(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %NEXT_PC, align 8
  %5 = add i64 %4, 10022
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i52 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i52, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i49 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i50 = zext i32 %call.i.i49 to i64
  store i64 %conv.i.i50, ptr %RDX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 7
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %NEXT_PC, align 8
  %16 = add i64 %15, 9845
  %17 = load ptr, ptr %MEMORY, align 8
  %call.i.i51 = call i64 @__remill_read_memory_64(ptr noundef %17, i64 noundef %16) #15
  store i64 %call.i.i51, ptr %RAX, align 8
  store ptr %17, ptr %MEMORY, align 8
  br label %18

18:                                               ; preds = %12
  %19 = load i64, ptr %NEXT_PC, align 8
  store i64 %19, ptr %PC, align 8
  %20 = add i64 %19, 3
  store i64 %20, ptr %NEXT_PC, align 8
  %21 = load i64, ptr %RAX, align 8
  %22 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %22, i64 noundef %21) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i1 = icmp ult i32 %call.i.i, 10
  %call.i.i.i2 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i1, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i2 to i8
  %cf.i.i3 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i3, align 1
  %conv.i.i.i.i4 = trunc i32 %sub.i.i to i8
  %23 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i4)
  %24 = and i8 %23, 1
  %conv.i.i.i5 = xor i8 %24, 1
  %pf.i.i.i6 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i5, ptr %pf.i.i.i6, align 1
  %xor.i.i.i.i7 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i8 = xor i32 %xor.i.i.i.i7, %sub.i.i
  %25 = trunc i32 %xor1.i.i.i.i8 to i8
  %26 = lshr i8 %25, 4
  %conv2.i.i.i9 = and i8 %26, 1
  %af.i.i.i10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i9, ptr %af.i.i.i10, align 1
  %cmp.i.i.i.i11 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i12 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i11, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i13 = zext i1 %call.i.i.i.i12 to i8
  %zf.i.i.i14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i13, ptr %zf.i.i.i14, align 1
  %cmp.i27.i.i.i15 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i16 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i15, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i17 = zext i1 %call1.i.i.i.i16 to i8
  %sf.i.i.i18 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i17, ptr %sf.i.i.i18, align 1
  %xor.i28.i.i.i19 = lshr i32 %xor.i.i.i.i7, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i20 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i21 = add nuw nsw i32 %xor3.i.i.i.i20, %xor.i28.i.i.i19
  %cmp.i29.i.i.i22 = icmp eq i32 %add.i.i.i.i21, 2
  %call.i30.i.i.i23 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i22, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i24 = zext i1 %call.i30.i.i.i23 to i8
  %of.i.i.i25 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i24, ptr %of.i.i.i25, align 1
  store ptr %22, ptr %MEMORY, align 8
  br label %27

27:                                               ; preds = %18
  %28 = load i64, ptr %NEXT_PC, align 8
  store i64 %28, ptr %PC, align 8
  %29 = add i64 %28, 3
  store i64 %29, ptr %NEXT_PC, align 8
  %30 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %31 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %31, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %32 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %32, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %30, ptr %MEMORY, align 8
  br label %33

33:                                               ; preds = %27
  %34 = load i64, ptr %NEXT_PC, align 8
  store i64 %34, ptr %PC, align 8
  %35 = add i64 %34, 2
  store i64 %35, ptr %NEXT_PC, align 8
  %36 = load i32, ptr %EDX, align 4
  %37 = zext i32 %36 to i64
  %38 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %37, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %38, ptr %MEMORY, align 8
  br label %39

39:                                               ; preds = %33
  %40 = load i64, ptr %NEXT_PC, align 8
  store i64 %40, ptr %PC, align 8
  %41 = add i64 %40, 3
  store i64 %41, ptr %NEXT_PC, align 8
  %42 = load i64, ptr %RCX, align 8
  %43 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %42 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %44 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %44, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %45 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %46 = and i8 %45, 1
  %conv.i.i.i = xor i8 %46, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %47 = trunc i32 %xor1.i.i.i.i to i8
  %48 = lshr i8 %47, 4
  %conv2.i.i.i = and i8 %48, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %43, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %39
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 3
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %RCX, align 8
  %53 = load i32, ptr %EDX, align 4
  %54 = zext i32 %53 to i64
  %55 = load ptr, ptr %MEMORY, align 8
  %conv.i.i44 = trunc i64 %52 to i32
  %sext.i = shl i64 %52, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %54, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %56 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i45 = icmp ult i64 %56, -4294967296
  %call.i.i.i46 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i45, i32 noundef %conv.i.i44, i32 noundef %53, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i46 to i8
  %cf.i.i47 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i47, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %55, ptr %MEMORY, align 8
  br label %57

57:                                               ; preds = %49
  %58 = load i64, ptr %NEXT_PC, align 8
  store i64 %58, ptr %PC, align 8
  %59 = add i64 %58, 3
  store i64 %59, ptr %NEXT_PC, align 8
  %60 = load i64, ptr %RCX, align 8
  %61 = load ptr, ptr %MEMORY, align 8
  %conv.i.i53 = trunc i64 %60 to i32
  %and3.i.i = and i32 1, %conv.i.i53
  %conv.i22.i54 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i54, ptr %RCX, align 8
  %cf.i.i55 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i55, align 1
  %conv.i.i.i56 = trunc i32 %and3.i.i to i8
  %62 = and i8 %conv.i.i.i56, 1
  %conv.i23.i57 = xor i8 %62, 1
  %pf.i.i58 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i57, ptr %pf.i.i58, align 1
  %cmp.i.i.i59 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i60 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i59, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i60 to i8
  %zf.i.i61 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i61, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i53, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i62 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i62, align 1
  %of.i.i63 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i63, align 1
  %af.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i64, align 1
  store ptr %61, ptr %MEMORY, align 8
  br label %63

63:                                               ; preds = %57
  %64 = load i64, ptr %NEXT_PC, align 8
  store i64 %64, ptr %PC, align 8
  %65 = add i64 %64, 3
  store i64 %65, ptr %NEXT_PC, align 8
  %66 = load i32, ptr %ECX, align 4
  %67 = zext i32 %66 to i64
  %68 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i26 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv.i12.i = zext i1 %call.i.i.i26 to i8
  %cf.i.i27 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i27, align 1
  %conv.i.i.i.i28 = trunc i32 %66 to i8
  %69 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i28)
  %70 = and i8 %69, 1
  %conv.i.i.i29 = xor i8 %70, 1
  %pf.i.i.i30 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i29, ptr %pf.i.i.i30, align 1
  %af.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i31, align 1
  %cmp.i.i.i.i32 = icmp eq i32 %66, 0
  %call.i.i.i.i33 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i32, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv5.i.i.i34 = zext i1 %call.i.i.i.i33 to i8
  %zf.i.i.i35 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i34, ptr %zf.i.i.i35, align 1
  %cmp.i27.i.i.i36 = icmp slt i32 %66, 0
  %call1.i.i.i.i37 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i36, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv8.i.i.i38 = zext i1 %call1.i.i.i.i37 to i8
  %sf.i.i.i39 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i38, ptr %sf.i.i.i39, align 1
  %xor.i28.i.i.i40 = lshr i32 %66, 31
  %call.i30.i.i.i41 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %66, i32 noundef 0, i32 noundef %66) #15
  %conv11.i.i.i42 = zext i1 %call.i30.i.i.i41 to i8
  %of.i.i.i43 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i42, ptr %of.i.i.i43, align 1
  store ptr %68, ptr %MEMORY, align 8
  br label %71

71:                                               ; preds = %63
  %72 = load i64, ptr %NEXT_PC, align 8
  store i64 %72, ptr %PC, align 8
  %73 = add i64 %72, 3
  store i64 %73, ptr %NEXT_PC, align 8
  %74 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %75 = load i8, ptr %zf.i, align 1
  store i8 %75, ptr %CL, align 1
  store ptr %74, ptr %MEMORY, align 8
  br label %76

76:                                               ; preds = %71
  %77 = load i64, ptr %NEXT_PC, align 8
  store i64 %77, ptr %PC, align 8
  %78 = add i64 %77, 2
  store i64 %78, ptr %NEXT_PC, align 8
  %79 = load i8, ptr %AL, align 1
  %80 = zext i8 %79 to i64
  %81 = load i8, ptr %CL, align 1
  %82 = zext i8 %81 to i64
  %83 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %82, %80
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i65 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i65, align 1
  %84 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %85 = and i8 %84, 1
  %conv.i27.i = xor i8 %85, 1
  %pf.i.i66 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i66, align 1
  %86 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i67 = and i32 %86, 255
  %cmp.i.i.i68 = icmp eq i8 %or3.i.i, 0
  %87 = trunc i64 %80 to i32
  %conv1.i.i.i = and i32 %87, 255
  %88 = trunc i64 %82 to i32
  %conv2.i.i.i69 = and i32 %88, 255
  %call.i.i.i70 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i68, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv3.i.i71 = zext i1 %call.i.i.i70 to i8
  %zf.i.i72 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i71, ptr %zf.i.i72, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i69, i32 noundef %conv.i.i.i67) #15
  %conv6.i.i73 = zext i1 %call4.i.i.i to i8
  %sf.i.i74 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i73, ptr %sf.i.i74, align 1
  %of.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i75, align 1
  %af.i.i76 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i76, align 1
  store ptr %83, ptr %MEMORY, align 8
  br label %89

89:                                               ; preds = %76
  %90 = load i64, ptr %NEXT_PC, align 8
  store i64 %90, ptr %PC, align 8
  %91 = add i64 %90, 2
  store i64 %91, ptr %NEXT_PC, align 8
  %92 = load i8, ptr %AL, align 1
  %93 = zext i8 %92 to i64
  %94 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %93
  %and3.i.i77 = trunc i64 %and3.i15.i to i8
  %cf.i.i78 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i78, align 1
  %95 = and i8 %and3.i.i77, 1
  %conv.i14.i = xor i8 %95, 1
  %pf.i.i79 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i79, align 1
  %96 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i80 = and i32 %96, 255
  %cmp.i.i.i81 = icmp eq i8 %and3.i.i77, 0
  %97 = trunc i64 %93 to i32
  %conv1.i.i.i82 = and i32 %97, 255
  %call.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i81, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv3.i.i84 = zext i1 %call.i.i.i83 to i8
  %zf.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i84, ptr %zf.i.i85, align 1
  %call4.i.i.i86 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i82, i32 noundef 1, i32 noundef %conv.i.i.i80) #15
  %conv6.i.i87 = zext i1 %call4.i.i.i86 to i8
  %sf.i.i88 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i87, ptr %sf.i.i88, align 1
  %of.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i89, align 1
  %af.i.i90 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i90, align 1
  store ptr %94, ptr %MEMORY, align 8
  br label %98

98:                                               ; preds = %89
  %99 = load i64, ptr %NEXT_PC, align 8
  store i64 %99, ptr %PC, align 8
  %100 = add i64 %99, 6
  store i64 %100, ptr %NEXT_PC, align 8
  %101 = load i64, ptr %NEXT_PC, align 8
  %102 = add i64 %101, 5
  %103 = load i64, ptr %NEXT_PC, align 8
  %104 = load ptr, ptr %MEMORY, align 8
  %zf.i48 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %105 = load i8, ptr %zf.i48, align 1
  %tobool.not.i = icmp eq i8 %105, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %102, i64 %103
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %104, ptr %MEMORY, align 8
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = load ptr, ptr %MEMORY, align 8
  ret ptr %107
}

define ptr @BB_2819(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %CL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %EDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %AL = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %RDX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 7, i32 0, i32 0
  %ECX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RCX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 5, i32 0, i32 0
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 4
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 48
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i108 = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i108, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %call.i.i103 = call i32 @__remill_read_memory_32(ptr noundef %11, i64 noundef %10) #15
  %conv.i.i104 = zext i32 %call.i.i103 to i64
  store i64 %conv.i.i104, ptr %RCX, align 8
  store ptr %11, ptr %MEMORY, align 8
  br label %12

12:                                               ; preds = %7
  %13 = load i64, ptr %NEXT_PC, align 8
  store i64 %13, ptr %PC, align 8
  %14 = add i64 %13, 3
  store i64 %14, ptr %NEXT_PC, align 8
  %15 = load i64, ptr %RCX, align 8
  %16 = load ptr, ptr %MEMORY, align 8
  %conv.i.i1 = trunc i64 %15 to i32
  %add.i.i2 = add i32 1, %conv.i.i1
  %conv.i22.i3 = zext i32 %add.i.i2 to i64
  store i64 %conv.i22.i3, ptr %RCX, align 8
  %cmp.i.i.i4 = icmp ult i32 %add.i.i2, %conv.i.i1
  %cmp1.i.i.i5 = icmp ult i32 %add.i.i2, 1
  %17 = or i1 %cmp.i.i.i4, %cmp1.i.i.i5
  %call.i.i.i6 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %17, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv.i23.i7 = zext i1 %call.i.i.i6 to i8
  %cf.i.i8 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i7, ptr %cf.i.i8, align 1
  %conv.i.i.i.i9 = trunc i32 %add.i.i2 to i8
  %18 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i9)
  %19 = and i8 %18, 1
  %conv.i.i.i10 = xor i8 %19, 1
  %pf.i.i.i11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i10, ptr %pf.i.i.i11, align 1
  %xor.i.i.i.i12 = xor i32 %add.i.i2, 1
  %xor1.i.i.i.i13 = xor i32 %xor.i.i.i.i12, %conv.i.i1
  %20 = trunc i32 %xor1.i.i.i.i13 to i8
  %21 = lshr i8 %20, 4
  %conv2.i.i.i14 = and i8 %21, 1
  %af.i.i.i15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i14, ptr %af.i.i.i15, align 1
  %cmp.i.i.i.i16 = icmp eq i32 %add.i.i2, 0
  %call.i.i.i.i17 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i16, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv5.i.i.i18 = zext i1 %call.i.i.i.i17 to i8
  %zf.i.i.i19 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i18, ptr %zf.i.i.i19, align 1
  %cmp.i27.i.i.i20 = icmp slt i32 %add.i.i2, 0
  %call1.i.i.i.i21 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i20, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv8.i.i.i22 = zext i1 %call1.i.i.i.i21 to i8
  %sf.i.i.i23 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i22, ptr %sf.i.i.i23, align 1
  %shr8.i.i.i.i24 = xor i32 %add.i.i2, %conv.i.i1
  %xor.i28.i.i.i25 = lshr i32 %shr8.i.i.i.i24, 31
  %xor3.i.i.i.i26 = lshr i32 %xor.i.i.i.i12, 31
  %add.i.i.i.i27 = add nuw nsw i32 %xor.i28.i.i.i25, %xor3.i.i.i.i26
  %cmp.i29.i.i.i28 = icmp eq i32 %add.i.i.i.i27, 2
  %call.i30.i.i.i29 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i28, i32 noundef %conv.i.i1, i32 noundef 1, i32 noundef %add.i.i2) #15
  %conv11.i.i.i30 = zext i1 %call.i30.i.i.i29 to i8
  %of.i.i.i31 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i30, ptr %of.i.i.i31, align 1
  store ptr %16, ptr %MEMORY, align 8
  br label %22

22:                                               ; preds = %12
  %23 = load i64, ptr %NEXT_PC, align 8
  store i64 %23, ptr %PC, align 8
  %24 = add i64 %23, 2
  store i64 %24, ptr %NEXT_PC, align 8
  %25 = load i64, ptr %RAX, align 8
  %26 = load i32, ptr %ECX, align 4
  %27 = zext i32 %26 to i64
  %28 = load ptr, ptr %MEMORY, align 8
  %call.i.i99 = call ptr @__remill_write_memory_32(ptr noundef %28, i64 noundef %25, i32 noundef %26) #15
  store ptr %call.i.i99, ptr %MEMORY, align 8
  br label %29

29:                                               ; preds = %22
  %30 = load i64, ptr %NEXT_PC, align 8
  store i64 %30, ptr %PC, align 8
  %31 = add i64 %30, 7
  store i64 %31, ptr %NEXT_PC, align 8
  %32 = load i64, ptr %NEXT_PC, align 8
  %33 = add i64 %32, 10301
  %34 = load ptr, ptr %MEMORY, align 8
  %call.i.i107 = call i64 @__remill_read_memory_64(ptr noundef %34, i64 noundef %33) #15
  store i64 %call.i.i107, ptr %RAX, align 8
  store ptr %34, ptr %MEMORY, align 8
  br label %35

35:                                               ; preds = %29
  %36 = load i64, ptr %NEXT_PC, align 8
  store i64 %36, ptr %PC, align 8
  %37 = add i64 %36, 4
  store i64 %37, ptr %NEXT_PC, align 8
  %38 = load i64, ptr %RAX, align 8
  %39 = load ptr, ptr %MEMORY, align 8
  store i64 %38, ptr %RAX, align 8
  %call.i.i.i32 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv.i.i33 = zext i1 %call.i.i.i32 to i8
  %cf.i.i34 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i.i33, ptr %cf.i.i34, align 1
  %conv.i.i.i.i35 = trunc i64 %38 to i8
  %40 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i35)
  %41 = and i8 %40, 1
  %conv.i.i.i36 = xor i8 %41, 1
  %pf.i.i.i37 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i36, ptr %pf.i.i.i37, align 1
  %af.i.i.i38 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i38, align 1
  %cmp.i.i.i.i39 = icmp eq i64 %38, 0
  %call.i.i.i.i40 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i39, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv5.i.i.i41 = zext i1 %call.i.i.i.i40 to i8
  %zf.i.i.i42 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i41, ptr %zf.i.i.i42, align 1
  %cmp.i27.i.i.i43 = icmp slt i64 %38, 0
  %call1.i.i.i.i44 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i43, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv8.i.i.i45 = zext i1 %call1.i.i.i.i44 to i8
  %sf.i.i.i46 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i45, ptr %sf.i.i.i46, align 1
  %xor.i28.i.i.i47 = lshr i64 %38, 63
  %call.i30.i.i.i48 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i64 noundef %38, i64 noundef 0, i64 noundef %38) #15
  %conv11.i.i.i49 = zext i1 %call.i30.i.i.i48 to i8
  %of.i.i.i50 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i49, ptr %of.i.i.i50, align 1
  store ptr %39, ptr %MEMORY, align 8
  br label %42

42:                                               ; preds = %35
  %43 = load i64, ptr %NEXT_PC, align 8
  store i64 %43, ptr %PC, align 8
  %44 = add i64 %43, 7
  store i64 %44, ptr %NEXT_PC, align 8
  %45 = load i64, ptr %RBP, align 8
  %46 = sub i64 %45, 160
  %47 = load i64, ptr %RAX, align 8
  %48 = load ptr, ptr %MEMORY, align 8
  %call.i.i100 = call ptr @__remill_write_memory_64(ptr noundef %48, i64 noundef %46, i64 noundef %47) #15
  store ptr %call.i.i100, ptr %MEMORY, align 8
  br label %49

49:                                               ; preds = %42
  %50 = load i64, ptr %NEXT_PC, align 8
  store i64 %50, ptr %PC, align 8
  %51 = add i64 %50, 7
  store i64 %51, ptr %NEXT_PC, align 8
  %52 = load i64, ptr %NEXT_PC, align 8
  %53 = add i64 %52, 9963
  %54 = load ptr, ptr %MEMORY, align 8
  %call.i.i106 = call i64 @__remill_read_memory_64(ptr noundef %54, i64 noundef %53) #15
  store i64 %call.i.i106, ptr %RAX, align 8
  store ptr %54, ptr %MEMORY, align 8
  br label %55

55:                                               ; preds = %49
  %56 = load i64, ptr %NEXT_PC, align 8
  store i64 %56, ptr %PC, align 8
  %57 = add i64 %56, 2
  store i64 %57, ptr %NEXT_PC, align 8
  %58 = load i64, ptr %RAX, align 8
  %59 = load ptr, ptr %MEMORY, align 8
  %call.i.i101 = call i32 @__remill_read_memory_32(ptr noundef %59, i64 noundef %58) #15
  %conv.i.i102 = zext i32 %call.i.i101 to i64
  store i64 %conv.i.i102, ptr %RDX, align 8
  store ptr %59, ptr %MEMORY, align 8
  br label %60

60:                                               ; preds = %55
  %61 = load i64, ptr %NEXT_PC, align 8
  store i64 %61, ptr %PC, align 8
  %62 = add i64 %61, 7
  store i64 %62, ptr %NEXT_PC, align 8
  %63 = load i64, ptr %NEXT_PC, align 8
  %64 = add i64 %63, 9746
  %65 = load ptr, ptr %MEMORY, align 8
  %call.i.i105 = call i64 @__remill_read_memory_64(ptr noundef %65, i64 noundef %64) #15
  store i64 %call.i.i105, ptr %RAX, align 8
  store ptr %65, ptr %MEMORY, align 8
  br label %66

66:                                               ; preds = %60
  %67 = load i64, ptr %NEXT_PC, align 8
  store i64 %67, ptr %PC, align 8
  %68 = add i64 %67, 3
  store i64 %68, ptr %NEXT_PC, align 8
  %69 = load i64, ptr %RAX, align 8
  %70 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i32 @__remill_read_memory_32(ptr noundef %70, i64 noundef %69) #15
  %sub.i.i = sub i32 %call.i.i, 10
  %cmp.i.i.i51 = icmp ult i32 %call.i.i, 10
  %call.i.i.i52 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %cmp.i.i.i51, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv.i9.i = zext i1 %call.i.i.i52 to i8
  %cf.i.i53 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i9.i, ptr %cf.i.i53, align 1
  %conv.i.i.i.i54 = trunc i32 %sub.i.i to i8
  %71 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i54)
  %72 = and i8 %71, 1
  %conv.i.i.i55 = xor i8 %72, 1
  %pf.i.i.i56 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i55, ptr %pf.i.i.i56, align 1
  %xor.i.i.i.i57 = xor i32 %call.i.i, 10
  %xor1.i.i.i.i58 = xor i32 %xor.i.i.i.i57, %sub.i.i
  %73 = trunc i32 %xor1.i.i.i.i58 to i8
  %74 = lshr i8 %73, 4
  %conv2.i.i.i59 = and i8 %74, 1
  %af.i.i.i60 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i59, ptr %af.i.i.i60, align 1
  %cmp.i.i.i.i61 = icmp eq i32 %call.i.i, 10
  %call.i.i.i.i62 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i61, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv5.i.i.i63 = zext i1 %call.i.i.i.i62 to i8
  %zf.i.i.i64 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i63, ptr %zf.i.i.i64, align 1
  %cmp.i27.i.i.i65 = icmp slt i32 %sub.i.i, 0
  %call1.i.i.i.i66 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i65, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv8.i.i.i67 = zext i1 %call1.i.i.i.i66 to i8
  %sf.i.i.i68 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i67, ptr %sf.i.i.i68, align 1
  %xor.i28.i.i.i69 = lshr i32 %xor.i.i.i.i57, 31
  %shr9.i.i.i.i = xor i32 %sub.i.i, %call.i.i
  %xor3.i.i.i.i70 = lshr i32 %shr9.i.i.i.i, 31
  %add.i.i.i.i71 = add nuw nsw i32 %xor3.i.i.i.i70, %xor.i28.i.i.i69
  %cmp.i29.i.i.i72 = icmp eq i32 %add.i.i.i.i71, 2
  %call.i30.i.i.i73 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i72, i32 noundef %call.i.i, i32 noundef 10, i32 noundef %sub.i.i) #15
  %conv11.i.i.i74 = zext i1 %call.i30.i.i.i73 to i8
  %of.i.i.i75 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i74, ptr %of.i.i.i75, align 1
  store ptr %70, ptr %MEMORY, align 8
  br label %75

75:                                               ; preds = %66
  %76 = load i64, ptr %NEXT_PC, align 8
  store i64 %76, ptr %PC, align 8
  %77 = add i64 %76, 3
  store i64 %77, ptr %NEXT_PC, align 8
  %78 = load ptr, ptr %MEMORY, align 8
  %sf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  %79 = load i8, ptr %sf.i, align 1
  %tobool.i = icmp ne i8 %79, 0
  %of.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  %80 = load i8, ptr %of.i, align 1
  %tobool2.i = icmp ne i8 %80, 0
  %cmp.i.i = xor i1 %tobool.i, %tobool2.i
  %conv.i = zext i1 %cmp.i.i to i8
  store i8 %conv.i, ptr %AL, align 1
  store ptr %78, ptr %MEMORY, align 8
  br label %81

81:                                               ; preds = %75
  %82 = load i64, ptr %NEXT_PC, align 8
  store i64 %82, ptr %PC, align 8
  %83 = add i64 %82, 2
  store i64 %83, ptr %NEXT_PC, align 8
  %84 = load i32, ptr %EDX, align 4
  %85 = zext i32 %84 to i64
  %86 = load ptr, ptr %MEMORY, align 8
  %conv.i11.i = and i64 %85, 4294967295
  store i64 %conv.i11.i, ptr %RCX, align 8
  store ptr %86, ptr %MEMORY, align 8
  br label %87

87:                                               ; preds = %81
  %88 = load i64, ptr %NEXT_PC, align 8
  store i64 %88, ptr %PC, align 8
  %89 = add i64 %88, 3
  store i64 %89, ptr %NEXT_PC, align 8
  %90 = load i64, ptr %RCX, align 8
  %91 = load ptr, ptr %MEMORY, align 8
  %conv.i.i = trunc i64 %90 to i32
  %add.i.i = add i32 1, %conv.i.i
  %conv.i22.i = zext i32 %add.i.i to i64
  store i64 %conv.i22.i, ptr %RCX, align 8
  %cmp.i.i.i = icmp ult i32 %add.i.i, %conv.i.i
  %cmp1.i.i.i = icmp ult i32 %add.i.i, 1
  %92 = or i1 %cmp.i.i.i, %cmp1.i.i.i
  %call.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext %92, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv.i23.i = zext i1 %call.i.i.i to i8
  %cf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i23.i, ptr %cf.i.i, align 1
  %conv.i.i.i.i = trunc i32 %add.i.i to i8
  %93 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i)
  %94 = and i8 %93, 1
  %conv.i.i.i = xor i8 %94, 1
  %pf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i, ptr %pf.i.i.i, align 1
  %xor.i.i.i.i = xor i32 %add.i.i, 1
  %xor1.i.i.i.i = xor i32 %xor.i.i.i.i, %conv.i.i
  %95 = trunc i32 %xor1.i.i.i.i to i8
  %96 = lshr i8 %95, 4
  %conv2.i.i.i = and i8 %96, 1
  %af.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %conv2.i.i.i, ptr %af.i.i.i, align 1
  %cmp.i.i.i.i = icmp eq i32 %add.i.i, 0
  %call.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv5.i.i.i = zext i1 %call.i.i.i.i to i8
  %zf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i, ptr %zf.i.i.i, align 1
  %cmp.i27.i.i.i = icmp slt i32 %add.i.i, 0
  %call1.i.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv8.i.i.i = zext i1 %call1.i.i.i.i to i8
  %sf.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i, ptr %sf.i.i.i, align 1
  %shr8.i.i.i.i = xor i32 %add.i.i, %conv.i.i
  %xor.i28.i.i.i = lshr i32 %shr8.i.i.i.i, 31
  %xor3.i.i.i.i = lshr i32 %xor.i.i.i.i, 31
  %add.i.i.i.i = add nuw nsw i32 %xor.i28.i.i.i, %xor3.i.i.i.i
  %cmp.i29.i.i.i = icmp eq i32 %add.i.i.i.i, 2
  %call.i30.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i29.i.i.i, i32 noundef %conv.i.i, i32 noundef 1, i32 noundef %add.i.i) #15
  %conv11.i.i.i = zext i1 %call.i30.i.i.i to i8
  %of.i.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i, ptr %of.i.i.i, align 1
  store ptr %91, ptr %MEMORY, align 8
  br label %97

97:                                               ; preds = %87
  %98 = load i64, ptr %NEXT_PC, align 8
  store i64 %98, ptr %PC, align 8
  %99 = add i64 %98, 3
  store i64 %99, ptr %NEXT_PC, align 8
  %100 = load i64, ptr %RCX, align 8
  %101 = load i32, ptr %EDX, align 4
  %102 = zext i32 %101 to i64
  %103 = load ptr, ptr %MEMORY, align 8
  %conv.i.i94 = trunc i64 %100 to i32
  %sext.i = shl i64 %100, 32
  %conv.i28.i = ashr exact i64 %sext.i, 32
  %sext32.i = shl i64 %102, 32
  %conv.i29.i = ashr exact i64 %sext32.i, 32
  %mul.i.i = mul nsw i64 %conv.i29.i, %conv.i28.i
  %conv.i31.i = and i64 %mul.i.i, 4294967295
  store i64 %conv.i31.i, ptr %RCX, align 8
  %104 = add nsw i64 %mul.i.i, -2147483648
  %cmp.i.i.i95 = icmp ult i64 %104, -4294967296
  %call.i.i.i96 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext %cmp.i.i.i95, i32 noundef %conv.i.i94, i32 noundef %101, i64 noundef %mul.i.i) #15
  %frombool.i.i = zext i1 %call.i.i.i96 to i8
  %cf.i.i97 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %frombool.i.i, ptr %cf.i.i97, align 1
  %call1.i.i = call zeroext i8 @__remill_undefined_8() #15
  %pf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %call1.i.i, ptr %pf.i.i, align 1
  %af.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 %call1.i.i, ptr %af.i.i, align 1
  %zf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %call1.i.i, ptr %zf.i.i, align 1
  %sf.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %call1.i.i, ptr %sf.i.i, align 1
  %of.i.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %frombool.i.i, ptr %of.i.i, align 1
  store ptr %103, ptr %MEMORY, align 8
  br label %105

105:                                              ; preds = %97
  %106 = load i64, ptr %NEXT_PC, align 8
  store i64 %106, ptr %PC, align 8
  %107 = add i64 %106, 3
  store i64 %107, ptr %NEXT_PC, align 8
  %108 = load i64, ptr %RCX, align 8
  %109 = load ptr, ptr %MEMORY, align 8
  %conv.i.i109 = trunc i64 %108 to i32
  %and3.i.i = and i32 1, %conv.i.i109
  %conv.i22.i110 = zext i32 %and3.i.i to i64
  store i64 %conv.i22.i110, ptr %RCX, align 8
  %cf.i.i111 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i111, align 1
  %conv.i.i.i112 = trunc i32 %and3.i.i to i8
  %110 = and i8 %conv.i.i.i112, 1
  %conv.i23.i113 = xor i8 %110, 1
  %pf.i.i114 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i23.i113, ptr %pf.i.i114, align 1
  %cmp.i.i.i115 = icmp eq i32 %and3.i.i, 0
  %call.i.i.i116 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i115, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv3.i.i = zext i1 %call.i.i.i116 to i8
  %zf.i.i117 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i, ptr %zf.i.i117, align 1
  %call1.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv.i.i109, i32 noundef 1, i32 noundef %and3.i.i) #15
  %conv6.i.i = zext i1 %call1.i.i.i to i8
  %sf.i.i118 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i, ptr %sf.i.i118, align 1
  %of.i.i119 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i119, align 1
  %af.i.i120 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i120, align 1
  store ptr %109, ptr %MEMORY, align 8
  br label %111

111:                                              ; preds = %105
  %112 = load i64, ptr %NEXT_PC, align 8
  store i64 %112, ptr %PC, align 8
  %113 = add i64 %112, 3
  store i64 %113, ptr %NEXT_PC, align 8
  %114 = load i32, ptr %ECX, align 4
  %115 = zext i32 %114 to i64
  %116 = load ptr, ptr %MEMORY, align 8
  %call.i.i.i76 = call zeroext i1 (i1, ...) @__remill_flag_computation_carry(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv.i12.i = zext i1 %call.i.i.i76 to i8
  %cf.i.i77 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 %conv.i12.i, ptr %cf.i.i77, align 1
  %conv.i.i.i.i78 = trunc i32 %114 to i8
  %117 = call i8 @llvm.ctpop.i8(i8 %conv.i.i.i.i78)
  %118 = and i8 %117, 1
  %conv.i.i.i79 = xor i8 %118, 1
  %pf.i.i.i80 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i.i.i79, ptr %pf.i.i.i80, align 1
  %af.i.i.i81 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  store i8 0, ptr %af.i.i.i81, align 1
  %cmp.i.i.i.i82 = icmp eq i32 %114, 0
  %call.i.i.i.i83 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i.i82, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv5.i.i.i84 = zext i1 %call.i.i.i.i83 to i8
  %zf.i.i.i85 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv5.i.i.i84, ptr %zf.i.i.i85, align 1
  %cmp.i27.i.i.i86 = icmp slt i32 %114, 0
  %call1.i.i.i.i87 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i27.i.i.i86, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv8.i.i.i88 = zext i1 %call1.i.i.i.i87 to i8
  %sf.i.i.i89 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv8.i.i.i88, ptr %sf.i.i.i89, align 1
  %xor.i28.i.i.i90 = lshr i32 %114, 31
  %call.i30.i.i.i91 = call zeroext i1 (i1, ...) @__remill_flag_computation_overflow(i1 noundef zeroext false, i32 noundef %114, i32 noundef 0, i32 noundef %114) #15
  %conv11.i.i.i92 = zext i1 %call.i30.i.i.i91 to i8
  %of.i.i.i93 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 %conv11.i.i.i92, ptr %of.i.i.i93, align 1
  store ptr %116, ptr %MEMORY, align 8
  br label %119

119:                                              ; preds = %111
  %120 = load i64, ptr %NEXT_PC, align 8
  store i64 %120, ptr %PC, align 8
  %121 = add i64 %120, 3
  store i64 %121, ptr %NEXT_PC, align 8
  %122 = load ptr, ptr %MEMORY, align 8
  %zf.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %123 = load i8, ptr %zf.i, align 1
  store i8 %123, ptr %CL, align 1
  store ptr %122, ptr %MEMORY, align 8
  br label %124

124:                                              ; preds = %119
  %125 = load i64, ptr %NEXT_PC, align 8
  store i64 %125, ptr %PC, align 8
  %126 = add i64 %125, 2
  store i64 %126, ptr %NEXT_PC, align 8
  %127 = load i8, ptr %AL, align 1
  %128 = zext i8 %127 to i64
  %129 = load i8, ptr %CL, align 1
  %130 = zext i8 %129 to i64
  %131 = load ptr, ptr %MEMORY, align 8
  %or3.i28.i = or i64 %130, %128
  %or3.i.i = trunc i64 %or3.i28.i to i8
  store i8 %or3.i.i, ptr %AL, align 1
  %cf.i.i121 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i121, align 1
  %132 = call i8 @llvm.ctpop.i8(i8 %or3.i.i)
  %133 = and i8 %132, 1
  %conv.i27.i = xor i8 %133, 1
  %pf.i.i122 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i27.i, ptr %pf.i.i122, align 1
  %134 = trunc i64 %or3.i28.i to i32
  %conv.i.i.i123 = and i32 %134, 255
  %cmp.i.i.i124 = icmp eq i8 %or3.i.i, 0
  %135 = trunc i64 %128 to i32
  %conv1.i.i.i = and i32 %135, 255
  %136 = trunc i64 %130 to i32
  %conv2.i.i.i125 = and i32 %136, 255
  %call.i.i.i126 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i124, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv3.i.i127 = zext i1 %call.i.i.i126 to i8
  %zf.i.i128 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i127, ptr %zf.i.i128, align 1
  %cmp.i19.i.i = icmp slt i8 %or3.i.i, 0
  %call4.i.i.i = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext %cmp.i19.i.i, i32 noundef %conv1.i.i.i, i32 noundef %conv2.i.i.i125, i32 noundef %conv.i.i.i123) #15
  %conv6.i.i129 = zext i1 %call4.i.i.i to i8
  %sf.i.i130 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i129, ptr %sf.i.i130, align 1
  %of.i.i131 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i131, align 1
  %af.i.i132 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call16.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call16.i, ptr %af.i.i132, align 1
  store ptr %131, ptr %MEMORY, align 8
  br label %137

137:                                              ; preds = %124
  %138 = load i64, ptr %NEXT_PC, align 8
  store i64 %138, ptr %PC, align 8
  %139 = add i64 %138, 2
  store i64 %139, ptr %NEXT_PC, align 8
  %140 = load i8, ptr %AL, align 1
  %141 = zext i8 %140 to i64
  %142 = load ptr, ptr %MEMORY, align 8
  %and3.i15.i = and i64 1, %141
  %and3.i.i133 = trunc i64 %and3.i15.i to i8
  %cf.i.i134 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 1
  store i8 0, ptr %cf.i.i134, align 1
  %143 = and i8 %and3.i.i133, 1
  %conv.i14.i = xor i8 %143, 1
  %pf.i.i135 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 3
  store i8 %conv.i14.i, ptr %pf.i.i135, align 1
  %144 = trunc i64 %and3.i15.i to i32
  %conv.i.i.i136 = and i32 %144, 255
  %cmp.i.i.i137 = icmp eq i8 %and3.i.i133, 0
  %145 = trunc i64 %141 to i32
  %conv1.i.i.i138 = and i32 %145, 255
  %call.i.i.i139 = call zeroext i1 (i1, ...) @__remill_flag_computation_zero(i1 noundef zeroext %cmp.i.i.i137, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv3.i.i140 = zext i1 %call.i.i.i139 to i8
  %zf.i.i141 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  store i8 %conv3.i.i140, ptr %zf.i.i141, align 1
  %call4.i.i.i142 = call zeroext i1 (i1, ...) @__remill_flag_computation_sign(i1 noundef zeroext false, i32 noundef %conv1.i.i.i138, i32 noundef 1, i32 noundef %conv.i.i.i136) #15
  %conv6.i.i143 = zext i1 %call4.i.i.i142 to i8
  %sf.i.i144 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 9
  store i8 %conv6.i.i143, ptr %sf.i.i144, align 1
  %of.i.i145 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 13
  store i8 0, ptr %of.i.i145, align 1
  %af.i.i146 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 5
  %call7.i = call zeroext i8 @__remill_undefined_8() #16
  store i8 %call7.i, ptr %af.i.i146, align 1
  store ptr %142, ptr %MEMORY, align 8
  br label %146

146:                                              ; preds = %137
  %147 = load i64, ptr %NEXT_PC, align 8
  store i64 %147, ptr %PC, align 8
  %148 = add i64 %147, 6
  store i64 %148, ptr %NEXT_PC, align 8
  %149 = load i64, ptr %NEXT_PC, align 8
  %150 = add i64 %149, 5
  %151 = load i64, ptr %NEXT_PC, align 8
  %152 = load ptr, ptr %MEMORY, align 8
  %zf.i98 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 2, i32 7
  %153 = load i8, ptr %zf.i98, align 1
  %tobool.not.i = icmp eq i8 %153, 0
  %call9.i = call zeroext i1 @__remill_compare_neq(i1 noundef zeroext %tobool.not.i) #16
  %frombool.i = zext i1 %call9.i to i8
  store i8 %frombool.i, ptr %BRANCH_TAKEN, align 1
  %cond1.i.i = select i1 %call9.i, i64 %150, i64 %151
  store i64 %cond1.i.i, ptr %NEXT_PC, align 8
  store ptr %152, ptr %MEMORY, align 8
  %154 = load i64, ptr %NEXT_PC, align 8
  store i64 %154, ptr %PC, align 8
  %155 = load ptr, ptr %MEMORY, align 8
  ret ptr %155
}

define ptr @BB_286c(ptr noalias %state, i64 %program_counter, ptr noalias %memory) #0 {
  %RBP = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 15, i32 0, i32 0
  %RAX = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 1, i32 0, i32 0
  %BRANCH_TAKEN = alloca i8, align 1
  %RETURN_PC = alloca i64, align 8
  %MONITOR = alloca i64, align 8
  %STATE = alloca ptr, align 8
  store ptr %state, ptr %STATE, align 8
  %MEMORY = alloca ptr, align 8
  store ptr %memory, ptr %MEMORY, align 8
  %NEXT_PC = alloca i64, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  %PC = getelementptr inbounds %struct.State.298969, ptr %state, i32 0, i32 0, i32 6, i32 33, i32 0, i32 0
  %CSBASE = alloca i64, align 8
  store i64 0, ptr %CSBASE, align 8
  %SSBASE = alloca i64, align 8
  store i64 0, ptr %SSBASE, align 8
  %ESBASE = alloca i64, align 8
  store i64 0, ptr %ESBASE, align 8
  %DSBASE = alloca i64, align 8
  store i64 0, ptr %DSBASE, align 8
  store i64 %program_counter, ptr %NEXT_PC, align 8
  br label %1

1:                                                ; preds = %0
  %2 = load i64, ptr %NEXT_PC, align 8
  store i64 %2, ptr %PC, align 8
  %3 = add i64 %2, 7
  store i64 %3, ptr %NEXT_PC, align 8
  %4 = load i64, ptr %RBP, align 8
  %5 = sub i64 %4, 160
  %6 = load ptr, ptr %MEMORY, align 8
  %call.i.i = call i64 @__remill_read_memory_64(ptr noundef %6, i64 noundef %5) #15
  store i64 %call.i.i, ptr %RAX, align 8
  store ptr %6, ptr %MEMORY, align 8
  br label %7

7:                                                ; preds = %1
  %8 = load i64, ptr %NEXT_PC, align 8
  store i64 %8, ptr %PC, align 8
  %9 = add i64 %8, 2
  store i64 %9, ptr %NEXT_PC, align 8
  %10 = load i64, ptr %RAX, align 8
  %11 = load ptr, ptr %MEMORY, align 8
  %rip.i = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %10, ptr %rip.i, align 8
  store i64 %10, ptr %NEXT_PC, align 8
  store ptr %11, ptr %MEMORY, align 8
  %12 = load ptr, ptr %MEMORY, align 8
  ret ptr %12
}

; Function Attrs: alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable
define dso_local void @__lifted_declare() local_unnamed_addr #4 {
entry:
  %agg.tmp = alloca %struct.State.298969, align 16
  call void @llvm.memset.p0.i64(ptr noundef nonnull align 16 dereferenceable(3504) %agg.tmp, i8 0, i64 3504, i1 false)
  %call = call ptr @__lifted_bb_entered(ptr noundef nonnull byval(%struct.State.298969) align 16 %agg.tmp, i64 noundef 0, ptr noundef null) #17
  ret void
}

; Function Attrs: nocallback nofree nounwind willreturn memory(argmem: write)
declare void @llvm.memset.p0.i64(ptr nocapture writeonly, i8, i64, i1 immarg) #5

; Function Attrs: mustprogress nounwind willreturn memory(read, argmem: readwrite)
declare ptr @__lifted_bb_entered(ptr noundef byval(%struct.State.298969) align 16, i64 noundef, ptr noundef) local_unnamed_addr #6

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rip(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rip = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  %0 = load i64, ptr %rip, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rax(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rax = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 1
  %0 = load i64, ptr %rax, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 9
  %0 = load i64, ptr %rsi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdi(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 11
  %0 = load i64, ptr %rdi, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rcx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 5
  %0 = load i64, ptr %rcx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rdx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 7
  %0 = load i64, ptr %rdx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r8(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 17
  %0 = load i64, ptr %r8, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r9(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 19
  %0 = load i64, ptr %r9, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r10(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 21
  %0 = load i64, ptr %r10, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r11(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 23
  %0 = load i64, ptr %r11, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rsp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  %0 = load i64, ptr %rsp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rflags(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 3
  %0 = load i64, ptr %rflag, align 16, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbx(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 3
  %0 = load i64, ptr %rbx, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_rbp(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 15
  %0 = load i64, ptr %rbp, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r12(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 25
  %0 = load i64, ptr %r12, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r13(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 27
  %0 = load i64, ptr %r13, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r14(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 29
  %0 = load i64, ptr %r14, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable
define dso_local i64 @__extract_r15(ptr noalias nocapture noundef readonly %state) local_unnamed_addr #7 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 31
  %0 = load i64, ptr %r15, align 8, !tbaa !23
  ret i64 %0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rax(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rax = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 1
  store i64 %val, ptr %rax, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rcx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rcx = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 5
  store i64 %val, ptr %rcx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdx = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 7
  store i64 %val, ptr %rdx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsi = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 9
  store i64 %val, ptr %rsi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rdi(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rdi = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 11
  store i64 %val, ptr %rdi, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r8(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r8 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 17
  store i64 %val, ptr %r8, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r9(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r9 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 19
  store i64 %val, ptr %r9, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r10(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r10 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 21
  store i64 %val, ptr %r10, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r11(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r11 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 23
  store i64 %val, ptr %r11, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rsp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rsp = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 13
  store i64 %val, ptr %rsp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rflags(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rflag = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 3
  store i64 %val, ptr %rflag, align 16, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rip(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %val, ptr %rip, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbx(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbx = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 3
  store i64 %val, ptr %rbx, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_rbp(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %rbp = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 15
  store i64 %val, ptr %rbp, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r12(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r12 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 25
  store i64 %val, ptr %r12, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r13(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r13 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 27
  store i64 %val, ptr %r13, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r14(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r14 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 29
  store i64 %val, ptr %r14, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local void @__store_r15(ptr noalias nocapture noundef writeonly %state, i64 noundef %val) local_unnamed_addr #8 {
entry:
  %r15 = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 31
  store i64 %val, ptr %r15, align 8, !tbaa !23
  ret void
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg(ptr noalias nocapture %state, i64 %rva, ptr noalias nocapture %memory, i64 %base) #9 {
entry:
  %mem_var = alloca ptr, align 8
  %pc_var = alloca i64, align 8
  store ptr %memory, ptr %mem_var, align 8
  %entry_pc = add i64 %rva, %base
  store i64 %entry_pc, ptr %pc_var, align 4
  switch i64 %rva, label %dead_end [
    i64 8464, label %bb_2110
    i64 8536, label %bb_2158
    i64 8751, label %bb_222F
    i64 8757, label %bb_2235
    i64 8811, label %bb_226B
    i64 8890, label %bb_22BA
    i64 8896, label %bb_22C0
    i64 8925, label %bb_22DD
    i64 8979, label %bb_2313
    i64 9092, label %bb_2384
    i64 9098, label %bb_238A
    i64 9152, label %bb_23C0
    i64 9257, label %bb_2429
    i64 9263, label %bb_242F
    i64 9317, label %bb_2465
    i64 9397, label %bb_24B5
    i64 9403, label %bb_24BB
    i64 9457, label %bb_24F1
    i64 9568, label %bb_2560
    i64 9574, label %bb_2566
    i64 9628, label %bb_259C
    i64 9741, label %bb_260D
    i64 9747, label %bb_2613
    i64 9801, label %bb_2649
    i64 9922, label %bb_26C2
    i64 9931, label %bb_26CB
    i64 9985, label %bb_2701
    i64 10067, label %bb_2753
    i64 10076, label %bb_275C
    i64 10130, label %bb_2792
    i64 10202, label %bb_27DA
    i64 10211, label %bb_27E3
    i64 10265, label %bb_2819
    i64 10348, label %bb_286C
    i64 10357, label %bb_2875
    i64 10389, label %bb_2895
    i64 10443, label %bb_28CB
    i64 10457, label %bb_28D9
    i64 10529, label %bb_2921
    i64 10538, label %bb_292A
    i64 10552, label %bb_2938
    i64 10561, label %bb_2941
    i64 10580, label %bb_2954
    i64 10634, label %bb_298A
    i64 10700, label %bb_29CC
    i64 -281474976710656, label %bb_FFFF000000000000
    i64 -281474976710655, label %bb_FFFF000000000001
  ]

dead_end:                                         ; preds = %bb_FFFF000000000001, %bb_FFFF000000000000, %bb_298A, %bb_2954, %bb_2941, %bb_2938, %bb_292A, %bb_2921, %bb_28D9, %bb_28CB, %bb_2895, %bb_2875, %bb_286C, %bb_2819, %bb_27E3, %bb_27DA, %bb_2792, %bb_275C, %bb_2753, %bb_2701, %bb_26CB, %bb_26C2, %bb_2649, %bb_2613, %bb_260D, %bb_259C, %bb_2566, %bb_2560, %bb_24F1, %bb_24BB, %bb_24B5, %bb_2465, %bb_242F, %bb_2429, %bb_23C0, %bb_238A, %bb_2384, %bb_2313, %bb_22DD, %bb_22C0, %bb_22BA, %bb_226B, %bb_2235, %bb_222F, %bb_2158, %bb_2110, %entry
  %0 = load ptr, ptr %mem_var, align 8
  ret ptr %0

bb_2110:                                          ; preds = %entry
  %block_pc = add i64 8464, %base
  store i64 %block_pc, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc)
  %1 = load ptr, ptr %mem_var, align 8
  %2 = load i64, ptr %pc_var, align 4
  %3 = call ptr @__lifted_bb_entered(ptr %state, i64 8464, ptr %1)
  %4 = call ptr @BB_2110(ptr %state, i64 %2, ptr %1) #18
  store ptr %4, ptr %mem_var, align 8
  %5 = call i64 @__extract_rip(ptr %state)
  store i64 %5, ptr %pc_var, align 4
  %next_rva = sub i64 %5, %base
  switch i64 %next_rva, label %dead_end [
    i64 8536, label %bb_2158
  ]

bb_2158:                                          ; preds = %bb_2110, %entry
  %block_pc1 = add i64 8536, %base
  store i64 %block_pc1, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc1)
  %6 = load ptr, ptr %mem_var, align 8
  %7 = load i64, ptr %pc_var, align 4
  %8 = call ptr @__lifted_bb_entered(ptr %state, i64 8536, ptr %6)
  %9 = call ptr @BB_2158(ptr %state, i64 %7, ptr %6) #18
  store ptr %9, ptr %mem_var, align 8
  %10 = call i64 @__extract_rip(ptr %state)
  store i64 %10, ptr %pc_var, align 4
  %next_rva2 = sub i64 %10, %base
  switch i64 %next_rva2, label %dead_end [
    i64 8751, label %bb_222F
  ]

bb_222F:                                          ; preds = %bb_2158, %entry
  %block_pc3 = add i64 8751, %base
  store i64 %block_pc3, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc3)
  %11 = load ptr, ptr %mem_var, align 8
  %12 = load i64, ptr %pc_var, align 4
  %13 = call ptr @__lifted_bb_entered(ptr %state, i64 8751, ptr %11)
  %14 = call ptr @BB_222f(ptr %state, i64 %12, ptr %11) #18
  store ptr %14, ptr %mem_var, align 8
  %15 = call i64 @__extract_rip(ptr %state)
  store i64 %15, ptr %pc_var, align 4
  %next_rva4 = sub i64 %15, %base
  switch i64 %next_rva4, label %dead_end [
    i64 8757, label %bb_2235
    i64 8896, label %bb_22C0
  ]

bb_2235:                                          ; preds = %bb_222F, %entry
  %block_pc5 = add i64 8757, %base
  store i64 %block_pc5, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc5)
  %16 = load ptr, ptr %mem_var, align 8
  %17 = load i64, ptr %pc_var, align 4
  %18 = call ptr @__lifted_bb_entered(ptr %state, i64 8757, ptr %16)
  %19 = call ptr @BB_2235(ptr %state, i64 %17, ptr %16) #18
  store ptr %19, ptr %mem_var, align 8
  %20 = call i64 @__extract_rip(ptr %state)
  store i64 %20, ptr %pc_var, align 4
  %next_rva6 = sub i64 %20, %base
  switch i64 %next_rva6, label %dead_end [
    i64 8811, label %bb_226B
  ]

bb_226B:                                          ; preds = %bb_2235, %entry
  %block_pc7 = add i64 8811, %base
  store i64 %block_pc7, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc7)
  %21 = load ptr, ptr %mem_var, align 8
  %22 = load i64, ptr %pc_var, align 4
  %23 = call ptr @__lifted_bb_entered(ptr %state, i64 8811, ptr %21)
  %24 = call ptr @BB_226b(ptr %state, i64 %22, ptr %21) #18
  store ptr %24, ptr %mem_var, align 8
  %25 = call i64 @__extract_rip(ptr %state)
  store i64 %25, ptr %pc_var, align 4
  %next_rva8 = sub i64 %25, %base
  switch i64 %next_rva8, label %dead_end [
    i64 8890, label %bb_22BA
  ]

bb_22BA:                                          ; preds = %bb_226B, %entry
  %block_pc9 = add i64 8890, %base
  store i64 %block_pc9, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc9)
  %26 = load ptr, ptr %mem_var, align 8
  %27 = load i64, ptr %pc_var, align 4
  %28 = call ptr @__lifted_bb_entered(ptr %state, i64 8890, ptr %26)
  %29 = call ptr @BB_22ba(ptr %state, i64 %27, ptr %26) #18
  store ptr %29, ptr %mem_var, align 8
  %30 = call i64 @__extract_rip(ptr %state)
  store i64 %30, ptr %pc_var, align 4
  %next_rva10 = sub i64 %30, %base
  switch i64 %next_rva10, label %dead_end [
    i64 10580, label %bb_2954
  ]

bb_22C0:                                          ; preds = %bb_222F, %entry
  %block_pc11 = add i64 8896, %base
  store i64 %block_pc11, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc11)
  %31 = load ptr, ptr %mem_var, align 8
  %32 = load i64, ptr %pc_var, align 4
  %33 = call ptr @__lifted_bb_entered(ptr %state, i64 8896, ptr %31)
  %34 = call ptr @BB_22c0(ptr %state, i64 %32, ptr %31) #18
  store ptr %34, ptr %mem_var, align 8
  %35 = call i64 @__extract_rip(ptr %state)
  store i64 %35, ptr %pc_var, align 4
  %next_rva12 = sub i64 %35, %base
  switch i64 %next_rva12, label %dead_end [
    i64 8925, label %bb_22DD
  ]

bb_22DD:                                          ; preds = %bb_24B5, %bb_22C0, %entry
  %block_pc13 = add i64 8925, %base
  store i64 %block_pc13, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc13)
  %36 = load ptr, ptr %mem_var, align 8
  %37 = load i64, ptr %pc_var, align 4
  %38 = call ptr @__lifted_bb_entered(ptr %state, i64 8925, ptr %36)
  %39 = call ptr @BB_22dd(ptr %state, i64 %37, ptr %36) #18
  store ptr %39, ptr %mem_var, align 8
  %40 = call i64 @__extract_rip(ptr %state)
  store i64 %40, ptr %pc_var, align 4
  %next_rva14 = sub i64 %40, %base
  switch i64 %next_rva14, label %dead_end [
    i64 8979, label %bb_2313
  ]

bb_2313:                                          ; preds = %bb_22DD, %entry
  %block_pc15 = add i64 8979, %base
  store i64 %block_pc15, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc15)
  %41 = load ptr, ptr %mem_var, align 8
  %42 = load i64, ptr %pc_var, align 4
  %43 = call ptr @__lifted_bb_entered(ptr %state, i64 8979, ptr %41)
  %44 = call ptr @BB_2313(ptr %state, i64 %42, ptr %41) #18
  store ptr %44, ptr %mem_var, align 8
  %45 = call i64 @__extract_rip(ptr %state)
  store i64 %45, ptr %pc_var, align 4
  %next_rva16 = sub i64 %45, %base
  switch i64 %next_rva16, label %dead_end [
    i64 9092, label %bb_2384
  ]

bb_2384:                                          ; preds = %bb_2313, %entry
  %block_pc17 = add i64 9092, %base
  store i64 %block_pc17, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc17)
  %46 = load ptr, ptr %mem_var, align 8
  %47 = load i64, ptr %pc_var, align 4
  %48 = call ptr @__lifted_bb_entered(ptr %state, i64 9092, ptr %46)
  %49 = call ptr @BB_2384(ptr %state, i64 %47, ptr %46) #18
  store ptr %49, ptr %mem_var, align 8
  %50 = call i64 @__extract_rip(ptr %state)
  store i64 %50, ptr %pc_var, align 4
  %next_rva18 = sub i64 %50, %base
  switch i64 %next_rva18, label %dead_end [
    i64 9098, label %bb_238A
    i64 9403, label %bb_24BB
  ]

bb_238A:                                          ; preds = %bb_2384, %entry
  %block_pc19 = add i64 9098, %base
  store i64 %block_pc19, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc19)
  %51 = load ptr, ptr %mem_var, align 8
  %52 = load i64, ptr %pc_var, align 4
  %53 = call ptr @__lifted_bb_entered(ptr %state, i64 9098, ptr %51)
  %54 = call ptr @BB_238a(ptr %state, i64 %52, ptr %51) #18
  store ptr %54, ptr %mem_var, align 8
  %55 = call i64 @__extract_rip(ptr %state)
  store i64 %55, ptr %pc_var, align 4
  %next_rva20 = sub i64 %55, %base
  switch i64 %next_rva20, label %dead_end [
    i64 9152, label %bb_23C0
  ]

bb_23C0:                                          ; preds = %bb_238A, %entry
  %block_pc21 = add i64 9152, %base
  store i64 %block_pc21, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc21)
  %56 = load ptr, ptr %mem_var, align 8
  %57 = load i64, ptr %pc_var, align 4
  %58 = call ptr @__lifted_bb_entered(ptr %state, i64 9152, ptr %56)
  %59 = call ptr @BB_23c0(ptr %state, i64 %57, ptr %56) #18
  store ptr %59, ptr %mem_var, align 8
  %60 = call i64 @__extract_rip(ptr %state)
  store i64 %60, ptr %pc_var, align 4
  %next_rva22 = sub i64 %60, %base
  switch i64 %next_rva22, label %dead_end [
    i64 9257, label %bb_2429
  ]

bb_2429:                                          ; preds = %bb_23C0, %entry
  %block_pc23 = add i64 9257, %base
  store i64 %block_pc23, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc23)
  %61 = load ptr, ptr %mem_var, align 8
  %62 = load i64, ptr %pc_var, align 4
  %63 = call ptr @__lifted_bb_entered(ptr %state, i64 9257, ptr %61)
  %64 = call ptr @BB_2429(ptr %state, i64 %62, ptr %61) #18
  store ptr %64, ptr %mem_var, align 8
  %65 = call i64 @__extract_rip(ptr %state)
  store i64 %65, ptr %pc_var, align 4
  %next_rva24 = sub i64 %65, %base
  switch i64 %next_rva24, label %dead_end [
    i64 9263, label %bb_242F
  ]

bb_242F:                                          ; preds = %bb_2429, %entry
  %block_pc25 = add i64 9263, %base
  store i64 %block_pc25, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc25)
  %66 = load ptr, ptr %mem_var, align 8
  %67 = load i64, ptr %pc_var, align 4
  %68 = call ptr @__lifted_bb_entered(ptr %state, i64 9263, ptr %66)
  %69 = call ptr @BB_242f(ptr %state, i64 %67, ptr %66) #18
  store ptr %69, ptr %mem_var, align 8
  %70 = call i64 @__extract_rip(ptr %state)
  store i64 %70, ptr %pc_var, align 4
  %next_rva26 = sub i64 %70, %base
  switch i64 %next_rva26, label %dead_end [
    i64 9317, label %bb_2465
  ]

bb_2465:                                          ; preds = %bb_242F, %entry
  %block_pc27 = add i64 9317, %base
  store i64 %block_pc27, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc27)
  %71 = load ptr, ptr %mem_var, align 8
  %72 = load i64, ptr %pc_var, align 4
  %73 = call ptr @__lifted_bb_entered(ptr %state, i64 9317, ptr %71)
  %74 = call ptr @BB_2465(ptr %state, i64 %72, ptr %71) #18
  store ptr %74, ptr %mem_var, align 8
  %75 = call i64 @__extract_rip(ptr %state)
  store i64 %75, ptr %pc_var, align 4
  %next_rva28 = sub i64 %75, %base
  switch i64 %next_rva28, label %dead_end [
    i64 9397, label %bb_24B5
  ]

bb_24B5:                                          ; preds = %bb_2465, %entry
  %block_pc29 = add i64 9397, %base
  store i64 %block_pc29, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc29)
  %76 = load ptr, ptr %mem_var, align 8
  %77 = load i64, ptr %pc_var, align 4
  %78 = call ptr @__lifted_bb_entered(ptr %state, i64 9397, ptr %76)
  %79 = call ptr @BB_24b5(ptr %state, i64 %77, ptr %76) #18
  store ptr %79, ptr %mem_var, align 8
  %80 = call i64 @__extract_rip(ptr %state)
  store i64 %80, ptr %pc_var, align 4
  %next_rva30 = sub i64 %80, %base
  switch i64 %next_rva30, label %dead_end [
    i64 8925, label %bb_22DD
  ]

bb_24BB:                                          ; preds = %bb_2384, %entry
  %block_pc31 = add i64 9403, %base
  store i64 %block_pc31, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc31)
  %81 = load ptr, ptr %mem_var, align 8
  %82 = load i64, ptr %pc_var, align 4
  %83 = call ptr @__lifted_bb_entered(ptr %state, i64 9403, ptr %81)
  %84 = call ptr @BB_24bb(ptr %state, i64 %82, ptr %81) #18
  store ptr %84, ptr %mem_var, align 8
  %85 = call i64 @__extract_rip(ptr %state)
  store i64 %85, ptr %pc_var, align 4
  %next_rva32 = sub i64 %85, %base
  switch i64 %next_rva32, label %dead_end [
    i64 9457, label %bb_24F1
  ]

bb_24F1:                                          ; preds = %bb_24BB, %entry
  %block_pc33 = add i64 9457, %base
  store i64 %block_pc33, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc33)
  %86 = load ptr, ptr %mem_var, align 8
  %87 = load i64, ptr %pc_var, align 4
  %88 = call ptr @__lifted_bb_entered(ptr %state, i64 9457, ptr %86)
  %89 = call ptr @BB_24f1(ptr %state, i64 %87, ptr %86) #18
  store ptr %89, ptr %mem_var, align 8
  %90 = call i64 @__extract_rip(ptr %state)
  store i64 %90, ptr %pc_var, align 4
  %next_rva34 = sub i64 %90, %base
  switch i64 %next_rva34, label %dead_end [
    i64 9568, label %bb_2560
  ]

bb_2560:                                          ; preds = %bb_24F1, %entry
  %block_pc35 = add i64 9568, %base
  store i64 %block_pc35, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc35)
  %91 = load ptr, ptr %mem_var, align 8
  %92 = load i64, ptr %pc_var, align 4
  %93 = call ptr @__lifted_bb_entered(ptr %state, i64 9568, ptr %91)
  %94 = call ptr @BB_2560(ptr %state, i64 %92, ptr %91) #18
  store ptr %94, ptr %mem_var, align 8
  %95 = call i64 @__extract_rip(ptr %state)
  store i64 %95, ptr %pc_var, align 4
  %next_rva36 = sub i64 %95, %base
  switch i64 %next_rva36, label %dead_end [
    i64 9574, label %bb_2566
  ]

bb_2566:                                          ; preds = %bb_286C, %bb_2560, %entry
  %block_pc37 = add i64 9574, %base
  store i64 %block_pc37, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc37)
  %96 = load ptr, ptr %mem_var, align 8
  %97 = load i64, ptr %pc_var, align 4
  %98 = call ptr @__lifted_bb_entered(ptr %state, i64 9574, ptr %96)
  %99 = call ptr @BB_2566(ptr %state, i64 %97, ptr %96) #18
  store ptr %99, ptr %mem_var, align 8
  %100 = call i64 @__extract_rip(ptr %state)
  store i64 %100, ptr %pc_var, align 4
  %next_rva38 = sub i64 %100, %base
  switch i64 %next_rva38, label %dead_end [
    i64 9628, label %bb_259C
  ]

bb_259C:                                          ; preds = %bb_2566, %entry
  %block_pc39 = add i64 9628, %base
  store i64 %block_pc39, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc39)
  %101 = load ptr, ptr %mem_var, align 8
  %102 = load i64, ptr %pc_var, align 4
  %103 = call ptr @__lifted_bb_entered(ptr %state, i64 9628, ptr %101)
  %104 = call ptr @BB_259c(ptr %state, i64 %102, ptr %101) #18
  store ptr %104, ptr %mem_var, align 8
  %105 = call i64 @__extract_rip(ptr %state)
  store i64 %105, ptr %pc_var, align 4
  %next_rva40 = sub i64 %105, %base
  switch i64 %next_rva40, label %dead_end [
    i64 9741, label %bb_260D
  ]

bb_260D:                                          ; preds = %bb_259C, %entry
  %block_pc41 = add i64 9741, %base
  store i64 %block_pc41, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc41)
  %106 = load ptr, ptr %mem_var, align 8
  %107 = load i64, ptr %pc_var, align 4
  %108 = call ptr @__lifted_bb_entered(ptr %state, i64 9741, ptr %106)
  %109 = call ptr @BB_260d(ptr %state, i64 %107, ptr %106) #18
  store ptr %109, ptr %mem_var, align 8
  %110 = call i64 @__extract_rip(ptr %state)
  store i64 %110, ptr %pc_var, align 4
  %next_rva42 = sub i64 %110, %base
  switch i64 %next_rva42, label %dead_end [
    i64 9747, label %bb_2613
    i64 10357, label %bb_2875
  ]

bb_2613:                                          ; preds = %bb_260D, %entry
  %block_pc43 = add i64 9747, %base
  store i64 %block_pc43, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc43)
  %111 = load ptr, ptr %mem_var, align 8
  %112 = load i64, ptr %pc_var, align 4
  %113 = call ptr @__lifted_bb_entered(ptr %state, i64 9747, ptr %111)
  %114 = call ptr @BB_2613(ptr %state, i64 %112, ptr %111) #18
  store ptr %114, ptr %mem_var, align 8
  %115 = call i64 @__extract_rip(ptr %state)
  store i64 %115, ptr %pc_var, align 4
  %next_rva44 = sub i64 %115, %base
  switch i64 %next_rva44, label %dead_end [
    i64 9801, label %bb_2649
  ]

bb_2649:                                          ; preds = %bb_2613, %entry
  %block_pc45 = add i64 9801, %base
  store i64 %block_pc45, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc45)
  %116 = load ptr, ptr %mem_var, align 8
  %117 = load i64, ptr %pc_var, align 4
  %118 = call ptr @__lifted_bb_entered(ptr %state, i64 9801, ptr %116)
  %119 = call ptr @BB_2649(ptr %state, i64 %117, ptr %116) #18
  store ptr %119, ptr %mem_var, align 8
  %120 = call i64 @__extract_rip(ptr %state)
  store i64 %120, ptr %pc_var, align 4
  %next_rva46 = sub i64 %120, %base
  switch i64 %next_rva46, label %dead_end [
    i64 9922, label %bb_26C2
  ]

bb_26C2:                                          ; preds = %bb_2649, %entry
  %block_pc47 = add i64 9922, %base
  store i64 %block_pc47, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc47)
  %121 = load ptr, ptr %mem_var, align 8
  %122 = load i64, ptr %pc_var, align 4
  %123 = call ptr @__lifted_bb_entered(ptr %state, i64 9922, ptr %121)
  %124 = call ptr @BB_26c2(ptr %state, i64 %122, ptr %121) #18
  store ptr %124, ptr %mem_var, align 8
  %125 = call i64 @__extract_rip(ptr %state)
  store i64 %125, ptr %pc_var, align 4
  %next_rva48 = sub i64 %125, %base
  switch i64 %next_rva48, label %dead_end [
    i64 9931, label %bb_26CB
    i64 10076, label %bb_275C
  ]

bb_26CB:                                          ; preds = %bb_26C2, %entry
  %block_pc49 = add i64 9931, %base
  store i64 %block_pc49, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc49)
  %126 = load ptr, ptr %mem_var, align 8
  %127 = load i64, ptr %pc_var, align 4
  %128 = call ptr @__lifted_bb_entered(ptr %state, i64 9931, ptr %126)
  %129 = call ptr @BB_26cb(ptr %state, i64 %127, ptr %126) #18
  store ptr %129, ptr %mem_var, align 8
  %130 = call i64 @__extract_rip(ptr %state)
  store i64 %130, ptr %pc_var, align 4
  %next_rva50 = sub i64 %130, %base
  switch i64 %next_rva50, label %dead_end [
    i64 9985, label %bb_2701
  ]

bb_2701:                                          ; preds = %bb_26CB, %entry
  %block_pc51 = add i64 9985, %base
  store i64 %block_pc51, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc51)
  %131 = load ptr, ptr %mem_var, align 8
  %132 = load i64, ptr %pc_var, align 4
  %133 = call ptr @__lifted_bb_entered(ptr %state, i64 9985, ptr %131)
  %134 = call ptr @BB_2701(ptr %state, i64 %132, ptr %131) #18
  store ptr %134, ptr %mem_var, align 8
  %135 = call i64 @__extract_rip(ptr %state)
  store i64 %135, ptr %pc_var, align 4
  %next_rva52 = sub i64 %135, %base
  switch i64 %next_rva52, label %dead_end [
    i64 10067, label %bb_2753
  ]

bb_2753:                                          ; preds = %bb_2701, %entry
  %block_pc53 = add i64 10067, %base
  store i64 %block_pc53, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc53)
  %136 = load ptr, ptr %mem_var, align 8
  %137 = load i64, ptr %pc_var, align 4
  %138 = call ptr @__lifted_bb_entered(ptr %state, i64 10067, ptr %136)
  %139 = call ptr @BB_2753(ptr %state, i64 %137, ptr %136) #18
  store ptr %139, ptr %mem_var, align 8
  %140 = call i64 @__extract_rip(ptr %state)
  store i64 %140, ptr %pc_var, align 4
  %next_rva54 = sub i64 %140, %base
  switch i64 %next_rva54, label %dead_end [
    i64 10357, label %bb_2875
  ]

bb_275C:                                          ; preds = %bb_26C2, %entry
  %block_pc55 = add i64 10076, %base
  store i64 %block_pc55, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc55)
  %141 = load ptr, ptr %mem_var, align 8
  %142 = load i64, ptr %pc_var, align 4
  %143 = call ptr @__lifted_bb_entered(ptr %state, i64 10076, ptr %141)
  %144 = call ptr @BB_275c(ptr %state, i64 %142, ptr %141) #18
  store ptr %144, ptr %mem_var, align 8
  %145 = call i64 @__extract_rip(ptr %state)
  store i64 %145, ptr %pc_var, align 4
  %next_rva56 = sub i64 %145, %base
  switch i64 %next_rva56, label %dead_end [
    i64 10130, label %bb_2792
  ]

bb_2792:                                          ; preds = %bb_275C, %entry
  %block_pc57 = add i64 10130, %base
  store i64 %block_pc57, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc57)
  %146 = load ptr, ptr %mem_var, align 8
  %147 = load i64, ptr %pc_var, align 4
  %148 = call ptr @__lifted_bb_entered(ptr %state, i64 10130, ptr %146)
  %149 = call ptr @BB_2792(ptr %state, i64 %147, ptr %146) #18
  store ptr %149, ptr %mem_var, align 8
  %150 = call i64 @__extract_rip(ptr %state)
  store i64 %150, ptr %pc_var, align 4
  %next_rva58 = sub i64 %150, %base
  switch i64 %next_rva58, label %dead_end [
    i64 10202, label %bb_27DA
  ]

bb_27DA:                                          ; preds = %bb_2792, %entry
  %block_pc59 = add i64 10202, %base
  store i64 %block_pc59, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc59)
  %151 = load ptr, ptr %mem_var, align 8
  %152 = load i64, ptr %pc_var, align 4
  %153 = call ptr @__lifted_bb_entered(ptr %state, i64 10202, ptr %151)
  %154 = call ptr @BB_27da(ptr %state, i64 %152, ptr %151) #18
  store ptr %154, ptr %mem_var, align 8
  %155 = call i64 @__extract_rip(ptr %state)
  store i64 %155, ptr %pc_var, align 4
  %next_rva60 = sub i64 %155, %base
  switch i64 %next_rva60, label %dead_end [
    i64 10211, label %bb_27E3
  ]

bb_27E3:                                          ; preds = %bb_27DA, %entry
  %block_pc61 = add i64 10211, %base
  store i64 %block_pc61, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc61)
  %156 = load ptr, ptr %mem_var, align 8
  %157 = load i64, ptr %pc_var, align 4
  %158 = call ptr @__lifted_bb_entered(ptr %state, i64 10211, ptr %156)
  %159 = call ptr @BB_27e3(ptr %state, i64 %157, ptr %156) #18
  store ptr %159, ptr %mem_var, align 8
  %160 = call i64 @__extract_rip(ptr %state)
  store i64 %160, ptr %pc_var, align 4
  %next_rva62 = sub i64 %160, %base
  switch i64 %next_rva62, label %dead_end [
    i64 10265, label %bb_2819
  ]

bb_2819:                                          ; preds = %bb_27E3, %entry
  %block_pc63 = add i64 10265, %base
  store i64 %block_pc63, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc63)
  %161 = load ptr, ptr %mem_var, align 8
  %162 = load i64, ptr %pc_var, align 4
  %163 = call ptr @__lifted_bb_entered(ptr %state, i64 10265, ptr %161)
  %164 = call ptr @BB_2819(ptr %state, i64 %162, ptr %161) #18
  store ptr %164, ptr %mem_var, align 8
  %165 = call i64 @__extract_rip(ptr %state)
  store i64 %165, ptr %pc_var, align 4
  %next_rva64 = sub i64 %165, %base
  switch i64 %next_rva64, label %dead_end [
    i64 10348, label %bb_286C
  ]

bb_286C:                                          ; preds = %bb_2819, %entry
  %block_pc65 = add i64 10348, %base
  store i64 %block_pc65, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc65)
  %166 = load ptr, ptr %mem_var, align 8
  %167 = load i64, ptr %pc_var, align 4
  %168 = call ptr @__lifted_bb_entered(ptr %state, i64 10348, ptr %166)
  %169 = call ptr @BB_286c(ptr %state, i64 %167, ptr %166) #18
  store ptr %169, ptr %mem_var, align 8
  %170 = call i64 @__extract_rip(ptr %state)
  store i64 %170, ptr %pc_var, align 4
  %next_rva66 = sub i64 %170, %base
  switch i64 %next_rva66, label %dead_end [
    i64 9574, label %bb_2566
  ]

bb_2875:                                          ; preds = %bb_2753, %bb_260D, %entry
  %block_pc67 = add i64 10357, %base
  store i64 %block_pc67, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc67)
  %171 = load ptr, ptr %mem_var, align 8
  %172 = load i64, ptr %pc_var, align 4
  %173 = call ptr @__lifted_bb_entered(ptr %state, i64 10357, ptr %171)
  %174 = call ptr @BB_2875(ptr %state, i64 %172, ptr %171) #18
  store ptr %174, ptr %mem_var, align 8
  %175 = call i64 @__extract_rip(ptr %state)
  store i64 %175, ptr %pc_var, align 4
  %next_rva68 = sub i64 %175, %base
  switch i64 %next_rva68, label %dead_end [
    i64 10389, label %bb_2895
    i64 10538, label %bb_292A
  ]

bb_2895:                                          ; preds = %bb_2875, %entry
  %block_pc69 = add i64 10389, %base
  store i64 %block_pc69, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc69)
  %176 = load ptr, ptr %mem_var, align 8
  %177 = load i64, ptr %pc_var, align 4
  %178 = call ptr @__lifted_bb_entered(ptr %state, i64 10389, ptr %176)
  %179 = call ptr @BB_2895(ptr %state, i64 %177, ptr %176) #18
  store ptr %179, ptr %mem_var, align 8
  %180 = call i64 @__extract_rip(ptr %state)
  store i64 %180, ptr %pc_var, align 4
  %next_rva70 = sub i64 %180, %base
  switch i64 %next_rva70, label %dead_end [
    i64 10443, label %bb_28CB
  ]

bb_28CB:                                          ; preds = %bb_2895, %entry
  %block_pc71 = add i64 10443, %base
  store i64 %block_pc71, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc71)
  %181 = load ptr, ptr %mem_var, align 8
  %182 = load i64, ptr %pc_var, align 4
  %183 = call ptr @__lifted_bb_entered(ptr %state, i64 10443, ptr %181)
  %184 = call ptr @BB_28cb(ptr %state, i64 %182, ptr %181) #18
  store ptr %184, ptr %mem_var, align 8
  %185 = call i64 @__extract_rip(ptr %state)
  store i64 %185, ptr %pc_var, align 4
  %next_rva72 = sub i64 %185, %base
  switch i64 %next_rva72, label %dead_end [
    i64 8240, label %bb_FFFF000000000001
  ]

bb_28D9:                                          ; preds = %bb_FFFF000000000001, %entry
  %block_pc73 = add i64 10457, %base
  store i64 %block_pc73, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc73)
  %186 = load ptr, ptr %mem_var, align 8
  %187 = load i64, ptr %pc_var, align 4
  %188 = call ptr @__lifted_bb_entered(ptr %state, i64 10457, ptr %186)
  %189 = call ptr @BB_28d9(ptr %state, i64 %187, ptr %186) #18
  store ptr %189, ptr %mem_var, align 8
  %190 = call i64 @__extract_rip(ptr %state)
  store i64 %190, ptr %pc_var, align 4
  %next_rva74 = sub i64 %190, %base
  switch i64 %next_rva74, label %dead_end [
    i64 10529, label %bb_2921
  ]

bb_2921:                                          ; preds = %bb_28D9, %entry
  %block_pc75 = add i64 10529, %base
  store i64 %block_pc75, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc75)
  %191 = load ptr, ptr %mem_var, align 8
  %192 = load i64, ptr %pc_var, align 4
  %193 = call ptr @__lifted_bb_entered(ptr %state, i64 10529, ptr %191)
  %194 = call ptr @BB_2921(ptr %state, i64 %192, ptr %191) #18
  store ptr %194, ptr %mem_var, align 8
  %195 = call i64 @__extract_rip(ptr %state)
  store i64 %195, ptr %pc_var, align 4
  %next_rva76 = sub i64 %195, %base
  switch i64 %next_rva76, label %dead_end [
    i64 10561, label %bb_2941
  ]

bb_292A:                                          ; preds = %bb_2875, %entry
  %block_pc77 = add i64 10538, %base
  store i64 %block_pc77, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc77)
  %196 = load ptr, ptr %mem_var, align 8
  %197 = load i64, ptr %pc_var, align 4
  %198 = call ptr @__lifted_bb_entered(ptr %state, i64 10538, ptr %196)
  %199 = call ptr @BB_292a(ptr %state, i64 %197, ptr %196) #18
  store ptr %199, ptr %mem_var, align 8
  %200 = call i64 @__extract_rip(ptr %state)
  store i64 %200, ptr %pc_var, align 4
  %next_rva78 = sub i64 %200, %base
  switch i64 %next_rva78, label %dead_end [
    i64 8240, label %bb_FFFF000000000000
  ]

bb_2938:                                          ; preds = %bb_FFFF000000000000, %entry
  %block_pc79 = add i64 10552, %base
  store i64 %block_pc79, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc79)
  %201 = load ptr, ptr %mem_var, align 8
  %202 = load i64, ptr %pc_var, align 4
  %203 = call ptr @__lifted_bb_entered(ptr %state, i64 10552, ptr %201)
  %204 = call ptr @BB_2938(ptr %state, i64 %202, ptr %201) #18
  store ptr %204, ptr %mem_var, align 8
  %205 = call i64 @__extract_rip(ptr %state)
  store i64 %205, ptr %pc_var, align 4
  %next_rva80 = sub i64 %205, %base
  switch i64 %next_rva80, label %dead_end [
    i64 10561, label %bb_2941
  ]

bb_2941:                                          ; preds = %bb_2938, %bb_2921, %entry
  %block_pc81 = add i64 10561, %base
  store i64 %block_pc81, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc81)
  %206 = load ptr, ptr %mem_var, align 8
  %207 = load i64, ptr %pc_var, align 4
  %208 = call ptr @__lifted_bb_entered(ptr %state, i64 10561, ptr %206)
  %209 = call ptr @BB_2941(ptr %state, i64 %207, ptr %206) #18
  store ptr %209, ptr %mem_var, align 8
  %210 = call i64 @__extract_rip(ptr %state)
  store i64 %210, ptr %pc_var, align 4
  %next_rva82 = sub i64 %210, %base
  switch i64 %next_rva82, label %dead_end [
    i64 10580, label %bb_2954
  ]

bb_2954:                                          ; preds = %bb_2941, %bb_22BA, %entry
  %block_pc83 = add i64 10580, %base
  store i64 %block_pc83, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc83)
  %211 = load ptr, ptr %mem_var, align 8
  %212 = load i64, ptr %pc_var, align 4
  %213 = call ptr @__lifted_bb_entered(ptr %state, i64 10580, ptr %211)
  %214 = call ptr @BB_2954(ptr %state, i64 %212, ptr %211) #18
  store ptr %214, ptr %mem_var, align 8
  %215 = call i64 @__extract_rip(ptr %state)
  store i64 %215, ptr %pc_var, align 4
  %next_rva84 = sub i64 %215, %base
  switch i64 %next_rva84, label %dead_end [
    i64 10634, label %bb_298A
  ]

bb_298A:                                          ; preds = %bb_2954, %entry
  %block_pc85 = add i64 10634, %base
  store i64 %block_pc85, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc85)
  %216 = load ptr, ptr %mem_var, align 8
  %217 = load i64, ptr %pc_var, align 4
  %218 = call ptr @__lifted_bb_entered(ptr %state, i64 10634, ptr %216)
  %219 = call ptr @BB_298a(ptr %state, i64 %217, ptr %216) #18
  store ptr %219, ptr %mem_var, align 8
  %220 = call i64 @__extract_rip(ptr %state)
  store i64 %220, ptr %pc_var, align 4
  %next_rva86 = sub i64 %220, %base
  switch i64 %next_rva86, label %dead_end [
    i64 10700, label %bb_29CC
  ]

bb_29CC:                                          ; preds = %bb_298A, %entry
  %block_pc87 = add i64 10700, %base
  store i64 %block_pc87, ptr %pc_var, align 4
  call void @__store_rip(ptr %state, i64 %block_pc87)
  %221 = load ptr, ptr %mem_var, align 8
  %222 = load i64, ptr %pc_var, align 4
  %223 = call ptr @__lifted_bb_entered(ptr %state, i64 10700, ptr %221)
  %224 = call ptr @BB_29cc(ptr %state, i64 %222, ptr %221) #18
  store ptr %224, ptr %mem_var, align 8
  %225 = call i64 @__extract_rip(ptr %state)
  store i64 %225, ptr %pc_var, align 4
  %next_rva88 = sub i64 %225, %base
  %226 = load ptr, ptr %mem_var, align 8
  ret ptr %226

bb_FFFF000000000000:                              ; preds = %bb_292A, %entry
  %227 = load ptr, ptr %mem_var, align 8
  %228 = load i64, ptr %pc_var, align 4
  %229 = call ptr @BB_ffff000000000000_ext(ptr %state, i64 %228, ptr %227) #18
  store ptr %229, ptr %mem_var, align 8
  %230 = call i64 @__extract_rip(ptr %state)
  store i64 %230, ptr %pc_var, align 4
  %next_rva89 = sub i64 %230, %base
  switch i64 %next_rva89, label %dead_end [
    i64 10552, label %bb_2938
  ]

bb_FFFF000000000001:                              ; preds = %bb_28CB, %entry
  %231 = load ptr, ptr %mem_var, align 8
  %232 = load i64, ptr %pc_var, align 4
  %233 = call ptr @BB_ffff000000000001_ext(ptr %state, i64 %232, ptr %231) #18
  store ptr %233, ptr %mem_var, align 8
  %234 = call i64 @__extract_rip(ptr %state)
  store i64 %234, ptr %pc_var, align 4
  %next_rva90 = sub i64 %234, %base
  switch i64 %next_rva90, label %dead_end [
    i64 10457, label %bb_28D9
  ]

return_bb:                                        ; No predecessors!
  %235 = load ptr, ptr %mem_var, align 8
  ret ptr %235
}

; Function Attrs: alwaysinline
define ptr @__lifted_rebuilt_cfg_concrete(ptr noalias nocapture %0, ptr noalias nocapture %1, i64 %2) #10 {
  %4 = call ptr @__lifted_rebuilt_cfg(ptr %0, i64 8464, ptr %1, i64 %2)
  ret ptr %4
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local ptr @__remill_function_return(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr noundef readnone returned %memory) local_unnamed_addr #11 {
entry:
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_zero(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_sign(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_overflow(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_flag_computation_carry(i1 noundef returned zeroext %result, ...) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sle(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_slt(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_sgt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ule(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ult(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_ugt(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_uge(i1 noundef returned zeroext %result) local_unnamed_addr #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_eq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i1 @__remill_compare_neq(i1 noundef returned zeroext %result) #11 {
entry:
  ret i1 %result
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i8 @__remill_undefined_8() #11 {
entry:
  ret i8 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local zeroext i16 @__remill_undefined_16() local_unnamed_addr #11 {
entry:
  ret i16 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i32 @__remill_undefined_32() local_unnamed_addr #11 {
entry:
  ret i32 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable
define dso_local i64 @__remill_undefined_64() local_unnamed_addr #11 {
entry:
  ret i64 0
}

; Function Attrs: alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable
define dso_local noalias nonnull ptr @__remill_error(ptr noalias nocapture noundef readnone %0, i64 noundef %1, ptr nocapture noundef readnone %2) local_unnamed_addr #12 {
entry:
  unreachable
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable
define dso_local ptr @__remill_jump(ptr noalias nocapture noundef writeonly %state, i64 noundef %pc, ptr noundef readnone returned %memory) local_unnamed_addr #8 {
entry:
  %rip = getelementptr inbounds %struct.X86State.298968, ptr %state, i64 0, i32 6, i32 33
  store i64 %pc, ptr %rip, align 8, !tbaa !23
  ret ptr %memory
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i8 @__remill_read_memory_8(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i8, ptr %arrayidx, align 1
  ret i8 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local zeroext i16 @__remill_read_memory_16(ptr nocapture noundef readnone %m, i64 noundef %a) local_unnamed_addr #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i16, ptr %arrayidx, align 1
  ret i16 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i32 @__remill_read_memory_32(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i32, ptr %arrayidx, align 1
  ret i32 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable
define dso_local i64 @__remill_read_memory_64(ptr nocapture noundef readnone %m, i64 noundef %a) #13 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  %v.0.copyload = load i64, ptr %arrayidx, align 1
  ret i64 %v.0.copyload
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_8(ptr noundef readnone returned %m, i64 noundef %a, i8 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i8 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_16(ptr noundef readnone returned %m, i64 noundef %a, i16 noundef zeroext %v) local_unnamed_addr #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i16 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_32(ptr noundef readnone returned %m, i64 noundef %a, i32 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i32 %v, ptr %arrayidx, align 1
  ret ptr %m
}

; Function Attrs: alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable
define dso_local ptr @__remill_write_memory_64(ptr noundef readnone returned %m, i64 noundef %a, i64 noundef %v) #14 {
entry:
  %arrayidx = getelementptr inbounds [0 x i8], ptr @RAM, i64 0, i64 %a
  store i64 %v, ptr %arrayidx, align 1
  ret ptr %m
}

attributes #0 = { "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #1 = { nocallback nofree nosync nounwind speculatable willreturn memory(none) }
attributes #2 = { "lifted.annotation_id"="3" "lifted.state_form"="folded" }
attributes #3 = { nocallback nofree nosync nounwind willreturn memory(inaccessiblemem: readwrite) }
attributes #4 = { alwaysinline nounwind memory(readwrite, inaccessiblemem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #5 = { nocallback nofree nounwind willreturn memory(argmem: write) }
attributes #6 = { mustprogress nounwind willreturn memory(read, argmem: readwrite) "disable-tail-calls"="true" "lifted.annotation_id"="1" "lifted.state_form"="folded" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #7 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: read) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #8 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(argmem: write) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #9 = { alwaysinline "lifted.annotation_id"="0" "lifted.state_form"="folded" }
attributes #10 = { alwaysinline "lifted.annotation_id"="2" "lifted.state_form"="folded" }
attributes #11 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #12 = { alwaysinline mustprogress nofree norecurse noreturn nosync nounwind willreturn memory(none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #13 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(read, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #14 = { alwaysinline mustprogress nofree norecurse nosync nounwind willreturn memory(write, argmem: none, inaccessiblemem: none) uwtable "disable-tail-calls"="true" "min-legal-vector-width"="0" "no-trapping-math"="true" "stack-protector-buffer-size"="8" "target-cpu"="x86-64" "target-features"="+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "tune-cpu"="generic" }
attributes #15 = { nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #16 = { alwaysinline nobuiltin nounwind willreturn memory(none) "no-builtins" }
attributes #17 = { nounwind willreturn memory(read, argmem: readwrite) }
attributes #18 = { alwaysinline }

!llvm.linker.options = !{}
!llvm.ident = !{!0, !0, !0}
!llvm.module.flags = !{!1, !2, !3, !4}

!0 = !{!"clang version 16.0.2"}
!1 = !{i32 1, !"wchar_size", i32 4}
!2 = !{i32 8, !"PIC Level", i32 2}
!3 = !{i32 7, !"PIE Level", i32 2}
!4 = !{i32 7, !"uwtable", i32 2}
!5 = !{!6}
!6 = distinct !{!6, !7, !"__extract_rsp: %state"}
!7 = distinct !{!7, !"__extract_rsp"}
!8 = !{!9}
!9 = distinct !{!9, !10, !"__store_rip: %state"}
!10 = distinct !{!10, !"__store_rip"}
!11 = !{!12}
!12 = distinct !{!12, !13, !"__store_rsp: %state"}
!13 = distinct !{!13, !"__store_rsp"}
!14 = !{!15}
!15 = distinct !{!15, !16, !"__extract_rsp: %state"}
!16 = distinct !{!16, !"__extract_rsp"}
!17 = !{!18}
!18 = distinct !{!18, !19, !"__store_rip: %state"}
!19 = distinct !{!19, !"__store_rip"}
!20 = !{!21}
!21 = distinct !{!21, !22, !"__store_rsp: %state"}
!22 = distinct !{!22, !"__store_rsp"}
!23 = !{!24, !24, i64 0}
!24 = !{!"omnipotent char", !25, i64 0}
!25 = !{!"Simple C++ TBAA"}
